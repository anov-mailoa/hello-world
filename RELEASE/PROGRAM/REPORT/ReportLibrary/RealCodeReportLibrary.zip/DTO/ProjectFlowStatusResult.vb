﻿Public Class ProjectFlowStatusResult
    Public Property CSESSION_ID As String
    Public Property CSESSION_NOTE As String
    Public Property CSCHEDULE_ID As String
    Public Property CSCHEDULE_NOTE As String
    Public Property CATTRIBUTE_GROUP As String
    Public Property CATTRIBUTE_ID As String
    Public Property CITEM_ID As String
    Public Property CITEM_NAME As String
    Public Property CPROJECT_STATUS As String
    Public Property CFUNCTION_ID As String
    Public Property CUSER_ID As String
    Public Property CUSER_NAME As String
    Public Property DPLAN_START_DATE As Nullable(Of Date)
    Public Property DPLAN_END_DATE As Nullable(Of Date)
    Public Property NMANDAYS As Decimal
    Public Property DACTUAL_START_DATE As Nullable(Of Date)
    Public Property DACTUAL_END_DATE As Nullable(Of Date)
    Public Property NACTUAL_MANDAYS As Decimal
    Public Property NDIFF As Decimal
End Class
