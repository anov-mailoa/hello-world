﻿Public Class ReleaseNoteResult
    Public Property CVERSION As String
    Public Property CREVISION As String
    Public Property CISSUE_ID As String
    Public Property CPROGRAM_ID As String
    Public Property CATTRIBUTE_NAME As String
    Public Property CDESCRIPTION As String
End Class
