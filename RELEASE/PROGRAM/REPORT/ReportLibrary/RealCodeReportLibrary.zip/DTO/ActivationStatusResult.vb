﻿Public Class ActivationStatusResult
    Public Property CAPPS_NAME As String
    Public Property CCUSTOMER_CODE As String
    Public Property CCUSTOMER_NAME As String
    Public Property CLAST_EXPIRY_DATE As String
    Public Property NWARNING_DAYS As Integer
    Public Property NDAYS_LEFT As Integer
End Class
