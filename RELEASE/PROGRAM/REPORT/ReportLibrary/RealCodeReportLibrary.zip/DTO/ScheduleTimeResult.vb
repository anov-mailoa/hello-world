﻿Public Class ScheduleTimeResult
    Public Property CSCHEDULE_ID As String
    Public Property CSCHEDULE_NOTE As String
    Public Property CSESSION_ID As String
    Public Property CSESSION_NOTE As String
    Public Property CATTRIBUTE_GROUP As String
    Public Property CATTRIBUTE_ID As String
    Public Property CITEM_ID As String
    Public Property CITEM_NAME As String
    Public Property CFUNCTION_ID As String
    Public Property CUSER_ID As String
    Public Property CUSER_NAME As String
    Public Property CREASSIGNMENT_ID As String
    Public Property CREASSIGNMENT_NAME As String
    Public Property DPLAN_START_DATE As Date
    Public Property DPLAN_END_DATE As Date
    Public Property NMANDAYS As Decimal
    Public Property DREVISED_START_DATE As Nullable(Of Date)
    Public Property DREVISED_END_DATE As Nullable(Of Date)
    Public Property NREVISED_MANDAYS As Decimal
    Public Property DACTUAL_START_DATE As Nullable(Of Date)
    Public Property DACTUAL_END_DATE As Nullable(Of Date)
    Public Property NACTUAL_MANDAYS As Decimal
    Public Property NDIFF As Decimal
    Public Property CACTION As String
    Public Property CSEQUENCE As String
    Public Property CACTION_USER_ID As String
    Public Property DACTION_DATE As Date
    Public Property CACTION_TIME As String
End Class
