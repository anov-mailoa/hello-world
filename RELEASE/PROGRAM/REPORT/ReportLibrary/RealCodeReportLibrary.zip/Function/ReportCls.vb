﻿Imports R_BackEnd
Imports R_Common

Public Class ReportCls

    Public Function TeamReview(pcCompanyId As String, _
                        pcAppsCode As String, _
                        pcVersion As String, _
                        pcProjectId As String, _
                        pcCutoffType As String) As List(Of TeamReviewResult)
        Dim lcQuery As String
        Dim loResult As List(Of TeamReviewResult)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "EXEC RSP_Team_Review '{0}', '{1}', '{2}', '{3}', '{4}' "
            lcQuery = String.Format(lcQuery, pcCompanyId, pcAppsCode, pcVersion, pcProjectId, pcCutoffType)
            loResult = loDb.SqlExecObjectQuery(Of TeamReviewResult)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function ScheduleTime(pcCompanyId As String, _
                        pcAppsCode As String, _
                        pcVersion As String, _
                        pcProjectId As String) As List(Of ScheduleTimeResult)
        Dim lcQuery As String
        Dim loResult As List(Of ScheduleTimeResult)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "EXEC RSP_Schedule_Time '{0}', '{1}', '{2}', '{3}' "
            lcQuery = String.Format(lcQuery, pcCompanyId, pcAppsCode, pcVersion, pcProjectId)
            loResult = loDb.SqlExecObjectQuery(Of ScheduleTimeResult)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function Quality(pcCompanyId As String, _
                        pcAppsCode As String, _
                        pcVersion As String, _
                        pcProjectId As String) As List(Of QualityResult)
        Dim lcQuery As String
        Dim loResult As List(Of QualityResult)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "EXEC RSP_Quality '{0}', '{1}', '{2}', '{3}' "
            lcQuery = String.Format(lcQuery, pcCompanyId, pcAppsCode, pcVersion, pcProjectId)
            loResult = loDb.SqlExecObjectQuery(Of QualityResult)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function ProjectFlowStatus(pcCompanyId As String, _
                        pcAppsCode As String, _
                        pcVersion As String, _
                        pcProjectId As String) As List(Of ProjectFlowStatusResult)
        Dim lcQuery As String
        Dim loResult As List(Of ProjectFlowStatusResult)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "EXEC RSP_Project_Flow_Status '{0}', '{1}', '{2}', '{3}' "
            lcQuery = String.Format(lcQuery, pcCompanyId, pcAppsCode, pcVersion, pcProjectId)
            loResult = loDb.SqlExecObjectQuery(Of ProjectFlowStatusResult)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function CheckoutItems(pcCompanyId As String, _
                        pcAppsCode As String, _
                        pcVersion As String) As List(Of CheckoutItemsResult)
        Dim lcQuery As String
        Dim loResult As List(Of CheckoutItemsResult)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "EXEC RSP_Get_Checkout_Item '{0}', '{1}', '{2}' "
            lcQuery = String.Format(lcQuery, pcCompanyId, pcAppsCode, pcVersion)
            loResult = loDb.SqlExecObjectQuery(Of CheckoutItemsResult)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function CheckinHistory(pcCompanyId As String, _
                    pcAppsCode As String, _
                    pcAttributeId As String, _
                    pcProgramId As String, _
                    pcVersion As String) As List(Of CheckinHistoryResult)
        Dim lcQuery As String
        Dim loResult As List(Of CheckinHistoryResult)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "EXEC RSP_Checkin_History '{0}', '{1}', '{2}', '{3}', '{4}' "
            lcQuery = String.Format(lcQuery, pcCompanyId, pcAppsCode, pcAttributeId, pcProgramId, pcVersion)
            loResult = loDb.SqlExecObjectQuery(Of CheckinHistoryResult)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function ProgramProfile(pcCompanyId As String, _
                    pcAppsCode As String) As List(Of ProgramProfileResult)
        Dim lcQuery As String
        Dim loResult As List(Of ProgramProfileResult)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "EXEC RSP_Program_Profile '{0}', '{1}' "
            lcQuery = String.Format(lcQuery, pcCompanyId, pcAppsCode)
            loResult = loDb.SqlExecObjectQuery(Of ProgramProfileResult)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function ActivationStatus(pcCompanyId As String, _
                                     pcOption As String) As List(Of ActivationStatusResult)
        Dim lcQuery As String
        Dim loResult As List(Of ActivationStatusResult)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "EXEC RSP_Activation_Status '{0}', '{1}' "
            lcQuery = String.Format(lcQuery, pcCompanyId, pcOption)
            loResult = loDb.SqlExecObjectQuery(Of ActivationStatusResult)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function ActivityHistory(pcCompanyId As String, _
                pcAppsCode As String, _
                pcAttributeGroup As String, _
                pcAttributeId As String, _
                pcItemId As String, _
                pcVersion As String) As List(Of ActivityHistoryResult)
        Dim lcQuery As String
        Dim loResult As List(Of ActivityHistoryResult)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "EXEC RSP_Activity_History '{0}', '{1}', '{2}', '{3}', '{4}', '{5}' "
            lcQuery = String.Format(lcQuery, pcCompanyId, pcAppsCode, pcAttributeGroup, pcAttributeId, pcItemId, pcVersion)
            loResult = loDb.SqlExecObjectQuery(Of ActivityHistoryResult)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function ReleaseNote(pcCompanyId As String,
                pcAppsCode As String,
                pcVersion As String) As List(Of ReleaseNoteResult)
        Dim lcQuery As String
        Dim loResult As List(Of ReleaseNoteResult)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "EXEC RSP_Release_Note '{0}', '{1}', '{2}' "
            lcQuery = String.Format(lcQuery, pcCompanyId, pcAppsCode, pcVersion)
            loResult = loDb.SqlExecObjectQuery(Of ReleaseNoteResult)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

End Class
