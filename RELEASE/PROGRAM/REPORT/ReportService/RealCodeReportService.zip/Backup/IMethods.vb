﻿Imports System.ServiceModel
Imports RealCodeReportLibrary

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IMethods" in both code and config file together.
<ServiceContract()>
Public Interface IMethods

    <OperationContract(), WebGet()> _
    Function TeamReview(pcCompanyId As String, _
                        pcAppsCode As String, _
                        pcVersion As String, _
                        pcProjectId As String, _
                        pcCutoffType As String) As List(Of TeamReviewResult)

    <OperationContract(), WebGet()> _
    Function ScheduleTime(pcCompanyId As String, _
                        pcAppsCode As String, _
                        pcVersion As String, _
                        pcProjectId As String) As List(Of ScheduleTimeResult)

    <OperationContract(), WebGet()> _
    Function Quality(pcCompanyId As String, _
                        pcAppsCode As String, _
                        pcVersion As String, _
                        pcProjectId As String) As List(Of QualityResult)

    <OperationContract(), WebGet()> _
    Function ProjectFlowStatus(pcCompanyId As String, _
                        pcAppsCode As String, _
                        pcVersion As String, _
                        pcProjectId As String) As List(Of ProjectFlowStatusResult)

    <OperationContract(), WebGet()> _
    Function CheckoutItemList(pcCompanyId As String, _
                        pcAppsCode As String, _
                        pcVersion As String) As List(Of CheckoutItemsResult)

    <OperationContract(), WebGet()> _
    Function CheckinHistory(pcCompanyId As String, _
                        pcAppsCode As String, _
                        pcAttributeId As String, _
                        pcProgramId As String, _
                        pcVersion As String) As List(Of CheckinHistoryResult)

    <OperationContract(), WebGet()> _
    Function ProgramProfile(pcCompanyId As String, _
                        pcAppsCode As String) As List(Of ProgramProfileResult)

    <OperationContract(), WebGet()> _
    Function ActivationStatus(pcCompanyId As String, _
                        pcOption As String) As List(Of ActivationStatusResult)

    <OperationContract(), WebGet()> _
    Function ActivityHistory(pcCompanyId As String, _
                        pcAppsCode As String, _
                        pcAttributeGroup As String, _
                        pcAttributeId As String, _
                        pcItemId As String, _
                        pcVersion As String) As List(Of ActivityHistoryResult)

End Interface
