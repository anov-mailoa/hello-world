﻿Imports R_Common
Imports RealCodeReportLibrary

' NOTE: You can use the "Rename" command on the context menu to change the class name "Parameters" in code, svc and config file together.
Public Class Parameters
    Implements IParameters

    Public Function GetApps(pcCompanyId As String) As System.Collections.Generic.List(Of RealCodeReportLibrary.Apps) Implements IParameters.GetApps
        Dim loException As New R_Exception
        Dim loCls As New ParamCls
        Dim loRtn As List(Of Apps)

        Try
            loRtn = loCls.GetApps(pcCompanyId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetProjects(pcCompanyId As String, pcAppsCode As String, pcVersion As String) As System.Collections.Generic.List(Of RealCodeReportLibrary.Projects) Implements IParameters.GetProjects
        Dim loException As New R_Exception
        Dim loCls As New ParamCls
        Dim loRtn As List(Of Projects)

        Try
            loRtn = loCls.GetProjects(pcCompanyId, pcAppsCode, pcVersion)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetVersions(pcCompanyId As String, pcAppsCode As String) As System.Collections.Generic.List(Of RealCodeReportLibrary.Versions) Implements IParameters.GetVersions
        Dim loException As New R_Exception
        Dim loCls As New ParamCls
        Dim loRtn As List(Of Versions)

        Try
            loRtn = loCls.GetVersions(pcCompanyId, pcAppsCode)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetProgramAttributes(pcCompanyId As String, pcAppsCode As String) As System.Collections.Generic.List(Of RealCodeReportLibrary.Attributes) Implements IParameters.GetProgramAttributes
        Dim loException As New R_Exception
        Dim loCls As New ParamCls
        Dim loRtn As List(Of Attributes)

        Try
            loRtn = loCls.GetProgramAttributes(pcCompanyId, pcAppsCode)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetPrograms(pcCompanyId As String, pcAppsCode As String, pcAttributeId As String) As System.Collections.Generic.List(Of RealCodeReportLibrary.Programs) Implements IParameters.GetPrograms
        Dim loException As New R_Exception
        Dim loCls As New ParamCls
        Dim loRtn As List(Of Programs)

        Try
            loRtn = loCls.GetPrograms(pcCompanyId, pcAppsCode, pcAttributeId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetItems(pcCompanyId As String, pcAppsCode As String, pcAttributeGroup As String, pcAttributeId As String) As System.Collections.Generic.List(Of RealCodeReportLibrary.Items) Implements IParameters.GetItems
        Dim loException As New R_Exception
        Dim loCls As New ParamCls
        Dim loRtn As List(Of Items)

        Try
            loRtn = loCls.GetItems(pcCompanyId, pcAppsCode, pcAttributeGroup, pcAttributeId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
