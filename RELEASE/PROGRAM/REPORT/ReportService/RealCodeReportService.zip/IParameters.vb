﻿Imports System.ServiceModel
Imports RealCodeReportLibrary

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IParameters" in both code and config file together.
<ServiceContract()>
Public Interface IParameters

    <OperationContract(), WebGet()> _
    Function GetApps(pcCompanyId As String) As List(Of Apps)

    <OperationContract(), WebGet()> _
    Function GetVersions(pcCompanyId As String, pcAppsCode As String) As List(Of Versions)

    <OperationContract(), WebGet()> _
    Function GetProjects(pcCompanyId As String, pcAppsCode As String, pcVersion As String) As List(Of Projects)

    <OperationContract(), WebGet()> _
    Function GetProgramAttributes(pcCompanyId As String, pcAppsCode As String) As List(Of Attributes)

    <OperationContract(), WebGet()> _
    Function GetPrograms(pcCompanyId As String, pcAppsCode As String, pcAttributeId As String) As List(Of Programs)

    <OperationContract(), WebGet()> _
    Function GetItems(pcCompanyId As String, pcAppsCode As String, pcAttributeGroup As String, pcAttributeId As String) As List(Of Items)

End Interface
