﻿Imports R_Common
Imports RealCodeReportLibrary

' NOTE: You can use the "Rename" command on the context menu to change the class name "Methods" in code, svc and config file together.
Public Class Methods
    Implements IMethods

    Public Function TeamReview(pcCompanyId As String, pcAppsCode As String, pcVersion As String, pcProjectId As String, pcCutoffType As String) As System.Collections.Generic.List(Of RealCodeReportLibrary.TeamReviewResult) Implements IMethods.TeamReview
        Dim loException As New R_Exception
        Dim loCls As New ReportCls
        Dim loRtn As List(Of TeamReviewResult)

        Try
            loRtn = loCls.TeamReview(pcCompanyId, pcAppsCode, pcVersion, pcProjectId, pcCutoffType)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function ScheduleTime(pcCompanyId As String, pcAppsCode As String, pcVersion As String, pcProjectId As String) As System.Collections.Generic.List(Of RealCodeReportLibrary.ScheduleTimeResult) Implements IMethods.ScheduleTime
        Dim loException As New R_Exception
        Dim loCls As New ReportCls
        Dim loRtn As List(Of ScheduleTimeResult)

        Try
            loRtn = loCls.ScheduleTime(pcCompanyId, pcAppsCode, pcVersion, pcProjectId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Quality(pcCompanyId As String, pcAppsCode As String, pcVersion As String, pcProjectId As String) As System.Collections.Generic.List(Of RealCodeReportLibrary.QualityResult) Implements IMethods.Quality
        Dim loException As New R_Exception
        Dim loCls As New ReportCls
        Dim loRtn As List(Of QualityResult)

        Try
            loRtn = loCls.Quality(pcCompanyId, pcAppsCode, pcVersion, pcProjectId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function ProjectFlowStatus(pcCompanyId As String, pcAppsCode As String, pcVersion As String, pcProjectId As String) As System.Collections.Generic.List(Of RealCodeReportLibrary.ProjectFlowStatusResult) Implements IMethods.ProjectFlowStatus
        Dim loException As New R_Exception
        Dim loCls As New ReportCls
        Dim loRtn As List(Of ProjectFlowStatusResult)

        Try
            loRtn = loCls.ProjectFlowStatus(pcCompanyId, pcAppsCode, pcVersion, pcProjectId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function CheckoutItemList(pcCompanyId As String, pcAppsCode As String, pcVersion As String) As System.Collections.Generic.List(Of RealCodeReportLibrary.CheckoutItemsResult) Implements IMethods.CheckoutItemList
        Dim loException As New R_Exception
        Dim loCls As New ReportCls
        Dim loRtn As List(Of CheckoutItemsResult)

        Try
            loRtn = loCls.CheckoutItems(pcCompanyId, pcAppsCode, pcVersion)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function CheckinHistory(pcCompanyId As String, pcAppsCode As String, pcAttributeId As String, pcProgramId As String, pcVersion As String) As System.Collections.Generic.List(Of RealCodeReportLibrary.CheckinHistoryResult) Implements IMethods.CheckinHistory
        Dim loException As New R_Exception
        Dim loCls As New ReportCls
        Dim loRtn As List(Of CheckinHistoryResult)

        Try
            loRtn = loCls.CheckinHistory(pcCompanyId, pcAppsCode, pcAttributeId, pcProgramId, pcVersion)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function ProgramProfile(pcCompanyId As String, pcAppsCode As String) As System.Collections.Generic.List(Of RealCodeReportLibrary.ProgramProfileResult) Implements IMethods.ProgramProfile
        Dim loException As New R_Exception
        Dim loCls As New ReportCls
        Dim loRtn As List(Of ProgramProfileResult)

        Try
            loRtn = loCls.ProgramProfile(pcCompanyId, pcAppsCode)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function ActivationStatus(pcCompanyId As String, pcOption As String) As System.Collections.Generic.List(Of RealCodeReportLibrary.ActivationStatusResult) Implements IMethods.ActivationStatus
        Dim loException As New R_Exception
        Dim loCls As New ReportCls
        Dim loRtn As List(Of ActivationStatusResult)

        Try
            loRtn = loCls.ActivationStatus(pcCompanyId, pcOption)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function ActivityHistory(pcCompanyId As String, pcAppsCode As String, pcAttributeGroup As String, pcAttributeId As String, pcItemId As String, pcVersion As String) As System.Collections.Generic.List(Of RealCodeReportLibrary.ActivityHistoryResult) Implements IMethods.ActivityHistory
        Dim loException As New R_Exception
        Dim loCls As New ReportCls
        Dim loRtn As List(Of ActivityHistoryResult)

        Try
            loRtn = loCls.ActivityHistory(pcCompanyId, pcAppsCode, pcAttributeGroup, pcAttributeId, pcItemId, pcVersion)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function ReleaseNote(pcCompanyId As String, pcAppsCode As String, pcVersion As String) As List(Of ReleaseNoteResult) Implements IMethods.ReleaseNote
        Dim loException As New R_Exception
        Dim loCls As New ReportCls
        Dim loRtn As List(Of ReleaseNoteResult)

        Try
            loRtn = loCls.ReleaseNote(pcCompanyId, pcAppsCode, pcVersion)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
