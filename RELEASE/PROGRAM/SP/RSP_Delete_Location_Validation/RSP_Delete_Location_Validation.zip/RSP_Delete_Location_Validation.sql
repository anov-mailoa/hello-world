/****** Object:  StoredProcedure [dbo].[RSP_Delete_Location_Validation]    Script Date: 9/22/2014 3:54:01 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSP_Delete_Location_Validation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSP_Delete_Location_Validation]
GO

/****** Object:  StoredProcedure [dbo].[RSP_Delete_Location_Validation]    Script Date: 9/22/2014 3:54:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Anov Mailoa
-- Create date: 10 February 2017
-- Description:	RSP_Delete_Location_Validation - To validate location removal
-- =============================================
CREATE PROCEDURE [dbo].[RSP_Delete_Location_Validation] 
	@CLOCATION_ID VARCHAR(20),
	@CRET_MSG VARCHAR(50) OUTPUT
WITH RECOMPILE, ENCRYPTION
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @CVALID_CODE AS VARCHAR(200)

	-- check if there are any user session assigned to the location
	SELECT TOP 1 @CVALID_CODE = RTRIM(CCOMPANY_ID) + 
		'|' + RTRIM(CAPPS_CODE) +
		'|' + RTRIM(CVERSION) +
		'|' + RTRIM(CPROJECT_ID) +
		'|' + RTRIM(CSESSION_ID) +
		'|' + RTRIM(CUSER_ID)
	FROM CSM_PROJECT_USERS (NOLOCK)
	WHERE CLOCATION_ID = @CLOCATION_ID
	IF @CVALID_CODE IS NOT NULL BEGIN
		-- last version has not been released
		SELECT @CRET_MSG = 'USER_SESSION_EXISTS'
		RETURN
	END

	SELECT @CRET_MSG = 'OK'
	RETURN
END
GO
