/****** Object:  StoredProcedure [dbo].[RSP_Get_Schedule_Combo]    Script Date: 9/22/2014 3:54:01 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSP_Get_Schedule_Combo]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSP_Get_Schedule_Combo]
GO

/****** Object:  StoredProcedure [dbo].[RSP_Get_Schedule_Combo]    Script Date: 9/22/2014 3:54:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Anov Mailoa
-- Create date: 20 February 2017
-- Description:	RSP_Get_Schedule_Combo - To display schedule combo
-- =============================================
CREATE PROCEDURE [dbo].[RSP_Get_Schedule_Combo] 
	@CCOMPANY_ID VARCHAR(8),
	@CAPPS_CODE VARCHAR(20),
	@CVERSION VARCHAR(15),
	@CPROJECT_ID VARCHAR(20),
	@CSESSION_ID VARCHAR(20),
	@CSTATUS VARCHAR(20)
WITH RECOMPILE, ENCRYPTION
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT A.CSCHEDULE_ID, B.CSCHEDULE_TYPE_NAME, A.CSTATUS,
	RTRIM(A.CSCHEDULE_ID) + ' - '  + RTRIM(B.CSCHEDULE_TYPE_NAME) 
	+ CASE WHEN RTRIM(A.CNOTE) = '' THEN '' ELSE ' - ' + dbo.RFN_Truncate_With_Ellipsis(A.CNOTE, 20) END AS CSCHEDULE_DESCRIPTION,
	B.IDESIGN_SEQUENCE, B.IDEV_SEQUENCE, B.IQC_SEQUENCE
	FROM CST_PROJECT_SCHEDULE A (NOLOCK)
	JOIN CSM_SCHEDULE_TYPE B (NOLOCK)
	ON B.CSCHEDULE_TYPE = A.CSCHEDULE_TYPE
    WHERE A.CCOMPANY_ID = @CCOMPANY_ID
    AND A.CAPPS_CODE = @CAPPS_CODE
    AND A.CVERSION = @CVERSION
    AND A.CPROJECT_ID = @CPROJECT_ID
	AND A.CSESSION_ID = @CSESSION_ID
	AND (@CSTATUS = '*' OR A.CSTATUS = @CSTATUS)

END
GO
