/****** Object:  StoredProcedure [dbo].[RSP_Get_App_Combo]    Script Date: 9/22/2014 3:54:01 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSP_Get_App_Combo]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSP_Get_App_Combo]
GO

/****** Object:  StoredProcedure [dbo].[RSP_Get_App_Combo]    Script Date: 9/22/2014 3:54:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Anov Mailoa
-- Create date: 10 November 2016
-- Description:	RSP_Get_App_Combo - To display application combo
-- =============================================
CREATE PROCEDURE [dbo].[RSP_Get_App_Combo] 
	@CCOMPANY_ID VARCHAR(8),
	@CUSER_ID VARCHAR(8),
	@CCOMMERCIAL CHAR(1)
WITH RECOMPILE, ENCRYPTION
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	SELECT A.CCOMPANY_ID, A.CAPPS_CODE,
	RTRIM(A.CAPPS_CODE) + ' - ' + RTRIM(A.CAPPS_NAME) AS CAPPS_NAME 
    FROM RVM_APPLICATION A (NOLOCK)
	JOIN RVM_APP_USER B (NOLOCK)
	ON B.CCOMPANY_ID = A.CCOMPANY_ID
	AND B.CAPPS_CODE = A.CAPPS_CODE
	AND B.CUSER_ID = @CUSER_ID
    WHERE A.CCOMPANY_ID = @CCOMPANY_ID
	AND A.LCOMMERCIAL = CASE @CCOMMERCIAL WHEN 'Y' THEN 1 WHEN 'N' THEN 0 ELSE A.LCOMMERCIAL END

END
GO
