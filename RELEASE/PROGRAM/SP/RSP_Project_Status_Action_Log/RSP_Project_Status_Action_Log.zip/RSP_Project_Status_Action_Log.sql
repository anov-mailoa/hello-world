/****** Object:  StoredProcedure [dbo].[RSP_Project_Status_Action_Log]    Script Date: 9/22/2014 3:54:01 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSP_Project_Status_Action_Log]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSP_Project_Status_Action_Log]
GO

/****** Object:  StoredProcedure [dbo].[RSP_Project_Status_Action_Log]    Script Date: 9/22/2014 3:54:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Anov Mailoa
-- Create date: 7 September 2017
-- Description:	RSP_Project_Status_Action_Log - To get project status action log
-- =============================================
CREATE PROCEDURE [dbo].[RSP_Project_Status_Action_Log] 
	@CCOMPANY_ID VARCHAR(8),
	@CAPPS_CODE VARCHAR(20),
	@CVERSION VARCHAR(15),
	@CPROJECT_ID VARCHAR(20),
	@CSESSION_ID VARCHAR(20),
	@CSCHEDULE_ID VARCHAR(20),
	@CATTRIBUTE_GROUP VARCHAR(20),
	@CATTRIBUTE_ID VARCHAR(20),
	@CITEM_ID VARCHAR(50),
	@CFUNCTION_ID VARCHAR(20)
WITH RECOMPILE, ENCRYPTION
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	/*

							    | Assignment                                      |
	| Session | Schedule | Item | Function | User | Location | MD | Plan | Actual |

	| Action Log                    |
	| Action | Sequence | Date/Time |
	
	*/

	SELECT A.CACTION, A.CSEQUENCE,
	A.CACTION_DATE, A.CACTION_TIME
	FROM CST_PROCESS_LOG A (NOLOCK)
	WHERE A.CCOMPANY_ID = @CCOMPANY_ID
	AND A.CAPPS_CODE = @CAPPS_CODE
	AND A.CVERSION = @CVERSION
	AND A.CPROJECT_ID = @CPROJECT_ID
	AND A.CSESSION_ID = @CSESSION_ID
	AND A.CSCHEDULE_ID = @CSCHEDULE_ID
	AND A.CATTRIBUTE_GROUP = @CATTRIBUTE_GROUP
	AND A.CATTRIBUTE_ID = @CATTRIBUTE_ID
	AND A.CITEM_ID = @CITEM_ID
	AND A.CFUNCTION_ID = @CFUNCTION_ID
	ORDER BY A.CITEM_ID, A.CACTION_DATE, A.CACTION_TIME, A.CSCHEDULE_ID

END
GO
