/****** Object:  StoredProcedure [dbo].[RSP_Delete_CR_Validation]    Script Date: 9/22/2014 3:54:01 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSP_Delete_CR_Validation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSP_Delete_CR_Validation]
GO

/****** Object:  StoredProcedure [dbo].[RSP_Delete_CR_Validation]    Script Date: 9/22/2014 3:54:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Anov Mailoa
-- Create date: 6 December 2016
-- Description:	RSP_Delete_CR_Validation - To validate CR removal
-- =============================================
CREATE PROCEDURE [dbo].[RSP_Delete_CR_Validation] 
	@CCOMPANY_ID VARCHAR(8),
	@CAPPS_CODE VARCHAR(20),
	@CATTRIBUTE_GROUP VARCHAR(20),
	@CATTRIBUTE_ID VARCHAR(20),
	@CITEM_ID VARCHAR(30),
	@CCR_ID VARCHAR(3),
	@CSEQUENCE CHAR(3),
	@COPTION VARCHAR(20),
	@CRET_MSG VARCHAR(50) OUTPUT
WITH RECOMPILE, ENCRYPTION
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @CSTATUS AS VARCHAR(20)

	-- check CR status
	SELECT TOP 1 @CSTATUS = CSTATUS
	FROM CSM_PROGRAM_CHANGES (NOLOCK)
	WHERE CCOMPANY_ID = @CCOMPANY_ID
	AND CAPPS_CODE = @CAPPS_CODE
	AND CATTRIBUTE_GROUP = @CATTRIBUTE_GROUP
	AND CATTRIBUTE_ID = @CATTRIBUTE_ID
	AND CPROGRAM_ID = @CITEM_ID
	AND CCR_ID = @CCR_ID
	IF @CSTATUS <> 'NEW' BEGIN
		-- status is not new, cannot delete
		SELECT @CRET_MSG = 'STATUS_NOT_NEW'
		RETURN
	END

	SELECT @CRET_MSG = 'OK'
	RETURN
END
GO
