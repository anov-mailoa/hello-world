/****** Object:  StoredProcedure [dbo].[RSP_Get_Issue_Combo]    Script Date: 9/22/2014 3:54:01 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSP_Get_Issue_Combo]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSP_Get_Issue_Combo]
GO

/****** Object:  StoredProcedure [dbo].[RSP_Get_Issue_Combo]    Script Date: 9/22/2014 3:54:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Anov Mailoa
-- Create date: 20 February 2017
-- Description:	RSP_Get_Issue_Combo - To display schedule combo
-- =============================================
CREATE PROCEDURE [dbo].[RSP_Get_Issue_Combo] 
	@CCOMPANY_ID VARCHAR(8),
	@CAPPS_CODE VARCHAR(20),
	@CVERSION VARCHAR(15),
	@CPROJECT_ID VARCHAR(20),
	@CSESSION_ID VARCHAR(20),
	@CATTRIBUTE_GROUP VARCHAR(20),
	@CATTRIBUTE_ID VARCHAR(20),
	@CITEM_ID VARCHAR(30),
	@CISSUE_TYPE VARCHAR(8),
	@LOUTSTANDING_ONLY BIT
WITH RECOMPILE, ENCRYPTION
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT CISSUE_ID, RTRIM(CDESCRIPTION) + ' (' + RTRIM(CISSUE_ID) + ')' AS CDESCRIPTION,
		LOK
	FROM CST_ISSUES (NOLOCK)
	WHERE CCOMPANY_ID = @CCOMPANY_ID
	AND CAPPS_CODE = @CAPPS_CODE
	AND CVERSION = @CVERSION
	AND CPROJECT_ID = @CPROJECT_ID
	AND CSESSION_ID = @CSESSION_ID
	AND CATTRIBUTE_GROUP = @CATTRIBUTE_GROUP
	AND CATTRIBUTE_ID = @CATTRIBUTE_ID
	AND CITEM_ID = @CITEM_ID
	AND CISSUE_TYPE = CASE WHEN @CISSUE_TYPE = '*' THEN CISSUE_TYPE ELSE @CISSUE_TYPE END
	AND LOK = CASE WHEN @LOUTSTANDING_ONLY = 1 THEN 0 ELSE LOK END
	UNION
	SELECT '', '---', CONVERT(BIT, 0)

END
GO
