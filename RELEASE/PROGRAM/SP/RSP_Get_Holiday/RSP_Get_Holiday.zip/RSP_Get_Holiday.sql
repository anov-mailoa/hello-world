/****** Object:  StoredProcedure [dbo].[RSP_Get_Holiday]    Script Date: 9/22/2014 3:54:01 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSP_Get_Holiday]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSP_Get_Holiday]
GO

/****** Object:  StoredProcedure [dbo].[RSP_Get_Holiday]    Script Date: 9/22/2014 3:54:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Anov Mailoa
-- Create date: 15 August 2016
-- Description:	RSP_Get_Holiday - To display holiday calendar
-- =============================================
CREATE PROCEDURE [dbo].[RSP_Get_Holiday] 
	@CYEAR VARCHAR(4),
	@CMONTH VARCHAR(2)
WITH RECOMPILE, ENCRYPTION
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	-- default year
	DECLARE @CPADDED_YEAR VARCHAR(4)
	SET @CPADDED_YEAR = RIGHT('0000' + LTRIM(RTRIM(@CYEAR)), 4)
	IF NOT @CPADDED_YEAR BETWEEN '1900' AND '2100' BEGIN
		SELECT @CPADDED_YEAR = CONVERT(VARCHAR(4), GETDATE(), 112)
	END
	-- default month
	DECLARE @CPADDED_MONTH VARCHAR(2)
	SET @CPADDED_MONTH = RIGHT('00' + LTRIM(RTRIM(@CMONTH)), 2)
	IF NOT @CPADDED_MONTH BETWEEN '01' AND '12' BEGIN
		SELECT @CPADDED_MONTH = SUBSTRING(CONVERT(VARCHAR(8), GETDATE(), 112), 5, 2)
	END

	SELECT CYEAR = LEFT(CHOLIDAY_DATE, 4),
		CMONTH = SUBSTRING(CHOLIDAY_DATE, 5, 2),
		CDAY = RIGHT(CHOLIDAY_DATE, 2),
		CDESCRIPTION
	FROM CSM_HOLIDAY (NOLOCK)
	WHERE LEFT(CHOLIDAY_DATE, 4) = @CPADDED_YEAR 
	AND (SUBSTRING(CHOLIDAY_DATE, 5, 2) = @CPADDED_MONTH OR @CMONTH = '*')

END
GO
