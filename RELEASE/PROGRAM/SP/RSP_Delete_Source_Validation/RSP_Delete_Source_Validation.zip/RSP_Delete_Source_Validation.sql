/****** Object:  StoredProcedure [dbo].[RSP_Delete_Source_Validation]    Script Date: 9/22/2014 3:54:01 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSP_Delete_Source_Validation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSP_Delete_Source_Validation]
GO

/****** Object:  StoredProcedure [dbo].[RSP_Delete_Source_Validation]    Script Date: 9/22/2014 3:54:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Anov Mailoa
-- Create date: 24 February 2016
-- Description:	RSP_Delete_Source_Validation - To validate source removal
-- =============================================
CREATE PROCEDURE [dbo].[RSP_Delete_Source_Validation] 
	@CCOMPANY_ID VARCHAR(8),
	@CAPPS_CODE VARCHAR(20),
	@CATTRIBUTE_GROUP VARCHAR(20),
	@CATTRIBUTE_ID VARCHAR(20),
	@CPROGRAM_ID VARCHAR(30),
	@CSOURCE_ID VARCHAR(30),
	@CRET_MSG VARCHAR(50) OUTPUT
WITH RECOMPILE, ENCRYPTION
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @CVALID_CODE AS VARCHAR(100)

	-- check if there are any transaction for this source
	SELECT TOP 1 @CVALID_CODE = CSOURCE_ID
	FROM CST_SOURCES (NOLOCK)
	WHERE CCOMPANY_ID = @CCOMPANY_ID
	AND CAPPS_CODE = @CAPPS_CODE
	AND CATTRIBUTE_GROUP = @CATTRIBUTE_GROUP
	AND CATTRIBUTE_ID = @CATTRIBUTE_ID
	AND CITEM_ID = @CPROGRAM_ID
	AND CSOURCE_ID = @CSOURCE_ID
	IF @CVALID_CODE IS NOT NULL BEGIN
		-- transaction exists
		SELECT @CRET_MSG = 'TRANSACTION_EXISTS'
		RETURN
	END

	SELECT @CRET_MSG = 'OK'
	RETURN
END
GO
