/****** Object:  StoredProcedure [dbo].[RSP_Customer_Configuration]    Script Date: 9/22/2014 3:54:01 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSP_Customer_Configuration]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSP_Customer_Configuration]
GO

/****** Object:  StoredProcedure [dbo].[RSP_Customer_Configuration]    Script Date: 9/22/2014 3:54:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Anov Mailoa
-- Create date: 12 February 2016
-- Description:	RSP_Customer_Configuration
-- =============================================
CREATE PROCEDURE [dbo].[RSP_Customer_Configuration] 
	@CCOMPANY_ID VARCHAR(8),
	@CAPPS_CODE VARCHAR(20),
	@CCUSTOMER_CODE VARCHAR(8),
	@CNO_VALUE VARCHAR(20) = '<n/a>'
WITH RECOMPILE, ENCRYPTION
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT 
		A.CCOMPANY_ID,
		A.CAPPS_CODE,	
		@CCUSTOMER_CODE AS CCUSTOMER_CODE,
		A.CFIELD_NAME,
		C.DCONFIG_DATE,
		C.CCONFIG_BY,
		C.CNOTE,
		A.CSEQUENCE,
		dbo.RFN_Level_Field_Group(A.CCOMPANY_ID, A.CAPPS_CODE, A.CFIELD_NAME, 1, 1) AS CLEVEL_1,
		dbo.RFN_Level_Field_Group(A.CCOMPANY_ID, A.CAPPS_CODE, A.CFIELD_NAME, 2, 1) AS CLEVEL_2,
		dbo.RFN_Level_Field_Group(A.CCOMPANY_ID, A.CAPPS_CODE, A.CFIELD_NAME, 3, 1) AS CLEVEL_3,
		dbo.RFN_Level_Field_Group(A.CCOMPANY_ID, A.CAPPS_CODE, A.CFIELD_NAME, 4, 1) AS CLEVEL_4,
		dbo.RFN_Level_Field_Group(A.CCOMPANY_ID, A.CAPPS_CODE, A.CFIELD_NAME, 5, 1) AS CLEVEL_5,
		A.CPRINT_LABEL, 
		ISNULL(B.CFIELD_VALUE, @CNO_VALUE) AS CFIELD_VALUE
	FROM LAM_APPS_CONFIG_FIELD A (NOLOCK)
	LEFT OUTER JOIN LAM_CUSTOMER_CONFIG_DETAIL B (NOLOCK)
	ON B.CCOMPANY_ID = A.CCOMPANY_ID
	AND B.CAPPS_CODE = A.CAPPS_CODE
	AND B.CFIELD_NAME = A.CFIELD_NAME
	AND B.CCUSTOMER_CODE = @CCUSTOMER_CODE
	JOIN LAM_CUSTOMER_CONFIG C (NOLOCK)
	ON C.CCOMPANY_ID = A.CCOMPANY_ID
	AND C.CAPPS_CODE = A.CAPPS_CODE
	AND C.CCUSTOMER_CODE = @CCUSTOMER_CODE
	WHERE A.CCOMPANY_ID = @CCOMPANY_ID
	AND A.CAPPS_CODE = @CAPPS_CODE
	AND A.LFIELD_GROUP = 0
	ORDER BY A.CSEQUENCE

END
GO
