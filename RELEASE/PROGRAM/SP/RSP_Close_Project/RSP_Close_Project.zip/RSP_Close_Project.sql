/****** Object:  StoredProcedure [dbo].[RSP_Close_Project]    Script Date: 9/22/2014 3:54:01 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSP_Close_Project]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSP_Close_Project]
GO

/****** Object:  StoredProcedure [dbo].[RSP_Close_Project]    Script Date: 9/22/2014 3:54:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Anov Mailoa
-- Create date: 23 November 2016
-- Description:	RSP_Close_Project - To close project
-- =============================================
CREATE PROCEDURE [dbo].[RSP_Close_Project] 
	@CCOMPANY_ID VARCHAR(8),
	@CAPPS_CODE VARCHAR(20),
	@CVERSION VARCHAR(15),
	@CPROJECT_ID VARCHAR(20),
	@CUSER_ID VARCHAR(8),
	@CRET_MSG VARCHAR(50) OUTPUT
WITH RECOMPILE, ENCRYPTION
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @ICOUNT AS INTEGER

	-- validation
	-- check if this project has active session
	SELECT @ICOUNT = COUNT(CSESSION_ID)
	FROM CSM_PROJECT_SESSIONS
	WHERE CCOMPANY_ID = @CCOMPANY_ID
	AND CAPPS_CODE = @CAPPS_CODE
	AND CVERSION = @CVERSION
	AND CPROJECT_ID = @CPROJECT_ID
	AND CSTATUS <> 'CLOSED'
	IF @ICOUNT > 0 BEGIN
		SELECT @CRET_MSG = 'OPEN_SESSION_FOUND'
		RETURN
	END

	-- close project
	UPDATE CSM_PROJECTS
	SET CSTATUS = 'CLOSED'
	WHERE CCOMPANY_ID = @CCOMPANY_ID
	AND CAPPS_CODE = @CAPPS_CODE
	AND CVERSION = @CVERSION
	AND CPROJECT_ID = @CPROJECT_ID

	SELECT @CRET_MSG = 'OK'
	RETURN
END
GO
