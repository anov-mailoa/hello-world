﻿Imports R_Common
Imports AutoreactivationService.LAT00130ServiceRef

' NOTE: You can use the "Rename" command on the context menu to change the class name "LAT00130Service" in code, svc and config file together.
Public Class LAT00130Service
    Implements ILAT00130Service

    Public Function ReactivationComplete(poPar As ReactivationCompleteParamDTO) As ReactivationCompleteReturnDTO Implements ILAT00130Service.ReactivationComplete
        Dim loException As New R_Exception
        Dim loCls As New LAT00130ServiceClient
        Dim loRtn As ReactivationCompleteReturnDTO

        Try
            loRtn = loCls.ReactivationComplete(poPar)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function ReactivationRequest(poPar As ReactivationRequestParamDTO) As ReactivationRequestReturnDTO Implements ILAT00130Service.ReactivationRequest
        Dim loException As New R_Exception
        Dim loCls As New LAT00130ServiceClient
        Dim loRtn As ReactivationRequestReturnDTO

        Try
            loRtn = loCls.ReactivationRequest(poPar)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
