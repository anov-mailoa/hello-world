﻿Imports R_Common
Imports AutoreactivationService.LAT00110ServiceRef

' NOTE: You can use the "Rename" command on the context menu to change the class name "LAT00110Service" in code, svc and config file together.
Public Class LAT00110Service
    Implements ILAT00110Service

    Public Function ActivationCodeInstall(poPar As LAT00110ServiceRef.ActivationCodeInstallParamDTO) As LAT00110ServiceRef.ActivationCodeInstallReturnDTO Implements ILAT00110Service.ActivationCodeInstall
        Dim loException As New R_Exception
        Dim loCls As New LAT00110ServiceClient
        Dim loRtn As ActivationCodeInstallReturnDTO

        Try
            loRtn = loCls.ActivationCodeInstall(poPar)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function ActivationRequest(poPar As LAT00110ServiceRef.ActivationRequestParamDTO) As LAT00110ServiceRef.ActivationRequestReturnDTO Implements ILAT00110Service.ActivationRequest
        Dim loException As New R_Exception
        Dim loCls As New LAT00110ServiceClient
        Dim loRtn As ActivationRequestReturnDTO

        Try
            loRtn = loCls.ActivationRequest(poPar)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function ActivationStatus(poPar As LAT00110ServiceRef.ActivationStatusParamDTO) As LAT00110ServiceRef.ActivationStatusReturnDTO Implements ILAT00110Service.ActivationStatus
        Dim loException As New R_Exception
        Dim loCls As New LAT00110ServiceClient
        Dim loRtn As ActivationStatusReturnDTO

        Try
            loRtn = loCls.ActivationStatus(poPar)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn

    End Function
End Class
