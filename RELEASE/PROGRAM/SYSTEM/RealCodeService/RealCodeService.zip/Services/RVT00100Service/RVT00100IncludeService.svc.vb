﻿Imports R_Common
Imports RVT00100Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "RVT00100IncludeService" in code, svc and config file together.
Public Class RVT00100IncludeService
    Implements IRVT00100IncludeService

    Public Sub Svc_R_Delete(poEntity As RVT00100Back.RVT00100IncludeDTO) Implements R_BackEnd.R_IServicebase(Of RVT00100Back.RVT00100IncludeDTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New RVT00100IncludesCls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As RVT00100Back.RVT00100IncludeDTO) As RVT00100Back.RVT00100IncludeDTO Implements R_BackEnd.R_IServicebase(Of RVT00100Back.RVT00100IncludeDTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New RVT00100IncludesCls
        Dim loRtn As RVT00100IncludeDTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As RVT00100Back.RVT00100IncludeDTO, poCRUDMode As R_Common.eCRUDMode) As RVT00100Back.RVT00100IncludeDTO Implements R_BackEnd.R_IServicebase(Of RVT00100Back.RVT00100IncludeDTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New RVT00100IncludesCls
        Dim loRtn As RVT00100IncludeDTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetProviderCombo(pcCompanyID As String) As System.Collections.Generic.List(Of RVT00100Back.RVT00100ProviderComboDTO) Implements IRVT00100IncludeService.GetProviderCombo
        Dim loException As New R_Exception
        Dim loCls As New RVT00100IncludesCls
        Dim loRtn As List(Of RVT00100ProviderComboDTO)

        Try
            loRtn = loCls.GetProviderCombo(pcCompanyID)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetAppVersionCombo(poTableKey As RVT00100Back.RVT00100GridDTO) As System.Collections.Generic.List(Of RVT00100Back.RVT00100AppVersionComboDTO) Implements IRVT00100IncludeService.GetAppVersionCombo
        Dim loException As New R_Exception
        Dim loCls As New RVT00100IncludesCls
        Dim loRtn As List(Of RVT00100AppVersionComboDTO)

        Try
            loRtn = loCls.GetAppVersionCombo(poTableKey)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
