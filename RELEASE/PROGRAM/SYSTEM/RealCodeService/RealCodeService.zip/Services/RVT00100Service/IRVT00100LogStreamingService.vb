﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports RVT00100Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IRVT00100LogStreamingService" in both code and config file together.
<ServiceContract()>
Public Interface IRVT00100LogStreamingService

    <OperationContract(Action:="getVersionLog", ReplyAction:="getVersionLog")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetVersionLog() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of RVT00100LogGridDTO))

End Interface
