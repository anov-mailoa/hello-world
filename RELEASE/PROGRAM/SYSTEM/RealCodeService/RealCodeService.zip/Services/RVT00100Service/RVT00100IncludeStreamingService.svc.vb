﻿Imports R_Common
Imports RVT00100Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "RVT00100IncludeStreamingService" in code, svc and config file together.
Public Class RVT00100IncludeStreamingService
    Implements IRVT00100IncludeStreamingService

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of RVT00100Back.RVT00100IncludeGridDTO)) Implements IRVT00100IncludeStreamingService.Dummy

    End Sub

    Public Function GetIncludes() As System.ServiceModel.Channels.Message Implements IRVT00100IncludeStreamingService.GetIncludes
        Dim loException As New R_Exception
        Dim loCls As New RVT00100IncludesCls
        Dim loRtnTemp As List(Of RVT00100IncludeGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New RVT00100IncludeGridDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
            End With

            loRtnTemp = loCls.GetIncludes(loTableKey)

            loRtn = R_StreamUtility(Of RVT00100IncludeGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getIncludes")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
