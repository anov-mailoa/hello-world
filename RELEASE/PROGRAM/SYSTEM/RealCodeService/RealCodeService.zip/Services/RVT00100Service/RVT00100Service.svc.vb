﻿Imports R_Common
Imports RVT00100Back
Imports RLicenseBack
Imports RLicenseService

' NOTE: You can use the "Rename" command on the context menu to change the class name "RVT00100Service" in code, svc and config file together.
Public Class RVT00100Service
    Implements IRVT00100Service

    Public Sub Svc_R_Delete(poEntity As RVT00100Back.RVT00100DTO) Implements R_BackEnd.R_IServicebase(Of RVT00100Back.RVT00100DTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New RVT00100Cls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As RVT00100Back.RVT00100DTO) As RVT00100Back.RVT00100DTO Implements R_BackEnd.R_IServicebase(Of RVT00100Back.RVT00100DTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New RVT00100Cls
        Dim loRtn As RVT00100DTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As RVT00100Back.RVT00100DTO, poCRUDMode As R_Common.eCRUDMode) As RVT00100Back.RVT00100DTO Implements R_BackEnd.R_IServicebase(Of RVT00100Back.RVT00100DTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New RVT00100Cls
        Dim loRtn As RVT00100DTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn

    End Function

    Public Function ReleaseVersion(poProcessParam As RVT00100Back.RVT00100ReleaseDTO) As System.Collections.Generic.List(Of RVT00100SerialFilesDTO) Implements IRVT00100Service.ReleaseVersion
        Dim loEx As New R_Exception
        Dim loCls As New RVT00100Cls
        Dim loRtn As New List(Of RVT00100SerialFilesDTO)

        Try
            loRtn = loCls.ReleaseVersion(poProcessParam)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
        Return loRtn
    End Function

    Public Function GetAppCombo(companyId As String, userId As String, endProduct As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseAppComboDTO) Implements IRVT00100Service.GetAppCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseAppComboDTO)

        Try
            loRtn = loCls.GetAppCombo(companyId, userId, endProduct)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function CreateVersion(poKey As RVT00100Back.RVT00100CrVerDTO) As String Implements IRVT00100Service.CreateVersion
        Dim loEx As New R_Exception
        Dim loCls As New RVT00100Cls
        Dim lcRtn As String

        Try
            lcRtn = loCls.CreateVersion(poKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
        Return lcRtn
    End Function

    Public Function DumpFiles(poProcessParam As RVT00100Back.RVT00100ReleaseDTO) As System.Collections.Generic.List(Of RVT00100SerialFilesDTO) Implements IRVT00100Service.DumpFiles
        Dim loEx As New R_Exception
        Dim loCls As New RVT00100Cls
        Dim loRtn As New List(Of RVT00100SerialFilesDTO)

        Try
            loRtn = loCls.DumpFiles(poProcessParam)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
        Return loRtn
    End Function

    Public Function ChangeVersionStatus(poProcessParam As RVT00100DTO) As String Implements IRVT00100Service.ChangeVersionStatus
        Dim loEx As New R_Exception
        Dim loCls As New RVT00100Cls
        Dim lcRtn As String

        Try
            lcRtn = loCls.ChangeVersionStatus(poProcessParam)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
        Return lcRtn
    End Function
End Class
