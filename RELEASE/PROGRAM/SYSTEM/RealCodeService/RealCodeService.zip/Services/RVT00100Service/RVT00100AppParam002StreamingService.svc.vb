﻿Imports R_Common
Imports RVT00100Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "RVT00100AppParam002StreamingService" in code, svc and config file together.
Public Class RVT00100AppParam002StreamingService
    Implements IRVT00100AppParam002StreamingService

    Public Function GetParameters() As System.ServiceModel.Channels.Message Implements IRVT00100AppParam002StreamingService.GetParameters
        Dim loException As New R_Exception
        Dim loCls As New RVT00100AppParam002Cls
        Dim loRtnTemp As List(Of RVT00100AppParam002GridDTO)
        Dim loRtn As Message
        Dim loTableKey As New RVT00100AppParam002KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CPARAMETER_GROUP = R_Utility.R_GetStreamingContext("cParameterGroup")
            End With

            loRtnTemp = loCls.GetParameters(loTableKey)

            loRtn = R_StreamUtility(Of RVT00100AppParam002GridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getParameters")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetItemList() As System.ServiceModel.Channels.Message Implements IRVT00100AppParam002StreamingService.GetItemList
        Dim loException As New R_Exception
        Dim loCls As New RVT00100AppParam002Cls
        Dim loRtnTemp As List(Of RVT00100ItemListDTO)
        Dim loRtn As Message
        Dim loTableKey As New RVT00100ItemKeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CATTRIBUTE_ID = R_Utility.R_GetStreamingContext("cAttributeId")
            End With

            loRtnTemp = loCls.GetItemList(loTableKey)

            loRtn = R_StreamUtility(Of RVT00100ItemListDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getItemList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetSourceGroupList() As System.ServiceModel.Channels.Message Implements IRVT00100AppParam002StreamingService.GetSourceGroupList
        Dim loException As New R_Exception
        Dim loCls As New RVT00100AppParam002Cls
        Dim loRtnTemp As List(Of RVT00100SourceGroupListDTO)
        Dim loRtn As Message
        Dim loTableKey As New RVT00100ItemKeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CATTRIBUTE_ID = R_Utility.R_GetStreamingContext("cAttributeId")
            End With

            loRtnTemp = loCls.GetSourceGroupList(loTableKey)

            loRtn = R_StreamUtility(Of RVT00100SourceGroupListDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getSourceGroupList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of RVT00100Back.RVT00100AppParam002GridDTO), poPar2 As RVT00100Back.RVT00100AppParam002KeyDTO, poPar3 As RVT00100Back.RVT00100ItemKeyDTO, poPar4 As System.Collections.Generic.List(Of RVT00100Back.RVT00100ItemListDTO), poPar5 As System.Collections.Generic.List(Of RVT00100Back.RVT00100SourceGroupListDTO), poPar6 As System.Collections.Generic.List(Of RVT00100Back.RVT00100SourceListDTO)) Implements IRVT00100AppParam002StreamingService.Dummy

    End Sub

    Public Function GetSourceList() As System.ServiceModel.Channels.Message Implements IRVT00100AppParam002StreamingService.GetSourceList
        Dim loException As New R_Exception
        Dim loCls As New RVT00100AppParam002Cls
        Dim loRtnTemp As List(Of RVT00100SourceListDTO)
        Dim loRtn As Message
        Dim loTableKey As New RVT00100ItemKeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CATTRIBUTE_ID = R_Utility.R_GetStreamingContext("cAttributeId")
            End With

            loRtnTemp = loCls.GetSourceList(loTableKey)

            loRtn = R_StreamUtility(Of RVT00100SourceListDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getSourceList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
