﻿Imports R_Common
Imports RVT00100Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "RVT00100StreamingService" in code, svc and config file together.
Public Class RVT00100StreamingService
    Implements IRVT00100StreamingService

    Public Function GetVersions() As System.ServiceModel.Channels.Message Implements IRVT00100StreamingService.GetVersions
        Dim loException As New R_Exception
        Dim loCls As New RVT00100Cls
        Dim loRtnTemp As List(Of RVT00100GridDTO)
        Dim loRtn As Message
        Dim loTableKey As New RVT00100GridDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
            End With

            loRtnTemp = loCls.GetVersions(loTableKey)

            loRtn = R_StreamUtility(Of RVT00100GridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getVersions")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of RVT00100Back.RVT00100GridDTO), poPar2 As System.Collections.Generic.List(Of RVT00100Back.RVT00100RevisionGridDTO)) Implements IRVT00100StreamingService.Dummy

    End Sub

    Public Function GetRevisions() As System.ServiceModel.Channels.Message Implements IRVT00100StreamingService.GetRevisions
        Dim loException As New R_Exception
        Dim loCls As New RVT00100RevisionCls
        Dim loRtnTemp As List(Of RVT00100RevisionGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New RVT00100RevisionGridDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
            End With

            loRtnTemp = loCls.GetRevisions(loTableKey)

            loRtn = R_StreamUtility(Of RVT00100RevisionGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getRevisions")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
