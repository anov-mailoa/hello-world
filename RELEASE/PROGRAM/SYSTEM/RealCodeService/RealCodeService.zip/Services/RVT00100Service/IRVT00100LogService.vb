﻿Imports System.ServiceModel
Imports R_BackEnd
Imports RVT00100Back
Imports R_Common

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IRVT00100LogService" in both code and config file together.
<ServiceContract()>
Public Interface IRVT00100LogService
    Inherits R_IServicebase(Of RVT00100LogDTO)

    <OperationContract(Action:="getAppUnitCombo", ReplyAction:="getAppUnitCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAppUnitCombo(key As RVT00100AppKeyDTO) As List(Of RVT00100AppUnitComboDTO)

    <OperationContract(Action:="getLogTypeCombo", ReplyAction:="getLogTypeCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetLogTypeCombo() As List(Of RVT00100LogTypeComboDTO)

End Interface
