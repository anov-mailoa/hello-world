﻿Imports R_Common
Imports LAT00200Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "LAT00200StreamingService" in code, svc and config file together.
Public Class LAT00200StreamingService
    Implements ILAT00200StreamingService

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of LAT00200Back.LAT00200ServerGridDTO)) Implements ILAT00200StreamingService.Dummy

    End Sub

    Public Function GetServerData() As System.ServiceModel.Channels.Message Implements ILAT00200StreamingService.GetServerData
        Dim loException As New R_Exception
        Dim loCls As New LAT00200Cls
        Dim loRtnTemp As List(Of LAT00200ServerGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New LAT00200KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CCUSTOMER_CODE = R_Utility.R_GetStreamingContext("cCustomerCode")
                .CSERVER_TYPE = R_Utility.R_GetStreamingContext("cServerType")
            End With

            loRtnTemp = loCls.GetServerData(loTableKey)

            loRtn = R_StreamUtility(Of LAT00200ServerGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getServerData")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
