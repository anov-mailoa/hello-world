﻿Imports R_Common
Imports RLicenseBack
Imports LAT00200Back
Imports RVM00100Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "LAT00200Service" in code, svc and config file together.
Public Class LAT00200Service
    Implements ILAT00200Service

    Public Function GetAppCombo(companyId As String, userId As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseAppComboDTO) Implements ILAT00200Service.GetAppCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseAppComboDTO)

        Try
            loRtn = loCls.GetAppCombo(companyId, userId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn

    End Function

    Public Function GetCustCombo(companyId As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseCustComboDTO) Implements ILAT00200Service.GetCustCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseCustComboDTO)

        Try
            loRtn = loCls.GetCustCombo(companyId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub RegisterServer(poNewEntity As LAT00200Back.LAT00200ServerDTO) Implements ILAT00200Service.RegisterServer
        Dim loEx As New R_Exception
        Dim loCls As New LAT00200Cls

        Try
            loCls.RegisterServer(poNewEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Dummy1() As System.Collections.Generic.List(Of LAT00200Back.LAT00200KeyDTO) Implements ILAT00200Service.Dummy1

    End Function

    Public Function GetApplicationCombo(companyId As String, userId As String) As System.Collections.Generic.List(Of RVM00100Back.RVM00100AppComboDTO) Implements ILAT00200Service.GetApplicationCombo
        Dim loException As New R_Exception
        Dim loCls As New RVM00100CustomerCls
        Dim loRtn As List(Of RVM00100AppComboDTO)

        Try
            loRtn = loCls.GetApplicationCombo(companyId, userId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
