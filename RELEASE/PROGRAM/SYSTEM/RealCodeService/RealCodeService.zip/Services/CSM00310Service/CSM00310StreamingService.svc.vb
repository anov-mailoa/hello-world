﻿Imports R_Common
Imports CSM00310BACK
Imports System.ServiceModel.Channels
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00310StreamingService" in code, svc and config file together.
Public Class CSM00310StreamingService
    Implements ICSM00310StreamingService

    Public Function GetProgramCustList() As System.ServiceModel.Channels.Message Implements ICSM00310StreamingService.GetProgramCustList
        Dim loException As New R_Exception
        Dim loCls As New CSM00310Cls
        Dim loRtnTemp As List(Of CSM00310GridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00310KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CCUSTOMER_CODE = R_Utility.R_GetStreamingContext("cCustomerCode")
            End With

            loRtnTemp = loCls.GetProgramCustList(loTableKey)

            loRtn = R_StreamUtility(Of CSM00310GridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getProgramCustList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetStandardProgramList() As System.ServiceModel.Channels.Message Implements ICSM00310StreamingService.GetStandardProgramList
        Dim loException As New R_Exception
        Dim loCls As New CSM00310Cls
        Dim loRtnTemp As List(Of CSM00310ItemListDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00310KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CATTRIBUTE_ID = R_Utility.R_GetStreamingContext("cAttributeId")
                .CCUSTOMER_CODE = R_Utility.R_GetStreamingContext("cCustomerCode")
            End With

            loRtnTemp = loCls.GetStandardProgramList(loTableKey)

            loRtn = R_StreamUtility(Of CSM00310ItemListDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getStandardProgramList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetCustomerList() As System.ServiceModel.Channels.Message Implements ICSM00310StreamingService.GetCustomerList
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtnTemp As List(Of RCustDBCustListDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00310KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
            End With

            loRtnTemp = loCls.GetCustList(loTableKey.CCOMPANY_ID)

            loRtn = R_StreamUtility(Of RCustDBCustListDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getCustomerList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of CSM00310BACK.CSM00310GridDTO), poPar2 As System.Collections.Generic.List(Of RLicenseBack.RCustDBCustListDTO), poPar3 As System.Collections.Generic.List(Of CSM00310BACK.CSM00310ItemListDTO)) Implements ICSM00310StreamingService.Dummy

    End Sub
End Class
