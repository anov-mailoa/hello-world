﻿Imports System.ServiceModel
Imports R_Common
Imports RLicenseBack
Imports LAR00100Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ILAR00100Service" in both code and config file together.
<ServiceContract()>
Public Interface ILAR00100Service

    <OperationContract(Action:="getAppCombo", ReplyAction:="getAppCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAppCombo(companyId As String, userId As String) As List(Of RLicenseAppComboDTO)

    <OperationContract(Action:="getCustByAppsCombo", ReplyAction:="getCustByAppsCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetCustByAppsCombo(companyId As String, appsCode As String) As List(Of RLicenseCustComboDTO)

    <OperationContract(Action:="getAppInfo", ReplyAction:="getAppInfo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAppInfo(tableKey As LAR00100AppsDTO) As LAR00100AppsDTO

    <OperationContract(Action:="getCustInfo", ReplyAction:="getCustInfo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetCustInfo(tableKey As LAR00100CustInfoDTO) As LAR00100CustInfoDTO

    <OperationContract(Action:="getContacts", ReplyAction:="getContacts")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetContacts(tableKey As LAR00100ContactDTO) As List(Of LAR00100ContactDTO)

    <OperationContract(Action:="getContracts", ReplyAction:="getContracts")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetContracts(tableKey As LAR00100ContractDTO) As List(Of LAR00100ContractDTO)

    <OperationContract(Action:="getCuCo", ReplyAction:="getCuCo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetCuco(tableKey As LAR00100CuCoDtlDTO) As List(Of LAR00100CuCoDtlDTO)

    <OperationContract(Action:="getCuCoHistory", ReplyAction:="getCuCoHistory")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetCuCoHistory(tableKey As LAR00100CuCoDtlDTO) As List(Of LAR00100CuCoDtlDTO)

    '<OperationContract()> _
    '<FaultContract(GetType(R_ServiceExceptions))> _
    'Function Dummy1() As List(Of LAR00100CuCoDtlDTO)

End Interface
