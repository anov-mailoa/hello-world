﻿Imports System.ServiceModel
Imports R_Common
Imports LAR00100Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ILAR00100StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ILAR00100StreamingService

    '<OperationContract(Action:="getCuCo", ReplyAction:="getCuCo")> _
    '<FaultContract(GetType(R_ServiceExceptions))> _
    'Function GetCuco(tableKey As LAR00100CuCoDtlDTO) As List(Of LAR00100CuCoDtlDTO)

    <OperationContract(Action:="getCuCoHistory", ReplyAction:="getCuCoHistory")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetCuCoHistory() As Message

    '<OperationContract()> _
    '<FaultContract(GetType(R_ServiceExceptions))> _
    'Sub Dummy(ByVal poPar1 As List(Of LAR00100CuCoDtlDTO))

End Interface
