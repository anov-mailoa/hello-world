﻿Imports R_Common
Imports CSM00400Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00400StreamingService" in code, svc and config file together.
Public Class CSM00400StreamingService
    Implements ICSM00400StreamingService

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of CSM00400Back.CSM00400GridDTO)) Implements ICSM00400StreamingService.Dummy

    End Sub

    Public Function GetSourceList() As System.ServiceModel.Channels.Message Implements ICSM00400StreamingService.GetSourceList
        Dim loException As New R_Exception
        Dim loCls As New CSM00400Cls
        Dim loRtnTemp As List(Of CSM00400GridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00400KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CATTRIBUTE_ID = R_Utility.R_GetStreamingContext("cAttributeId")
                .CPROGRAM_ID = R_Utility.R_GetStreamingContext("cProgramId")
            End With

            loRtnTemp = loCls.GetSourceList(loTableKey)

            loRtn = R_StreamUtility(Of CSM00400GridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getSourceList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
