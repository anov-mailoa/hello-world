﻿Imports R_Common
Imports CSM00600Back
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00600DetailService" in code, svc and config file together.
Public Class CSM00600DetailService
    Implements ICSM00600DetailService

    Public Sub Svc_R_Delete(poEntity As CSM00600Back.CSM00600DetailDTO) Implements R_BackEnd.R_IServicebase(Of CSM00600Back.CSM00600DetailDTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New CSM00600DetailCls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As CSM00600Back.CSM00600DetailDTO) As CSM00600Back.CSM00600DetailDTO Implements R_BackEnd.R_IServicebase(Of CSM00600Back.CSM00600DetailDTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New CSM00600DetailCls
        Dim loRtn As CSM00600DetailDTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As CSM00600Back.CSM00600DetailDTO, poCRUDMode As R_Common.eCRUDMode) As CSM00600Back.CSM00600DetailDTO Implements R_BackEnd.R_IServicebase(Of CSM00600Back.CSM00600DetailDTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New CSM00600DetailCls
        Dim loRtn As CSM00600DetailDTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    'Public Function GetIssueCombo(key As RLicenseBack.RCustDBIssueKeyDTO) As System.Collections.Generic.List(Of RLicenseBack.RCustDBIssueComboDTO) Implements ICSM00600DetailService.GetIssueCombo
    '    Dim loException As New R_Exception
    '    Dim loCls As New RLicenseCls
    '    Dim loRtn As List(Of RCustDBIssueComboDTO)

    '    Try
    '        loRtn = loCls.GetIssueCombo(key)
    '    Catch ex As Exception
    '        loException.Add(ex)
    '    End Try

    '    loException.ConvertAndThrowToServiceExceptionIfErrors()

    '    Return loRtn
    'End Function


End Class
