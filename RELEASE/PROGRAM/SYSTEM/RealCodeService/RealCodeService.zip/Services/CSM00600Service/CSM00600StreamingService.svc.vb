﻿Imports R_Common
Imports CSM00600Back
Imports System.ServiceModel.Channels
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00600StreamingService" in code, svc and config file together.
Public Class CSM00600StreamingService
    Implements ICSM00600StreamingService

    Public Function GetCRList() As System.ServiceModel.Channels.Message Implements ICSM00600StreamingService.GetCRList
        Dim loException As New R_Exception
        Dim loCls As New CSM00600Cls
        Dim loRtnTemp As List(Of CSM00600GridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00600KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CATTRIBUTE_ID = R_Utility.R_GetStreamingContext("cAttributeId")
                .CPROGRAM_ID = R_Utility.R_GetStreamingContext("cProgramId")
            End With

            loRtnTemp = loCls.GetCRList(loTableKey)

            loRtn = R_StreamUtility(Of CSM00600GridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getCRList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetIssueCombo() As System.ServiceModel.Channels.Message Implements ICSM00600StreamingService.GetIssueCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtnTemp As List(Of RCustDBIssueComboDTO)
        Dim loRtn As Message
        Dim loTableKey As New RCustDBIssueKeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .CPROJECT_ID = R_Utility.R_GetStreamingContext("cProjectId")
                .CSESSION_ID = R_Utility.R_GetStreamingContext("cSessionId")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CATTRIBUTE_ID = R_Utility.R_GetStreamingContext("cAttributeId")
                .CITEM_ID = R_Utility.R_GetStreamingContext("cItemId")
                .CISSUE_TYPE = R_Utility.R_GetStreamingContext("cIssueType")
                .LOUTSTANDING_ONLY = False
            End With

            loRtnTemp = loCls.GetIssueCombo(loTableKey)

            loRtn = R_StreamUtility(Of RCustDBIssueComboDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getIssueCombo")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetItemList() As System.ServiceModel.Channels.Message Implements ICSM00600StreamingService.GetItemList
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtnTemp As List(Of RCustDBItemComboDTO)
        Dim loRtn As Message
        Dim loTableKey As New RCustDBItemKeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CATTRIBUTE_ID = R_Utility.R_GetStreamingContext("cAttributeId")
            End With

            loRtnTemp = loCls.GetItemCombo(loTableKey)

            loRtn = R_StreamUtility(Of RCustDBItemComboDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getItemList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of CSM00600Back.CSM00600GridDTO), poPar2 As System.Collections.Generic.List(Of RLicenseBack.RCustDBIssueComboDTO), poPar3 As RLicenseBack.RCustDBIssueKeyDTO, poPar4 As System.Collections.Generic.List(Of RLicenseBack.RCustDBItemComboDTO)) Implements ICSM00600StreamingService.Dummy

    End Sub
End Class
