﻿Imports System.ServiceModel
Imports System.ServiceModel.Channels
Imports CSM00700Back
Imports R_Common

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00700StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00700StreamingService

    <OperationContract(Action:="getDatabaseList", ReplyAction:="getDatabaseList")>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function GetDatabaseList() As Message

    <OperationContract(Action:="getTableList", ReplyAction:="getTableList")>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function GetTableList() As Message

    <OperationContract(Action:="getColumnList", ReplyAction:="getColumnList")>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function GetColumnList() As Message

    <OperationContract()>
    <FaultContract(GetType(R_ServiceExceptions))>
    Sub Dummy(ByVal poPar1 As List(Of CSM00700DatabaseGridDTO),
              ByVal poPar2 As List(Of CSM00700DbTablesGridDTO),
              ByVal poPar3 As List(Of CSM00700DbColumnsGridDTO))

End Interface
