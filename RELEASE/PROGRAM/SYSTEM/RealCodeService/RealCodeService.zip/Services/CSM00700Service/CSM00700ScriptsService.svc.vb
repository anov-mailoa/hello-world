﻿' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00700ScriptsService" in code, svc and config file together.
' NOTE: In order to launch WCF Test Client for testing this service, please select CSM00700ScriptsService.svc or CSM00700ScriptsService.svc.vb at the Solution Explorer and start debugging.
Imports CSM00700Back
Imports R_BackEnd
Imports R_Common
Imports RLicenseService

Public Class CSM00700ScriptsService
    Implements ICSM00700ScriptsService

    Public Sub Svc_R_Delete(poEntity As CSM00700ScriptsDTO) Implements R_IServicebase(Of CSM00700ScriptsDTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New CSM00700ScriptsCls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As CSM00700ScriptsDTO) As CSM00700ScriptsDTO Implements R_IServicebase(Of CSM00700ScriptsDTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New CSM00700ScriptsCls
        Dim loRtn As CSM00700ScriptsDTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As CSM00700ScriptsDTO, poCRUDMode As eCRUDMode) As CSM00700ScriptsDTO Implements R_IServicebase(Of CSM00700ScriptsDTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New CSM00700ScriptsCls
        Dim loRtn As CSM00700ScriptsDTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function UploadScriptValidation(poKey As CSM00700KeyDTO) As String Implements ICSM00700ScriptsService.UploadScriptValidation
        Dim loEx As New R_Exception
        Dim loCls As New CSM00700ScriptsCls
        Dim lcRtn As String

        Try
            lcRtn = loCls.UploadScriptValidation(poKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
        Return lcRtn
    End Function

    Public Function ShiftScript(poKey As CSM00700KeyDTO) As String Implements ICSM00700ScriptsService.ShiftScript
        Dim loEx As New R_Exception
        Dim loCls As New CSM00700ScriptsCls
        Dim lcRtn As String

        Try
            lcRtn = loCls.ShiftScript(poKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
        Return lcRtn
    End Function
End Class
