﻿' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00700Service" in code, svc and config file together.
' NOTE: In order to launch WCF Test Client for testing this service, please select CSM00700Service.svc or CSM00700Service.svc.vb at the Solution Explorer and start debugging.
Imports CSM00700Back
Imports R_BackEnd
Imports R_Common
Imports RLicenseBack
Imports RLicenseService

Public Class CSM00700Service
    Implements ICSM00700Service

    Public Sub Svc_R_Delete(poEntity As CSM00700DatabaseDTO) Implements R_IServicebase(Of CSM00700DatabaseDTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New CSM00700DatabaseCls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function GetAppCombo(companyId As String, userId As String) As List(Of RLicenseAppComboDTO) Implements ICSM00700Service.GetAppCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseAppComboDTO)

        Try
            loRtn = loCls.GetAppCombo(companyId, userId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_GetRecord(poEntity As CSM00700DatabaseDTO) As CSM00700DatabaseDTO Implements R_IServicebase(Of CSM00700DatabaseDTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New CSM00700DatabaseCls
        Dim loRtn As CSM00700DatabaseDTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As CSM00700DatabaseDTO, poCRUDMode As eCRUDMode) As CSM00700DatabaseDTO Implements R_IServicebase(Of CSM00700DatabaseDTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New CSM00700DatabaseCls
        Dim loRtn As CSM00700DatabaseDTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function AddDatabase(poKey As CSM00700DatabaseDTO) As String Implements ICSM00700Service.AddDatabase
        Dim loEx As New R_Exception
        Dim loCls As New CSM00700DatabaseCls
        Dim lcRtn As String

        Try
            lcRtn = loCls.AddDatabase(poKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
        Return lcRtn
    End Function

    Public Function Dummy(poPar1 As CSM00700DbTablesDTO, poPar2 As CSM00700DbColumnsDTO) As List(Of CSM00700KeyDTO) Implements ICSM00700Service.Dummy
        Throw New NotImplementedException()
    End Function

End Class
