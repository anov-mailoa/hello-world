﻿' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00700ProgramsStreamingService" in code, svc and config file together.
' NOTE: In order to launch WCF Test Client for testing this service, please select CSM00700ProgramsStreamingService.svc or CSM00700ProgramsStreamingService.svc.vb at the Solution Explorer and start debugging.
Imports System.ServiceModel.Channels
Imports CSM00700Back
Imports R_Common
Imports RLicenseService

Public Class CSM00700ProgramsStreamingService
    Implements ICSM00700ProgramsStreamingService

    Public Sub Dummy(poPar1 As List(Of CSM00700DbProgramsGridDTO), poPar2 As List(Of CSM00700DbProgramSourcesGridDTO), poPar3 As List(Of CSM00700SourceGroupListDTO), poPar4 As CSM00700KeyDTO) Implements ICSM00700ProgramsStreamingService.Dummy
        Throw New NotImplementedException()
    End Sub

    Public Function GetDbProgramsList() As Message Implements ICSM00700ProgramsStreamingService.GetDbProgramsList
        Dim loException As New R_Exception
        Dim loCls As New CSM00700DbProgramsCls
        Dim loRtnTemp As List(Of CSM00700DbProgramsGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00700KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CDATABASE_ID = R_Utility.R_GetStreamingContext("cDatabaseId")
            End With

            loRtnTemp = loCls.GetDbProgramsList(loTableKey)

            loRtn = R_StreamUtility(Of CSM00700DbProgramsGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getDbProgramsList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetDbProgramSourceList() As Message Implements ICSM00700ProgramsStreamingService.GetDbProgramSourceList
        Dim loException As New R_Exception
        Dim loCls As New CSM00700DbProgramsCls
        Dim loRtnTemp As List(Of CSM00700DbProgramSourcesGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00700KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CATTRIBUTE_ID = R_Utility.R_GetStreamingContext("cAttributeId")
                .CSOURCE_GROUP_ID = R_Utility.R_GetStreamingContext("cSourceGroupId")
            End With

            loRtnTemp = loCls.GetDbProgramSourceList(loTableKey)

            loRtn = R_StreamUtility(Of CSM00700DbProgramSourcesGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getDbProgramSourceList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetSourceGroupList() As Message Implements ICSM00700ProgramsStreamingService.GetSourceGroupList
        Dim loException As New R_Exception
        Dim loCls As New CSM00700DbProgramsCls
        Dim loRtnTemp As List(Of CSM00700SourceGroupListDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00700KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CATTRIBUTE_ID = R_Utility.R_GetStreamingContext("cAttributeId")
            End With

            loRtnTemp = loCls.GetSourceGroupList(loTableKey)

            loRtn = R_StreamUtility(Of CSM00700SourceGroupListDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getSourceGroupList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
