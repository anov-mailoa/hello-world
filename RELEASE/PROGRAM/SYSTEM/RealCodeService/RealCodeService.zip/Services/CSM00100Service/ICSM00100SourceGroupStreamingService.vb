﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports CSM00100Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00100SourceGroupStreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00100SourceGroupStreamingService

    <OperationContract(Action:="getSourceGroupList", ReplyAction:="getSourceGroupList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetSourceGroupList() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of CSM00100SourceGroupGridDTO))

End Interface
