﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports CSM00100Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00100StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00100StreamingService

    <OperationContract(Action:="getAttributeGroupList", ReplyAction:="getAttributeGroupList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAttributeGroupList() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of CSM00100AttrGrpGridDTO))

End Interface
