﻿Imports R_Common
Imports System.ServiceModel.Channels
Imports CSM00100Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00100StreamingService" in code, svc and config file together.
Public Class CSM00100StreamingService
    Implements ICSM00100StreamingService

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of CSM00100Back.CSM00100AttrGrpGridDTO)) Implements ICSM00100StreamingService.Dummy

    End Sub

    Public Function GetAttributeGroupList() As System.ServiceModel.Channels.Message Implements ICSM00100StreamingService.GetAttributeGroupList
        Dim loException As New R_Exception
        Dim loCls As New CSM00100Cls
        Dim loRtnTemp As List(Of CSM00100AttrGrpGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00100AttrGrpKeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
            End With

            loRtnTemp = loCls.GetAttributeGroupList(loTableKey)

            loRtn = R_StreamUtility(Of CSM00100AttrGrpGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getAttributeGroupList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

End Class
