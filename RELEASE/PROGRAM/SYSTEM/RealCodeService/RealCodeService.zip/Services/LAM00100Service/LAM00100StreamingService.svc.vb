﻿Imports R_Common
Imports LAM00100Back
Imports System.ServiceModel.Channels
Imports LAT00100Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "LAM00100StreamingService" in code, svc and config file together.
Public Class LAM00100StreamingService
    Implements ILAM00100StreamingService

    Public Function GetAppList() As System.ServiceModel.Channels.Message Implements ILAM00100StreamingService.GetAppList
        Dim loException As New R_Exception
        Dim loCls As New LAM00100Cls
        Dim loRtnTemp As List(Of LAM00100GridDTO)
        Dim loRtn As Message
        Dim lcCompId As String

        Try
            lcCompId = R_Utility.R_GetStreamingContext("cCompId")

            loRtnTemp = loCls.getAppList(lcCompId)

            loRtn = R_StreamUtility(Of LAM00100GridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getAppList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub Dummy(poPar As System.Collections.Generic.List(Of LAM00100Back.LAM00100GridDTO)) Implements ILAM00100StreamingService.Dummy

    End Sub

End Class
