﻿Imports System.ServiceModel
Imports R_Common
Imports RLicenseBack
Imports CST00200Back
Imports CST00210Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICST00210Service" in both code and config file together.
<ServiceContract()>
Public Interface ICST00210Service

    <OperationContract(Action:="getAppCombo", ReplyAction:="getAppCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAppCombo(companyId As String, userId As String) As List(Of RLicenseAppComboDTO)

    <OperationContract(Action:="getVersionCombo", ReplyAction:="getVersionCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetVersionCombo(companyId As String, appsCode As String) As List(Of RCustDBVersionComboDTO)

    <OperationContract(Action:="getProjectCombo", ReplyAction:="getProjectCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetProjectCombo(key As RCustDBProjectKeyDTO) As List(Of RCustDBProjectComboDTO)

    <OperationContract(Action:="getSessionCombo", ReplyAction:="getSessionCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetSessionCombo(key As RCustDBProjectKeyDTO) As List(Of RCustDBSessionComboDTO)

    <OperationContract(Action:="getIssueTypeCombo", ReplyAction:="getIssueTypeCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetIssueTypeCombo() As List(Of CST00200IssueTypeComboDTO)

    <OperationContract(Action:="scheduleIssue", ReplyAction:="scheduleIssue")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub ScheduleIssue(poKey As CST00210KeyDTO, poIssueList As List(Of CST00210IssueDTO))

End Interface
