﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports CSM00500Back
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00510AssignmentStreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00510AssignmentStreamingService

    <OperationContract(Action:="getItemScheduleList", ReplyAction:="getItemScheduleList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetItemScheduleList() As Message

    <OperationContract(Action:="getIssueList", ReplyAction:="getIssueList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetIssueList() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of CSM00500ItemScheduleGridDTO), _
              ByVal poPar3 As RCustDBIssueListDTO, _
              ByVal poPar4 As RCustDBIssueKeyDTO)

End Interface
