﻿Imports R_Common
Imports RLicenseBack
Imports CSM00500Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00510AssignmentService" in code, svc and config file together.
Public Class CSM00510AssignmentService
    Implements ICSM00510AssignmentService

    Public Function Dummy1() As System.Collections.Generic.List(Of CSM00500Back.CSM00500ItemKeyDTO) Implements ICSM00510AssignmentService.Dummy1

    End Function

    Public Function GetFunctionCombo(poKey As RLicenseBack.RCustDBProjectKeyDTO) As System.Collections.Generic.List(Of RLicenseBack.RCustDBFunctionComboDTO) Implements ICSM00510AssignmentService.GetFunctionCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBFunctionComboDTO)

        Try
            loRtn = loCls.GetFunctionCombo(poKey)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn

    End Function

    Public Sub Svc_R_Delete(poEntity As CSM00500Back.CSM00500ItemDTO) Implements R_BackEnd.R_IServicebase(Of CSM00500Back.CSM00500ItemDTO).Svc_R_Delete
        ' Do nothing
    End Sub

    Public Function Svc_R_GetRecord(poEntity As CSM00500Back.CSM00500ItemDTO) As CSM00500Back.CSM00500ItemDTO Implements R_BackEnd.R_IServicebase(Of CSM00500Back.CSM00500ItemDTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New CSM00500AssignmentCls
        Dim loRtn As CSM00500ItemDTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn

    End Function

    Public Function Svc_R_Save(poEntity As CSM00500Back.CSM00500ItemDTO, poCRUDMode As R_Common.eCRUDMode) As CSM00500Back.CSM00500ItemDTO Implements R_BackEnd.R_IServicebase(Of CSM00500Back.CSM00500ItemDTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New CSM00500AssignmentCls
        Dim loRtn As CSM00500ItemDTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn

    End Function

    Public Function GetLocationCombo() As System.Collections.Generic.List(Of RLicenseBack.RCustDBLocationComboDTO) Implements ICSM00510AssignmentService.GetLocationCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBLocationComboDTO)

        Try
            loRtn = loCls.GetLocationCombo()
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub EstimateSchedule(poKey As CSM00500Back.CSM00500ItemKeyDTO) Implements ICSM00510AssignmentService.EstimateSchedule
        Dim loEx As New R_Exception
        Dim loCls As New CSM00500AssignmentCls

        Try
            loCls.EstimateSchedule(poKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub
End Class
