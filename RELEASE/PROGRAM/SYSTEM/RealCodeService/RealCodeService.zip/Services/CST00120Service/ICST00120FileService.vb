﻿Imports System.ServiceModel
Imports CST00120BACK
Imports R_Common
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IFileService" in both code and config file together.
<ServiceContract()>
Public Interface ICST00120FileService

    <OperationContract(Action:="getSlicedFile", ReplyAction:="getSlicedFile")>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function GetSlicedFile(key As RCustDBFileSplitKeyDTO) As RCustDBFileDTO

    <OperationContract(Action:="sliceFile", ReplyAction:="sliceFile")>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function SliceFile(key As RCustDBFileKeyDTO) As List(Of RCustDBFileSplitDTO)

    <OperationContract(Action:="getFileInfo", ReplyAction:="getFileInfo")>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function GetFileInfo(key As RCustDBFileKeyDTO) As List(Of CST00120FileInfoDTO)

End Interface
