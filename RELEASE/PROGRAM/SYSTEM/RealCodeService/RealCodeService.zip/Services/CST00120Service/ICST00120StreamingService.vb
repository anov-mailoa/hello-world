﻿Imports System.ServiceModel.Channels
Imports R_Common
Imports CST00120BACK

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICST00120StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ICST00120StreamingService

    <OperationContract(Action:="getProgramList", ReplyAction:="getProgramList")>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function GetProgramList() As Message

    <OperationContract()>
    <FaultContract(GetType(R_ServiceExceptions))>
    Sub Dummy(ByVal poPar1 As List(Of CST00120ProgramListDTO),
              ByVal poPar2 As CST00120KeyDTO)

End Interface
