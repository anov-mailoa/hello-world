﻿' NOTE: You can use the "Rename" command on the context menu to change the class name "CST00120StreamingService" in code, svc and config file together.
' NOTE: In order to launch WCF Test Client for testing this service, please select CST00120StreamingService.svc or CST00120StreamingService.svc.vb at the Solution Explorer and start debugging.
Imports System.ServiceModel.Channels
Imports CST00120BACK
Imports R_Common

Public Class CST00120StreamingService
    Implements ICST00120StreamingService

    Public Sub Dummy(poPar1 As List(Of CST00120ProgramListDTO),
                     poPar2 As CST00120KeyDTO) Implements ICST00120StreamingService.Dummy
        Throw New NotImplementedException()
    End Sub

    Public Function GetProgramList() As Message Implements ICST00120StreamingService.GetProgramList
        Dim loException As New R_Exception
        Dim loCls As New CST00120Cls
        Dim loRtnTemp As List(Of CST00120ProgramListDTO)
        Dim loRtn As Message
        Dim loTableKey As New CST00120KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
            End With

            loRtnTemp = loCls.GetProgramList(loTableKey)

            loRtn = R_StreamUtility(Of CST00120ProgramListDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getProgramList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
