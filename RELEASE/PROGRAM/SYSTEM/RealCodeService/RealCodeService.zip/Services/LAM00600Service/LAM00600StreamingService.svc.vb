﻿Imports R_Common
Imports LAM00600Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "LAM00600StreamingService" in code, svc and config file together.
Public Class LAM00600StreamingService
    Implements ILAM00600StreamingService

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of LAM00600Back.LAM00600GridDTO)) Implements ILAM00600StreamingService.Dummy

    End Sub

    Public Function GetAppsConfigField() As System.ServiceModel.Channels.Message Implements ILAM00600StreamingService.GetAppsConfigField
        Dim loException As New R_Exception
        Dim loCls As New LAM00600Cls
        Dim loRtnTemp As List(Of LAM00600GridDTO)
        Dim loRtn As Message
        Dim loTableKey As New LAM00600KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
            End With

            loRtnTemp = loCls.GetAppsConfigField(loTableKey)

            loRtn = R_StreamUtility(Of LAM00600GridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getAppsConfigField")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetAppsFieldCombo() As System.ServiceModel.Channels.Message Implements ILAM00600StreamingService.GetAppsFieldCombo
        Dim loException As New R_Exception
        Dim loCls As New LAM00600Cls
        Dim loRtnTemp As List(Of LAM00600GridDTO)
        Dim loRtn As Message
        Dim loTableKey As New LAM00600KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .LFIELD_GROUP = R_Utility.R_GetStreamingContext("lFieldGroup")
            End With

            loRtnTemp = loCls.GetAppsFieldCombo(loTableKey)

            loRtn = R_StreamUtility(Of LAM00600GridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getAppsFieldCombo")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn

    End Function

    Public Function getAvailableFieldName() As System.ServiceModel.Channels.Message Implements ILAM00600StreamingService.getAvailableFieldName
        Dim loException As New R_Exception
        Dim loCls As New LAM00600Cls
        Dim loRtnTemp As List(Of FieldNameDTO)
        Dim loRtn As Message
        Dim loTableKey As New LAM00600KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CFIELD_GROUP = R_Utility.R_GetStreamingContext("cFieldGroup")
            End With

            loRtnTemp = loCls.GetAvailableFieldName(loTableKey)

            loRtn = R_StreamUtility(Of FieldNameDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getAvailableFieldName")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function getSelectedFieldName() As System.ServiceModel.Channels.Message Implements ILAM00600StreamingService.getSelectedFieldName
        Dim loException As New R_Exception
        Dim loCls As New LAM00600Cls
        Dim loRtnTemp As List(Of FieldNameDTO)
        Dim loRtn As Message
        Dim loTableKey As New LAM00600KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CFIELD_GROUP = R_Utility.R_GetStreamingContext("cFieldGroup")
            End With

            loRtnTemp = loCls.GetSelectedFieldName(loTableKey)

            loRtn = R_StreamUtility(Of FieldNameDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getSelectedFieldName")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
