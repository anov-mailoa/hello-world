﻿Imports System.ServiceModel
Imports R_Common
Imports LAM00300Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ILAM00300StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ILAM00300StreamingService

    <OperationContract(Action:="getCustAppSqlList", ReplyAction:="getCustAppSqlList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetCustAppSqlList() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar As List(Of LAM00300GridDTO))

End Interface
