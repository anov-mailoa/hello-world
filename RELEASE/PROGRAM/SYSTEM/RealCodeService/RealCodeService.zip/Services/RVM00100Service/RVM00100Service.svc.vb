﻿Imports R_Common
Imports RVM00100Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "RVM00100Service" in code, svc and config file together.
Public Class RVM00100Service
    Implements IRVM00100Service

    Public Sub Svc_R_Delete(poEntity As RVM00100Back.RVM00100DTO) Implements R_BackEnd.R_IServicebase(Of RVM00100Back.RVM00100DTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New RVM00100Cls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As RVM00100Back.RVM00100DTO) As RVM00100Back.RVM00100DTO Implements R_BackEnd.R_IServicebase(Of RVM00100Back.RVM00100DTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New RVM00100Cls
        Dim loRtn As RVM00100DTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As RVM00100Back.RVM00100DTO, poCRUDMode As R_Common.eCRUDMode) As RVM00100Back.RVM00100DTO Implements R_BackEnd.R_IServicebase(Of RVM00100Back.RVM00100DTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New RVM00100Cls
        Dim loRtn As RVM00100DTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetActivationTypeCombo() As System.Collections.Generic.List(Of RVM00100Back.RVM00100ActivationTypeComboDTO) Implements IRVM00100Service.GetActivationTypeCombo
        Dim loException As New R_Exception
        Dim loCls As New RVM00100Cls
        Dim loRtn As List(Of RVM00100ActivationTypeComboDTO)

        Try
            loRtn = loCls.GetActivationTypeCombo()
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetApplicationTypeCombo() As System.Collections.Generic.List(Of RVM00100Back.RVM00100ApplicationTypeComboDTO) Implements IRVM00100Service.GetApplicationTypeCombo
        Dim loException As New R_Exception
        Dim loCls As New RVM00100Cls
        Dim loRtn As List(Of RVM00100ApplicationTypeComboDTO)

        Try
            loRtn = loCls.GetApplicationTypeCombo()
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
