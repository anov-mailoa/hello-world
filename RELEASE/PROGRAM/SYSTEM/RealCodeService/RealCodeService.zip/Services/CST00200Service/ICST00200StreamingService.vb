﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports CST00200Back
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICST00200StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ICST00200StreamingService

    <OperationContract(Action:="getItemInbox", ReplyAction:="getItemInbox")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetItemInbox() As Message

    <OperationContract(Action:="getIssueList", ReplyAction:="getIssueList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetIssueList() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of RCustDBItemInboxDTO), ByVal poPar2 As CST00200GridDTO, ByVal poPar3 As RCustDBInboxKeyDTO)

End Interface
