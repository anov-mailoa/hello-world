﻿Imports System.ServiceModel
Imports R_BackEnd
Imports CST00200Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICST00200AttachService" in both code and config file together.
<ServiceContract()>
Public Interface ICST00200AttachService
    Inherits R_IServicebase(Of CST00200AttachDTO)

End Interface
