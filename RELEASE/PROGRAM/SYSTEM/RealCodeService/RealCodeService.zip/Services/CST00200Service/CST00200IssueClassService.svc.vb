﻿Imports R_Common
Imports CST00200Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "CST00200IssueTypeService" in code, svc and config file together.
Public Class CST00200IssueClassService
    Implements ICST00200IssueClassService

    Public Sub Svc_R_Delete(poEntity As CST00200Back.CST00200IssueClassDTO) Implements R_BackEnd.R_IServicebase(Of CST00200Back.CST00200IssueClassDTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New CST00200IssueClassCls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As CST00200Back.CST00200IssueClassDTO) As CST00200Back.CST00200IssueClassDTO Implements R_BackEnd.R_IServicebase(Of CST00200Back.CST00200IssueClassDTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New CST00200IssueClassCls
        Dim loRtn As CST00200IssueClassDTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As CST00200Back.CST00200IssueClassDTO, poCRUDMode As R_Common.eCRUDMode) As CST00200Back.CST00200IssueClassDTO Implements R_BackEnd.R_IServicebase(Of CST00200Back.CST00200IssueClassDTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New CST00200IssueClassCls
        Dim loRtn As CST00200IssueClassDTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

End Class
