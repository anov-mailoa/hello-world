﻿Imports R_Common
Imports CST00200Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "CST00200ReviseService" in code, svc and config file together.
Public Class CST00200ReviseService
    Implements ICST00200ReviseService

    Public Function GetIssueClassCombo(key As CST00200Back.CST00200KeyDTO) As System.Collections.Generic.List(Of CST00200Back.CST00200IssueClassComboDTO) Implements ICST00200ReviseService.GetIssueClassCombo
        Dim loException As New R_Exception
        Dim loCls As New CST00200Cls
        Dim loRtn As List(Of CST00200IssueClassComboDTO)

        Try
            loRtn = loCls.GetIssueClassCombo(key)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetIssueTypeCombo() As System.Collections.Generic.List(Of CST00200Back.CST00200IssueTypeComboDTO) Implements ICST00200ReviseService.GetIssueTypeCombo
        Dim loException As New R_Exception
        Dim loCls As New CST00200Cls
        Dim loRtn As List(Of CST00200IssueTypeComboDTO)

        Try
            loRtn = loCls.GetIssueTypeCombo()
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub Svc_R_Delete(poEntity As CST00200Back.CST00200DTO) Implements R_BackEnd.R_IServicebase(Of CST00200Back.CST00200DTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New CST00200Cls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As CST00200Back.CST00200DTO) As CST00200Back.CST00200DTO Implements R_BackEnd.R_IServicebase(Of CST00200Back.CST00200DTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New CST00200ReviseCls
        Dim loRtn As CST00200DTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As CST00200Back.CST00200DTO, poCRUDMode As R_Common.eCRUDMode) As CST00200Back.CST00200DTO Implements R_BackEnd.R_IServicebase(Of CST00200Back.CST00200DTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New CST00200ReviseCls
        Dim loRtn As CST00200DTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
