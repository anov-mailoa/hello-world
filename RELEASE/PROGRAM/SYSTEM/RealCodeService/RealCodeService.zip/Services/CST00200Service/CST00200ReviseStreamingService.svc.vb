﻿Imports R_Common
Imports CST00200Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "CST00200ReviseStreamingService" in code, svc and config file together.
Public Class CST00200ReviseStreamingService
    Implements ICST00200ReviseStreamingService

    Public Function GetReviseIssueList() As System.ServiceModel.Channels.Message Implements ICST00200ReviseStreamingService.GetReviseIssueList
        Dim loException As New R_Exception
        Dim loCls As New CST00200ReviseCls
        Dim loRtnTemp As List(Of CST00200GridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CST00200ReviseKeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .CPROJECT_ID = R_Utility.R_GetStreamingContext("cProjectId")
                .CSESSION_ID = R_Utility.R_GetStreamingContext("cSessionId")
                .CORI_ATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cOriAttributeGroup")
                .CORI_ATTRIBUTE_ID = R_Utility.R_GetStreamingContext("cOriAttributeId")
                .CORI_ITEM_ID = R_Utility.R_GetStreamingContext("cOriItemId")
                .CORI_ISSUE_ID = R_Utility.R_GetStreamingContext("cOriIssueId")
            End With

            loRtnTemp = loCls.GetReviseIssueList(loTableKey)

            loRtn = R_StreamUtility(Of CST00200GridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getReviseIssueList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetItemList() As System.ServiceModel.Channels.Message Implements ICST00200ReviseStreamingService.GetItemList
        Dim loException As New R_Exception
        Dim loCls As New CST00200ReviseCls
        Dim loRtnTemp As List(Of CST00200ItemListDTO)
        Dim loRtn As Message
        Dim loTableKey As New CST00200KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .CPROJECT_ID = R_Utility.R_GetStreamingContext("cProjectId")
                .CSESSION_ID = R_Utility.R_GetStreamingContext("cSessionId")
            End With

            loRtnTemp = loCls.GetItemList(loTableKey)

            loRtn = R_StreamUtility(Of CST00200ItemListDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getItemList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of CST00200Back.CST00200ItemListDTO), poPar2 As CST00200Back.CST00200GridDTO, poPar3 As RLicenseBack.RCustDBInboxKeyDTO) Implements ICST00200ReviseStreamingService.Dummy

    End Sub
End Class
