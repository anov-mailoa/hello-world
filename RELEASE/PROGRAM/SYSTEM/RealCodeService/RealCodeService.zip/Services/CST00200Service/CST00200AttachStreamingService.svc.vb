﻿Imports R_Common
Imports CST00200Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "CST00200AttachStreamingService" in code, svc and config file together.
Public Class CST00200AttachStreamingService
    Implements ICST00200AttachStreamingService

    Public Function GetIssueAttachment() As System.ServiceModel.Channels.Message Implements ICST00200AttachStreamingService.GetIssueAttachment
        Dim loException As New R_Exception
        Dim loCls As New CST00200AttachCls
        Dim loRtnTemp As List(Of CST00200AttachGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CST00200KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .CPROJECT_ID = R_Utility.R_GetStreamingContext("cProjectId")
                .CSESSION_ID = R_Utility.R_GetStreamingContext("cSessionId")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CATTRIBUTE_ID = R_Utility.R_GetStreamingContext("cAttributeId")
                .CITEM_ID = R_Utility.R_GetStreamingContext("cItemId")
                .CISSUE_ID = R_Utility.R_GetStreamingContext("cIssueId")
            End With

            loRtnTemp = loCls.GetIssueAttachments(loTableKey)

            loRtn = R_StreamUtility(Of CST00200AttachGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getIssueAttachments")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub Dummy(poPar1 As CST00200Back.CST00200AttachGridDTO) Implements ICST00200AttachStreamingService.Dummy

    End Sub
End Class
