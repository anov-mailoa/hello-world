﻿Imports R_Common
Imports CST00200Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "CST00200IssueTypeStreamingService" in code, svc and config file together.
Public Class CST00200IssueClassStreamingService
    Implements ICST00200IssueClassStreamingService

    Public Sub Dummy(poPar1 As CST00200Back.CST00200IssueClassGridDTO) Implements ICST00200IssueClassStreamingService.Dummy

    End Sub

    Public Function GetIssueClassList() As System.ServiceModel.Channels.Message Implements ICST00200IssueClassStreamingService.GetIssueClassList
        Dim loException As New R_Exception
        Dim loCls As New CST00200IssueClassCls
        Dim loRtnTemp As List(Of CST00200IssueClassGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CST00200KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
            End With

            loRtnTemp = loCls.GetIssueClassList(loTableKey)

            loRtn = R_StreamUtility(Of CST00200IssueClassGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getIssueClassList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
