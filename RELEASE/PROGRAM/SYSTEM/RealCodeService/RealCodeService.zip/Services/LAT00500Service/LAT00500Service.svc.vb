﻿Imports R_Common
Imports LAT00500Back
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the class name "LAT00500Service" in code, svc and config file together.
Public Class LAT00500Service
    Implements ILAT00500Service

    Public Sub Svc_R_Delete(poEntity As LAT00500Back.LAT00500DTO) Implements R_BackEnd.R_IServicebase(Of LAT00500Back.LAT00500DTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New LAT00500Cls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As LAT00500Back.LAT00500DTO) As LAT00500Back.LAT00500DTO Implements R_BackEnd.R_IServicebase(Of LAT00500Back.LAT00500DTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New LAT00500Cls
        Dim loRtn As LAT00500DTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As LAT00500Back.LAT00500DTO, poCRUDMode As R_Common.eCRUDMode) As LAT00500Back.LAT00500DTO Implements R_BackEnd.R_IServicebase(Of LAT00500Back.LAT00500DTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New LAT00500Cls
        Dim loRtn As LAT00500DTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetAppCombo(companyId As String, userId As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseAppComboDTO) Implements ILAT00500Service.GetAppCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseAppComboDTO)

        Try
            loRtn = loCls.GetAppCombo(companyId, userId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetCustByAppsCombo(companyId As String, appsCode As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseCustComboDTO) Implements ILAT00500Service.GetCustByAppsCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseCustComboDTO)

        Try
            loRtn = loCls.GetCustByAppsCombo(companyId, appsCode)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Dummy1() As System.Collections.Generic.List(Of LAT00500Back.LAT00500KeyDTO) Implements ILAT00500Service.Dummy1

    End Function
End Class
