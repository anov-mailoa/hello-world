﻿Imports R_Common
Imports SAM01210Back
Imports SAM01200Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "SAM01210Service" in code, svc and config file together.
Public Class SAM01210Service
    Implements ISAM01210Service

    Public Sub Svc_R_Delete(poEntity As SAM01210DTO) Implements R_BackEnd.R_IServicebase(Of SAM01210DTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New SAM01210Cls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

    End Sub

    Public Function Svc_R_GetRecord(poEntity As SAM01210DTO) As SAM01210DTO Implements R_BackEnd.R_IServicebase(Of SAM01210DTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New SAM01210Cls
        Dim loRtn As SAM01210DTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As SAM01210DTO, poCRUDMode As R_Common.eCRUDMode) As SAM01210DTO Implements R_BackEnd.R_IServicebase(Of SAM01210DTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New SAM01210Cls
        Dim loRtn As SAM01210DTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function getSMTP(pcCompId As String) As String Implements ISAM01210Service.getSMTP
        Dim loEx As New R_Exception
        Dim loCls As New SAM01200Cls
        Dim loRtn As String

        Try
            loRtn = loCls.getSMTP(pcCompId)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function getCmbMenu(pcCompId As String) As System.Collections.Generic.List(Of SAM01200Back.cmbDTO) Implements ISAM01210Service.getCmbMenu
        Dim loEx As New R_Exception
        Dim loCls As New SAM01210Cls
        Dim loRtn As List(Of cmbDTO)

        Try
            loRtn = loCls.getCmbMenu(pcCompId)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
