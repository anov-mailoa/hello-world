﻿Imports R_Common
Imports RLicenseBack
Imports CST00200Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "CST00100Service" in code, svc and config file together.
Public Class CST00100Service
    Implements ICST00100Service

    Public Function Dummy1(key1 As RCustDBAttributeGroupComboDTO) As System.Collections.Generic.List(Of RLicenseBack.RCustDBProcessTransactionDTO) Implements ICST00100Service.Dummy1

    End Function

    Public Sub ItemProcess(poKey As RLicenseBack.RCustDBProcessTransactionDTO) Implements ICST00100Service.ItemProcess
        Dim loEx As New R_Exception
        Dim loCls As New RLicenseCls

        Try
            loCls.ItemProcess(poKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function GetAppCombo(companyId As String, userId As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseAppComboDTO) Implements ICST00100Service.GetAppCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseAppComboDTO)

        Try
            loRtn = loCls.GetAppCombo(companyId, userId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetProjectCombo(poKey As RLicenseBack.RCustDBProjectKeyDTO) As System.Collections.Generic.List(Of RLicenseBack.RCustDBProjectComboDTO) Implements ICST00100Service.GetProjectCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBProjectComboDTO)

        Try
            loRtn = loCls.GetProjectCombo(poKey)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetVersionCombo(companyId As String, appsCode As String) As System.Collections.Generic.List(Of RLicenseBack.RCustDBVersionComboDTO) Implements ICST00100Service.GetVersionCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBVersionComboDTO)

        Try
            loRtn = loCls.GetVersionCombo(companyId, appsCode)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetFunctionCombo(key As RLicenseBack.RCustDBProjectKeyDTO) As System.Collections.Generic.List(Of RLicenseBack.RCustDBFunctionComboDTO) Implements ICST00100Service.GetFunctionCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBFunctionComboDTO)

        Try
            loRtn = loCls.GetFunctionCombo(key)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetScheduleCombo(poKey As RLicenseBack.RCustDBProjectKeyDTO) As System.Collections.Generic.List(Of RLicenseBack.RCustDBScheduleComboDTO) Implements ICST00100Service.GetScheduleCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBScheduleComboDTO)

        Try
            loRtn = loCls.GetScheduleCombo(poKey)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetSessionCombo(poKey As RLicenseBack.RCustDBProjectKeyDTO) As System.Collections.Generic.List(Of RLicenseBack.RCustDBSessionComboDTO) Implements ICST00100Service.GetSessionCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBSessionComboDTO)

        Try
            loRtn = loCls.GetSessionCombo(poKey)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub Svc_R_Delete(poEntity As CST00200Back.CST00200DTO) Implements R_BackEnd.R_IServicebase(Of CST00200Back.CST00200DTO).Svc_R_Delete

    End Sub

    Public Function Svc_R_GetRecord(poEntity As CST00200Back.CST00200DTO) As CST00200Back.CST00200DTO Implements R_BackEnd.R_IServicebase(Of CST00200Back.CST00200DTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New CST00200Cls
        Dim loRtn As CST00200DTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As CST00200Back.CST00200DTO, poCRUDMode As R_Common.eCRUDMode) As CST00200Back.CST00200DTO Implements R_BackEnd.R_IServicebase(Of CST00200Back.CST00200DTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New CST00200Cls
        Dim loRtn As New CST00200DTO
        Dim loPar As New CST00200KeyDTO
        Try
            With loPar
                .CCOMPANY_ID = poEntity.CCOMPANY_ID
                .CAPPS_CODE = poEntity.CAPPS_CODE
                .CVERSION = poEntity.CVERSION
                .CPROJECT_ID = poEntity.CPROJECT_ID
                .CSESSION_ID = poEntity.CSESSION_ID
                .CATTRIBUTE_GROUP = poEntity.CATTRIBUTE_GROUP
                .CATTRIBUTE_ID = poEntity.CATTRIBUTE_ID
                .CITEM_ID = poEntity.CITEM_ID
                .CISSUE_ID = poEntity.CISSUE_ID
            End With
            loCls.MarkIssueAsSolved(loPar, poEntity.LSOLVED)
            With loRtn
                .CCOMPANY_ID = poEntity.CCOMPANY_ID
                .CAPPS_CODE = poEntity.CAPPS_CODE
                .CVERSION = poEntity.CVERSION
                .CPROJECT_ID = poEntity.CPROJECT_ID
                .CSESSION_ID = poEntity.CSESSION_ID
                .CATTRIBUTE_GROUP = poEntity.CATTRIBUTE_GROUP
                .CATTRIBUTE_ID = poEntity.CATTRIBUTE_ID
                .CITEM_ID = poEntity.CITEM_ID
                .CISSUE_ID = poEntity.CISSUE_ID
                .LSOLVED = poEntity.LSOLVED
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
