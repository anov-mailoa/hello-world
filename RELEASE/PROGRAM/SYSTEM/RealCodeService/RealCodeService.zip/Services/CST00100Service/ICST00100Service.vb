﻿Imports System.ServiceModel
Imports R_Common
Imports RLicenseBack
Imports CST00200Back
Imports R_BackEnd

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICST00100Service" in both code and config file together.
<ServiceContract()>
Public Interface ICST00100Service
    Inherits R_IServicebase(Of CST00200DTO)

    <OperationContract(Action:="getAppCombo", ReplyAction:="getAppCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAppCombo(companyId As String, userId As String) As List(Of RLicenseAppComboDTO)

    <OperationContract(Action:="getVersionCombo", ReplyAction:="getVersionCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetVersionCombo(companyId As String, appsCode As String) As List(Of RCustDBVersionComboDTO)

    <OperationContract(Action:="getProjectCombo", ReplyAction:="getProjectCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetProjectCombo(key As RCustDBProjectKeyDTO) As List(Of RCustDBProjectComboDTO)

    <OperationContract(Action:="getSessionCombo", ReplyAction:="getSessionCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetSessionCombo(key As RCustDBProjectKeyDTO) As List(Of RCustDBSessionComboDTO)

    <OperationContract(Action:="getScheduleCombo", ReplyAction:="getScheduleCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetScheduleCombo(key As RCustDBProjectKeyDTO) As List(Of RCustDBScheduleComboDTO)

    <OperationContract(Action:="getFunctionCombo", ReplyAction:="getFunctionCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetFunctionCombo(key As RCustDBProjectKeyDTO) As List(Of RCustDBFunctionComboDTO)

    <OperationContract(Action:="itemProcess", ReplyAction:="itemProcess")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub ItemProcess(poKey As RCustDBProcessTransactionDTO)

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function Dummy1(key1 As RCustDBAttributeGroupComboDTO) As List(Of RCustDBProcessTransactionDTO)

End Interface
