﻿Imports R_Common
Imports CSM00500Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00500UsersStreamingService" in code, svc and config file together.
Public Class CSM00500UsersStreamingService
    Implements ICSM00500UsersStreamingService

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of CSM00500Back.CSM00500UsersGridDTO)) Implements ICSM00500UsersStreamingService.Dummy

    End Sub

    Public Function GetProjectUserList() As System.ServiceModel.Channels.Message Implements ICSM00500UsersStreamingService.GetProjectUserList
        Dim loException As New R_Exception
        Dim loCls As New CSM00500UsersCls
        Dim loRtnTemp As List(Of CSM00500UsersGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00500UsersKeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .CPROJECT_ID = R_Utility.R_GetStreamingContext("cProjectId")
                .CSESSION_ID = R_Utility.R_GetStreamingContext("cSessionId")
            End With

            loRtnTemp = loCls.GetProjectUserList(loTableKey)

            loRtn = R_StreamUtility(Of CSM00500UsersGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getProjectUserList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
