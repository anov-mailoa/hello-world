﻿Imports System.ServiceModel
Imports R_BackEnd
Imports CSM00500Back
Imports R_Common
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00500UsersService" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00500UsersService
    Inherits R_IServicebase(Of CSM00500UsersDTO)

    <OperationContract(Action:="getFunctionCombo", ReplyAction:="getFunctionCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetFunctionCombo(key As RCustDBProjectKeyDTO) As List(Of RCustDBFunctionComboDTO)

    <OperationContract(Action:="getLocationCombo", ReplyAction:="getLocationCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetLocationCombo() As List(Of RCustDBLocationComboDTO)

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function Dummy1() As List(Of CSM00500UsersKeyDTO)


End Interface
