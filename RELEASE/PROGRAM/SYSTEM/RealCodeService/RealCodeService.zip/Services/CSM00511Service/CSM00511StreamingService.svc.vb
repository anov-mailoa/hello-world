﻿Imports R_Common
Imports CSM00511BACK
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00511StreamingService" in code, svc and config file together.
Public Class CSM00511StreamingService
    Implements ICSM00511StreamingService

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of CSM00511BACK.CSM00511ScheduleGridDTO)) Implements ICSM00511StreamingService.Dummy

    End Sub

    Public Function GetProjectScheduleList() As System.ServiceModel.Channels.Message Implements ICSM00511StreamingService.GetProjectScheduleList
        Dim loException As New R_Exception
        Dim loCls As New CSM00511ScheduleCls
        Dim loRtnTemp As List(Of CSM00511ScheduleGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00511KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .CPROJECT_ID = R_Utility.R_GetStreamingContext("cProjectId")
                .CSESSION_ID = R_Utility.R_GetStreamingContext("cSessionId")
            End With

            loRtnTemp = loCls.GetScheduleList(loTableKey)

            loRtn = R_StreamUtility(Of CSM00511ScheduleGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getProjectScheduleList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
