﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports RLicenseBack
Imports CSM00511BACK

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00511AssignmentStreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00511AssignmentStreamingService

    <OperationContract(Action:="getItemScheduleList", ReplyAction:="getItemScheduleList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetItemScheduleList() As Message

    <OperationContract(Action:="getIssueList", ReplyAction:="getIssueList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetIssueList() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of CSM00511ItemScheduleGridDTO), _
              ByVal poPar3 As RCustDBIssueListDTO, _
              ByVal poPar4 As RCustDBIssueKeyDTO)

End Interface
