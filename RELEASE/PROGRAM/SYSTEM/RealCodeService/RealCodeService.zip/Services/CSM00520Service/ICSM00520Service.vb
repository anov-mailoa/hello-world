﻿Imports System.ServiceModel
Imports R_BackEnd
Imports R_Common
Imports CSM00520Back
Imports RLicenseBack
Imports CSM00500Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00511Service" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00520Service
    Inherits R_IServicebase(Of CSM00520DTO)

    <OperationContract(Action:="getAppCombo", ReplyAction:="getAppCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAppCombo(companyId As String, userId As String) As List(Of RLicenseAppComboDTO)

    <OperationContract(Action:="getVersionCombo", ReplyAction:="getVersionCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetVersionCombo(companyId As String, appsCode As String) As List(Of RCustDBVersionComboDTO)

    <OperationContract(Action:="getProjectCombo", ReplyAction:="getProjectCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetProjectCombo(key As RCustDBProjectKeyDTO) As List(Of RCustDBProjectComboDTO)

    <OperationContract(Action:="startSession", ReplyAction:="startSession")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub StartSession(poKey As CSM00500SessionKeyDTO)

    <OperationContract(Action:="closeSession", ReplyAction:="closeSession")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub CloseSession(poKey As CSM00500SessionKeyDTO)

    <OperationContract()> _
     <FaultContract(GetType(R_ServiceExceptions))> _
    Function Dummy1() As List(Of CSM00520KeyDTO)

End Interface
