﻿Imports R_Common
Imports RLicenseBack
Imports CSM00520Back
Imports CSM00500Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00520Service" in code, svc and config file together.
Public Class CSM00520Service
    Implements ICSM00520Service

    Public Sub Svc_R_Delete(poEntity As CSM00520Back.CSM00520DTO) Implements R_BackEnd.R_IServicebase(Of CSM00520Back.CSM00520DTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New CSM00520Cls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As CSM00520Back.CSM00520DTO) As CSM00520Back.CSM00520DTO Implements R_BackEnd.R_IServicebase(Of CSM00520Back.CSM00520DTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New CSM00520Cls
        Dim loRtn As CSM00520DTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As CSM00520Back.CSM00520DTO, poCRUDMode As R_Common.eCRUDMode) As CSM00520Back.CSM00520DTO Implements R_BackEnd.R_IServicebase(Of CSM00520Back.CSM00520DTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New CSM00520Cls
        Dim loRtn As CSM00520DTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Dummy1() As System.Collections.Generic.List(Of CSM00520Back.CSM00520KeyDTO) Implements ICSM00520Service.Dummy1

    End Function

    Public Function GetAppCombo(companyId As String, userId As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseAppComboDTO) Implements ICSM00520Service.GetAppCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseAppComboDTO)

        Try
            loRtn = loCls.GetAppCombo(companyId, userId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetProjectCombo(poKey As RLicenseBack.RCustDBProjectKeyDTO) As System.Collections.Generic.List(Of RLicenseBack.RCustDBProjectComboDTO) Implements ICSM00520Service.GetProjectCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBProjectComboDTO)

        Try
            loRtn = loCls.GetProjectCombo(poKey)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetVersionCombo(companyId As String, appsCode As String) As System.Collections.Generic.List(Of RLicenseBack.RCustDBVersionComboDTO) Implements ICSM00520Service.GetVersionCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBVersionComboDTO)

        Try
            loRtn = loCls.GetVersionCombo(companyId, appsCode)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub CloseSession(poKey As CSM00500Back.CSM00500SessionKeyDTO) Implements ICSM00520Service.CloseSession
        Dim loEx As New R_Exception
        Dim loCls As New CSM00500SessionCls

        Try
            loCls.CloseSession(poKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Sub StartSession(poKey As CSM00500Back.CSM00500SessionKeyDTO) Implements ICSM00520Service.StartSession
        Dim loEx As New R_Exception
        Dim loCls As New CSM00500SessionCls

        Try
            loCls.StartSession(poKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

    End Sub
End Class
