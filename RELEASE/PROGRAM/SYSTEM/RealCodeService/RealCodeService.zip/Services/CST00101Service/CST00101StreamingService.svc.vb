﻿Imports R_Common
Imports RLicenseBack
Imports System.ServiceModel.Channels
Imports CST00101BACK
Imports CST00200Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "CST00101StreamingService" in code, svc and config file together.
Public Class CST00101StreamingService
    Implements ICST00101StreamingService

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of CST00101BACK.CST00101ItemInboxDTO), poPar2 As CST00101BACK.CST00101InboxKeyDTO, poPar3 As RLicenseBack.RCustDBIssueListDTO, poPar4 As RLicenseBack.RCustDBIssueKeyDTO, poPar5 As CST00200Back.CST00200KeyDTO, poPar6 As CST00200Back.CST00200AttachGridDTO, poPar7 As System.Collections.Generic.List(Of RLicenseBack.RCustDBInboxNotificationDTO), poPar8 As System.Collections.Generic.List(Of RLicenseBack.RCustDBItemRestoreDTO)) Implements ICST00101StreamingService.Dummy

    End Sub

    Public Function GetInboxNotification() As System.ServiceModel.Channels.Message Implements ICST00101StreamingService.GetInboxNotification
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtnTemp As List(Of RCustDBInboxNotificationDTO)
        Dim loRtn As Message
        Dim loTableKey As New RCustDBInboxKeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CFUNCTION_ID = R_Utility.R_GetStreamingContext("cFunctionId")
                .CUSER_ID = R_Utility.R_GetStreamingContext("cUserId")
            End With

            loRtnTemp = loCls.GetInboxNotification(loTableKey)

            loRtn = R_StreamUtility(Of RCustDBInboxNotificationDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getInboxNotification")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetIssueAttachment() As System.ServiceModel.Channels.Message Implements ICST00101StreamingService.GetIssueAttachment
        Dim loException As New R_Exception
        Dim loCls As New CST00200AttachCls
        Dim loRtnTemp As List(Of CST00200AttachGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CST00200KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .CPROJECT_ID = R_Utility.R_GetStreamingContext("cProjectId")
                .CSESSION_ID = R_Utility.R_GetStreamingContext("cSessionId")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CATTRIBUTE_ID = R_Utility.R_GetStreamingContext("cAttributeId")
                .CITEM_ID = R_Utility.R_GetStreamingContext("cItemId")
                .CISSUE_ID = R_Utility.R_GetStreamingContext("cIssueId")
            End With

            loRtnTemp = loCls.GetIssueAttachments(loTableKey)

            loRtn = R_StreamUtility(Of CST00200AttachGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getIssueAttachments")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetIssueList() As System.ServiceModel.Channels.Message Implements ICST00101StreamingService.GetIssueList
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtnTemp As List(Of RCustDBIssueListDTO)
        Dim loRtn As Message
        Dim loTableKey As New RCustDBIssueKeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .CPROJECT_ID = R_Utility.R_GetStreamingContext("cProjectId")
                .CSESSION_ID = R_Utility.R_GetStreamingContext("cSessionId")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CATTRIBUTE_ID = R_Utility.R_GetStreamingContext("cAttributeId")
                .CITEM_ID = R_Utility.R_GetStreamingContext("cItemId")
                .CSCHEDULE_ID = R_Utility.R_GetStreamingContext("cScheduleId")
                .CPREV_SCHEDULE_ID = R_Utility.R_GetStreamingContext("cPrevScheduleId")
                .LOUTSTANDING_ONLY = True
            End With

            loRtnTemp = loCls.GetIssueList(loTableKey)

            loRtn = R_StreamUtility(Of RCustDBIssueListDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getIssueList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetItemInbox() As System.ServiceModel.Channels.Message Implements ICST00101StreamingService.GetItemInbox
        Dim loException As New R_Exception
        Dim loCls As New CST00101Cls
        Dim loRtnTemp As List(Of CST00101ItemInboxDTO)
        Dim loRtn As Message
        Dim loTableKey As New CST00101InboxKeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .CPROJECT_ID = R_Utility.R_GetStreamingContext("cProjectId")
                .CFUNCTION_ID = R_Utility.R_GetStreamingContext("cFunctionId")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CUSER_ID = R_Utility.R_GetStreamingContext("cUserId")
            End With

            loRtnTemp = loCls.GetItemInbox(loTableKey)

            loRtn = R_StreamUtility(Of CST00101ItemInboxDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getItemInbox")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetItemRestore() As System.ServiceModel.Channels.Message Implements ICST00101StreamingService.GetItemRestore
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtnTemp As List(Of RCustDBItemRestoreDTO)
        Dim loRtn As Message
        Dim loTableKey As New RCustDBInboxKeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CPROJECT_ID = R_Utility.R_GetStreamingContext("cProjectId")
                .CSESSION_ID = R_Utility.R_GetStreamingContext("cSessionId")
                .CSCHEDULE_ID = R_Utility.R_GetStreamingContext("cScheduleId")
                .CFUNCTION_ID = R_Utility.R_GetStreamingContext("cFunctionId")
            End With

            loRtnTemp = loCls.GetItemRestore(loTableKey)

            loRtn = R_StreamUtility(Of RCustDBItemRestoreDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getItemRestore")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
