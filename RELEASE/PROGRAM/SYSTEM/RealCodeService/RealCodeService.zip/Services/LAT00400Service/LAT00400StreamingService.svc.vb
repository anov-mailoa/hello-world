﻿Imports R_Common
Imports LAT00400Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "LAT00400StreamingService" in code, svc and config file together.
Public Class LAT00400StreamingService
    Implements ILAT00400StreamingService

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of LAT00400Back.LAT00400CuCoGridDTO), poPar2 As System.Collections.Generic.List(Of LAT00400Back.LAT00400CuCoDtlGridDTO)) Implements ILAT00400StreamingService.Dummy

    End Sub

    Public Function GetCustomerConfig() As System.ServiceModel.Channels.Message Implements ILAT00400StreamingService.GetCustomerConfig
        Dim loException As New R_Exception
        Dim loCls As New LAT00400Cls
        Dim loRtnTemp As List(Of LAT00400CuCoGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New LAT00400KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CCUSTOMER_CODE = R_Utility.R_GetStreamingContext("cCustomerCode")
            End With

            loRtnTemp = loCls.GetCustomerConfig(loTableKey)

            loRtn = R_StreamUtility(Of LAT00400CuCoGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getCustomerConfig")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetCustomerConfigDetail() As System.ServiceModel.Channels.Message Implements ILAT00400StreamingService.GetCustomerConfigDetail
        Dim loException As New R_Exception
        Dim loCls As New LAT00400DetailCls
        Dim loRtnTemp As List(Of LAT00400CuCoDtlGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New LAT00400KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CCUSTOMER_CODE = R_Utility.R_GetStreamingContext("cCustomerCode")
                .CCONFIG_ID = R_Utility.R_GetStreamingContext("cConfigId")
            End With

            loRtnTemp = loCls.GetCustomerConfigDetail(loTableKey)

            loRtn = R_StreamUtility(Of LAT00400CuCoDtlGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getCustomerConfigDetail")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
