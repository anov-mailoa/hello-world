﻿Imports System.ServiceModel
Imports R_Common
Imports LAT00400Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ILAT00400StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ILAT00400StreamingService

    <OperationContract(Action:="getCustomerConfig", ReplyAction:="getCustomerConfig")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetCustomerConfig() As Message

    <OperationContract(Action:="getCustomerConfigDetail", ReplyAction:="getCustomerConfigDetail")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetCustomerConfigDetail() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of LAT00400CuCoGridDTO),
              ByVal poPar2 As List(Of LAT00400CuCoDtlGridDTO))

End Interface
