﻿Imports R_Common
Imports RVM00100Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "RVM00100CustomerStreamingService" in code, svc and config file together.
Public Class RVM00110StreamingService
    Implements IRVM00110StreamingService

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of RVM00100Back.RVM00100CustomerGridDTO)) Implements IRVM00110StreamingService.Dummy

    End Sub

    Public Function GetApplicationCustomers() As System.ServiceModel.Channels.Message Implements IRVM00110StreamingService.GetApplicationCustomers
        Dim loException As New R_Exception
        Dim loCls As New RVM00100CustomerCls
        Dim loRtnTemp As List(Of RVM00100CustomerGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New RVM00100CustomerGridDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
            End With

            loRtnTemp = loCls.GetApplicationCustomers(loTableKey)

            loRtn = R_StreamUtility(Of RVM00100CustomerGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getApplicationCustomers")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
