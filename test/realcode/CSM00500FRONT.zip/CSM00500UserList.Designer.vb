﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSM00500UserList
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.bsManager = New System.Windows.Forms.BindingSource(Me.components)
        Me.gvManager = New R_FrontEnd.R_RadGridView(Me.components)
        Me.R_ReturnLookUpAndFind1 = New R_FrontEnd.R_ReturnLookUpAndFind()
        CType(Me.bsManager, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvManager, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvManager.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'bsManager
        '
        Me.bsManager.DataSource = GetType(CSM00500Front.CSM00500ServiceRef.CSM00500DTO)
        '
        'gvManager
        '
        Me.gvManager.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gvManager.EnableFastScrolling = True
        Me.gvManager.Location = New System.Drawing.Point(12, 12)
        '
        '
        '
        Me.gvManager.MasterTemplate.AutoGenerateColumns = False
        Me.gvManager.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn1.FieldName = "CUSER_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CUSER_ID"
        R_GridViewTextBoxColumn1.Name = "_CUSER_ID"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CUSER_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 76
        R_GridViewTextBoxColumn2.FieldName = "CUSER_NAME"
        R_GridViewTextBoxColumn2.HeaderText = "_CUSER_NAME"
        R_GridViewTextBoxColumn2.Name = "_CUSER_NAME"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CUSER_NAME"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 325
        Me.gvManager.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2})
        Me.gvManager.MasterTemplate.DataSource = Me.bsManager
        Me.gvManager.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvManager.MasterTemplate.EnableFiltering = True
        Me.gvManager.MasterTemplate.EnableGrouping = False
        Me.gvManager.MasterTemplate.ShowFilteringRow = False
        Me.gvManager.MasterTemplate.ShowGroupedColumns = True
        Me.gvManager.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvManager.Name = "gvManager"
        Me.gvManager.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvManager.R_ConductorGridSource = Nothing
        Me.gvManager.R_ConductorSource = Nothing
        Me.gvManager.R_DataAdded = False
        Me.gvManager.R_NewRowText = Nothing
        Me.gvManager.ShowHeaderCellButtons = True
        Me.gvManager.Size = New System.Drawing.Size(420, 170)
        Me.gvManager.TabIndex = 1
        Me.gvManager.Text = "R_RadGridView1"
        '
        'R_ReturnLookUpAndFind1
        '
        Me.R_ReturnLookUpAndFind1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.R_ReturnLookUpAndFind1.Location = New System.Drawing.Point(270, 188)
        Me.R_ReturnLookUpAndFind1.Name = "R_ReturnLookUpAndFind1"
        Me.R_ReturnLookUpAndFind1.R_BindingSource = Me.bsManager
        Me.R_ReturnLookUpAndFind1.Size = New System.Drawing.Size(162, 31)
        Me.R_ReturnLookUpAndFind1.TabIndex = 2
        '
        'CSM00500UserList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(453, 231)
        Me.Controls.Add(Me.R_ReturnLookUpAndFind1)
        Me.Controls.Add(Me.gvManager)
        Me.Name = "CSM00500UserList"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "User List"
        CType(Me.bsManager, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvManager.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvManager, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents bsManager As System.Windows.Forms.BindingSource
    Friend WithEvents gvManager As R_FrontEnd.R_RadGridView
    Friend WithEvents R_ReturnLookUpAndFind1 As R_FrontEnd.R_ReturnLookUpAndFind

End Class
