﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSM00500PIC
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewComboBoxColumn1 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Dim R_GridViewLookUpColumn1 As R_FrontEnd.R_GridViewLookUpColumn = New R_FrontEnd.R_GridViewLookUpColumn()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn1 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewComboBoxColumn2 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Me.bsFunction = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsLocation = New System.Windows.Forms.BindingSource(Me.components)
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtSession = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblSession = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtProject = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblProject = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtVersion = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtApplication = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblVersion = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvUsers = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvUsers = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridUsers = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.lblCustom = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblCustomer = New R_FrontEnd.R_RadLabel(Me.components)
        CType(Me.bsFunction, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsLocation, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.txtSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvUsers, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvUsers.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvUsers, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridUsers, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCustom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'bsFunction
        '
        Me.bsFunction.DataSource = GetType(CSM00500Front.CSM00500UsersServiceRef.RCustDBFunctionComboDTO)
        '
        'bsLocation
        '
        Me.bsLocation.DataSource = GetType(CSM00500Front.CSM00500UsersServiceRef.RCustDBLocationComboDTO)
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.gvUsers, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 132.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lblCustom)
        Me.Panel1.Controls.Add(Me.lblCustomer)
        Me.Panel1.Controls.Add(Me.txtSession)
        Me.Panel1.Controls.Add(Me.lblSession)
        Me.Panel1.Controls.Add(Me.txtProject)
        Me.Panel1.Controls.Add(Me.lblProject)
        Me.Panel1.Controls.Add(Me.txtVersion)
        Me.Panel1.Controls.Add(Me.txtApplication)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Controls.Add(Me.lblVersion)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 126)
        Me.Panel1.TabIndex = 0
        '
        'txtSession
        '
        Me.txtSession.Location = New System.Drawing.Point(115, 86)
        Me.txtSession.Name = "txtSession"
        Me.txtSession.R_ConductorGridSource = Nothing
        Me.txtSession.R_ConductorSource = Nothing
        Me.txtSession.R_UDT = Nothing
        Me.txtSession.ReadOnly = True
        Me.txtSession.Size = New System.Drawing.Size(206, 20)
        Me.txtSession.TabIndex = 39
        Me.txtSession.TabStop = False
        '
        'lblSession
        '
        Me.lblSession.AutoSize = False
        Me.lblSession.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblSession.Location = New System.Drawing.Point(9, 87)
        Me.lblSession.Name = "lblSession"
        Me.lblSession.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblSession.R_ResourceId = "lblSession"
        Me.lblSession.Size = New System.Drawing.Size(100, 18)
        Me.lblSession.TabIndex = 38
        Me.lblSession.Text = "Application..."
        '
        'txtProject
        '
        Me.txtProject.Location = New System.Drawing.Point(115, 60)
        Me.txtProject.Name = "txtProject"
        Me.txtProject.R_ConductorGridSource = Nothing
        Me.txtProject.R_ConductorSource = Nothing
        Me.txtProject.R_UDT = Nothing
        Me.txtProject.ReadOnly = True
        Me.txtProject.Size = New System.Drawing.Size(206, 20)
        Me.txtProject.TabIndex = 29
        Me.txtProject.TabStop = False
        '
        'lblProject
        '
        Me.lblProject.AutoSize = False
        Me.lblProject.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblProject.Location = New System.Drawing.Point(9, 61)
        Me.lblProject.Name = "lblProject"
        Me.lblProject.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblProject.R_ResourceId = "lblProject"
        Me.lblProject.Size = New System.Drawing.Size(100, 18)
        Me.lblProject.TabIndex = 28
        Me.lblProject.Text = "Application..."
        '
        'txtVersion
        '
        Me.txtVersion.Location = New System.Drawing.Point(115, 34)
        Me.txtVersion.Name = "txtVersion"
        Me.txtVersion.R_ConductorGridSource = Nothing
        Me.txtVersion.R_ConductorSource = Nothing
        Me.txtVersion.R_UDT = Nothing
        Me.txtVersion.ReadOnly = True
        Me.txtVersion.Size = New System.Drawing.Size(206, 20)
        Me.txtVersion.TabIndex = 27
        Me.txtVersion.TabStop = False
        '
        'txtApplication
        '
        Me.txtApplication.Location = New System.Drawing.Point(115, 8)
        Me.txtApplication.Name = "txtApplication"
        Me.txtApplication.R_ConductorGridSource = Nothing
        Me.txtApplication.R_ConductorSource = Nothing
        Me.txtApplication.R_UDT = Nothing
        Me.txtApplication.ReadOnly = True
        Me.txtApplication.Size = New System.Drawing.Size(206, 20)
        Me.txtApplication.TabIndex = 26
        Me.txtApplication.TabStop = False
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 24
        Me.lblApplication.Text = "Application..."
        '
        'lblVersion
        '
        Me.lblVersion.AutoSize = False
        Me.lblVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblVersion.Location = New System.Drawing.Point(9, 35)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblVersion.R_ResourceId = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(100, 18)
        Me.lblVersion.TabIndex = 25
        Me.lblVersion.Text = "Application..."
        '
        'gvUsers
        '
        Me.gvUsers.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvUsers.EnableFastScrolling = True
        Me.gvUsers.Location = New System.Drawing.Point(3, 135)
        '
        '
        '
        Me.gvUsers.MasterTemplate.AutoGenerateColumns = False
        R_GridViewComboBoxColumn1.DataSource = Me.bsFunction
        R_GridViewComboBoxColumn1.DisplayMember = "CFUNCTION_ID"
        R_GridViewComboBoxColumn1.FieldName = "_CFUNCTION_ID"
        R_GridViewComboBoxColumn1.HeaderText = "_CFUNCTION_ID"
        R_GridViewComboBoxColumn1.Name = "_CFUNCTION_ID"
        R_GridViewComboBoxColumn1.R_EnableADD = True
        R_GridViewComboBoxColumn1.R_ResourceId = "_CFUNCTION_ID"
        R_GridViewComboBoxColumn1.ValueMember = "CFUNCTION_ID"
        R_GridViewComboBoxColumn1.Width = 182
        R_GridViewLookUpColumn1.FieldName = "_CUSER_ID"
        R_GridViewLookUpColumn1.HeaderText = "_CUSER_ID"
        R_GridViewLookUpColumn1.Name = "_CUSER_ID"
        R_GridViewLookUpColumn1.R_EnableADD = True
        R_GridViewLookUpColumn1.R_ResourceId = "_CUSER_ID"
        R_GridViewLookUpColumn1.R_Title = Nothing
        R_GridViewLookUpColumn1.Width = 125
        R_GridViewTextBoxColumn1.FieldName = "_CUSER_NAME"
        R_GridViewTextBoxColumn1.HeaderText = "_CUSER_NAME"
        R_GridViewTextBoxColumn1.Name = "_CUSER_NAME"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CUSER_NAME"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 168
        R_GridViewCheckBoxColumn1.FieldName = "_LMANAGER"
        R_GridViewCheckBoxColumn1.HeaderText = "_LMANAGER"
        R_GridViewCheckBoxColumn1.Name = "_LMANAGER"
        R_GridViewCheckBoxColumn1.R_EnableADD = True
        R_GridViewCheckBoxColumn1.R_EnableEDIT = True
        R_GridViewCheckBoxColumn1.R_ResourceId = "_LMANAGER"
        R_GridViewCheckBoxColumn1.Width = 102
        R_GridViewComboBoxColumn2.DataSource = Me.bsLocation
        R_GridViewComboBoxColumn2.DisplayMember = "CLOCATION_NAME"
        R_GridViewComboBoxColumn2.FieldName = "_CLOCATION_ID"
        R_GridViewComboBoxColumn2.HeaderText = "_CLOCATION_ID"
        R_GridViewComboBoxColumn2.Name = "_CLOCATION_ID"
        R_GridViewComboBoxColumn2.R_EnableADD = True
        R_GridViewComboBoxColumn2.R_EnableEDIT = True
        R_GridViewComboBoxColumn2.R_ResourceId = "_CLOCATION_ID"
        R_GridViewComboBoxColumn2.ValueMember = "CLOCATION_ID"
        R_GridViewComboBoxColumn2.Width = 46
        Me.gvUsers.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewComboBoxColumn1, R_GridViewLookUpColumn1, R_GridViewTextBoxColumn1, R_GridViewCheckBoxColumn1, R_GridViewComboBoxColumn2})
        Me.gvUsers.MasterTemplate.DataSource = Me.bsGvUsers
        Me.gvUsers.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvUsers.MasterTemplate.EnableFiltering = True
        Me.gvUsers.MasterTemplate.EnableGrouping = False
        Me.gvUsers.MasterTemplate.ShowFilteringRow = False
        Me.gvUsers.MasterTemplate.ShowGroupedColumns = True
        Me.gvUsers.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvUsers.Name = "gvUsers"
        Me.gvUsers.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvUsers.R_ConductorGridSource = Me.conGridUsers
        Me.gvUsers.R_ConductorSource = Nothing
        Me.gvUsers.R_DataAdded = False
        Me.gvUsers.R_NewRowText = Nothing
        Me.gvUsers.ShowHeaderCellButtons = True
        Me.gvUsers.Size = New System.Drawing.Size(1271, 437)
        Me.gvUsers.TabIndex = 1
        Me.gvUsers.Text = "R_RadGridView1"
        '
        'bsGvUsers
        '
        Me.bsGvUsers.DataSource = GetType(CSM00500Front.CSM00500UsersServiceRef.CSM00500UsersDTO)
        '
        'conGridUsers
        '
        Me.conGridUsers.R_ConductorParent = Nothing
        Me.conGridUsers.R_IsHeader = True
        Me.conGridUsers.R_RadGroupBox = Nothing
        '
        'lblCustom
        '
        Me.lblCustom.AutoSize = False
        Me.lblCustom.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustom.Location = New System.Drawing.Point(327, 61)
        Me.lblCustom.Name = "lblCustom"
        Me.lblCustom.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustom.R_ResourceId = ""
        Me.lblCustom.Size = New System.Drawing.Size(100, 18)
        Me.lblCustom.TabIndex = 44
        Me.lblCustom.Text = "Application..."
        '
        'lblCustomer
        '
        Me.lblCustomer.AutoSize = False
        Me.lblCustomer.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustomer.Location = New System.Drawing.Point(9, 35)
        Me.lblCustomer.Name = "lblCustomer"
        Me.lblCustomer.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustomer.R_ResourceId = "lblCustomer"
        Me.lblCustomer.Size = New System.Drawing.Size(100, 18)
        Me.lblCustomer.TabIndex = 43
        Me.lblCustomer.Text = "Application..."
        '
        'CSM00500PIC
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CSM00500PIC"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "PIC"
        CType(Me.bsFunction, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsLocation, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.txtSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvUsers.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvUsers, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvUsers, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridUsers, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCustom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents lblVersion As R_FrontEnd.R_RadLabel
    Friend WithEvents txtApplication As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtProject As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblProject As R_FrontEnd.R_RadLabel
    Friend WithEvents txtVersion As R_FrontEnd.R_RadTextBox
    Friend WithEvents gvUsers As R_FrontEnd.R_RadGridView
    Friend WithEvents bsGvUsers As System.Windows.Forms.BindingSource
    Friend WithEvents conGridUsers As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsFunction As System.Windows.Forms.BindingSource
    Friend WithEvents txtSession As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblSession As R_FrontEnd.R_RadLabel
    Friend WithEvents bsLocation As System.Windows.Forms.BindingSource
    Friend WithEvents lblCustom As R_FrontEnd.R_RadLabel
    Friend WithEvents lblCustomer As R_FrontEnd.R_RadLabel

End Class
