﻿Imports CSM00500FrontResources
Imports R_Common
Imports CSM00500Front.CSM00500StreamingServiceRef
Imports R_FrontEnd
Imports System.ServiceModel.Channels

Public Class CSM00500UserList

#Region " VARIABLE "
    Dim C_ServiceNameStream As String = "CSM00500Service/CSM00500StreamingService.svc"
#End Region

    Private Sub CSM00500Manager_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Try
            gvManager.R_RefreshGrid(poParameter)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

    Private Sub gvManager_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvManager.R_ServiceGetListRecord
        Dim loServiceStream As CSM00500StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00500StreamingService, CSM00500StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of RCustDBUserListDTO)
        Dim loStreaming2 As IEnumerable(Of CSM00500UsersGridDTO)
        Dim loListEntity As New List(Of CSM00500UsersGridDTO)

        Try
            With CType(poEntity, CSM00500UserListParameterDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)

                If .CFUNCTION_ID IsNot Nothing Then
                    R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                    R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
                    R_Utility.R_SetStreamingContext("cProjectId", .CPROJECT_ID)
                    R_Utility.R_SetStreamingContext("cFunctionId", .CFUNCTION_ID)
                    R_Utility.R_SetStreamingContext("cSessionId", .CSESSION_ID)

                    loRtn = loServiceStream.GetProjectUserList()
                    loStreaming2 = R_StreamUtility(Of CSM00500UsersGridDTO).ReadFromMessage(loRtn)

                    For Each loDto As CSM00500UsersGridDTO In loStreaming2
                        If loDto IsNot Nothing Then
                            loListEntity.Add(loDto)
                        Else
                            Exit For
                        End If
                    Next
                    poListEntityResult = loListEntity
                Else
                    loRtn = loServiceStream.GetProjectManagerList()
                    loStreaming = R_StreamUtility(Of RCustDBUserListDTO).ReadFromMessage(loRtn)

                    For Each loDto As RCustDBUserListDTO In loStreaming
                        If loDto IsNot Nothing Then
                            loListEntity.Add(New CSM00500UsersGridDTO With {.CUSER_ID = loDto.CUSER_ID,
                                                                        .CUSER_NAME = loDto.CUSER_NAME,
                                                                            .CLOCATION_ID = ""})
                        Else
                            Exit For
                        End If
                    Next
                    poListEntityResult = loListEntity
                End If

            End With
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loServiceStream.Close()
        loException.ThrowExceptionIfErrors()
    End Sub

End Class
