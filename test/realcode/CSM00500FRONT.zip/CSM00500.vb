﻿Imports CSM00500FrontResources
Imports R_Common
Imports CSM00500Front.CSM00500ServiceRef
Imports ClientHelper
Imports R_FrontEnd
Imports System.ServiceModel.Channels
Imports CSM00500Front.CSM00500StreamingServiceRef
Imports System.ServiceModel
Imports RCustDBFrontHelper
Imports Telerik.WinControls.UI

Public Class CSM00500

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSM00500Service/CSM00500Service.svc"
    Dim C_ServiceNameStream As String = "CSM00500Service/CSM00500StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CVERSION As String
    Dim _CCUSTOMER_CODE As String
    Dim _LCUSTOM As Boolean
    Dim lcFile As String
    Dim llInitialized As Boolean = False
#End Region

#Region " SUB and FUNCTION "

    Private Sub RefreshGrids()
        Dim loTableKey As New CSM00500KeyDTO
        Dim lcVersion As String
        Dim lcApplication As String
        Dim llVersionOK As Boolean

        lcApplication = ""
        lcVersion = ""
        llVersionOK = False

        If cboVersion.SelectedValue IsNot Nothing Then
            lcVersion = cboVersion.SelectedValue.Trim
            llVersionOK = True
        End If
        If cboApplication.SelectedValue IsNot Nothing Then
            lcApplication = cboApplication.SelectedValue.Trim
        End If
        _LCUSTOM = rdbCustom.IsChecked
        _CVERSION = IIf(_LCUSTOM, _CCUSTOMER_CODE, lcVersion)

        With loTableKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = lcApplication
            .CVERSION = _CVERSION
            .LCUSTOM = _LCUSTOM
            .CCUSTOMER_CODE = _CCUSTOMER_CODE
        End With

        With gvProject
            If llInitialized Then
                .R_RefreshGrid(loTableKey)
                .Columns(0).Sort(Telerik.WinControls.UI.RadSortOrder.Ascending, False)
            End If
            .Enabled = llVersionOK
            '.ReadOnly = _LCUSTOM
        End With
    End Sub

#End Region

#Region " FORM Events "

    Private Sub CSM00500_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Dim loSvc As CSM00500ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00500Service, CSM00500ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loAppCombo As New List(Of RLicenseAppComboDTO)

        Try
            llInitialized = False

            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            ' Application
            loAppCombo = loSvc.GetAppCombo(_CCOMPID, _CUSERID)
            If loAppCombo.Count <= 0 Then
                cboApplication.Items.Clear()
            End If
            bsApps.DataSource = loAppCombo
            llInitialized = True

            RefreshGrids()

            ' Predefined dock
            Me.R_Components = Me.components
            preSession.R_HeaderTitle = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00500SessionTitle")

        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loSvc.Close()
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub CSM00500_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " COMBO Actions "

    Private Sub cboApplication_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboApplication.SelectedValueChanged
        Dim loEx As New R_Exception
        Dim loSvc As CSM00500ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00500Service, CSM00500ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loVersionCombo As New List(Of RCustDBVersionComboDTO)

        Try
            ' Version
            loVersionCombo = loSvc.GetVersionCombo(_CCOMPID, CType(sender, R_RadDropDownList).SelectedValue)
            If loVersionCombo.Count > 0 Then
                bsVersion.DataSource = loVersionCombo
            Else
                cboVersion.Items.Clear()
            End If
            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loSvc.Close()
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub cboVersion_TextChanged(sender As Object, e As System.EventArgs) Handles cboVersion.TextChanged
        If sender.Items.Count > 0 Then
            RefreshGrids()
        End If
    End Sub

#End Region

#Region " GRIDVIEW Events "

    Private Sub gvProject_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvProject.DataBindingComplete
        gvProject.BestFitColumns()
    End Sub

    Private Sub gvProject_R_Before_Open_LookUpForm(sender As Object, e As Telerik.WinControls.UI.EditorRequiredEventArgs, ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles gvProject.R_Before_Open_LookUpForm
        poTargetForm = New CSM00500UserList
        poParameter = New CSM00500UserListParameterDTO With {.CCOMPANY_ID = _CCOMPID}
    End Sub

    Private Sub gvProject_R_Return_LookUp(sender As Object, e As Telerik.WinControls.UI.EditorRequiredEventArgs, poReturnObject As Object) Handles gvProject.R_Return_LookUp
        gvProject.CurrentRow.Cells("_CPROJECT_MANAGER").Value = poReturnObject.CUSER_ID
    End Sub

    Private Sub gvProject_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvProject.R_Saving
        With CType(poEntity, CSM00500DTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = cboApplication.SelectedValue.Trim
            ._CVERSION = IIf(_LCUSTOM, _CCUSTOMER_CODE, cboVersion.SelectedValue.Trim)
            ._LCUSTOM = _LCUSTOM
            ._CCUSTOMER_CODE = IIf(_LCUSTOM, _CCUSTOMER_CODE, "")
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With
    End Sub

    Private Sub gvProject_R_ServiceDelete(poEntity As Object) Handles gvProject.R_ServiceDelete
        Dim loService As CSM00500ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00500Service, CSM00500ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String
        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As FaultException
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loService.Close()
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvProject_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvProject.R_ServiceGetListRecord
        Dim loServiceStream As CSM00500StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00500StreamingService, CSM00500StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00500GridDTO)
        Dim loListEntity As New List(Of CSM00500DTO)

        Try
            With CType(poEntity, CSM00500KeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
                R_Utility.R_SetStreamingContext("lCustom", .LCUSTOM)
                R_Utility.R_SetStreamingContext("cCustomerCode", .CCUSTOMER_CODE)
            End With

            loRtn = loServiceStream.GetProjectList()
            loStreaming = R_StreamUtility(Of CSM00500GridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00500GridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New CSM00500DTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                                  ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                           ._CVERSION = loDto.CVERSION,
                                                           ._CPROJECT_ID = loDto.CPROJECT_ID,
                                                           ._CPROJECT_NAME = loDto.CPROJECT_NAME,
                                                           ._CDESCRIPTION = loDto.CDESCRIPTION,
                                                           ._CPROJECT_MANAGER = loDto.CPROJECT_MANAGER,
                                                           ._CSTATUS = loDto.CSTATUS,
                                                                  ._CCREATE_BY = loDto.CCREATE_BY,
                                                                  ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                                  ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                                  ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loServiceStream.Close()
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvProject_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvProject.R_ServiceGetRecord
        Dim loService As CSM00500ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00500Service, CSM00500ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New CSM00500DTO With {._CCOMPANY_ID = _CCOMPID,
                                                                             ._CAPPS_CODE = cboApplication.SelectedValue.Trim,
                                                                             ._CVERSION = CType(bsGvProject.Current, CSM00500DTO)._CVERSION,
                                                                             ._CPROJECT_ID = CType(bsGvProject.Current, CSM00500DTO)._CPROJECT_ID})
            With CType(poEntityResult, CSM00500DTO)
                _CCUSTOMER_CODE = ._CCUSTOMER_CODE
            End With

        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loService.Close()
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvProject_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvProject.R_ServiceSave
        Dim loService As CSM00500ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00500Service, CSM00500ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loService.Close()

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvProject_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvProject.R_Validation
        Dim loEx As New R_Exception()

        Try
            ' Customer
            If String.IsNullOrWhiteSpace(_CCUSTOMER_CODE) And _LCUSTOM Then
                loEx.Add("CSM00500_12", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00500_12"))
                plCancel = True
            End If

            With poGridCellCollection
                If String.IsNullOrWhiteSpace(.Item("_CPROJECT_ID").Value) Then
                    loEx.Add("CSM00500_01", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00500_01"))
                    plCancel = True
                End If

                If String.IsNullOrWhiteSpace(.Item("_CPROJECT_NAME").Value) Then
                    loEx.Add("CSM00500_02", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00500_02"))
                    plCancel = True
                End If

                If String.IsNullOrWhiteSpace(.Item("_CPROJECT_MANAGER").Value) Then
                    loEx.Add("CSM00500_03", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00500_03"))
                    plCancel = True
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvProject_R_CheckGridAdd(poEntityCollection As Object, ByRef plAllowGridAdd As Boolean) Handles gvProject.R_CheckGridAdd
        plAllowGridAdd = Not _LCUSTOM
    End Sub

    Private Sub gvProject_R_SetEditGridColumn(poEntity As Object, poGridCellCollection As GridViewCellInfoCollection, poGridColumnCollection As GridViewColumnCollection) Handles gvProject.R_SetEditGridColumn
        Dim llReadOnlyProjectName As Boolean

        llReadOnlyProjectName = _LCUSTOM
        CType(poGridColumnCollection("_CPROJECT_NAME"), R_GridViewTextBoxColumn).ReadOnly = llReadOnlyProjectName
    End Sub

    'Private Sub gvProject_R_Display(poEntity As Object, poGridCellCollection As GridViewCellInfoCollection, peGridMode As R_eGridMode) Handles gvProject.R_Display

    'End Sub

#End Region

#Region " PREDEFINED DOCK Events "

    Private Sub preSession_R_InstantiateDock(ByRef poTargetForm As R_FrontEnd.R_FormBase) Handles preSession.R_InstantiateDock
        poTargetForm = New CSM00500Session
    End Sub

    Private Sub preSession_R_PassParameter(ByRef poParameter As Object) Handles preSession.R_PassParameter
        Dim loPICKey As New CSM00500KeyDTO
        Dim lcVersion As String
        Dim lcApplication As String
        Dim lcProjectId As String
        Dim lcProjectName As String

        lcApplication = ""
        lcVersion = ""
        lcProjectId = ""
        If cboVersion.SelectedValue IsNot Nothing Then
            lcVersion = cboVersion.SelectedValue.Trim
        End If
        If cboApplication.SelectedValue IsNot Nothing Then
            lcApplication = cboApplication.SelectedValue.Trim
        End If
        If CType(bsGvProject.Current, CSM00500DTO)._CPROJECT_ID IsNot Nothing Then
            With CType(bsGvProject.Current, CSM00500DTO)
                lcProjectId = ._CPROJECT_ID
                lcProjectName = ._CPROJECT_NAME
                lcVersion = ._CVERSION
            End With
        End If

        With loPICKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = lcApplication
            .CVERSION = lcVersion
            .CPROJECT_ID = lcProjectId
            .CCUSTOMER_CODE = _CCUSTOMER_CODE
            .LCUSTOM = _LCUSTOM
        End With
        poParameter = New CSM00500DetailParameterDTO With {.CAPPS_NAME = cboApplication.Text,
                                                        .CPROJECT_NAME = lcProjectName,
                                                           .CCUSTOMER_NAME = lcProjectName,
                                                        .OGRID_KEY = loPICKey}

    End Sub

#End Region

#Region " BUTTON Actions "

    Private Sub btnCloseProject_Click(sender As System.Object, e As System.EventArgs) Handles btnCloseProject.Click
        Dim loService As CSM00500ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00500Service, CSM00500ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim loPar As New CSM00500KeyDTO
        Dim lcErr As String

        Try
            With loPar
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = cboApplication.SelectedValue.Trim
                .CVERSION = cboVersion.SelectedValue.Trim
                .CPROJECT_ID = CType(bsGvProject.Current, CSM00500DTO)._CPROJECT_ID
                .CUSER_ID = _CUSERID
            End With
            loService.CloseProject(loPar)
            RefreshGrids()
        Catch ex As FaultException
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loService.Close()
        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If
    End Sub

#End Region

#Region " LOOKUP Events "

    Private Sub R_LookUp1_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles lupCustomer.R_Before_Open_Form
        poTargetForm = New CustList
        poParameter = New FileStreamingServiceRef.RCustDBFileKeyDTO With {.CCOMPANY_ID = _CCOMPID}
    End Sub

    Private Sub R_LookUp1_R_Return_LookUp(poReturnObject As Object) Handles lupCustomer.R_Return_LookUp
        txtCustomerCode.Text = poReturnObject.CCUSTOMER_CODE
        txtCustomerName.Text = poReturnObject.CCUSTOMER_NAME
    End Sub

    Private Sub txtCustomerCode_TextChanged(sender As Object, e As System.EventArgs) Handles txtCustomerCode.TextChanged
        _CCUSTOMER_CODE = txtCustomerCode.Text
        RefreshGrids()
    End Sub

#End Region

#Region " RADIO BUTTON Actions "

    Private Sub rdbStandard_CheckStateChanged(sender As Object, e As System.EventArgs) Handles rdbStandard.CheckStateChanged
        If CType(sender, R_RadRadioButton).IsChecked Then
            RefreshGrids()
        End If
    End Sub

    Private Sub rdbCustom_CheckStateChanged(sender As Object, e As System.EventArgs) Handles rdbCustom.CheckStateChanged
        If CType(sender, R_RadRadioButton).IsChecked Then
            RefreshGrids()
        End If
    End Sub

    Private Sub conGridProject_R_SetAdd(plEnable As Boolean) Handles conGridProject.R_SetAdd
        lblVersion.Visible = Not plEnable And Not _LCUSTOM
        cboVersion.Enabled = Not plEnable And Not _LCUSTOM
        cboVersion.Visible = Not plEnable And Not _LCUSTOM
        'lblCustomer.Visible = Not plEnable And _LCUSTOM
        'txtCustomerCode.Enabled = Not plEnable And _LCUSTOM
        'lupCustomer.Enabled = Not plEnable And _LCUSTOM
        'txtCustomerCode.Visible = Not plEnable And _LCUSTOM
        'lupCustomer.Visible = Not plEnable And _LCUSTOM
        'txtCustomerName.Visible = Not plEnable And _LCUSTOM
    End Sub

    Private Sub conGridProject_R_SetEdit(plEnable As Boolean) Handles conGridProject.R_SetEdit
        lblVersion.Visible = Not plEnable And Not _LCUSTOM
        cboVersion.Enabled = Not plEnable And Not _LCUSTOM
        cboVersion.Visible = Not plEnable And Not _LCUSTOM
        'lblCustomer.Visible = Not plEnable And _LCUSTOM
        'txtCustomerCode.Enabled = Not plEnable And _LCUSTOM
        'lupCustomer.Enabled = Not plEnable And _LCUSTOM
        'txtCustomerCode.Visible = Not plEnable And _LCUSTOM
        'lupCustomer.Visible = Not plEnable And _LCUSTOM
        'txtCustomerName.Visible = Not plEnable And _LCUSTOM
    End Sub

#End Region

End Class
