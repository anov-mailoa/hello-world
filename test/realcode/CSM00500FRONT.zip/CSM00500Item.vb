﻿Imports CSM00500FrontResources
Imports R_Common
Imports ClientHelper
Imports CSM00500Front.CSM00500ItemServiceRef
Imports R_FrontEnd
Imports CSM00500Front.CSM00500ItemStreamingServiceRef
Imports System.ServiceModel.Channels
Imports CSM00500Common

Public Class CSM00500Item

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSM00500Service/CSM00500ItemService.svc"
    Dim C_ServiceNameStream As String = "CSM00500Service/CSM00500ItemStreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _CVERSION As String
    Dim _CPROJECTID As String
    Dim _CSESSIONID As String
    Dim _CUSER_NAME As String
    Dim _CDESIGN_PIC As String
    Dim _CDEVELOPMENT_PIC As String
    Dim _CQC_PIC As String
    Dim _CINIT_SCHEDULE_TYPE As String
    Dim _CCUSTOMER_NAME As String
    Dim _LCUSTOM As Boolean
#End Region

#Region " SUB and FUNCTION "

    Private Sub RefreshGrids()
        gvAvailableItems.R_RefreshGrid(_CCOMPID)
        gvSelectedItems.R_RefreshGrid(_CCOMPID)
    End Sub

#End Region

#Region " FORM Events "

    Private Sub CSM00500Item_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loSvc As CSM00500ItemServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00500ItemService, CSM00500ItemServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loAttributeGroupCombo As New List(Of RCustDBAttributeGroupComboDTO)
        Dim loScheduleTypeCombo As New List(Of RCustDBScheduleTypeComboDTO)
        Dim loDefaultPIC As New CSM00500DefaultPICDTO
        Dim loKey As New CSM00500KeyDTO

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            With CType(poParameter, CSM00500DetailParameterDTO)
                _CAPPSCODE = .OGRID_KEY.CAPPS_CODE
                _CVERSION = .OGRID_KEY.CVERSION
                _CPROJECTID = .OGRID_KEY.CPROJECT_ID
                _CSESSIONID = .CSESSION_ID
                _CINIT_SCHEDULE_TYPE = .CINIT_SCHEDULE_TYPE
                _LCUSTOM = .OGRID_KEY.LCUSTOM
                _CCUSTOMER_NAME = .CCUSTOMER_NAME
                txtApplication.Text = .CAPPS_NAME
                txtVersion.Text = IIf(.OGRID_KEY.LCUSTOM, .CCUSTOMER_NAME, .OGRID_KEY.CVERSION)
                txtProject.Text = .CPROJECT_NAME
                txtSession.Text = .CSESSION_ID
                lblVersion.Visible = Not .OGRID_KEY.LCUSTOM
                lblCustomer.Visible = .OGRID_KEY.LCUSTOM
                lblCustom.Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), IIf(_LCUSTOM, "rdbCustom", "rdbStandard"))
            End With

            ' Combos
            If _LCUSTOM Then
                loAttributeGroupCombo.Add(New RCustDBAttributeGroupComboDTO With {.CATTRIBUTE_GROUP = "PROGRAM"})
            Else
                loAttributeGroupCombo = loSvc.GetAttributeGroupCombo(_CCOMPID, _CAPPSCODE)
            End If
            bsAttributeGroup.DataSource = loAttributeGroupCombo
            loSvc.Close()

            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loSvc.Close()
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub CSM00500Item_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " COMBO Actions "
    Private Sub cboAttributeGroup_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboAttributeGroup.SelectedValueChanged
        Dim loEx As New R_Exception
        Dim loSvc As CSM00500ItemServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00500ItemService, CSM00500ItemServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loAttributeCombo As New List(Of RCustDBAttributeComboDTO)

        Try
            loAttributeCombo = loSvc.GetAttributeCombo(_CCOMPID, _CAPPSCODE, CType(sender, R_RadDropDownList).SelectedValue)
            bsAttribute.DataSource = loAttributeCombo
            loSvc.Close()
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loSvc.Close()
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub cboAttribute_TextChanged(sender As Object, e As System.EventArgs) Handles cboAttribute.TextChanged
        RefreshGrids()
    End Sub

#End Region

#Region " GRIDVIEW Events "

    Private Sub gvAvailableItems_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvAvailableItems.DataBindingComplete
        gvAvailableItems.BestFitColumns()
    End Sub

    Private Sub gvAvailableItems_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvAvailableItems.R_ServiceGetListRecord
        Dim loServiceStream As CSM00500ItemStreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00500ItemStreamingService, CSM00500ItemStreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00500ItemGridDTO)
        Dim loListEntity As New List(Of CSM00500ItemGridDTO)

        Try
            R_Utility.R_SetStreamingContext("cCompanyId", _CCOMPID)
            R_Utility.R_SetStreamingContext("cAppsCode", _CAPPSCODE)
            R_Utility.R_SetStreamingContext("cVersion", _CVERSION)
            R_Utility.R_SetStreamingContext("cProjectId", _CPROJECTID)
            R_Utility.R_SetStreamingContext("cAttributeGroup", cboAttributeGroup.SelectedValue)
            R_Utility.R_SetStreamingContext("cAttributeId", cboAttribute.SelectedValue)
            R_Utility.R_SetStreamingContext("cSessionId", txtSession.Text)
            R_Utility.R_SetStreamingContext("lCustom", _LCUSTOM)
            R_Utility.R_SetStreamingContext("cCustomerCode", _CVERSION)

            loRtn = loServiceStream.GetAvailableItems()
            loStreaming = R_StreamUtility(Of CSM00500ItemGridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00500ItemGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loServiceStream.Close()
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvAvailableItems_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvAvailableItems.R_ServiceGetRecord
        Dim loEx As New R_Exception

        Try
            poEntityResult = poEntity
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSelectedItems_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvSelectedItems.DataBindingComplete
        gvSelectedItems.BestFitColumns()
    End Sub

    Private Sub gvSelectedItems_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvSelectedItems.R_ServiceGetListRecord
        Dim loServiceStream As CSM00500ItemStreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00500ItemStreamingService, CSM00500ItemStreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00500ItemGridDTO)
        Dim loListEntity As New List(Of CSM00500ItemGridDTO)

        Try
            R_Utility.R_SetStreamingContext("cCompanyId", _CCOMPID)
            R_Utility.R_SetStreamingContext("cAppsCode", _CAPPSCODE)
            R_Utility.R_SetStreamingContext("cVersion", _CVERSION)
            R_Utility.R_SetStreamingContext("cProjectId", _CPROJECTID)
            R_Utility.R_SetStreamingContext("cAttributeGroup", cboAttributeGroup.SelectedValue)
            R_Utility.R_SetStreamingContext("cAttributeId", cboAttribute.SelectedValue)
            R_Utility.R_SetStreamingContext("cSessionId", txtSession.Text)
            R_Utility.R_SetStreamingContext("lCustom", _LCUSTOM)
            R_Utility.R_SetStreamingContext("cCustomerCode", _CVERSION)

            loRtn = loServiceStream.GetSelectedItems()
            loStreaming = R_StreamUtility(Of CSM00500ItemGridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00500ItemGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loServiceStream.Close()
        loException.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " PIC "

    Private Sub btnDesign_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnDesign.R_Before_Open_Form
        poTargetForm = New CSM00500UserList
        poParameter = New CSM00500UserListParameterDTO With {.CCOMPANY_ID = _CCOMPID, _
                                                             .CAPPS_CODE = _CAPPSCODE, _
                                                             .CVERSION = _CVERSION, _
                                                             .CPROJECT_ID = _CPROJECTID, _
                                                             .CFUNCTION_ID = "DESIGN"}
    End Sub

    Private Sub btnDesign_R_Return_LookUp(poReturnObject As Object) Handles btnDesign.R_Return_LookUp
        With poReturnObject
            _CDESIGN_PIC = .CUSER_ID
            txtDesignPIC.Text = .CUSER_NAME.Trim & " (" & .CUSER_ID.Trim & ")"
        End With
    End Sub

    Private Sub btnDevelopment_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnDevelopment.R_Before_Open_Form
        poTargetForm = New CSM00500UserList
        poParameter = New CSM00500UserListParameterDTO With {.CCOMPANY_ID = _CCOMPID, _
                                                             .CAPPS_CODE = _CAPPSCODE, _
                                                             .CVERSION = _CVERSION, _
                                                             .CPROJECT_ID = _CPROJECTID, _
                                                             .CFUNCTION_ID = "DEVELOPMENT"}
    End Sub

    Private Sub btnDevelopment_R_Return_LookUp(poReturnObject As Object) Handles btnDevelopment.R_Return_LookUp
        With poReturnObject
            _CDEVELOPMENT_PIC = .CUSER_ID
            txtDevelopmentPIC.Text = .CUSER_NAME.Trim & " (" & .CUSER_ID.Trim & ")"
        End With
    End Sub

    Private Sub btnQC_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnQC.R_Before_Open_Form
        poTargetForm = New CSM00500UserList
        poParameter = New CSM00500UserListParameterDTO With {.CCOMPANY_ID = _CCOMPID, _
                                                             .CAPPS_CODE = _CAPPSCODE, _
                                                             .CVERSION = _CVERSION, _
                                                             .CPROJECT_ID = _CPROJECTID, _
                                                             .CFUNCTION_ID = "QC"}
    End Sub

    Private Sub btnQC_R_Return_LookUp(poReturnObject As Object) Handles btnQC.R_Return_LookUp
        With poReturnObject
            _CQC_PIC = .CUSER_ID
            txtQCPIC.Text = .CUSER_NAME.Trim & " (" & .CUSER_ID.Trim & ")"
        End With
    End Sub

    Private Sub btnProcess_Click(sender As Object, e As System.EventArgs) Handles btnProcess.Click
        Dim loEx As New R_Exception
        Dim loBatchPar As R_BatchParameter
        Dim loSvc As R_ProcessAndUploadClient
        Dim loBigObject As New List(Of CSM00500BatchDTO)
        Dim lcKeyGuid As String
        Dim loUserParameters As New List(Of R_KeyValue)
        Dim lcScheduleType As String

        lcScheduleType = cboScheduleType.SelectedValue
        Me.Cursor = Windows.Forms.Cursors.WaitCursor
        btnProcess.Enabled = False
        Try
            ' Jika complaint, tidak bisa add design item
            If cboAttributeGroup.SelectedValue = "DESIGN" And _CINIT_SCHEDULE_TYPE = "3" Then
                loEx.Add("CSM00500_11", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00500_11"))
                Exit Try
            End If

            Dim loCheckedItems = From item In CType(bsGvAvailableItems.List, List(Of CSM00500ItemGridDTO)) _
                             Where item.LSELECT = True
            Dim loSpecItems = From item In CType(bsGvAvailableItems.List, List(Of CSM00500ItemGridDTO)) _
                             Where item.LSELECT = True And item.LSPEC = True

            If loCheckedItems.ToList.Count = 0 Then
                loEx.Add("CSM00500_04", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00500_04"))
                Exit Try
            End If

            'Instantiate FrontHelper
            loSvc = New R_ProcessAndUploadClient(Nothing, Nothing, Nothing)
            AddHandler loSvc.ProcessError, AddressOf ProcessError
            AddHandler loSvc.ProcessComplete, AddressOf ProcessComplete

            'Items
            loBigObject.AddRange(loCheckedItems.Select(Function(x) New CSM00500BatchDTO() _
                    With {.CCOMPANY_ID = _CCOMPID, _
                          .CAPPS_CODE = _CAPPSCODE, _
                          .CVERSION = _CVERSION, _
                          .CPROJECT_ID = _CPROJECTID, _
                          .CSESSION_ID = _CSESSIONID, _
                          .CATTRIBUTE_GROUP = cboAttributeGroup.SelectedValue, _
                          .CATTRIBUTE_ID = cboAttribute.SelectedValue, _
                          .CITEM_ID = x.CITEM_ID}).ToList())

            If loBigObject.Count = 0 Then
                Exit Try
            End If

            With loBatchPar
                .COMPANY_ID = _CCOMPID
                .USER_ID = _CUSERID
                .ClassName = "CSM00500Back.CSM00500ItemCls"
                .BigObject = loBigObject
                .UserParameters = loUserParameters
            End With
            lcKeyGuid = loSvc.R_BatchProcess(loBatchPar, loBigObject.Count)

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            btnProcess.Enabled = True
            Me.Cursor = Windows.Forms.Cursors.Default
        End Try

        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If

    End Sub


    Private Sub ProcessComplete(pcKeyGuid As String, poProcessResultMode As eProcessResultMode)
        Dim loEx As New R_Exception()

        Select Case poProcessResultMode
            Case eProcessResultMode.Success
                MsgBox("Process Complete", MsgBoxStyle.OkOnly, "Project Setting")
                RefreshGrids()
            Case eProcessResultMode.Fail
                Dim loException As New R_Exception
                Dim loRtn As List(Of R_ErrorStatusReturn)
                Dim loHelp As New R_ProcessAndUploadClient(bwCSM00500, Nothing, Nothing)
                Dim loPar As R_UploadAndProcessKey

                Try
                    With loPar
                        .COMPANY_ID = _CCOMPID
                        .USER_ID = _CUSERID
                        .KEY_GUID = pcKeyGuid
                    End With
                    loRtn = loHelp.R_GetErrorProcess(loPar)

                    For Each loError As R_ErrorStatusReturn In loRtn
                        loEx.Add(loError.SeqNo.ToString, loError.ErrorMessage)
                    Next
                Catch ex As Exception
                    loException.Add(ex)
                End Try

                If loException.Haserror Then
                    loEx.ThrowExceptionIfErrors()
                End If
        End Select
        btnProcess.Enabled = True
        Me.Cursor = Windows.Forms.Cursors.Default
    End Sub

    Private Sub ProcessError(pcKeyGuid As String, ex As R_Exception)
        Dim loEx As New R_Exception()

        If ex.Haserror Then
            Me.R_DisplayException(ex)
        End If
        RefreshGrids()
        btnProcess.Enabled = True
        Me.Cursor = Windows.Forms.Cursors.Default
    End Sub

#End Region

#Region " DELETE ITEM "

    Private Sub btnDeleteItem_Click(sender As System.Object, e As System.EventArgs) Handles btnDeleteItem.Click
        Dim loEx As New R_Exception()
        Dim loSvc As CSM00500ItemServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00500ItemService, CSM00500ItemServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loKey As New CSM00500ItemKeyDTO

        Try
            With loKey
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = _CAPPSCODE
                .CVERSION = _CVERSION
                .CPROJECT_ID = _CPROJECTID
                .CSESSION_ID = _CSESSIONID
                .CATTRIBUTE_GROUP = cboAttributeGroup.SelectedValue
                .CATTRIBUTE_ID = CType(bsGvSelectedItems.Current, CSM00500ItemGridDTO).CATTRIBUTE_ID
                .CITEM_ID = CType(bsGvSelectedItems.Current, CSM00500ItemGridDTO).CITEM_ID
                .CUSER_ID = _CUSERID
            End With
            loSvc.DeleteItem(loKey)
            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loSvc.Close()
        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If
    End Sub

#End Region

End Class
