﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSM00500
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewLookUpColumn1 As R_FrontEnd.R_GridViewLookUpColumn = New R_FrontEnd.R_GridViewLookUpColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblCustomer = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblVersion = New R_FrontEnd.R_RadLabel(Me.components)
        Me.cboVersion = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsVersion = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridProject = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.txtCustomerName = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtCustomerCode = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lupCustomer = New R_FrontEnd.R_LookUp(Me.components)
        Me.rdbCustom = New R_FrontEnd.R_RadRadioButton(Me.components)
        Me.rdbStandard = New R_FrontEnd.R_RadRadioButton(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.cboApplication = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.gvProject = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvProject = New System.Windows.Forms.BindingSource(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnCloseProject = New R_FrontEnd.R_RadButton(Me.components)
        Me.preSession = New R_FrontEnd.R_PredefinedDock(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCustomerName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCustomerCode, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lupCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.rdbCustom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.rdbStandard, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvProject.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvProject, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.btnCloseProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.gvProject, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 0, 2)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 96.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lblCustomer)
        Me.Panel1.Controls.Add(Me.lblVersion)
        Me.Panel1.Controls.Add(Me.cboVersion)
        Me.Panel1.Controls.Add(Me.txtCustomerName)
        Me.Panel1.Controls.Add(Me.txtCustomerCode)
        Me.Panel1.Controls.Add(Me.lupCustomer)
        Me.Panel1.Controls.Add(Me.rdbCustom)
        Me.Panel1.Controls.Add(Me.rdbStandard)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Controls.Add(Me.cboApplication)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 90)
        Me.Panel1.TabIndex = 0
        '
        'lblCustomer
        '
        Me.lblCustomer.AutoSize = False
        Me.lblCustomer.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustomer.Location = New System.Drawing.Point(9, 59)
        Me.lblCustomer.Name = "lblCustomer"
        Me.lblCustomer.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustomer.R_ResourceId = "lblCustomer"
        Me.lblCustomer.Size = New System.Drawing.Size(100, 18)
        Me.lblCustomer.TabIndex = 30
        Me.lblCustomer.Text = "Application..."
        Me.lblCustomer.Visible = False
        '
        'lblVersion
        '
        Me.lblVersion.AutoSize = False
        Me.lblVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblVersion.Location = New System.Drawing.Point(9, 59)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblVersion.R_ResourceId = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(100, 18)
        Me.lblVersion.TabIndex = 23
        Me.lblVersion.Text = "Application..."
        '
        'cboVersion
        '
        Me.cboVersion.DataSource = Me.bsVersion
        Me.cboVersion.DisplayMember = "CCODE_NAME"
        Me.cboVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboVersion.Location = New System.Drawing.Point(115, 58)
        Me.cboVersion.Name = "cboVersion"
        Me.cboVersion.R_ConductorGridSource = Me.conGridProject
        Me.cboVersion.R_ConductorSource = Nothing
        Me.cboVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboVersion.Size = New System.Drawing.Size(147, 20)
        Me.cboVersion.TabIndex = 24
        Me.cboVersion.Text = "R_RadDropDownList1"
        Me.cboVersion.ValueMember = "CVERSION"
        '
        'bsVersion
        '
        Me.bsVersion.DataSource = GetType(CSM00500Front.CSM00500ServiceRef.RCustDBVersionComboDTO)
        '
        'conGridProject
        '
        Me.conGridProject.R_ConductorParent = Nothing
        Me.conGridProject.R_IsHeader = True
        Me.conGridProject.R_RadGroupBox = Nothing
        '
        'txtCustomerName
        '
        Me.txtCustomerName.Enabled = False
        Me.txtCustomerName.Location = New System.Drawing.Point(257, 58)
        Me.txtCustomerName.Name = "txtCustomerName"
        Me.txtCustomerName.R_ConductorGridSource = Nothing
        Me.txtCustomerName.R_ConductorSource = Nothing
        Me.txtCustomerName.R_UDT = Nothing
        Me.txtCustomerName.Size = New System.Drawing.Size(258, 20)
        Me.txtCustomerName.TabIndex = 29
        Me.txtCustomerName.Visible = False
        '
        'txtCustomerCode
        '
        Me.txtCustomerCode.Location = New System.Drawing.Point(115, 58)
        Me.txtCustomerCode.Name = "txtCustomerCode"
        Me.txtCustomerCode.R_ConductorGridSource = Me.conGridProject
        Me.txtCustomerCode.R_ConductorSource = Nothing
        Me.txtCustomerCode.R_UDT = Nothing
        Me.txtCustomerCode.Size = New System.Drawing.Size(100, 20)
        Me.txtCustomerCode.TabIndex = 28
        Me.txtCustomerCode.Visible = False
        '
        'lupCustomer
        '
        Me.lupCustomer.Location = New System.Drawing.Point(221, 58)
        Me.lupCustomer.Name = "lupCustomer"
        Me.lupCustomer.R_ConductorGridSource = Me.conGridProject
        Me.lupCustomer.R_ConductorSource = Nothing
        Me.lupCustomer.R_DescriptionId = Nothing
        Me.lupCustomer.R_Field_Description = ""
        Me.lupCustomer.R_Field_Value = ""
        Me.lupCustomer.R_ResourceId = Nothing
        Me.lupCustomer.R_TextBox_Description = Me.txtCustomerName
        Me.lupCustomer.R_TextBox_Value = Me.txtCustomerCode
        Me.lupCustomer.R_Title = Nothing
        Me.lupCustomer.Size = New System.Drawing.Size(30, 20)
        Me.lupCustomer.TabIndex = 27
        Me.lupCustomer.Text = "..."
        Me.lupCustomer.Visible = False
        '
        'rdbCustom
        '
        Me.rdbCustom.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.rdbCustom.Location = New System.Drawing.Point(246, 35)
        Me.rdbCustom.Name = "rdbCustom"
        Me.rdbCustom.R_ConductorGridSource = Nothing
        Me.rdbCustom.R_ConductorSource = Nothing
        Me.rdbCustom.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.rdbCustom.R_ResourceId = "rdbCustom"
        Me.rdbCustom.Size = New System.Drawing.Size(122, 18)
        Me.rdbCustom.TabIndex = 26
        Me.rdbCustom.TabStop = False
        Me.rdbCustom.Text = "R_RadRadioButton2"
        '
        'rdbStandard
        '
        Me.rdbStandard.CheckState = System.Windows.Forms.CheckState.Checked
        Me.rdbStandard.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.rdbStandard.Location = New System.Drawing.Point(115, 35)
        Me.rdbStandard.Name = "rdbStandard"
        Me.rdbStandard.R_ConductorGridSource = Nothing
        Me.rdbStandard.R_ConductorSource = Nothing
        Me.rdbStandard.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.rdbStandard.R_ResourceId = "rdbStandard"
        Me.rdbStandard.Size = New System.Drawing.Size(122, 18)
        Me.rdbStandard.TabIndex = 25
        Me.rdbStandard.Text = "R_RadRadioButton1"
        Me.rdbStandard.ToggleState = Telerik.WinControls.Enumerations.ToggleState.[On]
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 21
        Me.lblApplication.Text = "Application..."
        '
        'cboApplication
        '
        Me.cboApplication.DataSource = Me.bsApps
        Me.cboApplication.DisplayMember = "CAPPS_NAME"
        Me.cboApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboApplication.Location = New System.Drawing.Point(115, 9)
        Me.cboApplication.Name = "cboApplication"
        Me.cboApplication.R_ConductorGridSource = Me.conGridProject
        Me.cboApplication.R_ConductorSource = Nothing
        Me.cboApplication.R_EnableOTHER = True
        Me.cboApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboApplication.Size = New System.Drawing.Size(400, 20)
        Me.cboApplication.TabIndex = 22
        Me.cboApplication.Text = "R_RadDropDownList1"
        Me.cboApplication.ValueMember = "CAPPS_CODE"
        '
        'bsApps
        '
        Me.bsApps.DataSource = GetType(CSM00500Front.CSM00500ServiceRef.RLicenseAppComboDTO)
        '
        'gvProject
        '
        Me.gvProject.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvProject.EnableFastScrolling = True
        Me.gvProject.Location = New System.Drawing.Point(3, 99)
        '
        '
        '
        Me.gvProject.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn1.FieldName = "_CPROJECT_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CPROJECT_ID"
        R_GridViewTextBoxColumn1.MaxLength = 20
        R_GridViewTextBoxColumn1.Name = "_CPROJECT_ID"
        R_GridViewTextBoxColumn1.R_EnableADD = True
        R_GridViewTextBoxColumn1.R_ResourceId = "_CPROJECT_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 94
        R_GridViewTextBoxColumn2.FieldName = "_CPROJECT_NAME"
        R_GridViewTextBoxColumn2.HeaderText = "_CPROJECT_NAME"
        R_GridViewTextBoxColumn2.MaxLength = 100
        R_GridViewTextBoxColumn2.Name = "_CPROJECT_NAME"
        R_GridViewTextBoxColumn2.R_EnableADD = True
        R_GridViewTextBoxColumn2.R_EnableEDIT = True
        R_GridViewTextBoxColumn2.R_ResourceId = "_CPROJECT_NAME"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 115
        R_GridViewTextBoxColumn3.FieldName = "_CDESCRIPTION"
        R_GridViewTextBoxColumn3.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxColumn3.MaxLength = 200
        R_GridViewTextBoxColumn3.Name = "_CDESCRIPTION"
        R_GridViewTextBoxColumn3.R_EnableADD = True
        R_GridViewTextBoxColumn3.R_EnableEDIT = True
        R_GridViewTextBoxColumn3.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 103
        R_GridViewLookUpColumn1.FieldName = "_CPROJECT_MANAGER"
        R_GridViewLookUpColumn1.HeaderText = "_CPROJECT_MANAGER"
        R_GridViewLookUpColumn1.Name = "_CPROJECT_MANAGER"
        R_GridViewLookUpColumn1.R_EnableADD = True
        R_GridViewLookUpColumn1.R_EnableEDIT = True
        R_GridViewLookUpColumn1.R_ResourceId = "_CPROJECT_MANAGER"
        R_GridViewLookUpColumn1.R_Title = Nothing
        R_GridViewLookUpColumn1.Width = 137
        R_GridViewTextBoxColumn4.FieldName = "_CSTATUS"
        R_GridViewTextBoxColumn4.HeaderText = "_CSTATUS"
        R_GridViewTextBoxColumn4.Name = "_CSTATUS"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CSTATUS"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 73
        Me.gvProject.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewLookUpColumn1, R_GridViewTextBoxColumn4})
        Me.gvProject.MasterTemplate.DataSource = Me.bsGvProject
        Me.gvProject.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvProject.MasterTemplate.EnableFiltering = True
        Me.gvProject.MasterTemplate.EnableGrouping = False
        Me.gvProject.MasterTemplate.ShowFilteringRow = False
        Me.gvProject.MasterTemplate.ShowGroupedColumns = True
        Me.gvProject.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvProject.Name = "gvProject"
        Me.gvProject.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvProject.R_ConductorGridSource = Me.conGridProject
        Me.gvProject.R_ConductorSource = Nothing
        Me.gvProject.R_DataAdded = False
        Me.gvProject.R_NewRowText = Nothing
        Me.gvProject.ShowHeaderCellButtons = True
        Me.gvProject.Size = New System.Drawing.Size(1271, 441)
        Me.gvProject.TabIndex = 2
        Me.gvProject.Text = "R_RadGridView1"
        '
        'bsGvProject
        '
        Me.bsGvProject.DataSource = GetType(CSM00500Front.CSM00500ServiceRef.CSM00500DTO)
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.btnCloseProject)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 546)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1271, 26)
        Me.Panel2.TabIndex = 3
        '
        'btnCloseProject
        '
        Me.btnCloseProject.Location = New System.Drawing.Point(3, 0)
        Me.btnCloseProject.Name = "btnCloseProject"
        Me.btnCloseProject.R_ConductorGridSource = Nothing
        Me.btnCloseProject.R_ConductorSource = Nothing
        Me.btnCloseProject.R_DescriptionId = Nothing
        Me.btnCloseProject.R_ResourceId = "btnCloseProject"
        Me.btnCloseProject.Size = New System.Drawing.Size(110, 24)
        Me.btnCloseProject.TabIndex = 0
        Me.btnCloseProject.Text = "R_RadButton1"
        '
        'preSession
        '
        Me.preSession.R_ConductorGridSource = Me.conGridProject
        Me.preSession.R_ConductorSource = Nothing
        Me.preSession.R_CopyAccess = False
        Me.preSession.R_DockIndex = 0
        Me.preSession.R_EnableHASDATA = True
        Me.preSession.R_HeaderTitle = ""
        '
        'CSM00500
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CSM00500"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCustomerName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCustomerCode, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lupCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.rdbCustom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.rdbStandard, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvProject.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvProject, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        CType(Me.btnCloseProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource
    Friend WithEvents bsVersion As System.Windows.Forms.BindingSource
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents cboVersion As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents lblVersion As R_FrontEnd.R_RadLabel
    Friend WithEvents cboApplication As R_FrontEnd.R_RadDropDownList
    Friend WithEvents gvProject As R_FrontEnd.R_RadGridView
    Friend WithEvents bsGvProject As System.Windows.Forms.BindingSource
    Friend WithEvents conGridProject As R_FrontEnd.R_ConductorGrid
    Friend WithEvents preSession As R_FrontEnd.R_PredefinedDock
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents btnCloseProject As R_FrontEnd.R_RadButton
    Friend WithEvents rdbCustom As R_FrontEnd.R_RadRadioButton
    Friend WithEvents rdbStandard As R_FrontEnd.R_RadRadioButton
    Friend WithEvents lblCustomer As R_FrontEnd.R_RadLabel
    Friend WithEvents txtCustomerName As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtCustomerCode As R_FrontEnd.R_RadTextBox
    Friend WithEvents lupCustomer As R_FrontEnd.R_LookUp

End Class
