﻿Imports R_Common
Imports R_BackEnd

Public Class CSI00100Cls

    Public Function GetProjectStatus(poKey As CSI00100ParamDTO) As List(Of CSI00100ProjectStatusDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSI00100ProjectStatusDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "EXEC RSP_Project_Status '{0}', '{1}', '{2}', '{3}', '{4}', '{5}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID, .CUSER_ID, .COPTION)
            End With
            loResult = loDb.SqlExecObjectQuery(Of CSI00100ProjectStatusDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetActionLog(poKey As CSI00100ParamDTO) As List(Of CSI00100ActionLogDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSI00100ActionLogDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "EXEC RSP_Project_Status_Action_Log '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID, .CSESSION_ID, _
                                        .CSCHEDULE_ID, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CITEM_ID, .CFUNCTION_ID)
            End With
            loResult = loDb.SqlExecObjectQuery(Of CSI00100ActionLogDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function
End Class
