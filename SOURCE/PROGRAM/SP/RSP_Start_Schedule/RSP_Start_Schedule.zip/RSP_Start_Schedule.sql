/****** Object:  StoredProcedure [dbo].[RSP_Start_Schedule]    Script Date: 9/22/2014 3:54:01 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSP_Start_Schedule]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSP_Start_Schedule]
GO

/****** Object:  StoredProcedure [dbo].[RSP_Start_Schedule]    Script Date: 9/22/2014 3:54:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Anov Mailoa
-- Create date: 30 March 2017
-- Description:	RSP_Start_Schedule - To start schedule
-- =============================================
CREATE PROCEDURE [dbo].[RSP_Start_Schedule] 
	@CCOMPANY_ID VARCHAR(8),
	@CAPPS_CODE VARCHAR(20),
	@CVERSION VARCHAR(15),
	@CPROJECT_ID VARCHAR(20),
	@CSESSION_ID VARCHAR(20),
	@CSCHEDULE_ID VARCHAR(20),
	@CUSER_ID VARCHAR(8),
	@CERR_NO VARCHAR(50) OUTPUT,
	@CERR_MSG VARCHAR(100) OUTPUT
WITH RECOMPILE, ENCRYPTION
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @ICOUNT AS INTEGER,
		@CCHECK_CODE AS VARCHAR(50)

	-- validation
	-- Schedule bisa dimulai jika session juga sudah dimulai
	SELECT @CCHECK_CODE = CSTATUS
	FROM CSM_PROJECT_SESSIONS (NOLOCK)
	WHERE CCOMPANY_ID = @CCOMPANY_ID
	AND CAPPS_CODE = @CAPPS_CODE
	AND CVERSION = @CVERSION
	AND CPROJECT_ID = @CPROJECT_ID
	AND CSESSION_ID = @CSESSION_ID
	IF RTRIM(@CCHECK_CODE) = 'NEW' BEGIN
		SELECT @CERR_NO = 'RSP_Start_Schedule_E002',
			@CERR_MSG = 'Session must be started first.'
		RETURN
	END
	-- Schedule bisa dimulai jika sudah ada assignment, minimal 1 record
	SELECT @ICOUNT = COUNT(CPLAN_START_DATE) - 
		SUM(CASE WHEN CREASSIGNMENT_ID = '' OR CLOCATION_ID = '' OR CPLAN_START_DATE = '' THEN 1 ELSE 0 END)
	FROM CST_PROJECT_ASSIGNMENT (NOLOCK)
	WHERE CCOMPANY_ID = @CCOMPANY_ID
	AND CAPPS_CODE = @CAPPS_CODE
	AND CVERSION = @CVERSION
	AND CPROJECT_ID = @CPROJECT_ID
	AND CSESSION_ID = @CSESSION_ID
	AND CSCHEDULE_ID = @CSCHEDULE_ID
	IF @ICOUNT = 0 BEGIN
		SELECT @CERR_NO = 'RSP_Start_Schedule_E001',
			@CERR_MSG = 'Schedule must be properly assigned. Please check project assignment for this schedule.'
		RETURN
	END

	-- start schedule
	UPDATE CST_PROJECT_SCHEDULE 
    SET 
    CSTATUS = 'START', 
    CUPDATE_BY = @CUSER_ID, 
    DUPDATE_DATE = GETDATE() 
    WHERE CCOMPANY_ID = @CCOMPANY_ID 
    AND CAPPS_CODE = @CAPPS_CODE 
    AND CVERSION = @CVERSION 
    AND CPROJECT_ID = @CPROJECT_ID 
    AND CSESSION_ID = @CSESSION_ID 
    AND CSCHEDULE_ID = @CSCHEDULE_ID 
    AND CSTATUS = 'PLAN' 

	UPDATE CST_PROJECT_ASSIGNMENT 
    SET 
    CSTATUS = 'START', 
    CUPDATE_BY = @CUSER_ID, 
    DUPDATE_DATE = GETDATE() 
    WHERE CCOMPANY_ID = @CCOMPANY_ID 
    AND CAPPS_CODE = @CAPPS_CODE 
    AND CVERSION = @CVERSION 
    AND CPROJECT_ID = @CPROJECT_ID 
    AND CSESSION_ID = @CSESSION_ID 
    AND CSCHEDULE_ID = @CSCHEDULE_ID 
	AND CREASSIGNMENT_ID <> ''
	AND CLOCATION_ID <> ''
    AND CPLAN_START_DATE <> '' 
    AND CSTATUS = 'PLAN' 

	SELECT @CERR_MSG = 'OK'
	RETURN
END
GO
