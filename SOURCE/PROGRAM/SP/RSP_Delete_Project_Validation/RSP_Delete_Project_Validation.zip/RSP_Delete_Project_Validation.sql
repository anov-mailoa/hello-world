/****** Object:  StoredProcedure [dbo].[RSP_Delete_Project_Validation]    Script Date: 9/22/2014 3:54:01 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSP_Delete_Project_Validation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSP_Delete_Project_Validation]
GO

/****** Object:  StoredProcedure [dbo].[RSP_Delete_Project_Validation]    Script Date: 9/22/2014 3:54:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Anov Mailoa
-- Create date: 23 November 2016
-- Description:	RSP_Delete_Project_Validation - To validate project removal
-- =============================================
CREATE PROCEDURE [dbo].[RSP_Delete_Project_Validation] 
	@CCOMPANY_ID VARCHAR(8),
	@CAPPS_CODE VARCHAR(20),
	@CVERSION VARCHAR(15),
	@CPROJECT_ID VARCHAR(20),
	@CRET_MSG VARCHAR(50) OUTPUT
WITH RECOMPILE, ENCRYPTION
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @CVALID_CODE AS VARCHAR(100)

	-- check if there are any session
	SELECT TOP 1 @CVALID_CODE = CSESSION_ID
	FROM CSM_PROJECT_SESSIONS (NOLOCK)
	WHERE CCOMPANY_ID = @CCOMPANY_ID
	AND CAPPS_CODE = @CAPPS_CODE
	AND CVERSION = @CVERSION
	AND CPROJECT_ID = @CPROJECT_ID
	IF @CVALID_CODE IS NOT NULL BEGIN
		-- last version has not been released
		SELECT @CRET_MSG = 'SESSION_EXISTS'
		RETURN
	END

	SELECT @CRET_MSG = 'OK'
	RETURN
END
GO
