/****** Object:  StoredProcedure [dbo].[RSP_Get_Session_Combo]    Script Date: 9/22/2014 3:54:01 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSP_Get_Session_Combo]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSP_Get_Session_Combo]
GO

/****** Object:  StoredProcedure [dbo].[RSP_Get_Session_Combo]    Script Date: 9/22/2014 3:54:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Anov Mailoa
-- Create date: 14 February 2017
-- Description:	RSP_Get_Session_Combo - To display session combo
-- =============================================
CREATE PROCEDURE [dbo].[RSP_Get_Session_Combo] 
	@CCOMPANY_ID VARCHAR(8),
	@CAPPS_CODE VARCHAR(20),
	@CVERSION VARCHAR(15),
	@CPROJECT_ID VARCHAR(20),
	@CSTATUS VARCHAR(20)
WITH RECOMPILE, ENCRYPTION
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SELECT A.CSESSION_ID, A.CSTATUS, 
    RTRIM(A.CSESSION_ID) + ' - '  + RTRIM(B.CSCHEDULE_TYPE_NAME) 
		+ CASE WHEN RTRIM(A.CNOTE) = '' THEN '' ELSE ' - ' + dbo.RFN_Truncate_With_Ellipsis(A.CNOTE, 20) END AS CSESSION_AND_STATUS
    FROM CSM_PROJECT_SESSIONS A (NOLOCK)
	JOIN CSM_SCHEDULE_TYPE B
	ON B.CSCHEDULE_TYPE = A.CINIT_SCHEDULE_TYPE
    WHERE A.CCOMPANY_ID = @CCOMPANY_ID
    AND A.CAPPS_CODE = @CAPPS_CODE
    AND A.CVERSION = @CVERSION
    AND A.CPROJECT_ID = @CPROJECT_ID
	AND (@CSTATUS = '*' OR A.CSTATUS = @CSTATUS)

END
GO
