/****** Object:  StoredProcedure [dbo].[RSP_Get_Item_Combo]    Script Date: 9/22/2014 3:54:01 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSP_Get_Item_Combo]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSP_Get_Item_Combo]
GO

/****** Object:  StoredProcedure [dbo].[RSP_Get_Item_Combo]    Script Date: 9/22/2014 3:54:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Anov Mailoa
-- Create date: 6 December 2016
-- Description:	RSP_Get_Item_Combo - To display item combo
-- =============================================
CREATE PROCEDURE [dbo].[RSP_Get_Item_Combo] 
	@CCOMPANY_ID VARCHAR(8),
	@CAPPS_CODE VARCHAR(20),
	@CATTRIBUTE_GROUP VARCHAR(20),
	@CATTRIBUTE_ID VARCHAR(20)
WITH RECOMPILE, ENCRYPTION
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- create item table
	DECLARE @TITEMS AS TABLE (
		CITEM_ID VARCHAR(30),
		CITEM_NAME NVARCHAR(75),
		LSPEC BIT
	)

	-- Designs
	IF @CATTRIBUTE_GROUP = 'DESIGN'
		INSERT INTO @TITEMS
		SELECT CITEM_ID = CDOCUMENT_ID, CITEM_NAME = RTRIM(CDOCUMENT_ID) + ' - ' + RTRIM(CDOCUMENT_NAME),
			LSPEC = 1
		FROM CSM_DESIGNS 
		WHERE CCOMPANY_ID = @CCOMPANY_ID
		AND CAPPS_CODE = @CAPPS_CODE
		AND CATTRIBUTE_GROUP = @CATTRIBUTE_GROUP
		AND CATTRIBUTE_ID = @CATTRIBUTE_ID

	-- Programs
	IF @CATTRIBUTE_GROUP = 'PROGRAM'
		INSERT INTO @TITEMS
		SELECT CITEM_ID = CPROGRAM_ID, CITEM_NAME = RTRIM(CPROGRAM_ID) + ' - ' + RTRIM(CPROGRAM_NAME),
			LSPEC = LSPEC
		FROM CSM_PROGRAMS 
		WHERE CCOMPANY_ID = @CCOMPANY_ID
		AND CAPPS_CODE = @CAPPS_CODE
		AND CATTRIBUTE_GROUP = @CATTRIBUTE_GROUP
		AND CATTRIBUTE_ID = @CATTRIBUTE_ID

	SELECT *
	FROM @TITEMS

END
GO
