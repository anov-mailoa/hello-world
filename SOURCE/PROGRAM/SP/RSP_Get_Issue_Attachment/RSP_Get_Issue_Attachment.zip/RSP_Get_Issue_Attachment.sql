/****** Object:  StoredProcedure [dbo].[RSP_Get_Issue_Attachment]    Script Date: 9/22/2014 3:54:01 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSP_Get_Issue_Attachment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSP_Get_Issue_Attachment]
GO

/****** Object:  StoredProcedure [dbo].[RSP_Get_Issue_Attachment]    Script Date: 9/22/2014 3:54:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Anov Mailoa
-- Create date: 3 November 2016
-- Description:	RSP_Get_Issue_Attachment - To get issue attachment file byte
-- =============================================
CREATE PROCEDURE [dbo].[RSP_Get_Issue_Attachment] 
	@CCOMPANY_ID VARCHAR(8),
	@CAPPS_CODE VARCHAR(20),
	@CVERSION VARCHAR(15),
	@CPROJECT_ID VARCHAR(20),
	@CSESSION_ID VARCHAR(20),
	@CFUNCTION_ID VARCHAR(20),
	@CATTRIBUTE_GROUP VARCHAR(20),
    @CATTRIBUTE_ID VARCHAR(20),
    @CITEM_ID VARCHAR(30),
	@CISSUE_ID VARCHAR(20)
WITH RECOMPILE, ENCRYPTION
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @CRELATIVE_PATH AS VARCHAR(MAX)

	SELECT @CRELATIVE_PATH = '\' + RTRIM(@CCOMPANY_ID) + '\' + RTRIM(@CAPPS_CODE) + '\' + RTRIM(@CVERSION) + '\' +
	RTRIM(@CATTRIBUTE_GROUP) + '\' + RTRIM(@CATTRIBUTE_ID) + '\'
	SELECT @CRELATIVE_PATH = @CRELATIVE_PATH + 'ISSUE\' + RTRIM(@CITEM_ID) + '\' + RTRIM(@CISSUE_ID) + '\'

    SELECT A.CFILE_NAME AS CSOURCE_ID,
	@CRELATIVE_PATH AS CFILE_PATH, 
    A.OBINARY_FILE_DATA AS OFILE_BYTE
    FROM CST_ISSUES_ATTACH A (NOLOCK)
    WHERE A.CCOMPANY_ID = @CCOMPANY_ID
    AND A.CAPPS_CODE = @CAPPS_CODE
    AND A.CVERSION = @CVERSION
	AND A.CPROJECT_ID = @CPROJECT_ID
	AND A.CSESSION_ID = @CSESSION_ID
    AND A.CATTRIBUTE_GROUP = @CATTRIBUTE_GROUP
    AND A.CATTRIBUTE_ID = @CATTRIBUTE_ID
    AND A.CITEM_ID = @CITEM_ID
	AND A.CISSUE_ID = @CISSUE_ID

END
GO
