/****** Object:  StoredProcedure [dbo].[RSP_Close_Schedule]    Script Date: 9/22/2014 3:54:01 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSP_Close_Schedule]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSP_Close_Schedule]
GO

/****** Object:  StoredProcedure [dbo].[RSP_Close_Schedule]    Script Date: 9/22/2014 3:54:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Anov Mailoa
-- Create date: 7 April 2017
-- Description:	RSP_Close_Schedule - To close schedule
-- =============================================
CREATE PROCEDURE [dbo].[RSP_Close_Schedule] 
	@CCOMPANY_ID VARCHAR(8),
	@CAPPS_CODE VARCHAR(20),
	@CVERSION VARCHAR(15),
	@CPROJECT_ID VARCHAR(20),
	@CSESSION_ID VARCHAR(20),
	@CSCHEDULE_ID VARCHAR(20),
	@CUSER_ID VARCHAR(8),
	@CERR_NO VARCHAR(50) OUTPUT,
	@CERR_MSG VARCHAR(100) OUTPUT
WITH RECOMPILE, ENCRYPTION
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @ICOUNT AS INTEGER

	-- validation
	-- Schedule bisa diakhiri jika semua process sudah selesai dilakukan (cek actual end date)
	SELECT @ICOUNT = SUM(CASE WHEN CACTUAL_END_DATE = '' THEN 1 ELSE 0 END)
	FROM CST_PROJECT_ASSIGNMENT (NOLOCK)
	WHERE CCOMPANY_ID = @CCOMPANY_ID
	AND CAPPS_CODE = @CAPPS_CODE
	AND CVERSION = @CVERSION
	AND CPROJECT_ID = @CPROJECT_ID
	AND CSESSION_ID = @CSESSION_ID
	AND CSCHEDULE_ID = @CSCHEDULE_ID
	IF @ICOUNT > 0 BEGIN
		SELECT @CERR_NO = 'RSP_Close_Schedule_E001',
			@CERR_MSG = 'Schedule must be done to the last process.'
		RETURN
	END

	-- close schedule
	UPDATE CST_PROJECT_SCHEDULE 
    SET 
    CSTATUS = 'CLOSED', 
    CUPDATE_BY = @CUSER_ID, 
    DUPDATE_DATE = GETDATE() 
    WHERE CCOMPANY_ID = @CCOMPANY_ID 
    AND CAPPS_CODE = @CAPPS_CODE 
    AND CVERSION = @CVERSION 
    AND CPROJECT_ID = @CPROJECT_ID 
    AND CSESSION_ID = @CSESSION_ID 
    AND CSCHEDULE_ID = @CSCHEDULE_ID 
    AND CSTATUS = 'START' 

	UPDATE CST_PROJECT_ASSIGNMENT 
    SET 
    CSTATUS = 'DONE', 
    CUPDATE_BY = @CUSER_ID, 
    DUPDATE_DATE = GETDATE() 
    WHERE CCOMPANY_ID = @CCOMPANY_ID 
    AND CAPPS_CODE = @CAPPS_CODE 
    AND CVERSION = @CVERSION 
    AND CPROJECT_ID = @CPROJECT_ID 
    AND CSESSION_ID = @CSESSION_ID 
    AND CSCHEDULE_ID = @CSCHEDULE_ID 
    AND CACTUAL_END_DATE <> '' 

	SELECT @CERR_MSG = 'OK'
	RETURN
END
GO
