/****** Object:  StoredProcedure [dbo].[RSP_Session_Validation]    Script Date: 9/22/2014 3:54:01 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSP_Session_Validation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSP_Session_Validation]
GO

/****** Object:  StoredProcedure [dbo].[RSP_Session_Validation]    Script Date: 9/22/2014 3:54:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Anov Mailoa
-- Create date: 15 August 2016
-- Description:	RSP_Session_Validation - To validate session action
-- =============================================
CREATE PROCEDURE [dbo].[RSP_Session_Validation] 
	@CCOMPANY_ID VARCHAR(8),
	@CAPPS_CODE VARCHAR(20),
	@CVERSION VARCHAR(15),
	@CPROJECT_ID VARCHAR(20),
	@CSESSION_ID VARCHAR(20),
	@CSCHEDULE_ID VARCHAR(20),
	@CATTRIBUTE_GROUP VARCHAR(20),
    @CATTRIBUTE_ID VARCHAR(20),
    @CITEM_ID VARCHAR(50),
	@CACTION VARCHAR(30)
WITH RECOMPILE, ENCRYPTION
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @ICOUNT AS INTEGER,
		@CCHECK_CODE AS VARCHAR(MAX)
	DECLARE @TRETURN AS TABLE (
		CMESSAGE_CODE VARCHAR(50),
		CDESCRIPTION VARCHAR(200))

	IF @CACTION = 'CLOSE' BEGIN
		-- Session bisa di-close setelah status ON-PROGRESS
		SELECT @ICOUNT = COUNT(CSESSION_ID)
		FROM CSM_PROJECT_SESSIONS
		WHERE CCOMPANY_ID = @CCOMPANY_ID
		AND CAPPS_CODE = @CAPPS_CODE
		AND CVERSION = @CVERSION
		AND CPROJECT_ID = @CPROJECT_ID
		AND CSESSION_ID = @CSESSION_ID
		AND CSTATUS = 'ON-PROGRESS'
		IF @ICOUNT = 0 BEGIN
			INSERT INTO @TRETURN
			VALUES ('RSP_Session_Validation_E001', 'Session ' + RTRIM(@CSESSION_ID) + ' status is not ON-PROGRESS.')
		END
		ELSE BEGIN
			-- Pastikan tidak ada schedule yang belum closed
			SELECT @ICOUNT = COUNT(CSCHEDULE_ID)
			FROM CST_PROJECT_SCHEDULE
			WHERE CCOMPANY_ID = @CCOMPANY_ID
			AND CAPPS_CODE = @CAPPS_CODE
			AND CVERSION = @CVERSION
			AND CPROJECT_ID = @CPROJECT_ID
			AND CSESSION_ID = @CSESSION_ID
			AND CSTATUS <> 'CLOSED'
			IF @ICOUNT > 0 BEGIN
				INSERT INTO @TRETURN
				VALUES ('RSP_Session_Validation_E010', 'All schedules must be closed first. Please check project schedule.')
			END
			ELSE BEGIN
				-- Session bisa di-close hanya jika semua program yang harus melalui QC sudah berstatus QCCI

				SELECT @ICOUNT = COUNT(CITEM_ID)
				FROM CSM_PROJECT_PROGRAMS
				WHERE CCOMPANY_ID = @CCOMPANY_ID
				AND CAPPS_CODE = @CAPPS_CODE
				AND CVERSION = @CVERSION
				AND CPROJECT_ID = @CPROJECT_ID
				AND CSESSION_ID = @CSESSION_ID
				AND ((CATTRIBUTE_GROUP = 'DESIGN' AND CSPEC_STATUS <> 'DSGCI')
					OR (CATTRIBUTE_GROUP = 'PROGRAM' AND CSTATUS <> 'QCCI'))

				IF @ICOUNT > 0 BEGIN
					INSERT INTO @TRETURN
					VALUES ('RSP_Session_Validation_E002', 'Some program in session ' + RTRIM(@CSESSION_ID) + ' are not completely designed or fully tested.')
				END
			END
		END
	END
	IF @CACTION = 'ADD_ITEM' BEGIN
		-- Program bisa ditambahkan pada new session hanya jika session belum closed
		SELECT @CCHECK_CODE = CSTATUS
		FROM CSM_PROJECT_SESSIONS (NOLOCK)
		WHERE CCOMPANY_ID = @CCOMPANY_ID
		AND CAPPS_CODE = @CAPPS_CODE
		AND CVERSION = @CVERSION
		AND CPROJECT_ID = @CPROJECT_ID
		AND CSESSION_ID = @CSESSION_ID
		IF RTRIM(@CCHECK_CODE) = 'CLOSED' BEGIN
			INSERT INTO @TRETURN
			VALUES ('RSP_Session_Validation_E011', 'Session ' + RTRIM(@CSESSION_ID) + ' has been closed.')
		END
		ELSE BEGIN
			SET @CCHECK_CODE = ''
			-- Program bisa ditambahkan pada new session hanya jika di session project yang lain sudah closed
			SELECT @CCHECK_CODE = 'Project: ' + RTRIM(A.CPROJECT_ID) + '|Session: ' + RTRIM(A.CSESSION_ID) + '|Status: ' + RTRIM(B.CSTATUS)
			FROM CSM_PROJECT_PROGRAMS A
			JOIN CSM_PROJECT_SESSIONS B
			ON B.CCOMPANY_ID = A.CCOMPANY_ID
			AND B.CAPPS_CODE = A.CAPPS_CODE
			AND B.CVERSION = A.CVERSION
			AND B.CPROJECT_ID = A.CPROJECT_ID
			AND B.CSESSION_ID = A.CSESSION_ID
			WHERE A.CCOMPANY_ID = @CCOMPANY_ID
			AND A.CAPPS_CODE = @CAPPS_CODE
			AND A.CVERSION = @CVERSION
			AND A.CPROJECT_ID <> @CPROJECT_ID
			AND A.CATTRIBUTE_GROUP = @CATTRIBUTE_GROUP
			AND A.CATTRIBUTE_ID = @CATTRIBUTE_ID
			AND A.CITEM_ID = @CITEM_ID
			AND B.CSTATUS <> 'CLOSED'

			IF @CCHECK_CODE <> '' BEGIN
				INSERT INTO @TRETURN
				VALUES ('RSP_Session_Validation_E003', 'Item ' + RTRIM(@CITEM_ID) + ' is in another project (' + RTRIM(@CCHECK_CODE) + ').')
			END
			ELSE BEGIN
				SET @CCHECK_CODE = ''
				-- Program bisa ditambahkan pada new session hanya jika di session yang lain sudah closed
				SELECT @CCHECK_CODE = 'Project: ' + RTRIM(A.CPROJECT_ID) + '|Session: ' + RTRIM(A.CSESSION_ID) + '|Status: ' + RTRIM(B.CSTATUS)
				FROM CSM_PROJECT_PROGRAMS A
				JOIN CSM_PROJECT_SESSIONS B
				ON B.CCOMPANY_ID = A.CCOMPANY_ID
				AND B.CAPPS_CODE = A.CAPPS_CODE
				AND B.CVERSION = A.CVERSION
				AND B.CPROJECT_ID = A.CPROJECT_ID
				AND B.CSESSION_ID = A.CSESSION_ID
				WHERE A.CCOMPANY_ID = @CCOMPANY_ID
				AND A.CAPPS_CODE = @CAPPS_CODE
				AND A.CVERSION = @CVERSION
				AND A.CPROJECT_ID = @CPROJECT_ID
				AND A.CSESSION_ID <> @CSESSION_ID
				AND A.CATTRIBUTE_GROUP = @CATTRIBUTE_GROUP
				AND A.CATTRIBUTE_ID = @CATTRIBUTE_ID
				AND A.CITEM_ID = @CITEM_ID
				AND B.CSTATUS <> 'CLOSED'

				IF @CCHECK_CODE <> '' BEGIN
					INSERT INTO @TRETURN
					VALUES ('RSP_Session_Validation_E003', 'Item ' + RTRIM(@CITEM_ID) + ' is in another session (' + RTRIM(@CCHECK_CODE) + ').')
				END
			END
		END
	END
	IF @CACTION = 'DELETE_ITEM' BEGIN
		SELECT @CCHECK_CODE = CSTATUS
		FROM CSM_PROJECT_SESSIONS
		WHERE CCOMPANY_ID = @CCOMPANY_ID
		AND CAPPS_CODE = @CAPPS_CODE
		AND CVERSION = @CVERSION
		AND CPROJECT_ID = @CPROJECT_ID
		AND CSESSION_ID = @CSESSION_ID
		IF @CCHECK_CODE = 'CLOSED' BEGIN
			INSERT INTO @TRETURN
			VALUES ('RSP_Session_Validation_E006', 'Session ' + RTRIM(@CSESSION_ID) + ' status is CLOSED.')
		END
		ELSE BEGIN
			SELECT @ICOUNT = COUNT(CITEM_ID)
			FROM CSM_PROJECT_PROGRAMS 
			WHERE CCOMPANY_ID = @CCOMPANY_ID
			AND CAPPS_CODE = @CAPPS_CODE
			AND CVERSION = @CVERSION
			AND CPROJECT_ID = @CPROJECT_ID
			AND CSESSION_ID = @CSESSION_ID
			AND CATTRIBUTE_GROUP = @CATTRIBUTE_GROUP
			AND CATTRIBUTE_ID = @CATTRIBUTE_ID
			AND CITEM_ID = @CITEM_ID
			AND CSTATUS <> 'NEW'
			IF @ICOUNT > 0 BEGIN
				INSERT INTO @TRETURN
				VALUES ('RSP_Session_Validation_E007', 'Program ' + RTRIM(@CITEM_ID) + ' in this session is already being processed.')
			END

		END
	END
	IF @CACTION = 'START' BEGIN
		-- Session bisa dimulai hanya jika sudah ada item untuk session ini
		SELECT @ICOUNT = COUNT(CITEM_ID)
		FROM CSM_PROJECT_PROGRAMS A
		WHERE A.CCOMPANY_ID = @CCOMPANY_ID
		AND A.CAPPS_CODE = @CAPPS_CODE
		AND A.CVERSION = @CVERSION
		AND A.CPROJECT_ID = @CPROJECT_ID
		AND A.CSESSION_ID = @CSESSION_ID
		IF @ICOUNT = 0 BEGIN
			INSERT INTO @TRETURN
			VALUES ('RSP_Session_Validation_E004', 'There is no items assigned for this session.')
		END
		ELSE BEGIN
			-- Session bisa dimulai hanya jika schedule sudah start
			--SELECT @ICOUNT = COUNT(CSCHEDULE_ID)
			--FROM CST_PROJECT_SCHEDULE A
			--WHERE A.CCOMPANY_ID = @CCOMPANY_ID
			--AND A.CAPPS_CODE = @CAPPS_CODE
			--AND A.CVERSION = @CVERSION
			--AND A.CPROJECT_ID = @CPROJECT_ID
			--AND A.CSESSION_ID = @CSESSION_ID
			--AND A.CSTATUS <> 'START'

			--IF @ICOUNT > 0 BEGIN
			--	INSERT INTO @TRETURN
			--	VALUES ('RSP_Session_Validation_E005', 'Session must be properly scheduled. Please check project schedule for this session.')
			--END
			--ELSE BEGIN

			-- Session tidak bisa di-start setelah status START
			SELECT @ICOUNT = COUNT(CSESSION_ID)
			FROM CSM_PROJECT_SESSIONS
			WHERE CCOMPANY_ID = @CCOMPANY_ID
			AND CAPPS_CODE = @CAPPS_CODE
			AND CVERSION = @CVERSION
			AND CPROJECT_ID = @CPROJECT_ID
			AND CSESSION_ID = @CSESSION_ID
			AND CSTATUS <> 'NEW'
			IF @ICOUNT = 1 BEGIN
				INSERT INTO @TRETURN
				VALUES ('RSP_Session_Validation_E008', 'Session ' + RTRIM(@CSESSION_ID) + ' has already been started.')
			END
			--END
		END
	END

	IF @CACTION = 'START_SCHEDULE' BEGIN
		-- Schedule bisa dimulai hanya jika sudah ada assignment, minimal 1 record
		SELECT @ICOUNT = COUNT(CPLAN_START_DATE) - SUM(CASE WHEN CPLAN_START_DATE = '' THEN 1 ELSE 0 END)
		FROM CST_PROJECT_ASSIGNMENT (NOLOCK)
		WHERE CCOMPANY_ID = @CCOMPANY_ID
		AND CAPPS_CODE = @CAPPS_CODE
		AND CVERSION = @CVERSION
		AND CPROJECT_ID = @CPROJECT_ID
		AND CSESSION_ID = @CSESSION_ID
		AND CSCHEDULE_ID = @CSCHEDULE_ID
		IF @ICOUNT = 0 BEGIN
			INSERT INTO @TRETURN
			VALUES ('RSP_Session_Validation_E009', 'Schedule must be properly assigned. Please check project assignment for this schedule.')
		END
	END

	IF @CACTION = 'DELETE' BEGIN
		-- Session bisa dihapus jika status = NEW
		SELECT @CCHECK_CODE = CSTATUS
		FROM CSM_PROJECT_SESSIONS (NOLOCK)
		WHERE CCOMPANY_ID = @CCOMPANY_ID
		AND CAPPS_CODE = @CAPPS_CODE
		AND CVERSION = @CVERSION
		AND CPROJECT_ID = @CPROJECT_ID
		AND CSESSION_ID = @CSESSION_ID
		IF RTRIM(@CCHECK_CODE) <> 'NEW' BEGIN
			INSERT INTO @TRETURN
			VALUES ('RSP_Session_Validation_E013', 'Session ' + RTRIM(@CSESSION_ID) + ' is not NEW.')
		END
		ELSE BEGIN
			-- Session bisa dihapus jika belum ada item untuk session ini
			SELECT @ICOUNT = COUNT(CITEM_ID)
			FROM CSM_PROJECT_PROGRAMS A
			WHERE A.CCOMPANY_ID = @CCOMPANY_ID
			AND A.CAPPS_CODE = @CAPPS_CODE
			AND A.CVERSION = @CVERSION
			AND A.CPROJECT_ID = @CPROJECT_ID
			AND A.CSESSION_ID = @CSESSION_ID
			IF @ICOUNT > 0 BEGIN
				INSERT INTO @TRETURN
				VALUES ('RSP_Session_Validation_E012', 'There are items assigned for this session.')
			END
		END
	END

	IF @CACTION = 'CHECK_INIT_SCHEDULE' BEGIN
		SET @CCHECK_CODE = ''
		-- Program bisa ditambahkan pada new session hanya jika initial schedule belum closed
		SELECT @CCHECK_CODE = RTRIM(A.CSTATUS)
		FROM CST_PROJECT_SCHEDULE A (NOLOCK)
		RIGHT JOIN CSM_PROJECT_SESSIONS B (NOLOCK)
		ON B.CCOMPANY_ID = A.CCOMPANY_ID
		AND B.CAPPS_CODE = A.CAPPS_CODE
		AND B.CVERSION = A.CVERSION
		AND B.CPROJECT_ID = A.CPROJECT_ID
		AND B.CSESSION_ID = A.CSESSION_ID
		AND B.CINIT_SCHEDULE_TYPE = A.CSCHEDULE_TYPE
		WHERE B.CCOMPANY_ID = @CCOMPANY_ID
		AND B.CAPPS_CODE = @CAPPS_CODE
		AND B.CVERSION = @CVERSION
		AND B.CPROJECT_ID = @CPROJECT_ID
		AND B.CSESSION_ID = @CSESSION_ID
		IF @CCHECK_CODE = 'CLOSED' BEGIN
			INSERT INTO @TRETURN
			VALUES ('RSP_Session_Validation_E014', 'Initial schedule status for session ' + RTRIM(@CSESSION_ID) + ' is CLOSED.')
		END
	END

	SELECT * FROM @TRETURN
END
GO
