/****** Object:  StoredProcedure [dbo].[RSP_Get_Version_Combo]    Script Date: 9/22/2014 3:54:01 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSP_Get_Version_Combo]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSP_Get_Version_Combo]
GO

/****** Object:  StoredProcedure [dbo].[RSP_Get_Version_Combo]    Script Date: 9/22/2014 3:54:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Anov Mailoa
-- Create date: 21 November 2016
-- Description:	RSP_Get_Version_Combo - To display version combo
-- =============================================
CREATE PROCEDURE [dbo].[RSP_Get_Version_Combo] 
	@CCOMPANY_ID VARCHAR(8),
	@CAPPS_CODE VARCHAR(20)
WITH RECOMPILE, ENCRYPTION
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SELECT CVERSION, 
	RTRIM(CVERSION) + CASE WHEN RTRIM(CCODE_NAME) = '' THEN '' ELSE ' - ' + RTRIM(CCODE_NAME) END AS CCODE_NAME 
	FROM RVT_APP_VERSION (NOLOCK)
	WHERE CCOMPANY_ID = @CCOMPANY_ID
	AND CAPPS_CODE = @CAPPS_CODE
	AND CSTATUS <> 'CLOSED'
	ORDER BY CMAJOR DESC, CMINOR DESC

END
GO
