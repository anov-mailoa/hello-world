/****** Object:  StoredProcedure [dbo].[RSP_Get_Schedule_ID]    Script Date: 9/22/2014 3:54:01 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSP_Get_Schedule_ID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSP_Get_Schedule_ID]
GO

/****** Object:  StoredProcedure [dbo].[RSP_Get_Schedule_ID]    Script Date: 9/22/2014 3:54:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Anov Mailoa
-- Create date: 20 January 2017
-- Description:	RSP_Get_Schedule_ID - To get schedule ID
-- =============================================
CREATE PROCEDURE [dbo].[RSP_Get_Schedule_ID] 
	@CCOMPANY_ID VARCHAR(8),
	@CAPPS_CODE VARCHAR(20),
	@CVERSION VARCHAR(15),
	@CPROJECT_ID VARCHAR(20),
	@CSESSION_ID VARCHAR(20),
	@CSCHEDULE_ID VARCHAR(20) OUTPUT
WITH RECOMPILE, ENCRYPTION
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @INO_OF_SCHEDULE AS INTEGER,
		@CDATE AS VARCHAR(8)

	SELECT @INO_OF_SCHEDULE = COUNT(CSCHEDULE_ID) + 1
	FROM CST_PROJECT_SCHEDULE (NOLOCK)
	WHERE CCOMPANY_ID = @CCOMPANY_ID
	AND CAPPS_CODE = @CAPPS_CODE
	AND CVERSION = @CVERSION
	AND CPROJECT_ID = @CPROJECT_ID
	AND CSESSION_ID = @CSESSION_ID

	SET @CDATE = CONVERT(VARCHAR(8), GETDATE(), 112)

	SELECT @CSCHEDULE_ID = 'SCH' + @CDATE + RIGHT('000000000' + RTRIM(CONVERT(VARCHAR(9), @INO_OF_SCHEDULE)), 9)

	-- Result
	RETURN
END
GO
