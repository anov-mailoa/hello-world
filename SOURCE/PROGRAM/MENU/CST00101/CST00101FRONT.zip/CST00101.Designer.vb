﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CST00101
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewCheckBoxSelectColumn1 As R_FrontEnd.R_GridViewCheckBoxSelectColumn = New R_FrontEnd.R_GridViewCheckBoxSelectColumn()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn6 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn7 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn8 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn9 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn10 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn11 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn12 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn2 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn3 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn4 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn13 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDecimalColumn1 As R_FrontEnd.R_GridViewDecimalColumn = New R_FrontEnd.R_GridViewDecimalColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblCustom = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblCustomer = New R_FrontEnd.R_RadLabel(Me.components)
        Me.btnRefresh = New R_FrontEnd.R_RadButton(Me.components)
        Me.txtAttributeGroup = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtFunction = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtProject = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtVersion = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtApplication = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.btnFilter = New R_FrontEnd.R_PopUp(Me.components)
        Me.conGridInbox = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.lblAttributeGroup = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblFunction = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblProject = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblVersion = New R_FrontEnd.R_RadLabel(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnRestore = New R_FrontEnd.R_PopUp(Me.components)
        Me.btnBackup = New R_FrontEnd.R_PopUp(Me.components)
        Me.btnSpecCheckOut = New R_FrontEnd.R_RadButton(Me.components)
        Me.btnCancelCheckOut = New R_FrontEnd.R_RadButton(Me.components)
        Me.btnCheckOut = New R_FrontEnd.R_RadButton(Me.components)
        Me.btnCheckIn = New R_FrontEnd.R_RadButton(Me.components)
        Me.gvInbox = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvInbox = New System.Windows.Forms.BindingSource(Me.components)
        Me.preIssues = New R_FrontEnd.R_PredefinedDock(Me.components)
        Me.daInboxNotification = New Telerik.WinControls.UI.RadDesktopAlert(Me.components)
        Me.bsFunction = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsProject = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsVersion = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.lblCustom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnRefresh, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtAttributeGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtFunction, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnFilter, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridInbox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblAttributeGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblFunction, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.btnRestore, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnBackup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnSpecCheckOut, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnCancelCheckOut, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnCheckOut, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnCheckIn, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvInbox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvInbox.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvInbox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsFunction, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.gvInbox, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 120.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lblCustom)
        Me.Panel1.Controls.Add(Me.lblCustomer)
        Me.Panel1.Controls.Add(Me.btnRefresh)
        Me.Panel1.Controls.Add(Me.txtAttributeGroup)
        Me.Panel1.Controls.Add(Me.txtFunction)
        Me.Panel1.Controls.Add(Me.txtProject)
        Me.Panel1.Controls.Add(Me.txtVersion)
        Me.Panel1.Controls.Add(Me.txtApplication)
        Me.Panel1.Controls.Add(Me.btnFilter)
        Me.Panel1.Controls.Add(Me.lblAttributeGroup)
        Me.Panel1.Controls.Add(Me.lblFunction)
        Me.Panel1.Controls.Add(Me.lblProject)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Controls.Add(Me.lblVersion)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 114)
        Me.Panel1.TabIndex = 0
        '
        'lblCustom
        '
        Me.lblCustom.AutoSize = False
        Me.lblCustom.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustom.Location = New System.Drawing.Point(521, 61)
        Me.lblCustom.Name = "lblCustom"
        Me.lblCustom.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustom.R_ResourceId = ""
        Me.lblCustom.Size = New System.Drawing.Size(100, 18)
        Me.lblCustom.TabIndex = 62
        Me.lblCustom.Text = "Application..."
        '
        'lblCustomer
        '
        Me.lblCustomer.AutoSize = False
        Me.lblCustomer.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustomer.Location = New System.Drawing.Point(9, 35)
        Me.lblCustomer.Name = "lblCustomer"
        Me.lblCustomer.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustomer.R_ResourceId = "lblCustomer"
        Me.lblCustomer.Size = New System.Drawing.Size(100, 18)
        Me.lblCustomer.TabIndex = 61
        Me.lblCustomer.Text = "Application..."
        '
        'btnRefresh
        '
        Me.btnRefresh.Location = New System.Drawing.Point(637, 6)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.R_ConductorGridSource = Nothing
        Me.btnRefresh.R_ConductorSource = Nothing
        Me.btnRefresh.R_DescriptionId = Nothing
        Me.btnRefresh.R_ResourceId = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(110, 24)
        Me.btnRefresh.TabIndex = 60
        Me.btnRefresh.Text = "R_RadButton1"
        '
        'txtAttributeGroup
        '
        Me.txtAttributeGroup.Location = New System.Drawing.Point(453, 86)
        Me.txtAttributeGroup.Name = "txtAttributeGroup"
        Me.txtAttributeGroup.R_ConductorGridSource = Nothing
        Me.txtAttributeGroup.R_ConductorSource = Nothing
        Me.txtAttributeGroup.R_UDT = Nothing
        Me.txtAttributeGroup.ReadOnly = True
        Me.txtAttributeGroup.Size = New System.Drawing.Size(200, 20)
        Me.txtAttributeGroup.TabIndex = 59
        Me.txtAttributeGroup.TabStop = False
        '
        'txtFunction
        '
        Me.txtFunction.Location = New System.Drawing.Point(115, 86)
        Me.txtFunction.Name = "txtFunction"
        Me.txtFunction.R_ConductorGridSource = Nothing
        Me.txtFunction.R_ConductorSource = Nothing
        Me.txtFunction.R_UDT = Nothing
        Me.txtFunction.ReadOnly = True
        Me.txtFunction.Size = New System.Drawing.Size(200, 20)
        Me.txtFunction.TabIndex = 58
        Me.txtFunction.TabStop = False
        '
        'txtProject
        '
        Me.txtProject.Location = New System.Drawing.Point(115, 60)
        Me.txtProject.Name = "txtProject"
        Me.txtProject.R_ConductorGridSource = Nothing
        Me.txtProject.R_ConductorSource = Nothing
        Me.txtProject.R_UDT = Nothing
        Me.txtProject.ReadOnly = True
        Me.txtProject.Size = New System.Drawing.Size(400, 20)
        Me.txtProject.TabIndex = 53
        Me.txtProject.TabStop = False
        '
        'txtVersion
        '
        Me.txtVersion.Location = New System.Drawing.Point(115, 34)
        Me.txtVersion.Name = "txtVersion"
        Me.txtVersion.R_ConductorGridSource = Nothing
        Me.txtVersion.R_ConductorSource = Nothing
        Me.txtVersion.R_UDT = Nothing
        Me.txtVersion.ReadOnly = True
        Me.txtVersion.Size = New System.Drawing.Size(200, 20)
        Me.txtVersion.TabIndex = 52
        Me.txtVersion.TabStop = False
        '
        'txtApplication
        '
        Me.txtApplication.Location = New System.Drawing.Point(115, 8)
        Me.txtApplication.Name = "txtApplication"
        Me.txtApplication.R_ConductorGridSource = Nothing
        Me.txtApplication.R_ConductorSource = Nothing
        Me.txtApplication.R_UDT = Nothing
        Me.txtApplication.ReadOnly = True
        Me.txtApplication.Size = New System.Drawing.Size(400, 20)
        Me.txtApplication.TabIndex = 51
        Me.txtApplication.TabStop = False
        '
        'btnFilter
        '
        Me.btnFilter.Location = New System.Drawing.Point(521, 6)
        Me.btnFilter.Name = "btnFilter"
        Me.btnFilter.R_ConductorGridSource = Me.conGridInbox
        Me.btnFilter.R_ConductorSource = Nothing
        Me.btnFilter.R_DescriptionId = Nothing
        Me.btnFilter.R_EnableOTHER = True
        Me.btnFilter.R_ResourceId = "btnFilter"
        Me.btnFilter.R_Title = "Inbox Filter"
        Me.btnFilter.Size = New System.Drawing.Size(110, 24)
        Me.btnFilter.TabIndex = 42
        Me.btnFilter.Text = "R_PopUp1"
        '
        'conGridInbox
        '
        Me.conGridInbox.R_ConductorParent = Nothing
        Me.conGridInbox.R_IsHeader = True
        Me.conGridInbox.R_RadGroupBox = Nothing
        '
        'lblAttributeGroup
        '
        Me.lblAttributeGroup.AutoSize = False
        Me.lblAttributeGroup.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblAttributeGroup.Location = New System.Drawing.Point(357, 87)
        Me.lblAttributeGroup.Name = "lblAttributeGroup"
        Me.lblAttributeGroup.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblAttributeGroup.R_ResourceId = "lblAttributeGroup"
        Me.lblAttributeGroup.Size = New System.Drawing.Size(100, 18)
        Me.lblAttributeGroup.TabIndex = 39
        Me.lblAttributeGroup.Text = "R_RadLabel1"
        '
        'lblFunction
        '
        Me.lblFunction.AutoSize = False
        Me.lblFunction.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblFunction.Location = New System.Drawing.Point(9, 87)
        Me.lblFunction.Name = "lblFunction"
        Me.lblFunction.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblFunction.R_ResourceId = "lblFunction"
        Me.lblFunction.Size = New System.Drawing.Size(100, 18)
        Me.lblFunction.TabIndex = 37
        Me.lblFunction.Text = "Application..."
        '
        'lblProject
        '
        Me.lblProject.AutoSize = False
        Me.lblProject.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblProject.Location = New System.Drawing.Point(9, 61)
        Me.lblProject.Name = "lblProject"
        Me.lblProject.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblProject.R_ResourceId = "lblProject"
        Me.lblProject.Size = New System.Drawing.Size(100, 18)
        Me.lblProject.TabIndex = 33
        Me.lblProject.Text = "Application..."
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 30
        Me.lblApplication.Text = "Application..."
        '
        'lblVersion
        '
        Me.lblVersion.AutoSize = False
        Me.lblVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblVersion.Location = New System.Drawing.Point(9, 35)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblVersion.R_ResourceId = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(100, 18)
        Me.lblVersion.TabIndex = 32
        Me.lblVersion.Text = "Application..."
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.btnRestore)
        Me.Panel2.Controls.Add(Me.btnBackup)
        Me.Panel2.Controls.Add(Me.btnSpecCheckOut)
        Me.Panel2.Controls.Add(Me.btnCancelCheckOut)
        Me.Panel2.Controls.Add(Me.btnCheckOut)
        Me.Panel2.Controls.Add(Me.btnCheckIn)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 542)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1271, 30)
        Me.Panel2.TabIndex = 1
        '
        'btnRestore
        '
        Me.btnRestore.Location = New System.Drawing.Point(589, 3)
        Me.btnRestore.Name = "btnRestore"
        Me.btnRestore.R_ConductorGridSource = Nothing
        Me.btnRestore.R_ConductorSource = Nothing
        Me.btnRestore.R_DescriptionId = Nothing
        Me.btnRestore.R_ResourceId = "btnRestore"
        Me.btnRestore.R_Title = "Restore"
        Me.btnRestore.Size = New System.Drawing.Size(110, 24)
        Me.btnRestore.TabIndex = 10
        Me.btnRestore.Text = "Restore"
        '
        'btnBackup
        '
        Me.btnBackup.Location = New System.Drawing.Point(473, 3)
        Me.btnBackup.Name = "btnBackup"
        Me.btnBackup.R_ConductorGridSource = Nothing
        Me.btnBackup.R_ConductorSource = Nothing
        Me.btnBackup.R_DescriptionId = Nothing
        Me.btnBackup.R_ResourceId = "btnBackup"
        Me.btnBackup.R_Title = "Backup Note"
        Me.btnBackup.Size = New System.Drawing.Size(110, 24)
        Me.btnBackup.TabIndex = 9
        Me.btnBackup.Text = "Backup"
        '
        'btnSpecCheckOut
        '
        Me.btnSpecCheckOut.Location = New System.Drawing.Point(125, 3)
        Me.btnSpecCheckOut.Name = "btnSpecCheckOut"
        Me.btnSpecCheckOut.R_ConductorGridSource = Me.conGridInbox
        Me.btnSpecCheckOut.R_ConductorSource = Nothing
        Me.btnSpecCheckOut.R_DescriptionId = Nothing
        Me.btnSpecCheckOut.R_EnableHASDATA = True
        Me.btnSpecCheckOut.R_ResourceId = "btnSpecCheckOut"
        Me.btnSpecCheckOut.Size = New System.Drawing.Size(110, 24)
        Me.btnSpecCheckOut.TabIndex = 8
        Me.btnSpecCheckOut.Text = "Check-Out"
        '
        'btnCancelCheckOut
        '
        Me.btnCancelCheckOut.Location = New System.Drawing.Point(357, 3)
        Me.btnCancelCheckOut.Name = "btnCancelCheckOut"
        Me.btnCancelCheckOut.R_ConductorGridSource = Me.conGridInbox
        Me.btnCancelCheckOut.R_ConductorSource = Nothing
        Me.btnCancelCheckOut.R_DescriptionId = Nothing
        Me.btnCancelCheckOut.R_EnableHASDATA = True
        Me.btnCancelCheckOut.R_ResourceId = "btnCancelCheckOut"
        Me.btnCancelCheckOut.Size = New System.Drawing.Size(110, 24)
        Me.btnCancelCheckOut.TabIndex = 5
        Me.btnCancelCheckOut.Text = "Cancel CO"
        '
        'btnCheckOut
        '
        Me.btnCheckOut.Location = New System.Drawing.Point(9, 3)
        Me.btnCheckOut.Name = "btnCheckOut"
        Me.btnCheckOut.R_ConductorGridSource = Me.conGridInbox
        Me.btnCheckOut.R_ConductorSource = Nothing
        Me.btnCheckOut.R_DescriptionId = Nothing
        Me.btnCheckOut.R_EnableHASDATA = True
        Me.btnCheckOut.R_ResourceId = "btnCheckOut"
        Me.btnCheckOut.Size = New System.Drawing.Size(110, 24)
        Me.btnCheckOut.TabIndex = 4
        Me.btnCheckOut.Text = "Check-Out"
        '
        'btnCheckIn
        '
        Me.btnCheckIn.Location = New System.Drawing.Point(241, 3)
        Me.btnCheckIn.Name = "btnCheckIn"
        Me.btnCheckIn.R_ConductorGridSource = Me.conGridInbox
        Me.btnCheckIn.R_ConductorSource = Nothing
        Me.btnCheckIn.R_DescriptionId = Nothing
        Me.btnCheckIn.R_EnableHASDATA = True
        Me.btnCheckIn.R_ResourceId = "btnCheckIn"
        Me.btnCheckIn.Size = New System.Drawing.Size(110, 24)
        Me.btnCheckIn.TabIndex = 3
        Me.btnCheckIn.Text = "Check-In"
        '
        'gvInbox
        '
        Me.gvInbox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvInbox.EnableFastScrolling = True
        Me.gvInbox.Location = New System.Drawing.Point(3, 123)
        '
        '
        '
        Me.gvInbox.MasterTemplate.AllowAddNewRow = False
        Me.gvInbox.MasterTemplate.AllowDeleteRow = False
        Me.gvInbox.MasterTemplate.AutoGenerateColumns = False
        R_GridViewCheckBoxSelectColumn1.EditMode = Telerik.WinControls.UI.EditMode.OnValueChange
        R_GridViewCheckBoxSelectColumn1.EnableHeaderCheckBox = True
        R_GridViewCheckBoxSelectColumn1.FieldName = "LSELECT"
        R_GridViewCheckBoxSelectColumn1.HeaderText = ""
        R_GridViewCheckBoxSelectColumn1.Name = "_LSELECT"
        R_GridViewCheckBoxSelectColumn1.R_EnableEDIT = True
        R_GridViewCheckBoxSelectColumn1.R_ResourceId = ""
        R_GridViewCheckBoxSelectColumn1.Width = 33
        R_GridViewTextBoxColumn1.FieldName = "CSESSION_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CSESSION_ID"
        R_GridViewTextBoxColumn1.Name = "_CSESSION_ID"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CSESSION_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 93
        R_GridViewTextBoxColumn2.FieldName = "CSCHEDULE_ID"
        R_GridViewTextBoxColumn2.HeaderText = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn2.Name = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 103
        R_GridViewTextBoxColumn3.FieldName = "CATTRIBUTE_ID"
        R_GridViewTextBoxColumn3.HeaderText = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn3.Name = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 104
        R_GridViewTextBoxColumn4.FieldName = "CITEM_ID"
        R_GridViewTextBoxColumn4.HeaderText = "_CITEM_ID"
        R_GridViewTextBoxColumn4.Name = "_CITEM_ID"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CITEM_ID"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 74
        R_GridViewTextBoxColumn5.FieldName = "CITEM_NAME"
        R_GridViewTextBoxColumn5.HeaderText = "_CITEM_NAME"
        R_GridViewTextBoxColumn5.Name = "_CITEM_NAME"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CITEM_NAME"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 95
        R_GridViewTextBoxColumn6.FieldName = "CITEM_STATUS"
        R_GridViewTextBoxColumn6.HeaderText = "_CITEM_STATUS"
        R_GridViewTextBoxColumn6.Name = "_CITEM_STATUS"
        R_GridViewTextBoxColumn6.R_ResourceId = "_CITEM_STATUS"
        R_GridViewTextBoxColumn6.R_UDT = Nothing
        R_GridViewTextBoxColumn6.Width = 102
        R_GridViewTextBoxColumn7.FieldName = "CLAST_ACTION"
        R_GridViewTextBoxColumn7.HeaderText = "_CLAST_ACTION"
        R_GridViewTextBoxColumn7.Name = "_CLAST_ACTION"
        R_GridViewTextBoxColumn7.R_ResourceId = "_CLAST_ACTION"
        R_GridViewTextBoxColumn7.R_UDT = Nothing
        R_GridViewTextBoxColumn7.Width = 103
        R_GridViewTextBoxColumn8.FieldName = "CLAST_ACTION_BY"
        R_GridViewTextBoxColumn8.HeaderText = "_CLAST_ACTION_BY"
        R_GridViewTextBoxColumn8.Name = "_CLAST_ACTION_BY"
        R_GridViewTextBoxColumn8.R_ResourceId = "_CLAST_ACTION_BY"
        R_GridViewTextBoxColumn8.R_UDT = Nothing
        R_GridViewTextBoxColumn8.Width = 121
        R_GridViewTextBoxColumn9.FieldName = "CSPEC_STATUS"
        R_GridViewTextBoxColumn9.HeaderText = "_CSPEC_STATUS"
        R_GridViewTextBoxColumn9.Name = "_CSPEC_STATUS"
        R_GridViewTextBoxColumn9.R_ResourceId = "_CSPEC_STATUS"
        R_GridViewTextBoxColumn9.R_UDT = Nothing
        R_GridViewTextBoxColumn9.Width = 103
        R_GridViewTextBoxColumn10.FieldName = "CLAST_SPEC_ACTION"
        R_GridViewTextBoxColumn10.HeaderText = "_CLAST_SPEC_ACTION"
        R_GridViewTextBoxColumn10.Name = "_CLAST_SPEC_ACTION"
        R_GridViewTextBoxColumn10.R_ResourceId = "_CLAST_SPEC_ACTION"
        R_GridViewTextBoxColumn10.R_UDT = Nothing
        R_GridViewTextBoxColumn10.Width = 133
        R_GridViewTextBoxColumn11.FieldName = "CLAST_SPEC_ACTION_BY"
        R_GridViewTextBoxColumn11.HeaderText = "_CLAST_SPEC_ACTION_BY"
        R_GridViewTextBoxColumn11.Name = "_CLAST_SPEC_ACTION_BY"
        R_GridViewTextBoxColumn11.R_ResourceId = "_CLAST_SPEC_ACTION_BY"
        R_GridViewTextBoxColumn11.R_UDT = Nothing
        R_GridViewTextBoxColumn11.Width = 151
        R_GridViewTextBoxColumn12.FieldName = "CCURRENT_SCHEDULE_ID"
        R_GridViewTextBoxColumn12.HeaderText = "_CCURRENT_SCHEDULE_ID"
        R_GridViewTextBoxColumn12.Name = "_CCURRENT_SCHEDULE_ID"
        R_GridViewTextBoxColumn12.R_ResourceId = "_CCURRENT_SCHEDULE_ID"
        R_GridViewTextBoxColumn12.R_UDT = Nothing
        R_GridViewTextBoxColumn12.Width = 156
        R_GridViewDateTimeColumn1.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn1.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn1.FieldName = "DPLAN_START_DATE"
        R_GridViewDateTimeColumn1.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn1.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn1.HeaderText = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn1.Name = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn1.R_ResourceId = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn1.Width = 131
        R_GridViewDateTimeColumn2.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn2.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn2.FieldName = "DPLAN_END_DATE"
        R_GridViewDateTimeColumn2.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn2.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn2.HeaderText = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn2.Name = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn2.R_ResourceId = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn2.Width = 121
        R_GridViewDateTimeColumn3.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn3.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn3.FieldName = "DREVISED_START_DATE"
        R_GridViewDateTimeColumn3.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn3.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn3.HeaderText = "_DREVISED_START_DATE"
        R_GridViewDateTimeColumn3.Name = "_DREVISED_START_DATE"
        R_GridViewDateTimeColumn3.R_ResourceId = "_DREVISED_START_DATE"
        R_GridViewDateTimeColumn3.Width = 145
        R_GridViewDateTimeColumn4.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn4.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn4.FieldName = "DREVISED_END_DATE"
        R_GridViewDateTimeColumn4.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn4.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn4.HeaderText = "_DREVISED_END_DATE"
        R_GridViewDateTimeColumn4.Name = "_DREVISED_END_DATE"
        R_GridViewDateTimeColumn4.R_ResourceId = "_DREVISED_END_DATE"
        R_GridViewDateTimeColumn4.Width = 136
        R_GridViewTextBoxColumn13.FieldName = "CASSIGNMENT_STATUS"
        R_GridViewTextBoxColumn13.HeaderText = "_CASSIGNMENT_STATUS"
        R_GridViewTextBoxColumn13.Name = "_CASSIGNMENT_STATUS"
        R_GridViewTextBoxColumn13.R_ResourceId = "_CASSIGNMENT_STATUS"
        R_GridViewTextBoxColumn13.R_UDT = Nothing
        R_GridViewTextBoxColumn13.Width = 147
        R_GridViewDecimalColumn1.DataType = GetType(Integer)
        R_GridViewDecimalColumn1.DecimalPlaces = 0
        R_GridViewDecimalColumn1.FieldName = "NISSUES"
        R_GridViewDecimalColumn1.FormatString = "{0:N}"
        R_GridViewDecimalColumn1.HeaderText = "_NISSUES"
        R_GridViewDecimalColumn1.Name = "_NISSUES"
        R_GridViewDecimalColumn1.R_ResourceId = "_NISSUES"
        R_GridViewDecimalColumn1.ThousandsSeparator = True
        R_GridViewDecimalColumn1.Width = 70
        Me.gvInbox.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewCheckBoxSelectColumn1, R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewTextBoxColumn4, R_GridViewTextBoxColumn5, R_GridViewTextBoxColumn6, R_GridViewTextBoxColumn7, R_GridViewTextBoxColumn8, R_GridViewTextBoxColumn9, R_GridViewTextBoxColumn10, R_GridViewTextBoxColumn11, R_GridViewTextBoxColumn12, R_GridViewDateTimeColumn1, R_GridViewDateTimeColumn2, R_GridViewDateTimeColumn3, R_GridViewDateTimeColumn4, R_GridViewTextBoxColumn13, R_GridViewDecimalColumn1})
        Me.gvInbox.MasterTemplate.DataSource = Me.bsGvInbox
        Me.gvInbox.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvInbox.MasterTemplate.EnableFiltering = True
        Me.gvInbox.MasterTemplate.EnableGrouping = False
        Me.gvInbox.MasterTemplate.EnableSorting = False
        Me.gvInbox.MasterTemplate.ShowFilteringRow = False
        Me.gvInbox.MasterTemplate.ShowGroupedColumns = True
        Me.gvInbox.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvInbox.Name = "gvInbox"
        Me.gvInbox.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvInbox.R_ConductorGridSource = Me.conGridInbox
        Me.gvInbox.R_ConductorSource = Nothing
        Me.gvInbox.R_DataAdded = False
        Me.gvInbox.R_NewRowText = Nothing
        Me.gvInbox.ShowHeaderCellButtons = True
        Me.gvInbox.Size = New System.Drawing.Size(1271, 413)
        Me.gvInbox.TabIndex = 2
        Me.gvInbox.Text = "R_RadGridView1"
        '
        'bsGvInbox
        '
        Me.bsGvInbox.DataSource = GetType(CST00101Front.CST00101StreamingServiceRef.CST00101ItemInboxDTO)
        '
        'preIssues
        '
        Me.preIssues.R_ConductorGridSource = Me.conGridInbox
        Me.preIssues.R_ConductorSource = Nothing
        Me.preIssues.R_CopyAccess = False
        Me.preIssues.R_DockIndex = 0
        Me.preIssues.R_EnableHASDATA = True
        Me.preIssues.R_HeaderTitle = ""
        '
        'daInboxNotification
        '
        Me.daInboxNotification.AutoClose = False
        Me.daInboxNotification.AutoCloseDelay = 30
        Me.daInboxNotification.CaptionText = "RealCode To-Do Alert"
        Me.daInboxNotification.FixedSize = New System.Drawing.Size(500, 250)
        Me.daInboxNotification.IsPinned = True
        Me.daInboxNotification.Opacity = 1.0!
        Me.daInboxNotification.ShowOptionsButton = False
        Me.daInboxNotification.ThemeName = ""
        '
        'bsApps
        '
        Me.bsApps.DataSource = GetType(CST00101Front.CST00101ServiceRef.RLicenseAppComboDTO)
        '
        'CST00101
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CST00101"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.lblCustom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnRefresh, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtAttributeGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtFunction, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnFilter, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridInbox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblAttributeGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblFunction, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        CType(Me.btnRestore, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnBackup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnSpecCheckOut, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnCancelCheckOut, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnCheckOut, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnCheckIn, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvInbox.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvInbox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvInbox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsFunction, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource
    Friend WithEvents bsVersion As System.Windows.Forms.BindingSource
    Friend WithEvents bsProject As System.Windows.Forms.BindingSource
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents lblProject As R_FrontEnd.R_RadLabel
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents lblVersion As R_FrontEnd.R_RadLabel
    Friend WithEvents gvInbox As R_FrontEnd.R_RadGridView
    Friend WithEvents conGridInbox As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsGvInbox As System.Windows.Forms.BindingSource
    Friend WithEvents btnCheckIn As R_FrontEnd.R_RadButton
    Friend WithEvents btnCheckOut As R_FrontEnd.R_RadButton
    Friend WithEvents lblFunction As R_FrontEnd.R_RadLabel
    Friend WithEvents bsFunction As System.Windows.Forms.BindingSource
    Friend WithEvents lblAttributeGroup As R_FrontEnd.R_RadLabel
    Friend WithEvents btnCancelCheckOut As R_FrontEnd.R_RadButton
    Friend WithEvents preIssues As R_FrontEnd.R_PredefinedDock
    Friend WithEvents btnFilter As R_FrontEnd.R_PopUp
    Friend WithEvents txtProject As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtVersion As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtApplication As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtAttributeGroup As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtFunction As R_FrontEnd.R_RadTextBox
    Friend WithEvents btnRefresh As R_FrontEnd.R_RadButton
    Friend WithEvents daInboxNotification As Telerik.WinControls.UI.RadDesktopAlert
    Friend WithEvents btnSpecCheckOut As R_FrontEnd.R_RadButton
    Friend WithEvents btnBackup As R_FrontEnd.R_PopUp
    Friend WithEvents btnRestore As R_FrontEnd.R_PopUp
    Friend WithEvents lblCustomer As R_FrontEnd.R_RadLabel
    Friend WithEvents lblCustom As R_FrontEnd.R_RadLabel

End Class
