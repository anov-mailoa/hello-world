﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CST00101Restore
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewCheckBoxSelectColumn1 As R_FrontEnd.R_GridViewCheckBoxSelectColumn = New R_FrontEnd.R_GridViewCheckBoxSelectColumn()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn6 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.gvItems = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsItems = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridItems = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.R_ReturnPopUp1 = New R_FrontEnd.R_ReturnPopUp()
        Me.btnCancel = New R_FrontEnd.R_RadButton(Me.components)
        Me.btnOk = New R_FrontEnd.R_RadButton(Me.components)
        Me.R_RadButton1 = New R_FrontEnd.R_RadButton(Me.components)
        Me.R_RadButton2 = New R_FrontEnd.R_RadButton(Me.components)
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        CType(Me.gvItems, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvItems.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsItems, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridItems, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_ReturnPopUp1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.R_ReturnPopUp1.SuspendLayout()
        CType(Me.btnCancel, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnOk, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadButton1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadButton2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'gvItems
        '
        Me.gvItems.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvItems.EnableFastScrolling = True
        Me.gvItems.Location = New System.Drawing.Point(3, 3)
        '
        '
        '
        Me.gvItems.MasterTemplate.AllowAddNewRow = False
        Me.gvItems.MasterTemplate.AllowDeleteRow = False
        Me.gvItems.MasterTemplate.AutoGenerateColumns = False
        R_GridViewCheckBoxSelectColumn1.EditMode = Telerik.WinControls.UI.EditMode.OnValueChange
        R_GridViewCheckBoxSelectColumn1.EnableHeaderCheckBox = True
        R_GridViewCheckBoxSelectColumn1.FieldName = "LSELECT"
        R_GridViewCheckBoxSelectColumn1.HeaderText = ""
        R_GridViewCheckBoxSelectColumn1.Name = "_LSELECT"
        R_GridViewCheckBoxSelectColumn1.R_EnableEDIT = True
        R_GridViewCheckBoxSelectColumn1.R_ResourceId = Nothing
        R_GridViewCheckBoxSelectColumn1.Width = 33
        R_GridViewTextBoxColumn1.FieldName = "CATTRIBUTE_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn1.Name = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 104
        R_GridViewTextBoxColumn2.FieldName = "CITEM_ID"
        R_GridViewTextBoxColumn2.HeaderText = "_CITEM_ID"
        R_GridViewTextBoxColumn2.Name = "_CITEM_ID"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CITEM_ID"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 74
        R_GridViewTextBoxColumn3.FieldName = "CITEM_NAME"
        R_GridViewTextBoxColumn3.HeaderText = "_CITEM_NAME"
        R_GridViewTextBoxColumn3.Name = "_CITEM_NAME"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CITEM_NAME"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 95
        R_GridViewTextBoxColumn4.FieldName = "CSOURCE_ID"
        R_GridViewTextBoxColumn4.HeaderText = "_CSOURCE_ID"
        R_GridViewTextBoxColumn4.Name = "_CSOURCE_ID"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CSOURCE_ID"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 91
        R_GridViewTextBoxColumn5.FieldName = "CBACKUP_TIME"
        R_GridViewTextBoxColumn5.HeaderText = "_CBACKUP_TIME"
        R_GridViewTextBoxColumn5.Name = "_CBACKUP_TIME"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CBACKUP_TIME"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 105
        R_GridViewTextBoxColumn6.FieldName = "CNOTE"
        R_GridViewTextBoxColumn6.HeaderText = "_CNOTE"
        R_GridViewTextBoxColumn6.Name = "_CNOTE"
        R_GridViewTextBoxColumn6.R_ResourceId = "_CNOTE"
        R_GridViewTextBoxColumn6.R_UDT = Nothing
        R_GridViewTextBoxColumn6.Width = 63
        Me.gvItems.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewCheckBoxSelectColumn1, R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewTextBoxColumn4, R_GridViewTextBoxColumn5, R_GridViewTextBoxColumn6})
        Me.gvItems.MasterTemplate.DataSource = Me.bsItems
        Me.gvItems.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvItems.MasterTemplate.EnableFiltering = True
        Me.gvItems.MasterTemplate.EnableGrouping = False
        Me.gvItems.MasterTemplate.ShowFilteringRow = False
        Me.gvItems.MasterTemplate.ShowGroupedColumns = True
        Me.gvItems.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvItems.Name = "gvItems"
        Me.gvItems.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvItems.R_ConductorGridSource = Me.conGridItems
        Me.gvItems.R_ConductorSource = Nothing
        Me.gvItems.R_DataAdded = False
        Me.gvItems.R_NewRowText = Nothing
        Me.gvItems.ShowHeaderCellButtons = True
        Me.gvItems.Size = New System.Drawing.Size(612, 253)
        Me.gvItems.TabIndex = 1
        Me.gvItems.Text = "R_RadGridView1"
        '
        'bsItems
        '
        Me.bsItems.DataSource = GetType(CST00101Front.CST00101StreamingServiceRef.RCustDBItemRestoreDTO)
        '
        'conGridItems
        '
        Me.conGridItems.R_ConductorParent = Nothing
        Me.conGridItems.R_IsHeader = True
        Me.conGridItems.R_RadGroupBox = Nothing
        '
        'R_ReturnPopUp1
        '
        Me.R_ReturnPopUp1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.R_ReturnPopUp1.Controls.Add(Me.btnCancel)
        Me.R_ReturnPopUp1.Controls.Add(Me.btnOk)
        Me.R_ReturnPopUp1.Controls.Add(Me.R_RadButton1)
        Me.R_ReturnPopUp1.Controls.Add(Me.R_RadButton2)
        Me.R_ReturnPopUp1.Location = New System.Drawing.Point(453, 262)
        Me.R_ReturnPopUp1.Name = "R_ReturnPopUp1"
        Me.R_ReturnPopUp1.Size = New System.Drawing.Size(162, 30)
        Me.R_ReturnPopUp1.TabIndex = 3
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(84, 3)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.R_ConductorGridSource = Nothing
        Me.btnCancel.R_ConductorSource = Nothing
        Me.btnCancel.R_DescriptionId = Nothing
        Me.btnCancel.R_ResourceId = Nothing
        Me.btnCancel.Size = New System.Drawing.Size(75, 23)
        Me.btnCancel.TabIndex = 1
        Me.btnCancel.Text = "Cancel"
        '
        'btnOk
        '
        Me.btnOk.Location = New System.Drawing.Point(3, 3)
        Me.btnOk.Name = "btnOk"
        Me.btnOk.R_ConductorGridSource = Nothing
        Me.btnOk.R_ConductorSource = Nothing
        Me.btnOk.R_DescriptionId = Nothing
        Me.btnOk.R_ResourceId = Nothing
        Me.btnOk.Size = New System.Drawing.Size(75, 23)
        Me.btnOk.TabIndex = 0
        Me.btnOk.Text = "OK"
        '
        'R_RadButton1
        '
        Me.R_RadButton1.Location = New System.Drawing.Point(84, 3)
        Me.R_RadButton1.Name = "R_RadButton1"
        Me.R_RadButton1.R_ConductorGridSource = Nothing
        Me.R_RadButton1.R_ConductorSource = Nothing
        Me.R_RadButton1.R_DescriptionId = Nothing
        Me.R_RadButton1.R_ResourceId = Nothing
        Me.R_RadButton1.Size = New System.Drawing.Size(75, 23)
        Me.R_RadButton1.TabIndex = 1
        Me.R_RadButton1.Text = "Cancel"
        '
        'R_RadButton2
        '
        Me.R_RadButton2.Location = New System.Drawing.Point(3, 3)
        Me.R_RadButton2.Name = "R_RadButton2"
        Me.R_RadButton2.R_ConductorGridSource = Nothing
        Me.R_RadButton2.R_ConductorSource = Nothing
        Me.R_RadButton2.R_DescriptionId = Nothing
        Me.R_RadButton2.R_ResourceId = Nothing
        Me.R_RadButton2.Size = New System.Drawing.Size(75, 23)
        Me.R_RadButton2.TabIndex = 0
        Me.R_RadButton2.Text = "OK"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.gvItems, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.R_ReturnPopUp1, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(618, 295)
        Me.TableLayoutPanel1.TabIndex = 4
        '
        'CST00101Restore
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(618, 295)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CST00101Restore"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "Restore"
        CType(Me.gvItems.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvItems, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsItems, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridItems, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_ReturnPopUp1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.R_ReturnPopUp1.ResumeLayout(False)
        CType(Me.btnCancel, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnOk, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadButton1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadButton2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents bsItems As System.Windows.Forms.BindingSource
    Friend WithEvents gvItems As R_FrontEnd.R_RadGridView
    Friend WithEvents R_ReturnPopUp1 As R_FrontEnd.R_ReturnPopUp
    Friend WithEvents btnCancel As R_FrontEnd.R_RadButton
    Friend WithEvents btnOk As R_FrontEnd.R_RadButton
    Friend WithEvents R_RadButton1 As R_FrontEnd.R_RadButton
    Friend WithEvents R_RadButton2 As R_FrontEnd.R_RadButton
    Friend WithEvents conGridItems As R_FrontEnd.R_ConductorGrid
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel

End Class
