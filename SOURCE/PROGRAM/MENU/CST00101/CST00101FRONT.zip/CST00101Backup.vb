﻿Imports CST00101Front.CST00101ServiceRef
Imports R_FrontEnd
Imports ClientHelper
Imports R_Common
Imports CST00101Front.CST00101StreamingServiceRef
Imports System.ServiceModel.Channels

Public Class CST00101Backup

#Region " VARIABLE "
    Dim C_ServiceName As String = "CST00101Service/CST00101Service.svc"
    Dim C_ServiceNameStream As String = "CST00101Service/CST00101StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim loBackupRestoreParam As New CST00101BackupRestoreDTO
#End Region

#Region " FORM Methods "

    Private Sub R_ReturnPopUp1_R_SetPopUpResult(ByRef poEntityResult As Object) Handles R_ReturnPopUp1.R_SetPopUpResult
        loBackupRestoreParam.CNOTE = txtNote.Text.Trim
        poEntityResult = loBackupRestoreParam
    End Sub

    Private Sub CST00200Backup_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim loEx As New R_Exception

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            loBackupRestoreParam = poParameter

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

End Class
