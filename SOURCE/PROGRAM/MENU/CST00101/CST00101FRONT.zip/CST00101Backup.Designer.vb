﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CST00101Backup
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.txtNote = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.R_ReturnPopUp1 = New R_FrontEnd.R_ReturnPopUp()
        Me.btnCancel = New R_FrontEnd.R_RadButton(Me.components)
        Me.btnOk = New R_FrontEnd.R_RadButton(Me.components)
        CType(Me.txtNote, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_ReturnPopUp1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.R_ReturnPopUp1.SuspendLayout()
        CType(Me.btnCancel, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnOk, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtNote
        '
        Me.txtNote.AcceptsReturn = True
        Me.txtNote.AutoSize = False
        Me.txtNote.Location = New System.Drawing.Point(12, 11)
        Me.txtNote.Multiline = True
        Me.txtNote.Name = "txtNote"
        Me.txtNote.R_ConductorGridSource = Nothing
        Me.txtNote.R_ConductorSource = Nothing
        Me.txtNote.R_UDT = Nothing
        Me.txtNote.Size = New System.Drawing.Size(386, 150)
        Me.txtNote.TabIndex = 1
        '
        'R_ReturnPopUp1
        '
        Me.R_ReturnPopUp1.Controls.Add(Me.btnCancel)
        Me.R_ReturnPopUp1.Controls.Add(Me.btnOk)
        Me.R_ReturnPopUp1.Location = New System.Drawing.Point(236, 167)
        Me.R_ReturnPopUp1.Name = "R_ReturnPopUp1"
        Me.R_ReturnPopUp1.Size = New System.Drawing.Size(162, 31)
        Me.R_ReturnPopUp1.TabIndex = 2
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(84, 3)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.R_ConductorGridSource = Nothing
        Me.btnCancel.R_ConductorSource = Nothing
        Me.btnCancel.R_DescriptionId = Nothing
        Me.btnCancel.R_ResourceId = Nothing
        Me.btnCancel.Size = New System.Drawing.Size(75, 23)
        Me.btnCancel.TabIndex = 1
        Me.btnCancel.Text = "Cancel"
        '
        'btnOk
        '
        Me.btnOk.Location = New System.Drawing.Point(3, 3)
        Me.btnOk.Name = "btnOk"
        Me.btnOk.R_ConductorGridSource = Nothing
        Me.btnOk.R_ConductorSource = Nothing
        Me.btnOk.R_DescriptionId = Nothing
        Me.btnOk.R_ResourceId = Nothing
        Me.btnOk.Size = New System.Drawing.Size(75, 23)
        Me.btnOk.TabIndex = 0
        Me.btnOk.Text = "OK"
        '
        'CST00100Backup
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(405, 202)
        Me.ControlBox = False
        Me.Controls.Add(Me.R_ReturnPopUp1)
        Me.Controls.Add(Me.txtNote)
        Me.Name = "CST00100Backup"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "Backup"
        CType(Me.txtNote, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_ReturnPopUp1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.R_ReturnPopUp1.ResumeLayout(False)
        CType(Me.btnCancel, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnOk, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents txtNote As R_FrontEnd.R_RadTextBox
    Friend WithEvents R_ReturnPopUp1 As R_FrontEnd.R_ReturnPopUp
    Friend WithEvents btnCancel As R_FrontEnd.R_RadButton
    Friend WithEvents btnOk As R_FrontEnd.R_RadButton

End Class
