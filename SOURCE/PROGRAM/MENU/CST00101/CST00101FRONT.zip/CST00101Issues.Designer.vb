﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CST00101Issues
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxMultilineColumn1 As R_FrontEnd.R_GridViewTextBoxMultilineColumn = New R_FrontEnd.R_GridViewTextBoxMultilineColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxMultilineColumn2 As R_FrontEnd.R_GridViewTextBoxMultilineColumn = New R_FrontEnd.R_GridViewTextBoxMultilineColumn()
        Dim R_GridViewTextBoxColumn6 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn1 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.gvAttachment = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvAttachment = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridAttach = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.conGridIssue = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.gvIssue = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvIssue = New System.Windows.Forms.BindingSource(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtItemName = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.R_RadLabel1 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnDownloadAttachment = New R_FrontEnd.R_RadButton(Me.components)
        Me.lblAttachmentList = New R_FrontEnd.R_RadLabel(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.gvAttachment, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvAttachment.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvAttachment, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridAttach, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvIssue.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.txtItemName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.btnDownloadAttachment, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblAttachmentList, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.gvAttachment, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.gvIssue, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 0, 2)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 4
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'gvAttachment
        '
        Me.gvAttachment.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvAttachment.EnableFastScrolling = True
        Me.gvAttachment.Location = New System.Drawing.Point(3, 478)
        '
        '
        '
        Me.gvAttachment.MasterTemplate.AllowAddNewRow = False
        Me.gvAttachment.MasterTemplate.AllowEditRow = False
        Me.gvAttachment.MasterTemplate.AutoGenerateColumns = False
        Me.gvAttachment.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn1.FieldName = "CFILE_NAME"
        R_GridViewTextBoxColumn1.HeaderText = "_CFILE_NAME"
        R_GridViewTextBoxColumn1.Name = "_CFILE_NAME"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CFILE_NAME"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 172
        R_GridViewTextBoxMultilineColumn1.FieldName = "CDESCRIPTION"
        R_GridViewTextBoxMultilineColumn1.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxMultilineColumn1.Name = "_CDESCRIPTION"
        R_GridViewTextBoxMultilineColumn1.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxMultilineColumn1.R_UDT = Nothing
        R_GridViewTextBoxMultilineColumn1.ReadOnly = True
        R_GridViewTextBoxMultilineColumn1.Width = 1080
        R_GridViewTextBoxMultilineColumn1.WrapText = True
        Me.gvAttachment.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxMultilineColumn1})
        Me.gvAttachment.MasterTemplate.DataSource = Me.bsGvAttachment
        Me.gvAttachment.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvAttachment.MasterTemplate.EnableFiltering = True
        Me.gvAttachment.MasterTemplate.EnableGrouping = False
        Me.gvAttachment.MasterTemplate.ShowFilteringRow = False
        Me.gvAttachment.MasterTemplate.ShowGroupedColumns = True
        Me.gvAttachment.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvAttachment.Name = "gvAttachment"
        Me.gvAttachment.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvAttachment.R_ConductorGridSource = Me.conGridAttach
        Me.gvAttachment.R_ConductorSource = Nothing
        Me.gvAttachment.R_DataAdded = False
        Me.gvAttachment.R_NewRowText = Nothing
        Me.gvAttachment.ReadOnly = True
        Me.gvAttachment.ShowHeaderCellButtons = True
        Me.gvAttachment.Size = New System.Drawing.Size(1271, 94)
        Me.gvAttachment.TabIndex = 3
        Me.gvAttachment.Text = "R_RadGridView1"
        '
        'bsGvAttachment
        '
        Me.bsGvAttachment.DataSource = GetType(CST00101Front.CST00101StreamingServiceRef.CST00200AttachGridDTO)
        '
        'conGridAttach
        '
        Me.conGridAttach.R_ConductorParent = Me.conGridIssue
        Me.conGridAttach.R_RadGroupBox = Nothing
        '
        'conGridIssue
        '
        Me.conGridIssue.R_ConductorParent = Nothing
        Me.conGridIssue.R_IsHeader = True
        Me.conGridIssue.R_RadGroupBox = Nothing
        '
        'gvIssue
        '
        Me.gvIssue.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gvIssue.EnableFastScrolling = True
        Me.gvIssue.Location = New System.Drawing.Point(3, 39)
        '
        '
        '
        Me.gvIssue.MasterTemplate.AllowAddNewRow = False
        Me.gvIssue.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn2.FieldName = "CISSUE_ID"
        R_GridViewTextBoxColumn2.HeaderText = "_CISSUE_ID"
        R_GridViewTextBoxColumn2.Name = "_CISSUE_ID"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CISSUE_ID"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 78
        R_GridViewTextBoxColumn3.FieldName = "CUSER_ID"
        R_GridViewTextBoxColumn3.HeaderText = "_CUSER_ID"
        R_GridViewTextBoxColumn3.Name = "_CUSER_ID"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CUSER_ID"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 76
        R_GridViewDateTimeColumn1.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn1.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn1.FieldName = "DISSUE_DATE"
        R_GridViewDateTimeColumn1.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn1.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn1.HeaderText = "_DISSUE_DATE"
        R_GridViewDateTimeColumn1.Name = "_DISSUE_DATE"
        R_GridViewDateTimeColumn1.R_ResourceId = "_DISSUE_DATE"
        R_GridViewDateTimeColumn1.Width = 95
        R_GridViewTextBoxColumn4.FieldName = "CISSUE_CLASS_DESCRIPTION"
        R_GridViewTextBoxColumn4.HeaderText = "_CISSUE_CLASS"
        R_GridViewTextBoxColumn4.Name = "_CISSUE_CLASS"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CISSUE_CLASS"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 99
        R_GridViewTextBoxColumn5.FieldName = "CISSUE_TYPE"
        R_GridViewTextBoxColumn5.HeaderText = "_CISSUE_TYPE"
        R_GridViewTextBoxColumn5.Name = "_CISSUE_TYPE"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CISSUE_TYPE"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 91
        R_GridViewTextBoxMultilineColumn2.FieldName = "CDESCRIPTION"
        R_GridViewTextBoxMultilineColumn2.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxMultilineColumn2.Name = "_CDESCRIPTION"
        R_GridViewTextBoxMultilineColumn2.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxMultilineColumn2.R_UDT = Nothing
        R_GridViewTextBoxMultilineColumn2.ReadOnly = True
        R_GridViewTextBoxMultilineColumn2.Width = 103
        R_GridViewTextBoxMultilineColumn2.WrapText = True
        R_GridViewTextBoxColumn6.FieldName = "CSCHEDULE_ID"
        R_GridViewTextBoxColumn6.HeaderText = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn6.Name = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn6.R_ResourceId = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn6.R_UDT = Nothing
        R_GridViewTextBoxColumn6.Width = 103
        R_GridViewCheckBoxColumn1.FieldName = "LSOLVED"
        R_GridViewCheckBoxColumn1.HeaderText = "_LSOLVED"
        R_GridViewCheckBoxColumn1.Name = "_LSOLVED"
        R_GridViewCheckBoxColumn1.R_EnableEDIT = True
        R_GridViewCheckBoxColumn1.R_ResourceId = "_LSOLVED"
        R_GridViewCheckBoxColumn1.Width = 88
        Me.gvIssue.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewDateTimeColumn1, R_GridViewTextBoxColumn4, R_GridViewTextBoxColumn5, R_GridViewTextBoxMultilineColumn2, R_GridViewTextBoxColumn6, R_GridViewCheckBoxColumn1})
        Me.gvIssue.MasterTemplate.DataSource = Me.bsGvIssue
        Me.gvIssue.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvIssue.MasterTemplate.EnableFiltering = True
        Me.gvIssue.MasterTemplate.EnableGrouping = False
        Me.gvIssue.MasterTemplate.ShowFilteringRow = False
        Me.gvIssue.MasterTemplate.ShowGroupedColumns = True
        Me.gvIssue.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvIssue.Name = "gvIssue"
        Me.gvIssue.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvIssue.R_ConductorGridSource = Me.conGridIssue
        Me.gvIssue.R_ConductorSource = Nothing
        Me.gvIssue.R_DataAdded = False
        Me.gvIssue.R_NewRowText = Nothing
        Me.gvIssue.ShowHeaderCellButtons = True
        Me.gvIssue.Size = New System.Drawing.Size(1271, 397)
        Me.gvIssue.TabIndex = 1
        Me.gvIssue.Text = "R_RadGridView1"
        '
        'bsGvIssue
        '
        Me.bsGvIssue.DataSource = GetType(CST00101Front.CST00101StreamingServiceRef.RCustDBIssueListDTO)
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.txtItemName)
        Me.Panel1.Controls.Add(Me.R_RadLabel1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 30)
        Me.Panel1.TabIndex = 0
        '
        'txtItemName
        '
        Me.txtItemName.Location = New System.Drawing.Point(115, 3)
        Me.txtItemName.Name = "txtItemName"
        Me.txtItemName.R_ConductorGridSource = Nothing
        Me.txtItemName.R_ConductorSource = Nothing
        Me.txtItemName.R_UDT = Nothing
        Me.txtItemName.ReadOnly = True
        Me.txtItemName.Size = New System.Drawing.Size(227, 20)
        Me.txtItemName.TabIndex = 1
        Me.txtItemName.TabStop = False
        '
        'R_RadLabel1
        '
        Me.R_RadLabel1.AutoSize = False
        Me.R_RadLabel1.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel1.Location = New System.Drawing.Point(9, 4)
        Me.R_RadLabel1.Name = "R_RadLabel1"
        Me.R_RadLabel1.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel1.R_ResourceId = "_CITEM_NAME"
        Me.R_RadLabel1.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel1.TabIndex = 0
        Me.R_RadLabel1.Text = "R_RadLabel1"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.btnDownloadAttachment)
        Me.Panel2.Controls.Add(Me.lblAttachmentList)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 442)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1271, 30)
        Me.Panel2.TabIndex = 4
        '
        'btnDownloadAttachment
        '
        Me.btnDownloadAttachment.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDownloadAttachment.Location = New System.Drawing.Point(1152, 3)
        Me.btnDownloadAttachment.Name = "btnDownloadAttachment"
        Me.btnDownloadAttachment.R_ConductorGridSource = Me.conGridAttach
        Me.btnDownloadAttachment.R_ConductorSource = Nothing
        Me.btnDownloadAttachment.R_DescriptionId = Nothing
        Me.btnDownloadAttachment.R_EnableHASDATA = True
        Me.btnDownloadAttachment.R_ResourceId = "btnDownloadAttachment"
        Me.btnDownloadAttachment.Size = New System.Drawing.Size(110, 24)
        Me.btnDownloadAttachment.TabIndex = 3
        Me.btnDownloadAttachment.Text = "R_RadButton1"
        '
        'lblAttachmentList
        '
        Me.lblAttachmentList.AutoSize = False
        Me.lblAttachmentList.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblAttachmentList.Location = New System.Drawing.Point(9, 3)
        Me.lblAttachmentList.Name = "lblAttachmentList"
        Me.lblAttachmentList.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblAttachmentList.R_ResourceId = "lblAttachmentList"
        Me.lblAttachmentList.Size = New System.Drawing.Size(100, 18)
        Me.lblAttachmentList.TabIndex = 2
        Me.lblAttachmentList.Text = "R_RadLabel1"
        '
        'CST00101Issues
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CST00101Issues"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.TableLayoutPanel1.ResumeLayout(False)
        CType(Me.gvAttachment.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvAttachment, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvAttachment, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridAttach, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridIssue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvIssue.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvIssue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvIssue, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.txtItemName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        CType(Me.btnDownloadAttachment, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblAttachmentList, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents txtItemName As R_FrontEnd.R_RadTextBox
    Friend WithEvents R_RadLabel1 As R_FrontEnd.R_RadLabel
    Friend WithEvents bsGvIssue As System.Windows.Forms.BindingSource
    Friend WithEvents gvIssue As R_FrontEnd.R_RadGridView
    Friend WithEvents bsGvAttachment As System.Windows.Forms.BindingSource
    Friend WithEvents gvAttachment As R_FrontEnd.R_RadGridView
    Friend WithEvents conGridIssue As R_FrontEnd.R_ConductorGrid
    Friend WithEvents conGridAttach As R_FrontEnd.R_ConductorGrid
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents lblAttachmentList As R_FrontEnd.R_RadLabel
    Friend WithEvents btnDownloadAttachment As R_FrontEnd.R_RadButton

End Class
