﻿Imports CST00101Front.CST00101StreamingServiceRef

<Serializable()> _
Public Class CST00101BackupRestoreDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CVERSION As String
    Public Property CPROJECT_ID As String
    Public Property CSESSION_ID As String
    Public Property CSCHEDULE_ID As String
    Public Property CATTRIBUTE_GROUP As String
    Public Property CFUNCTION_ID As String
    Public Property CNOTE As String
    Public Property ORESTORE_LIST As New List(Of RCustDBItemRestoreDTO)

End Class
