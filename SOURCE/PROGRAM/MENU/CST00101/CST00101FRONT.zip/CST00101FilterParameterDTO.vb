﻿Imports CST00101Front.CST00101ServiceRef

<Serializable()> _
Public Class CST00101FilterParameterDTO
    Public Property OFILTER_KEY As RCustDBProjectKeyDTO
    Public Property OAPPS_LIST As List(Of RLicenseAppComboDTO)
    Public Property OVERSION_LIST As List(Of RCustDBVersionComboDTO)
    Public Property OPROJECT_LIST As List(Of RCustDBProjectComboDTO)
    Public Property OSESSION_LIST As List(Of RCustDBSessionComboDTO)
    Public Property OSCHEDULE_LIST As List(Of RCustDBScheduleComboDTO)
    Public Property OFUNCTION_LIST As List(Of RCustDBFunctionComboDTO)
    Public Property OATTRIBUTE_GROUP_LIST As List(Of RCustDBAttributeGroupComboDTO)
    Public Property CAPPS_NAME As String
    Public Property CCODE_NAME As String
    Public Property CPROJECT_NAME As String
    Public Property CSESSION_STATUS As String
    Public Property CSCHEDULE_DESCRIPTION As String
    Public Property CSCHEDULE_STATUS As String
    Public Property IDESIGN_SEQUENCE As Integer
    Public Property IDEV_SEQUENCE As Integer
    Public Property IQC_SEQUENCE As Integer
    Public Property LMANAGER As Boolean
    Public Property CREFRESH_COMBO_MODE As String
    Public Property LCUSTOM As Boolean
    Public Property CVERSION As String
    Public Property CCUSTOMER_CODE As String
    Public Property CCUSTOMER_NAME As String

    Sub New()
        ' initialization
        OFILTER_KEY = New RCustDBProjectKeyDTO
        With OFILTER_KEY
            .CCOMPANY_ID = ""
            .CAPPS_CODE = ""
            .CVERSION = ""
            .CPROJECT_ID = ""
            .CSESSION_ID = ""
            .CSCHEDULE_ID = ""
            .CFUNCTION_ID = ""
            .CATTRIBUTE_GROUP = ""
            .CUSER_ID = ""
        End With
        CAPPS_NAME = ""
        CPROJECT_NAME = ""
        CSESSION_STATUS = ""
        CSCHEDULE_DESCRIPTION = ""
        CSCHEDULE_STATUS = ""
        IDESIGN_SEQUENCE = 0
        IDEV_SEQUENCE = 0
        IQC_SEQUENCE = 0
        LMANAGER = False
    End Sub
End Class
