﻿Imports CST00101Front.CST00101ServiceRef
Imports R_FrontEnd
Imports ClientHelper
Imports R_Common
Imports CST00101Front.CST00101StreamingServiceRef
Imports System.ServiceModel.Channels
Imports RCustDBFrontHelper

Public Class CST00101Filter

#Region " VARIABLE "
    Dim C_ServiceName As String = "CST00101Service/CST00101Service.svc"
    Dim C_ServiceNameStream As String = "CST00101Service/CST00101StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _LCUSTOM As Boolean
    Dim loFilterParam As New CST00101FilterParameterDTO
    Dim llRefreshCombo As Boolean
#End Region

#Region " SUBs and FUNCTIONs "

    Private Sub ComboManager(pcCode As String, pcValue As String, pcDisplay As String)
        Dim loSvc As CST00101ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00101Service, CST00101ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loProjectKey As New CST00101Front.CST00101ServiceRef.RCustDBProjectKeyDTO
        Dim lcValue As String = ""
        Dim lcDisplay As String = ""

        ' Refresh Combo
        With loProjectKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = loFilterParam.OFILTER_KEY.CAPPS_CODE
            .CVERSION = IIf(_LCUSTOM, loFilterParam.CCUSTOMER_CODE, loFilterParam.CVERSION)
            .CPROJECT_ID = loFilterParam.OFILTER_KEY.CPROJECT_ID
            .CSESSION_ID = loFilterParam.OFILTER_KEY.CSESSION_ID
            .CSTATUS = "*"
            .CUSER_ID = _CUSERID
            .LCHECK_PROJECT_MANAGER = False
        End With

        If pcValue IsNot Nothing Then
            lcValue = pcValue.Trim
        Else
            If Not pcCode.Equals("_INIT") Then
                Exit Sub
            End If
        End If
        If pcDisplay IsNot Nothing Then
            lcDisplay = pcDisplay
        End If

        With loFilterParam
            Select Case pcCode
                Case "_INIT"
                    ' initialize combo
                    cboVersion.Items.Clear()
                    cboProject.Items.Clear()
                    cboFunction.Items.Clear()
                    cboAttributeGroup.Items.Clear()
                    If .OAPPS_LIST Is Nothing Then
                        Dim loAppCombo As New List(Of RLicenseAppComboDTO)
                        loAppCombo = loSvc.GetAppCombo(_CCOMPID, _CUSERID)
                        If loAppCombo.Count <= 0 Then
                            cboApplication.Items.Clear()
                        End If
                        llRefreshCombo = True
                        bsApps.DataSource = loAppCombo
                        .OAPPS_LIST = loAppCombo
                    Else
                        llRefreshCombo = False
                        bsApps.DataSource = .OAPPS_LIST
                        cboApplication.SelectedValue = .OFILTER_KEY.CAPPS_CODE
                        rdbStandard.IsChecked = Not .LCUSTOM
                        rdbCustom.IsChecked = .LCUSTOM
                        bsVersion.DataSource = .OVERSION_LIST
                        cboVersion.SelectedValue = .CVERSION
                        txtCustomerCode.Text = .CCUSTOMER_CODE
                        txtCustomerName.Text = .CCUSTOMER_NAME
                        bsProject.DataSource = .OPROJECT_LIST
                        cboProject.SelectedValue = .OFILTER_KEY.CPROJECT_ID
                        bsSession.DataSource = .OSESSION_LIST
                        bsSchedule.DataSource = .OSCHEDULE_LIST
                        bsFunction.DataSource = .OFUNCTION_LIST
                        llRefreshCombo = True
                        cboFunction.SelectedValue = .OFILTER_KEY.CFUNCTION_ID
                        llRefreshCombo = False
                        bsAttributeGroup.DataSource = .OATTRIBUTE_GROUP_LIST
                        cboAttributeGroup.SelectedValue = .OFILTER_KEY.CATTRIBUTE_GROUP
                        llRefreshCombo = True
                    End If
                    .CREFRESH_COMBO_MODE = "NORMAL"
                Case "_CAPPS_CODE"
                    If Not lcValue.Equals(.OFILTER_KEY.CAPPS_CODE) Then
                        .OVERSION_LIST = Nothing
                        .OPROJECT_LIST = Nothing
                        .OSESSION_LIST = Nothing
                        .OSCHEDULE_LIST = Nothing
                    End If
                    If .OVERSION_LIST Is Nothing Then
                        Dim loVersionCombo As New List(Of RCustDBVersionComboDTO)
                        If .CREFRESH_COMBO_MODE = "NORMAL" Then
                            .OFILTER_KEY.CAPPS_CODE = lcValue
                        End If
                        .CAPPS_NAME = lcDisplay
                        loVersionCombo = loSvc.GetVersionCombo(_CCOMPID, .OFILTER_KEY.CAPPS_CODE)
                        If loVersionCombo.Count <= 0 Then
                            cboVersion.Items.Clear()
                            cboProject.Items.Clear()
                        End If
                        bsVersion.DataSource = loVersionCombo
                        .OVERSION_LIST = loVersionCombo
                    End If
                    If .OFILTER_KEY.CVERSION IsNot Nothing Then
                        cboVersion.SelectedValue = .OFILTER_KEY.CVERSION
                    End If
                Case "_CVERSION"
                    If Not lcValue.Equals(.OFILTER_KEY.CVERSION) Then
                        .OPROJECT_LIST = Nothing
                        .OSESSION_LIST = Nothing
                        .OSCHEDULE_LIST = Nothing
                    End If
                    If .OPROJECT_LIST Is Nothing OrElse .OPROJECT_LIST.Count = 0 Then
                        Dim loProjectCombo As New List(Of RCustDBProjectComboDTO)
                        If .CREFRESH_COMBO_MODE = "NORMAL" Then
                            .OFILTER_KEY.CVERSION = lcValue
                            loProjectKey.CVERSION = lcValue
                        End If
                        '.CCODE_NAME = lcDisplay
                        loProjectKey.CSTATUS = "*"
                        loProjectCombo = loSvc.GetProjectCombo(loProjectKey)
                        If loProjectCombo.Count <= 0 Then
                            cboProject.Items.Clear()
                        End If
                        bsProject.DataSource = loProjectCombo
                        .OPROJECT_LIST = loProjectCombo
                    End If
                    If .OFILTER_KEY.CPROJECT_ID IsNot Nothing Then
                        cboProject.SelectedValue = .OFILTER_KEY.CPROJECT_ID
                    End If
                    .LCUSTOM = _LCUSTOM
                Case "_CPROJECT_ID"
                    If Not lcValue.Equals(.OFILTER_KEY.CPROJECT_ID) Then
                        .OSESSION_LIST = Nothing
                        .OSCHEDULE_LIST = Nothing
                    End If
                    If .OPROJECT_LIST Is Nothing OrElse .OPROJECT_LIST.Count = 0 Then

                        If .CREFRESH_COMBO_MODE = "NORMAL" Then
                            .OFILTER_KEY.CPROJECT_ID = lcValue
                            loProjectKey.CPROJECT_ID = lcValue
                        End If

                        .CPROJECT_NAME = lcDisplay
                        loProjectKey.CSTATUS = "*"
                        Dim loFunctionCombo As New List(Of RCustDBFunctionComboDTO)
                        loFunctionCombo = loSvc.GetFunctionCombo(loProjectKey)
                        If loFunctionCombo.Count <= 0 Then
                            cboFunction.Items.Clear()
                        End If
                        bsFunction.DataSource = loFunctionCombo
                        .OFUNCTION_LIST = loFunctionCombo

                    End If
                    If .OFILTER_KEY.CFUNCTION_ID IsNot Nothing Then
                        cboFunction.SelectedValue = .OFILTER_KEY.CFUNCTION_ID
                    End If
                Case "_CFUNCTION_ID"
                    Select Case lcValue
                        Case "DESIGN"
                            lblAttributeGroup.Visible = True
                            cboAttributeGroup.Visible = True
                        Case Else
                            lblAttributeGroup.Visible = False
                            cboAttributeGroup.Visible = False
                    End Select
                    If .OATTRIBUTE_GROUP_LIST Is Nothing Or Not lcValue.Equals(.OFILTER_KEY.CFUNCTION_ID) Then
                        If .CREFRESH_COMBO_MODE = "NORMAL" Then
                            .OFILTER_KEY.CFUNCTION_ID = lcValue
                        End If
                        Dim loAttributeGroupCombo As New List(Of RCustDBAttributeGroupComboDTO)
                        cboAttributeGroup.Items.Clear()
                        Select Case .OFILTER_KEY.CFUNCTION_ID
                            Case "DESIGN"
                                loAttributeGroupCombo.Add(New RCustDBAttributeGroupComboDTO With {.CATTRIBUTE_GROUP = "DESIGN"})
                                loAttributeGroupCombo.Add(New RCustDBAttributeGroupComboDTO With {.CATTRIBUTE_GROUP = "PROGRAM"})
                            Case Else
                                loAttributeGroupCombo.Add(New RCustDBAttributeGroupComboDTO With {.CATTRIBUTE_GROUP = "PROGRAM"})
                                .OFILTER_KEY.CATTRIBUTE_GROUP = "PROGRAM"
                        End Select
                        bsAttributeGroup.DataSource = loAttributeGroupCombo
                        .OATTRIBUTE_GROUP_LIST = loAttributeGroupCombo
                    End If
                Case "_CATTRIBUTE_GROUP"
                    If Not lcValue.Equals(.OFILTER_KEY.CATTRIBUTE_GROUP) Then
                        .OFILTER_KEY.CATTRIBUTE_GROUP = lcValue
                    End If
            End Select
        End With
        loSvc.Close()
    End Sub

    Private Sub EnableVerCust()
        _LCUSTOM = rdbCustom.IsChecked
        lblVersion.Visible = Not _LCUSTOM
        cboVersion.Enabled = Not _LCUSTOM
        cboVersion.Visible = Not _LCUSTOM
        lblCustomer.Visible = _LCUSTOM
        txtCustomerCode.Enabled = False
        lupCustomer.Enabled = _LCUSTOM
        txtCustomerCode.Visible = _LCUSTOM
        lupCustomer.Visible = _LCUSTOM
        txtCustomerName.Visible = _LCUSTOM
    End Sub

#End Region

#Region " COMBO Actions "

    Private Sub cboApplication_Trigger(sender As Object, e As System.EventArgs) Handles cboApplication.SelectedIndexChanged
        If llRefreshCombo Then
            ComboManager("_CAPPS_CODE", sender.SelectedValue, sender.SelectedText)
        End If
    End Sub

    Private Sub cboVersion_Trigger(sender As Object, e As System.EventArgs) Handles cboVersion.SelectedIndexChanged
        If llRefreshCombo Then
            With loFilterParam
                .CVERSION = sender.SelectedValue
                .CCODE_NAME = sender.SelectedText
            End With
            ComboManager("_CVERSION", sender.SelectedValue, sender.SelectedText)
        End If
    End Sub

    Private Sub cboProject_Trigger(sender As Object, e As System.EventArgs) Handles cboProject.SelectedIndexChanged
        If llRefreshCombo Then
            ComboManager("_CPROJECT_ID", sender.SelectedValue, sender.SelectedText)
        End If
    End Sub

    Private Sub cboFunction_Trigger(sender As Object, e As Telerik.WinControls.UI.Data.PositionChangedEventArgs) Handles cboFunction.SelectedIndexChanged
        If llRefreshCombo Then
            ComboManager("_CFUNCTION_ID", sender.SelectedValue, sender.SelectedText)
        End If
    End Sub

    Private Sub cboAttributeGroup_Trigger(sender As Object, e As Telerik.WinControls.UI.Data.PositionChangedEventArgs) Handles cboAttributeGroup.SelectedIndexChanged
        If llRefreshCombo Then
            ComboManager("_CATTRIBUTE_GROUP", sender.SelectedValue, sender.SelectedText)
        End If
    End Sub

    Private Sub btnRefresh_Click(sender As System.Object, e As System.EventArgs) Handles btnRefresh.Click
        With loFilterParam
            .OAPPS_LIST = Nothing
            .OVERSION_LIST = Nothing
            .OPROJECT_LIST = Nothing
            .OSESSION_LIST = Nothing
            .OSCHEDULE_LIST = Nothing
            .OFUNCTION_LIST = Nothing
            .OATTRIBUTE_GROUP_LIST = Nothing
            .CREFRESH_COMBO_MODE = "REFRESH"
        End With
        ComboManager("_INIT", Nothing, Nothing)
    End Sub

#End Region

#Region " FORM Methods "

    Private Sub R_ReturnPopUp1_R_SetPopUpResult(ByRef poEntityResult As Object) Handles R_ReturnPopUp1.R_SetPopUpResult
        poEntityResult = loFilterParam
    End Sub

    Private Sub CST00200Filter_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim loEx As New R_Exception

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            loFilterParam = poParameter

            ComboManager("_INIT", Nothing, Nothing)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " LOOKUP Events "

    Private Sub R_LookUp1_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles lupCustomer.R_Before_Open_Form
        poTargetForm = New CustList
        poParameter = New FileStreamingServiceRef.RCustDBFileKeyDTO With {.CCOMPANY_ID = _CCOMPID}
    End Sub

    Private Sub R_LookUp1_R_Return_LookUp(poReturnObject As Object) Handles lupCustomer.R_Return_LookUp
        txtCustomerCode.Text = poReturnObject.CCUSTOMER_CODE
        txtCustomerName.Text = poReturnObject.CCUSTOMER_NAME
        With loFilterParam
            .CCUSTOMER_CODE = txtCustomerCode.Text
            .CCUSTOMER_NAME = txtCustomerName.Text
            ComboManager("_CVERSION", .CCUSTOMER_CODE, .CCUSTOMER_NAME)
        End With
    End Sub

#End Region

#Region " RADIO BUTTON Actions "

    Private Sub rdbStandard_CheckStateChanged(sender As Object, e As System.EventArgs) Handles rdbStandard.CheckStateChanged
        If CType(sender, R_RadRadioButton).IsChecked Then
            EnableVerCust()
            If llRefreshCombo Then
                ComboManager("_CVERSION", cboVersion.SelectedValue, cboVersion.SelectedText)
            End If
        End If
    End Sub

    Private Sub rdbCustom_CheckStateChanged(sender As Object, e As System.EventArgs) Handles rdbCustom.CheckStateChanged
        If CType(sender, R_RadRadioButton).IsChecked Then
            EnableVerCust()
            If llRefreshCombo Then
                ComboManager("_CVERSION", txtCustomerCode.Text, txtCustomerName.Text)
            End If
        End If
    End Sub

#End Region

End Class
