﻿Imports R_Common
Imports CST00101Front.CST00101StreamingServiceRef
Imports R_FrontEnd
Imports System.ServiceModel.Channels
Imports RCustDBFrontHelper
Imports RCustDBFrontHelper.FileServiceRef
Imports ClientHelper
Imports CST00101FrontResources
Imports CST00101Front.CST00101ServiceRef

Public Class CST00101Issues

#Region " VARIABLE "
    Dim C_ServiceName As String = "CST00101Service/CST00101Service.svc"
    Dim C_ServiceNameStream As String = "CST00101Service/CST00101StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _LREADY_TO_REFRESH As Boolean = False
    Dim _LINIT As Boolean
    Dim _CISSUE_ID As String
    Dim _OISSUE_PARAM As CST00101IssuesParamDTO
#End Region

#Region " FORM Events "

    Private Sub CST00101Issues_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim loEx As New R_Exception

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            _OISSUE_PARAM = poParameter
            txtItemName.Text = _OISSUE_PARAM.CITEM_NAME
            gvIssue.R_RefreshGrid(_OISSUE_PARAM.OISSUE_KEY)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub CST00101Issues_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " ISSUE Gridview "

    Private Sub gvIssue_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvIssue.R_Display
        Dim loEx As New R_Exception
        Dim loTableKey As New RCustDBIssueListDTO

        Try
            loTableKey = CType(bsGvIssue.Current, RCustDBIssueListDTO)
            gvAttachment.R_RefreshGrid(loTableKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

    Private Sub gvIssue_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvIssue.R_ServiceGetListRecord
        Dim loServiceStream As CST00101StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00101StreamingService, CST00101StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of RCustDBIssueListDTO)
        Dim loListEntity As New List(Of RCustDBIssueListDTO)

        Try
            With CType(poEntity, RCustDBIssueKeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
                R_Utility.R_SetStreamingContext("cProjectId", .CPROJECT_ID)
                R_Utility.R_SetStreamingContext("cSessionId", .CSESSION_ID)
                R_Utility.R_SetStreamingContext("cAttributeGroup", .CATTRIBUTE_GROUP)
                R_Utility.R_SetStreamingContext("cAttributeId", .CATTRIBUTE_ID)
                R_Utility.R_SetStreamingContext("cItemId", .CITEM_ID)
                R_Utility.R_SetStreamingContext("cScheduleId", .CSCHEDULE_ID)
                R_Utility.R_SetStreamingContext("cPrevScheduleId", "*")
            End With

            loRtn = loServiceStream.GetIssueList()
            loStreaming = R_StreamUtility(Of RCustDBIssueListDTO).ReadFromMessage(loRtn)

            For Each loDto As RCustDBIssueListDTO In loStreaming
                If loDto IsNot Nothing Then
                    loDto.DISSUE_DATE = General.StrToDate(loDto.CISSUE_DATE)
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvIssue_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvIssue.R_ServiceGetRecord
        Dim loService As CST00101ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00101Service, CST00101ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim loTempResult As New CST00200DTO

        Try
            loTempResult = loService.Svc_R_GetRecord(New CST00200DTO With {._CCOMPANY_ID = _CCOMPID,
                                                                             ._CAPPS_CODE = _OISSUE_PARAM.OISSUE_KEY.CAPPS_CODE,
                                                                             ._CVERSION = _OISSUE_PARAM.OISSUE_KEY.CVERSION,
                                                                             ._CPROJECT_ID = _OISSUE_PARAM.OISSUE_KEY.CPROJECT_ID,
                                                                             ._CSESSION_ID = _OISSUE_PARAM.OISSUE_KEY.CSESSION_ID,
                                                                             ._CATTRIBUTE_GROUP = _OISSUE_PARAM.OISSUE_KEY.CATTRIBUTE_GROUP,
                                                                             ._CATTRIBUTE_ID = _OISSUE_PARAM.OISSUE_KEY.CATTRIBUTE_ID,
                                                                             ._CITEM_ID = _OISSUE_PARAM.OISSUE_KEY.CITEM_ID,
                                                                             ._CISSUE_ID = CType(bsGvIssue.Current, RCustDBIssueListDTO).CISSUE_ID})
            poEntityResult = New RCustDBIssueListDTO With {.CCOMPANY_ID = loTempResult._CCOMPANY_ID, _
                                                           .CAPPS_CODE = loTempResult._CAPPS_CODE, _
                                                           .CVERSION = loTempResult._CVERSION, _
                                                           .CPROJECT_ID = loTempResult._CPROJECT_ID, _
                                                           .CSESSION_ID = loTempResult._CSESSION_ID, _
                                                           .CATTRIBUTE_GROUP = loTempResult._CATTRIBUTE_GROUP, _
                                                           .CATTRIBUTE_ID = loTempResult._CATTRIBUTE_ID, _
                                                           .CITEM_ID = loTempResult._CITEM_ID, _
                                                           .CISSUE_ID = loTempResult._CISSUE_ID, _
                                                           .LSOLVED = loTempResult._LSOLVED}
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvIssue_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvIssue.R_ServiceSave
        Dim loService As CST00101ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00101Service, CST00101ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String
        Dim loTempEntity As CST00200DTO
        Dim loTempResult As New CST00200DTO

        Try
            loTempEntity = New CST00200DTO With {._CCOMPANY_ID = poEntity.CCOMPANY_ID, _
                                                           ._CAPPS_CODE = poEntity.CAPPS_CODE, _
                                                           ._CVERSION = poEntity.CVERSION, _
                                                           ._CPROJECT_ID = poEntity.CPROJECT_ID, _
                                                           ._CSESSION_ID = poEntity.CSESSION_ID, _
                                                           ._CATTRIBUTE_GROUP = poEntity.CATTRIBUTE_GROUP, _
                                                           ._CATTRIBUTE_ID = poEntity.CATTRIBUTE_ID, _
                                                           ._CITEM_ID = poEntity.CITEM_ID, _
                                                           ._CISSUE_ID = poEntity.CISSUE_ID, _
                                                           ._LSOLVED = poEntity.LSOLVED}
            loTempResult = loService.Svc_R_Save(loTempEntity, peGridMode)
            poEntityResult = New RCustDBIssueListDTO With {.CCOMPANY_ID = loTempResult._CCOMPANY_ID, _
                                               .CAPPS_CODE = loTempResult._CAPPS_CODE, _
                                               .CVERSION = loTempResult._CVERSION, _
                                               .CPROJECT_ID = loTempResult._CPROJECT_ID, _
                                               .CSESSION_ID = loTempResult._CSESSION_ID, _
                                               .CATTRIBUTE_GROUP = loTempResult._CATTRIBUTE_GROUP, _
                                               .CATTRIBUTE_ID = loTempResult._CATTRIBUTE_ID, _
                                               .CITEM_ID = loTempResult._CITEM_ID, _
                                               .CISSUE_ID = loTempResult._CISSUE_ID, _
                                               .LSOLVED = loTempResult._LSOLVED}
        Catch ex As Exception
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
#End Region

#Region " ATTACHMENT Gridview "

    Private Sub gvAttachment_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvAttachment.R_ServiceGetListRecord
        Dim loServiceStream As CST00101StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00101StreamingService, CST00101StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CST00200AttachGridDTO)
        Dim loListEntity As New List(Of CST00200AttachGridDTO)

        Try
            With CType(poEntity, RCustDBIssueListDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
                R_Utility.R_SetStreamingContext("cProjectId", .CPROJECT_ID)
                R_Utility.R_SetStreamingContext("cSessionId", .CSESSION_ID)
                R_Utility.R_SetStreamingContext("cAttributeGroup", .CATTRIBUTE_GROUP)
                R_Utility.R_SetStreamingContext("cAttributeId", .CATTRIBUTE_ID)
                R_Utility.R_SetStreamingContext("cItemId", .CITEM_ID)
                R_Utility.R_SetStreamingContext("cIssueId", .CISSUE_ID)
            End With

            loRtn = loServiceStream.GetIssueAttachment()
            loStreaming = R_StreamUtility(Of CST00200AttachGridDTO).ReadFromMessage(loRtn)

            For Each loDto As CST00200AttachGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " DOWNLOAD "

    Private Sub btnDownloadAttachment_Click(sender As Object, e As System.EventArgs) Handles btnDownloadAttachment.Click
        Dim loException As New R_Exception
        Dim loFileHandler As New FileHandler
        Dim loKey As New RCustDBFileKeyDTO

        Try
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor

            With loKey
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = _OISSUE_PARAM.OISSUE_KEY.CAPPS_CODE
                .CVERSION = _OISSUE_PARAM.OISSUE_KEY.CVERSION
                .CPROJECT_ID = _OISSUE_PARAM.OISSUE_KEY.CPROJECT_ID
                .CSESSION_ID = _OISSUE_PARAM.OISSUE_KEY.CSESSION_ID
                .CATTRIBUTE_GROUP = _OISSUE_PARAM.OISSUE_KEY.CATTRIBUTE_GROUP
                .CATTRIBUTE_ID = _OISSUE_PARAM.OISSUE_KEY.CATTRIBUTE_ID
                .CITEM_ID = _OISSUE_PARAM.OISSUE_KEY.CITEM_ID
                .CISSUE_ID = CType(bsGvIssue.Current, RCustDBIssueListDTO).CISSUE_ID
                .CSEQUENCE = _OISSUE_PARAM.OISSUE_KEY.CSEQUENCE
                .CACTION = "ISSUE"
                .CUSER_ID = _CUSERID
                .CFILE_GROUP = "ISSUE"
            End With
            With loFileHandler
                .CCOMPANY_ID = _CCOMPID
                .CUSER_ID = _CUSERID
                .DownloadFile(loKey)
            End With
        Catch ex As Exception
            loException.Add(ex)
        Finally
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            MsgBox(R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "msgDone"))
        End Try
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        If loException.Haserror Then
            Me.R_DisplayException(loException)
        End If
    End Sub

#End Region


End Class

Public Class CST00101IssuesParamDTO
    Public Property CITEM_NAME As String
    Public Property OISSUE_KEY As RCustDBIssueKeyDTO
End Class