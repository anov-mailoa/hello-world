﻿Imports R_BackEnd
Imports R_Common
Imports RLicenseBack

Public Class CST00101Cls

    Public Function GetItemInbox(poKey As CST00101InboxKeyDTO) As List(Of CST00101ItemInboxDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CST00101ItemInboxDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "EXEC RSP_Item_Inbox_CST00101 '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID, .CFUNCTION_ID, .CATTRIBUTE_GROUP, .CUSER_ID)

            End With
            loResult = loDb.SqlExecObjectQuery(Of CST00101ItemInboxDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetAllFunctionCombo() As List(Of RCustDBFunctionComboDTO)
        Dim loResult As New List(Of RCustDBFunctionComboDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            ' Initialize function combo
            With loResult
                .Add(New RCustDBFunctionComboDTO With {.CFUNCTION_ID = "DESIGN", .LMANAGER = True})
                .Add(New RCustDBFunctionComboDTO With {.CFUNCTION_ID = "DEVELOPMENT", .LMANAGER = True})
                .Add(New RCustDBFunctionComboDTO With {.CFUNCTION_ID = "QC", .LMANAGER = True})
            End With

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

End Class
