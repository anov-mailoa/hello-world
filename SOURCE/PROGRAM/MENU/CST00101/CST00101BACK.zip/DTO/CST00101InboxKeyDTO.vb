﻿Public Class CST00101InboxKeyDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CVERSION As String
    Public Property CPROJECT_ID As String
    Public Property CFUNCTION_ID As String
    Public Property CSESSION_ID As String
    Public Property CSCHEDULE_ID As String
    Public Property CATTRIBUTE_GROUP As String
    Public Property CUSER_ID As String
End Class
