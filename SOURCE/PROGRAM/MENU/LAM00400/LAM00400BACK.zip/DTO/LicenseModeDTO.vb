﻿Imports R_BackEnd

'<Serializable()> _
Public Class LicenseModeDTO
    Inherits R_DTOBase

    Public Property CLICENSE_MODE As String
End Class
