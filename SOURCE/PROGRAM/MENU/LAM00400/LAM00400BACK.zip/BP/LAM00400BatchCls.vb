﻿Imports R_Common
Imports R_BackEnd
Imports LAM00400Common
Imports System.Data.Common
Imports System.Transactions

Public Class LAM00400BatchCls
    Implements R_IBatchProcess

    Public Sub R_BatchProcess(poBatchProcessPar As R_Common.R_BatchProcessPar) Implements R_Common.R_IBatchProcess.R_BatchProcess
        Dim loEx As New R_Exception()
        Dim loObject As List(Of LAM00400BatchDTO)
        Dim loDb As New R_Db
        Dim lcQuery As String
        Dim loResult As LAM00400LicenseModeDTO
        Dim loConn As DbConnection
        Dim CUSER_ID As String
        Dim loMapping As New Dictionary(Of String, String)()
        Dim countLoop As Integer = 0
        Dim CCOMP_ID As String

        Try
            'get all program
            loObject = R_Utility.Deserialize(poBatchProcessPar.BigObject)
            CCOMP_ID = poBatchProcessPar.Key.COMPANY_ID
            CUSER_ID = poBatchProcessPar.Key.USER_ID

            Using TransScope As New TransactionScope(TransactionScopeOption.Required)
                loConn = loDb.GetConnection()

                'delete dulu semua
                lcQuery = "DELETE LAM_COMPANY_LICENSE_MODE "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery = String.Format(lcQuery, CCOMP_ID)
                loDb.SqlExecNonQuery(lcQuery, loConn, False)

                For Each save As LAM00400BatchDTO In loObject
                    lcQuery = "exec RSP_WriteUploadProcessStatus '{0}', '{1}', '{2}', '{3}', '{4}'"
                    lcQuery = String.Format(lcQuery, CCOMP_ID, CUSER_ID, poBatchProcessPar.Key.KEY_GUID.Trim, countLoop, "Save " + save.CLICENSE_MODE)
                    loDb.SqlExecNonQuery(lcQuery, loConn, False)

                    If loResult Is Nothing Then
                        'insert into LAM_COMPANY_LICENSE_MODE
                        lcQuery = "INSERT INTO LAM_COMPANY_LICENSE_MODE (CCOMPANY_ID, CLICENSE_MODE, CCREATE_BY, DCREATE_DATE) "
                        lcQuery += "VALUES ('{0}', '{1}', '{2}', GETDATE())"
                        lcQuery = String.Format(lcQuery, CCOMP_ID, save.CLICENSE_MODE, CUSER_ID)
                        loDb.SqlExecNonQuery(lcQuery, loConn, False)
                    End If

                    countLoop += 1
                Next

                lcQuery = "exec RSP_WriteUploadProcessStatus '{0}', '{1}', '{2}', '{3}', '{4}', '{5}'"
                lcQuery = String.Format(lcQuery, CCOMP_ID, CUSER_ID, poBatchProcessPar.Key.KEY_GUID.Trim, countLoop, "Save Complete", 1)
                loDb.SqlExecNonQuery(lcQuery, loConn, True)

                TransScope.Complete()
            End Using

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub
End Class
