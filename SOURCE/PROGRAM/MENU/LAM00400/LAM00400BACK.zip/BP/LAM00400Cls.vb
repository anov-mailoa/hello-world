﻿Imports R_Common
Imports R_BackEnd
Imports System.Data.Common
Imports ServerHelper.General
Imports System.Transactions

Public Class LAM00400Cls

    Public Function GetSelectedLicenseMode(pcCompanyId As String) As List(Of LicenseModeDTO)
        Dim loResult As List(Of LicenseModeDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT CLICENSE_MODE "
            lcQuery += "FROM "
            lcQuery += "LAM_COMPANY_LICENSE_MODE (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery += "ORDER BY LDEFAULT DESC, CLICENSE_MODE "
            lcQuery = String.Format(lcQuery, pcCompanyId)

            loResult = loDb.SqlExecObjectQuery(Of LicenseModeDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

        Return loResult
    End Function

    Public Function GetAvailableLicenseMode(pcCompanyId As String) As List(Of LicenseModeDTO)
        Dim loResult As List(Of LicenseModeDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT CLICENSE_MODE "
            lcQuery += "FROM "
            lcQuery += "LAM_LICENSE_MODE A (NOLOCK) "
            lcQuery += "WHERE NOT EXISTS ("
            lcQuery += "SELECT CLICENSE_MODE "
            lcQuery += "FROM "
            lcQuery += "LAM_COMPANY_LICENSE_MODE (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery += "AND CLICENSE_MODE = A.CLICENSE_MODE "
            lcQuery += ")"
            lcQuery += "ORDER BY LDEFAULT DESC, CLICENSE_MODE "
            lcQuery = String.Format(lcQuery, pcCompanyId)

            loResult = loDb.SqlExecObjectQuery(Of LicenseModeDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

        Return loResult
    End Function

End Class
