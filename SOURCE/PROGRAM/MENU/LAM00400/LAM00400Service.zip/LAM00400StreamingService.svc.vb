﻿Imports R_Common
Imports LAM00400Back
Imports System.ServiceModel.Channels
' NOTE: You can use the "Rename" command on the context menu to change the class name "LAM00400StreamingService" in code, svc and config file together.
Public Class LAM00400StreamingService
    Implements ILAM00400StreamingService

    Public Function getAvailableLicenseMode() As System.ServiceModel.Channels.Message Implements ILAM00400StreamingService.getAvailableLicenseMode
        Dim loException As New R_Exception
        Dim loCls As New LAM00400Cls
        Dim loRtnTemp As List(Of LicenseModeDTO)
        Dim loRtn As Message
        Dim lcCompId As String

        Try
            lcCompId = R_Utility.R_GetStreamingContext("cCompId")

            loRtnTemp = loCls.GetAvailableLicenseMode(lcCompId)

            loRtn = R_StreamUtility(Of LicenseModeDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getAvailableLicenseMode")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function getSelectedLicenseMode() As System.ServiceModel.Channels.Message Implements ILAM00400StreamingService.getSelectedLicenseMode
        Dim loException As New R_Exception
        Dim loCls As New LAM00400Cls
        Dim loRtnTemp As List(Of LicenseModeDTO)
        Dim loRtn As Message
        Dim lcCompId As String

        Try
            lcCompId = R_Utility.R_GetStreamingContext("cCompId")

            loRtnTemp = loCls.GetSelectedLicenseMode(lcCompId)

            loRtn = R_StreamUtility(Of LicenseModeDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getSelectedLicenseMode")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of LAM00400Back.LicenseModeDTO)) Implements ILAM00400StreamingService.Dummy

    End Sub
End Class
