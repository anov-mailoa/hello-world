﻿<Serializable()> _
Public Class LAM00400BatchDTO
    Public Property CLICENSE_MODE As String
End Class
