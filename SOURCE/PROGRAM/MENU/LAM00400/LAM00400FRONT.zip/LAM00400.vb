﻿Imports R_FrontEnd
Imports LAM00400Front.LAM00400StreamingServiceRef
Imports R_Common
Imports System.ServiceModel.Channels
Imports ClientHelper
Imports LAM00400FrontResources

Public Class LAM00400

#Region " VARIABLE "
    'Dim C_ServiceName As String = "LAM00400Service/LAM00400Service.svc"
    'Dim C_ServiceNameStream As String = "LAM00400Service/LAM00400StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
#End Region

    Private Sub LAM00400_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        _CUSERID = U_GlobalVar.UserId
        _CCOMPID = U_GlobalVar.CompId

        gvAvailable.R_RefreshGrid(_CCOMPID)
        gvSelected.R_RefreshGrid(_CCOMPID)
    End Sub

    Private Sub gvAvailable_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvAvailable.R_ServiceGetListRecord
        Dim loServiceStream As LAM00400StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00400StreamingService, LAM00400StreamingServiceClient)(e_ServiceClientType.StreamingService, "LAM00400Service/LAM00400StreamingService.svc")
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of LicenseModeDTO)
        Dim loListEntity As New List(Of LicenseModeDTO)

        Try
            R_Utility.R_SetStreamingContext("cCompId", _CCOMPID)

            loRtn = loServiceStream.getAvailableLicenseMode()
            loStreaming = R_StreamUtility(Of LicenseModeDTO).ReadFromMessage(loRtn)

            For Each loDto As LicenseModeDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSelected_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvSelected.R_ServiceGetListRecord
        Dim loServiceStream As LAM00400StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00400StreamingService, LAM00400StreamingServiceClient)(e_ServiceClientType.StreamingService, "LAM00400Service/LAM00400StreamingService.svc")
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of LicenseModeDTO)
        Dim loListEntity As New List(Of LicenseModeDTO)

        Try
            R_Utility.R_SetStreamingContext("cCompId", _CCOMPID)

            loRtn = loServiceStream.getSelectedLicenseMode()
            loStreaming = R_StreamUtility(Of LicenseModeDTO).ReadFromMessage(loRtn)

            For Each loDto As LicenseModeDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub btnSave_Click(sender As System.Object, e As System.EventArgs) Handles btnSave.Click
        Dim loEx As New R_Exception
        Dim loBatchPar As R_BatchParameter
        Dim loSvc As R_ProcessAndUploadClient
        Dim loBigObject As List(Of LAM00400Common.LAM00400BatchDTO)
        Dim lcKeyGuid As String
        Dim loUserPar As R_KeyValue
        Dim loUserParameters As New List(Of R_KeyValue)

        Try
            If bsGvSelected.List.Count = 0 Then
                loEx.Add("", "Please choose license mode!")
                Exit Try
            End If

            'Instantiate FrontHelper
            loSvc = New R_ProcessAndUploadClient(bwLAM00400, Nothing, Nothing)
            AddHandler loSvc.ProcessError, AddressOf ProcessError
            AddHandler loSvc.ProcessComplete, AddressOf ProcessComplete

            loBigObject = CType(bsGvSelected.List, List(Of LicenseModeDTO)) _
            .Select(Function(x) New LAM00400Common.LAM00400BatchDTO() _
                    With {.CLICENSE_MODE = x.CLICENSE_MODE}).ToList()

            If loBigObject.Count = 0 Then
                Exit Try
            End If

            With loBatchPar
                .COMPANY_ID = _CCOMPID
                .USER_ID = _CUSERID
                .ClassName = "LAM00400Back.LAM00400BatchCls"
                .BigObject = loBigObject
                .UserParameters = loUserParameters
            End With
            lcKeyGuid = loSvc.R_BatchProcess(loBatchPar, bsGvSelected.List.Count)

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If

    End Sub

    Private Sub ProcessComplete(pcKeyGuid As String, poProcessResultMode As eProcessResultMode)
        Dim loEx As New R_Exception()

        Select Case poProcessResultMode
            Case eProcessResultMode.Success
                MsgBox("Process Complete")
                gvAvailable.R_RefreshGrid(_CCOMPID)
                gvSelected.R_RefreshGrid(_CCOMPID)
            Case eProcessResultMode.Fail
                Dim loException As New R_Exception
                Dim loRtn As List(Of R_ErrorStatusReturn)
                Dim loHelp As New R_ProcessAndUploadClient(bwLAM00400, Nothing, Nothing)
                Dim loPar As R_UploadAndProcessKey

                Try
                    With loPar
                        .COMPANY_ID = _CCOMPID
                        .USER_ID = _CUSERID
                        .KEY_GUID = pcKeyGuid
                    End With
                    loRtn = loHelp.R_GetErrorProcess(loPar)

                    For Each loError As R_ErrorStatusReturn In loRtn
                        loEx.Add(loError.SeqNo.ToString, loError.ErrorMessage)
                    Next
                Catch ex As Exception
                    loException.Add(ex)
                End Try

                If loException.Haserror Then
                    loEx.ThrowExceptionIfErrors()
                End If
        End Select
    End Sub

    Private Sub ProcessError(pcKeyGuid As String, ex As R_Exception)
        Dim loEx As New R_Exception()

        If ex.Haserror Then
            loEx.Add(ex)
        End If

        loEx.ThrowExceptionIfErrors()
    End Sub

End Class
