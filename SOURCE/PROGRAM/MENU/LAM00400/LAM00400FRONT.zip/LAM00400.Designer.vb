﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LAM00400
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.gvAvailable = New R_FrontEnd.R_RadGridViewDragDrop(Me.components)
        Me.bsGvAvailable = New System.Windows.Forms.BindingSource(Me.components)
        Me.gvSelected = New R_FrontEnd.R_RadGridViewDragDrop(Me.components)
        Me.bsGvSelected = New System.Windows.Forms.BindingSource(Me.components)
        Me.R_RadGroupBox1 = New R_FrontEnd.R_RadGroupBox(Me.components)
        Me.btnSave = New R_FrontEnd.R_RadButton(Me.components)
        Me.R_RadLabel2 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel1 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_Mover1 = New R_FrontEnd.R_Mover()
        Me.bwLAM00400 = New System.ComponentModel.BackgroundWorker()
        CType(Me.gvAvailable, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvAvailable.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvAvailable, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvSelected, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvSelected.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvSelected, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadGroupBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.R_RadGroupBox1.SuspendLayout()
        CType(Me.btnSave, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_Mover1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'gvAvailable
        '
        Me.gvAvailable.Location = New System.Drawing.Point(5, 66)
        '
        '
        '
        Me.gvAvailable.MasterTemplate.AutoGenerateColumns = False
        Me.gvAvailable.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn1.FieldName = "CLICENSE_MODE"
        R_GridViewTextBoxColumn1.HeaderText = "CLICENSE_MODE"
        R_GridViewTextBoxColumn1.Name = "CLICENSE_MODE"
        R_GridViewTextBoxColumn1.R_ResourceId = "CLICENSE_MODE"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 220
        Me.gvAvailable.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1})
        Me.gvAvailable.MasterTemplate.DataSource = Me.bsGvAvailable
        Me.gvAvailable.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvAvailable.MasterTemplate.EnableFiltering = True
        Me.gvAvailable.MasterTemplate.ShowFilteringRow = False
        Me.gvAvailable.MasterTemplate.ShowGroupedColumns = True
        Me.gvAvailable.Name = "gvAvailable"
        Me.gvAvailable.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvAvailable.R_ConductorGridSource = Nothing
        Me.gvAvailable.R_ConductorSource = Nothing
        Me.gvAvailable.Size = New System.Drawing.Size(240, 150)
        Me.gvAvailable.TabIndex = 0
        Me.gvAvailable.Text = "R_RadGridViewDragDrop1"
        '
        'bsGvAvailable
        '
        Me.bsGvAvailable.DataSource = GetType(LAM00400Front.LAM00400StreamingServiceRef.LicenseModeDTO)
        '
        'gvSelected
        '
        Me.gvSelected.Location = New System.Drawing.Point(251, 66)
        '
        '
        '
        Me.gvSelected.MasterTemplate.AutoGenerateColumns = False
        Me.gvSelected.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn2.FieldName = "CLICENSE_MODE"
        R_GridViewTextBoxColumn2.HeaderText = "CLICENSE_MODE"
        R_GridViewTextBoxColumn2.Name = "CLICENSE_MODE"
        R_GridViewTextBoxColumn2.R_ResourceId = "CLICENSE_MODE"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 220
        Me.gvSelected.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn2})
        Me.gvSelected.MasterTemplate.DataSource = Me.bsGvSelected
        Me.gvSelected.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvSelected.MasterTemplate.EnableFiltering = True
        Me.gvSelected.MasterTemplate.ShowFilteringRow = False
        Me.gvSelected.MasterTemplate.ShowGroupedColumns = True
        Me.gvSelected.Name = "gvSelected"
        Me.gvSelected.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvSelected.R_ConductorGridSource = Nothing
        Me.gvSelected.R_ConductorSource = Nothing
        Me.gvSelected.Size = New System.Drawing.Size(240, 150)
        Me.gvSelected.TabIndex = 1
        Me.gvSelected.Text = "R_RadGridViewDragDrop1"
        '
        'bsGvSelected
        '
        Me.bsGvSelected.DataSource = GetType(LAM00400Front.LAM00400StreamingServiceRef.LicenseModeDTO)
        '
        'R_RadGroupBox1
        '
        Me.R_RadGroupBox1.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping
        Me.R_RadGroupBox1.Controls.Add(Me.btnSave)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel2)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel1)
        Me.R_RadGroupBox1.Controls.Add(Me.gvAvailable)
        Me.R_RadGroupBox1.Controls.Add(Me.gvSelected)
        Me.R_RadGroupBox1.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadGroupBox1.HeaderText = ""
        Me.R_RadGroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.R_RadGroupBox1.Name = "R_RadGroupBox1"
        Me.R_RadGroupBox1.R_ConductorGridSource = Nothing
        Me.R_RadGroupBox1.R_ConductorSource = Nothing
        Me.R_RadGroupBox1.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadGroupBox1.R_ResourceId = Nothing
        Me.R_RadGroupBox1.Size = New System.Drawing.Size(497, 253)
        Me.R_RadGroupBox1.TabIndex = 2
        '
        'btnSave
        '
        Me.btnSave.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnSave.Location = New System.Drawing.Point(381, 222)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.R_ConductorGridSource = Nothing
        Me.btnSave.R_ConductorSource = Nothing
        Me.btnSave.R_DescriptionId = Nothing
        Me.btnSave.R_ResourceId = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(110, 24)
        Me.btnSave.TabIndex = 4
        Me.btnSave.Text = "R_RadButton1"
        '
        'R_RadLabel2
        '
        Me.R_RadLabel2.AutoSize = False
        Me.R_RadLabel2.Font = New System.Drawing.Font("Calibri", 18.0!)
        Me.R_RadLabel2.Location = New System.Drawing.Point(252, 21)
        Me.R_RadLabel2.Name = "R_RadLabel2"
        Me.R_RadLabel2.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Header
        Me.R_RadLabel2.R_ResourceId = "lblSelected"
        Me.R_RadLabel2.Size = New System.Drawing.Size(240, 39)
        Me.R_RadLabel2.TabIndex = 3
        Me.R_RadLabel2.Text = "lblSelected"
        '
        'R_RadLabel1
        '
        Me.R_RadLabel1.AutoSize = False
        Me.R_RadLabel1.Font = New System.Drawing.Font("Calibri", 18.0!)
        Me.R_RadLabel1.Location = New System.Drawing.Point(5, 21)
        Me.R_RadLabel1.Name = "R_RadLabel1"
        Me.R_RadLabel1.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Header
        Me.R_RadLabel1.R_ResourceId = "lblAvailable"
        Me.R_RadLabel1.Size = New System.Drawing.Size(240, 39)
        Me.R_RadLabel1.TabIndex = 2
        Me.R_RadLabel1.Text = "lblAvailable"
        '
        'R_Mover1
        '
        Me.R_Mover1.Location = New System.Drawing.Point(554, 52)
        Me.R_Mover1.Name = "R_Mover1"
        Me.R_Mover1.R_SourceGrid = Me.gvAvailable
        Me.R_Mover1.R_TargetGrid = Me.gvSelected
        Me.R_Mover1.Size = New System.Drawing.Size(46, 197)
        Me.R_Mover1.TabIndex = 3
        Me.R_Mover1.Visible = False
        '
        'LAM00400
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.R_Mover1)
        Me.Controls.Add(Me.R_RadGroupBox1)
        Me.Name = "LAM00400"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.gvAvailable.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvAvailable, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvAvailable, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvSelected.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvSelected, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvSelected, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadGroupBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.R_RadGroupBox1.ResumeLayout(False)
        CType(Me.btnSave, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_Mover1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents gvAvailable As R_FrontEnd.R_RadGridViewDragDrop
    Friend WithEvents gvSelected As R_FrontEnd.R_RadGridViewDragDrop
    Friend WithEvents R_RadGroupBox1 As R_FrontEnd.R_RadGroupBox
    Friend WithEvents R_RadLabel1 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel2 As R_FrontEnd.R_RadLabel
    Friend WithEvents btnSave As R_FrontEnd.R_RadButton
    Friend WithEvents R_Mover1 As R_FrontEnd.R_Mover
    Friend WithEvents bsGvAvailable As System.Windows.Forms.BindingSource
    Friend WithEvents bsGvSelected As System.Windows.Forms.BindingSource
    Friend WithEvents bwLAM00400 As System.ComponentModel.BackgroundWorker

End Class
