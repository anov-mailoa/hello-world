﻿Public Class ReactivationRequestReturnDTO
    Public Property CRETURN_CODE As String
    Public Property CDESCRIPTION As String
    Public Property CACTIVATION_TYPE As String
    Public Property CACTIVATION_CODE As String
    Public Property CSERIAL_NO As String
    Public Property CEXPIRY_DATE As String
    Public Property NGRACE_DAYS As Integer
    Public Property NWARNING_DAYS As Integer
    Public Property CRETURN_TYPE As String
End Class
