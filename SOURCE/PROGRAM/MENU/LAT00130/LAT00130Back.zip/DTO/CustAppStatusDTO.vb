﻿Public Class CustAppStatusDTO
    Public Property CREACTIVATION_STATUS As String
    Public Property CCURRENT_EXPIRY_DATE As String
End Class
