﻿Public Class ReactivationCompleteReturnDTO
    Public Property CRETURN_CODE As String
    Public Property CDESCRIPTION As String
    Public Property CRETURN_TYPE As String
End Class
