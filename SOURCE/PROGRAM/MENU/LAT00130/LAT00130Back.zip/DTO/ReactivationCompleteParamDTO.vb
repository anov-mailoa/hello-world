﻿Public Class ReactivationCompleteParamDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CCUSTOMER_CODE As String
    Public Property CSERVER_TYPE As String
End Class
