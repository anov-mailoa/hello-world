﻿Imports LAT00100Back
Imports R_BackEnd
Imports System.Data.Common
Imports R_Common

Public Class LAT00130Cls

    Public Function ReactivationRequest(poPar As ReactivationRequestParamDTO) As ReactivationRequestReturnDTO
        Dim loReturn As New ReactivationRequestReturnDTO
        Dim loEx As New R_Exception()
        Dim lcQuery As String
        Dim lcResult As String = Nothing
        Dim loDb As New R_Db()
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim loSPReturn As DataTable
        Dim lcStartDate As String
        Dim lcExpiryDate As String
        Dim lcInstallationKey As String = ""
        Dim lnGraceDays As Integer = 0
        Dim lnWarningDays As Integer = 0

        Try

            With loReturn
                .CRETURN_CODE = "000"
                .CDESCRIPTION = "Success."
                .CRETURN_TYPE = "0"
            End With

            With poPar
                ' Validation
                ' Company ID
                If Len(.CCOMPANY_ID.Trim) = 0 Then
                    With loReturn
                        .CRETURN_CODE = "100"
                        .CDESCRIPTION = "Company ID is empty."
                        .CRETURN_TYPE = "1"
                    End With
                    Exit Try
                End If
                If Len(.CCOMPANY_ID.Trim) > 8 Then
                    With loReturn
                        .CRETURN_CODE = "101"
                        .CDESCRIPTION = "Company ID exceeds maximum length."
                        .CRETURN_TYPE = "1"
                    End With
                    Exit Try
                End If

                ' Application Code
                If Len(.CAPPS_CODE.Trim) = 0 Then
                    With loReturn
                        .CRETURN_CODE = "200"
                        .CDESCRIPTION = "Application Code is empty."
                        .CRETURN_TYPE = "1"
                    End With
                    Exit Try
                End If
                If Len(.CAPPS_CODE.Trim) > 20 Then
                    With loReturn
                        .CRETURN_CODE = "201"
                        .CDESCRIPTION = "Application Code exceeds maximum length."
                        .CRETURN_TYPE = "1"
                    End With
                    Exit Try
                End If

                ' Customer Code
                If Len(poPar.CCUSTOMER_CODE.Trim) = 0 Then
                    With loReturn
                        .CRETURN_CODE = "300"
                        .CDESCRIPTION = "Customer Code is empty."
                        .CRETURN_TYPE = "1"
                    End With
                    Exit Try
                End If
                If Len(poPar.CCUSTOMER_CODE.Trim) > 8 Then
                    With loReturn
                        .CRETURN_CODE = "301"
                        .CDESCRIPTION = "Customer Code exceeds maximum length."
                        .CRETURN_TYPE = "1"
                    End With
                    Exit Try
                End If
                loCmd = loDb.GetCommand()
                lcQuery = "EXEC RSP_LAT00130_Before_Reactivation '{0}', '{1}', '{2}', '{3}', @CRETURN_CODE OUTPUT, @CDESCRIPTION OUTPUT, @CRETURN_TYPE OUTPUT "
                lcQuery = String.Format(lcQuery, _
                                            .CCOMPANY_ID, _
                                            .CAPPS_CODE, _
                                            .CCUSTOMER_CODE, _
                                            .CSERVER_TYPE)
                loCmd.CommandText = lcQuery
                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@CRETURN_CODE"
                    .DbType = DbType.String
                    .Size = 3
                    .Direction = ParameterDirection.Output
                End With
                loCmd.Parameters.Add(loPar)
                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@CDESCRIPTION"
                    .DbType = DbType.String
                    .Size = 8000
                    .Direction = ParameterDirection.Output
                End With
                loCmd.Parameters.Add(loPar)
                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@CRETURN_TYPE"
                    .DbType = DbType.String
                    .Size = 1
                    .Direction = ParameterDirection.Output
                End With
                loCmd.Parameters.Add(loPar)
                loSPReturn = loDb.SqlExecQuery(loDb.GetConnection(), loCmd)

                If loCmd.Parameters("@CRETURN_CODE") Is Nothing Then
                    With loReturn
                        .CRETURN_CODE = "999"
                        .CDESCRIPTION = "Unknown error"
                        .CRETURN_TYPE = "1"
                    End With
                Else
                    With loReturn
                        .CRETURN_CODE = loCmd.Parameters("@CRETURN_CODE").Value
                        .CDESCRIPTION = loCmd.Parameters("@CDESCRIPTION").Value
                        .CRETURN_TYPE = loCmd.Parameters("@CRETURN_TYPE").Value
                        .CACTIVATION_TYPE = loSPReturn.Rows(0).Item("CACTIVATION_TYPE").Trim
                    End With
                End If
                If Not loReturn.CRETURN_CODE.Equals("000") Then
                    Exit Try
                End If


            End With

            With loSPReturn.Rows(0)
                loReturn.CACTIVATION_TYPE = .Item("CACTIVATION_TYPE")
                If loReturn.CACTIVATION_TYPE.Trim = "001" Then
                    loReturn.CSERIAL_NO = .Item("CINSTALLATION_KEY")
                    loReturn.CEXPIRY_DATE = .Item("CEXPIRY_DATE")
                    loReturn.NGRACE_DAYS = .Item("NGRACE_DAYS")
                    loReturn.NWARNING_DAYS = .Item("NWARNING_DAYS")
                ElseIf loReturn.CACTIVATION_TYPE.Trim = "002" Then
                    loReturn.CACTIVATION_CODE = .Item("CACTIVATION_CODE")
                    lcInstallationKey = .Item("CINSTALLATION_KEY")
                    lnGraceDays = .Item("NGRACE_DAYS")
                    lnWarningDays = .Item("NWARNING_DAYS")
                End If
                lcStartDate = .Item("CSTART_DATE")
                lcExpiryDate = .Item("CEXPIRY_DATE")
            End With

            ' Save Activation
            If loReturn.CACTIVATION_TYPE.Trim = "002" AndAlso loReturn.CACTIVATION_CODE.Trim.Equals("") Then
                Dim loCls As New LAT00100Cls
                Dim loActivation As New LAT00100ActivationDTO

                With loActivation
                    .CCOMPANY_ID = poPar.CCOMPANY_ID
                    .CAPPS_CODE = poPar.CAPPS_CODE
                    .CCUSTOMER_CODE = poPar.CCUSTOMER_CODE
                    .CSERVER_TYPE = poPar.CSERVER_TYPE
                    .CSERVER_UID = lcInstallationKey
                    .CSTART_DATE = lcStartDate
                    .CEXPIRY_DATE = lcExpiryDate
                    .NGRACE_DAYS = lnGraceDays
                    .NWARNING_DAYS = lnWarningDays
                    .CREFERENCE_NO = ""
                    .LACTIVATION_REQUEST = False
                    .LREACTIVATION_REQUEST = True
                    .CUPDATE_BY = "OPRA" ' on-premise reactivation
                    .CCREATE_BY = "OPRA"
                End With

                loCls.SaveActivation(loActivation)
                loReturn.CACTIVATION_CODE = loActivation.CACTIVATION_CODE
            End If

            ' update current dan status
            lcQuery = "UPDATE LAM_APP_CUST "
            lcQuery += "SET CCURRENT_EXPIRY_DATE = CONVERT(VARCHAR(8), DATEADD(day, -1, DATEADD(month, NINTERVAL, DATEADD(day, 1, CONVERT(date, CLAST_EXPIRY_DATE, 112)))), 112), "
            lcQuery += "CREACTIVATION_STATUS = '{5}', "
            lcQuery += "CUPDATE_BY = 'OPRA', DUPDATE_DATE = GETDATE() "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery += "AND CAPPS_CODE = '{1}' "
            lcQuery += "AND CCUSTOMER_CODE = '{2}' "
            lcQuery += "AND CSERVER_TYPE = '{3}' "
            lcQuery = String.Format(lcQuery, poPar.CCOMPANY_ID, poPar.CAPPS_CODE, poPar.CCUSTOMER_CODE, poPar.CSERVER_TYPE, _
                                    lcExpiryDate, "ON-PROGRESS")
            loDb.SqlExecNonQuery(lcQuery)



        Catch ex As Exception
            With loReturn
                .CRETURN_CODE = "999"
                .CDESCRIPTION = ex.Message
                .CRETURN_TYPE = "1"
            End With
        End Try

        Return loReturn
    End Function

    Public Function ReactivationComplete(poPar As ReactivationCompleteParamDTO) As ReactivationCompleteReturnDTO
        Dim loReturn As New ReactivationCompleteReturnDTO
        Dim loEx As New R_Exception()
        Dim lcQuery As String
        Dim lcResult As String = Nothing
        Dim loResult As CustAppStatusDTO
        Dim loDb As New R_Db()
        Dim loCmd As DbCommand
        Dim loPar As DbParameter

        Try
            With loReturn
                .CRETURN_CODE = "000"
                .CDESCRIPTION = "Success."
                .CRETURN_TYPE = "0"

                ' Validation
                ' Company ID
                If Len(poPar.CCOMPANY_ID.Trim) = 0 Then
                    .CRETURN_CODE = "100"
                    .CDESCRIPTION = "Company ID is empty."
                    .CRETURN_TYPE = "1"
                    Exit Try
                End If
                If Len(poPar.CCOMPANY_ID.Trim) > 8 Then
                    .CRETURN_CODE = "101"
                    .CDESCRIPTION = "Company ID exceeds maximum length."
                    .CRETURN_TYPE = "1"
                    Exit Try
                End If
                lcQuery = "SELECT CCOMPANY_ID "
                lcQuery += "FROM SAM_COMPANIES (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery = String.Format(lcQuery, poPar.CCOMPANY_ID)
                lcResult = loDb.SqlExecObjectQuery(Of String)(lcQuery, loDb.GetConnection, False).FirstOrDefault
                If lcResult Is Nothing Then
                    .CRETURN_CODE = "102"
                    .CDESCRIPTION = "Company ID does not exist."
                    .CRETURN_TYPE = "1"
                    Exit Try
                End If

                ' Application Code
                If Len(poPar.CAPPS_CODE.Trim) = 0 Then
                    .CRETURN_CODE = "200"
                    .CDESCRIPTION = "Application Code is empty."
                    .CRETURN_TYPE = "1"
                    Exit Try
                End If
                If Len(poPar.CAPPS_CODE.Trim) > 20 Then
                    .CRETURN_CODE = "201"
                    .CDESCRIPTION = "Application Code exceeds maximum length."
                    .CRETURN_TYPE = "1"
                    Exit Try
                End If
                lcQuery = "SELECT CAPPS_CODE "
                lcQuery += "FROM RVM_APPLICATION (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery = String.Format(lcQuery, poPar.CCOMPANY_ID, poPar.CAPPS_CODE)
                lcResult = loDb.SqlExecObjectQuery(Of String)(lcQuery, loDb.GetConnection, False).FirstOrDefault
                If lcResult Is Nothing Then
                    .CRETURN_CODE = "202"
                    .CDESCRIPTION = "Application Code does not exist."
                    .CRETURN_TYPE = "1"
                    Exit Try
                End If

                ' Customer Code
                If Len(poPar.CCUSTOMER_CODE.Trim) = 0 Then
                    .CRETURN_CODE = "300"
                    .CDESCRIPTION = "Customer Code is empty."
                    .CRETURN_TYPE = "1"
                    Exit Try
                End If
                If Len(poPar.CCUSTOMER_CODE.Trim) > 20 Then
                    .CRETURN_CODE = "301"
                    .CDESCRIPTION = "Customer Code exceeds maximum length."
                    .CRETURN_TYPE = "1"
                    Exit Try
                End If
                lcQuery = "SELECT CREACTIVATION_STATUS, CCURRENT_EXPIRY_DATE "
                lcQuery += "FROM LAM_APP_CUST (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                lcQuery += "AND CSERVER_TYPE = '{3}' "
                lcQuery = String.Format(lcQuery, poPar.CCOMPANY_ID, poPar.CAPPS_CODE, poPar.CCUSTOMER_CODE, poPar.CSERVER_TYPE)
                loResult = loDb.SqlExecObjectQuery(Of CustAppStatusDTO)(lcQuery, loDb.GetConnection, False).FirstOrDefault
                If loResult Is Nothing Then
                    .CRETURN_CODE = "302"
                    .CDESCRIPTION = "Customer Code does not exist or use the application."
                    .CRETURN_TYPE = "1"
                    Exit Try
                Else
                    If Not loResult.CREACTIVATION_STATUS.Trim.Equals("ON-PROGRESS") Then
                        .CRETURN_CODE = "401"
                        .CDESCRIPTION = "Status is not ON-PROGRESS."
                        .CRETURN_TYPE = "1"
                        Exit Try
                    End If
                End If

                ' Update to COMPLETE
                lcQuery = "UPDATE LAM_APP_CUST "
                lcQuery += "SET CREACTIVATION_STATUS = '{4}', "
                lcQuery += "CLAST_EXPIRY_DATE = '{5}', "
                lcQuery += "CCURRENT_EXPIRY_DATE = '' "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                lcQuery += "AND CSERVER_TYPE = '{3}' "
                lcQuery = String.Format(lcQuery, poPar.CCOMPANY_ID, poPar.CAPPS_CODE, poPar.CCUSTOMER_CODE, poPar.CSERVER_TYPE, _
                                        "COMPLETE", loResult.CCURRENT_EXPIRY_DATE)
                loDb.SqlExecNonQuery(lcQuery)

            End With
        Catch ex As Exception
            With loReturn
                .CRETURN_CODE = "999"
                .CDESCRIPTION = ex.Message
                .CRETURN_TYPE = "1"
            End With
        End Try

        Return loReturn
    End Function

End Class
