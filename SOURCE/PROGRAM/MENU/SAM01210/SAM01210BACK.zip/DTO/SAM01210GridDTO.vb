﻿Imports R_BackEnd

Public Class SAM01210GridDTO
    Inherits R_DTOBase

    ' User
    Public Property CUSER_ID As String
    Public Property CUSER_NAME As String
    Public Property CPOSITION As String
    Public Property DLAST_UPDATE_PSWD As Nullable(Of Date)
    Public Property CEMAIL_ADDRESS As String

    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)

    ' Company User
    Public Property CCOMPANY_ID As String
    Public Property CCOMPANY_NAME As String
    Public Property LTIME_LIMITATION As Boolean
    Public Property CSTART_DATE As String
    Public Property CEND_DATE As String
    Public Property IUSER_LEVEL As Integer

End Class
