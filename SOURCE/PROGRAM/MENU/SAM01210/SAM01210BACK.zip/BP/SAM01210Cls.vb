﻿Imports R_Common
Imports R_BackEnd
Imports System.Data.Common
Imports System.Transactions
Imports SAM01200Back

Public Class SAM01210Cls
    Inherits R_BusinessObject(Of SAM01210DTO)

    Private lcRandomStr As String

    Protected Overrides Sub R_Deleting(poEntity As SAM01210DTO)
        Dim loEx As New R_Exception()
        Dim loCls As New SAM01200Cls
        Dim loEntity As New SAM01200UserDTO

        Try
            loEntity = R_Utility.R_ConvertObjectToObject(Of SAM01210DTO, SAM01200UserDTO)(poEntity)
            loCls.deleteUSER(loEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

    Protected Overrides Function R_Display(poEntity As SAM01210DTO) As SAM01210DTO
        Dim loResult As SAM01210DTO
        Dim loTempResult As UserCompanyDTO
        Dim loUserCompanyCls As New UserCompanyCls
        Dim loEx As New R_Exception
        Dim loEntity As New UserCompanyDTO

        Try
            loEntity = R_Utility.R_ConvertObjectToObject(Of SAM01210DTO, UserCompanyDTO)(poEntity)
            loTempResult = loUserCompanyCls.displayUserCompany(loEntity)
            loResult = R_Utility.R_ConvertObjectToObject(Of UserCompanyDTO, SAM01210DTO)(loTempResult)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As SAM01210DTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loUserCls As New SAM01200Cls
        Dim loUserCompanyCls As New UserCompanyCls
        Dim loNewEntity As New SAM01200UserDTO
        Dim loNewCompanyEntity As New UserCompanyDTO

        Try
            loNewEntity = R_Utility.R_ConvertObjectToObject(Of SAM01210DTO, SAM01200UserDTO)(poNewEntity)
            If poNewEntity.CSECURITY_AND_ACCOUNT_POLICY.Trim.Equals("bycompany") Then
                loNewEntity.CEMAIL_ID = ""
            End If
            loUserCls.SaveSAM_USER(loNewEntity, poCRUDMode)
            loNewCompanyEntity = R_Utility.R_ConvertObjectToObject(Of SAM01210DTO, UserCompanyDTO)(poNewEntity)
            If poNewEntity.CSECURITY_AND_ACCOUNT_POLICY.Trim.Equals("byuser") Then
                loNewCompanyEntity.CEMAIL_ID = ""
            End If
            loUserCompanyCls.saveSAM_USER_COMPANY(loNewCompanyEntity, poCRUDMode)

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

    Public Function getUserCompanyList(pcCompanyId As String) As List(Of SAM01210GridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of SAM01210GridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT A.CCOMPANY_ID, "
            lcQuery += "A.CUSER_ID, "
            lcQuery += "A.LTIME_LIMITATION, "
            lcQuery += "A.CSTART_DATE, "
            lcQuery += "A.CEND_DATE, "
            lcQuery += "A.IUSER_LEVEL, "
            lcQuery += "A.DSTART_DATE, "
            lcQuery += "A.DEND_DATE, "
            lcQuery += "B.CUSER_NAME, "
            lcQuery += "B.CPOSITION, "
            lcQuery += "B.DLAST_UPDATE_PSWD, "
            lcQuery += "B.CEMAIL_ADDRESS, "
            lcQuery += "B.CCREATE_BY, "
            lcQuery += "B.DCREATE_DATE, "
            lcQuery += "B.CUPDATE_BY, "
            lcQuery += "B.DUPDATE_DATE "
            lcQuery += "FROM SAM_USER_COMPANY A (NOLOCK) "
            lcQuery += "JOIN SAM_USER B (NOLOCK) "
            lcQuery += "ON B.CUSER_ID = A.CUSER_ID "
            lcQuery += "WHERE A.CCOMPANY_ID = '{0}'"
            lcQuery = String.Format(lcQuery, pcCompanyId)

            loResult = loDb.SqlExecObjectQuery(Of SAM01210GridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function getCmbMenu(pcCompId As String) As List(Of cmbDTO)
        Dim lcQuery As String
        Dim loResult As List(Of cmbDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT CMENU_ID AS CID, CMENU_NAME AS CDESC "
            lcQuery += "FROM SAM_MENU (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' AND LSYSTEM_FLAG = 0 "
            lcQuery = String.Format(lcQuery, pcCompId)

            loResult = loDb.SqlExecObjectQuery(Of cmbDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

End Class
