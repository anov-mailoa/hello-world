﻿Imports System.ServiceModel
Imports R_Common
Imports SAM01210Back
Imports R_BackEnd
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ISAM01210StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ISAM01210StreamingService

    <OperationContract(Action:="getUserCompanyList", ReplyAction:="getUserCompanyList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function getUserCompanyList() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of SAM01210GridDTO))

End Interface
