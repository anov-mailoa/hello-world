﻿Imports R_Common
Imports SAM01210Back
Imports System.ServiceModel.Channels
' NOTE: You can use the "Rename" command on the context menu to change the class name "SAM01210StreamingService" in code, svc and config file together.
Public Class SAM01210StreamingService
    Implements ISAM01210StreamingService

    Public Function getUserCompanyList() As System.ServiceModel.Channels.Message Implements ISAM01210StreamingService.getUserCompanyList
        Dim loException As New R_Exception
        Dim loCls As New SAM01210Cls
        Dim loRtnTemp As List(Of SAM01210GridDTO)
        Dim loRtn As Message
        Dim lcUserId As String

        Try
            lcUserId = R_Utility.R_GetStreamingContext("cCompId")

            loRtnTemp = loCls.getUserCompanyList(lcUserId)

            loRtn = R_StreamUtility(Of SAM01210GridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getUserCompanyList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn

    End Function

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of SAM01210GridDTO)) Implements ISAM01210StreamingService.Dummy

    End Sub
End Class
