﻿Public Class MenuAccessParamDTO
    Public Property CUSER_ID As String
End Class
