﻿Imports SAM01210Front.SAM01200ServiceRef
Imports SAM01210Front.SAM01210ServiceRef
Imports SAM01210Front.SAM01100StreamingServiceRef
Imports SAM01210Front.MenuProgramServiceRef
Imports R_Common
Imports R_FrontEnd
Imports SAM01210Front.SAM01200StreamingServiceRef
Imports System.ServiceModel.Channels
Imports SAM01210Front.UserMenuServiceRef
Imports ClientHelper
Imports SAM01210FrontResources
Imports Telerik.WinControls.UI

Public Class MenuAccess
#Region " VARIABLE "
    Dim C_ServiceName As String = "SAM01200Service/SAM01200Service.svc"
    Dim C_ServiceNameStream As String = "SAM01200Service/SAM01200StreamingService/SAM01200StreamingService.svc"
    Dim C_ServiceNameCompany As String = "SAM01200Service/UserCompanyService/UserCompanyService.svc"
    Dim C_ServiceNameMenu As String = "SAM01200Service/UserMenuService/UserMenuService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _oParentData As New MenuAccessParamDTO
#End Region

    Private Sub MenuAccess_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim loService As SAM01210ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01210Service, SAM01210ServiceClient)(e_ServiceClientType.RegularService, "SAM01210Service/SAM01210Service.svc")
        Dim loEx As New R_Exception

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            bsCmbMenu.DataSource = loService.getCmbMenu(_CCOMPID)
            loService.Close()

            _oParentData = poParameter

            gvUserMenu.R_RefreshGrid(_CCOMPID)

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#Region "GRIDVIEW USER MENU"

    Private Sub gvUserMenu_CellEditorInitialized(sender As Object, e As Telerik.WinControls.UI.GridViewCellEventArgs) Handles gvUserMenu.CellEditorInitialized
        Dim editor As RadDropDownListEditor = TryCast(sender.ActiveEditor, RadDropDownListEditor)
        If editor IsNot Nothing Then
            RemoveHandler editor.ValueChanged, AddressOf editor_ValueChanged
            AddHandler editor.ValueChanged, AddressOf editor_ValueChanged
        End If

    End Sub

    Private Sub gvUserMenu_CellValueChanged(sender As Object, e As Telerik.WinControls.UI.GridViewCellEventArgs) Handles gvUserMenu.CellValueChanged
        Dim cSender As String = sender.ColumnInfo.Name

        If cSender = "_CMENU_ID" Then
            sender.GridViewElement.CurrentRow.Cells("_CMENU_NAME").Value = CType(bsCmbMenu.Current, SAM01210Front.SAM01210ServiceRef.cmbDTO)._CDESC
        End If
    End Sub

    Private Sub gvUserMenu_R_AfterAdd(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection) Handles gvUserMenu.R_AfterAdd
        poGridCellCollection(4).Value = _CUSERID
        poGridCellCollection(5).Value = DateTime.Now
    End Sub

    Private Sub gvUserMenu_R_CheckDelete(poEntity As Object, ByRef plAllowDelete As Boolean) Handles gvUserMenu.R_CheckDelete
        If CType(poEntity, UserMenuDTO)._CMENU_ID = "MA" And _CUSERID.ToLower = "admin" Then
            plAllowDelete = False
        End If
    End Sub

    Private Sub gvUserMenu_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvUserMenu.R_Display
        If poEntity IsNot Nothing Then
            gvMenuPrograms.R_RefreshGrid(CType(poEntity, UserMenuDTO)._CMENU_ID)
        End If
    End Sub

    Private Sub gvUserMenu_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvUserMenu.R_Saving
        With CType(poEntity, UserMenuDTO)
            ._DDATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            ._CUSER_ID = _oParentData.CUSER_ID
            ._CCOMPANY_ID = _CCOMPID
        End With
    End Sub

    Private Sub gvUserMenu_R_ServiceDelete(poEntity As Object) Handles gvUserMenu.R_ServiceDelete
        Dim loService As UserMenuServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IUserMenuService, UserMenuServiceClient)(e_ServiceClientType.RegularService, C_ServiceNameMenu)
        Dim loEx As New R_Exception

        Try
            loService.Svc_R_Delete(New UserMenuDTO With {._CCOMPANY_ID = _CCOMPID,
                                                         ._CUSER_ID = _oParentData.CUSER_ID,
                                                         ._CMENU_ID = CType(poEntity, UserMenuDTO)._CMENU_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
    Private Sub gvUserMenu_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvUserMenu.R_ServiceGetListRecord
        Dim loServiceStream As SAM01200StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01200StreamingService, SAM01200StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loEx As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of UserMenuDTOnon)
        Dim loListEntity As New List(Of UserMenuDTO)

        Try
            R_Utility.R_SetStreamingContext("cCompanyId", poEntity)
            R_Utility.R_SetStreamingContext("cUserId", _oParentData.CUSER_ID)

            loRtn = loServiceStream.getUserMenuList()
            loStreaming = R_StreamUtility(Of UserMenuDTOnon).ReadFromMessage(loRtn)

            For Each loDto As UserMenuDTOnon In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New UserMenuDTO With {._CMENU_ID = loDto.CMENU_ID,
                                                            ._CMENU_NAME = loDto.CMENU_NAME,
                                                            ._CCREATE_BY = loDto.CCREATE_BY,
                                                            ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                            ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                            ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvUserMenu_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvUserMenu.R_ServiceGetRecord
        Dim loService As UserMenuServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IUserMenuService, UserMenuServiceClient)(e_ServiceClientType.RegularService, C_ServiceNameMenu)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New UserMenuDTO With {._CCOMPANY_ID = _CCOMPID,
                                                                             ._CUSER_ID = _oParentData.CUSER_ID,
                                                                             ._CMENU_ID = CType(poEntity, UserMenuDTO)._CMENU_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvUserMenu_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvUserMenu.R_ServiceSave
        Dim loService As UserMenuServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IUserMenuService, UserMenuServiceClient)(e_ServiceClientType.RegularService, C_ServiceNameMenu)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvUserMenu_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvUserMenu.R_Validation
        Dim loEx As New R_Exception()

        Try
            pcError = ""
            With poGridCellCollection
                If String.IsNullOrWhiteSpace(.Item(0).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS005")
                    loEx.Add("PS005", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS005"))
                    plCancel = True
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region


    Private Sub MenuAccess_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

    Private Sub gvMenuPrograms_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvMenuPrograms.R_ServiceGetListRecord
        Dim loServiceStream As SAM01100StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01100StreamingService, SAM01100StreamingServiceClient)(e_ServiceClientType.StreamingService, "SAM01100Service/SAM01100StreamingService/SAM01100StreamingService.svc")
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of SAM01100MenuProgramDTOnon)
        Dim loListEntity As New List(Of SAM01100MenuProgramDTO)

        Try
            R_Utility.R_SetStreamingContext("cCompId", _CCOMPID)
            R_Utility.R_SetStreamingContext("cMenuId", poEntity)

            loRtn = loServiceStream.getMenuProgramList()
            loStreaming = R_StreamUtility(Of SAM01100MenuProgramDTOnon).ReadFromMessage(loRtn)

            For Each loDto As SAM01100MenuProgramDTOnon In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New SAM01100MenuProgramDTO With {._CPROGRAM_ID = loDto.CPROGRAM_ID,
                                                                      ._CPROGRAM_NAME = loDto.CPROGRAM_NAME,
                                                                      ._CPROGRAM_ACCESS = loDto.CPROGRAM_ACCESS,
                                                                      ._CBUTTON_ACCESS = loDto.CBUTTON_ACCESS,
                                                                      ._CCREATE_BY = loDto.CCREATE_BY,
                                                                      ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                                      ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                                      ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub editor_ValueChanged(sender As Object, e As EventArgs)
        Dim editor As RadDropDownListEditor = TryCast(sender, RadDropDownListEditor)
        gvMenuPrograms.R_RefreshGrid(editor.Value)
    End Sub
End Class
