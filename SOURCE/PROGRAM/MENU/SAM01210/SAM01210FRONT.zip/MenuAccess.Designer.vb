﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MenuAccess
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewComboBoxColumn1 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn2 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewLookUpColumn1 As R_FrontEnd.R_GridViewLookUpColumn = New R_FrontEnd.R_GridViewLookUpColumn()
        Dim R_GridViewTextBoxColumn6 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn7 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn3 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn8 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn4 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Me.bsCmbMenu = New System.Windows.Forms.BindingSource(Me.components)
        Me.gvUserMenu = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvUserMenu = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridUserMenu = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.R_RadGroupBox1 = New R_FrontEnd.R_RadGroupBox(Me.components)
        Me.R_RadGroupBox2 = New R_FrontEnd.R_RadGroupBox(Me.components)
        Me.gvMenuPrograms = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvMenuPrograms = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridMenuPrograms = New R_FrontEnd.R_ConductorGrid(Me.components)
        CType(Me.bsCmbMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvUserMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvUserMenu.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvUserMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridUserMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadGroupBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.R_RadGroupBox1.SuspendLayout()
        CType(Me.R_RadGroupBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.R_RadGroupBox2.SuspendLayout()
        CType(Me.gvMenuPrograms, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvMenuPrograms.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvMenuPrograms, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridMenuPrograms, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'bsCmbMenu
        '
        Me.bsCmbMenu.DataSource = GetType(SAM01210Front.SAM01210ServiceRef.cmbDTO)
        '
        'gvUserMenu
        '
        Me.gvUserMenu.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gvUserMenu.Location = New System.Drawing.Point(5, 21)
        '
        '
        '
        Me.gvUserMenu.MasterTemplate.AutoGenerateColumns = False
        R_GridViewComboBoxColumn1.DataSource = Me.bsCmbMenu
        R_GridViewComboBoxColumn1.DisplayMember = "_CID"
        R_GridViewComboBoxColumn1.FieldName = "_CMENU_ID"
        R_GridViewComboBoxColumn1.HeaderText = "_CMENU_ID"
        R_GridViewComboBoxColumn1.MinWidth = 100
        R_GridViewComboBoxColumn1.Name = "_CMENU_ID"
        R_GridViewComboBoxColumn1.R_EnableADD = True
        R_GridViewComboBoxColumn1.R_ResourceId = "_CMENU_ID"
        R_GridViewComboBoxColumn1.ValueMember = "_CID"
        R_GridViewComboBoxColumn1.Width = 100
        R_GridViewTextBoxColumn1.FieldName = "_CMENU_NAME"
        R_GridViewTextBoxColumn1.HeaderText = "_CMENU_NAME"
        R_GridViewTextBoxColumn1.IsAutoGenerated = True
        R_GridViewTextBoxColumn1.MinWidth = 150
        R_GridViewTextBoxColumn1.Name = "_CMENU_NAME"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CMENU_NAME"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 150
        R_GridViewTextBoxColumn2.FieldName = "_CUPDATE_BY"
        R_GridViewTextBoxColumn2.HeaderText = "_CUPDATE_BY"
        R_GridViewTextBoxColumn2.IsAutoGenerated = True
        R_GridViewTextBoxColumn2.MinWidth = 150
        R_GridViewTextBoxColumn2.Name = "_CUPDATE_BY"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CUPDATE_BY"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 150
        R_GridViewDateTimeColumn1.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn1.FieldName = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.HeaderText = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.IsAutoGenerated = True
        R_GridViewDateTimeColumn1.MinWidth = 200
        R_GridViewDateTimeColumn1.Name = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.R_ResourceId = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.Width = 200
        R_GridViewTextBoxColumn3.FieldName = "_CCREATE_BY"
        R_GridViewTextBoxColumn3.HeaderText = "_CCREATE_BY"
        R_GridViewTextBoxColumn3.IsAutoGenerated = True
        R_GridViewTextBoxColumn3.MinWidth = 150
        R_GridViewTextBoxColumn3.Name = "_CCREATE_BY"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CCREATE_BY"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 150
        R_GridViewDateTimeColumn2.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn2.FieldName = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.HeaderText = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.IsAutoGenerated = True
        R_GridViewDateTimeColumn2.MinWidth = 200
        R_GridViewDateTimeColumn2.Name = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.R_ResourceId = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.Width = 200
        Me.gvUserMenu.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewComboBoxColumn1, R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewDateTimeColumn1, R_GridViewTextBoxColumn3, R_GridViewDateTimeColumn2})
        Me.gvUserMenu.MasterTemplate.DataSource = Me.bsGvUserMenu
        Me.gvUserMenu.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvUserMenu.MasterTemplate.EnableFiltering = True
        Me.gvUserMenu.MasterTemplate.EnableGrouping = False
        Me.gvUserMenu.MasterTemplate.ShowGroupedColumns = True
        Me.gvUserMenu.Name = "gvUserMenu"
        Me.gvUserMenu.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvUserMenu.R_ConductorGridSource = Me.conGridUserMenu
        Me.gvUserMenu.R_ConductorSource = Nothing
        Me.gvUserMenu.R_DataAdded = False
        Me.gvUserMenu.R_NewRowText = Nothing
        Me.gvUserMenu.Size = New System.Drawing.Size(760, 159)
        Me.gvUserMenu.TabIndex = 4
        Me.gvUserMenu.Text = "R_RadGridView3"
        '
        'bsGvUserMenu
        '
        Me.bsGvUserMenu.DataSource = GetType(SAM01210Front.UserMenuServiceRef.UserMenuDTO)
        '
        'conGridUserMenu
        '
        Me.conGridUserMenu.R_ConductorParent = Nothing
        Me.conGridUserMenu.R_IsHeader = True
        Me.conGridUserMenu.R_RadGroupBox = Nothing
        '
        'R_RadGroupBox1
        '
        Me.R_RadGroupBox1.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping
        Me.R_RadGroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.R_RadGroupBox1.Controls.Add(Me.gvUserMenu)
        Me.R_RadGroupBox1.Font = New System.Drawing.Font("Calibri", 15.0!)
        Me.R_RadGroupBox1.HeaderText = "R_RadGroupBox1"
        Me.R_RadGroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.R_RadGroupBox1.Name = "R_RadGroupBox1"
        Me.R_RadGroupBox1.R_ConductorGridSource = Nothing
        Me.R_RadGroupBox1.R_ConductorSource = Nothing
        Me.R_RadGroupBox1.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.GroupBox
        Me.R_RadGroupBox1.R_ResourceId = "_Menu_Access"
        Me.R_RadGroupBox1.Size = New System.Drawing.Size(770, 185)
        Me.R_RadGroupBox1.TabIndex = 5
        Me.R_RadGroupBox1.Text = "R_RadGroupBox1"
        '
        'R_RadGroupBox2
        '
        Me.R_RadGroupBox2.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping
        Me.R_RadGroupBox2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.R_RadGroupBox2.Controls.Add(Me.gvMenuPrograms)
        Me.R_RadGroupBox2.Font = New System.Drawing.Font("Calibri", 15.0!)
        Me.R_RadGroupBox2.HeaderText = "R_RadGroupBox2"
        Me.R_RadGroupBox2.Location = New System.Drawing.Point(12, 203)
        Me.R_RadGroupBox2.Name = "R_RadGroupBox2"
        Me.R_RadGroupBox2.R_ConductorGridSource = Nothing
        Me.R_RadGroupBox2.R_ConductorSource = Nothing
        Me.R_RadGroupBox2.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.GroupBox
        Me.R_RadGroupBox2.R_ResourceId = "_Program"
        Me.R_RadGroupBox2.Size = New System.Drawing.Size(770, 102)
        Me.R_RadGroupBox2.TabIndex = 6
        Me.R_RadGroupBox2.Text = "R_RadGroupBox2"
        '
        'gvMenuPrograms
        '
        Me.gvMenuPrograms.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gvMenuPrograms.Location = New System.Drawing.Point(5, 21)
        '
        '
        '
        Me.gvMenuPrograms.MasterTemplate.AllowAddNewRow = False
        Me.gvMenuPrograms.MasterTemplate.AutoGenerateColumns = False
        Me.gvMenuPrograms.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn4.FieldName = "_CPROGRAM_ID"
        R_GridViewTextBoxColumn4.HeaderText = "CPROGRAM_ID"
        R_GridViewTextBoxColumn4.Name = "_CPROGRAM_ID"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CPROGRAM_ID"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 99
        R_GridViewTextBoxColumn5.FieldName = "_CPROGRAM_NAME"
        R_GridViewTextBoxColumn5.HeaderText = "CPROGRAM_NAME"
        R_GridViewTextBoxColumn5.IsAutoGenerated = True
        R_GridViewTextBoxColumn5.Name = "_CPROGRAM_NAME"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CPROGRAM_NAME"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 99
        R_GridViewLookUpColumn1.FieldName = "_CPROGRAM_ACCESS"
        R_GridViewLookUpColumn1.HeaderText = "CPROGRAM_ACCESS"
        R_GridViewLookUpColumn1.Name = "_CPROGRAM_ACCESS"
        R_GridViewLookUpColumn1.R_EnableADD = True
        R_GridViewLookUpColumn1.R_EnableEDIT = True
        R_GridViewLookUpColumn1.R_ResourceId = "_CPROGRAM_ACCESS"
        R_GridViewLookUpColumn1.Width = 103
        R_GridViewTextBoxColumn6.FieldName = "_CBUTTON_ACCESS"
        R_GridViewTextBoxColumn6.HeaderText = "CBUTTON_ACCESS"
        R_GridViewTextBoxColumn6.Name = "_CBUTTON_ACCESS"
        R_GridViewTextBoxColumn6.R_ResourceId = "_BUTTON_ACCESS"
        R_GridViewTextBoxColumn6.R_UDT = Nothing
        R_GridViewTextBoxColumn6.Width = 45
        R_GridViewTextBoxColumn7.FieldName = "_CUPDATE_BY"
        R_GridViewTextBoxColumn7.HeaderText = "CUPDATE_BY"
        R_GridViewTextBoxColumn7.IsAutoGenerated = True
        R_GridViewTextBoxColumn7.Name = "_CUPDATE_BY"
        R_GridViewTextBoxColumn7.R_ResourceId = "_CUPDATE_BY"
        R_GridViewTextBoxColumn7.R_UDT = Nothing
        R_GridViewTextBoxColumn7.Width = 99
        R_GridViewDateTimeColumn3.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn3.FieldName = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn3.HeaderText = "DUPDATE_DATE"
        R_GridViewDateTimeColumn3.IsAutoGenerated = True
        R_GridViewDateTimeColumn3.Name = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn3.R_ResourceId = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn3.Width = 99
        R_GridViewTextBoxColumn8.FieldName = "_CCREATE_BY"
        R_GridViewTextBoxColumn8.HeaderText = "CCREATE_BY"
        R_GridViewTextBoxColumn8.IsAutoGenerated = True
        R_GridViewTextBoxColumn8.Name = "_CCREATE_BY"
        R_GridViewTextBoxColumn8.R_ResourceId = "_CCREATE_BY"
        R_GridViewTextBoxColumn8.R_UDT = Nothing
        R_GridViewTextBoxColumn8.Width = 99
        R_GridViewDateTimeColumn4.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn4.FieldName = "_DCREATE_DATE"
        R_GridViewDateTimeColumn4.HeaderText = "DCREATE_DATE"
        R_GridViewDateTimeColumn4.IsAutoGenerated = True
        R_GridViewDateTimeColumn4.Name = "_DCREATE_DATE"
        R_GridViewDateTimeColumn4.R_ResourceId = "_DCREATE_DATE"
        R_GridViewDateTimeColumn4.Width = 104
        Me.gvMenuPrograms.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn4, R_GridViewTextBoxColumn5, R_GridViewLookUpColumn1, R_GridViewTextBoxColumn6, R_GridViewTextBoxColumn7, R_GridViewDateTimeColumn3, R_GridViewTextBoxColumn8, R_GridViewDateTimeColumn4})
        Me.gvMenuPrograms.MasterTemplate.DataSource = Me.bsGvMenuPrograms
        Me.gvMenuPrograms.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvMenuPrograms.MasterTemplate.EnableFiltering = True
        Me.gvMenuPrograms.MasterTemplate.EnableGrouping = False
        Me.gvMenuPrograms.MasterTemplate.ShowGroupedColumns = True
        Me.gvMenuPrograms.Name = "gvMenuPrograms"
        Me.gvMenuPrograms.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvMenuPrograms.R_ConductorGridSource = Me.conGridMenuPrograms
        Me.gvMenuPrograms.R_ConductorSource = Nothing
        Me.gvMenuPrograms.R_DataAdded = False
        Me.gvMenuPrograms.R_NewRowText = Nothing
        Me.gvMenuPrograms.ReadOnly = True
        Me.gvMenuPrograms.Size = New System.Drawing.Size(760, 76)
        Me.gvMenuPrograms.TabIndex = 2
        Me.gvMenuPrograms.Text = "R_RadGridView2"
        '
        'bsGvMenuPrograms
        '
        Me.bsGvMenuPrograms.DataSource = GetType(SAM01210Front.MenuProgramServiceRef.SAM01100MenuProgramDTO)
        '
        'conGridMenuPrograms
        '
        Me.conGridMenuPrograms.R_ConductorParent = Me.conGridUserMenu
        Me.conGridMenuPrograms.R_RadGroupBox = Nothing
        '
        'MenuAccess
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(794, 317)
        Me.Controls.Add(Me.R_RadGroupBox2)
        Me.Controls.Add(Me.R_RadGroupBox1)
        Me.Name = "MenuAccess"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "Assign Menu"
        CType(Me.bsCmbMenu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvUserMenu.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvUserMenu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvUserMenu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridUserMenu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadGroupBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.R_RadGroupBox1.ResumeLayout(False)
        CType(Me.R_RadGroupBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.R_RadGroupBox2.ResumeLayout(False)
        CType(Me.gvMenuPrograms.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvMenuPrograms, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvMenuPrograms, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridMenuPrograms, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents gvUserMenu As R_FrontEnd.R_RadGridView
    Friend WithEvents bsGvUserMenu As System.Windows.Forms.BindingSource
    Friend WithEvents bsCmbMenu As System.Windows.Forms.BindingSource
    Friend WithEvents conGridUserMenu As R_FrontEnd.R_ConductorGrid
    Friend WithEvents R_RadGroupBox1 As R_FrontEnd.R_RadGroupBox
    Friend WithEvents R_RadGroupBox2 As R_FrontEnd.R_RadGroupBox
    Friend WithEvents gvMenuPrograms As R_FrontEnd.R_RadGridView
    Friend WithEvents conGridMenuPrograms As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsGvMenuPrograms As System.Windows.Forms.BindingSource

End Class
