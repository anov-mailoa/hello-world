﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SAM01210
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn1 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewDateTimeColumn2 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn3 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDecimalColumn1 As R_FrontEnd.R_GridViewDecimalColumn = New R_FrontEnd.R_GridViewDecimalColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn4 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn6 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn5 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Me.gvUser = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvUser = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridUser = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.btnAssignMenu = New R_FrontEnd.R_Detail(Me.components)
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        CType(Me.gvUser, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvUser.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvUser, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridUser, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnAssignMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'gvUser
        '
        Me.gvUser.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvUser.EnableFastScrolling = True
        Me.gvUser.Location = New System.Drawing.Point(3, 3)
        '
        '
        '
        Me.gvUser.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn1.FieldName = "_CUSER_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CUSER_ID"
        R_GridViewTextBoxColumn1.Name = "_CUSER_ID"
        R_GridViewTextBoxColumn1.R_EnableADD = True
        R_GridViewTextBoxColumn1.R_ResourceId = "_CUSER_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 73
        R_GridViewTextBoxColumn2.FieldName = "_CUSER_NAME"
        R_GridViewTextBoxColumn2.HeaderText = "_CUSER_NAME"
        R_GridViewTextBoxColumn2.Name = "_CUSER_NAME"
        R_GridViewTextBoxColumn2.R_EnableADD = True
        R_GridViewTextBoxColumn2.R_EnableEDIT = True
        R_GridViewTextBoxColumn2.R_ResourceId = "_CUSER_NAME"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 93
        R_GridViewTextBoxColumn3.FieldName = "_CPOSITION"
        R_GridViewTextBoxColumn3.HeaderText = "_CPOSITION"
        R_GridViewTextBoxColumn3.Name = "_CPOSITION"
        R_GridViewTextBoxColumn3.R_EnableADD = True
        R_GridViewTextBoxColumn3.R_EnableEDIT = True
        R_GridViewTextBoxColumn3.R_ResourceId = "_CPOSITION"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 79
        R_GridViewDateTimeColumn1.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn1.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn1.FieldName = "_DLAST_UPDATE_PSWD"
        R_GridViewDateTimeColumn1.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn1.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn1.HeaderText = "_DLAST_UPDATE_PSWD"
        R_GridViewDateTimeColumn1.Name = "_DLAST_UPDATE_PSWD"
        R_GridViewDateTimeColumn1.R_ResourceId = "_DLAST_UPDATE_PSWD"
        R_GridViewDateTimeColumn1.Width = 135
        R_GridViewTextBoxColumn4.FieldName = "_CEMAIL_ADDRESS"
        R_GridViewTextBoxColumn4.HeaderText = "_CEMAIL_ADDRESS"
        R_GridViewTextBoxColumn4.Name = "_CEMAIL_ADDRESS"
        R_GridViewTextBoxColumn4.R_EnableADD = True
        R_GridViewTextBoxColumn4.R_EnableEDIT = True
        R_GridViewTextBoxColumn4.R_ResourceId = "_CEMAIL_ADDRESS"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 113
        R_GridViewCheckBoxColumn1.FieldName = "_LTIME_LIMITATION"
        R_GridViewCheckBoxColumn1.HeaderText = "_LTIME_LIMITATION"
        R_GridViewCheckBoxColumn1.Name = "_LTIME_LIMITATION"
        R_GridViewCheckBoxColumn1.R_EnableADD = True
        R_GridViewCheckBoxColumn1.R_EnableEDIT = True
        R_GridViewCheckBoxColumn1.R_ResourceId = "_LTIME_LIMITATION"
        R_GridViewCheckBoxColumn1.Width = 130
        R_GridViewDateTimeColumn2.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn2.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn2.FieldName = "_DSTART_DATE"
        R_GridViewDateTimeColumn2.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn2.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn2.HeaderText = "_DSTART_DATE"
        R_GridViewDateTimeColumn2.Name = "_DSTART_DATE"
        R_GridViewDateTimeColumn2.R_EnableADD = True
        R_GridViewDateTimeColumn2.R_EnableEDIT = True
        R_GridViewDateTimeColumn2.R_ResourceId = "_CSTART_DATE"
        R_GridViewDateTimeColumn2.Width = 93
        R_GridViewDateTimeColumn3.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn3.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn3.FieldName = "_DEND_DATE"
        R_GridViewDateTimeColumn3.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn3.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn3.HeaderText = "_DEND_DATE"
        R_GridViewDateTimeColumn3.Name = "_DEND_DATE"
        R_GridViewDateTimeColumn3.R_EnableADD = True
        R_GridViewDateTimeColumn3.R_EnableEDIT = True
        R_GridViewDateTimeColumn3.R_ResourceId = "_CEND_DATE"
        R_GridViewDateTimeColumn3.Width = 84
        R_GridViewDecimalColumn1.DataType = GetType(Integer)
        R_GridViewDecimalColumn1.FieldName = "_IUSER_LEVEL"
        R_GridViewDecimalColumn1.FormatString = "{0:N}"
        R_GridViewDecimalColumn1.HeaderText = "_IUSER_LEVEL"
        R_GridViewDecimalColumn1.Name = "_IUSER_LEVEL"
        R_GridViewDecimalColumn1.R_EnableADD = True
        R_GridViewDecimalColumn1.R_EnableEDIT = True
        R_GridViewDecimalColumn1.R_ResourceId = "_IUSER_LEVEL"
        R_GridViewDecimalColumn1.ThousandsSeparator = True
        R_GridViewDecimalColumn1.Width = 86
        R_GridViewTextBoxColumn5.FieldName = "_CUPDATE_BY"
        R_GridViewTextBoxColumn5.HeaderText = "_CUPDATE_BY"
        R_GridViewTextBoxColumn5.Name = "_CUPDATE_BY"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CUPDATE_BY"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 88
        R_GridViewDateTimeColumn4.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn4.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn4.FieldName = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn4.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn4.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn4.HeaderText = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn4.Name = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn4.R_ResourceId = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn4.Width = 101
        R_GridViewTextBoxColumn6.FieldName = "_CCREATE_BY"
        R_GridViewTextBoxColumn6.HeaderText = "_CCREATE_BY"
        R_GridViewTextBoxColumn6.Name = "_CCREATE_BY"
        R_GridViewTextBoxColumn6.R_ResourceId = "_CCREATE_BY"
        R_GridViewTextBoxColumn6.R_UDT = Nothing
        R_GridViewTextBoxColumn6.Width = 86
        R_GridViewDateTimeColumn5.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn5.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn5.FieldName = "_DCREATE_DATE"
        R_GridViewDateTimeColumn5.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn5.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn5.HeaderText = "_DCREATE_DATE"
        R_GridViewDateTimeColumn5.Name = "_DCREATE_DATE"
        R_GridViewDateTimeColumn5.R_ResourceId = "_DCREATE_DATE"
        R_GridViewDateTimeColumn5.Width = 102
        Me.gvUser.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewDateTimeColumn1, R_GridViewTextBoxColumn4, R_GridViewCheckBoxColumn1, R_GridViewDateTimeColumn2, R_GridViewDateTimeColumn3, R_GridViewDecimalColumn1, R_GridViewTextBoxColumn5, R_GridViewDateTimeColumn4, R_GridViewTextBoxColumn6, R_GridViewDateTimeColumn5})
        Me.gvUser.MasterTemplate.DataSource = Me.bsGvUser
        Me.gvUser.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvUser.MasterTemplate.EnableFiltering = True
        Me.gvUser.MasterTemplate.EnableGrouping = False
        Me.gvUser.MasterTemplate.ShowFilteringRow = False
        Me.gvUser.MasterTemplate.ShowGroupedColumns = True
        Me.gvUser.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvUser.Name = "gvUser"
        Me.gvUser.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvUser.R_ConductorGridSource = Me.conGridUser
        Me.gvUser.R_ConductorSource = Nothing
        Me.gvUser.R_DataAdded = False
        Me.gvUser.R_NewRowText = Nothing
        Me.gvUser.ShowHeaderCellButtons = True
        Me.gvUser.Size = New System.Drawing.Size(1271, 537)
        Me.gvUser.TabIndex = 0
        Me.gvUser.Text = "R_RadGridView1"
        '
        'bsGvUser
        '
        Me.bsGvUser.DataSource = GetType(SAM01210Front.SAM01210ServiceRef.SAM01210DTO)
        '
        'conGridUser
        '
        Me.conGridUser.R_ConductorParent = Nothing
        Me.conGridUser.R_IsHeader = True
        Me.conGridUser.R_RadGroupBox = Nothing
        '
        'btnAssignMenu
        '
        Me.btnAssignMenu.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnAssignMenu.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnAssignMenu.Location = New System.Drawing.Point(1158, 0)
        Me.btnAssignMenu.Name = "btnAssignMenu"
        Me.btnAssignMenu.R_ConductorGridSource = Me.conGridUser
        Me.btnAssignMenu.R_ConductorSource = Nothing
        Me.btnAssignMenu.R_DescriptionId = Nothing
        Me.btnAssignMenu.R_EnableOTHER = True
        Me.btnAssignMenu.R_ResourceId = "_AssignMenu"
        Me.btnAssignMenu.R_Title = Nothing
        Me.btnAssignMenu.Size = New System.Drawing.Size(110, 24)
        Me.btnAssignMenu.TabIndex = 13
        Me.btnAssignMenu.Text = "R_Detail1"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.gvUser, 0, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 14
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnAssignMenu)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 546)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 26)
        Me.Panel1.TabIndex = 0
        '
        'SAM01210
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "SAM01210"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.gvUser.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvUser, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvUser, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridUser, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnAssignMenu, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents gvUser As R_FrontEnd.R_RadGridView
    Friend WithEvents bsGvUser As System.Windows.Forms.BindingSource
    Friend WithEvents conGridUser As R_FrontEnd.R_ConductorGrid
    Friend WithEvents btnAssignMenu As R_FrontEnd.R_Detail
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel

End Class
