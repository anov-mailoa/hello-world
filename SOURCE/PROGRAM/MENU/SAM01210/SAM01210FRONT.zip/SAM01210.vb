﻿Imports SAM01210FrontResources
Imports R_Common
Imports ClientHelper
Imports R_FrontEnd
Imports SAM01210Front.SAM01210ServiceRef
Imports SAM01210Front.SAM01210StreamingServiceRef
Imports System.ServiceModel.Channels
Imports System.Globalization
Imports HelperStreamExtensionLibrary
Imports System.Text.RegularExpressions

Public Class SAM01210

#Region " VARIABLE "
    Dim C_ServiceName As String = "SAM01210Service/SAM01210Service.svc"
    Dim C_ServiceNameStream As String = "SAM01210Service/SAM01210StreamingService/SAM01210StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
#End Region


    Private Sub SAM01210_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            gvUser.R_RefreshGrid(_CCOMPID)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub SAM01210_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

    Private Sub gvUser_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvUser.DataBindingComplete
        gvUser.BestFitColumns()
    End Sub

    Private Sub gvUser_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvUser.R_Saving
        With CType(poEntity, SAM01210DTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With
    End Sub

    Private Sub gvUser_R_ServiceDelete(poEntity As Object) Handles gvUser.R_ServiceDelete
        Dim loService As SAM01210ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01210Service, SAM01210ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcEmailId As String
        Dim oEmailCls As New EmailCls
        Dim lcSMTP As String

        Try
            lcSMTP = loService.getSMTP(_CCOMPID)
            Dim oEmailPar As EmailParam
            With oEmailPar
                .cSubject = EmailProp.cEmailSubjectDeleted
                .cBody = String.Format(EmailProp.cDeleteUserBody, poEntity._CUSER_ID)
                .cEmailFrom = lcSMTP
            End With
            lcEmailId = oEmailCls.sendEmail(poEntity, oEmailPar, _CCOMPID, _CUSERID)

            With CType(poEntity, SAM01210DTO)
                ._CCOMPANY_ID = _CCOMPID
                ._CEMAIL_ID = lcEmailId
            End With

            loService.Svc_R_Delete(poEntity)

            MsgBox("Sent to user email", MsgBoxStyle.OkOnly, "")
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub


    Private Sub gvUser_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvUser.R_ServiceGetListRecord
        Dim loServiceStream As SAM01210StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01210StreamingService, SAM01210StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of SAM01210GridDTO)
        Dim loListEntity As New List(Of SAM01210DTO)

        Try
            R_Utility.R_SetStreamingContext("cCompId", poEntity)

            loRtn = loServiceStream.getUserCompanyList()
            loStreaming = R_StreamUtility(Of SAM01210GridDTO).ReadFromMessage(loRtn)

            For Each loDto As SAM01210GridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New SAM01210DTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                           ._CUSER_ID = loDto.CUSER_ID,
                                                           ._CUSER_NAME = loDto.CUSER_NAME,
                                                           ._CPOSITION = loDto.CPOSITION,
                                                           ._DLAST_UPDATE_PSWD = loDto.DLAST_UPDATE_PSWD,
                                                           ._CEMAIL_ADDRESS = loDto.CEMAIL_ADDRESS,
                                                           ._LTIME_LIMITATION = loDto.LTIME_LIMITATION,
                                                           ._CSTART_DATE = loDto.CSTART_DATE,
                                                           ._CEND_DATE = loDto.CEND_DATE,
                                                           ._IUSER_LEVEL = loDto.IUSER_LEVEL,
                                                           ._CCREATE_BY = loDto.CCREATE_BY,
                                                           ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                           ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                           ._DUPDATE_DATE = loDto.DUPDATE_DATE,
                                                           ._DSTART_DATE = getDate(loDto.CSTART_DATE),
                                                           ._DEND_DATE = getDate(loDto.CEND_DATE)})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Function getDate(pcDate As String) As Nullable(Of Date)
        If String.IsNullOrEmpty(pcDate) Then
            Return Nothing
        Else
            Return DateTime.ParseExact(pcDate, "yyyyMMdd", CultureInfo.CurrentCulture)
        End If
    End Function

    Private Sub gvUser_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvUser.R_ServiceGetRecord
        Dim loService As SAM01210ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01210Service, SAM01210ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvUser_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvUser.R_ServiceSave
        Dim loService As SAM01210ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01210Service, SAM01210ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcEmailId As String
        Dim cParamValues As String
        Dim oEmailCls As New EmailCls
        Dim lcSMTP As String

        Try
            lcSMTP = loService.getSMTP(_CCOMPID)
            cParamValues = U_GlobalVar.SecurityParameter.cSecurityAndAccountPolicy
            CType(poEntity, SAM01210DTO)._CSECURITY_AND_ACCOUNT_POLICY = cParamValues

            If peGridMode = R_eGridMode.Add Then
                Dim oEmailPar As New EmailParam

                If cParamValues = "byuser" Then
                    With oEmailPar
                        .cSubject = EmailProp.cEmailSubjectNew
                        .cBody = String.Format(EmailProp.cNewUserBody, poEntity._CUSER_ID, poEntity._CUSER_ID, "{2}")
                        .cEmailFrom = lcSMTP
                    End With
                End If
                If cParamValues = "bycompany" Then
                    With oEmailPar
                        .cSubject = EmailProp.cEmailSubjectNew
                        .cBody = String.Format(EmailProp.cNewUserCompBody, poEntity._CUSER_ID, "{1}", poEntity._CCOMPANY_ID)
                        .cEmailFrom = lcSMTP
                    End With
                End If
                lcEmailId = oEmailCls.sendEmail(poEntity, oEmailPar, _CCOMPID, _CUSERID)
                If String.IsNullOrEmpty(lcEmailId) = False Then
                    CType(poEntity, SAM01210DTO)._CEMAIL_ID = lcEmailId
                End If
            End If

            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvUser_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvUser.R_Validation
        Dim loEx As New R_Exception()

        Try
            pcError = ""
            With poGridCellCollection
                If String.IsNullOrWhiteSpace(.Item(0).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS001")
                    loEx.Add("PS001", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS001"))
                    plCancel = True
                End If

                If String.IsNullOrWhiteSpace(.Item(1).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS002")
                    loEx.Add("PS002", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS002"))
                    plCancel = True
                End If

                If String.IsNullOrWhiteSpace(.Item(4).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS003")
                    loEx.Add("PS003", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS003"))
                    plCancel = True
                Else
                    If IsEmail(.Item(4).Value.ToString) = False Then
                        pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS006")
                        loEx.Add("PS006", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS006"))
                        plCancel = True
                    End If
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Function IsEmail(ByVal email As String) As Boolean
        Dim pattern As String = "^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"
        Dim emailAddressMatch As Match = Regex.Match(email, pattern)
        If emailAddressMatch.Success Then
            Return True
        Else
            Return False
        End If
    End Function

    Private Sub btnAssignMenu_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnAssignMenu.R_Before_Open_Form
        Dim loParam As New MenuAccessParamDTO
        poTargetForm = New MenuAccess
        loParam.CUSER_ID = CType(bsGvUser.Current, SAM01210DTO)._CUSER_ID
        poParameter = loParam
    End Sub
End Class
