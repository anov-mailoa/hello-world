﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CST00200Attach
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxMultilineColumn1 As R_FrontEnd.R_GridViewTextBoxMultilineColumn = New R_FrontEnd.R_GridViewTextBoxMultilineColumn()
        Me.lblIssueID = New R_FrontEnd.R_RadLabel(Me.components)
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtIssueId = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.txtDescription = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblDescription = New R_FrontEnd.R_RadLabel(Me.components)
        Me.btnUpload = New R_FrontEnd.R_RadButton(Me.components)
        Me.btnBrowse = New R_FrontEnd.R_RadButton(Me.components)
        Me.txtFilename = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblFile = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvAttachment = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvAttachment = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridAttach = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.ofdAttach = New System.Windows.Forms.OpenFileDialog()
        CType(Me.lblIssueID, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.txtIssueId, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.txtDescription, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblDescription, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnUpload, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnBrowse, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtFilename, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblFile, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvAttachment, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvAttachment.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvAttachment, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridAttach, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblIssueID
        '
        Me.lblIssueID.AutoSize = False
        Me.lblIssueID.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblIssueID.Location = New System.Drawing.Point(9, 4)
        Me.lblIssueID.Name = "lblIssueID"
        Me.lblIssueID.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblIssueID.R_ResourceId = "_CISSUE_ID"
        Me.lblIssueID.Size = New System.Drawing.Size(100, 18)
        Me.lblIssueID.TabIndex = 0
        Me.lblIssueID.Text = "R_RadLabel1"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.gvAttachment, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 144.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(678, 329)
        Me.TableLayoutPanel1.TabIndex = 1
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.txtIssueId)
        Me.Panel1.Controls.Add(Me.lblIssueID)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(672, 30)
        Me.Panel1.TabIndex = 0
        '
        'txtIssueId
        '
        Me.txtIssueId.Location = New System.Drawing.Point(115, 3)
        Me.txtIssueId.Name = "txtIssueId"
        Me.txtIssueId.R_ConductorGridSource = Nothing
        Me.txtIssueId.R_ConductorSource = Nothing
        Me.txtIssueId.R_UDT = Nothing
        Me.txtIssueId.ReadOnly = True
        Me.txtIssueId.Size = New System.Drawing.Size(106, 20)
        Me.txtIssueId.TabIndex = 1
        Me.txtIssueId.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.txtDescription)
        Me.Panel2.Controls.Add(Me.lblDescription)
        Me.Panel2.Controls.Add(Me.btnUpload)
        Me.Panel2.Controls.Add(Me.btnBrowse)
        Me.Panel2.Controls.Add(Me.txtFilename)
        Me.Panel2.Controls.Add(Me.lblFile)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 188)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(672, 138)
        Me.Panel2.TabIndex = 1
        '
        'txtDescription
        '
        Me.txtDescription.AcceptsReturn = True
        Me.txtDescription.AutoSize = False
        Me.txtDescription.Location = New System.Drawing.Point(115, 38)
        Me.txtDescription.Multiline = True
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.R_ConductorGridSource = Nothing
        Me.txtDescription.R_ConductorSource = Nothing
        Me.txtDescription.R_UDT = Nothing
        Me.txtDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtDescription.Size = New System.Drawing.Size(347, 91)
        Me.txtDescription.TabIndex = 7
        '
        'lblDescription
        '
        Me.lblDescription.AutoSize = False
        Me.lblDescription.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblDescription.Location = New System.Drawing.Point(9, 39)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblDescription.R_ResourceId = "_CDESCRIPTION"
        Me.lblDescription.Size = New System.Drawing.Size(100, 18)
        Me.lblDescription.TabIndex = 6
        Me.lblDescription.Text = "R_RadLabel3"
        '
        'btnUpload
        '
        Me.btnUpload.Location = New System.Drawing.Point(468, 36)
        Me.btnUpload.Name = "btnUpload"
        Me.btnUpload.R_ConductorGridSource = Nothing
        Me.btnUpload.R_ConductorSource = Nothing
        Me.btnUpload.R_DescriptionId = Nothing
        Me.btnUpload.R_ResourceId = "btnUpload"
        Me.btnUpload.Size = New System.Drawing.Size(110, 24)
        Me.btnUpload.TabIndex = 5
        Me.btnUpload.Text = "R_RadButton2"
        '
        'btnBrowse
        '
        Me.btnBrowse.Location = New System.Drawing.Point(468, 10)
        Me.btnBrowse.Name = "btnBrowse"
        Me.btnBrowse.R_ConductorGridSource = Nothing
        Me.btnBrowse.R_ConductorSource = Nothing
        Me.btnBrowse.R_DescriptionId = Nothing
        Me.btnBrowse.R_ResourceId = "btnBrowse"
        Me.btnBrowse.Size = New System.Drawing.Size(110, 24)
        Me.btnBrowse.TabIndex = 4
        Me.btnBrowse.Text = "R_RadButton1"
        '
        'txtFilename
        '
        Me.txtFilename.Location = New System.Drawing.Point(115, 12)
        Me.txtFilename.Name = "txtFilename"
        Me.txtFilename.R_ConductorGridSource = Nothing
        Me.txtFilename.R_ConductorSource = Nothing
        Me.txtFilename.R_UDT = Nothing
        Me.txtFilename.ReadOnly = True
        Me.txtFilename.Size = New System.Drawing.Size(347, 20)
        Me.txtFilename.TabIndex = 1
        Me.txtFilename.TabStop = False
        '
        'lblFile
        '
        Me.lblFile.AutoSize = False
        Me.lblFile.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblFile.Location = New System.Drawing.Point(9, 13)
        Me.lblFile.Name = "lblFile"
        Me.lblFile.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblFile.R_ResourceId = "lblFile"
        Me.lblFile.Size = New System.Drawing.Size(100, 18)
        Me.lblFile.TabIndex = 0
        Me.lblFile.Text = "R_RadLabel2"
        '
        'gvAttachment
        '
        Me.gvAttachment.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvAttachment.Location = New System.Drawing.Point(3, 39)
        '
        '
        '
        Me.gvAttachment.MasterTemplate.AllowAddNewRow = False
        Me.gvAttachment.MasterTemplate.AutoGenerateColumns = False
        Me.gvAttachment.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn1.FieldName = "_CFILE_NAME"
        R_GridViewTextBoxColumn1.HeaderText = "_CFILE_NAME"
        R_GridViewTextBoxColumn1.Name = "_CFILE_NAME"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CFILE_NAME"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 90
        R_GridViewTextBoxMultilineColumn1.FieldName = "_CDESCRIPTION"
        R_GridViewTextBoxMultilineColumn1.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxMultilineColumn1.Name = "_CDESCRIPTION"
        R_GridViewTextBoxMultilineColumn1.R_EnableADD = False
        R_GridViewTextBoxMultilineColumn1.R_EnableEDIT = True
        R_GridViewTextBoxMultilineColumn1.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxMultilineColumn1.R_UDT = Nothing
        R_GridViewTextBoxMultilineColumn1.ReadOnly = True
        R_GridViewTextBoxMultilineColumn1.Width = 563
        R_GridViewTextBoxMultilineColumn1.WrapText = True
        Me.gvAttachment.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxMultilineColumn1})
        Me.gvAttachment.MasterTemplate.DataSource = Me.bsGvAttachment
        Me.gvAttachment.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvAttachment.MasterTemplate.EnableFiltering = True
        Me.gvAttachment.MasterTemplate.EnableGrouping = False
        Me.gvAttachment.MasterTemplate.ShowFilteringRow = False
        Me.gvAttachment.MasterTemplate.ShowGroupedColumns = True
        Me.gvAttachment.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvAttachment.Name = "gvAttachment"
        Me.gvAttachment.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvAttachment.R_ConductorGridSource = Me.conGridAttach
        Me.gvAttachment.R_ConductorSource = Nothing
        Me.gvAttachment.R_DataAdded = False
        Me.gvAttachment.R_NewRowText = Nothing
        Me.gvAttachment.ShowHeaderCellButtons = True
        Me.gvAttachment.Size = New System.Drawing.Size(672, 143)
        Me.gvAttachment.TabIndex = 2
        Me.gvAttachment.Text = "R_RadGridView1"
        '
        'bsGvAttachment
        '
        Me.bsGvAttachment.DataSource = GetType(CST00200Front.CST00200AttachStreamingServiceRef.CST00200AttachGridDTO)
        '
        'conGridAttach
        '
        Me.conGridAttach.R_ConductorParent = Nothing
        Me.conGridAttach.R_IsHeader = True
        Me.conGridAttach.R_RadGroupBox = Nothing
        '
        'ofdAttach
        '
        '
        'CST00200Attach
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(678, 329)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CST00200Attach"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.lblIssueID, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.txtIssueId, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.txtDescription, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblDescription, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnUpload, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnBrowse, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtFilename, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblFile, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvAttachment.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvAttachment, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvAttachment, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridAttach, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lblIssueID As R_FrontEnd.R_RadLabel
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents txtIssueId As R_FrontEnd.R_RadTextBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents txtFilename As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblFile As R_FrontEnd.R_RadLabel
    Friend WithEvents gvAttachment As R_FrontEnd.R_RadGridView
    Friend WithEvents txtDescription As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblDescription As R_FrontEnd.R_RadLabel
    Friend WithEvents btnUpload As R_FrontEnd.R_RadButton
    Friend WithEvents btnBrowse As R_FrontEnd.R_RadButton
    Friend WithEvents ofdAttach As System.Windows.Forms.OpenFileDialog
    Friend WithEvents bsGvAttachment As System.Windows.Forms.BindingSource
    Friend WithEvents conGridAttach As R_FrontEnd.R_ConductorGrid

End Class
