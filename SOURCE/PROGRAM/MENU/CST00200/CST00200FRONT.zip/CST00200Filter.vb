﻿Imports CST00200Front.CST00200ServiceRef
Imports R_FrontEnd
Imports ClientHelper
Imports R_Common
Imports RCustDBFrontHelper

Public Class CST00200Filter

#Region " VARIABLE "
    Dim C_ServiceName As String = "CST00200Service/CST00200Service.svc"
    Dim C_ServiceNameStream As String = "CST00200Service/CST00200StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _LCUSTOM As Boolean
    Dim loFilterParam As New CST00200FilterParameterDTO
    Dim llRefreshCombo As Boolean
#End Region

#Region " SUBs and FUNCTIONs "

    Private Sub ComboManager(pcCode As String, pcValue As String, pcDisplay As String)
        Dim loSvc As CST00200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00200Service, CST00200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loProjectKey As New CST00200Front.CST00200ServiceRef.RCustDBProjectKeyDTO
        Dim lcValue As String = ""
        Dim lcDisplay As String = ""

        ' Refresh Combo
        With loProjectKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = loFilterParam.OFILTER_KEY.CAPPS_CODE
            .CVERSION = IIf(_LCUSTOM, loFilterParam.CCUSTOMER_CODE, loFilterParam.CVERSION)
            .CPROJECT_ID = loFilterParam.OFILTER_KEY.CPROJECT_ID
            .CSESSION_ID = loFilterParam.OFILTER_KEY.CSESSION_ID
            .CSTATUS = "*"
            .CUSER_ID = _CUSERID
        End With

        If pcValue IsNot Nothing Then
            lcValue = pcValue.Trim
        Else
            If Not pcCode.Equals("_INIT") Then
                Exit Sub
            End If
        End If
        If pcDisplay IsNot Nothing Then
            lcDisplay = pcDisplay
        End If

        With loFilterParam
            Select Case pcCode
                Case "_INIT"
                    ' initialize combo
                    cboVersion.Items.Clear()
                    cboProject.Items.Clear()
                    cboSession.Items.Clear()
                    cboSchedule.Items.Clear()
                    If .OAPPS_LIST Is Nothing Then
                        Dim loAppCombo As New List(Of RLicenseAppComboDTO)
                        loAppCombo = loSvc.GetAppCombo(_CCOMPID, _CUSERID)
                        If loAppCombo.Count <= 0 Then
                            cboApplication.Items.Clear()
                        End If
                        llRefreshCombo = True
                        bsApps.DataSource = loAppCombo
                        .OAPPS_LIST = loAppCombo
                    Else
                        llRefreshCombo = False
                        bsApps.DataSource = .OAPPS_LIST
                        cboApplication.SelectedValue = .OFILTER_KEY.CAPPS_CODE
                        rdbStandard.IsChecked = Not .LCUSTOM
                        rdbCustom.IsChecked = .LCUSTOM
                        bsVersion.DataSource = .OVERSION_LIST
                        cboVersion.SelectedValue = .CVERSION
                        txtCustomerCode.Text = .CCUSTOMER_CODE
                        txtCustomerName.Text = .CCUSTOMER_NAME
                        bsProject.DataSource = .OPROJECT_LIST
                        cboProject.SelectedValue = .OFILTER_KEY.CPROJECT_ID
                        bsSession.DataSource = .OSESSION_LIST
                        cboSession.SelectedValue = .OFILTER_KEY.CSESSION_ID
                        bsSchedule.DataSource = .OSCHEDULE_LIST
                        cboSchedule.SelectedValue = .OFILTER_KEY.CSCHEDULE_ID
                        llRefreshCombo = True
                    End If
                Case "_CAPPS_CODE"
                    If Not lcValue.Equals(.OFILTER_KEY.CAPPS_CODE) Then
                        .OVERSION_LIST = Nothing
                        .OPROJECT_LIST = Nothing
                        .OSESSION_LIST = Nothing
                        .OSCHEDULE_LIST = Nothing
                    End If
                    If .OVERSION_LIST Is Nothing Then
                        Dim loVersionCombo As New List(Of RCustDBVersionComboDTO)
                        .OFILTER_KEY.CAPPS_CODE = lcValue
                        loProjectKey.CAPPS_CODE = lcValue
                        .CAPPS_NAME = lcDisplay
                        loVersionCombo = loSvc.GetVersionCombo(_CCOMPID, lcValue)
                        If loVersionCombo.Count <= 0 Then
                            cboVersion.Items.Clear()
                            cboProject.Items.Clear()
                        End If
                        bsVersion.DataSource = loVersionCombo
                        .OVERSION_LIST = loVersionCombo
                    End If
                Case "_CVERSION"
                    If Not lcValue.Equals(.OFILTER_KEY.CVERSION) Then
                        .OPROJECT_LIST = Nothing
                        .OSESSION_LIST = Nothing
                        .OSCHEDULE_LIST = Nothing
                    End If
                    If .OPROJECT_LIST Is Nothing OrElse .OPROJECT_LIST.Count = 0 Then
                        Dim loProjectCombo As New List(Of RCustDBProjectComboDTO)
                        .OFILTER_KEY.CVERSION = lcValue
                        loProjectKey.CVERSION = lcValue
                        loProjectKey.CSTATUS = "*"
                        loProjectCombo = loSvc.GetProjectCombo(loProjectKey)
                        If loProjectCombo.Count <= 0 Then
                            cboProject.Items.Clear()
                            cboSession.Items.Clear()
                            cboSchedule.Items.Clear()
                        End If
                        bsProject.DataSource = loProjectCombo
                        .OPROJECT_LIST = loProjectCombo
                    End If
                    .LCUSTOM = _LCUSTOM
                Case "_CPROJECT_ID"
                    If Not lcValue.Equals(.OFILTER_KEY.CPROJECT_ID) Then
                        .OSESSION_LIST = Nothing
                        .OSCHEDULE_LIST = Nothing
                    End If
                    If .OSESSION_LIST Is Nothing OrElse .OSESSION_LIST.Count = 0 Then
                        Dim loSessionCombo As New List(Of RCustDBSessionComboDTO)
                        .OFILTER_KEY.CPROJECT_ID = lcValue
                        loProjectKey.CPROJECT_ID = lcValue
                        .CPROJECT_NAME = lcDisplay
                        loProjectKey.CSTATUS = "*"
                        loSessionCombo = loSvc.GetSessionCombo(loProjectKey)
                        If loSessionCombo.Count <= 0 Then
                            cboSession.Items.Clear()
                            cboSchedule.Items.Clear()
                        End If
                        bsSession.DataSource = loSessionCombo
                        .OSESSION_LIST = loSessionCombo
                    End If
                Case "_CSESSION_ID"
                    If Not lcValue.Equals(.OFILTER_KEY.CSESSION_ID) Then
                        .OSCHEDULE_LIST = Nothing
                    End If
                    If .OSCHEDULE_LIST Is Nothing OrElse .OSCHEDULE_LIST.Count = 0 Then
                        .OFILTER_KEY.CSESSION_ID = lcValue
                        loProjectKey.CSESSION_ID = lcValue
                        Dim loScheduleCombo As New List(Of RCustDBScheduleComboDTO)
                        loProjectKey.CSTATUS = "START"
                        loScheduleCombo = loSvc.GetScheduleCombo(loProjectKey)
                        If loScheduleCombo.Count <= 0 Then
                            cboSchedule.Items.Clear()
                        End If
                        bsSchedule.DataSource = loScheduleCombo
                        .OSCHEDULE_LIST = loScheduleCombo
                    End If

                    If bsSession.DataSource IsNot Nothing Then
                        If bsSession.Current IsNot Nothing Then
                            .CSESSION_STATUS = CType(bsSession.Current, RCustDBSessionComboDTO).CSTATUS
                        End If
                    End If
                Case "_CSCHEDULE_ID"
                    If Not lcValue.Equals(.OFILTER_KEY.CSCHEDULE_ID) Then
                        .OFILTER_KEY.CSCHEDULE_ID = lcValue
                    End If

                    If bsSchedule.DataSource IsNot Nothing Then
                        If bsSchedule.Current IsNot Nothing Then
                            .CSCHEDULE_DESCRIPTION = CType(bsSchedule.Current, RCustDBScheduleComboDTO).CSCHEDULE_DESCRIPTION
                            .CSCHEDULE_STATUS = CType(bsSchedule.Current, RCustDBScheduleComboDTO).CSTATUS
                        End If
                    End If
            End Select
        End With
        loSvc.Close()
    End Sub

    Private Sub EnableVerCust()
        _LCUSTOM = rdbCustom.IsChecked
        lblVersion.Visible = Not _LCUSTOM
        cboVersion.Enabled = Not _LCUSTOM
        cboVersion.Visible = Not _LCUSTOM
        lblCustomer.Visible = _LCUSTOM
        txtCustomerCode.Enabled = False
        lupCustomer.Enabled = _LCUSTOM
        txtCustomerCode.Visible = _LCUSTOM
        lupCustomer.Visible = _LCUSTOM
        txtCustomerName.Visible = _LCUSTOM
    End Sub

#End Region

#Region " COMBO Actions "

    Private Sub cboSession_Trigger(sender As Object, e As System.EventArgs) Handles cboSession.SelectedIndexChanged
        If llRefreshCombo Then
            ComboManager("_CSESSION_ID", sender.SelectedValue, sender.SelectedText)
        End If
    End Sub

    Private Sub cboApplication_Trigger(sender As Object, e As System.EventArgs) Handles cboApplication.SelectedIndexChanged
        If llRefreshCombo Then
            ComboManager("_CAPPS_CODE", sender.SelectedValue, sender.SelectedText)
        End If
    End Sub

    Private Sub cboVersion_Trigger(sender As Object, e As System.EventArgs) Handles cboVersion.SelectedIndexChanged
        If llRefreshCombo Then
            With loFilterParam
                .CVERSION = sender.SelectedValue
                .CCODE_NAME = sender.SelectedText
            End With
            ComboManager("_CVERSION", sender.SelectedValue, sender.SelectedText)
        End If
    End Sub

    Private Sub cboProject_Trigger(sender As Object, e As System.EventArgs) Handles cboProject.SelectedIndexChanged
        If llRefreshCombo Then
            ComboManager("_CPROJECT_ID", sender.SelectedValue, sender.SelectedText)
        End If
    End Sub

    Private Sub cboSchedule_Trigger(sender As Object, e As Telerik.WinControls.UI.Data.PositionChangedEventArgs) Handles cboSchedule.SelectedIndexChanged
        If llRefreshCombo Then
            ComboManager("_CSCHEDULE_ID", sender.SelectedValue, sender.SelectedText)
        End If
    End Sub

#End Region

#Region " FORM Methods "

    Private Sub R_ReturnPopUp1_R_SetPopUpResult(ByRef poEntityResult As Object) Handles R_ReturnPopUp1.R_SetPopUpResult
        poEntityResult = loFilterParam
    End Sub

    Private Sub CST00200Filter_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim loEx As New R_Exception

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            loFilterParam = poParameter
            ComboManager("_INIT", Nothing, Nothing)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " LOOKUP Events "

    Private Sub R_LookUp1_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles lupCustomer.R_Before_Open_Form
        poTargetForm = New CustList
        poParameter = New FileStreamingServiceRef.RCustDBFileKeyDTO With {.CCOMPANY_ID = _CCOMPID}
    End Sub

    Private Sub R_LookUp1_R_Return_LookUp(poReturnObject As Object) Handles lupCustomer.R_Return_LookUp
        txtCustomerCode.Text = poReturnObject.CCUSTOMER_CODE
        txtCustomerName.Text = poReturnObject.CCUSTOMER_NAME
        With loFilterParam
            .CCUSTOMER_CODE = txtCustomerCode.Text
            .CCUSTOMER_NAME = txtCustomerName.Text
            ComboManager("_CVERSION", .CCUSTOMER_CODE, .CCUSTOMER_NAME)
        End With
    End Sub

#End Region

#Region " RADIO BUTTON Actions "

    Private Sub rdbStandard_CheckStateChanged(sender As Object, e As System.EventArgs) Handles rdbStandard.CheckStateChanged
        If CType(sender, R_RadRadioButton).IsChecked Then
            EnableVerCust()
            If llRefreshCombo Then
                ComboManager("_CVERSION", cboVersion.SelectedValue, cboVersion.SelectedText)
            End If
        End If
    End Sub

    Private Sub rdbCustom_CheckStateChanged(sender As Object, e As System.EventArgs) Handles rdbCustom.CheckStateChanged
        If CType(sender, R_RadRadioButton).IsChecked Then
            EnableVerCust()
            If llRefreshCombo Then
                ComboManager("_CVERSION", txtCustomerCode.Text, txtCustomerName.Text)
            End If
        End If
    End Sub

#End Region

End Class
