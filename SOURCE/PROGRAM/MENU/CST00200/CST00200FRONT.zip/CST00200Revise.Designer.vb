﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CST00200Revise
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewLookUpColumn1 As R_FrontEnd.R_GridViewLookUpColumn = New R_FrontEnd.R_GridViewLookUpColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewComboBoxColumn1 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Dim R_GridViewComboBoxColumn2 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Dim R_GridViewLookUpColumn2 As R_FrontEnd.R_GridViewLookUpColumn = New R_FrontEnd.R_GridViewLookUpColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn6 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn1 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Me.bsIssueClass = New System.Windows.Forms.BindingSource()
        Me.bsIssueType = New System.Windows.Forms.BindingSource()
        Me.bsFunction = New System.Windows.Forms.BindingSource()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtDescription = New R_FrontEnd.R_RadTextBox()
        Me.lblDescription = New R_FrontEnd.R_RadLabel()
        Me.lblIssueTo = New R_FrontEnd.R_RadLabel()
        Me.txtIssueType = New R_FrontEnd.R_RadTextBox()
        Me.lblIssueClass = New R_FrontEnd.R_RadLabel()
        Me.txtIssueClass = New R_FrontEnd.R_RadTextBox()
        Me.txtIssue = New R_FrontEnd.R_RadTextBox()
        Me.txtItem = New R_FrontEnd.R_RadTextBox()
        Me.txtAttribute = New R_FrontEnd.R_RadTextBox()
        Me.lblIssue = New R_FrontEnd.R_RadLabel()
        Me.lblAttribute = New R_FrontEnd.R_RadLabel()
        Me.lblItem = New R_FrontEnd.R_RadLabel()
        Me.lblSchedule = New R_FrontEnd.R_RadLabel()
        Me.txtSchedule = New R_FrontEnd.R_RadTextBox()
        Me.lblSession = New R_FrontEnd.R_RadLabel()
        Me.txtSession = New R_FrontEnd.R_RadTextBox()
        Me.txtProject = New R_FrontEnd.R_RadTextBox()
        Me.txtVersion = New R_FrontEnd.R_RadTextBox()
        Me.txtApplication = New R_FrontEnd.R_RadTextBox()
        Me.lblProject = New R_FrontEnd.R_RadLabel()
        Me.lblApplication = New R_FrontEnd.R_RadLabel()
        Me.lblVersion = New R_FrontEnd.R_RadLabel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnAttachment = New R_FrontEnd.R_PopUp()
        Me.conGridIssue = New R_FrontEnd.R_ConductorGrid()
        Me.lblIssueList = New R_FrontEnd.R_RadLabel()
        Me.gvIssue = New R_FrontEnd.R_RadGridView()
        Me.bsGvIssue = New System.Windows.Forms.BindingSource()
        CType(Me.bsIssueClass, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsIssueType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsFunction, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.txtDescription, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblDescription, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblIssueTo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtIssueType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblIssueClass, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtIssueClass, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtAttribute, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblAttribute, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.btnAttachment, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblIssueList, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvIssue.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'bsIssueClass
        '
        Me.bsIssueClass.DataSource = GetType(CST00200Front.CST00200ServiceRef.CST00200IssueClassComboDTO)
        '
        'bsIssueType
        '
        Me.bsIssueType.DataSource = GetType(CST00200Front.CST00200ServiceRef.CST00200IssueTypeComboDTO)
        '
        'bsFunction
        '
        Me.bsFunction.DataSource = GetType(CST00200Front.CST00200ServiceRef.RCustDBFunctionComboDTO)
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 150.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.txtDescription)
        Me.Panel1.Controls.Add(Me.lblDescription)
        Me.Panel1.Controls.Add(Me.lblIssueTo)
        Me.Panel1.Controls.Add(Me.txtIssueType)
        Me.Panel1.Controls.Add(Me.lblIssueClass)
        Me.Panel1.Controls.Add(Me.txtIssueClass)
        Me.Panel1.Controls.Add(Me.txtIssue)
        Me.Panel1.Controls.Add(Me.txtItem)
        Me.Panel1.Controls.Add(Me.txtAttribute)
        Me.Panel1.Controls.Add(Me.lblIssue)
        Me.Panel1.Controls.Add(Me.lblAttribute)
        Me.Panel1.Controls.Add(Me.lblItem)
        Me.Panel1.Controls.Add(Me.lblSchedule)
        Me.Panel1.Controls.Add(Me.txtSchedule)
        Me.Panel1.Controls.Add(Me.lblSession)
        Me.Panel1.Controls.Add(Me.txtSession)
        Me.Panel1.Controls.Add(Me.txtProject)
        Me.Panel1.Controls.Add(Me.txtVersion)
        Me.Panel1.Controls.Add(Me.txtApplication)
        Me.Panel1.Controls.Add(Me.lblProject)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Controls.Add(Me.lblVersion)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 144)
        Me.Panel1.TabIndex = 1
        '
        'txtDescription
        '
        Me.txtDescription.AcceptsReturn = True
        Me.txtDescription.AutoSize = False
        Me.txtDescription.Location = New System.Drawing.Point(739, 8)
        Me.txtDescription.Multiline = True
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.R_ConductorGridSource = Nothing
        Me.txtDescription.R_ConductorSource = Nothing
        Me.txtDescription.R_UDT = Nothing
        Me.txtDescription.ReadOnly = True
        Me.txtDescription.Size = New System.Drawing.Size(312, 123)
        Me.txtDescription.TabIndex = 67
        Me.txtDescription.TabStop = False
        '
        'lblDescription
        '
        Me.lblDescription.AutoSize = False
        Me.lblDescription.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblDescription.Location = New System.Drawing.Point(633, 9)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblDescription.R_ResourceId = "lblDescription"
        Me.lblDescription.Size = New System.Drawing.Size(100, 18)
        Me.lblDescription.TabIndex = 66
        Me.lblDescription.Text = "Application..."
        '
        'lblIssueTo
        '
        Me.lblIssueTo.AutoSize = False
        Me.lblIssueTo.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblIssueTo.Location = New System.Drawing.Point(321, 113)
        Me.lblIssueTo.Name = "lblIssueTo"
        Me.lblIssueTo.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblIssueTo.R_ResourceId = "lblIssueTo"
        Me.lblIssueTo.Size = New System.Drawing.Size(100, 18)
        Me.lblIssueTo.TabIndex = 65
        Me.lblIssueTo.Text = "Application..."
        '
        'txtIssueType
        '
        Me.txtIssueType.Location = New System.Drawing.Point(427, 112)
        Me.txtIssueType.Name = "txtIssueType"
        Me.txtIssueType.R_ConductorGridSource = Nothing
        Me.txtIssueType.R_ConductorSource = Nothing
        Me.txtIssueType.R_UDT = Nothing
        Me.txtIssueType.ReadOnly = True
        Me.txtIssueType.Size = New System.Drawing.Size(200, 20)
        Me.txtIssueType.TabIndex = 64
        Me.txtIssueType.TabStop = False
        '
        'lblIssueClass
        '
        Me.lblIssueClass.AutoSize = False
        Me.lblIssueClass.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblIssueClass.Location = New System.Drawing.Point(321, 87)
        Me.lblIssueClass.Name = "lblIssueClass"
        Me.lblIssueClass.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblIssueClass.R_ResourceId = "lblIssueClass"
        Me.lblIssueClass.Size = New System.Drawing.Size(100, 18)
        Me.lblIssueClass.TabIndex = 63
        Me.lblIssueClass.Text = "Application..."
        '
        'txtIssueClass
        '
        Me.txtIssueClass.Location = New System.Drawing.Point(427, 86)
        Me.txtIssueClass.Name = "txtIssueClass"
        Me.txtIssueClass.R_ConductorGridSource = Nothing
        Me.txtIssueClass.R_ConductorSource = Nothing
        Me.txtIssueClass.R_UDT = Nothing
        Me.txtIssueClass.ReadOnly = True
        Me.txtIssueClass.Size = New System.Drawing.Size(200, 20)
        Me.txtIssueClass.TabIndex = 62
        Me.txtIssueClass.TabStop = False
        '
        'txtIssue
        '
        Me.txtIssue.Location = New System.Drawing.Point(427, 60)
        Me.txtIssue.Name = "txtIssue"
        Me.txtIssue.R_ConductorGridSource = Nothing
        Me.txtIssue.R_ConductorSource = Nothing
        Me.txtIssue.R_UDT = Nothing
        Me.txtIssue.ReadOnly = True
        Me.txtIssue.Size = New System.Drawing.Size(200, 20)
        Me.txtIssue.TabIndex = 61
        Me.txtIssue.TabStop = False
        '
        'txtItem
        '
        Me.txtItem.Location = New System.Drawing.Point(427, 34)
        Me.txtItem.Name = "txtItem"
        Me.txtItem.R_ConductorGridSource = Nothing
        Me.txtItem.R_ConductorSource = Nothing
        Me.txtItem.R_UDT = Nothing
        Me.txtItem.ReadOnly = True
        Me.txtItem.Size = New System.Drawing.Size(200, 20)
        Me.txtItem.TabIndex = 60
        Me.txtItem.TabStop = False
        '
        'txtAttribute
        '
        Me.txtAttribute.Location = New System.Drawing.Point(427, 8)
        Me.txtAttribute.Name = "txtAttribute"
        Me.txtAttribute.R_ConductorGridSource = Nothing
        Me.txtAttribute.R_ConductorSource = Nothing
        Me.txtAttribute.R_UDT = Nothing
        Me.txtAttribute.ReadOnly = True
        Me.txtAttribute.Size = New System.Drawing.Size(200, 20)
        Me.txtAttribute.TabIndex = 59
        Me.txtAttribute.TabStop = False
        '
        'lblIssue
        '
        Me.lblIssue.AutoSize = False
        Me.lblIssue.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblIssue.Location = New System.Drawing.Point(321, 61)
        Me.lblIssue.Name = "lblIssue"
        Me.lblIssue.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblIssue.R_ResourceId = "lblIssue"
        Me.lblIssue.Size = New System.Drawing.Size(100, 18)
        Me.lblIssue.TabIndex = 58
        Me.lblIssue.Text = "Application..."
        '
        'lblAttribute
        '
        Me.lblAttribute.AutoSize = False
        Me.lblAttribute.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblAttribute.Location = New System.Drawing.Point(321, 9)
        Me.lblAttribute.Name = "lblAttribute"
        Me.lblAttribute.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblAttribute.R_ResourceId = "lblAttribute"
        Me.lblAttribute.Size = New System.Drawing.Size(100, 18)
        Me.lblAttribute.TabIndex = 56
        Me.lblAttribute.Text = "Application..."
        '
        'lblItem
        '
        Me.lblItem.AutoSize = False
        Me.lblItem.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblItem.Location = New System.Drawing.Point(321, 35)
        Me.lblItem.Name = "lblItem"
        Me.lblItem.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblItem.R_ResourceId = "lblItem"
        Me.lblItem.Size = New System.Drawing.Size(100, 18)
        Me.lblItem.TabIndex = 57
        Me.lblItem.Text = "Application..."
        '
        'lblSchedule
        '
        Me.lblSchedule.AutoSize = False
        Me.lblSchedule.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblSchedule.Location = New System.Drawing.Point(9, 113)
        Me.lblSchedule.Name = "lblSchedule"
        Me.lblSchedule.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblSchedule.R_ResourceId = "lblSchedule"
        Me.lblSchedule.Size = New System.Drawing.Size(100, 18)
        Me.lblSchedule.TabIndex = 55
        Me.lblSchedule.Text = "Application..."
        '
        'txtSchedule
        '
        Me.txtSchedule.Location = New System.Drawing.Point(115, 112)
        Me.txtSchedule.Name = "txtSchedule"
        Me.txtSchedule.R_ConductorGridSource = Nothing
        Me.txtSchedule.R_ConductorSource = Nothing
        Me.txtSchedule.R_UDT = Nothing
        Me.txtSchedule.ReadOnly = True
        Me.txtSchedule.Size = New System.Drawing.Size(200, 20)
        Me.txtSchedule.TabIndex = 54
        Me.txtSchedule.TabStop = False
        '
        'lblSession
        '
        Me.lblSession.AutoSize = False
        Me.lblSession.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblSession.Location = New System.Drawing.Point(9, 87)
        Me.lblSession.Name = "lblSession"
        Me.lblSession.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblSession.R_ResourceId = "lblSession"
        Me.lblSession.Size = New System.Drawing.Size(100, 18)
        Me.lblSession.TabIndex = 52
        Me.lblSession.Text = "Application..."
        '
        'txtSession
        '
        Me.txtSession.Location = New System.Drawing.Point(115, 86)
        Me.txtSession.Name = "txtSession"
        Me.txtSession.R_ConductorGridSource = Nothing
        Me.txtSession.R_ConductorSource = Nothing
        Me.txtSession.R_UDT = Nothing
        Me.txtSession.ReadOnly = True
        Me.txtSession.Size = New System.Drawing.Size(200, 20)
        Me.txtSession.TabIndex = 51
        Me.txtSession.TabStop = False
        '
        'txtProject
        '
        Me.txtProject.Location = New System.Drawing.Point(115, 60)
        Me.txtProject.Name = "txtProject"
        Me.txtProject.R_ConductorGridSource = Nothing
        Me.txtProject.R_ConductorSource = Nothing
        Me.txtProject.R_UDT = Nothing
        Me.txtProject.ReadOnly = True
        Me.txtProject.Size = New System.Drawing.Size(200, 20)
        Me.txtProject.TabIndex = 50
        Me.txtProject.TabStop = False
        '
        'txtVersion
        '
        Me.txtVersion.Location = New System.Drawing.Point(115, 34)
        Me.txtVersion.Name = "txtVersion"
        Me.txtVersion.R_ConductorGridSource = Nothing
        Me.txtVersion.R_ConductorSource = Nothing
        Me.txtVersion.R_UDT = Nothing
        Me.txtVersion.ReadOnly = True
        Me.txtVersion.Size = New System.Drawing.Size(200, 20)
        Me.txtVersion.TabIndex = 49
        Me.txtVersion.TabStop = False
        '
        'txtApplication
        '
        Me.txtApplication.Location = New System.Drawing.Point(115, 8)
        Me.txtApplication.Name = "txtApplication"
        Me.txtApplication.R_ConductorGridSource = Nothing
        Me.txtApplication.R_ConductorSource = Nothing
        Me.txtApplication.R_UDT = Nothing
        Me.txtApplication.ReadOnly = True
        Me.txtApplication.Size = New System.Drawing.Size(200, 20)
        Me.txtApplication.TabIndex = 48
        Me.txtApplication.TabStop = False
        '
        'lblProject
        '
        Me.lblProject.AutoSize = False
        Me.lblProject.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblProject.Location = New System.Drawing.Point(9, 61)
        Me.lblProject.Name = "lblProject"
        Me.lblProject.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblProject.R_ResourceId = "lblProject"
        Me.lblProject.Size = New System.Drawing.Size(100, 18)
        Me.lblProject.TabIndex = 33
        Me.lblProject.Text = "Application..."
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 30
        Me.lblApplication.Text = "Application..."
        '
        'lblVersion
        '
        Me.lblVersion.AutoSize = False
        Me.lblVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblVersion.Location = New System.Drawing.Point(9, 35)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblVersion.R_ResourceId = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(100, 18)
        Me.lblVersion.TabIndex = 32
        Me.lblVersion.Text = "Application..."
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.btnAttachment)
        Me.Panel2.Controls.Add(Me.lblIssueList)
        Me.Panel2.Controls.Add(Me.gvIssue)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 153)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1271, 419)
        Me.Panel2.TabIndex = 5
        '
        'btnAttachment
        '
        Me.btnAttachment.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnAttachment.Location = New System.Drawing.Point(1152, 3)
        Me.btnAttachment.Name = "btnAttachment"
        Me.btnAttachment.R_ConductorGridSource = Me.conGridIssue
        Me.btnAttachment.R_ConductorSource = Nothing
        Me.btnAttachment.R_DescriptionId = Nothing
        Me.btnAttachment.R_EnableHASDATA = True
        Me.btnAttachment.R_ResourceId = "btnAttachment"
        Me.btnAttachment.R_Title = Nothing
        Me.btnAttachment.Size = New System.Drawing.Size(110, 24)
        Me.btnAttachment.TabIndex = 2
        Me.btnAttachment.Text = "R_PopUp1"
        '
        'conGridIssue
        '
        Me.conGridIssue.R_ConductorParent = Nothing
        Me.conGridIssue.R_IsHeader = True
        Me.conGridIssue.R_RadGroupBox = Nothing
        '
        'lblIssueList
        '
        Me.lblIssueList.AutoSize = False
        Me.lblIssueList.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblIssueList.Location = New System.Drawing.Point(9, 6)
        Me.lblIssueList.Name = "lblIssueList"
        Me.lblIssueList.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblIssueList.R_ResourceId = "lblIssueList"
        Me.lblIssueList.Size = New System.Drawing.Size(100, 18)
        Me.lblIssueList.TabIndex = 1
        Me.lblIssueList.Text = "R_RadLabel1"
        '
        'gvIssue
        '
        Me.gvIssue.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gvIssue.AutoSizeRows = True
        Me.gvIssue.EnableFastScrolling = True
        Me.gvIssue.Location = New System.Drawing.Point(0, 30)
        '
        '
        '
        Me.gvIssue.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn1.FieldName = "_CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn1.HeaderText = "_CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn1.Name = "_CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 131
        R_GridViewTextBoxColumn2.FieldName = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn2.HeaderText = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn2.Name = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 104
        R_GridViewLookUpColumn1.FieldName = "_CITEM_ID"
        R_GridViewLookUpColumn1.HeaderText = "_CITEM_ID"
        R_GridViewLookUpColumn1.Name = "_CITEM_ID"
        R_GridViewLookUpColumn1.R_EnableADD = True
        R_GridViewLookUpColumn1.R_ResourceId = "_CITEM_ID"
        R_GridViewLookUpColumn1.R_Title = Nothing
        R_GridViewLookUpColumn1.Width = 74
        R_GridViewTextBoxColumn3.FieldName = "_CISSUE_ID"
        R_GridViewTextBoxColumn3.HeaderText = "_CISSUE_ID"
        R_GridViewTextBoxColumn3.MaxLength = 15
        R_GridViewTextBoxColumn3.Name = "_CISSUE_ID"
        R_GridViewTextBoxColumn3.R_EnableADD = True
        R_GridViewTextBoxColumn3.R_ResourceId = "_CISSUE_ID"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 78
        R_GridViewTextBoxColumn4.FieldName = "_CUSER_ID"
        R_GridViewTextBoxColumn4.HeaderText = "_CUSER_ID"
        R_GridViewTextBoxColumn4.Name = "_CUSER_ID"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CUSER_ID"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 76
        R_GridViewDateTimeColumn1.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn1.FieldName = "_DISSUE_DATE"
        R_GridViewDateTimeColumn1.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn1.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn1.HeaderText = "_DISSUE_DATE"
        R_GridViewDateTimeColumn1.Name = "_DISSUE_DATE"
        R_GridViewDateTimeColumn1.R_ResourceId = "_DISSUE_DATE"
        R_GridViewDateTimeColumn1.Width = 95
        R_GridViewComboBoxColumn1.DataSource = Me.bsIssueClass
        R_GridViewComboBoxColumn1.DisplayMember = "CDESCRIPTION"
        R_GridViewComboBoxColumn1.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDown
        R_GridViewComboBoxColumn1.FieldName = "_CISSUE_CLASS"
        R_GridViewComboBoxColumn1.HeaderText = "_CISSUE_CLASS"
        R_GridViewComboBoxColumn1.Name = "_CISSUE_CLASS"
        R_GridViewComboBoxColumn1.R_EnableADD = True
        R_GridViewComboBoxColumn1.R_EnableEDIT = True
        R_GridViewComboBoxColumn1.R_ResourceId = "_CISSUE_CLASS"
        R_GridViewComboBoxColumn1.ValueMember = "CISSUE_CLASS"
        R_GridViewComboBoxColumn1.Width = 99
        R_GridViewComboBoxColumn2.DataSource = Me.bsIssueType
        R_GridViewComboBoxColumn2.DisplayMember = "CDESCRIPTION"
        R_GridViewComboBoxColumn2.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDown
        R_GridViewComboBoxColumn2.FieldName = "_CISSUE_TYPE"
        R_GridViewComboBoxColumn2.HeaderText = "_CISSUE_TYPE"
        R_GridViewComboBoxColumn2.Name = "_CISSUE_TYPE"
        R_GridViewComboBoxColumn2.R_EnableADD = True
        R_GridViewComboBoxColumn2.R_EnableEDIT = True
        R_GridViewComboBoxColumn2.R_ResourceId = "_CISSUE_TYPE"
        R_GridViewComboBoxColumn2.ValueMember = "CISSUE_TYPE"
        R_GridViewComboBoxColumn2.Width = 91
        R_GridViewLookUpColumn2.FieldName = "_CDESCRIPTION"
        R_GridViewLookUpColumn2.HeaderText = "_CDESCRIPTION"
        R_GridViewLookUpColumn2.Name = "_CDESCRIPTION"
        R_GridViewLookUpColumn2.R_EnableADD = True
        R_GridViewLookUpColumn2.R_EnableEDIT = True
        R_GridViewLookUpColumn2.R_ResourceId = "_CDESCRIPTION"
        R_GridViewLookUpColumn2.R_Title = "Description"
        R_GridViewLookUpColumn2.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        R_GridViewLookUpColumn2.Width = 103
        R_GridViewLookUpColumn2.WrapText = True
        R_GridViewTextBoxColumn5.FieldName = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn5.HeaderText = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn5.Name = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 103
        R_GridViewTextBoxColumn6.FieldName = "_CPREV_SCHEDULE_ID"
        R_GridViewTextBoxColumn6.HeaderText = "_CPREV_SCHEDULE_ID"
        R_GridViewTextBoxColumn6.Name = "_CPREV_SCHEDULE_ID"
        R_GridViewTextBoxColumn6.R_ResourceId = "_CPREV_SCHEDULE_ID"
        R_GridViewTextBoxColumn6.R_UDT = Nothing
        R_GridViewTextBoxColumn6.Width = 134
        R_GridViewCheckBoxColumn1.FieldName = "_LOK"
        R_GridViewCheckBoxColumn1.HeaderText = "_LOK"
        R_GridViewCheckBoxColumn1.Name = "_LOK"
        R_GridViewCheckBoxColumn1.R_EnableEDIT = True
        R_GridViewCheckBoxColumn1.R_ResourceId = "_LOK"
        R_GridViewCheckBoxColumn1.Width = 62
        Me.gvIssue.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewLookUpColumn1, R_GridViewTextBoxColumn3, R_GridViewTextBoxColumn4, R_GridViewDateTimeColumn1, R_GridViewComboBoxColumn1, R_GridViewComboBoxColumn2, R_GridViewLookUpColumn2, R_GridViewTextBoxColumn5, R_GridViewTextBoxColumn6, R_GridViewCheckBoxColumn1})
        Me.gvIssue.MasterTemplate.DataSource = Me.bsGvIssue
        Me.gvIssue.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvIssue.MasterTemplate.EnableFiltering = True
        Me.gvIssue.MasterTemplate.EnableGrouping = False
        Me.gvIssue.MasterTemplate.ShowFilteringRow = False
        Me.gvIssue.MasterTemplate.ShowGroupedColumns = True
        Me.gvIssue.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvIssue.Name = "gvIssue"
        Me.gvIssue.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvIssue.R_ConductorGridSource = Me.conGridIssue
        Me.gvIssue.R_ConductorSource = Nothing
        Me.gvIssue.R_DataAdded = False
        Me.gvIssue.R_NewRowText = Nothing
        Me.gvIssue.ShowHeaderCellButtons = True
        Me.gvIssue.Size = New System.Drawing.Size(1271, 389)
        Me.gvIssue.TabIndex = 0
        Me.gvIssue.Text = "R_RadGridView1"
        '
        'bsGvIssue
        '
        Me.bsGvIssue.DataSource = GetType(CST00200Front.CST00200StreamingServiceRef.CST00200GridDTO)
        '
        'CST00200Revise
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CST00200Revise"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.bsIssueClass, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsIssueType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsFunction, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.txtDescription, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblDescription, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblIssueTo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtIssueType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblIssueClass, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtIssueClass, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtIssue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtAttribute, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblIssue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblAttribute, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        CType(Me.btnAttachment, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridIssue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblIssueList, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvIssue.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvIssue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvIssue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblProject As R_FrontEnd.R_RadLabel
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents lblVersion As R_FrontEnd.R_RadLabel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents gvIssue As R_FrontEnd.R_RadGridView
    Friend WithEvents bsGvIssue As System.Windows.Forms.BindingSource
    Friend WithEvents bsFunction As System.Windows.Forms.BindingSource
    Friend WithEvents bsIssueClass As System.Windows.Forms.BindingSource
    Friend WithEvents lblIssueList As R_FrontEnd.R_RadLabel
    Friend WithEvents btnAttachment As R_FrontEnd.R_PopUp
    Friend WithEvents txtSession As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtProject As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtVersion As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtApplication As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblSession As R_FrontEnd.R_RadLabel
    Friend WithEvents lblSchedule As R_FrontEnd.R_RadLabel
    Friend WithEvents txtSchedule As R_FrontEnd.R_RadTextBox
    Friend WithEvents bsIssueType As System.Windows.Forms.BindingSource
    Friend WithEvents txtDescription As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblDescription As R_FrontEnd.R_RadLabel
    Friend WithEvents lblIssueTo As R_FrontEnd.R_RadLabel
    Friend WithEvents txtIssueType As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblIssueClass As R_FrontEnd.R_RadLabel
    Friend WithEvents txtIssueClass As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtIssue As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtItem As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtAttribute As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblIssue As R_FrontEnd.R_RadLabel
    Friend WithEvents lblAttribute As R_FrontEnd.R_RadLabel
    Friend WithEvents lblItem As R_FrontEnd.R_RadLabel
    Friend WithEvents conGridIssue As R_FrontEnd.R_ConductorGrid

End Class
