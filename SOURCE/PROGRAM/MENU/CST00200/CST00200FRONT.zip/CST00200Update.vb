﻿Imports CST00200FrontResources
Imports R_Common
'Imports CST00200Front.CST00200ReviseServiceRef
Imports CST00200Front.CST00200ServiceRef
Imports CST00200Front.CST00200StreamingServiceRef
Imports ClientHelper
Imports R_FrontEnd
Imports System.ServiceModel.Channels
Imports RCustDBFrontHelper

Public Class CST00200Update

#Region " VARIABLE "
    Dim C_ServiceName As String = "CST00200Service/CST00200Service.svc"
    Dim C_ServiceNameStream As String = "CST00200Service/CST00200StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _CVERSION As String
    Dim _CPROJECTID As String
    Dim _CSESSIONID As String
    Dim _CSCHEDULEID As String
    Dim _CUSER_NAME As String
    Dim _CFUNCTIONID As String
    Dim _LINIT As Boolean
    Dim _CATTRIBUTEGROUP As String
    Dim _CATTRIBUTEID As String
    Dim _CITEMID As String
    Dim _CACTION As String
    Dim _CISSUE_ID As String
    Dim _OISSUE_CLIPBOARD As CST00200GridDTO

#End Region

#Region " SUBs and FUNCTIONs "

    Private Sub RefreshGrids(poKey As CST00200ReviseParameterDTO)
        If _LINIT Then
            With gvIssue
                .R_RefreshGrid(poKey)
            End With
        End If
    End Sub

#End Region

#Region " FORM Events "

    Private Sub CST00200_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Try
            _LINIT = False
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            _CFUNCTIONID = "QC"
            _LINIT = True
            _OISSUE_CLIPBOARD = New CST00200GridDTO
            With CType(poParameter, CST00200ReviseParameterDTO)
                _CAPPSCODE = .OFILTER_KEY.CAPPS_CODE
                _CVERSION = .OFILTER_KEY.CVERSION
                _CPROJECTID = .OFILTER_KEY.CPROJECT_ID
                _CSESSIONID = .OFILTER_KEY.CSESSION_ID
                _CATTRIBUTEGROUP = .OFILTER_KEY.CATTRIBUTE_GROUP
                _CATTRIBUTEID = .OFILTER_KEY.CATTRIBUTE_ID
                _CISSUE_ID = .OFILTER_KEY.CISSUE_ID
                _CSCHEDULEID = .OFILTER_KEY.CSCHEDULE_ID
                _CITEMID = .OFILTER_KEY.CITEM_ID
                txtApplication.Text = .CAPPS_NAME
                txtVersion.Text = .OFILTER_KEY.CVERSION
                txtProject.Text = .CPROJECT_NAME
                txtSession.Text = .OFILTER_KEY.CSESSION_ID
                txtSchedule.Text = .OFILTER_KEY.CSCHEDULE_ID
                bsIssueClass.DataSource = .OISSUE_CLASS_LIST
                bsIssueType.DataSource = .OISSUE_TYPE_LIST
            End With
            RefreshGrids(poParameter)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub CST00200_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " ISSUE Gridview "

    Private Sub gvIssue_CellValueChanged(sender As Object, e As Telerik.WinControls.UI.GridViewCellEventArgs) Handles gvIssue.CellValueChanged
        If e.Column.Name.Equals("_CISSUE_CLASS") Then
            e.Row.Cells("_CISSUE_TYPE").Value = CType(bsIssueClass.Current, CST00200Front.CST00200ServiceRef.CST00200IssueClassComboDTO).CISSUE_TYPE.ToString
        End If
    End Sub

    Private Sub gvIssue_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvIssue.DataBindingComplete
        With gvIssue
            '.BestFitColumns()
            .Columns("_CDESCRIPTION").Width = 360
        End With
    End Sub

    Private Sub gvIssue_R_AfterAdd(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection) Handles gvIssue.R_AfterAdd
        With poGridCellCollection
            .Item("_CISSUE_ID").Value = _CISSUE_ID
        End With
    End Sub

    Private Sub gvIssue_R_Before_Open_LookUpForm(sender As Object, e As Telerik.WinControls.UI.EditorRequiredEventArgs, ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles gvIssue.R_Before_Open_LookUpForm
        If gvIssue.CurrentColumn.Name.Trim.Equals("_CDESCRIPTION") Then
            poTargetForm = New CST00200Description
            poParameter = New CST00200DTO With {._CDESCRIPTION = gvIssue.CurrentRow.Cells("_CDESCRIPTION").Value}
        ElseIf gvIssue.CurrentColumn.Name.Trim.Equals("_CITEM_ID") Then
            poTargetForm = New CST00200ItemList
            poParameter = New CST00200KeyDTO With {.CCOMPANY_ID = _CCOMPID, _
                                                        .CAPPS_CODE = _CAPPSCODE, _
                                                        .CVERSION = _CVERSION, _
                                                        .CPROJECT_ID = _CPROJECTID, _
                                                        .CSESSION_ID = _CSESSIONID}
        End If
    End Sub

    Private Sub gvIssue_R_CheckGridAdd(poEntityCollection As Object, ByRef plAllowGridAdd As Boolean) Handles gvIssue.R_CheckGridAdd
        plAllowGridAdd = False
    End Sub

    Private Sub gvIssue_R_CheckGridDelete(poEntityCollection As Object, ByRef plAllowGridDelete As Boolean) Handles gvIssue.R_CheckGridDelete
        plAllowGridDelete = False
    End Sub

    Private Sub gvIssue_R_CheckGridEdit(poEntityCollection As Object, ByRef plAllowGridEdit As Boolean) Handles gvIssue.R_CheckGridEdit
        plAllowGridEdit = True
    End Sub

    Private Sub gvIssue_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvIssue.R_Display
        _CISSUE_ID = CType(bsGvIssue.Current, CST00200DTO)._CISSUE_ID
        _CITEMID = CType(bsGvIssue.Current, CST00200DTO)._CITEM_ID
    End Sub

    Private Sub gvIssue_R_Return_LookUp(sender As Object, e As Telerik.WinControls.UI.EditorRequiredEventArgs, poReturnObject As Object) Handles gvIssue.R_Return_LookUp
        If gvIssue.CurrentColumn.Name.Trim.Equals("_CDESCRIPTION") Then
            e.Editor.Value = poReturnObject._CDESCRIPTION
        ElseIf gvIssue.CurrentColumn.Name.Trim.Equals("_CITEM_ID") Then
            gvIssue.CurrentRow.Cells("_CITEM_ID").Value = poReturnObject.CITEM_ID
            gvIssue.CurrentRow.Cells("_CATTRIBUTE_GROUP").Value = poReturnObject.CATTRIBUTE_GROUP
            gvIssue.CurrentRow.Cells("_CATTRIBUTE_ID").Value = poReturnObject.CATTRIBUTE_ID
        End If
    End Sub

    Private Sub gvIssue_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvIssue.R_Saving
        With CType(poEntity, CST00200DTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = _CAPPSCODE
            ._CVERSION = _CVERSION
            ._CPROJECT_ID = _CPROJECTID
            ._CSESSION_ID = _CSESSIONID
            ._CUSER_ID = _CUSERID
            ._CPREV_SCHEDULE_ID = _CSCHEDULEID
            ._CORI_ATTRIBUTE_GROUP = _CATTRIBUTEGROUP
            ._CORI_ATTRIBUTE_ID = _CATTRIBUTEID
            ._CORI_ITEM_ID = _CITEMID
            ._CORI_ISSUE_ID = _CISSUE_ID
            ._CCREATE_BY = _CUSERID
            ._CUPDATE_BY = _CUSERID
        End With
    End Sub

    Private Sub gvIssue_R_ServiceDelete(poEntity As Object) Handles gvIssue.R_ServiceDelete
        Dim loService As CST00200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00200Service, CST00200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String

        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvIssue_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvIssue.R_ServiceGetListRecord
        Dim loServiceStream As CST00200StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00200StreamingService, CST00200StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CST00200GridDTO)
        Dim loListEntity As New List(Of CST00200DTO)

        Try
            With CType(poEntity, CST00200ReviseParameterDTO).OFILTER_KEY
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
                R_Utility.R_SetStreamingContext("cProjectId", .CPROJECT_ID)
                R_Utility.R_SetStreamingContext("cSessionId", .CSESSION_ID)
                R_Utility.R_SetStreamingContext("cOriAttributeGroup", .CATTRIBUTE_GROUP)
                R_Utility.R_SetStreamingContext("cOriAttributeId", .CATTRIBUTE_ID)
                R_Utility.R_SetStreamingContext("cOriItemId", .CITEM_ID)
                R_Utility.R_SetStreamingContext("cOriIssueId", .CISSUE_ID)
            End With
            R_Utility.R_SetStreamingContext("cCompanyId", _CCOMPID)
            R_Utility.R_SetStreamingContext("cAppsCode", _CAPPSCODE)
            R_Utility.R_SetStreamingContext("cVersion", _CVERSION)
            R_Utility.R_SetStreamingContext("cProjectId", _CPROJECTID)
            R_Utility.R_SetStreamingContext("cSessionId", _CSESSIONID)
            R_Utility.R_SetStreamingContext("cScheduleId", _CSCHEDULEID)
            R_Utility.R_SetStreamingContext("cFunctionId", _CFUNCTIONID)
            R_Utility.R_SetStreamingContext("cAttributeGroup", _CATTRIBUTEGROUP)
            R_Utility.R_SetStreamingContext("cAttributeId", "*")
            R_Utility.R_SetStreamingContext("cItemId", "*")

            loRtn = loServiceStream.GetIssueList()
            loStreaming = R_StreamUtility(Of CST00200GridDTO).ReadFromMessage(loRtn)

            For Each loDto As CST00200GridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New CST00200DTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                           ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                           ._CVERSION = loDto.CVERSION,
                                                           ._CPROJECT_ID = loDto.CPROJECT_ID,
                                                           ._CSESSION_ID = loDto.CSESSION_ID,
                                                           ._CATTRIBUTE_GROUP = loDto.CATTRIBUTE_GROUP,
                                                           ._CATTRIBUTE_ID = loDto.CATTRIBUTE_ID,
                                                           ._CITEM_ID = loDto.CITEM_ID,
                                                           ._CISSUE_ID = loDto.CISSUE_ID,
                                                           ._CUSER_ID = loDto.CUSER_ID,
                                                           ._DISSUE_DATE = General.StrToDate(loDto.CISSUE_DATE),
                                                           ._CISSUE_CLASS = loDto.CISSUE_CLASS,
                                                           ._CISSUE_TYPE = loDto.CISSUE_TYPE,
                                                           ._CDESCRIPTION = loDto.CDESCRIPTION,
                                                           ._CSCHEDULE_ID = loDto.CSCHEDULE_ID,
                                                           ._CPREV_SCHEDULE_ID = loDto.CPREV_SCHEDULE_ID,
                                                           ._LOK = loDto.LOK,
                                                           ._CORI_ATTRIBUTE_GROUP = loDto.CORI_ATTRIBUTE_GROUP,
                                                           ._CORI_ATTRIBUTE_ID = loDto.CORI_ATTRIBUTE_ID,
                                                           ._CORI_ISSUE_ID = loDto.CORI_ISSUE_ID,
                                                           ._CORI_ITEM_ID = loDto.CORI_ITEM_ID})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvIssue_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvIssue.R_ServiceGetRecord
        Dim loService As CST00200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00200Service, CST00200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New CST00200DTO With {._CCOMPANY_ID = _CCOMPID,
                                                                             ._CAPPS_CODE = _CAPPSCODE,
                                                                             ._CVERSION = _CVERSION,
                                                                             ._CPROJECT_ID = _CPROJECTID,
                                                                             ._CSESSION_ID = _CSESSIONID,
                                                                             ._CATTRIBUTE_GROUP = _CATTRIBUTEGROUP,
                                                                             ._CATTRIBUTE_ID = _CATTRIBUTEID,
                                                                             ._CITEM_ID = _CITEMID,
                                                                             ._CISSUE_ID = CType(bsGvIssue.Current, CST00200DTO)._CISSUE_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvIssue_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvIssue.R_ServiceSave
        Dim loService As CST00200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00200Service, CST00200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
            poEntityResult._DISSUE_DATE = General.StrToDate(poEntityResult._CISSUE_DATE)
        Catch ex As Exception
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvIssue_R_SetEditGridColumn(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, poGridColumnCollection As Telerik.WinControls.UI.GridViewColumnCollection) Handles gvIssue.R_SetEditGridColumn
        CType(poGridColumnCollection("_LOK"), R_GridViewCheckBoxColumn).ReadOnly = False
        CType(poGridColumnCollection("_CDESCRIPTION"), R_GridViewLookUpColumn).ReadOnly = False
    End Sub

    Private Sub gvIssue_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvIssue.R_Validation
        Dim loEx As New R_Exception()

        Try
            With poGridCellCollection
                If String.IsNullOrWhiteSpace(.Item("_CISSUE_ID").Value) Then
                    loEx.Add("CST00200_01", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CST00200_01"))
                    plCancel = True
                End If
                If String.IsNullOrWhiteSpace(.Item("_CISSUE_TYPE").Value) Then
                    loEx.Add("CST00200_02", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CST00200_02"))
                    plCancel = True
                End If
                If String.IsNullOrWhiteSpace(.Item("_CDESCRIPTION").Value) Then
                    loEx.Add("CST00200_03", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CST00200_03"))
                    plCancel = True
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " ATTACHMENT button "

    Private Sub btnAttachment_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object)
        poTargetForm = New CST00200Attach
        With CType(poTargetForm, CST00200Attach)
            .Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "btnAttachment")
        End With

        poParameter = New CST00200KeyDTO
        With poParameter
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = _CAPPSCODE
            .CVERSION = _CVERSION
            .CPROJECT_ID = _CPROJECTID
            .CSESSION_ID = _CSESSIONID
            .CFUNCTION_ID = _CFUNCTIONID
            .CATTRIBUTE_GROUP = _CATTRIBUTEGROUP
            .CATTRIBUTE_ID = _CATTRIBUTEID
            .CITEM_ID = _CITEMID
            .CISSUE_ID = _CISSUE_ID
        End With
    End Sub

#End Region

End Class
