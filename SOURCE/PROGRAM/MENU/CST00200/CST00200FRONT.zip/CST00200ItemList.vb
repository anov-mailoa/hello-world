﻿Imports CST00200FrontResources
Imports R_Common
Imports CST00200Front.CST00200ReviseStreamingServiceRef
Imports R_FrontEnd
Imports System.ServiceModel.Channels
Imports CST00200Front.CST00200ReviseServiceRef

Public Class CST00200ItemList

#Region " VARIABLE "
    Dim C_ServiceName As String = "CST00200Service/CST00200ReviseService.svc"
    Dim C_ServiceNameStream As String = "CST00200Service/CST00200ReviseStreamingService.svc"
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _CVERSION As String
    Dim _INIT As Boolean = False
#End Region

#Region " FORM Events "

    Private Sub CSM00500Manager_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loKey As New CST00200KeyDTO

        Try
            gvManager.R_RefreshGrid(poParameter)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub
#End Region

#Region " GRIDVIEW Events "

    Private Sub gvManager_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvManager.DataBindingComplete
        With gvManager
            .BestFitColumns()
        End With
    End Sub

    Private Sub gvManager_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvManager.R_ServiceGetListRecord
        Dim loServiceStream As CST00200ReviseStreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00200ReviseStreamingService, CST00200ReviseStreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CST00200ItemListDTO)
        Dim loListEntity As New List(Of CST00200ItemListDTO)

        Try
            With CType(poEntity, CST00200KeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
                R_Utility.R_SetStreamingContext("cProjectId", .CPROJECT_ID)
                R_Utility.R_SetStreamingContext("cSessionId", .CSESSION_ID)

                loRtn = loServiceStream.GetItemList()
                loStreaming = R_StreamUtility(Of CST00200ItemListDTO).ReadFromMessage(loRtn)

                For Each loDto As CST00200ItemListDTO In loStreaming
                    If loDto IsNot Nothing Then
                        loListEntity.Add(loDto)
                    Else
                        Exit For
                    End If
                Next
                poListEntityResult = loListEntity

            End With
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loServiceStream.Close()
        loException.ThrowExceptionIfErrors()
    End Sub
#End Region

End Class
