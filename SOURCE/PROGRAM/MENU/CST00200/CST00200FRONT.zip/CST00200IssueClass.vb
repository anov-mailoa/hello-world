﻿Imports CST00200FrontResources
Imports R_Common
Imports ClientHelper
Imports CST00200Front.CST00200IssueClassServiceRef
Imports CST00200Front.CST00200IssueClassStreamingServiceRef
Imports R_FrontEnd
Imports System.ServiceModel.Channels
Imports CST00200Front.CST00200ServiceRef

Public Class CST00200IssueClass

#Region " VARIABLE "
    Dim C_ServiceName As String = "CST00200Service/CST00200IssueClassService.svc"
    Dim C_ServiceNameStream As String = "CST00200Service/CST00200IssueClassStreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _CAPPSNAME As String

    Public Property CAPPS_NAME() As String
        Get
            Return _CAPPSNAME
        End Get
        Set(ByVal value As String)
            _CAPPSNAME = value
        End Set
    End Property
#End Region

#Region " FORM Events "

    Private Sub CST00200IssueClass_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loTableKey As New CST00200IssueClassGridDTO
        Dim loSvc As CST00200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00200Service, CST00200ServiceClient)(e_ServiceClientType.RegularService, "CST00200Service/CST00200Service.svc")

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            _CAPPSCODE = poParameter.CAPPS_CODE
            With loTableKey
                .CCOMPANY_ID = poParameter.CCOMPANY_ID
                .CAPPS_CODE = poParameter.CAPPS_CODE
            End With
            txtApplication.Text = _CAPPSNAME
            Dim loIssueTypeCombo As New List(Of CST00200IssueTypeComboDTO)
            loIssueTypeCombo = loSvc.GetIssueTypeCombo()
            bsIssueType.DataSource = loIssueTypeCombo

            gvIssueType.R_RefreshGrid(loTableKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub CST00200_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " GRIDVIEW "

    Private Sub gvIssueType_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvIssueType.R_Saving
        With CType(poEntity, CST00200IssueClassDTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = _CAPPSCODE
            ._CCREATE_BY = _CUSERID
            ._CUPDATE_BY = _CUSERID
        End With
    End Sub

    Private Sub gvIssueType_R_ServiceDelete(poEntity As Object) Handles gvIssueType.R_ServiceDelete
        Dim loService As CST00200IssueClassServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00200IssueClassService, CST00200IssueClassServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception()

        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As Exception
            If TypeOf (ex) Is System.ServiceModel.FaultException(Of R_ServiceExceptions) Then
                With CType(ex, System.ServiceModel.FaultException(Of R_ServiceExceptions)).Detail.Exceptions.Item(0)
                    loEx.Add(.ErrNo, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), .ErrNo))
                End With
            Else
                loEx.Add(ex)
            End If
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

    Private Sub gvIssueType_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvIssueType.R_ServiceGetListRecord
        Dim loServiceStream As CST00200IssueClassStreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00200IssueClassStreamingService, CST00200IssueClassStreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CST00200IssueClassGridDTO)
        Dim loListEntity As New List(Of CST00200IssueClassDTO)

        Try
            With CType(poEntity, CST00200IssueClassGridDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
            End With

            loRtn = loServiceStream.GetIssueClassList()
            loStreaming = R_StreamUtility(Of CST00200IssueClassGridDTO).ReadFromMessage(loRtn)

            For Each loDto As CST00200IssueClassGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New CST00200IssueClassDTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                                     ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                                     ._CISSUE_CLASS = loDto.CISSUE_CLASS,
                                                                     ._CISSUE_TYPE = loDto.CISSUE_TYPE,
                                                                     ._CDESCRIPTION = loDto.CDESCRIPTION})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvIssueType_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvIssueType.R_ServiceGetRecord
        Dim loService As CST00200IssueClassServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00200IssueClassService, CST00200IssueClassServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New CST00200IssueClassDTO With {._CCOMPANY_ID = _CCOMPID,
                                                                             ._CAPPS_CODE = _CAPPSCODE,
                                                                             ._CISSUE_CLASS = CType(bsGvIssueClass.Current, CST00200IssueClassDTO)._CISSUE_CLASS})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvIssueType_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvIssueType.R_ServiceSave
        Dim loService As CST00200IssueClassServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00200IssueClassService, CST00200IssueClassServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvIssueType_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvIssueType.R_Validation
        Dim loEx As New R_Exception()

        Try
            With poGridCellCollection
                If String.IsNullOrWhiteSpace(.Item("_CISSUE_TYPE").Value) Then
                    loEx.Add("CST00200_02", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CST00200_02"))
                    plCancel = True
                End If
                If String.IsNullOrWhiteSpace(.Item("_CDESCRIPTION").Value) Then
                    loEx.Add("CST00200_03", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CST00200_03"))
                    plCancel = True
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

End Class
