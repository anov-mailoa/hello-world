﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class CST00200Update
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn7 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn8 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewLookUpColumn3 As R_FrontEnd.R_GridViewLookUpColumn = New R_FrontEnd.R_GridViewLookUpColumn()
        Dim R_GridViewTextBoxColumn9 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn10 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn2 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewComboBoxColumn3 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Dim R_GridViewComboBoxColumn4 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Dim R_GridViewLookUpColumn4 As R_FrontEnd.R_GridViewLookUpColumn = New R_FrontEnd.R_GridViewLookUpColumn()
        Dim R_GridViewTextBoxColumn11 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn12 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn2 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Me.bsIssueClass = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsIssueType = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsFunction = New System.Windows.Forms.BindingSource(Me.components)
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblSchedule = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtSchedule = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblSession = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtSession = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtProject = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtVersion = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtApplication = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblProject = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblVersion = New R_FrontEnd.R_RadLabel(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.conGridIssue = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.lblIssueList = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvIssue = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvIssue = New System.Windows.Forms.BindingSource(Me.components)
        CType(Me.bsIssueClass, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsIssueType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsFunction, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.lblSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.conGridIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblIssueList, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvIssue.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'bsIssueClass
        '
        Me.bsIssueClass.DataSource = GetType(CST00200Front.CST00200ServiceRef.CST00200IssueClassComboDTO)
        '
        'bsIssueType
        '
        Me.bsIssueType.DataSource = GetType(CST00200Front.CST00200ServiceRef.CST00200IssueTypeComboDTO)
        '
        'bsFunction
        '
        Me.bsFunction.DataSource = GetType(CST00200Front.CST00200ServiceRef.RCustDBFunctionComboDTO)
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 150.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lblSchedule)
        Me.Panel1.Controls.Add(Me.txtSchedule)
        Me.Panel1.Controls.Add(Me.lblSession)
        Me.Panel1.Controls.Add(Me.txtSession)
        Me.Panel1.Controls.Add(Me.txtProject)
        Me.Panel1.Controls.Add(Me.txtVersion)
        Me.Panel1.Controls.Add(Me.txtApplication)
        Me.Panel1.Controls.Add(Me.lblProject)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Controls.Add(Me.lblVersion)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 144)
        Me.Panel1.TabIndex = 1
        '
        'lblSchedule
        '
        Me.lblSchedule.AutoSize = False
        Me.lblSchedule.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblSchedule.Location = New System.Drawing.Point(9, 113)
        Me.lblSchedule.Name = "lblSchedule"
        Me.lblSchedule.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblSchedule.R_ResourceId = "lblSchedule"
        Me.lblSchedule.Size = New System.Drawing.Size(100, 18)
        Me.lblSchedule.TabIndex = 55
        Me.lblSchedule.Text = "Application..."
        '
        'txtSchedule
        '
        Me.txtSchedule.Location = New System.Drawing.Point(115, 112)
        Me.txtSchedule.Name = "txtSchedule"
        Me.txtSchedule.R_ConductorGridSource = Nothing
        Me.txtSchedule.R_ConductorSource = Nothing
        Me.txtSchedule.R_UDT = Nothing
        Me.txtSchedule.ReadOnly = True
        Me.txtSchedule.Size = New System.Drawing.Size(200, 20)
        Me.txtSchedule.TabIndex = 54
        Me.txtSchedule.TabStop = False
        '
        'lblSession
        '
        Me.lblSession.AutoSize = False
        Me.lblSession.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblSession.Location = New System.Drawing.Point(9, 87)
        Me.lblSession.Name = "lblSession"
        Me.lblSession.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblSession.R_ResourceId = "lblSession"
        Me.lblSession.Size = New System.Drawing.Size(100, 18)
        Me.lblSession.TabIndex = 52
        Me.lblSession.Text = "Application..."
        '
        'txtSession
        '
        Me.txtSession.Location = New System.Drawing.Point(115, 86)
        Me.txtSession.Name = "txtSession"
        Me.txtSession.R_ConductorGridSource = Nothing
        Me.txtSession.R_ConductorSource = Nothing
        Me.txtSession.R_UDT = Nothing
        Me.txtSession.ReadOnly = True
        Me.txtSession.Size = New System.Drawing.Size(200, 20)
        Me.txtSession.TabIndex = 51
        Me.txtSession.TabStop = False
        '
        'txtProject
        '
        Me.txtProject.Location = New System.Drawing.Point(115, 60)
        Me.txtProject.Name = "txtProject"
        Me.txtProject.R_ConductorGridSource = Nothing
        Me.txtProject.R_ConductorSource = Nothing
        Me.txtProject.R_UDT = Nothing
        Me.txtProject.ReadOnly = True
        Me.txtProject.Size = New System.Drawing.Size(200, 20)
        Me.txtProject.TabIndex = 50
        Me.txtProject.TabStop = False
        '
        'txtVersion
        '
        Me.txtVersion.Location = New System.Drawing.Point(115, 34)
        Me.txtVersion.Name = "txtVersion"
        Me.txtVersion.R_ConductorGridSource = Nothing
        Me.txtVersion.R_ConductorSource = Nothing
        Me.txtVersion.R_UDT = Nothing
        Me.txtVersion.ReadOnly = True
        Me.txtVersion.Size = New System.Drawing.Size(200, 20)
        Me.txtVersion.TabIndex = 49
        Me.txtVersion.TabStop = False
        '
        'txtApplication
        '
        Me.txtApplication.Location = New System.Drawing.Point(115, 8)
        Me.txtApplication.Name = "txtApplication"
        Me.txtApplication.R_ConductorGridSource = Nothing
        Me.txtApplication.R_ConductorSource = Nothing
        Me.txtApplication.R_UDT = Nothing
        Me.txtApplication.ReadOnly = True
        Me.txtApplication.Size = New System.Drawing.Size(200, 20)
        Me.txtApplication.TabIndex = 48
        Me.txtApplication.TabStop = False
        '
        'lblProject
        '
        Me.lblProject.AutoSize = False
        Me.lblProject.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblProject.Location = New System.Drawing.Point(9, 61)
        Me.lblProject.Name = "lblProject"
        Me.lblProject.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblProject.R_ResourceId = "lblProject"
        Me.lblProject.Size = New System.Drawing.Size(100, 18)
        Me.lblProject.TabIndex = 33
        Me.lblProject.Text = "Application..."
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 30
        Me.lblApplication.Text = "Application..."
        '
        'lblVersion
        '
        Me.lblVersion.AutoSize = False
        Me.lblVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblVersion.Location = New System.Drawing.Point(9, 35)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblVersion.R_ResourceId = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(100, 18)
        Me.lblVersion.TabIndex = 32
        Me.lblVersion.Text = "Application..."
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.lblIssueList)
        Me.Panel2.Controls.Add(Me.gvIssue)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 153)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1271, 419)
        Me.Panel2.TabIndex = 5
        '
        'conGridIssue
        '
        Me.conGridIssue.R_ConductorParent = Nothing
        Me.conGridIssue.R_IsHeader = True
        Me.conGridIssue.R_RadGroupBox = Nothing
        '
        'lblIssueList
        '
        Me.lblIssueList.AutoSize = False
        Me.lblIssueList.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblIssueList.Location = New System.Drawing.Point(9, 6)
        Me.lblIssueList.Name = "lblIssueList"
        Me.lblIssueList.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblIssueList.R_ResourceId = "lblIssueList"
        Me.lblIssueList.Size = New System.Drawing.Size(100, 18)
        Me.lblIssueList.TabIndex = 1
        Me.lblIssueList.Text = "R_RadLabel1"
        '
        'gvIssue
        '
        Me.gvIssue.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gvIssue.AutoSizeRows = True
        Me.gvIssue.EnableFastScrolling = True
        Me.gvIssue.Location = New System.Drawing.Point(0, 30)
        '
        '
        '
        Me.gvIssue.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn7.FieldName = "_CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn7.HeaderText = "_CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn7.Name = "_CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn7.R_ResourceId = "_CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn7.R_UDT = Nothing
        R_GridViewTextBoxColumn7.Width = 131
        R_GridViewTextBoxColumn8.FieldName = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn8.HeaderText = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn8.Name = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn8.R_ResourceId = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn8.R_UDT = Nothing
        R_GridViewTextBoxColumn8.Width = 104
        R_GridViewLookUpColumn3.FieldName = "_CITEM_ID"
        R_GridViewLookUpColumn3.HeaderText = "_CITEM_ID"
        R_GridViewLookUpColumn3.Name = "_CITEM_ID"
        R_GridViewLookUpColumn3.R_EnableADD = True
        R_GridViewLookUpColumn3.R_ResourceId = "_CITEM_ID"
        R_GridViewLookUpColumn3.R_Title = Nothing
        R_GridViewLookUpColumn3.Width = 74
        R_GridViewTextBoxColumn9.FieldName = "_CISSUE_ID"
        R_GridViewTextBoxColumn9.HeaderText = "_CISSUE_ID"
        R_GridViewTextBoxColumn9.MaxLength = 15
        R_GridViewTextBoxColumn9.Name = "_CISSUE_ID"
        R_GridViewTextBoxColumn9.R_EnableADD = True
        R_GridViewTextBoxColumn9.R_ResourceId = "_CISSUE_ID"
        R_GridViewTextBoxColumn9.R_UDT = Nothing
        R_GridViewTextBoxColumn9.Width = 78
        R_GridViewTextBoxColumn10.FieldName = "_CUSER_ID"
        R_GridViewTextBoxColumn10.HeaderText = "_CUSER_ID"
        R_GridViewTextBoxColumn10.Name = "_CUSER_ID"
        R_GridViewTextBoxColumn10.R_ResourceId = "_CUSER_ID"
        R_GridViewTextBoxColumn10.R_UDT = Nothing
        R_GridViewTextBoxColumn10.Width = 76
        R_GridViewDateTimeColumn2.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn2.FieldName = "_DISSUE_DATE"
        R_GridViewDateTimeColumn2.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn2.FormatString = "{0: dd/MM/yyyy }"
        R_GridViewDateTimeColumn2.HeaderText = "_DISSUE_DATE"
        R_GridViewDateTimeColumn2.Name = "_DISSUE_DATE"
        R_GridViewDateTimeColumn2.R_MinDate = New Date(CType(0, Long))
        R_GridViewDateTimeColumn2.R_ResourceId = "_DISSUE_DATE"
        R_GridViewDateTimeColumn2.Width = 95
        R_GridViewComboBoxColumn3.DataSource = Me.bsIssueClass
        R_GridViewComboBoxColumn3.DisplayMember = "CDESCRIPTION"
        R_GridViewComboBoxColumn3.FieldName = "_CISSUE_CLASS"
        R_GridViewComboBoxColumn3.HeaderText = "_CISSUE_CLASS"
        R_GridViewComboBoxColumn3.Name = "_CISSUE_CLASS"
        R_GridViewComboBoxColumn3.R_EnableADD = True
        R_GridViewComboBoxColumn3.R_EnableEDIT = True
        R_GridViewComboBoxColumn3.R_ResourceId = "_CISSUE_CLASS"
        R_GridViewComboBoxColumn3.ValueMember = "CISSUE_CLASS"
        R_GridViewComboBoxColumn3.Width = 99
        R_GridViewComboBoxColumn4.DataSource = Me.bsIssueType
        R_GridViewComboBoxColumn4.DisplayMember = "CDESCRIPTION"
        R_GridViewComboBoxColumn4.FieldName = "_CISSUE_TYPE"
        R_GridViewComboBoxColumn4.HeaderText = "_CISSUE_TYPE"
        R_GridViewComboBoxColumn4.Name = "_CISSUE_TYPE"
        R_GridViewComboBoxColumn4.R_EnableADD = True
        R_GridViewComboBoxColumn4.R_EnableEDIT = True
        R_GridViewComboBoxColumn4.R_ResourceId = "_CISSUE_TYPE"
        R_GridViewComboBoxColumn4.ValueMember = "CISSUE_TYPE"
        R_GridViewComboBoxColumn4.Width = 91
        R_GridViewLookUpColumn4.FieldName = "_CDESCRIPTION"
        R_GridViewLookUpColumn4.HeaderText = "_CDESCRIPTION"
        R_GridViewLookUpColumn4.Name = "_CDESCRIPTION"
        R_GridViewLookUpColumn4.R_EnableADD = True
        R_GridViewLookUpColumn4.R_EnableEDIT = True
        R_GridViewLookUpColumn4.R_ResourceId = "_CDESCRIPTION"
        R_GridViewLookUpColumn4.R_Title = "Description"
        R_GridViewLookUpColumn4.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        R_GridViewLookUpColumn4.Width = 103
        R_GridViewLookUpColumn4.WrapText = True
        R_GridViewTextBoxColumn11.FieldName = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn11.HeaderText = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn11.Name = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn11.R_ResourceId = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn11.R_UDT = Nothing
        R_GridViewTextBoxColumn11.Width = 103
        R_GridViewTextBoxColumn12.FieldName = "_CPREV_SCHEDULE_ID"
        R_GridViewTextBoxColumn12.HeaderText = "_CPREV_SCHEDULE_ID"
        R_GridViewTextBoxColumn12.Name = "_CPREV_SCHEDULE_ID"
        R_GridViewTextBoxColumn12.R_ResourceId = "_CPREV_SCHEDULE_ID"
        R_GridViewTextBoxColumn12.R_UDT = Nothing
        R_GridViewTextBoxColumn12.Width = 134
        R_GridViewCheckBoxColumn2.FieldName = "_LOK"
        R_GridViewCheckBoxColumn2.HeaderText = "_LOK"
        R_GridViewCheckBoxColumn2.Name = "_LOK"
        R_GridViewCheckBoxColumn2.R_EnableEDIT = True
        R_GridViewCheckBoxColumn2.R_ResourceId = "_LOK"
        R_GridViewCheckBoxColumn2.Width = 62
        Me.gvIssue.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn7, R_GridViewTextBoxColumn8, R_GridViewLookUpColumn3, R_GridViewTextBoxColumn9, R_GridViewTextBoxColumn10, R_GridViewDateTimeColumn2, R_GridViewComboBoxColumn3, R_GridViewComboBoxColumn4, R_GridViewLookUpColumn4, R_GridViewTextBoxColumn11, R_GridViewTextBoxColumn12, R_GridViewCheckBoxColumn2})
        Me.gvIssue.MasterTemplate.DataSource = Me.bsGvIssue
        Me.gvIssue.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvIssue.MasterTemplate.EnableFiltering = True
        Me.gvIssue.MasterTemplate.EnableGrouping = False
        Me.gvIssue.MasterTemplate.ShowFilteringRow = False
        Me.gvIssue.MasterTemplate.ShowGroupedColumns = True
        Me.gvIssue.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvIssue.Name = "gvIssue"
        Me.gvIssue.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvIssue.R_ConductorGridSource = Me.conGridIssue
        Me.gvIssue.R_ConductorSource = Nothing
        Me.gvIssue.R_DataAdded = False
        Me.gvIssue.R_NewRowText = Nothing
        Me.gvIssue.ShowHeaderCellButtons = True
        Me.gvIssue.Size = New System.Drawing.Size(1271, 389)
        Me.gvIssue.TabIndex = 0
        Me.gvIssue.Text = "R_RadGridView1"
        '
        'bsGvIssue
        '
        Me.bsGvIssue.DataSource = GetType(CST00200Front.CST00200StreamingServiceRef.CST00200GridDTO)
        '
        'CST00200Update
        '
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CST00200Update"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.bsIssueClass, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsIssueType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsFunction, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.lblSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        CType(Me.conGridIssue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblIssueList, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvIssue.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvIssue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvIssue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblProject As R_FrontEnd.R_RadLabel
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents lblVersion As R_FrontEnd.R_RadLabel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents gvIssue As R_FrontEnd.R_RadGridView
    Friend WithEvents bsGvIssue As System.Windows.Forms.BindingSource
    Friend WithEvents bsFunction As System.Windows.Forms.BindingSource
    Friend WithEvents bsIssueClass As System.Windows.Forms.BindingSource
    Friend WithEvents lblIssueList As R_FrontEnd.R_RadLabel
    Friend WithEvents txtSession As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtProject As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtVersion As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtApplication As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblSession As R_FrontEnd.R_RadLabel
    Friend WithEvents lblSchedule As R_FrontEnd.R_RadLabel
    Friend WithEvents txtSchedule As R_FrontEnd.R_RadTextBox
    Friend WithEvents bsIssueType As System.Windows.Forms.BindingSource
    Friend WithEvents conGridIssue As R_FrontEnd.R_ConductorGrid

End Class
