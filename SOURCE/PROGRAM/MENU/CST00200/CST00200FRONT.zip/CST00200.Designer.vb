﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CST00200
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewComboBoxColumn1 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Dim R_GridViewComboBoxColumn2 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Dim R_GridViewLookUpColumn1 As R_FrontEnd.R_GridViewLookUpColumn = New R_FrontEnd.R_GridViewLookUpColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn1 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn6 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn7 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn8 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn9 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn10 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn2 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn3 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn4 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn5 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn11 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn12 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.bsIssueClass = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsIssueType = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsFunction = New System.Windows.Forms.BindingSource(Me.components)
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnUpdate = New R_FrontEnd.R_Detail(Me.components)
        Me.conGridIssue = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.conGridInbox = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.lblCustom = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblCustomer = New R_FrontEnd.R_RadLabel(Me.components)
        Me.btnRefresh = New R_FrontEnd.R_RadButton(Me.components)
        Me.lblSchedule = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtSchedule = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblSession = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtSession = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtProject = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtVersion = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtApplication = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.btnFilter = New R_FrontEnd.R_PopUp(Me.components)
        Me.btnIssueClass = New R_FrontEnd.R_PopUp(Me.components)
        Me.lblProject = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblVersion = New R_FrontEnd.R_RadLabel(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnRevise = New R_FrontEnd.R_Detail(Me.components)
        Me.btnCopy = New R_FrontEnd.R_RadButton(Me.components)
        Me.btnPaste = New R_FrontEnd.R_RadButton(Me.components)
        Me.btnAttachment = New R_FrontEnd.R_PopUp(Me.components)
        Me.lblIssueList = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvIssue = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvIssue = New System.Windows.Forms.BindingSource(Me.components)
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.gvInbox = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvInbox = New System.Windows.Forms.BindingSource(Me.components)
        CType(Me.bsIssueClass, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsIssueType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsFunction, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.btnUpdate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridInbox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCustom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnRefresh, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnFilter, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnIssueClass, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.btnRevise, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnCopy, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnPaste, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnAttachment, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblIssueList, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvIssue.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.gvInbox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvInbox.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvInbox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'bsIssueClass
        '
        Me.bsIssueClass.DataSource = GetType(CST00200Front.CST00200ServiceRef.CST00200IssueClassComboDTO)
        '
        'bsIssueType
        '
        Me.bsIssueType.DataSource = GetType(CST00200Front.CST00200ServiceRef.CST00200IssueTypeComboDTO)
        '
        'bsFunction
        '
        Me.bsFunction.DataSource = GetType(CST00200Front.CST00200ServiceRef.RCustDBFunctionComboDTO)
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel3, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 150.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnUpdate)
        Me.Panel1.Controls.Add(Me.lblCustom)
        Me.Panel1.Controls.Add(Me.lblCustomer)
        Me.Panel1.Controls.Add(Me.btnRefresh)
        Me.Panel1.Controls.Add(Me.lblSchedule)
        Me.Panel1.Controls.Add(Me.txtSchedule)
        Me.Panel1.Controls.Add(Me.lblSession)
        Me.Panel1.Controls.Add(Me.txtSession)
        Me.Panel1.Controls.Add(Me.txtProject)
        Me.Panel1.Controls.Add(Me.txtVersion)
        Me.Panel1.Controls.Add(Me.txtApplication)
        Me.Panel1.Controls.Add(Me.btnFilter)
        Me.Panel1.Controls.Add(Me.btnIssueClass)
        Me.Panel1.Controls.Add(Me.lblProject)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Controls.Add(Me.lblVersion)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 144)
        Me.Panel1.TabIndex = 1
        '
        'btnUpdate
        '
        Me.btnUpdate.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnUpdate.Location = New System.Drawing.Point(1152, 39)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.R_ConductorGridSource = Me.conGridIssue
        Me.btnUpdate.R_ConductorSource = Nothing
        Me.btnUpdate.R_DescriptionId = Nothing
        Me.btnUpdate.R_EnableOTHER = True
        Me.btnUpdate.R_ResourceId = "btnUpdate"
        Me.btnUpdate.R_Title = "Update Issue"
        Me.btnUpdate.Size = New System.Drawing.Size(110, 24)
        Me.btnUpdate.TabIndex = 64
        Me.btnUpdate.Text = "btnUpdate"
        '
        'conGridIssue
        '
        Me.conGridIssue.R_ConductorParent = Me.conGridInbox
        Me.conGridIssue.R_RadGroupBox = Nothing
        '
        'conGridInbox
        '
        Me.conGridInbox.R_ConductorParent = Nothing
        Me.conGridInbox.R_IsHeader = True
        Me.conGridInbox.R_RadGroupBox = Nothing
        '
        'lblCustom
        '
        Me.lblCustom.AutoSize = False
        Me.lblCustom.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustom.Location = New System.Drawing.Point(521, 61)
        Me.lblCustom.Name = "lblCustom"
        Me.lblCustom.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustom.R_ResourceId = ""
        Me.lblCustom.Size = New System.Drawing.Size(100, 18)
        Me.lblCustom.TabIndex = 63
        Me.lblCustom.Text = "Application..."
        '
        'lblCustomer
        '
        Me.lblCustomer.AutoSize = False
        Me.lblCustomer.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustomer.Location = New System.Drawing.Point(9, 35)
        Me.lblCustomer.Name = "lblCustomer"
        Me.lblCustomer.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustomer.R_ResourceId = "lblCustomer"
        Me.lblCustomer.Size = New System.Drawing.Size(100, 18)
        Me.lblCustomer.TabIndex = 62
        Me.lblCustomer.Text = "Application..."
        '
        'btnRefresh
        '
        Me.btnRefresh.Location = New System.Drawing.Point(646, 9)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.R_ConductorGridSource = Nothing
        Me.btnRefresh.R_ConductorSource = Nothing
        Me.btnRefresh.R_DescriptionId = Nothing
        Me.btnRefresh.R_ResourceId = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(110, 24)
        Me.btnRefresh.TabIndex = 61
        Me.btnRefresh.Text = "R_RadButton1"
        '
        'lblSchedule
        '
        Me.lblSchedule.AutoSize = False
        Me.lblSchedule.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblSchedule.Location = New System.Drawing.Point(9, 113)
        Me.lblSchedule.Name = "lblSchedule"
        Me.lblSchedule.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblSchedule.R_ResourceId = "lblSchedule"
        Me.lblSchedule.Size = New System.Drawing.Size(100, 18)
        Me.lblSchedule.TabIndex = 55
        Me.lblSchedule.Text = "Application..."
        '
        'txtSchedule
        '
        Me.txtSchedule.Location = New System.Drawing.Point(115, 112)
        Me.txtSchedule.Name = "txtSchedule"
        Me.txtSchedule.R_ConductorGridSource = Nothing
        Me.txtSchedule.R_ConductorSource = Nothing
        Me.txtSchedule.R_UDT = Nothing
        Me.txtSchedule.ReadOnly = True
        Me.txtSchedule.Size = New System.Drawing.Size(200, 20)
        Me.txtSchedule.TabIndex = 54
        Me.txtSchedule.TabStop = False
        '
        'lblSession
        '
        Me.lblSession.AutoSize = False
        Me.lblSession.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblSession.Location = New System.Drawing.Point(9, 87)
        Me.lblSession.Name = "lblSession"
        Me.lblSession.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblSession.R_ResourceId = "lblSession"
        Me.lblSession.Size = New System.Drawing.Size(100, 18)
        Me.lblSession.TabIndex = 52
        Me.lblSession.Text = "Application..."
        '
        'txtSession
        '
        Me.txtSession.Location = New System.Drawing.Point(115, 86)
        Me.txtSession.Name = "txtSession"
        Me.txtSession.R_ConductorGridSource = Nothing
        Me.txtSession.R_ConductorSource = Nothing
        Me.txtSession.R_UDT = Nothing
        Me.txtSession.ReadOnly = True
        Me.txtSession.Size = New System.Drawing.Size(200, 20)
        Me.txtSession.TabIndex = 51
        Me.txtSession.TabStop = False
        '
        'txtProject
        '
        Me.txtProject.Location = New System.Drawing.Point(115, 60)
        Me.txtProject.Name = "txtProject"
        Me.txtProject.R_ConductorGridSource = Nothing
        Me.txtProject.R_ConductorSource = Nothing
        Me.txtProject.R_UDT = Nothing
        Me.txtProject.ReadOnly = True
        Me.txtProject.Size = New System.Drawing.Size(400, 20)
        Me.txtProject.TabIndex = 50
        Me.txtProject.TabStop = False
        '
        'txtVersion
        '
        Me.txtVersion.Location = New System.Drawing.Point(115, 34)
        Me.txtVersion.Name = "txtVersion"
        Me.txtVersion.R_ConductorGridSource = Nothing
        Me.txtVersion.R_ConductorSource = Nothing
        Me.txtVersion.R_UDT = Nothing
        Me.txtVersion.ReadOnly = True
        Me.txtVersion.Size = New System.Drawing.Size(200, 20)
        Me.txtVersion.TabIndex = 49
        Me.txtVersion.TabStop = False
        '
        'txtApplication
        '
        Me.txtApplication.Location = New System.Drawing.Point(115, 8)
        Me.txtApplication.Name = "txtApplication"
        Me.txtApplication.R_ConductorGridSource = Nothing
        Me.txtApplication.R_ConductorSource = Nothing
        Me.txtApplication.R_UDT = Nothing
        Me.txtApplication.ReadOnly = True
        Me.txtApplication.Size = New System.Drawing.Size(400, 20)
        Me.txtApplication.TabIndex = 48
        Me.txtApplication.TabStop = False
        '
        'btnFilter
        '
        Me.btnFilter.Location = New System.Drawing.Point(530, 9)
        Me.btnFilter.Name = "btnFilter"
        Me.btnFilter.R_ConductorGridSource = Me.conGridIssue
        Me.btnFilter.R_ConductorSource = Nothing
        Me.btnFilter.R_DescriptionId = Nothing
        Me.btnFilter.R_EnableOTHER = True
        Me.btnFilter.R_ResourceId = "btnFilter"
        Me.btnFilter.R_Title = "Issue Filter"
        Me.btnFilter.Size = New System.Drawing.Size(110, 24)
        Me.btnFilter.TabIndex = 37
        Me.btnFilter.Text = "R_PopUp1"
        '
        'btnIssueClass
        '
        Me.btnIssueClass.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnIssueClass.Location = New System.Drawing.Point(1152, 9)
        Me.btnIssueClass.Name = "btnIssueClass"
        Me.btnIssueClass.R_ConductorGridSource = Me.conGridIssue
        Me.btnIssueClass.R_ConductorSource = Nothing
        Me.btnIssueClass.R_DescriptionId = Nothing
        Me.btnIssueClass.R_EnableOTHER = True
        Me.btnIssueClass.R_ResourceId = "btnIssueClass"
        Me.btnIssueClass.R_Title = Nothing
        Me.btnIssueClass.Size = New System.Drawing.Size(110, 24)
        Me.btnIssueClass.TabIndex = 36
        Me.btnIssueClass.Text = "R_PopUp1"
        '
        'lblProject
        '
        Me.lblProject.AutoSize = False
        Me.lblProject.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblProject.Location = New System.Drawing.Point(9, 61)
        Me.lblProject.Name = "lblProject"
        Me.lblProject.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblProject.R_ResourceId = "lblProject"
        Me.lblProject.Size = New System.Drawing.Size(100, 18)
        Me.lblProject.TabIndex = 33
        Me.lblProject.Text = "Application..."
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 30
        Me.lblApplication.Text = "Application..."
        '
        'lblVersion
        '
        Me.lblVersion.AutoSize = False
        Me.lblVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblVersion.Location = New System.Drawing.Point(9, 35)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblVersion.R_ResourceId = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(100, 18)
        Me.lblVersion.TabIndex = 32
        Me.lblVersion.Text = "Application..."
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.btnRevise)
        Me.Panel2.Controls.Add(Me.btnCopy)
        Me.Panel2.Controls.Add(Me.btnPaste)
        Me.Panel2.Controls.Add(Me.btnAttachment)
        Me.Panel2.Controls.Add(Me.lblIssueList)
        Me.Panel2.Controls.Add(Me.gvIssue)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 323)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1271, 249)
        Me.Panel2.TabIndex = 5
        '
        'btnRevise
        '
        Me.btnRevise.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnRevise.Location = New System.Drawing.Point(1152, 3)
        Me.btnRevise.Name = "btnRevise"
        Me.btnRevise.R_ConductorGridSource = Me.conGridIssue
        Me.btnRevise.R_ConductorSource = Nothing
        Me.btnRevise.R_DescriptionId = Nothing
        Me.btnRevise.R_EnableHASDATA = True
        Me.btnRevise.R_EnableOTHER = True
        Me.btnRevise.R_ResourceId = "btnRevise"
        Me.btnRevise.R_Title = "Revise Issue"
        Me.btnRevise.Size = New System.Drawing.Size(110, 24)
        Me.btnRevise.TabIndex = 5
        Me.btnRevise.Text = "R_Detail1"
        '
        'btnCopy
        '
        Me.btnCopy.Location = New System.Drawing.Point(804, 3)
        Me.btnCopy.Name = "btnCopy"
        Me.btnCopy.R_ConductorGridSource = Me.conGridIssue
        Me.btnCopy.R_ConductorSource = Nothing
        Me.btnCopy.R_DescriptionId = Nothing
        Me.btnCopy.R_EnableHASDATA = True
        Me.btnCopy.R_ResourceId = "btnCopy"
        Me.btnCopy.Size = New System.Drawing.Size(110, 24)
        Me.btnCopy.TabIndex = 4
        Me.btnCopy.Text = "R_RadButton1"
        '
        'btnPaste
        '
        Me.btnPaste.Location = New System.Drawing.Point(920, 3)
        Me.btnPaste.Name = "btnPaste"
        Me.btnPaste.R_ConductorGridSource = Nothing
        Me.btnPaste.R_ConductorSource = Nothing
        Me.btnPaste.R_DescriptionId = Nothing
        Me.btnPaste.R_ResourceId = "btnPaste"
        Me.btnPaste.Size = New System.Drawing.Size(110, 24)
        Me.btnPaste.TabIndex = 3
        Me.btnPaste.Text = "R_RadButton1"
        '
        'btnAttachment
        '
        Me.btnAttachment.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnAttachment.Location = New System.Drawing.Point(1036, 3)
        Me.btnAttachment.Name = "btnAttachment"
        Me.btnAttachment.R_ConductorGridSource = Me.conGridIssue
        Me.btnAttachment.R_ConductorSource = Nothing
        Me.btnAttachment.R_DescriptionId = Nothing
        Me.btnAttachment.R_EnableHASDATA = True
        Me.btnAttachment.R_ResourceId = "btnAttachment"
        Me.btnAttachment.R_Title = Nothing
        Me.btnAttachment.Size = New System.Drawing.Size(110, 24)
        Me.btnAttachment.TabIndex = 2
        Me.btnAttachment.Text = "R_PopUp1"
        '
        'lblIssueList
        '
        Me.lblIssueList.AutoSize = False
        Me.lblIssueList.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblIssueList.Location = New System.Drawing.Point(9, 6)
        Me.lblIssueList.Name = "lblIssueList"
        Me.lblIssueList.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblIssueList.R_ResourceId = "lblIssueList"
        Me.lblIssueList.Size = New System.Drawing.Size(100, 18)
        Me.lblIssueList.TabIndex = 1
        Me.lblIssueList.Text = "R_RadLabel1"
        '
        'gvIssue
        '
        Me.gvIssue.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gvIssue.AutoSizeRows = True
        Me.gvIssue.EnableFastScrolling = True
        Me.gvIssue.Location = New System.Drawing.Point(0, 30)
        '
        '
        '
        Me.gvIssue.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn1.FieldName = "_CISSUE_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CISSUE_ID"
        R_GridViewTextBoxColumn1.MaxLength = 15
        R_GridViewTextBoxColumn1.Name = "_CISSUE_ID"
        R_GridViewTextBoxColumn1.R_EnableADD = True
        R_GridViewTextBoxColumn1.R_ResourceId = "_CISSUE_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 78
        R_GridViewTextBoxColumn2.FieldName = "_CUSER_ID"
        R_GridViewTextBoxColumn2.HeaderText = "_CUSER_ID"
        R_GridViewTextBoxColumn2.Name = "_CUSER_ID"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CUSER_ID"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 76
        R_GridViewDateTimeColumn1.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn1.FieldName = "_DISSUE_DATE"
        R_GridViewDateTimeColumn1.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn1.FormatString = "{0: dd/MM/yyyy }"
        R_GridViewDateTimeColumn1.HeaderText = "_DISSUE_DATE"
        R_GridViewDateTimeColumn1.Name = "_DISSUE_DATE"
        R_GridViewDateTimeColumn1.R_MinDate = New Date(CType(0, Long))
        R_GridViewDateTimeColumn1.R_ResourceId = "_DISSUE_DATE"
        R_GridViewDateTimeColumn1.Width = 95
        R_GridViewComboBoxColumn1.DataSource = Me.bsIssueClass
        R_GridViewComboBoxColumn1.DisplayMember = "CDESCRIPTION"
        R_GridViewComboBoxColumn1.FieldName = "_CISSUE_CLASS"
        R_GridViewComboBoxColumn1.HeaderText = "_CISSUE_CLASS"
        R_GridViewComboBoxColumn1.Name = "_CISSUE_CLASS"
        R_GridViewComboBoxColumn1.R_EnableADD = True
        R_GridViewComboBoxColumn1.R_EnableEDIT = True
        R_GridViewComboBoxColumn1.R_ResourceId = "_CISSUE_CLASS"
        R_GridViewComboBoxColumn1.ValueMember = "CISSUE_CLASS"
        R_GridViewComboBoxColumn1.Width = 99
        R_GridViewComboBoxColumn2.DataSource = Me.bsIssueType
        R_GridViewComboBoxColumn2.DisplayMember = "CDESCRIPTION"
        R_GridViewComboBoxColumn2.FieldName = "_CISSUE_TYPE"
        R_GridViewComboBoxColumn2.HeaderText = "_CISSUE_TYPE"
        R_GridViewComboBoxColumn2.Name = "_CISSUE_TYPE"
        R_GridViewComboBoxColumn2.R_EnableADD = True
        R_GridViewComboBoxColumn2.R_EnableEDIT = True
        R_GridViewComboBoxColumn2.R_ResourceId = "_CISSUE_TYPE"
        R_GridViewComboBoxColumn2.ValueMember = "CISSUE_TYPE"
        R_GridViewComboBoxColumn2.Width = 91
        R_GridViewLookUpColumn1.FieldName = "_CDESCRIPTION"
        R_GridViewLookUpColumn1.HeaderText = "_CDESCRIPTION"
        R_GridViewLookUpColumn1.Name = "_CDESCRIPTION"
        R_GridViewLookUpColumn1.R_EnableADD = True
        R_GridViewLookUpColumn1.R_EnableEDIT = True
        R_GridViewLookUpColumn1.R_ResourceId = "_CDESCRIPTION"
        R_GridViewLookUpColumn1.R_Title = "Description"
        R_GridViewLookUpColumn1.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        R_GridViewLookUpColumn1.Width = 103
        R_GridViewLookUpColumn1.WrapText = True
        R_GridViewTextBoxColumn3.FieldName = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn3.HeaderText = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn3.Name = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 103
        R_GridViewTextBoxColumn4.FieldName = "_CPREV_SCHEDULE_ID"
        R_GridViewTextBoxColumn4.HeaderText = "_CPREV_SCHEDULE_ID"
        R_GridViewTextBoxColumn4.Name = "_CPREV_SCHEDULE_ID"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CPREV_SCHEDULE_ID"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 134
        R_GridViewCheckBoxColumn1.FieldName = "_LOK"
        R_GridViewCheckBoxColumn1.HeaderText = "_LOK"
        R_GridViewCheckBoxColumn1.Name = "_LOK"
        R_GridViewCheckBoxColumn1.R_EnableEDIT = True
        R_GridViewCheckBoxColumn1.R_ResourceId = "_LOK"
        R_GridViewCheckBoxColumn1.Width = 62
        Me.gvIssue.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewDateTimeColumn1, R_GridViewComboBoxColumn1, R_GridViewComboBoxColumn2, R_GridViewLookUpColumn1, R_GridViewTextBoxColumn3, R_GridViewTextBoxColumn4, R_GridViewCheckBoxColumn1})
        Me.gvIssue.MasterTemplate.DataSource = Me.bsGvIssue
        Me.gvIssue.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvIssue.MasterTemplate.EnableFiltering = True
        Me.gvIssue.MasterTemplate.EnableGrouping = False
        Me.gvIssue.MasterTemplate.ShowFilteringRow = False
        Me.gvIssue.MasterTemplate.ShowGroupedColumns = True
        Me.gvIssue.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvIssue.Name = "gvIssue"
        Me.gvIssue.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvIssue.R_ConductorGridSource = Me.conGridIssue
        Me.gvIssue.R_ConductorSource = Nothing
        Me.gvIssue.R_DataAdded = False
        Me.gvIssue.R_NewRowText = Nothing
        Me.gvIssue.ShowHeaderCellButtons = True
        Me.gvIssue.Size = New System.Drawing.Size(1271, 219)
        Me.gvIssue.TabIndex = 0
        Me.gvIssue.Text = "R_RadGridView1"
        '
        'bsGvIssue
        '
        Me.bsGvIssue.DataSource = GetType(CST00200Front.CST00200StreamingServiceRef.CST00200GridDTO)
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.gvInbox)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(3, 153)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1271, 164)
        Me.Panel3.TabIndex = 6
        '
        'gvInbox
        '
        Me.gvInbox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvInbox.EnableFastScrolling = True
        Me.gvInbox.Location = New System.Drawing.Point(0, 0)
        '
        '
        '
        Me.gvInbox.MasterTemplate.AllowAddNewRow = False
        Me.gvInbox.MasterTemplate.AllowDeleteRow = False
        Me.gvInbox.MasterTemplate.AllowEditRow = False
        Me.gvInbox.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn5.FieldName = "CATTRIBUTE_ID"
        R_GridViewTextBoxColumn5.HeaderText = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn5.Name = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 104
        R_GridViewTextBoxColumn6.FieldName = "CITEM_ID"
        R_GridViewTextBoxColumn6.HeaderText = "_CITEM_ID"
        R_GridViewTextBoxColumn6.Name = "_CITEM_ID"
        R_GridViewTextBoxColumn6.R_ResourceId = "_CITEM_ID"
        R_GridViewTextBoxColumn6.R_UDT = Nothing
        R_GridViewTextBoxColumn6.Width = 74
        R_GridViewTextBoxColumn7.FieldName = "CITEM_NAME"
        R_GridViewTextBoxColumn7.HeaderText = "_CITEM_NAME"
        R_GridViewTextBoxColumn7.Name = "_CITEM_NAME"
        R_GridViewTextBoxColumn7.R_ResourceId = "_CITEM_NAME"
        R_GridViewTextBoxColumn7.R_UDT = Nothing
        R_GridViewTextBoxColumn7.Width = 95
        R_GridViewTextBoxColumn8.FieldName = "CITEM_STATUS"
        R_GridViewTextBoxColumn8.HeaderText = "_CITEM_STATUS"
        R_GridViewTextBoxColumn8.Name = "_CITEM_STATUS"
        R_GridViewTextBoxColumn8.R_ResourceId = "_CITEM_STATUS"
        R_GridViewTextBoxColumn8.R_UDT = Nothing
        R_GridViewTextBoxColumn8.Width = 102
        R_GridViewTextBoxColumn9.FieldName = "CSESSION_ID"
        R_GridViewTextBoxColumn9.HeaderText = "_CSESSION_ID"
        R_GridViewTextBoxColumn9.Name = "_CSESSION_ID"
        R_GridViewTextBoxColumn9.R_ResourceId = "_CSESSION_ID"
        R_GridViewTextBoxColumn9.R_UDT = Nothing
        R_GridViewTextBoxColumn9.Width = 93
        R_GridViewTextBoxColumn10.FieldName = "CSCHEDULE_ID"
        R_GridViewTextBoxColumn10.HeaderText = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn10.Name = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn10.R_ResourceId = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn10.R_UDT = Nothing
        R_GridViewTextBoxColumn10.Width = 103
        R_GridViewDateTimeColumn2.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn2.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn2.FieldName = "DPLAN_START_DATE"
        R_GridViewDateTimeColumn2.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn2.FormatString = "{0: dd/MM/yyyy }"
        R_GridViewDateTimeColumn2.HeaderText = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn2.Name = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn2.R_MinDate = New Date(CType(0, Long))
        R_GridViewDateTimeColumn2.R_ResourceId = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn2.Width = 131
        R_GridViewDateTimeColumn3.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn3.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn3.FieldName = "DPLAN_END_DATE"
        R_GridViewDateTimeColumn3.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn3.FormatString = "{0: dd/MM/yyyy }"
        R_GridViewDateTimeColumn3.HeaderText = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn3.Name = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn3.R_MinDate = New Date(CType(0, Long))
        R_GridViewDateTimeColumn3.R_ResourceId = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn3.Width = 121
        R_GridViewDateTimeColumn4.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn4.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn4.FieldName = "DREVISED_START_DATE"
        R_GridViewDateTimeColumn4.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn4.FormatString = "{0: dd/MM/yyyy }"
        R_GridViewDateTimeColumn4.HeaderText = "_DREVISED_START_DATE"
        R_GridViewDateTimeColumn4.Name = "_DREVISED_START_DATE"
        R_GridViewDateTimeColumn4.R_MinDate = New Date(CType(0, Long))
        R_GridViewDateTimeColumn4.R_ResourceId = "_DREVISED_START_DATE"
        R_GridViewDateTimeColumn4.Width = 145
        R_GridViewDateTimeColumn5.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn5.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn5.FieldName = "DREVISED_END_DATE"
        R_GridViewDateTimeColumn5.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn5.FormatString = "{0: dd/MM/yyyy }"
        R_GridViewDateTimeColumn5.HeaderText = "_DREVISED_END_DATE"
        R_GridViewDateTimeColumn5.Name = "_DREVISED_END_DATE"
        R_GridViewDateTimeColumn5.R_MinDate = New Date(CType(0, Long))
        R_GridViewDateTimeColumn5.R_ResourceId = "_DREVISED_END_DATE"
        R_GridViewDateTimeColumn5.Width = 136
        R_GridViewTextBoxColumn11.FieldName = "CLAST_ACTION"
        R_GridViewTextBoxColumn11.HeaderText = "_CLAST_ACTION"
        R_GridViewTextBoxColumn11.Name = "_CLAST_ACTION"
        R_GridViewTextBoxColumn11.R_ResourceId = "_CLAST_ACTION"
        R_GridViewTextBoxColumn11.R_UDT = Nothing
        R_GridViewTextBoxColumn11.Width = 103
        R_GridViewTextBoxColumn12.FieldName = "CLAST_ACTION_BY"
        R_GridViewTextBoxColumn12.HeaderText = "_CLAST_ACTION_BY"
        R_GridViewTextBoxColumn12.Name = "_CLAST_ACTION_BY"
        R_GridViewTextBoxColumn12.R_ResourceId = "_CLAST_ACTION_BY"
        R_GridViewTextBoxColumn12.R_UDT = Nothing
        R_GridViewTextBoxColumn12.Width = 121
        Me.gvInbox.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn5, R_GridViewTextBoxColumn6, R_GridViewTextBoxColumn7, R_GridViewTextBoxColumn8, R_GridViewTextBoxColumn9, R_GridViewTextBoxColumn10, R_GridViewDateTimeColumn2, R_GridViewDateTimeColumn3, R_GridViewDateTimeColumn4, R_GridViewDateTimeColumn5, R_GridViewTextBoxColumn11, R_GridViewTextBoxColumn12})
        Me.gvInbox.MasterTemplate.DataSource = Me.bsGvInbox
        Me.gvInbox.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvInbox.MasterTemplate.EnableFiltering = True
        Me.gvInbox.MasterTemplate.EnableGrouping = False
        Me.gvInbox.MasterTemplate.ShowFilteringRow = False
        Me.gvInbox.MasterTemplate.ShowGroupedColumns = True
        Me.gvInbox.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvInbox.Name = "gvInbox"
        Me.gvInbox.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvInbox.R_ConductorGridSource = Me.conGridInbox
        Me.gvInbox.R_ConductorSource = Nothing
        Me.gvInbox.R_DataAdded = False
        Me.gvInbox.R_NewRowText = Nothing
        Me.gvInbox.ShowHeaderCellButtons = True
        Me.gvInbox.Size = New System.Drawing.Size(1271, 164)
        Me.gvInbox.TabIndex = 3
        Me.gvInbox.Text = "R_RadGridView1"
        '
        'bsGvInbox
        '
        Me.bsGvInbox.DataSource = GetType(CST00200Front.CST00200StreamingServiceRef.RCustDBItemInboxDTO)
        '
        'CST00200
        '
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CST00200"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.bsIssueClass, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsIssueType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsFunction, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.btnUpdate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridIssue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridInbox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCustom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnRefresh, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnFilter, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnIssueClass, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        CType(Me.btnRevise, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnCopy, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnPaste, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnAttachment, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblIssueList, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvIssue.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvIssue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvIssue, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        CType(Me.gvInbox.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvInbox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvInbox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblProject As R_FrontEnd.R_RadLabel
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents lblVersion As R_FrontEnd.R_RadLabel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents gvIssue As R_FrontEnd.R_RadGridView
    Friend WithEvents gvInbox As R_FrontEnd.R_RadGridView
    Friend WithEvents conGridInbox As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsGvInbox As System.Windows.Forms.BindingSource
    Friend WithEvents conGridIssue As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsGvIssue As System.Windows.Forms.BindingSource
    Friend WithEvents bsFunction As System.Windows.Forms.BindingSource
    Friend WithEvents bsIssueClass As System.Windows.Forms.BindingSource
    Friend WithEvents btnIssueClass As R_FrontEnd.R_PopUp
    Friend WithEvents lblIssueList As R_FrontEnd.R_RadLabel
    Friend WithEvents btnAttachment As R_FrontEnd.R_PopUp
    Friend WithEvents btnFilter As R_FrontEnd.R_PopUp
    Friend WithEvents txtSession As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtProject As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtVersion As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtApplication As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblSession As R_FrontEnd.R_RadLabel
    Friend WithEvents btnPaste As R_FrontEnd.R_RadButton
    Friend WithEvents btnCopy As R_FrontEnd.R_RadButton
    Friend WithEvents lblSchedule As R_FrontEnd.R_RadLabel
    Friend WithEvents txtSchedule As R_FrontEnd.R_RadTextBox
    Friend WithEvents btnRefresh As R_FrontEnd.R_RadButton
    Friend WithEvents bsIssueType As System.Windows.Forms.BindingSource
    Friend WithEvents btnRevise As R_FrontEnd.R_Detail
    Friend WithEvents lblCustomer As R_FrontEnd.R_RadLabel
    Friend WithEvents lblCustom As R_FrontEnd.R_RadLabel
    Friend WithEvents btnUpdate As R_FrontEnd.R_Detail
End Class
