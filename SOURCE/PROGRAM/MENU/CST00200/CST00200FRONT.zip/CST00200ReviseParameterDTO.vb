﻿Imports CST00200Front.CST00200ServiceRef

<Serializable()> _
Public Class CST00200ReviseParameterDTO
    Public Property OFILTER_KEY As CST00200KeyDTO
    Public Property OISSUE_CLASS_LIST As List(Of CST00200IssueClassComboDTO)
    Public Property OISSUE_TYPE_LIST As List(Of CST00200IssueTypeComboDTO)
    Public Property CAPPS_NAME As String
    Public Property CCODE_NAME As String
    Public Property CPROJECT_NAME As String
    Public Property CITEM_NAME As String
    Public Property CISSUE_CLASS As String
    Public Property CISSUE_TYPE As String
    Public Property CDESCRIPTION As String

    Sub New()
        ' initialization
        OFILTER_KEY = New CST00200KeyDTO
        OISSUE_CLASS_LIST = New List(Of CST00200IssueClassComboDTO)
        OISSUE_TYPE_LIST = New List(Of CST00200IssueTypeComboDTO)
        With OFILTER_KEY
            .CCOMPANY_ID = ""
            .CAPPS_CODE = ""
            .CVERSION = ""
            .CPROJECT_ID = ""
            .CSESSION_ID = ""
            .CSCHEDULE_ID = ""
            .CATTRIBUTE_GROUP = ""
            .CATTRIBUTE_ID = ""
            .CITEM_ID = ""
            .CISSUE_ID = ""
            .CUSER_ID = ""
        End With
        CAPPS_NAME = ""
        CPROJECT_NAME = ""
        CISSUE_CLASS = ""
    End Sub

End Class
