﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CST00200IssueClass
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn7 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewComboBoxColumn4 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Dim R_GridViewTextBoxColumn8 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.bsIssueType = New System.Windows.Forms.BindingSource(Me.components)
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtApplication = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvIssueType = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvIssueClass = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridIssueClass = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.R_ReturnPopUp1 = New R_FrontEnd.R_ReturnPopUp()
        Me.btnCancel = New R_FrontEnd.R_RadButton(Me.components)
        Me.btnOk = New R_FrontEnd.R_RadButton(Me.components)
        CType(Me.bsIssueType, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvIssueType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvIssueType.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvIssueClass, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridIssueClass, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_ReturnPopUp1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.R_ReturnPopUp1.SuspendLayout()
        CType(Me.btnCancel, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnOk, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'bsIssueType
        '
        Me.bsIssueType.DataSource = GetType(CST00200Front.CST00200ServiceRef.CST00200IssueTypeComboDTO)
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.R_ReturnPopUp1, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.gvIssueType, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(588, 267)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.txtApplication)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(582, 34)
        Me.Panel1.TabIndex = 0
        '
        'txtApplication
        '
        Me.txtApplication.Location = New System.Drawing.Point(115, 8)
        Me.txtApplication.Name = "txtApplication"
        Me.txtApplication.R_ConductorGridSource = Nothing
        Me.txtApplication.R_ConductorSource = Nothing
        Me.txtApplication.R_UDT = Nothing
        Me.txtApplication.ReadOnly = True
        Me.txtApplication.Size = New System.Drawing.Size(407, 20)
        Me.txtApplication.TabIndex = 28
        Me.txtApplication.TabStop = False
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 27
        Me.lblApplication.Text = "Application..."
        '
        'gvIssueType
        '
        Me.gvIssueType.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvIssueType.EnableFastScrolling = True
        Me.gvIssueType.Location = New System.Drawing.Point(3, 43)
        '
        '
        '
        Me.gvIssueType.MasterTemplate.AutoGenerateColumns = False
        Me.gvIssueType.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn7.FieldName = "_CISSUE_CLASS"
        R_GridViewTextBoxColumn7.HeaderText = "_CISSUE_CLASS"
        R_GridViewTextBoxColumn7.Name = "_CISSUE_CLASS"
        R_GridViewTextBoxColumn7.R_EnableADD = True
        R_GridViewTextBoxColumn7.R_ResourceId = "_CISSUE_CLASS"
        R_GridViewTextBoxColumn7.R_UDT = Nothing
        R_GridViewTextBoxColumn7.Width = 210
        R_GridViewComboBoxColumn4.DataSource = Me.bsIssueType
        R_GridViewComboBoxColumn4.DisplayMember = "CDESCRIPTION"
        R_GridViewComboBoxColumn4.FieldName = "_CISSUE_TYPE"
        R_GridViewComboBoxColumn4.HeaderText = "_CISSUE_TYPE"
        R_GridViewComboBoxColumn4.Name = "_CISSUE_TYPE"
        R_GridViewComboBoxColumn4.R_EnableADD = True
        R_GridViewComboBoxColumn4.R_ResourceId = "_CISSUE_TYPE"
        R_GridViewComboBoxColumn4.ValueMember = "CISSUE_TYPE"
        R_GridViewComboBoxColumn4.Width = 116
        R_GridViewTextBoxColumn8.FieldName = "_CDESCRIPTION"
        R_GridViewTextBoxColumn8.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxColumn8.Name = "_CDESCRIPTION"
        R_GridViewTextBoxColumn8.R_EnableADD = True
        R_GridViewTextBoxColumn8.R_EnableEDIT = True
        R_GridViewTextBoxColumn8.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxColumn8.R_UDT = Nothing
        R_GridViewTextBoxColumn8.Width = 238
        Me.gvIssueType.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn7, R_GridViewComboBoxColumn4, R_GridViewTextBoxColumn8})
        Me.gvIssueType.MasterTemplate.DataSource = Me.bsGvIssueClass
        Me.gvIssueType.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvIssueType.MasterTemplate.EnableFiltering = True
        Me.gvIssueType.MasterTemplate.EnableGrouping = False
        Me.gvIssueType.MasterTemplate.ShowFilteringRow = False
        Me.gvIssueType.MasterTemplate.ShowGroupedColumns = True
        Me.gvIssueType.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvIssueType.Name = "gvIssueType"
        Me.gvIssueType.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvIssueType.R_ConductorGridSource = Me.conGridIssueClass
        Me.gvIssueType.R_ConductorSource = Nothing
        Me.gvIssueType.R_DataAdded = False
        Me.gvIssueType.R_NewRowText = Nothing
        Me.gvIssueType.ShowHeaderCellButtons = True
        Me.gvIssueType.Size = New System.Drawing.Size(582, 185)
        Me.gvIssueType.TabIndex = 1
        Me.gvIssueType.Text = "R_RadGridView1"
        '
        'bsGvIssueClass
        '
        Me.bsGvIssueClass.DataSource = GetType(CST00200Front.CST00200IssueClassStreamingServiceRef.CST00200IssueClassGridDTO)
        '
        'conGridIssueClass
        '
        Me.conGridIssueClass.R_ConductorParent = Nothing
        Me.conGridIssueClass.R_IsHeader = True
        Me.conGridIssueClass.R_RadGroupBox = Nothing
        '
        'R_ReturnPopUp1
        '
        Me.R_ReturnPopUp1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.R_ReturnPopUp1.Controls.Add(Me.btnCancel)
        Me.R_ReturnPopUp1.Controls.Add(Me.btnOk)
        Me.R_ReturnPopUp1.Location = New System.Drawing.Point(504, 234)
        Me.R_ReturnPopUp1.Name = "R_ReturnPopUp1"
        Me.R_ReturnPopUp1.Size = New System.Drawing.Size(81, 30)
        Me.R_ReturnPopUp1.TabIndex = 2
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(84, 3)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.R_ConductorGridSource = Nothing
        Me.btnCancel.R_ConductorSource = Nothing
        Me.btnCancel.R_DescriptionId = Nothing
        Me.btnCancel.R_ResourceId = Nothing
        Me.btnCancel.Size = New System.Drawing.Size(75, 23)
        Me.btnCancel.TabIndex = 1
        Me.btnCancel.Text = "Cancel"
        '
        'btnOk
        '
        Me.btnOk.Location = New System.Drawing.Point(3, 3)
        Me.btnOk.Name = "btnOk"
        Me.btnOk.R_ConductorGridSource = Nothing
        Me.btnOk.R_ConductorSource = Nothing
        Me.btnOk.R_DescriptionId = Nothing
        Me.btnOk.R_ResourceId = Nothing
        Me.btnOk.Size = New System.Drawing.Size(75, 23)
        Me.btnOk.TabIndex = 0
        Me.btnOk.Text = "OK"
        '
        'CST00200IssueClass
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(588, 267)
        Me.ControlBox = False
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CST00200IssueClass"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.bsIssueType, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvIssueType.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvIssueType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvIssueClass, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridIssueClass, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_ReturnPopUp1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.R_ReturnPopUp1.ResumeLayout(False)
        CType(Me.btnCancel, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnOk, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents txtApplication As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents gvIssueType As R_FrontEnd.R_RadGridView
    Friend WithEvents bsGvIssueClass As System.Windows.Forms.BindingSource
    Friend WithEvents conGridIssueClass As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsIssueType As System.Windows.Forms.BindingSource
    Friend WithEvents R_ReturnPopUp1 As R_FrontEnd.R_ReturnPopUp
    Friend WithEvents btnCancel As R_FrontEnd.R_RadButton
    Friend WithEvents btnOk As R_FrontEnd.R_RadButton

End Class
