﻿Imports CST00200FrontResources
Imports R_Common
Imports CST00200Front.CST00200ServiceRef
Imports CST00200Front.CST00200StreamingServiceRef
Imports ClientHelper
Imports R_FrontEnd
Imports System.ServiceModel.Channels
Imports RCustDBFrontHelper

Public Class CST00200

#Region " VARIABLE "
    Dim C_ServiceName As String = "CST00200Service/CST00200Service.svc"
    Dim C_ServiceNameStream As String = "CST00200Service/CST00200StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _CVERSION As String
    Dim _CPROJECTID As String
    Dim _CSESSIONID As String
    Dim _CSCHEDULEID As String
    Dim _CUSER_NAME As String
    Dim _CFUNCTIONID As String
    Dim _LINIT As Boolean
    Dim _CATTRIBUTEGROUP As String
    Dim _CATTRIBUTEID As String
    Dim _CITEMID As String
    Dim _CITEM_NAME As String
    Dim _CACTION As String
    Dim _CISSUE_ID As String
    Dim _CISSUE_CLASS As String
    Dim _CISSUE_TYPE As String
    Dim _CDESCRIPTION As String
    Dim loFilterParam As New CST00200FilterParameterDTO
    Dim _OISSUE_CLIPBOARD As CST00200GridDTO
    Dim _CREVISE_SCHEDULE_ID As String
    Dim _CORIATTRIBUTEGROUP As String
    Dim _CORIATTRIBUTEID As String
    Dim _CORIITEMID As String
    Dim _CORIISSUE_ID As String

#End Region

#Region " SUBs and FUNCTIONs "

    Private Sub RefreshGrids(poKey As RCustDBInboxKeyDTO)
        If _LINIT Then
            With gvInbox
                .R_RefreshGrid(poKey)
            End With
        End If
    End Sub

    Private Sub ComboManager(pcCode As String, pcValue As String)
        Dim loSvc As CST00200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00200Service, CST00200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loProjectKey As New RCustDBProjectKeyDTO

        ' Refresh Combo
        '_LDONE_COMBO_SETTING = False
        Select Case pcCode
            Case "_CISSUE_CLASS"
                Dim loIssueClassCombo As New List(Of CST00200IssueClassComboDTO)
                loIssueClassCombo = loSvc.GetIssueClassCombo(New CST00200KeyDTO With {.CCOMPANY_ID = _CCOMPID,
                                                                                    .CAPPS_CODE = _CAPPSCODE})
                bsIssueClass.DataSource = loIssueClassCombo
                Dim loIssueTypeCombo As New List(Of CST00200IssueTypeComboDTO)
                loIssueTypeCombo = loSvc.GetIssueTypeCombo()
                bsIssueType.DataSource = loIssueTypeCombo
        End Select
        loSvc.Close()

    End Sub

#End Region

#Region " FILTER "

    Private Sub btnFilter_R_After_Open_Form(poPopUpResult As System.Windows.Forms.DialogResult, poPopUpEntityResult As Object) Handles btnFilter.R_After_Open_Form
        Dim loGridKey As New RCustDBInboxKeyDTO

        If poPopUpResult = Windows.Forms.DialogResult.OK Then
            loFilterParam = poPopUpEntityResult
            With loFilterParam
                _CAPPSCODE = .OFILTER_KEY.CAPPS_CODE
                _CVERSION = .OFILTER_KEY.CVERSION
                _CPROJECTID = .OFILTER_KEY.CPROJECT_ID
                _CSESSIONID = .OFILTER_KEY.CSESSION_ID
                _CSCHEDULEID = .OFILTER_KEY.CSCHEDULE_ID
                _CFUNCTIONID = "QC"
                txtApplication.Text = .CAPPS_NAME
                txtVersion.Text = IIf(.LCUSTOM, .CCUSTOMER_NAME, .CCODE_NAME)
                txtProject.Text = .CPROJECT_NAME
                txtSession.Text = .OFILTER_KEY.CSESSION_ID
                txtSchedule.Text = .OFILTER_KEY.CSCHEDULE_ID
                lblVersion.Visible = Not .LCUSTOM
                lblCustomer.Visible = .LCUSTOM
                lblCustom.Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), IIf(.LCUSTOM, "rdbCustom", "rdbStandard"))
            End With
            If Not (String.IsNullOrEmpty(_CAPPSCODE) Or String.IsNullOrEmpty(_CVERSION) Or String.IsNullOrEmpty(_CPROJECTID)) Then
                With loGridKey
                    .CCOMPANY_ID = _CCOMPID
                    .CAPPS_CODE = _CAPPSCODE
                    .CVERSION = _CVERSION
                    .CPROJECT_ID = _CPROJECTID
                    .CSESSION_ID = _CSESSIONID
                    .CSCHEDULE_ID = _CSCHEDULEID
                    .CFUNCTION_ID = _CFUNCTIONID
                    .CATTRIBUTE_GROUP = _CATTRIBUTEGROUP
                    .CUSER_ID = _CUSERID
                End With
                ComboManager("_CISSUE_CLASS", Nothing)
                RefreshGrids(loGridKey)
            End If
        End If
    End Sub

    Private Sub btnFilter_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnFilter.R_Before_Open_Form
        poTargetForm = New CST00200Filter
        poParameter = loFilterParam
    End Sub

#End Region

#Region " FORM Events "

    Private Sub CST00200_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loComboKey As New RCustDBProjectKeyDTO

        Try
            _LINIT = False
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            _CATTRIBUTEGROUP = "PROGRAM"
            _CFUNCTIONID = "QC"
            _LINIT = True
            With loComboKey
                .CCOMPANY_ID = _CCOMPID
                .CUSER_ID = _CUSERID
            End With
            loFilterParam.OFILTER_KEY.CCOMPANY_ID = _CCOMPID
            btnFilter.PerformClick()
            _OISSUE_CLIPBOARD = New CST00200GridDTO
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub CST00200_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " INBOX Gridview "

    Private Sub gvInbox_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvInbox.DataBindingComplete
        gvInbox.BestFitColumns()
    End Sub

    Private Sub gvInbox_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvInbox.R_Display
        Dim loEx As New R_Exception
        Dim loTableKey As New RCustDBItemInboxDTO

        Try
            loTableKey = CType(bsGvInbox.Current, RCustDBItemInboxDTO)
            With loTableKey
                _CSESSIONID = .CSESSION_ID
                _CATTRIBUTEID = .CATTRIBUTE_ID
                _CITEMID = .CITEM_ID
                _CSCHEDULEID = .CSCHEDULE_ID
                _CITEM_NAME = .CITEM_ID.Trim + " - " + .CITEM_NAME.Trim
            End With
            gvIssue.R_RefreshGrid(loTableKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvInbox_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvInbox.R_ServiceGetListRecord
        Dim loServiceStream As CST00200StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00200StreamingService, CST00200StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of RCustDBItemInboxDTO)
        Dim loListEntity As New List(Of RCustDBItemInboxDTO)

        Try
            With CType(poEntity, RCustDBInboxKeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
                R_Utility.R_SetStreamingContext("cProjectId", .CPROJECT_ID)
                R_Utility.R_SetStreamingContext("cSessionId", .CSESSION_ID)
                R_Utility.R_SetStreamingContext("cScheduleId", .CSCHEDULE_ID)
                R_Utility.R_SetStreamingContext("cFunctionId", .CFUNCTION_ID)
                R_Utility.R_SetStreamingContext("cAttributeGroup", .CATTRIBUTE_GROUP)
                R_Utility.R_SetStreamingContext("cUserId", .CUSER_ID)
            End With

            loRtn = loServiceStream.GetItemInbox()
            loStreaming = R_StreamUtility(Of RCustDBItemInboxDTO).ReadFromMessage(loRtn)

            For Each loDto As RCustDBItemInboxDTO In loStreaming
                If loDto IsNot Nothing Then
                    With loDto
                        .DPLAN_START_DATE = General.StrToDate(.CPLAN_START_DATE)
                        .DPLAN_END_DATE = General.StrToDate(.CPLAN_END_DATE)
                        .DREVISED_START_DATE = General.StrToDate(.CREVISED_START_DATE)
                        .DREVISED_END_DATE = General.StrToDate(.CREVISED_END_DATE)
                    End With
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub conGridInbox_R_SetHasData(plEnable As Boolean) Handles conGridInbox.R_SetHasData
        gvIssue.Enabled = plEnable
    End Sub

#End Region

#Region " ISSUE Gridview "

    Private Sub gvIssue_CellValueChanged(sender As Object, e As Telerik.WinControls.UI.GridViewCellEventArgs) Handles gvIssue.CellValueChanged
        If e.Column.Name.Equals("_CISSUE_CLASS") Then
            e.Row.Cells("_CISSUE_TYPE").Value = CType(bsIssueClass.Current, CST00200IssueClassComboDTO).CISSUE_TYPE.ToString
            _CISSUE_CLASS = CType(bsIssueClass.Current, CST00200IssueClassComboDTO).CDESCRIPTION.ToString
        End If
    End Sub

    Private Sub gvIssue_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvIssue.DataBindingComplete
        With gvIssue
            '.BestFitColumns()
            .Columns("_CDESCRIPTION").Width = 360
        End With
    End Sub

    Private Sub gvIssue_R_Before_Open_LookUpForm(sender As Object, e As Telerik.WinControls.UI.EditorRequiredEventArgs, ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles gvIssue.R_Before_Open_LookUpForm
        poTargetForm = New CST00200Description
        poParameter = New CST00200DTO With {._CDESCRIPTION = gvIssue.CurrentRow.Cells("_CDESCRIPTION").Value}
    End Sub

    Private Sub gvIssue_R_CheckGridAdd(poEntityCollection As Object, ByRef plAllowGridAdd As Boolean) Handles gvIssue.R_CheckGridAdd
        If bsGvInbox.Count > 0 Then
            With CType(bsGvInbox.Current, RCustDBItemInboxDTO)
                plAllowGridAdd = (.CLAST_ACTION = "QCCO" And .CLAST_ACTION_BY = _CUSERID)
            End With
        End If
    End Sub

    Private Sub gvIssue_R_CheckGridDelete(poEntityCollection As Object, ByRef plAllowGridDelete As Boolean) Handles gvIssue.R_CheckGridDelete
        If bsGvInbox.Count > 0 Then
            With CType(bsGvInbox.Current, RCustDBItemInboxDTO)
                plAllowGridDelete = (.CLAST_ACTION = "QCCO" And .CLAST_ACTION_BY = _CUSERID)
            End With
        End If
    End Sub

    Private Sub gvIssue_R_CheckGridEdit(poEntityCollection As Object, ByRef plAllowGridEdit As Boolean) Handles gvIssue.R_CheckGridEdit
        If bsGvInbox.Count > 0 Then
            With CType(bsGvInbox.Current, RCustDBItemInboxDTO)
                plAllowGridEdit = (.CLAST_ACTION = "QCCO" And .CLAST_ACTION_BY = _CUSERID)
            End With
        End If
    End Sub

    Private Sub gvIssue_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvIssue.R_Display
        With CType(poEntity, CST00200DTO)
            _CREVISE_SCHEDULE_ID = ._CSCHEDULE_ID
            _CISSUE_ID = ._CISSUE_ID
            _CISSUE_TYPE = ._CISSUE_TYPE
            _CDESCRIPTION = ._CDESCRIPTION
            _CORIATTRIBUTEGROUP = IIf(._CORI_ATTRIBUTE_GROUP.Trim.Equals(""), ._CATTRIBUTE_GROUP, ._CORI_ATTRIBUTE_GROUP)
            _CORIATTRIBUTEID = IIf(._CORI_ATTRIBUTE_ID.Trim.Equals(""), ._CATTRIBUTE_ID, ._CORI_ATTRIBUTE_ID)
            _CORIITEMID = IIf(._CORI_ITEM_ID.Trim.Equals(""), ._CITEM_ID, ._CORI_ITEM_ID)
            _CORIISSUE_ID = IIf(._CORI_ISSUE_ID.Trim.Equals(""), ._CISSUE_ID, ._CORI_ISSUE_ID)
            If bsIssueClass.Count > 0 Then
                _CISSUE_CLASS = (From item In CType(bsIssueClass.List, IList(Of CST00200IssueClassComboDTO)) Where item.CISSUE_CLASS = ._CISSUE_CLASS).FirstOrDefault.CDESCRIPTION
                _CISSUE_TYPE = (From item In CType(bsIssueType.List, IList(Of CST00200IssueTypeComboDTO)) Where item.CISSUE_TYPE = ._CISSUE_TYPE).FirstOrDefault.CDESCRIPTION
            Else
                _CISSUE_CLASS = ""
                _CISSUE_TYPE = ""
            End If
        End With
    End Sub

    Private Sub gvIssue_R_Return_LookUp(sender As Object, e As Telerik.WinControls.UI.EditorRequiredEventArgs, poReturnObject As Object) Handles gvIssue.R_Return_LookUp
        e.Editor.Value = poReturnObject._CDESCRIPTION
    End Sub

    Private Sub gvIssue_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvIssue.R_Saving
        With CType(poEntity, CST00200DTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = _CAPPSCODE
            ._CVERSION = _CVERSION
            ._CPROJECT_ID = _CPROJECTID
            ._CSESSION_ID = _CSESSIONID
            ._CATTRIBUTE_GROUP = _CATTRIBUTEGROUP
            ._CATTRIBUTE_ID = _CATTRIBUTEID
            ._CITEM_ID = _CITEMID
            ._CUSER_ID = _CUSERID
            ._CPREV_SCHEDULE_ID = _CSCHEDULEID
            ._CCREATE_BY = _CUSERID
            ._CUPDATE_BY = _CUSERID
        End With
    End Sub

    Private Sub gvIssue_R_ServiceDelete(poEntity As Object) Handles gvIssue.R_ServiceDelete
        Dim loService As CST00200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00200Service, CST00200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String

        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvIssue_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvIssue.R_ServiceGetListRecord
        Dim loServiceStream As CST00200StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00200StreamingService, CST00200StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CST00200GridDTO)
        Dim loListEntity As New List(Of CST00200DTO)

        Try
            With CType(poEntity, RCustDBItemInboxDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
                R_Utility.R_SetStreamingContext("cProjectId", .CPROJECT_ID)
                R_Utility.R_SetStreamingContext("cSessionId", .CSESSION_ID)
                R_Utility.R_SetStreamingContext("cFunctionId", .CFUNCTION_ID)
                R_Utility.R_SetStreamingContext("cAttributeGroup", .CATTRIBUTE_GROUP)
                R_Utility.R_SetStreamingContext("cAttributeId", .CATTRIBUTE_ID)
                R_Utility.R_SetStreamingContext("cItemId", .CITEM_ID)
                R_Utility.R_SetStreamingContext("cScheduleId", "*")
                R_Utility.R_SetStreamingContext("cPrevScheduleId", "*")
            End With

            loRtn = loServiceStream.GetIssueList()
            loStreaming = R_StreamUtility(Of CST00200GridDTO).ReadFromMessage(loRtn)

            For Each loDto As CST00200GridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New CST00200DTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                           ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                           ._CVERSION = loDto.CVERSION,
                                                           ._CPROJECT_ID = loDto.CPROJECT_ID,
                                                           ._CSESSION_ID = loDto.CSESSION_ID,
                                                           ._CATTRIBUTE_GROUP = loDto.CATTRIBUTE_GROUP,
                                                           ._CATTRIBUTE_ID = loDto.CATTRIBUTE_ID,
                                                           ._CITEM_ID = loDto.CITEM_ID,
                                                           ._CISSUE_ID = loDto.CISSUE_ID,
                                                           ._CUSER_ID = loDto.CUSER_ID,
                                                           ._DISSUE_DATE = General.StrToDate(loDto.CISSUE_DATE),
                                                           ._CISSUE_CLASS = loDto.CISSUE_CLASS,
                                                           ._CISSUE_TYPE = loDto.CISSUE_TYPE,
                                                           ._CDESCRIPTION = loDto.CDESCRIPTION,
                                                           ._CSCHEDULE_ID = loDto.CSCHEDULE_ID,
                                                           ._CPREV_SCHEDULE_ID = loDto.CPREV_SCHEDULE_ID,
                                                           ._LOK = loDto.LOK,
                                                           ._CORI_ATTRIBUTE_GROUP = loDto.CORI_ATTRIBUTE_GROUP,
                                                           ._CORI_ATTRIBUTE_ID = loDto.CORI_ATTRIBUTE_ID,
                                                           ._CORI_ISSUE_ID = loDto.CORI_ISSUE_ID,
                                                           ._CORI_ITEM_ID = loDto.CORI_ITEM_ID})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvIssue_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvIssue.R_ServiceGetRecord
        Dim loService As CST00200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00200Service, CST00200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New CST00200DTO With {._CCOMPANY_ID = _CCOMPID,
                                                                             ._CAPPS_CODE = _CAPPSCODE,
                                                                             ._CVERSION = _CVERSION,
                                                                             ._CPROJECT_ID = _CPROJECTID,
                                                                             ._CSESSION_ID = _CSESSIONID,
                                                                             ._CATTRIBUTE_GROUP = _CATTRIBUTEGROUP,
                                                                             ._CATTRIBUTE_ID = _CATTRIBUTEID,
                                                                             ._CITEM_ID = _CITEMID,
                                                                             ._CISSUE_ID = CType(bsGvIssue.Current, CST00200DTO)._CISSUE_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvIssue_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvIssue.R_ServiceSave
        Dim loService As CST00200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00200Service, CST00200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String
        Dim lcPredefinedErr As String

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
            poEntityResult._DISSUE_DATE = General.StrToDate(poEntityResult._CISSUE_DATE)
        Catch ex As Exception
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            lcPredefinedErr = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr)
            If lcPredefinedErr IsNot Nothing Then
                loEx.ErrorList.Clear()
                loEx.Add(lcErr, lcPredefinedErr)
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvIssue_R_SetEditGridColumn(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, poGridColumnCollection As Telerik.WinControls.UI.GridViewColumnCollection) Handles gvIssue.R_SetEditGridColumn
        Dim llEnableOK As Boolean
        Dim llEnableIssueType As Boolean

        llEnableOK = (gvInbox.CurrentRow.Cells("_CSCHEDULE_ID").Value = CType(poEntity, CST00200DTO)._CSCHEDULE_ID)
        CType(poGridColumnCollection("_LOK"), R_GridViewCheckBoxColumn).ReadOnly = Not llEnableOK
        llEnableIssueType = (CType(poEntity, CST00200DTO)._CSCHEDULE_ID = "")
        CType(poGridColumnCollection("_CISSUE_CLASS"), R_GridViewComboBoxColumn).ReadOnly = Not llEnableIssueType
        CType(poGridColumnCollection("_CISSUE_TYPE"), R_GridViewComboBoxColumn).ReadOnly = Not llEnableIssueType

    End Sub

    Private Sub gvIssue_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvIssue.R_Validation
        Dim loEx As New R_Exception()

        Try
            With poGridCellCollection
                If String.IsNullOrWhiteSpace(.Item("_CISSUE_ID").Value) Then
                    loEx.Add("CST00200_01", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CST00200_01"))
                    plCancel = True
                End If
                If String.IsNullOrWhiteSpace(.Item("_CISSUE_TYPE").Value) Then
                    loEx.Add("CST00200_02", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CST00200_02"))
                    plCancel = True
                End If
                If String.IsNullOrWhiteSpace(.Item("_CDESCRIPTION").Value) Then
                    loEx.Add("CST00200_03", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CST00200_03"))
                    plCancel = True
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " ISSUE CLASS button "

    Private Sub btnIssueClass_R_After_Open_Form(poPopUpResult As System.Windows.Forms.DialogResult, poPopUpEntityResult As Object) Handles btnIssueClass.R_After_Open_Form
        ComboManager("_CISSUE_CLASS", Nothing)
    End Sub

    Private Sub btnIssueClass_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnIssueClass.R_Before_Open_Form
        poTargetForm = New CST00200IssueClass
        With CType(poTargetForm, CST00200IssueClass)
            .Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "btnIssueClass")
            .CAPPS_NAME = txtApplication.Text
        End With

        poParameter = New CST00200KeyDTO With {.CCOMPANY_ID = _CCOMPID, .CAPPS_CODE = _CAPPSCODE}
    End Sub

#End Region

#Region " ATTACHMENT button "

    Private Sub btnAttachment_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnAttachment.R_Before_Open_Form
        poTargetForm = New CST00200Attach
        With CType(poTargetForm, CST00200Attach)
            .Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "btnAttachment")
        End With

        poParameter = New CST00200KeyDTO
        With poParameter
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = _CAPPSCODE
            .CVERSION = _CVERSION
            .CPROJECT_ID = _CPROJECTID
            .CSESSION_ID = _CSESSIONID
            .CFUNCTION_ID = _CFUNCTIONID
            .CATTRIBUTE_GROUP = _CATTRIBUTEGROUP
            .CATTRIBUTE_ID = _CATTRIBUTEID
            .CITEM_ID = _CITEMID
            .CISSUE_ID = _CISSUE_ID
        End With
    End Sub

#End Region

#Region " SCHEDULE button "
    Private Sub btnSchedule_Click(sender As Object, e As System.EventArgs)
        Dim loException As New R_Exception
        Dim loService As CST00200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00200Service, CST00200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loTableKey As New RCustDBItemInboxDTO

        Try
            loService.ScheduleIssue(loFilterParam.OFILTER_KEY)
            loTableKey = CType(bsGvInbox.Current, RCustDBItemInboxDTO)
            With loTableKey
                _CSESSIONID = .CSESSION_ID
                _CATTRIBUTEID = .CATTRIBUTE_ID
                _CITEMID = .CITEM_ID
                _CSCHEDULEID = .CSCHEDULE_ID
            End With
            gvIssue.R_RefreshGrid(loTableKey)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        If loException.Haserror Then
            Me.R_DisplayException(loException)
        End If
    End Sub
#End Region

#Region " COPY & PASTE ISSUE button "

    Private Sub btnCopy_Click(sender As System.Object, e As System.EventArgs) Handles btnCopy.Click
        If gvIssue.CurrentRow IsNot Nothing Then
            With gvIssue.CurrentRow
                _OISSUE_CLIPBOARD.CISSUE_ID = .Cells("_CISSUE_ID").Value
                _OISSUE_CLIPBOARD.CISSUE_CLASS = .Cells("_CISSUE_CLASS").Value
                _OISSUE_CLIPBOARD.CDESCRIPTION = .Cells("_CDESCRIPTION").Value
            End With
        End If
    End Sub

    Private Sub btnPaste_Click(sender As System.Object, e As System.EventArgs) Handles btnPaste.Click
        If gvIssue.IsInEditMode Then
            With gvIssue.CurrentRow
                .Cells("_CISSUE_ID").Value = _OISSUE_CLIPBOARD.CISSUE_ID
                .Cells("_CISSUE_CLASS").Value = _OISSUE_CLIPBOARD.CISSUE_CLASS
                .Cells("_CDESCRIPTION").Value = _OISSUE_CLIPBOARD.CDESCRIPTION
            End With
            gvIssue.EndEdit()
        End If
    End Sub

#End Region

#Region " REFRESH button "

    Private Sub btnRefresh_Click(sender As Object, e As System.EventArgs) Handles btnRefresh.Click
        Dim loGridKey As New RCustDBInboxKeyDTO

        If Not (String.IsNullOrEmpty(_CAPPSCODE) Or String.IsNullOrEmpty(_CVERSION) Or String.IsNullOrEmpty(_CPROJECTID)) Then
            With loGridKey
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = _CAPPSCODE
                .CVERSION = _CVERSION
                .CPROJECT_ID = _CPROJECTID
                .CSESSION_ID = _CSESSIONID
                .CSCHEDULE_ID = _CSCHEDULEID
                .CFUNCTION_ID = _CFUNCTIONID
                .CATTRIBUTE_GROUP = _CATTRIBUTEGROUP
                .CUSER_ID = _CUSERID
            End With
            RefreshGrids(loGridKey)
        End If
    End Sub

#End Region

#Region " REVISE button "

    Private Sub btnRevise_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnRevise.R_Before_Open_Form
        Dim loPICKey As New CST00200KeyDTO

        poTargetForm = New CST00200Revise

        With loPICKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = _CAPPSCODE
            .CVERSION = _CVERSION
            .CPROJECT_ID = _CPROJECTID
            .CSESSION_ID = _CSESSIONID
            .CATTRIBUTE_GROUP = _CATTRIBUTEGROUP
            .CATTRIBUTE_ID = _CATTRIBUTEID
            .CITEM_ID = _CITEMID
            .CISSUE_ID = _CISSUE_ID
            .CSCHEDULE_ID = _CREVISE_SCHEDULE_ID
        End With
        poParameter = New CST00200ReviseParameterDTO With {.CAPPS_NAME = txtApplication.Text.Trim, _
                                                        .CPROJECT_NAME = txtProject.Text.Trim, _
                                                        .CITEM_NAME = _CITEM_NAME, _
                                                           .CISSUE_CLASS = _CISSUE_CLASS, _
                                                           .CISSUE_TYPE = _CISSUE_TYPE, _
                                                           .CDESCRIPTION = _CDESCRIPTION, _
                                                        .OFILTER_KEY = loPICKey, _
                                                           .OISSUE_CLASS_LIST = bsIssueClass.DataSource, _
                                                           .OISSUE_TYPE_LIST = bsIssueType.DataSource}
    End Sub

#End Region

#Region " UPDATE button "

    Private Sub btnUpdate_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnUpdate.R_Before_Open_Form
        Dim loPICKey As New CST00200KeyDTO

        poTargetForm = New CST00200Update

        With loPICKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = _CAPPSCODE
            .CVERSION = _CVERSION
            .CPROJECT_ID = _CPROJECTID
            .CSESSION_ID = _CSESSIONID
            .CATTRIBUTE_GROUP = _CATTRIBUTEGROUP
            .CATTRIBUTE_ID = _CATTRIBUTEID
            .CITEM_ID = _CITEMID
            .CISSUE_ID = _CISSUE_ID
            .CSCHEDULE_ID = _CREVISE_SCHEDULE_ID
        End With
        poParameter = New CST00200ReviseParameterDTO With {.CAPPS_NAME = txtApplication.Text.Trim,
                                                        .CPROJECT_NAME = txtProject.Text.Trim,
                                                        .CITEM_NAME = _CITEM_NAME,
                                                           .CISSUE_CLASS = _CISSUE_CLASS,
                                                           .CISSUE_TYPE = _CISSUE_TYPE,
                                                           .CDESCRIPTION = _CDESCRIPTION,
                                                        .OFILTER_KEY = loPICKey,
                                                           .OISSUE_CLASS_LIST = bsIssueClass.DataSource,
                                                           .OISSUE_TYPE_LIST = bsIssueType.DataSource}
    End Sub

#End Region

End Class
