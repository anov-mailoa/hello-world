﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CST00200Description
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.R_ReturnLookUpAndFind1 = New R_FrontEnd.R_ReturnLookUpAndFind()
        Me.bsRetVal = New System.Windows.Forms.BindingSource(Me.components)
        Me.txtDescription = New R_FrontEnd.R_RadTextBox(Me.components)
        CType(Me.bsRetVal, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDescription, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'R_ReturnLookUpAndFind1
        '
        Me.R_ReturnLookUpAndFind1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.R_ReturnLookUpAndFind1.Location = New System.Drawing.Point(270, 188)
        Me.R_ReturnLookUpAndFind1.Name = "R_ReturnLookUpAndFind1"
        Me.R_ReturnLookUpAndFind1.R_BindingSource = Me.bsRetVal
        Me.R_ReturnLookUpAndFind1.Size = New System.Drawing.Size(162, 31)
        Me.R_ReturnLookUpAndFind1.TabIndex = 2
        '
        'bsRetVal
        '
        Me.bsRetVal.DataSource = GetType(CST00200Front.CST00200ServiceRef.CST00200DTO)
        '
        'txtDescription
        '
        Me.txtDescription.AcceptsReturn = True
        Me.txtDescription.AutoSize = False
        Me.txtDescription.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsRetVal, "_CDESCRIPTION", True))
        Me.txtDescription.Location = New System.Drawing.Point(12, 12)
        Me.txtDescription.Multiline = True
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.R_ConductorGridSource = Nothing
        Me.txtDescription.R_ConductorSource = Nothing
        Me.txtDescription.R_UDT = Nothing
        Me.txtDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtDescription.Size = New System.Drawing.Size(420, 170)
        Me.txtDescription.TabIndex = 3
        '
        'CST00200Description
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(453, 231)
        Me.Controls.Add(Me.txtDescription)
        Me.Controls.Add(Me.R_ReturnLookUpAndFind1)
        Me.Name = "CST00200Description"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "User List"
        CType(Me.bsRetVal, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDescription, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents R_ReturnLookUpAndFind1 As R_FrontEnd.R_ReturnLookUpAndFind
    Friend WithEvents txtDescription As R_FrontEnd.R_RadTextBox
    Friend WithEvents bsRetVal As System.Windows.Forms.BindingSource

End Class
