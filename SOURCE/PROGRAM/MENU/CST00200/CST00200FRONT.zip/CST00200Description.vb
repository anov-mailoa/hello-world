﻿Imports CST00200FrontResources
Imports R_Common

Public Class CST00200Description

#Region " VARIABLE "
    Dim C_ServiceNameStream As String = "CSM00500Service/CSM00500StreamingService.svc"
#End Region

    Private Sub CSM00500Manager_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Try
            'gvManager.R_RefreshGrid(poParameter)
            bsRetVal.DataSource = poParameter
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

End Class
