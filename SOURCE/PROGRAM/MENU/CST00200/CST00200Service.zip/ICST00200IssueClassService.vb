﻿Imports System.ServiceModel
Imports CST00200Back
Imports R_BackEnd

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICST00200IssueTypeService" in both code and config file together.
<ServiceContract()>
Public Interface ICST00200IssueClassService
    Inherits R_IServicebase(Of CST00200IssueClassDTO)

End Interface
