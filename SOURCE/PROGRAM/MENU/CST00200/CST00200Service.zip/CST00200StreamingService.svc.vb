﻿Imports R_Common
Imports RLicenseBack
Imports System.ServiceModel.Channels
Imports CST00200Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "CST00200StreamingService" in code, svc and config file together.
Public Class CST00200StreamingService
    Implements ICST00200StreamingService

    Public Function GetIssueList() As System.ServiceModel.Channels.Message Implements ICST00200StreamingService.GetIssueList
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtnTemp As List(Of RCustDBIssueListDTO)
        Dim loRtn As Message
        Dim loTableKey As New RCustDBIssueKeyDTO
        Dim loRtnTemp2 As List(Of CST00200GridDTO)

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .CPROJECT_ID = R_Utility.R_GetStreamingContext("cProjectId")
                .CSESSION_ID = R_Utility.R_GetStreamingContext("cSessionId")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CATTRIBUTE_ID = R_Utility.R_GetStreamingContext("cAttributeId")
                .CITEM_ID = R_Utility.R_GetStreamingContext("cItemId")
                .CSCHEDULE_ID = R_Utility.R_GetStreamingContext("cScheduleId")
                .CPREV_SCHEDULE_ID = R_Utility.R_GetStreamingContext("cPrevScheduleId")
                .LOUTSTANDING_ONLY = False
            End With

            loRtnTemp = loCls.GetIssueList(loTableKey)
            loRtnTemp2 = R_Utility.R_ConvertCollectionToCollection(Of RCustDBIssueListDTO, CST00200GridDTO)(loRtnTemp)

            loRtn = R_StreamUtility(Of CST00200GridDTO).WriteToMessage(loRtnTemp2.AsEnumerable, "getIssueList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetItemInbox() As System.ServiceModel.Channels.Message Implements ICST00200StreamingService.GetItemInbox
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtnTemp As List(Of RCustDBItemInboxDTO)
        Dim loRtn As Message
        Dim loTableKey As New RCustDBInboxKeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .CPROJECT_ID = R_Utility.R_GetStreamingContext("cProjectId")
                .CSESSION_ID = R_Utility.R_GetStreamingContext("cSessionId")
                .CSCHEDULE_ID = R_Utility.R_GetStreamingContext("cScheduleId")
                .CFUNCTION_ID = R_Utility.R_GetStreamingContext("cFunctionId")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CUSER_ID = R_Utility.R_GetStreamingContext("cUserId")
            End With

            loRtnTemp = loCls.GetItemInbox(loTableKey)
            ' ambil yang locked saja
            'loRtnTemp = loRtnTemp.Where(Function(x) x.CITEM_STATUS = "LOCKED").ToList

            loRtn = R_StreamUtility(Of RCustDBItemInboxDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getItemInbox")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of RLicenseBack.RCustDBItemInboxDTO), poPar2 As CST00200Back.CST00200GridDTO, poPar3 As RLicenseBack.RCustDBInboxKeyDTO) Implements ICST00200StreamingService.Dummy

    End Sub
End Class
