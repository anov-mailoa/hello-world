﻿Imports R_Common
Imports CST00200Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "CST00200AttachService" in code, svc and config file together.
Public Class CST00200AttachService
    Implements ICST00200AttachService

    Public Sub Svc_R_Delete(poEntity As CST00200Back.CST00200AttachDTO) Implements R_BackEnd.R_IServicebase(Of CST00200Back.CST00200AttachDTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New CST00200AttachCls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As CST00200Back.CST00200AttachDTO) As CST00200Back.CST00200AttachDTO Implements R_BackEnd.R_IServicebase(Of CST00200Back.CST00200AttachDTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New CST00200AttachCls
        Dim loRtn As CST00200AttachDTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As CST00200Back.CST00200AttachDTO, poCRUDMode As R_Common.eCRUDMode) As CST00200Back.CST00200AttachDTO Implements R_BackEnd.R_IServicebase(Of CST00200Back.CST00200AttachDTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New CST00200AttachCls
        Dim loRtn As CST00200AttachDTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
