﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports CST00200Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICST00200AttachStreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ICST00200AttachStreamingService

    <OperationContract(Action:="getIssueAttachments", ReplyAction:="getIssueAttachments")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetIssueAttachment() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As CST00200AttachGridDTO)

End Interface
