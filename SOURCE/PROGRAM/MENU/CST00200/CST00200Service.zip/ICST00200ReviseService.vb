﻿Imports System.ServiceModel
Imports R_Common
Imports CST00200Back
Imports R_BackEnd

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICST00200ReviseService" in both code and config file together.
<ServiceContract()>
Public Interface ICST00200ReviseService
    Inherits R_IServicebase(Of CST00200DTO)

    <OperationContract(Action:="getIssueTypeCombo", ReplyAction:="getIssueTypeCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetIssueTypeCombo() As List(Of CST00200IssueTypeComboDTO)

    <OperationContract(Action:="getIssueClassCombo", ReplyAction:="getIssueClassCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetIssueClassCombo(key As CST00200KeyDTO) As List(Of CST00200IssueClassComboDTO)

End Interface
