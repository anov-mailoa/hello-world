﻿Imports R_Common
Imports RLicenseBack
Imports CST00200Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "CST00200Service" in code, svc and config file together.
Public Class CST00200Service
    Implements ICST00200Service

    Public Function GetAppCombo(companyId As String, userId As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseAppComboDTO) Implements ICST00200Service.GetAppCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseAppComboDTO)

        Try
            loRtn = loCls.GetAppCombo(companyId, userId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetProjectCombo(poKey As RLicenseBack.RCustDBProjectKeyDTO) As System.Collections.Generic.List(Of RLicenseBack.RCustDBProjectComboDTO) Implements ICST00200Service.GetProjectCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBProjectComboDTO)

        Try
            loRtn = loCls.GetProjectCombo(poKey)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetVersionCombo(companyId As String, appsCode As String) As System.Collections.Generic.List(Of RLicenseBack.RCustDBVersionComboDTO) Implements ICST00200Service.GetVersionCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBVersionComboDTO)

        Try
            loRtn = loCls.GetVersionCombo(companyId, appsCode)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub Svc_R_Delete(poEntity As CST00200Back.CST00200DTO) Implements R_BackEnd.R_IServicebase(Of CST00200Back.CST00200DTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New CST00200Cls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As CST00200Back.CST00200DTO) As CST00200Back.CST00200DTO Implements R_BackEnd.R_IServicebase(Of CST00200Back.CST00200DTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New CST00200Cls
        Dim loRtn As CST00200DTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As CST00200Back.CST00200DTO, poCRUDMode As R_Common.eCRUDMode) As CST00200Back.CST00200DTO Implements R_BackEnd.R_IServicebase(Of CST00200Back.CST00200DTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New CST00200Cls
        Dim loRtn As CST00200DTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetFunctionCombo() As System.Collections.Generic.List(Of RLicenseBack.RCustDBFunctionComboDTO) Implements ICST00200Service.GetFunctionCombo
        Dim loException As New R_Exception
        Dim loCls As New CST00200Cls
        Dim loRtn As List(Of RCustDBFunctionComboDTO)

        Try
            loRtn = loCls.GetFunctionCombo()
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetIssueTypeCombo() As System.Collections.Generic.List(Of CST00200Back.CST00200IssueTypeComboDTO) Implements ICST00200Service.GetIssueTypeCombo
        Dim loException As New R_Exception
        Dim loCls As New CST00200Cls
        Dim loRtn As List(Of CST00200IssueTypeComboDTO)

        Try
            loRtn = loCls.GetIssueTypeCombo()
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetSessionCombo(poKey As RLicenseBack.RCustDBProjectKeyDTO) As System.Collections.Generic.List(Of RLicenseBack.RCustDBSessionComboDTO) Implements ICST00200Service.GetSessionCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBSessionComboDTO)

        Try
            loRtn = loCls.GetSessionCombo(poKey)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetScheduleCombo(poKey As RLicenseBack.RCustDBProjectKeyDTO) As System.Collections.Generic.List(Of RLicenseBack.RCustDBScheduleComboDTO) Implements ICST00200Service.GetScheduleCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBScheduleComboDTO)

        Try
            loRtn = loCls.GetScheduleCombo(poKey)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetIssueClassCombo(key As CST00200Back.CST00200KeyDTO) As System.Collections.Generic.List(Of CST00200Back.CST00200IssueClassComboDTO) Implements ICST00200Service.GetIssueClassCombo
        Dim loException As New R_Exception
        Dim loCls As New CST00200Cls
        Dim loRtn As List(Of CST00200IssueClassComboDTO)

        Try
            loRtn = loCls.GetIssueClassCombo(key)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn

    End Function

    Public Sub ScheduleIssue(poPar As CST00200Back.CST00200KeyDTO) Implements ICST00200Service.ScheduleIssue
        Dim loException As New R_Exception
        Dim loCls As New CST00200Cls

        Try
            loCls.ScheduleIssue(poPar)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

    End Sub
End Class
