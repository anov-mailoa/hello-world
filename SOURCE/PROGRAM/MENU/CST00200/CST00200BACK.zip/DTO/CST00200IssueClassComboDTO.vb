﻿Public Class CST00200IssueClassComboDTO
    Public Property CISSUE_CLASS As String
    Public Property CISSUE_TYPE As String
    Public Property CDESCRIPTION As String
End Class
