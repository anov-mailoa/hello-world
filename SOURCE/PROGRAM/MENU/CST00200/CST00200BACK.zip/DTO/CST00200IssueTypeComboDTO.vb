﻿Public Class CST00200IssueTypeComboDTO
    Public Property CISSUE_TYPE As String
    Public Property CDESCRIPTION As String
End Class
