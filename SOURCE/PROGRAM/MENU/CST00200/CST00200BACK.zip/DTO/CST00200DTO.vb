﻿Imports R_BackEnd

<Serializable()> _
Public Class CST00200DTO
    Inherits R_DTOBase

    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CVERSION As String
    Public Property CPROJECT_ID As String
    Public Property CSESSION_ID As String
    Public Property CATTRIBUTE_GROUP As String
    Public Property CATTRIBUTE_ID As String
    Public Property CITEM_ID As String
    Public Property CISSUE_ID As String
    Public Property CUSER_ID As String
    Public Property CISSUE_DATE As String
    Public Property CISSUE_TYPE As String
    Public Property CISSUE_CLASS As String
    Public Property CDESCRIPTION As String
    Public Property CSCHEDULE_ID As String
    Public Property CPREV_SCHEDULE_ID As String
    Public Property LOK As Boolean
    Public Property LSOLVED As Boolean
    Public Property CORI_ATTRIBUTE_GROUP As String
    Public Property CORI_ATTRIBUTE_ID As String
    Public Property CORI_ITEM_ID As String
    Public Property CORI_ISSUE_ID As String
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)
    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)

    Public Property DISSUE_DATE As Nullable(Of DateTime)

End Class
