﻿Imports R_BackEnd
Imports R_Common
Imports System.Data.Common
Imports RLicenseBack
Imports ServerHelper.General
Imports System.Transactions

Public Class CST00200Cls
    Inherits R_BusinessObject(Of CST00200DTO)

    Public Function GetIssueList(poKey As CST00200KeyDTO) As List(Of CST00200GridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CST00200GridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CST_ISSUES (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery += "AND CPROJECT_ID = '{3}' "
                lcQuery += "AND CSESSION_ID = '{4}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{5}' "
                lcQuery += "AND CATTRIBUTE_ID = '{6}' "
                lcQuery += "AND CITEM_ID = '{7}' "
                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CVERSION, _
                                        .CPROJECT_ID, _
                                        .CSESSION_ID, _
                                        .CATTRIBUTE_GROUP, _
                                        .CATTRIBUTE_ID, _
                                        .CITEM_ID)
            End With
            loResult = loDb.SqlExecObjectQuery(Of CST00200GridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetFunctionCombo() As List(Of RCustDBFunctionComboDTO)
        Dim loResult As New List(Of RCustDBFunctionComboDTO)
        Dim loEx As New R_Exception

        Try
            With loResult
                .Add(New RCustDBFunctionComboDTO With {.CFUNCTION_ID = "DESIGN"})
                .Add(New RCustDBFunctionComboDTO With {.CFUNCTION_ID = "DEVELOPMENT"})
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetIssueClassCombo(poKey As CST00200KeyDTO) As List(Of CST00200IssueClassComboDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CST00200IssueClassComboDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CSM_ISSUE_CLASS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE)
            End With
            loResult = loDb.SqlExecObjectQuery(Of CST00200IssueClassComboDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult

    End Function

    Public Function GetIssueTypeCombo() As List(Of CST00200IssueTypeComboDTO)
        Dim loResult As New List(Of CST00200IssueTypeComboDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            loResult.Add(New CST00200IssueTypeComboDTO With {.CISSUE_TYPE = "DESIGN", .CDESCRIPTION = "Design"})
            loResult.Add(New CST00200IssueTypeComboDTO With {.CISSUE_TYPE = "PROGRAM", .CDESCRIPTION = "Development"})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Sub ScheduleIssue(poPar As CST00200KeyDTO)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db
        Dim lcQuery As String
        Dim loConn As DbConnection
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcRtn As String = "OK"

        Try
            Using TransScope As New TransactionScope(TransactionScopeOption.Required)
                ' update schedule
                loCmd = loDb.GetCommand()
                lcQuery = "EXEC RSP_Issue_Schedule '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', @CRET_MSG OUTPUT "
                With poPar
                    lcQuery = String.Format(lcQuery, _
                                            .CCOMPANY_ID, _
                                            .CAPPS_CODE, _
                                            .CVERSION, _
                                            .CPROJECT_ID, _
                                            .CSESSION_ID,
                                            .CUSER_ID)
                End With
                loCmd.CommandText = lcQuery
                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@CRET_MSG"
                    .DbType = DbType.String
                    .Size = 50
                    .Direction = ParameterDirection.Output
                End With
                loCmd.Parameters.Add(loPar)
                loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)

                If loCmd.Parameters("@CRET_MSG") Is Nothing Then
                    lcRtn = "UNKNOWN_ERROR"
                Else
                    lcRtn = loCmd.Parameters("@CRET_MSG").Value
                End If
                If Not lcRtn.Equals("OK") Then
                    loEx.Add(lcRtn, lcRtn)
                    Exit Try
                End If
                TransScope.Complete()
            End Using

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Sub MarkIssueAsSolved(poPar As CST00200KeyDTO, poSolved As Boolean)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db
        Dim lcQuery As String
        Dim loConn As DbConnection

        Try
            Using TransScope As New TransactionScope(TransactionScopeOption.Required)
                ' update schedule

                With poPar

                    lcQuery = "UPDATE CST_ISSUES "
                    lcQuery += "SET "
                    lcQuery += "LSOLVED = {9}, "
                    lcQuery += "CUPDATE_BY = '{10}', "
                    lcQuery += "DUPDATE_DATE = GETDATE() "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CVERSION = '{2}' "
                    lcQuery += "AND CPROJECT_ID = '{3}' "
                    lcQuery += "AND CSESSION_ID = '{4}' "
                    lcQuery += "AND CATTRIBUTE_GROUP = '{5}' "
                    lcQuery += "AND CATTRIBUTE_ID = '{6}' "
                    lcQuery += "AND CITEM_ID = '{7}' "
                    lcQuery += "AND CISSUE_ID = '{8}' "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CVERSION,
                    .CPROJECT_ID,
                    .CSESSION_ID,
                    .CATTRIBUTE_GROUP,
                    .CATTRIBUTE_ID,
                    .CITEM_ID,
                    .CISSUE_ID,
                    getBit(poSolved),
                    .CUSER_ID)
                End With
                loDb.SqlExecNonQuery(lcQuery, loConn, True)

                TransScope.Complete()
            End Using

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Sub R_Deleting(poEntity As CST00200DTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim lcException As String

        Try
            loConn = loDb.GetConnection()

            With poEntity

                ' delete validation
                lcException = CRUDValidation("DELETE", poEntity, loConn)
                If Not String.IsNullOrEmpty(lcException) Then
                    Throw New Exception(lcException)
                End If

                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "CST_ISSUES "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery += "AND CPROJECT_ID = '{3}' "
                lcQuery += "AND CSESSION_ID = '{4}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{5}' "
                lcQuery += "AND CATTRIBUTE_ID = '{6}' "
                lcQuery += "AND CITEM_ID = '{7}' "
                lcQuery += "AND CISSUE_ID = '{8}' "
                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CVERSION, _
                                        .CPROJECT_ID, _
                                        .CSESSION_ID, _
                                        .CATTRIBUTE_GROUP, _
                                        .CATTRIBUTE_ID, _
                                        .CITEM_ID, _
                                        .CISSUE_ID)
                loDb.SqlExecNonQuery(lcQuery, loConn, False)

                ' delete attachment table
                lcQuery = "DELETE FROM "
                lcQuery += "CST_ISSUES_ATTACH "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery += "AND CPROJECT_ID = '{3}' "
                lcQuery += "AND CSESSION_ID = '{4}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{5}' "
                lcQuery += "AND CATTRIBUTE_ID = '{6}' "
                lcQuery += "AND CITEM_ID = '{7}' "
                lcQuery += "AND CISSUE_ID = '{8}' "
                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CVERSION, _
                                        .CPROJECT_ID, _
                                        .CSESSION_ID, _
                                        .CATTRIBUTE_GROUP, _
                                        .CATTRIBUTE_ID, _
                                        .CITEM_ID, _
                                        .CISSUE_ID)
                loDb.SqlExecNonQuery(lcQuery, loConn, True)

            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As CST00200DTO) As CST00200DTO
        Dim lcQuery As String
        Dim loResult As CST00200DTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CST_ISSUES (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery += "AND CPROJECT_ID = '{3}' "
                lcQuery += "AND CSESSION_ID = '{4}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{5}' "
                lcQuery += "AND CATTRIBUTE_ID = '{6}' "
                lcQuery += "AND CITEM_ID = '{7}' "
                lcQuery += "AND CISSUE_ID = '{8}' "
                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CVERSION, _
                                        .CPROJECT_ID, _
                                        .CSESSION_ID, _
                                        .CATTRIBUTE_GROUP, _
                                        .CATTRIBUTE_ID, _
                                        .CITEM_ID, _
                                        .CISSUE_ID)
                loResult = loDb.SqlExecObjectQuery(Of CST00200DTO)(lcQuery).FirstOrDefault
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As CST00200DTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim lcException As String

        Try
            loConn = loDb.GetConnection()

            With poNewEntity
                If poCRUDMode = eCRUDMode.AddMode Then

                    ' update validation
                    lcException = CRUDValidation("CREATE", poNewEntity, loConn)
                    If Not String.IsNullOrEmpty(lcException) Then
                        Throw New Exception(lcException)
                    End If

                    lcQuery = "INSERT INTO CST_ISSUES ("
                    lcQuery += "CCOMPANY_ID, "
                    lcQuery += "CAPPS_CODE, "
                    lcQuery += "CVERSION, "
                    lcQuery += "CPROJECT_ID, "
                    lcQuery += "CSESSION_ID, "
                    lcQuery += "CATTRIBUTE_GROUP, "
                    lcQuery += "CATTRIBUTE_ID, "
                    lcQuery += "CITEM_ID, "
                    lcQuery += "CISSUE_ID, "
                    lcQuery += "CUSER_ID, "
                    lcQuery += "CISSUE_DATE, "
                    lcQuery += "CISSUE_TYPE, "
                    lcQuery += "CISSUE_CLASS, "
                    lcQuery += "CDESCRIPTION, "
                    lcQuery += "CSCHEDULE_ID, "
                    lcQuery += "CPREV_SCHEDULE_ID, "
                    lcQuery += "LOK, "
                    lcQuery += "CUPDATE_BY, "
                    lcQuery += "DUPDATE_DATE, "
                    lcQuery += "CCREATE_BY, "
                    lcQuery += "DCREATE_DATE) "
                    lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', CONVERT(char(8), GETDATE(), 112), '{10}', '{11}', '{12}', '{13}', '{14}', {15}, '{16}' , GETDATE(), '{17}', GETDATE()) "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CVERSION,
                    .CPROJECT_ID,
                    .CSESSION_ID,
                    .CATTRIBUTE_GROUP,
                    .CATTRIBUTE_ID,
                    .CITEM_ID,
                    .CISSUE_ID,
                    .CUSER_ID,
                    .CISSUE_TYPE,
                    .CISSUE_CLASS,
                    .CDESCRIPTION,
                    .CSCHEDULE_ID,
                    .CPREV_SCHEDULE_ID,
                    getBit(.LOK),
                    .CUPDATE_BY,
                    .CCREATE_BY)

                ElseIf poCRUDMode = eCRUDMode.EditMode Then

                    ' update validation
                    lcException = CRUDValidation("UPDATE", poNewEntity, loConn)
                    If Not String.IsNullOrEmpty(lcException) Then
                        Throw New Exception(lcException)
                    End If

                    lcQuery = "UPDATE CST_ISSUES "
                    lcQuery += "SET "
                    lcQuery += "CISSUE_TYPE = '{9}', "
                    lcQuery += "CDESCRIPTION = '{10}', "
                    lcQuery += "CISSUE_CLASS = '{11}', "
                    lcQuery += "LOK = {12}, "
                    lcQuery += "CUPDATE_BY = '{13}', "
                    lcQuery += "DUPDATE_DATE = GETDATE() "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CVERSION = '{2}' "
                    lcQuery += "AND CPROJECT_ID = '{3}' "
                    lcQuery += "AND CSESSION_ID = '{4}' "
                    lcQuery += "AND CATTRIBUTE_GROUP = '{5}' "
                    lcQuery += "AND CATTRIBUTE_ID = '{6}' "
                    lcQuery += "AND CITEM_ID = '{7}' "
                    lcQuery += "AND CISSUE_ID = '{8}' "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CVERSION,
                    .CPROJECT_ID,
                    .CSESSION_ID,
                    .CATTRIBUTE_GROUP,
                    .CATTRIBUTE_ID,
                    .CITEM_ID,
                    .CISSUE_ID,
                    .CISSUE_TYPE,
                    .CDESCRIPTION,
                    .CISSUE_CLASS,
                    getBit(.LOK),
                    .CUPDATE_BY)

                End If
            End With
            loDb.SqlExecNonQuery(lcQuery, loConn, True)
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Friend Function CRUDValidation(pcCRUDAction As String, poEntity As CST00200DTO, ByRef poConn As DbConnection) As String
        Dim lcException As String = "Unknown error."
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim loResult As CST00200DTO
        Dim loEx As New R_Exception

        Try
            '    loConn = poDb.GetConnection()
            lcException = ""

            If String.Equals(pcCRUDAction, "CREATE") Then
                With poEntity
                    lcQuery = "SELECT * "
                    lcQuery += "FROM "
                    lcQuery += "CST_ISSUES (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CVERSION = '{2}' "
                    lcQuery += "AND CPROJECT_ID = '{3}' "
                    lcQuery += "AND CSESSION_ID = '{4}' "
                    lcQuery += "AND CATTRIBUTE_GROUP = '{5}' "
                    lcQuery += "AND CATTRIBUTE_ID = '{6}' "
                    lcQuery += "AND CITEM_ID = '{7}' "
                    lcQuery += "AND CISSUE_ID = '{8}' "
                    lcQuery = String.Format(lcQuery,
                                            .CCOMPANY_ID,
                                            .CAPPS_CODE,
                                            .CVERSION,
                                            .CPROJECT_ID,
                                            .CSESSION_ID,
                                            .CATTRIBUTE_GROUP,
                                            .CATTRIBUTE_ID,
                                            .CITEM_ID,
                                            .CISSUE_ID)
                End With
                loResult = loDb.SqlExecObjectQuery(Of CST00200DTO)(lcQuery, poConn, False).FirstOrDefault
                If loResult IsNot Nothing Then
                    lcException = "DUPLICATE_ENTRY"
                End If
            End If

            If Not String.IsNullOrWhiteSpace(poEntity.CSCHEDULE_ID) Then
                If String.Equals(pcCRUDAction, "DELETE") Then
                    ' jika sudah scheduled, tidak boleh delete lagi
                    lcException = "SCHEDULED"
                End If

                If String.Equals(pcCRUDAction, "UPDATE") Then

                    ' cek current status, jika sudah QCCI, tidak boleh update lagi
                    Dim lcStatus As String

                    lcStatus = ""
                    lcQuery = "SELECT CSTATUS "
                    lcQuery += "FROM "
                    lcQuery += "CST_PROJECT_PROGRAMS (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CVERSION = '{2}' "
                    lcQuery += "AND CPROJECT_ID = '{3}' "
                    lcQuery += "AND CSESSION_ID = '{4}' "
                    lcQuery += "AND CSCHEDULE_ID = '{5}' "
                    lcQuery += "AND CATTRIBUTE_GROUP = '{6}' "
                    lcQuery += "AND CATTRIBUTE_ID = '{7}' "
                    lcQuery += "AND CITEM_ID = '{8}' "
                    With poEntity
                        lcQuery = String.Format(lcQuery,
                        .CCOMPANY_ID,
                        .CAPPS_CODE,
                        .CVERSION,
                        .CPROJECT_ID,
                        .CSESSION_ID,
                        .CSCHEDULE_ID,
                        .CATTRIBUTE_GROUP,
                        .CATTRIBUTE_ID,
                        .CITEM_ID)
                    End With
                    lcStatus = loDb.SqlExecObjectQuery(Of String)(lcQuery, poConn, False).FirstOrDefault
                    If Not (lcStatus.Trim.Equals("PLAN") Or lcStatus.Trim.Equals("QCCO")) Then
                        lcException = "STATUS_NO_EDIT"
                    End If
                End If
            Else
                If String.Equals(pcCRUDAction, "DELETE") Then
                    ' cek current schedule ID, pastikan 
                    Dim lcStatus As String

                    lcStatus = ""
                    lcQuery = "SELECT CSCHEDULE_ID "
                    lcQuery += "FROM "
                    lcQuery += "CST_ISSUES (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CVERSION = '{2}' "
                    lcQuery += "AND CPROJECT_ID = '{3}' "
                    lcQuery += "AND CSESSION_ID = '{4}' "
                    lcQuery += "AND CATTRIBUTE_GROUP = '{5}' "
                    lcQuery += "AND CATTRIBUTE_ID = '{6}' "
                    lcQuery += "AND CITEM_ID = '{7}' "
                    lcQuery += "AND CISSUE_ID = '{8}' "
                    With poEntity
                        lcQuery = String.Format(lcQuery,
                        .CCOMPANY_ID,
                        .CAPPS_CODE,
                        .CVERSION,
                        .CPROJECT_ID,
                        .CSESSION_ID,
                        .CATTRIBUTE_GROUP,
                        .CATTRIBUTE_ID,
                        .CITEM_ID,
                        .CISSUE_ID)
                    End With
                    lcStatus = loDb.SqlExecObjectQuery(Of String)(lcQuery, poConn, False).FirstOrDefault
                    If Not String.IsNullOrWhiteSpace(lcStatus) Then
                        lcException = "SCHEDULED"
                    End If
                End If
            End If

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        If loEx.Haserror Then
            For Each loException In loEx.GetErrorList
                lcException = "Error on saving process: " + loException.ErrDescp.Trim() + "(" + loException.ErrNo.Trim + ")" + vbCrLf
                If loException.HasErrorDetail Then
                    For Each loExDt In loException.ErrorDetails
                        lcException += "Detail: " + loExDt.ErrDescp.Trim() + "(" + loExDt.ErrNo.Trim + ")" + vbCrLf
                    Next
                End If
            Next
        End If

        Return lcException
    End Function

End Class
