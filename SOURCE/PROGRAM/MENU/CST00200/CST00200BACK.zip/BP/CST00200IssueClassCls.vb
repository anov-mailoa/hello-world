﻿Imports R_BackEnd
Imports R_Common
Imports System.Data.Common

Public Class CST00200IssueClassCls
    Inherits R_BusinessObject(Of CST00200IssueClassDTO)

    Public Function GetIssueClassList(poKey As CST00200KeyDTO) As List(Of CST00200IssueClassGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CST00200IssueClassGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CSM_ISSUE_CLASS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE)
            End With
            loResult = loDb.SqlExecObjectQuery(Of CST00200IssueClassGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Deleting(poEntity As CST00200IssueClassDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loResult As List(Of CST00200IssueClassDTO)

        Try
            loConn = loDb.GetConnection()

            With poEntity

                ' validation
                lcQuery = "SELECT TOP 1 * "
                lcQuery += "FROM "
                lcQuery += "CST_ISSUES (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CISSUE_CLASS = '{2}' "
                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CISSUE_CLASS)
                loResult = loDb.SqlExecObjectQuery(Of CST00200IssueClassDTO)(lcQuery)
                If loResult.Count > 0 Then
                    loEx.Add("CST00200Back001", "")
                    Exit Try
                End If

                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "CSM_ISSUE_CLASS "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CISSUE_CLASS = '{2}' "
                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CISSUE_CLASS)
                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As CST00200IssueClassDTO) As CST00200IssueClassDTO
        Dim lcQuery As String
        Dim loResult As CST00200IssueClassDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CSM_ISSUE_CLASS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CISSUE_CLASS = '{2}' "
                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CISSUE_CLASS)
                loResult = loDb.SqlExecObjectQuery(Of CST00200IssueClassDTO)(lcQuery).FirstOrDefault
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As CST00200IssueClassDTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String

        Try
            loConn = loDb.GetConnection()

            With poNewEntity
                If poCRUDMode = eCRUDMode.AddMode Then

                    lcQuery = "INSERT INTO CSM_ISSUE_CLASS ("
                    lcQuery += "CCOMPANY_ID, "
                    lcQuery += "CAPPS_CODE, "
                    lcQuery += "CISSUE_CLASS, "
                    lcQuery += "CISSUE_TYPE, "
                    lcQuery += "CDESCRIPTION, "
                    lcQuery += "CUPDATE_BY, "
                    lcQuery += "DUPDATE_DATE, "
                    lcQuery += "CCREATE_BY, "
                    lcQuery += "DCREATE_DATE) "
                    lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', GETDATE(), '{6}', GETDATE()) "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CISSUE_CLASS,
                    .CISSUE_TYPE,
                    .CDESCRIPTION,
                    .CUPDATE_BY,
                    .CCREATE_BY)

                ElseIf poCRUDMode = eCRUDMode.EditMode Then

                    lcQuery = "UPDATE CSM_ISSUE_CLASS "
                    lcQuery += "SET "
                    lcQuery += "CDESCRIPTION = '{3}', "
                    lcQuery += "CUPDATE_BY = '{4}', "
                    lcQuery += "DUPDATE_DATE = GETDATE() "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CISSUE_CLASS = '{2}' "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CISSUE_CLASS,
                    .CDESCRIPTION,
                    .CUPDATE_BY)

                End If
            End With
            loDb.SqlExecNonQuery(lcQuery, loConn, True)
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

End Class
