﻿Imports R_BackEnd
Imports R_Common
Imports System.Data.Common

Public Class CST00200AttachCls
    Inherits R_BusinessObject(Of CST00200AttachDTO)

    Public Function GetIssueAttachments(poKey As CST00200KeyDTO) As List(Of CST00200AttachGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CST00200AttachGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CST_ISSUES_ATTACH (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery += "AND CPROJECT_ID = '{3}' "
                lcQuery += "AND CSESSION_ID = '{4}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{5}' "
                lcQuery += "AND CATTRIBUTE_ID = '{6}' "
                lcQuery += "AND CITEM_ID = '{7}' "
                lcQuery += "AND CISSUE_ID = '{8}' "
                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CVERSION, _
                                        .CPROJECT_ID, _
                                        .CSESSION_ID, _
                                        .CATTRIBUTE_GROUP, _
                                        .CATTRIBUTE_ID, _
                                        .CITEM_ID, _
                                        .CISSUE_ID)
            End With
            loResult = loDb.SqlExecObjectQuery(Of CST00200AttachGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Deleting(poEntity As CST00200AttachDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection

        Try
            loConn = loDb.GetConnection()

            With poEntity

                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "CST_ISSUES_ATTACH "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery += "AND CPROJECT_ID = '{3}' "
                lcQuery += "AND CSESSION_ID = '{4}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{5}' "
                lcQuery += "AND CATTRIBUTE_ID = '{6}' "
                lcQuery += "AND CITEM_ID = '{7}' "
                lcQuery += "AND CISSUE_ID = '{8}' "
                lcQuery += "AND CFILE_NAME = '{9}' "
                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CVERSION, _
                                        .CPROJECT_ID, _
                                        .CSESSION_ID, _
                                        .CATTRIBUTE_GROUP, _
                                        .CATTRIBUTE_ID, _
                                        .CITEM_ID, _
                                        .CISSUE_ID, _
                                        .CFILE_NAME)
                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As CST00200AttachDTO) As CST00200AttachDTO
        Dim lcQuery As String
        Dim loResult As CST00200AttachDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CST_ISSUES_ATTACH (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery += "AND CPROJECT_ID = '{3}' "
                lcQuery += "AND CSESSION_ID = '{4}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{5}' "
                lcQuery += "AND CATTRIBUTE_ID = '{6}' "
                lcQuery += "AND CITEM_ID = '{7}' "
                lcQuery += "AND CISSUE_ID = '{8}' "
                lcQuery += "AND CFILE_NAME = '{9}' "
                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CVERSION, _
                                        .CPROJECT_ID, _
                                        .CSESSION_ID, _
                                        .CATTRIBUTE_GROUP, _
                                        .CATTRIBUTE_ID, _
                                        .CITEM_ID, _
                                        .CISSUE_ID, _
                                        .CFILE_NAME)
                loResult = loDb.SqlExecObjectQuery(Of CST00200AttachDTO)(lcQuery).FirstOrDefault
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As CST00200AttachDTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String

        Try
            loConn = loDb.GetConnection()

            If poCRUDMode = eCRUDMode.EditMode Then
                With poNewEntity

                    lcQuery = "UPDATE CST_ISSUES_ATTACH "
                    lcQuery += "SET "
                    lcQuery += "CDESCRIPTION = '{10}', "
                    lcQuery += "CUPDATE_BY = '{11}', "
                    lcQuery += "DUPDATE_DATE = GETDATE() "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CVERSION = '{2}' "
                    lcQuery += "AND CPROJECT_ID = '{3}' "
                    lcQuery += "AND CSESSION_ID = '{4}' "
                    lcQuery += "AND CATTRIBUTE_GROUP = '{5}' "
                    lcQuery += "AND CATTRIBUTE_ID = '{6}' "
                    lcQuery += "AND CITEM_ID = '{7}' "
                    lcQuery += "AND CISSUE_ID = '{8}' "
                    lcQuery += "AND CFILE_NAME = '{9}' "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CVERSION,
                    .CPROJECT_ID,
                    .CSESSION_ID,
                    .CATTRIBUTE_GROUP,
                    .CATTRIBUTE_ID,
                    .CITEM_ID,
                    .CISSUE_ID,
                    .CFILE_NAME,
                    .CDESCRIPTION,
                    .CUPDATE_BY)

                End With
                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End If
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

End Class
