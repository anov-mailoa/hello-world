﻿Imports CST00100FrontResources
Imports R_Common
Imports CST00100Front.CST00100StreamingServiceRef
Imports R_FrontEnd
Imports System.ServiceModel.Channels

Public Class CST00100Restore

#Region " VARIABLE "
    Dim C_ServiceNameStream As String = "CST00100Service/CST00100StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim loBackupRestoreParam As New CST00100BackupRestoreDTO
#End Region

#Region " FORM Methods "

    Private Sub CST00100Manager_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Try
            loBackupRestoreParam = poParameter
            gvItems.R_RefreshGrid(poParameter)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

    Private Sub R_ReturnPopUp1_R_SetPopUpResult(ByRef poEntityResult As Object) Handles R_ReturnPopUp1.R_SetPopUpResult
        Dim loException As New R_Exception

        Try
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor

            Dim loCheckedItems = From item In CType(bsItems.List, List(Of RCustDBItemRestoreDTO)) Where item.LSELECT = True

            If loCheckedItems.Count > 0 Then
                loBackupRestoreParam.ORESTORE_LIST.Clear()
                For Each loRow As RCustDBItemRestoreDTO In loCheckedItems
                    loBackupRestoreParam.ORESTORE_LIST.Add(loRow)
                Next
            End If
            poEntityResult = loBackupRestoreParam
        Catch ex As Exception
            loException.Add(ex)
        Finally
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        End Try
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        If loException.Haserror Then
            Me.R_DisplayException(loException)
        End If
    End Sub

    Private Sub R_ReturnPopUp1_R_ValidationPopUpResult(ByRef plCancel As Boolean, poButton As System.Windows.Forms.DialogResult) Handles R_ReturnPopUp1.R_ValidationPopUpResult
        Dim loException As New R_Exception

        Try
            If poButton = Windows.Forms.DialogResult.OK Then
                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor

                Dim loCheckedItems = From item In CType(bsItems.List, List(Of RCustDBItemRestoreDTO)) Where item.LSELECT = True

                If loCheckedItems.Count <= 0 Then
                    loException.Add("CST00100_01", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CST00100_01").Trim) ' no item selected
                    plCancel = True
                    Exit Try
                End If
            End If
        Catch ex As Exception
            loException.Add(ex)
        Finally
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        End Try
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        If loException.Haserror Then
            Me.R_DisplayException(loException)
        End If
    End Sub

#End Region

#Region " GRIDVIEW "

    Private Sub gvItems_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvItems.DataBindingComplete
        gvItems.BestFitColumns()
    End Sub

    Private Sub gvItems_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvItems.R_ServiceGetListRecord
        Dim loServiceStream As CST00100StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00100StreamingService, CST00100StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of RCustDBItemRestoreDTO)
        Dim loListEntity As New List(Of RCustDBItemRestoreDTO)

        Try
            With CType(poEntity, CST00100BackupRestoreDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
                R_Utility.R_SetStreamingContext("cAttributeGroup", .CATTRIBUTE_GROUP)
                R_Utility.R_SetStreamingContext("cProjectId", .CPROJECT_ID)
                R_Utility.R_SetStreamingContext("cSessionId", .CSESSION_ID)
                R_Utility.R_SetStreamingContext("cScheduleId", .CSCHEDULE_ID)
                R_Utility.R_SetStreamingContext("cFunctionId", .CFUNCTION_ID)

                loRtn = loServiceStream.GetItemRestore()
                loStreaming = R_StreamUtility(Of RCustDBItemRestoreDTO).ReadFromMessage(loRtn)

                For Each loDto As RCustDBItemRestoreDTO In loStreaming
                    If loDto IsNot Nothing Then
                        loListEntity.Add(loDto)
                    Else
                        Exit For
                    End If
                Next
                poListEntityResult = loListEntity

            End With
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loServiceStream.Close()
        loException.ThrowExceptionIfErrors()
    End Sub

#End Region


End Class
