﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CST00100Filter
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.R_ReturnPopUp1 = New R_FrontEnd.R_ReturnPopUp()
        Me.lblSession = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblProject = New R_FrontEnd.R_RadLabel(Me.components)
        Me.cboSession = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsSession = New System.Windows.Forms.BindingSource(Me.components)
        Me.cboProject = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsProject = New System.Windows.Forms.BindingSource(Me.components)
        Me.cboVersion = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsVersion = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblVersion = New R_FrontEnd.R_RadLabel(Me.components)
        Me.cboApplication = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblSchedule = New R_FrontEnd.R_RadLabel(Me.components)
        Me.cboSchedule = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsSchedule = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsFunction = New System.Windows.Forms.BindingSource(Me.components)
        Me.cboFunction = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.lblFunction = New R_FrontEnd.R_RadLabel(Me.components)
        Me.cboAttributeGroup = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsAttributeGroup = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblAttributeGroup = New R_FrontEnd.R_RadLabel(Me.components)
        Me.btnRefresh = New R_FrontEnd.R_RadButton(Me.components)
        Me.rdbCustom = New R_FrontEnd.R_RadRadioButton(Me.components)
        Me.rdbStandard = New R_FrontEnd.R_RadRadioButton(Me.components)
        Me.lblCustomer = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lupCustomer = New R_FrontEnd.R_LookUp(Me.components)
        Me.txtCustomerName = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtCustomerCode = New R_FrontEnd.R_RadTextBox(Me.components)
        CType(Me.R_ReturnPopUp1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsFunction, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboFunction, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblFunction, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboAttributeGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsAttributeGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblAttributeGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnRefresh, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.rdbCustom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.rdbStandard, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lupCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCustomerName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCustomerCode, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'R_ReturnPopUp1
        '
        Me.R_ReturnPopUp1.Location = New System.Drawing.Point(356, 232)
        Me.R_ReturnPopUp1.Name = "R_ReturnPopUp1"
        Me.R_ReturnPopUp1.Size = New System.Drawing.Size(162, 31)
        Me.R_ReturnPopUp1.TabIndex = 0
        '
        'lblSession
        '
        Me.lblSession.AutoSize = False
        Me.lblSession.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblSession.Location = New System.Drawing.Point(12, 114)
        Me.lblSession.Name = "lblSession"
        Me.lblSession.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblSession.R_ResourceId = "lblSession"
        Me.lblSession.Size = New System.Drawing.Size(100, 18)
        Me.lblSession.TabIndex = 40
        Me.lblSession.Text = "Application..."
        '
        'lblProject
        '
        Me.lblProject.AutoSize = False
        Me.lblProject.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblProject.Location = New System.Drawing.Point(12, 88)
        Me.lblProject.Name = "lblProject"
        Me.lblProject.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblProject.R_ResourceId = "lblProject"
        Me.lblProject.Size = New System.Drawing.Size(100, 18)
        Me.lblProject.TabIndex = 37
        Me.lblProject.Text = "Application..."
        '
        'cboSession
        '
        Me.cboSession.DataSource = Me.bsSession
        Me.cboSession.DisplayMember = "CSESSION_AND_STATUS"
        Me.cboSession.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboSession.Location = New System.Drawing.Point(118, 114)
        Me.cboSession.Name = "cboSession"
        Me.cboSession.R_ConductorGridSource = Nothing
        Me.cboSession.R_ConductorSource = Nothing
        Me.cboSession.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboSession.Size = New System.Drawing.Size(400, 20)
        Me.cboSession.TabIndex = 39
        Me.cboSession.Text = "R_RadDropDownList1"
        Me.cboSession.ValueMember = "CSESSION_ID"
        '
        'bsSession
        '
        Me.bsSession.DataSource = GetType(CST00100Front.CST00100ServiceRef.RCustDBSessionComboDTO)
        '
        'cboProject
        '
        Me.cboProject.DataSource = Me.bsProject
        Me.cboProject.DisplayMember = "CPROJECT_NAME"
        Me.cboProject.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboProject.Location = New System.Drawing.Point(118, 88)
        Me.cboProject.Name = "cboProject"
        Me.cboProject.R_ConductorGridSource = Nothing
        Me.cboProject.R_ConductorSource = Nothing
        Me.cboProject.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboProject.Size = New System.Drawing.Size(400, 20)
        Me.cboProject.TabIndex = 38
        Me.cboProject.Text = "R_RadDropDownList1"
        Me.cboProject.ValueMember = "CPROJECT_ID"
        '
        'bsProject
        '
        Me.bsProject.DataSource = GetType(CST00100Front.CST00100ServiceRef.RCustDBProjectComboDTO)
        '
        'cboVersion
        '
        Me.cboVersion.DataSource = Me.bsVersion
        Me.cboVersion.DisplayMember = "CCODE_NAME"
        Me.cboVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboVersion.Location = New System.Drawing.Point(118, 62)
        Me.cboVersion.Name = "cboVersion"
        Me.cboVersion.R_ConductorGridSource = Nothing
        Me.cboVersion.R_ConductorSource = Nothing
        Me.cboVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboVersion.Size = New System.Drawing.Size(202, 20)
        Me.cboVersion.TabIndex = 36
        Me.cboVersion.Text = "R_RadDropDownList1"
        Me.cboVersion.ValueMember = "CVERSION"
        '
        'bsVersion
        '
        Me.bsVersion.DataSource = GetType(CST00100Front.CST00100ServiceRef.RCustDBVersionComboDTO)
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(12, 12)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 33
        Me.lblApplication.Text = "Application..."
        '
        'lblVersion
        '
        Me.lblVersion.AutoSize = False
        Me.lblVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblVersion.Location = New System.Drawing.Point(12, 62)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblVersion.R_ResourceId = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(100, 18)
        Me.lblVersion.TabIndex = 35
        Me.lblVersion.Text = "Application..."
        '
        'cboApplication
        '
        Me.cboApplication.DataSource = Me.bsApps
        Me.cboApplication.DisplayMember = "CAPPS_NAME"
        Me.cboApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboApplication.Location = New System.Drawing.Point(118, 12)
        Me.cboApplication.Name = "cboApplication"
        Me.cboApplication.R_ConductorGridSource = Nothing
        Me.cboApplication.R_ConductorSource = Nothing
        Me.cboApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboApplication.Size = New System.Drawing.Size(400, 20)
        Me.cboApplication.TabIndex = 34
        Me.cboApplication.Text = "R_RadDropDownList1"
        Me.cboApplication.ValueMember = "CAPPS_CODE"
        '
        'bsApps
        '
        Me.bsApps.DataSource = GetType(CST00100Front.CST00100ServiceRef.RLicenseAppComboDTO)
        '
        'lblSchedule
        '
        Me.lblSchedule.AutoSize = False
        Me.lblSchedule.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblSchedule.Location = New System.Drawing.Point(12, 140)
        Me.lblSchedule.Name = "lblSchedule"
        Me.lblSchedule.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblSchedule.R_ResourceId = "lblSchedule"
        Me.lblSchedule.Size = New System.Drawing.Size(100, 18)
        Me.lblSchedule.TabIndex = 42
        Me.lblSchedule.Text = "Application..."
        '
        'cboSchedule
        '
        Me.cboSchedule.DataSource = Me.bsSchedule
        Me.cboSchedule.DisplayMember = "CSCHEDULE_DESCRIPTION"
        Me.cboSchedule.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboSchedule.Location = New System.Drawing.Point(118, 140)
        Me.cboSchedule.Name = "cboSchedule"
        Me.cboSchedule.R_ConductorGridSource = Nothing
        Me.cboSchedule.R_ConductorSource = Nothing
        Me.cboSchedule.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboSchedule.Size = New System.Drawing.Size(400, 20)
        Me.cboSchedule.TabIndex = 41
        Me.cboSchedule.Text = "R_RadDropDownList1"
        Me.cboSchedule.ValueMember = "CSCHEDULE_ID"
        '
        'bsSchedule
        '
        Me.bsSchedule.DataSource = GetType(CST00100Front.CST00100ServiceRef.RCustDBScheduleComboDTO)
        '
        'cboFunction
        '
        Me.cboFunction.DataSource = Me.bsFunction
        Me.cboFunction.DisplayMember = "CFUNCTION_ID"
        Me.cboFunction.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboFunction.Location = New System.Drawing.Point(118, 166)
        Me.cboFunction.Name = "cboFunction"
        Me.cboFunction.R_ConductorGridSource = Nothing
        Me.cboFunction.R_ConductorSource = Nothing
        Me.cboFunction.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboFunction.Size = New System.Drawing.Size(202, 20)
        Me.cboFunction.TabIndex = 44
        Me.cboFunction.Text = "R_RadDropDownList1"
        Me.cboFunction.ValueMember = "CFUNCTION_ID"
        '
        'lblFunction
        '
        Me.lblFunction.AutoSize = False
        Me.lblFunction.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblFunction.Location = New System.Drawing.Point(12, 166)
        Me.lblFunction.Name = "lblFunction"
        Me.lblFunction.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblFunction.R_ResourceId = "lblFunction"
        Me.lblFunction.Size = New System.Drawing.Size(100, 18)
        Me.lblFunction.TabIndex = 43
        Me.lblFunction.Text = "Application..."
        '
        'cboAttributeGroup
        '
        Me.cboAttributeGroup.DataSource = Me.bsAttributeGroup
        Me.cboAttributeGroup.DisplayMember = "CATTRIBUTE_GROUP"
        Me.cboAttributeGroup.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboAttributeGroup.Location = New System.Drawing.Point(118, 192)
        Me.cboAttributeGroup.Name = "cboAttributeGroup"
        Me.cboAttributeGroup.R_ConductorGridSource = Nothing
        Me.cboAttributeGroup.R_ConductorSource = Nothing
        Me.cboAttributeGroup.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboAttributeGroup.Size = New System.Drawing.Size(202, 20)
        Me.cboAttributeGroup.TabIndex = 46
        Me.cboAttributeGroup.Text = "R_RadDropDownList1"
        Me.cboAttributeGroup.ValueMember = "CATTRIBUTE_GROUP"
        '
        'bsAttributeGroup
        '
        Me.bsAttributeGroup.DataSource = GetType(CST00100Front.CST00100ServiceRef.RCustDBAttributeGroupComboDTO)
        '
        'lblAttributeGroup
        '
        Me.lblAttributeGroup.AutoSize = False
        Me.lblAttributeGroup.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblAttributeGroup.Location = New System.Drawing.Point(12, 192)
        Me.lblAttributeGroup.Name = "lblAttributeGroup"
        Me.lblAttributeGroup.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblAttributeGroup.R_ResourceId = "lblAttributeGroup"
        Me.lblAttributeGroup.Size = New System.Drawing.Size(100, 18)
        Me.lblAttributeGroup.TabIndex = 45
        Me.lblAttributeGroup.Text = "R_RadLabel1"
        '
        'btnRefresh
        '
        Me.btnRefresh.Location = New System.Drawing.Point(118, 232)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.R_ConductorGridSource = Nothing
        Me.btnRefresh.R_ConductorSource = Nothing
        Me.btnRefresh.R_DescriptionId = Nothing
        Me.btnRefresh.R_ResourceId = "btnRefreshCombo"
        Me.btnRefresh.Size = New System.Drawing.Size(110, 24)
        Me.btnRefresh.TabIndex = 61
        Me.btnRefresh.Text = "R_RadButton1"
        '
        'rdbCustom
        '
        Me.rdbCustom.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.rdbCustom.Location = New System.Drawing.Point(249, 38)
        Me.rdbCustom.Name = "rdbCustom"
        Me.rdbCustom.R_ConductorGridSource = Nothing
        Me.rdbCustom.R_ConductorSource = Nothing
        Me.rdbCustom.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.rdbCustom.R_ResourceId = "rdbCustom"
        Me.rdbCustom.Size = New System.Drawing.Size(122, 18)
        Me.rdbCustom.TabIndex = 63
        Me.rdbCustom.TabStop = False
        Me.rdbCustom.Text = "R_RadRadioButton2"
        '
        'rdbStandard
        '
        Me.rdbStandard.CheckState = System.Windows.Forms.CheckState.Checked
        Me.rdbStandard.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.rdbStandard.Location = New System.Drawing.Point(118, 38)
        Me.rdbStandard.Name = "rdbStandard"
        Me.rdbStandard.R_ConductorGridSource = Nothing
        Me.rdbStandard.R_ConductorSource = Nothing
        Me.rdbStandard.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.rdbStandard.R_ResourceId = "rdbStandard"
        Me.rdbStandard.Size = New System.Drawing.Size(122, 18)
        Me.rdbStandard.TabIndex = 62
        Me.rdbStandard.Text = "R_RadRadioButton1"
        Me.rdbStandard.ToggleState = Telerik.WinControls.Enumerations.ToggleState.[On]
        '
        'lblCustomer
        '
        Me.lblCustomer.AutoSize = False
        Me.lblCustomer.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustomer.Location = New System.Drawing.Point(12, 62)
        Me.lblCustomer.Name = "lblCustomer"
        Me.lblCustomer.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustomer.R_ResourceId = "lblCustomer"
        Me.lblCustomer.Size = New System.Drawing.Size(100, 18)
        Me.lblCustomer.TabIndex = 64
        Me.lblCustomer.Text = "Application..."
        '
        'lupCustomer
        '
        Me.lupCustomer.Location = New System.Drawing.Point(224, 62)
        Me.lupCustomer.Name = "lupCustomer"
        Me.lupCustomer.R_ConductorGridSource = Nothing
        Me.lupCustomer.R_ConductorSource = Nothing
        Me.lupCustomer.R_DescriptionId = Nothing
        Me.lupCustomer.R_Field_Description = ""
        Me.lupCustomer.R_Field_Value = ""
        Me.lupCustomer.R_ResourceId = Nothing
        Me.lupCustomer.R_TextBox_Description = Me.txtCustomerName
        Me.lupCustomer.R_TextBox_Value = Me.txtCustomerCode
        Me.lupCustomer.R_Title = Nothing
        Me.lupCustomer.Size = New System.Drawing.Size(30, 20)
        Me.lupCustomer.TabIndex = 67
        Me.lupCustomer.Text = "..."
        '
        'txtCustomerName
        '
        Me.txtCustomerName.Enabled = False
        Me.txtCustomerName.Location = New System.Drawing.Point(260, 62)
        Me.txtCustomerName.Name = "txtCustomerName"
        Me.txtCustomerName.R_ConductorGridSource = Nothing
        Me.txtCustomerName.R_ConductorSource = Nothing
        Me.txtCustomerName.R_UDT = Nothing
        Me.txtCustomerName.Size = New System.Drawing.Size(258, 20)
        Me.txtCustomerName.TabIndex = 65
        '
        'txtCustomerCode
        '
        Me.txtCustomerCode.Location = New System.Drawing.Point(118, 62)
        Me.txtCustomerCode.Name = "txtCustomerCode"
        Me.txtCustomerCode.R_ConductorGridSource = Nothing
        Me.txtCustomerCode.R_ConductorSource = Nothing
        Me.txtCustomerCode.R_UDT = Nothing
        Me.txtCustomerCode.Size = New System.Drawing.Size(100, 20)
        Me.txtCustomerCode.TabIndex = 66
        '
        'CST00100Filter
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(531, 291)
        Me.ControlBox = False
        Me.Controls.Add(Me.lupCustomer)
        Me.Controls.Add(Me.txtCustomerCode)
        Me.Controls.Add(Me.txtCustomerName)
        Me.Controls.Add(Me.lblCustomer)
        Me.Controls.Add(Me.rdbCustom)
        Me.Controls.Add(Me.rdbStandard)
        Me.Controls.Add(Me.btnRefresh)
        Me.Controls.Add(Me.cboAttributeGroup)
        Me.Controls.Add(Me.lblAttributeGroup)
        Me.Controls.Add(Me.cboFunction)
        Me.Controls.Add(Me.lblFunction)
        Me.Controls.Add(Me.lblSchedule)
        Me.Controls.Add(Me.cboSchedule)
        Me.Controls.Add(Me.lblSession)
        Me.Controls.Add(Me.lblProject)
        Me.Controls.Add(Me.cboSession)
        Me.Controls.Add(Me.cboProject)
        Me.Controls.Add(Me.cboVersion)
        Me.Controls.Add(Me.lblApplication)
        Me.Controls.Add(Me.lblVersion)
        Me.Controls.Add(Me.cboApplication)
        Me.Controls.Add(Me.R_ReturnPopUp1)
        Me.Name = "CST00100Filter"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "Filter"
        CType(Me.R_ReturnPopUp1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsFunction, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboFunction, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblFunction, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboAttributeGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsAttributeGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblAttributeGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnRefresh, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.rdbCustom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.rdbStandard, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lupCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCustomerName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCustomerCode, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents R_ReturnPopUp1 As R_FrontEnd.R_ReturnPopUp
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource
    Friend WithEvents bsVersion As System.Windows.Forms.BindingSource
    Friend WithEvents bsProject As System.Windows.Forms.BindingSource
    Friend WithEvents bsSession As System.Windows.Forms.BindingSource
    Friend WithEvents lblSession As R_FrontEnd.R_RadLabel
    Friend WithEvents lblProject As R_FrontEnd.R_RadLabel
    Friend WithEvents cboSession As R_FrontEnd.R_RadDropDownList
    Friend WithEvents cboProject As R_FrontEnd.R_RadDropDownList
    Friend WithEvents cboVersion As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents lblVersion As R_FrontEnd.R_RadLabel
    Friend WithEvents cboApplication As R_FrontEnd.R_RadDropDownList
    Friend WithEvents bsSchedule As System.Windows.Forms.BindingSource
    Friend WithEvents lblSchedule As R_FrontEnd.R_RadLabel
    Friend WithEvents cboSchedule As R_FrontEnd.R_RadDropDownList
    Friend WithEvents bsFunction As System.Windows.Forms.BindingSource
    Friend WithEvents cboFunction As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblFunction As R_FrontEnd.R_RadLabel
    Friend WithEvents cboAttributeGroup As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblAttributeGroup As R_FrontEnd.R_RadLabel
    Friend WithEvents bsAttributeGroup As System.Windows.Forms.BindingSource
    Friend WithEvents btnRefresh As R_FrontEnd.R_RadButton
    Friend WithEvents rdbCustom As R_FrontEnd.R_RadRadioButton
    Friend WithEvents rdbStandard As R_FrontEnd.R_RadRadioButton
    Friend WithEvents lblCustomer As R_FrontEnd.R_RadLabel
    Friend WithEvents lupCustomer As R_FrontEnd.R_LookUp
    Friend WithEvents txtCustomerName As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtCustomerCode As R_FrontEnd.R_RadTextBox

End Class
