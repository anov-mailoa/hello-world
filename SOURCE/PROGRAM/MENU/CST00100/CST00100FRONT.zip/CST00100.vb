﻿Imports CST00100FrontResources
Imports R_Common
Imports ClientHelper
Imports CST00100Front.CST00100ServiceRef
Imports CST00100Front.CST00100StreamingServiceRef
Imports R_FrontEnd
Imports System.ServiceModel.Channels
Imports RCustDBFrontHelper
Imports RCustDBFileCommon
Imports Telerik.WinControls
Imports System.Drawing
Imports Telerik.WinControls.UI

Public Class CST00100

#Region " VARIABLE "
    Dim C_ServiceName As String = "CST00100Service/CST00100Service.svc"
    Dim C_ServiceNameStream As String = "CST00100Service/CST00100StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _CVERSION As String
    Dim _CPROJECTID As String
    Dim _CSESSIONID As String
    Dim _CSCHEDULEID As String
    Dim _CUSER_NAME As String
    Dim _CFUNCTIONID As String
    Dim _LDONE_COMBO_SETTING As Boolean = False
    Dim _LREADY_TO_REFRESH As Boolean = False
    Dim _LINIT As Boolean
    Dim _CATTRIBUTEGROUP As String
    Dim _CATTRIBUTEID As String
    Dim _CITEMID As String
    'Dim _CSCHEDULE_ID As String
    Dim _CACTION As String
    Dim _CBACKUP_NOTE As String
    Dim _CBACKUP_TIME As String
    Dim _CLAST_ACTION As String
    Dim _CLAST_ACTION_BY As String
    Dim loFilterParam As New CST00100FilterParameterDTO
    Dim loGridKey As New RCustDBInboxKeyDTO
    Dim loBackupRestoreParam As New CST00100BackupRestoreDTO

#End Region

#Region " SUBs and FUNCTIONs "

    Private Sub RefreshGrids()
        With gvInbox
            bsGvInbox.ResetBindings(False)
            .R_RefreshGrid(loGridKey)
            .Columns(0).Sort(Telerik.WinControls.UI.RadSortOrder.Ascending, False)
        End With
    End Sub

    Private Sub ProcessHandler(pcProcess As String)
        Dim loException As New R_Exception
        Dim loFileHandler As New FileHandler
        Dim llProcess As Boolean

        Try
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
            llProcess = False

            If pcProcess = "SPECCHECKOUT" And Not _CFUNCTIONID = "DEVELOPMENT" Then
                loException.Add("CST00100_02", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CST00100_02").Trim) ' no item selected
                Exit Try
            End If

            Select Case pcProcess
                ' Checkin
                Case "CHECKIN"
                    Select Case _CFUNCTIONID
                        Case "DESIGN"
                            _CACTION = "DSGCI"
                        Case "DEVELOPMENT"
                            _CACTION = "DEVCI"
                        Case "QC"
                            _CACTION = "QCCI"
                    End Select
                Case "CHECKOUT"
                    ' Checkout
                    Select Case _CFUNCTIONID
                        Case "DESIGN"
                            _CACTION = "DSGCO"
                        Case "DEVELOPMENT"
                            _CACTION = "DEVCO"
                        Case "QC"
                            _CACTION = "QCCO"
                    End Select
                Case "SPECCHECKOUT"
                    ' Checkout
                    Select Case _CFUNCTIONID
                        Case "DEVELOPMENT"
                            _CACTION = "DEVSCO"
                    End Select
                Case "CANCELCHECKOUT"
                    ' Cancel Checkout
                    Select Case _CFUNCTIONID
                        Case "DESIGN"
                            _CACTION = "DSGCCO"
                        Case "DEVELOPMENT"
                            _CACTION = "DEVCCO"
                        Case "QC"
                            _CACTION = "QCCCO"
                    End Select
                Case "BACKUP"
                    ' Backup
                    _CACTION = "BACKUP"
                Case "COPY"
                    ' Copy
                    Select Case _CFUNCTIONID
                        Case "DESIGN"
                            _CACTION = "DSGCO"
                        Case "DEVELOPMENT"
                            _CACTION = "DEVCO"
                        Case "QC"
                            _CACTION = "QCCO"
                    End Select
                Case "RESTORE"
                    ' Backup
                    _CACTION = "RESTORE"
            End Select
            If _CACTION = "RESTORE" Then
                With loFileHandler
                    .CCOMPANY_ID = _CCOMPID
                    .CUSER_ID = _CUSERID
                    For Each loRow As RCustDBItemRestoreDTO In loBackupRestoreParam.ORESTORE_LIST
                        .OFILE_PROCESS_KEY.Add(New RCustDBFileProcessKeyDTO With {.CCOMPANY_ID = _CCOMPID, _
                                .CAPPS_CODE = _CAPPSCODE, _
                                .CVERSION = _CVERSION, _
                                .CPROJECT_ID = _CPROJECTID, _
                                .CSESSION_ID = _CSESSIONID, _
                                .CSCHEDULE_ID = _CSCHEDULEID, _
                                .CFUNCTION_ID = _CFUNCTIONID, _
                                .CATTRIBUTE_GROUP = _CATTRIBUTEGROUP, _
                                .CATTRIBUTE_ID = loRow.CATTRIBUTE_ID, _
                                .CITEM_ID = loRow.CITEM_ID, _
                                .CBACKUP_TIME = loRow.CBACKUP_TIME, _
                                .CACTION = _CACTION, _
                                .CUSER_ID = _CUSERID})
                    Next
                    .CPROGRAM_ID = "CST00100"
                    .CBACKUP_NOTE = _CBACKUP_NOTE
                    .CopySource()
                End With
            Else
                Dim loCheckedItems = From item In CType(bsGvInbox.List, List(Of RCustDBItemInboxDTO)) Where item.LSELECT = True

                If pcProcess = "RESTORE" And loCheckedItems.Count > 1 Then
                    loException.Add("CST00100_03", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CST00100_03").Trim) ' no item selected
                    Exit Try
                End If

                If loCheckedItems.Count > 0 Then
                    llProcess = True
                    With loFileHandler
                        .CCOMPANY_ID = _CCOMPID
                        .CUSER_ID = _CUSERID
                        For Each loRow As RCustDBItemInboxDTO In loCheckedItems
                            If Not pcProcess = "CHECKIN" _
                                Or (pcProcess = "CHECKIN" And ((_CFUNCTIONID = "DEVELOPMENT" And (loRow.CLAST_ACTION = "DEVCO" Or loRow.CLAST_ACTION = "DEVSCO" Or loRow.CLAST_ACTION = "DSGCCO") And loRow.CLAST_ACTION_BY = _CUSERID) _
                                Or (_CFUNCTIONID = "DESIGN" And ((loRow.CATTRIBUTE_GROUP = "DESIGN" And loRow.CLAST_ACTION = "DSGCO" And loRow.CLAST_ACTION_BY = _CUSERID) Or (loRow.CATTRIBUTE_GROUP = "PROGRAM" And loRow.CLAST_SPEC_ACTION = "DSGCO" And loRow.CLAST_SPEC_ACTION_BY = _CUSERID))) _
                                Or (_CFUNCTIONID = "QC" And loRow.CLAST_ACTION = "QCCO" And loRow.CLAST_ACTION_BY = _CUSERID))) Then
                                .OFILE_PROCESS_KEY.Add(New RCustDBFileProcessKeyDTO With {.CCOMPANY_ID = _CCOMPID, _
                                        .CAPPS_CODE = _CAPPSCODE, _
                                        .CVERSION = _CVERSION, _
                                        .CPROJECT_ID = _CPROJECTID, _
                                        .CSESSION_ID = _CSESSIONID, _
                                        .CSCHEDULE_ID = _CSCHEDULEID, _
                                        .CFUNCTION_ID = _CFUNCTIONID, _
                                        .CATTRIBUTE_GROUP = _CATTRIBUTEGROUP, _
                                        .CATTRIBUTE_ID = loRow.CATTRIBUTE_ID, _
                                        .CITEM_ID = loRow.CITEM_ID, _
                                        .LSPEC = loRow.LSPEC, _
                                        .CACTION = _CACTION, _
                                        .CUSER_ID = _CUSERID})
                            End If
                        Next
                        .CPROGRAM_ID = "CST00100"
                        .CBACKUP_NOTE = _CBACKUP_NOTE

                        Select Case pcProcess
                            Case "CHECKIN"
                                .CheckIn()
                                Threading.Thread.Sleep(5000)
                            Case "CHECKOUT"
                                .CheckOut()
                            Case "SPECCHECKOUT"
                                .CheckOut()
                            Case "CANCELCHECKOUT"
                                .CancelCheckOut()
                            Case "BACKUP"
                                .CheckIn()
                                Threading.Thread.Sleep(5000)
                            Case "COPY"
                                .CopySource()
                        End Select
                    End With
                Else
                    loException.Add("CST00100_01", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CST00100_01").Trim) ' no item selected
                    Exit Try
                End If
            End If

        Catch ex As Exception
            loException.Add(ex)
        Finally
            If loFileHandler.OEXCEPTION IsNot Nothing Then
                loException.Add(loFileHandler.OEXCEPTION)
            End If
            If llProcess Then
                RefreshGrids()
            End If
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        End Try
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        If loException.Haserror Then
            Me.R_DisplayException(loException)
        End If
    End Sub

    Private Sub ShowInboxNotification()
        Dim loServiceStream As CST00100StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00100StreamingService, CST00100StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of RCustDBInboxNotificationDTO)
        Dim loMethodKey As New RCustDBInboxKeyDTO
        Dim lcNotificationHeader As String = ""
        Dim lcNotificationContent As String = ""
        Dim lcNotificationFooter As String = ""

        Try
            daInboxNotification.Hide()

            With loMethodKey
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = _CAPPSCODE
                .CFUNCTION_ID = _CFUNCTIONID
                .CUSER_ID = _CUSERID
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cFunctionId", .CFUNCTION_ID)
                R_Utility.R_SetStreamingContext("cUserId", .CUSER_ID)
            End With

            loRtn = loServiceStream.GetInboxNotification()
            loStreaming = R_StreamUtility(Of RCustDBInboxNotificationDTO).ReadFromMessage(loRtn)

            ' prepare notification header
            lcNotificationHeader = "<html>You have task(s) to do:<br><ol>"
            For Each loDto As RCustDBInboxNotificationDTO In loStreaming
                If loDto IsNot Nothing Then
                    With loDto
                        lcNotificationContent += "<li><b>"
                        If .NOVERDUE > 0 Then
                            lcNotificationContent += "<span><color=Red>"
                        End If
                        lcNotificationContent += "Item: " + .CITEM_NAME + " | "
                        lcNotificationContent += "Attribute ID: " + .CATTRIBUTE_ID + " | "
                        lcNotificationContent += "Version: " + .CVERSION + " | "
                        lcNotificationContent += "Project ID: " + .CPROJECT_ID + " | "
                        lcNotificationContent += "Session ID: " + .CSESSION_ID + " | "
                        lcNotificationContent += "Schedule ID: " + .CSCHEDULE_ID + " | "
                        lcNotificationContent += "Attribute Group: " + .CATTRIBUTE_GROUP + " | "
                        If .NOVERDUE > 0 Then
                            lcNotificationContent += "</span>"
                        End If
                        lcNotificationContent += "</b><br>"
                        lcNotificationContent += "Mandays: " + .NMANDAYS.ToString + "| "
                        lcNotificationContent += "Start: " + General.StrToDate(.CPLAN_START_DATE).Value.ToString("yyyy-MM-dd") + "| "
                        lcNotificationContent += "End: " + General.StrToDate(.CPLAN_END_DATE).Value.ToString("yyyy-MM-dd") + "| "
                        lcNotificationContent += "Overdue: " + .NOVERDUE.ToString + " day(s).</li>"
                    End With
                Else
                    Exit For
                End If
            Next
            ' prepare notification footer
            lcNotificationFooter += "</ol></html>"

            If lcNotificationContent.Length > 0 Then
                With daInboxNotification
                    .ContentText = lcNotificationHeader + lcNotificationContent + lcNotificationFooter
                    .Show()
                End With
            End If

        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " FILTER "

    Private Sub btnFilter_R_After_Open_Form(poPopUpResult As System.Windows.Forms.DialogResult, poPopUpEntityResult As Object) Handles btnFilter.R_After_Open_Form

        If poPopUpResult = Windows.Forms.DialogResult.OK Then
            loFilterParam = poPopUpEntityResult
            With loFilterParam
                _CAPPSCODE = .OFILTER_KEY.CAPPS_CODE
                _CVERSION = .OFILTER_KEY.CVERSION
                _CPROJECTID = .OFILTER_KEY.CPROJECT_ID
                _CSESSIONID = .OFILTER_KEY.CSESSION_ID
                _CSCHEDULEID = .OFILTER_KEY.CSCHEDULE_ID
                _CFUNCTIONID = .OFILTER_KEY.CFUNCTION_ID
                _CATTRIBUTEGROUP = .OFILTER_KEY.CATTRIBUTE_GROUP
                txtApplication.Text = .CAPPS_NAME
                txtVersion.Text = IIf(.LCUSTOM, .CCUSTOMER_NAME, .CCODE_NAME)
                txtProject.Text = .CPROJECT_NAME
                txtSession.Text = .OFILTER_KEY.CSESSION_ID
                txtSchedule.Text = .CSCHEDULE_DESCRIPTION
                txtFunction.Text = .OFILTER_KEY.CFUNCTION_ID
                txtAttributeGroup.Text = .OFILTER_KEY.CATTRIBUTE_GROUP
                lblVersion.Visible = Not .LCUSTOM
                lblCustomer.Visible = .LCUSTOM
                lblCustom.Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), IIf(.LCUSTOM, "rdbCustom", "rdbStandard"))
            End With
            If Not (String.IsNullOrEmpty(_CAPPSCODE) Or String.IsNullOrEmpty(_CVERSION) Or String.IsNullOrEmpty(_CPROJECTID)) Then
                With loGridKey
                    .CCOMPANY_ID = _CCOMPID
                    .CAPPS_CODE = _CAPPSCODE
                    .CVERSION = _CVERSION
                    .CPROJECT_ID = _CPROJECTID
                    .CSESSION_ID = _CSESSIONID
                    .CSCHEDULE_ID = _CSCHEDULEID
                    .CFUNCTION_ID = _CFUNCTIONID
                    .CATTRIBUTE_GROUP = _CATTRIBUTEGROUP
                    .CUSER_ID = _CUSERID
                End With
                RefreshGrids()
            End If
            ShowInboxNotification()
        End If
        btnSpecCheckOut.Enabled = (_CFUNCTIONID = "DEVELOPMENT")
    End Sub

    Private Sub btnFilter_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnFilter.R_Before_Open_Form
        poTargetForm = New CST00100Filter
        poParameter = loFilterParam
    End Sub

#End Region

#Region " BACKUP "

    Private Sub btnBackup_R_After_Open_Form(poPopUpResult As System.Windows.Forms.DialogResult, poPopUpEntityResult As Object) Handles btnBackup.R_After_Open_Form
        If poPopUpResult = Windows.Forms.DialogResult.OK Then
            loBackupRestoreParam = poPopUpEntityResult
            _CBACKUP_NOTE = loBackupRestoreParam.CNOTE
            ProcessHandler("BACKUP")
        End If
    End Sub

    Private Sub btnBackup_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnBackup.R_Before_Open_Form
        poTargetForm = New CST00100Backup
        poParameter = loBackupRestoreParam
    End Sub

#End Region

#Region " RESTORE "

    Private Sub btnRestore_R_After_Open_Form(poPopUpResult As System.Windows.Forms.DialogResult, poPopUpEntityResult As Object) Handles btnRestore.R_After_Open_Form
        If poPopUpResult = Windows.Forms.DialogResult.OK Then
            loBackupRestoreParam = poPopUpEntityResult
            ProcessHandler("RESTORE")
        End If
    End Sub

    Private Sub btnRestore_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnRestore.R_Before_Open_Form
        poTargetForm = New CST00100Restore
        With loBackupRestoreParam
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = _CAPPSCODE
            .CVERSION = _CVERSION
            .CPROJECT_ID = _CPROJECTID
            .CSESSION_ID = _CSESSIONID
            .CSCHEDULE_ID = _CSCHEDULEID
            .CATTRIBUTE_GROUP = _CATTRIBUTEGROUP
            .CFUNCTION_ID = _CFUNCTIONID
        End With
        poParameter = loBackupRestoreParam
    End Sub

#End Region

#Region " FORM Events "

    Private Sub CST00100_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loComboKey As New RCustDBProjectKeyDTO

        Try
            _LINIT = False
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            ' Predefined dock
            Me.R_Components = Me.components
            preIssues.R_HeaderTitle = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CST00100IssuesTitle")
            loFilterParam.OFILTER_KEY.CCOMPANY_ID = _CCOMPID
            loFilterParam.CREFRESH_COMBO_MODE = "NORMAL"
            btnFilter.PerformClick()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub CST00100_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " GRIDVIEW Events "

    Private Sub gvInbox_RowFormatting(sender As Object, e As Telerik.WinControls.UI.RowFormattingEventArgs) Handles gvInbox.RowFormatting
        Dim llCheckOutByFunction As Boolean
        Dim llLocked As Boolean

        llCheckOutByFunction = False
        With e.RowElement.RowInfo.Cells("_CLAST_ACTION")

            Select Case _CFUNCTIONID
                Case "DESIGN"
                    llCheckOutByFunction = loFilterParam.IDESIGN_SEQUENCE = 1 And .Value = ""
                    llLocked = e.RowElement.RowInfo.Cells("_CSPEC_STATUS").Value = "LOCKED"
                Case "DEVELOPMENT"
                    llCheckOutByFunction = (loFilterParam.IDEV_SEQUENCE = 1 And .Value = "") _
                                            Or (loFilterParam.IDEV_SEQUENCE = 2 And .Value = "DSGCI")
                    llLocked = e.RowElement.RowInfo.Cells("_CITEM_STATUS").Value = "LOCKED"
                Case "QC"
                    llCheckOutByFunction = (loFilterParam.IQC_SEQUENCE = 1 And .Value = "") _
                                            Or (loFilterParam.IQC_SEQUENCE > 1 And .Value = "DEVCI")
            End Select

        End With

        If llLocked Then
            ' Item is LOCKED --> definitely RED
            With e.RowElement
                .DrawFill = True
                .GradientStyle = GradientStyles.Solid
                .BackColor = Color.Red
            End With
        ElseIf llCheckOutByFunction Then
            ' Item is ready to be checked out
            With e.RowElement
                .DrawFill = True
                .GradientStyle = GradientStyles.Solid
                .BackColor = Color.GreenYellow
            End With
        Else
            e.RowElement.ResetValue(LightVisualElement.BackColorProperty, ValueResetFlags.Local)
            e.RowElement.ResetValue(LightVisualElement.GradientStyleProperty, ValueResetFlags.Local)
            e.RowElement.ResetValue(LightVisualElement.DrawFillProperty, ValueResetFlags.Local)
        End If

    End Sub

    Private Sub gvInbox_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvInbox.R_Display
        With CType(poEntity, RCustDBItemInboxDTO)
            _CATTRIBUTEID = .CATTRIBUTE_ID
            _CITEMID = .CITEM_ID
            _CSESSIONID = .CSESSION_ID
            _CLAST_ACTION = .CLAST_ACTION
            _CLAST_ACTION_BY = .CLAST_ACTION_BY
        End With
    End Sub

    Private Sub gvInbox_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvInbox.R_ServiceGetListRecord
        Dim loServiceStream As CST00100StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00100StreamingService, CST00100StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of RCustDBItemInboxDTO)
        Dim loListEntity As New List(Of RCustDBItemInboxDTO)

        Try
            With CType(poEntity, RCustDBInboxKeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
                R_Utility.R_SetStreamingContext("cProjectId", .CPROJECT_ID)
                R_Utility.R_SetStreamingContext("cSessionId", .CSESSION_ID)
                R_Utility.R_SetStreamingContext("cScheduleId", .CSCHEDULE_ID)
                R_Utility.R_SetStreamingContext("cFunctionId", .CFUNCTION_ID)
                R_Utility.R_SetStreamingContext("cAttributeGroup", .CATTRIBUTE_GROUP)
                R_Utility.R_SetStreamingContext("cUserId", .CUSER_ID)
            End With

            loRtn = loServiceStream.GetItemInbox()
            loStreaming = R_StreamUtility(Of RCustDBItemInboxDTO).ReadFromMessage(loRtn)

            For Each loDto As RCustDBItemInboxDTO In loStreaming
                If loDto IsNot Nothing Then
                    With loDto
                        .DPLAN_START_DATE = General.StrToDate(.CPLAN_START_DATE)
                        .DPLAN_END_DATE = General.StrToDate(.CPLAN_END_DATE)
                        .DREVISED_START_DATE = General.StrToDate(.CREVISED_START_DATE)
                        .DREVISED_END_DATE = General.StrToDate(.CREVISED_END_DATE)
                    End With
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub conGridInbox_R_SetHasData(plEnable As Boolean) Handles conGridInbox.R_SetHasData
        btnSpecCheckOut.Enabled = plEnable And _CFUNCTIONID = "DEVELOPMENT"
    End Sub

#End Region

#Region " BUTTON Actions "

    Private Sub btnCheckIn_Click(sender As System.Object, e As System.EventArgs) Handles btnCheckIn.Click
        ProcessHandler("CHECKIN")
    End Sub

    Private Sub btnCheckOut_Click(sender As System.Object, e As System.EventArgs) Handles btnCheckOut.Click
        ProcessHandler("CHECKOUT")
    End Sub

    Private Sub btnSpecCheckOut_Click(sender As System.Object, e As System.EventArgs) Handles btnSpecCheckOut.Click
        ProcessHandler("SPECCHECKOUT")
    End Sub

    Private Sub btnCancelCheckOut_Click(sender As Object, e As System.EventArgs) Handles btnCancelCheckOut.Click
        ProcessHandler("CANCELCHECKOUT")
    End Sub

    Private Sub btnBackup_Click(sender As Object, e As System.EventArgs)
        ProcessHandler("BACKUP")
    End Sub

    Private Sub btnCopy_Click(sender As Object, e As System.EventArgs)
        ProcessHandler("COPY")
    End Sub

    Private Sub btnRefresh_Click(sender As System.Object, e As System.EventArgs) Handles btnRefresh.Click
        RefreshGrids()
    End Sub

#End Region

#Region " PREDEFINED DOCK Events "

    Private Sub preIssues_R_InstantiateDock(ByRef poTargetForm As R_FrontEnd.R_FormBase) Handles preIssues.R_InstantiateDock
        poTargetForm = New CST00100Issues
    End Sub

    Private Sub preIssues_R_PassParameter(ByRef poParameter As Object) Handles preIssues.R_PassParameter
        Dim loIssueKey As New RCustDBIssueKeyDTO

        With loIssueKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = _CAPPSCODE
            .CVERSION = _CVERSION
            .CPROJECT_ID = _CPROJECTID
            .CSESSION_ID = _CSESSIONID
            .CATTRIBUTE_GROUP = _CATTRIBUTEGROUP
            .CATTRIBUTE_ID = _CATTRIBUTEID
            .CITEM_ID = _CITEMID
            .CSCHEDULE_ID = _CSCHEDULEID
        End With
        poParameter = New CST00100IssuesParamDTO With {.CITEM_NAME = CType(bsGvInbox.Current, RCustDBItemInboxDTO).CITEM_NAME,
                                                       .OISSUE_KEY = loIssueKey}
    End Sub

#End Region

End Class
