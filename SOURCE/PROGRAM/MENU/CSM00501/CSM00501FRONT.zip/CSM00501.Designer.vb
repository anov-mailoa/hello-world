﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSM00501
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.calDayoff = New R_FrontEnd.R_RadCalendar(Me.components)
        Me.btnCRUD = New R_FrontEnd.R_Detail(Me.components)
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnDelete = New R_FrontEnd.R_RadButton(Me.components)
        Me.btnUpdate = New R_FrontEnd.R_RadButton(Me.components)
        Me.lblDescription = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtDescription = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.dtpHoliday = New R_FrontEnd.R_RadDateTimePicker(Me.components)
        CType(Me.calDayoff, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnCRUD, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.btnDelete, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnUpdate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblDescription, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDescription, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dtpHoliday, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'calDayoff
        '
        Me.calDayoff.DayNameFormat = Telerik.WinControls.UI.DayNameFormat.[Short]
        Me.calDayoff.Dock = System.Windows.Forms.DockStyle.Fill
        Me.calDayoff.Location = New System.Drawing.Point(3, 3)
        Me.calDayoff.Name = "calDayoff"
        Me.calDayoff.R_ConductorGridSource = Nothing
        Me.calDayoff.R_ConductorSource = Nothing
        Me.calDayoff.Size = New System.Drawing.Size(971, 569)
        Me.calDayoff.TabIndex = 0
        Me.calDayoff.Text = "R_RadCalendar1"
        '
        'btnCRUD
        '
        Me.btnCRUD.Location = New System.Drawing.Point(21, 204)
        Me.btnCRUD.Name = "btnCRUD"
        Me.btnCRUD.R_ConductorGridSource = Nothing
        Me.btnCRUD.R_ConductorSource = Nothing
        Me.btnCRUD.R_DescriptionId = Nothing
        Me.btnCRUD.R_ResourceId = Nothing
        Me.btnCRUD.R_Title = Nothing
        Me.btnCRUD.Size = New System.Drawing.Size(110, 24)
        Me.btnCRUD.TabIndex = 0
        Me.btnCRUD.Text = "R_Detail1"
        Me.btnCRUD.Visible = False
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 300.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.calDayoff, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 1, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 1
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnDelete)
        Me.Panel1.Controls.Add(Me.btnUpdate)
        Me.Panel1.Controls.Add(Me.lblDescription)
        Me.Panel1.Controls.Add(Me.txtDescription)
        Me.Panel1.Controls.Add(Me.dtpHoliday)
        Me.Panel1.Controls.Add(Me.btnCRUD)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(980, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(294, 569)
        Me.Panel1.TabIndex = 1
        '
        'btnDelete
        '
        Me.btnDelete.Location = New System.Drawing.Point(128, 140)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.R_ConductorGridSource = Nothing
        Me.btnDelete.R_ConductorSource = Nothing
        Me.btnDelete.R_DescriptionId = Nothing
        Me.btnDelete.R_ResourceId = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(110, 24)
        Me.btnDelete.TabIndex = 9
        Me.btnDelete.Text = "R_RadButton2"
        '
        'btnUpdate
        '
        Me.btnUpdate.Location = New System.Drawing.Point(12, 140)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.R_ConductorGridSource = Nothing
        Me.btnUpdate.R_ConductorSource = Nothing
        Me.btnUpdate.R_DescriptionId = Nothing
        Me.btnUpdate.R_ResourceId = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(110, 24)
        Me.btnUpdate.TabIndex = 8
        Me.btnUpdate.Text = "R_RadButton1"
        '
        'lblDescription
        '
        Me.lblDescription.AutoSize = False
        Me.lblDescription.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblDescription.Location = New System.Drawing.Point(12, 35)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblDescription.R_ResourceId = "lblDescription"
        Me.lblDescription.Size = New System.Drawing.Size(100, 18)
        Me.lblDescription.TabIndex = 7
        Me.lblDescription.Text = "R_RadLabel1"
        '
        'txtDescription
        '
        Me.txtDescription.AcceptsReturn = True
        Me.txtDescription.AutoSize = False
        Me.txtDescription.Location = New System.Drawing.Point(12, 59)
        Me.txtDescription.Multiline = True
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.R_ConductorGridSource = Nothing
        Me.txtDescription.R_ConductorSource = Nothing
        Me.txtDescription.R_UDT = Nothing
        Me.txtDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtDescription.Size = New System.Drawing.Size(247, 75)
        Me.txtDescription.TabIndex = 6
        '
        'dtpHoliday
        '
        Me.dtpHoliday.Enabled = False
        Me.dtpHoliday.Format = System.Windows.Forms.DateTimePickerFormat.[Long]
        Me.dtpHoliday.Location = New System.Drawing.Point(12, 9)
        Me.dtpHoliday.Name = "dtpHoliday"
        Me.dtpHoliday.R_ConductorGridSource = Nothing
        Me.dtpHoliday.R_ConductorSource = Nothing
        Me.dtpHoliday.ReadOnly = True
        Me.dtpHoliday.Size = New System.Drawing.Size(247, 20)
        Me.dtpHoliday.TabIndex = 5
        Me.dtpHoliday.TabStop = False
        Me.dtpHoliday.Text = "Thursday, September 29, 2016"
        Me.dtpHoliday.Value = New Date(2016, 9, 29, 16, 30, 38, 199)
        '
        'CSM00501
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CSM00501"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.calDayoff, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnCRUD, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.btnDelete, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnUpdate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblDescription, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDescription, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dtpHoliday, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents calDayoff As R_FrontEnd.R_RadCalendar
    Friend WithEvents btnCRUD As R_FrontEnd.R_Detail
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnDelete As R_FrontEnd.R_RadButton
    Friend WithEvents btnUpdate As R_FrontEnd.R_RadButton
    Friend WithEvents lblDescription As R_FrontEnd.R_RadLabel
    Friend WithEvents txtDescription As R_FrontEnd.R_RadTextBox
    Friend WithEvents dtpHoliday As R_FrontEnd.R_RadDateTimePicker

End Class
