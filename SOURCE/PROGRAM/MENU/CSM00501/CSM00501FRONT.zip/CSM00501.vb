﻿Imports Telerik.WinControls.UI
Imports CSM00501Front.CSM00501ServiceRef
Imports R_FrontEnd
Imports CSM00501FrontResources
Imports R_Common
Imports RCustDBFrontHelper.General
Imports ClientHelper

Public Class CSM00501

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSM00501Service/CSM00501Service.svc"
    Dim C_ServiceNameStream As String = "CSM00501Service/CSM00501StreamingService.svc"
    Dim _CUSERID As String
    Dim _NYEAR As Integer
    Dim _OHOLIDAY_LIST As List(Of CSM00501HolidayListDTO)
    Dim _OHOLIDAY As New CSM00501HolidayCRUDDTO
    Dim _OCRUD_ACTION As CSM00501ClsCRUDAction
    Dim loService As CSM00501ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00501Service, CSM00501ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
#End Region

    Private Sub RefreshCalendar(year As String, month As String)
        _OHOLIDAY_LIST = loService.GetHolidayList(year, month)
    End Sub

    Private Sub SetButton()

        If String.IsNullOrEmpty(_OHOLIDAY.CDESCRIPTION) Then
            _OCRUD_ACTION = CSM00501ClsCRUDAction.Insert
            btnDelete.Enabled = False
        Else
            _OCRUD_ACTION = CSM00501ClsCRUDAction.Update
            btnDelete.Enabled = True
        End If

    End Sub

    Private Sub CSM00501_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class

        _OHOLIDAY.CUSER_ID = U_GlobalVar.UserId
        dtpHoliday.Value = Today
        RefreshCalendar(Today.Year.ToString, "*")
        SetButton()
    End Sub

    Private Sub calDayoff_ElementRender(sender As Object, e As Telerik.WinControls.UI.RenderElementEventArgs) Handles calDayoff.ElementRender

        Dim renderDate As Date
        Dim loFont As System.Drawing.Font = New Drawing.Font(e.Element.Font.FontFamily, 14, Drawing.FontStyle.Bold)

        With e.Element

            .TextAlignment = Drawing.ContentAlignment.TopLeft
            .TextWrap = True
            .Font = loFont
            .ResetValue(LightVisualElement.ForeColorProperty, Telerik.WinControls.ValueResetFlags.Local)
            If e.Day.Date.DayOfWeek.Equals(DayOfWeek.Sunday) And e.Day.Date.Month.Equals(e.View.Calendar.DefaultView.ViewStartDate.Month) Then
                .ForeColor = Drawing.Color.Red
            Else
                ' loop holiday list
                If _OHOLIDAY_LIST IsNot Nothing Then
                    For Each loHoliday As CSM00501HolidayListDTO In _OHOLIDAY_LIST
                        ' for displayed month only
                        If CInt(loHoliday.CMONTH) = e.Day.Date.Month Then
                            renderDate = New Date(CInt(loHoliday.CYEAR), CInt(loHoliday.CMONTH), CInt(loHoliday.CDAY))
                            If renderDate.Equals(e.Day.Date) Then
                                .ForeColor = Drawing.Color.Red
                            End If
                        End If
                    Next

                End If

            End If
        End With

    End Sub

    Private Sub calDayoff_SelectionChanged(sender As Object, e As System.EventArgs) Handles calDayoff.SelectionChanged
        Dim lcYear As String
        Dim lcMonth As String
        Dim lcDay As String
        Dim loHoliday As CSM00501HolidayListDTO

        _OHOLIDAY.CDESCRIPTION = ""
        With CType(sender, R_RadCalendar)
            lcYear = .FocusedDate.Year.ToString
            lcMonth = Microsoft.VisualBasic.Right("00" & .FocusedDate.Month.ToString, 2)
            lcDay = Microsoft.VisualBasic.Right("00" & .FocusedDate.Day.ToString, 2)
            loHoliday = _OHOLIDAY_LIST.Where(Function(x) _
                                                    x.CYEAR.Equals(lcYear) _
                                                    And x.CMONTH.Equals(lcMonth) _
                                                    And x.CDAY.Equals(lcDay)).FirstOrDefault
        End With

        If loHoliday IsNot Nothing Then
            _OHOLIDAY.CDESCRIPTION = loHoliday.CDESCRIPTION
        End If
        txtDescription.Text = _OHOLIDAY.CDESCRIPTION
        _OHOLIDAY.CHOLIDAY_DATE = lcYear.Trim & lcMonth.Trim & lcDay.Trim

        dtpHoliday.Value = StrToDate(_OHOLIDAY.CHOLIDAY_DATE)
        SetButton()
    End Sub

    Private Sub calDayoff_ViewChanged(sender As Object, e As System.EventArgs) Handles calDayoff.ViewChanged
        Dim lnYear As Integer
        Dim loSender As R_RadCalendar

        ' get holiday list, only if year is changed
        loSender = sender
        lnYear = loSender.DefaultView.ViewStartDate.Year
        If Not lnYear.Equals(_NYEAR) Then
            RefreshCalendar(lnYear.ToString, "*")
            _NYEAR = lnYear
        End If
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As System.EventArgs) Handles btnUpdate.Click
        Dim loEx As New R_Exception
        Dim loService As CSM00501ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00501Service, CSM00501ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)

        Try
            ' validation
            If String.IsNullOrEmpty(txtDescription.Text) Then
                loEx.Add("CSM00501_01", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00501_01"))
                Exit Try
            End If

            ' update data
            With _OHOLIDAY
                .CDESCRIPTION = txtDescription.Text.Trim
            End With
            loService.SetHoliday(_OHOLIDAY, _OCRUD_ACTION)
            RefreshCalendar(Today.Year.ToString, "*")
            SetButton()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As System.EventArgs) Handles btnDelete.Click
        Dim loEx As New R_Exception
        Dim loService As CSM00501ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00501Service, CSM00501ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)

        Try
            ' delete data
            loService.SetHoliday(_OHOLIDAY, CSM00501ClsCRUDAction.Delete)
            RefreshCalendar(Today.Year.ToString, "*")
            txtDescription.Text = ""
            _OHOLIDAY.CDESCRIPTION = ""
            SetButton()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If
    End Sub
End Class
