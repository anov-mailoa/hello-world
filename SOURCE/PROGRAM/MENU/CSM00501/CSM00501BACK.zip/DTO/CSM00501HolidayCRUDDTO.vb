﻿Public Class CSM00501HolidayCRUDDTO
    Public Property CHOLIDAY_DATE As String
    Public Property CDESCRIPTION As String
    Public Property CUSER_ID As String
End Class
