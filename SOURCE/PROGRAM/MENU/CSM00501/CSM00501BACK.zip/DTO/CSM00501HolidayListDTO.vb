﻿Public Class CSM00501HolidayListDTO
    Public Property CYEAR As String
    Public Property CMONTH As String
    Public Property CDAY As String
    Public Property CDESCRIPTION As String
End Class
