﻿Imports R_BackEnd
Imports R_Common
Imports ServerHelper.General

Public Class CSM00501Cls

    Public Enum CRUDAction
        Insert = 1
        Update = 2
        Delete = 3
    End Enum

    Public Function GetHolidayList(pcYear As String, pcMonth As String) As List(Of CSM00501HolidayListDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00501HolidayListDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "EXEC RSP_Get_Holiday '{0}', '{1}' "
            lcQuery = String.Format(lcQuery, pcYear, pcMonth)

            loResult = loDb.SqlExecObjectQuery(Of CSM00501HolidayListDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Sub SetHoliday(poKey As CSM00501HolidayCRUDDTO, poAction As CRUDAction)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00501HolidayListDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                ' Update database
                Select Case poAction
                    Case CRUDAction.Insert
                        lcQuery = "INSERT INTO CSM_HOLIDAY "
                        lcQuery += "VALUES ('{0}', '{1}', '{2}', GETDATE(), '{2}', GETDATE()) "
                        lcQuery = String.Format(lcQuery, .CHOLIDAY_DATE, .CDESCRIPTION, .CUSER_ID)
                    Case CRUDAction.Update
                        lcQuery = "UPDATE CSM_HOLIDAY "
                        lcQuery += "SET CDESCRIPTION = '{1}', "
                        lcQuery += "CUPDATE_BY = '{2}', "
                        lcQuery += "DUPDATE_DATE = GETDATE() "
                        lcQuery += "WHERE CHOLIDAY_DATE = '{0}' "
                        lcQuery = String.Format(lcQuery, .CHOLIDAY_DATE, .CDESCRIPTION, .CUSER_ID)
                    Case CRUDAction.Delete
                        lcQuery = "DELETE CSM_HOLIDAY "
                        lcQuery += "WHERE CHOLIDAY_DATE = '{0}' "
                        lcQuery = String.Format(lcQuery, .CHOLIDAY_DATE)
                End Select
                loDb.SqlExecNonQuery(lcQuery)

            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

End Class
