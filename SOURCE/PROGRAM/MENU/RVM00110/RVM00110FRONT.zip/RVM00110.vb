﻿Imports RVM00110Front.RVM00110StreamingServiceRef
Imports RVM00110Front.RVM00110ServiceRef
Imports R_FrontEnd
Imports R_Common
Imports System.ServiceModel.Channels
Imports RVM00110FrontResources
Imports ClientHelper
Imports RCustDBFrontHelper

Public Class RVM00110

#Region " VARIABLE "
    Dim C_ServiceName As String = "RVM00110Service/RVM00110Service.svc"
    Dim C_ServiceNameStream As String = "RVM00110Service/RVM00110StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPS_CODE As String
    Dim _CVERSION As String
    Dim llInitialized As Boolean = False
#End Region

#Region " F O R M "

    Private Sub RVM00110_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loSvc As RVM00110ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVM00110Service, RVM00110ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loAppCombo As New List(Of RVM00100AppComboDTO)

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            ' Application
            loAppCombo = loSvc.GetApplicationCombo(_CCOMPID, _CUSERID)
            If loAppCombo.Count <= 0 Then
                cboApplication.Items.Clear()
            End If
            bsApps.DataSource = loAppCombo
            _CAPPS_CODE = cboApplication.SelectedValue

            ' Main grid
            Dim loTableKey As New RVM00100CustomerGridDTO
            With loTableKey
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = _CAPPS_CODE
            End With
            gvCustomer.R_RefreshGrid(loTableKey)
            llInitialized = True

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()


    End Sub

    Private Sub RVM00110Customer_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " G R I D V I E W "

    Private Sub gvCustomer_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvCustomer.DataBindingComplete
        gvCustomer.BestFitColumns()
    End Sub

    Private Sub gvCustomer_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvCustomer.R_Saving
        With CType(poEntity, RVM00100CustomerDTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = _CAPPS_CODE
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With
    End Sub

    Private Sub gvCustomer_R_ServiceDelete(poEntity As Object) Handles gvCustomer.R_ServiceDelete
        Dim loService As RVM00110ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVM00110Service, RVM00110ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvCustomer_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvCustomer.R_ServiceGetListRecord
        Dim loServiceStream As RVM00110StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVM00110StreamingService, RVM00110StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of RVM00100CustomerGridDTO)
        Dim loListEntity As New List(Of RVM00100CustomerDTO)

        Try
            With poEntity
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
            End With

            loRtn = loServiceStream.GetApplicationCustomers()
            loStreaming = R_StreamUtility(Of RVM00100CustomerGridDTO).ReadFromMessage(loRtn)

            For Each loDto As RVM00100CustomerGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New RVM00100CustomerDTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                              ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                                   ._CCUSTOMER_CODE = loDto.CCUSTOMER_CODE,
                                                                   ._CCUSTOMER_NAME = loDto.CCUSTOMER_NAME,
                                                                   ._CSERVER_TYPE = loDto.CSERVER_TYPE,
                                                                   ._CSERVER_TYPE_NAME = loDto.CSERVER_TYPE_NAME,
                                                                   ._CSERVER_UID = loDto.CSERVER_UID,
                                                                   ._LACTIVE = loDto.LACTIVE,
                                                                   ._NINTERVAL = loDto.NINTERVAL,
                                                                   ._NGRACE_DAYS = loDto.NGRACE_DAYS,
                                                                   ._NWARNING_DAYS = loDto.NWARNING_DAYS,
                                                                   ._CLAST_EXPIRY_DATE = loDto.CLAST_EXPIRY_DATE,
                                                                   ._CCURRENT_EXPIRY_DATE = loDto.CCURRENT_EXPIRY_DATE,
                                                                   ._CREACTIVATION_STATUS = loDto.CREACTIVATION_STATUS,
                                                                   ._DLAST_EXPIRY_DATE = General.StrToDate(loDto.CLAST_EXPIRY_DATE),
                                                                   ._DCURRENT_EXPIRY_DATE = General.StrToDate(loDto.CCURRENT_EXPIRY_DATE),
                                                              ._CCREATE_BY = loDto.CCREATE_BY,
                                                              ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                              ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                              ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvCustomer_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvCustomer.R_ServiceGetRecord
        Dim loService As RVM00110ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVM00110Service, RVM00110ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvCustomer_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvCustomer.R_ServiceSave
        Dim loService As RVM00110ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVM00110Service, RVM00110ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " C O M B O "

    Private Sub cboApplication_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboApplication.SelectedValueChanged
        _CAPPS_CODE = CType(sender, R_RadDropDownList).SelectedValue
        lblActivationType.Text = "Activation Type: " & bsApps.Current.CACTIVATION_TYPE_NAME

        If llInitialized = True Then
            ' Main grid
            Dim loTableKey As New RVM00100CustomerGridDTO
            With loTableKey
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = _CAPPS_CODE
            End With
            gvCustomer.R_RefreshGrid(loTableKey)
        End If

    End Sub

#End Region

End Class
