﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RVM00110
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn1 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewDecimalColumn1 As R_FrontEnd.R_GridViewDecimalColumn = New R_FrontEnd.R_GridViewDecimalColumn()
        Dim R_GridViewDecimalColumn2 As R_FrontEnd.R_GridViewDecimalColumn = New R_FrontEnd.R_GridViewDecimalColumn()
        Dim R_GridViewDecimalColumn3 As R_FrontEnd.R_GridViewDecimalColumn = New R_FrontEnd.R_GridViewDecimalColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn2 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblActivationType = New R_FrontEnd.R_RadLabel(Me.components)
        Me.cboApplication = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvCustomer = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvCustomer = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridCustomer = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.lblActivationType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvCustomer.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.gvCustomer, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lblActivationType)
        Me.Panel1.Controls.Add(Me.cboApplication)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 24)
        Me.Panel1.TabIndex = 0
        '
        'lblActivationType
        '
        Me.lblActivationType.AutoSize = False
        Me.lblActivationType.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblActivationType.Location = New System.Drawing.Point(521, 3)
        Me.lblActivationType.Name = "lblActivationType"
        Me.lblActivationType.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblActivationType.R_ResourceId = Nothing
        Me.lblActivationType.Size = New System.Drawing.Size(564, 18)
        Me.lblActivationType.TabIndex = 5
        Me.lblActivationType.Text = "R_RadLabel1"
        '
        'cboApplication
        '
        Me.cboApplication.DataMember = Nothing
        Me.cboApplication.DataSource = Me.bsApps
        Me.cboApplication.DisplayMember = "CAPPS_NAME"
        Me.cboApplication.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList
        Me.cboApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboApplication.Location = New System.Drawing.Point(115, 3)
        Me.cboApplication.Name = "cboApplication"
        Me.cboApplication.R_ConductorGridSource = Nothing
        Me.cboApplication.R_ConductorSource = Nothing
        Me.cboApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboApplication.Size = New System.Drawing.Size(400, 20)
        Me.cboApplication.TabIndex = 4
        Me.cboApplication.Text = "R_RadDropDownList1"
        Me.cboApplication.ValueMember = "CAPPS_CODE"
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 3)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 3
        Me.lblApplication.Text = "Application..."
        '
        'gvCustomer
        '
        Me.gvCustomer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvCustomer.EnableFastScrolling = True
        Me.gvCustomer.Location = New System.Drawing.Point(3, 33)
        '
        '
        '
        Me.gvCustomer.MasterTemplate.AllowAddNewRow = False
        Me.gvCustomer.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn1.FieldName = "_CCUSTOMER_CODE"
        R_GridViewTextBoxColumn1.HeaderText = "_CCUSTOMER_CODE"
        R_GridViewTextBoxColumn1.IsPinned = True
        R_GridViewTextBoxColumn1.Name = "_CCUSTOMER_CODE"
        R_GridViewTextBoxColumn1.PinPosition = Telerik.WinControls.UI.PinnedColumnPosition.Left
        R_GridViewTextBoxColumn1.R_ResourceId = "_CCUSTOMER_CODE"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 126
        R_GridViewTextBoxColumn2.FieldName = "_CCUSTOMER_NAME"
        R_GridViewTextBoxColumn2.HeaderText = "_CCUSTOMER_NAME"
        R_GridViewTextBoxColumn2.IsPinned = True
        R_GridViewTextBoxColumn2.Name = "_CCUSTOMER_NAME"
        R_GridViewTextBoxColumn2.PinPosition = Telerik.WinControls.UI.PinnedColumnPosition.Left
        R_GridViewTextBoxColumn2.R_ResourceId = "_CCUSTOMER_NAME"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 128
        R_GridViewTextBoxColumn3.FieldName = "_CSERVER_TYPE_NAME"
        R_GridViewTextBoxColumn3.HeaderText = "_CSERVER_TYPE_NAME"
        R_GridViewTextBoxColumn3.Name = "_CSERVER_TYPE_NAME"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CSERVER_TYPE_NAME"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 137
        R_GridViewCheckBoxColumn1.FieldName = "_LACTIVE"
        R_GridViewCheckBoxColumn1.HeaderText = "_LACTIVE"
        R_GridViewCheckBoxColumn1.Name = "_LACTIVE"
        R_GridViewCheckBoxColumn1.R_EnableEDIT = True
        R_GridViewCheckBoxColumn1.R_ResourceId = "_LACTIVE"
        R_GridViewCheckBoxColumn1.Width = 83
        R_GridViewDecimalColumn1.DataType = GetType(Integer)
        R_GridViewDecimalColumn1.DecimalPlaces = 0
        R_GridViewDecimalColumn1.FieldName = "_NINTERVAL"
        R_GridViewDecimalColumn1.FormatString = "{0:N}"
        R_GridViewDecimalColumn1.HeaderText = "_NINTERVAL"
        R_GridViewDecimalColumn1.Maximum = New Decimal(New Integer() {144, 0, 0, 0})
        R_GridViewDecimalColumn1.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        R_GridViewDecimalColumn1.Name = "_NINTERVAL"
        R_GridViewDecimalColumn1.R_EnableEDIT = True
        R_GridViewDecimalColumn1.R_ResourceId = "_NINTERVAL"
        R_GridViewDecimalColumn1.ThousandsSeparator = True
        R_GridViewDecimalColumn1.Width = 85
        R_GridViewDecimalColumn2.DataType = GetType(Integer)
        R_GridViewDecimalColumn2.DecimalPlaces = 0
        R_GridViewDecimalColumn2.FieldName = "_NGRACE_DAYS"
        R_GridViewDecimalColumn2.FormatString = "{0:N}"
        R_GridViewDecimalColumn2.HeaderText = "_NGRACE_DAYS"
        R_GridViewDecimalColumn2.Maximum = New Decimal(New Integer() {720, 0, 0, 0})
        R_GridViewDecimalColumn2.Minimum = New Decimal(New Integer() {0, 0, 0, 0})
        R_GridViewDecimalColumn2.Name = "_NGRACE_DAYS"
        R_GridViewDecimalColumn2.R_EnableEDIT = True
        R_GridViewDecimalColumn2.R_ResourceId = "_NGRACE_DAYS"
        R_GridViewDecimalColumn2.ThousandsSeparator = True
        R_GridViewDecimalColumn2.Width = 102
        R_GridViewDecimalColumn3.DataType = GetType(Integer)
        R_GridViewDecimalColumn3.DecimalPlaces = 0
        R_GridViewDecimalColumn3.FieldName = "_NWARNING_DAYS"
        R_GridViewDecimalColumn3.FormatString = "{0:N}"
        R_GridViewDecimalColumn3.HeaderText = "_NWARNING_DAYS"
        R_GridViewDecimalColumn3.Maximum = New Decimal(New Integer() {60, 0, 0, 0})
        R_GridViewDecimalColumn3.Minimum = New Decimal(New Integer() {0, 0, 0, 0})
        R_GridViewDecimalColumn3.Name = "_NWARNING_DAYS"
        R_GridViewDecimalColumn3.R_EnableEDIT = True
        R_GridViewDecimalColumn3.R_ResourceId = "_NWARNING_DAYS"
        R_GridViewDecimalColumn3.ThousandsSeparator = True
        R_GridViewDecimalColumn3.Width = 120
        R_GridViewDateTimeColumn1.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn1.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn1.FieldName = "_DLAST_EXPIRY_DATE"
        R_GridViewDateTimeColumn1.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn1.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn1.HeaderText = "_DLAST_EXPIRY_DATE"
        R_GridViewDateTimeColumn1.Name = "_DLAST_EXPIRY_DATE"
        R_GridViewDateTimeColumn1.R_ResourceId = "_DLAST_EXPIRY_DATE"
        R_GridViewDateTimeColumn1.Width = 131
        R_GridViewDateTimeColumn2.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn2.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn2.FieldName = "_DCURRENT_EXPIRY_DATE"
        R_GridViewDateTimeColumn2.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn2.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn2.HeaderText = "_DCURRENT_EXPIRY_DATE"
        R_GridViewDateTimeColumn2.Name = "_DCURRENT_EXPIRY_DATE"
        R_GridViewDateTimeColumn2.R_ResourceId = "_DCURRENT_EXPIRY_DATE"
        R_GridViewDateTimeColumn2.Width = 154
        R_GridViewTextBoxColumn4.FieldName = "_CREACTIVATION_STATUS"
        R_GridViewTextBoxColumn4.HeaderText = "_CREACTIVATION_STATUS"
        R_GridViewTextBoxColumn4.Name = "_CREACTIVATION_STATUS"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CREACTIVATION_STATUS"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 154
        Me.gvCustomer.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewCheckBoxColumn1, R_GridViewDecimalColumn1, R_GridViewDecimalColumn2, R_GridViewDecimalColumn3, R_GridViewDateTimeColumn1, R_GridViewDateTimeColumn2, R_GridViewTextBoxColumn4})
        Me.gvCustomer.MasterTemplate.DataSource = Me.bsGvCustomer
        Me.gvCustomer.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvCustomer.MasterTemplate.EnableFiltering = True
        Me.gvCustomer.MasterTemplate.EnableGrouping = False
        Me.gvCustomer.MasterTemplate.ShowFilteringRow = False
        Me.gvCustomer.MasterTemplate.ShowGroupedColumns = True
        Me.gvCustomer.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvCustomer.Name = "gvCustomer"
        Me.gvCustomer.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvCustomer.R_ConductorGridSource = Me.conGridCustomer
        Me.gvCustomer.R_ConductorSource = Nothing
        Me.gvCustomer.R_DataAdded = False
        Me.gvCustomer.R_NewRowText = Nothing
        Me.gvCustomer.ShowHeaderCellButtons = True
        Me.gvCustomer.Size = New System.Drawing.Size(1271, 539)
        Me.gvCustomer.TabIndex = 1
        Me.gvCustomer.Text = "R_RadGridView1"
        '
        'bsGvCustomer
        '
        Me.bsGvCustomer.DataSource = GetType(RVM00110Front.RVM00110ServiceRef.RVM00100CustomerDTO)
        '
        'conGridCustomer
        '
        Me.conGridCustomer.R_ConductorParent = Nothing
        Me.conGridCustomer.R_IsHeader = True
        Me.conGridCustomer.R_RadGroupBox = Nothing
        '
        'RVM00110
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "RVM00110"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "Customer"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.lblActivationType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvCustomer.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(false)

End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents gvCustomer As R_FrontEnd.R_RadGridView
    Friend WithEvents bsGvCustomer As System.Windows.Forms.BindingSource
    Friend WithEvents conGridCustomer As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource
    Friend WithEvents cboApplication As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents lblActivationType As R_FrontEnd.R_RadLabel

End Class
