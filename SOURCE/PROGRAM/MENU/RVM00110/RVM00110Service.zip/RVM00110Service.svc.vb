﻿Imports R_Common
Imports RVM00100Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "RVM00100CustomerService" in code, svc and config file together.
Public Class RVM00110Service
    Implements IRVM00110Service

    Public Sub Svc_R_Delete(poEntity As RVM00100Back.RVM00100CustomerDTO) Implements R_BackEnd.R_IServicebase(Of RVM00100Back.RVM00100CustomerDTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New RVM00100CustomerCls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As RVM00100Back.RVM00100CustomerDTO) As RVM00100Back.RVM00100CustomerDTO Implements R_BackEnd.R_IServicebase(Of RVM00100Back.RVM00100CustomerDTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New RVM00100CustomerCls
        Dim loRtn As RVM00100CustomerDTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As RVM00100Back.RVM00100CustomerDTO, poCRUDMode As R_Common.eCRUDMode) As RVM00100Back.RVM00100CustomerDTO Implements R_BackEnd.R_IServicebase(Of RVM00100Back.RVM00100CustomerDTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New RVM00100CustomerCls
        Dim loRtn As RVM00100CustomerDTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetApplicationCombo(companyId As String, userId As String) As System.Collections.Generic.List(Of RVM00100Back.RVM00100AppComboDTO) Implements IRVM00110Service.GetApplicationCombo
        Dim loException As New R_Exception
        Dim loCls As New RVM00100CustomerCls
        Dim loRtn As List(Of RVM00100AppComboDTO)

        Try
            loRtn = loCls.GetApplicationCombo(companyId, userId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
