﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LicenseAndActivation
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.R_RadGroupBox1 = New R_FrontEnd.R_RadGroupBox(Me.components)
        Me.lblNoUser = New R_FrontEnd.R_RadLabel(Me.components)
        Me.bsDetail = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblLicenseMode = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel4 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel3 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblCompId = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel1 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadGroupBox2 = New R_FrontEnd.R_RadGroupBox(Me.components)
        Me.lblWarning = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblGrace = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblTo = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblFrom = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel7 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel6 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel5 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.btnRtnPopup = New R_FrontEnd.R_ReturnPopUp()
        Me.conDetail = New R_FrontEnd.R_Conductor(Me.components)
        Me.R_RadLabel2 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel8 = New R_FrontEnd.R_RadLabel(Me.components)
        CType(Me.R_RadGroupBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.R_RadGroupBox1.SuspendLayout()
        CType(Me.lblNoUser, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsDetail, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblLicenseMode, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCompId, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadGroupBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.R_RadGroupBox2.SuspendLayout()
        CType(Me.lblWarning, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblGrace, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblTo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblFrom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conDetail, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'R_RadGroupBox1
        '
        Me.R_RadGroupBox1.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping
        Me.R_RadGroupBox1.Controls.Add(Me.lblNoUser)
        Me.R_RadGroupBox1.Controls.Add(Me.lblLicenseMode)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel4)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel3)
        Me.R_RadGroupBox1.Controls.Add(Me.lblCompId)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel1)
        Me.R_RadGroupBox1.Font = New System.Drawing.Font("Calibri", 15.0!)
        Me.R_RadGroupBox1.HeaderText = "R_RadGroupBox1"
        Me.R_RadGroupBox1.Location = New System.Drawing.Point(13, 13)
        Me.R_RadGroupBox1.Name = "R_RadGroupBox1"
        Me.R_RadGroupBox1.R_ConductorGridSource = Nothing
        Me.R_RadGroupBox1.R_ConductorSource = Nothing
        Me.R_RadGroupBox1.R_ResourceId = "_LicenseInfo"
        Me.R_RadGroupBox1.Size = New System.Drawing.Size(323, 108)
        Me.R_RadGroupBox1.TabIndex = 0
        Me.R_RadGroupBox1.Text = "R_RadGroupBox1"
        '
        'lblNoUser
        '
        Me.lblNoUser.AutoSize = False
        Me.lblNoUser.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_NLICENSEE", True))
        Me.lblNoUser.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblNoUser.Location = New System.Drawing.Point(128, 79)
        Me.lblNoUser.Name = "lblNoUser"
        Me.lblNoUser.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblNoUser.R_ResourceId = Nothing
        Me.lblNoUser.Size = New System.Drawing.Size(100, 18)
        Me.lblNoUser.TabIndex = 5
        Me.lblNoUser.Text = "R_RadLabel13"
        '
        'bsDetail
        '
        Me.bsDetail.DataSource = GetType(SAM01000Front.SAM01000ServiceRef.LicenseDTO)
        '
        'lblLicenseMode
        '
        Me.lblLicenseMode.AutoSize = False
        Me.lblLicenseMode.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_CLICENSE_MODE", True))
        Me.lblLicenseMode.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblLicenseMode.Location = New System.Drawing.Point(128, 55)
        Me.lblLicenseMode.Name = "lblLicenseMode"
        Me.lblLicenseMode.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblLicenseMode.R_ResourceId = Nothing
        Me.lblLicenseMode.Size = New System.Drawing.Size(100, 18)
        Me.lblLicenseMode.TabIndex = 4
        Me.lblLicenseMode.Text = "R_RadLabel12"
        '
        'R_RadLabel4
        '
        Me.R_RadLabel4.AutoSize = False
        Me.R_RadLabel4.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel4.Location = New System.Drawing.Point(22, 79)
        Me.R_RadLabel4.Name = "R_RadLabel4"
        Me.R_RadLabel4.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel4.R_ResourceId = "_NoUser"
        Me.R_RadLabel4.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel4.TabIndex = 3
        Me.R_RadLabel4.Text = "R_RadLabel4"
        '
        'R_RadLabel3
        '
        Me.R_RadLabel3.AutoSize = False
        Me.R_RadLabel3.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel3.Location = New System.Drawing.Point(22, 55)
        Me.R_RadLabel3.Name = "R_RadLabel3"
        Me.R_RadLabel3.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel3.R_ResourceId = "_LicenseMode"
        Me.R_RadLabel3.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel3.TabIndex = 2
        Me.R_RadLabel3.Text = "R_RadLabel3"
        '
        'lblCompId
        '
        Me.lblCompId.AutoSize = False
        Me.lblCompId.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_CCOMPANY_ID", True))
        Me.lblCompId.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCompId.Location = New System.Drawing.Point(128, 31)
        Me.lblCompId.Name = "lblCompId"
        Me.lblCompId.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCompId.R_ResourceId = Nothing
        Me.lblCompId.Size = New System.Drawing.Size(100, 18)
        Me.lblCompId.TabIndex = 1
        Me.lblCompId.Text = "R_RadLabel2"
        '
        'R_RadLabel1
        '
        Me.R_RadLabel1.AutoSize = False
        Me.R_RadLabel1.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel1.Location = New System.Drawing.Point(22, 31)
        Me.R_RadLabel1.Name = "R_RadLabel1"
        Me.R_RadLabel1.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel1.R_ResourceId = "_Company2"
        Me.R_RadLabel1.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel1.TabIndex = 0
        Me.R_RadLabel1.Text = "R_RadLabel1"
        '
        'R_RadGroupBox2
        '
        Me.R_RadGroupBox2.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping
        Me.R_RadGroupBox2.Controls.Add(Me.R_RadLabel8)
        Me.R_RadGroupBox2.Controls.Add(Me.R_RadLabel2)
        Me.R_RadGroupBox2.Controls.Add(Me.lblWarning)
        Me.R_RadGroupBox2.Controls.Add(Me.lblGrace)
        Me.R_RadGroupBox2.Controls.Add(Me.lblTo)
        Me.R_RadGroupBox2.Controls.Add(Me.lblFrom)
        Me.R_RadGroupBox2.Controls.Add(Me.R_RadLabel7)
        Me.R_RadGroupBox2.Controls.Add(Me.R_RadLabel6)
        Me.R_RadGroupBox2.Controls.Add(Me.R_RadLabel5)
        Me.R_RadGroupBox2.Font = New System.Drawing.Font("Calibri", 15.0!)
        Me.R_RadGroupBox2.HeaderText = "R_RadGroupBox2"
        Me.R_RadGroupBox2.Location = New System.Drawing.Point(13, 140)
        Me.R_RadGroupBox2.Name = "R_RadGroupBox2"
        Me.R_RadGroupBox2.R_ConductorGridSource = Nothing
        Me.R_RadGroupBox2.R_ConductorSource = Nothing
        Me.R_RadGroupBox2.R_ResourceId = "_ActivationInfo"
        Me.R_RadGroupBox2.Size = New System.Drawing.Size(323, 108)
        Me.R_RadGroupBox2.TabIndex = 1
        Me.R_RadGroupBox2.Text = "R_RadGroupBox2"
        '
        'lblWarning
        '
        Me.lblWarning.AutoSize = False
        Me.lblWarning.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_NWARNING_DAYS", True))
        Me.lblWarning.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblWarning.Location = New System.Drawing.Point(128, 82)
        Me.lblWarning.Name = "lblWarning"
        Me.lblWarning.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblWarning.R_ResourceId = Nothing
        Me.lblWarning.Size = New System.Drawing.Size(43, 18)
        Me.lblWarning.TabIndex = 7
        Me.lblWarning.Text = "R_RadLabel11"
        '
        'lblGrace
        '
        Me.lblGrace.AutoSize = False
        Me.lblGrace.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_NGRACE_DAYS", True))
        Me.lblGrace.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblGrace.Location = New System.Drawing.Point(128, 58)
        Me.lblGrace.Name = "lblGrace"
        Me.lblGrace.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblGrace.R_ResourceId = Nothing
        Me.lblGrace.Size = New System.Drawing.Size(43, 18)
        Me.lblGrace.TabIndex = 6
        Me.lblGrace.Text = "R_RadLabel10"
        '
        'lblTo
        '
        Me.lblTo.AutoSize = False
        Me.lblTo.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblTo.Location = New System.Drawing.Point(223, 34)
        Me.lblTo.Name = "lblTo"
        Me.lblTo.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblTo.R_ResourceId = Nothing
        Me.lblTo.Size = New System.Drawing.Size(94, 18)
        Me.lblTo.TabIndex = 5
        Me.lblTo.Text = "R_RadLabel9"
        '
        'lblFrom
        '
        Me.lblFrom.AutoSize = False
        Me.lblFrom.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblFrom.Location = New System.Drawing.Point(128, 34)
        Me.lblFrom.Name = "lblFrom"
        Me.lblFrom.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblFrom.R_ResourceId = Nothing
        Me.lblFrom.Size = New System.Drawing.Size(89, 18)
        Me.lblFrom.TabIndex = 4
        Me.lblFrom.Text = "R_RadLabel8"
        '
        'R_RadLabel7
        '
        Me.R_RadLabel7.AutoSize = False
        Me.R_RadLabel7.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel7.Location = New System.Drawing.Point(22, 82)
        Me.R_RadLabel7.Name = "R_RadLabel7"
        Me.R_RadLabel7.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel7.R_ResourceId = "_Warning"
        Me.R_RadLabel7.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel7.TabIndex = 3
        Me.R_RadLabel7.Text = "R_RadLabel7"
        '
        'R_RadLabel6
        '
        Me.R_RadLabel6.AutoSize = False
        Me.R_RadLabel6.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel6.Location = New System.Drawing.Point(22, 58)
        Me.R_RadLabel6.Name = "R_RadLabel6"
        Me.R_RadLabel6.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel6.R_ResourceId = "_Grace"
        Me.R_RadLabel6.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel6.TabIndex = 2
        Me.R_RadLabel6.Text = "R_RadLabel6"
        '
        'R_RadLabel5
        '
        Me.R_RadLabel5.AutoSize = False
        Me.R_RadLabel5.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel5.Location = New System.Drawing.Point(22, 34)
        Me.R_RadLabel5.Name = "R_RadLabel5"
        Me.R_RadLabel5.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel5.R_ResourceId = "_ActivationDate"
        Me.R_RadLabel5.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel5.TabIndex = 1
        Me.R_RadLabel5.Text = "R_RadLabel5"
        '
        'btnRtnPopup
        '
        Me.btnRtnPopup.Location = New System.Drawing.Point(174, 254)
        Me.btnRtnPopup.Name = "btnRtnPopup"
        Me.btnRtnPopup.Size = New System.Drawing.Size(162, 31)
        Me.btnRtnPopup.TabIndex = 2
        '
        'conDetail
        '
        Me.conDetail.R_BindingSource = Me.bsDetail
        Me.conDetail.R_ConductorParent = Nothing
        Me.conDetail.R_IsHeader = True
        Me.conDetail.R_RadGroupBox = Nothing
        '
        'R_RadLabel2
        '
        Me.R_RadLabel2.AutoSize = False
        Me.R_RadLabel2.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel2.Location = New System.Drawing.Point(177, 58)
        Me.R_RadLabel2.Name = "R_RadLabel2"
        Me.R_RadLabel2.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel2.R_ResourceId = "_Day"
        Me.R_RadLabel2.Size = New System.Drawing.Size(94, 18)
        Me.R_RadLabel2.TabIndex = 8
        Me.R_RadLabel2.Text = "R_RadLabel9"
        '
        'R_RadLabel8
        '
        Me.R_RadLabel8.AutoSize = False
        Me.R_RadLabel8.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel8.Location = New System.Drawing.Point(177, 82)
        Me.R_RadLabel8.Name = "R_RadLabel8"
        Me.R_RadLabel8.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel8.R_ResourceId = "_Day"
        Me.R_RadLabel8.Size = New System.Drawing.Size(94, 18)
        Me.R_RadLabel8.TabIndex = 9
        Me.R_RadLabel8.Text = "R_RadLabel9"
        '
        'LicenseAndActivation
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(342, 286)
        Me.Controls.Add(Me.btnRtnPopup)
        Me.Controls.Add(Me.R_RadGroupBox2)
        Me.Controls.Add(Me.R_RadGroupBox1)
        Me.Name = "LicenseAndActivation"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "License And Activation"
        CType(Me.R_RadGroupBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.R_RadGroupBox1.ResumeLayout(False)
        CType(Me.lblNoUser, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsDetail, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblLicenseMode, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCompId, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadGroupBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.R_RadGroupBox2.ResumeLayout(False)
        CType(Me.lblWarning, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblGrace, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblTo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblFrom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conDetail, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents R_RadGridView1 As R_FrontEnd.R_RadGridView
    Friend WithEvents R_RadGroupBox1 As R_FrontEnd.R_RadGroupBox
    Friend WithEvents R_RadGroupBox2 As R_FrontEnd.R_RadGroupBox
    Friend WithEvents btnRtnPopup As R_FrontEnd.R_ReturnPopUp
    Friend WithEvents R_RadLabel4 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel3 As R_FrontEnd.R_RadLabel
    Friend WithEvents lblCompId As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel1 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel7 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel6 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel5 As R_FrontEnd.R_RadLabel
    Friend WithEvents lblTo As R_FrontEnd.R_RadLabel
    Friend WithEvents lblFrom As R_FrontEnd.R_RadLabel
    Friend WithEvents lblWarning As R_FrontEnd.R_RadLabel
    Friend WithEvents lblGrace As R_FrontEnd.R_RadLabel
    Friend WithEvents lblNoUser As R_FrontEnd.R_RadLabel
    Friend WithEvents lblLicenseMode As R_FrontEnd.R_RadLabel
    Friend WithEvents bsDetail As System.Windows.Forms.BindingSource
    Friend WithEvents conDetail As R_FrontEnd.R_Conductor
    Friend WithEvents R_RadLabel2 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel8 As R_FrontEnd.R_RadLabel

End Class
