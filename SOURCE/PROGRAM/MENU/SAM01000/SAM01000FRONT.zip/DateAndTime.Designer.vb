﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DateAndTime
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.R_RadGroupBox1 = New R_FrontEnd.R_RadGroupBox(Me.components)
        Me.lblLongDate = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblShortDate = New R_FrontEnd.R_RadLabel(Me.components)
        Me.cmbLongDate = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsDetail = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsLongDate = New System.Windows.Forms.BindingSource(Me.components)
        Me.R_RadLabel4 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.cmbShortDate = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsShortDate = New System.Windows.Forms.BindingSource(Me.components)
        Me.R_RadLabel2 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel1 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.cmbLongTime = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsLongTime = New System.Windows.Forms.BindingSource(Me.components)
        Me.cmbShortTime = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsShortTime = New System.Windows.Forms.BindingSource(Me.components)
        Me.R_RadGroupBox2 = New R_FrontEnd.R_RadGroupBox(Me.components)
        Me.lblLongTime = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblShortTime = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel7 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel9 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel10 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.rtnPopup = New R_FrontEnd.R_ReturnPopUp()
        Me.pageView = New R_FrontEnd.R_RadPageView(Me.components)
        Me.pageViewDate = New Telerik.WinControls.UI.RadPageViewPage()
        Me.pageViewTime = New Telerik.WinControls.UI.RadPageViewPage()
        Me.pageViewNumber = New Telerik.WinControls.UI.RadPageViewPage()
        Me.R_RadGroupBox3 = New R_FrontEnd.R_RadGroupBox(Me.components)
        Me.cmbRoundingMethod = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsRoundingMethod = New System.Windows.Forms.BindingSource(Me.components)
        Me.spinRoundingPlaces = New R_FrontEnd.R_RadSpinEditor(Me.components)
        Me.R_RadLabel13 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel12 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.spinDecimalPlaces = New R_FrontEnd.R_RadSpinEditor(Me.components)
        Me.R_RadLabel11 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtGroupingSymbol = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.cmbNumberFormat = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsNumberFormat = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblNumberFormat = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel6 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel5 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel3 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.pageViewReportLang = New Telerik.WinControls.UI.RadPageViewPage()
        Me.R_RadGroupBox4 = New R_FrontEnd.R_RadGroupBox(Me.components)
        Me.cmbReportLang = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsReportLang = New System.Windows.Forms.BindingSource(Me.components)
        Me.R_RadLabel8 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.pageViewSettings = New Telerik.WinControls.UI.RadPageViewPage()
        Me.cmbEnableSaveConfirm = New R_FrontEnd.R_RadCheckBox(Me.components)
        CType(Me.R_RadGroupBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.R_RadGroupBox1.SuspendLayout()
        CType(Me.lblLongDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblShortDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbLongDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsDetail, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsLongDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbShortDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsShortDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbLongTime, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsLongTime, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbShortTime, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsShortTime, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadGroupBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.R_RadGroupBox2.SuspendLayout()
        CType(Me.lblLongTime, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblShortTime, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pageView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pageView.SuspendLayout()
        Me.pageViewDate.SuspendLayout()
        Me.pageViewTime.SuspendLayout()
        Me.pageViewNumber.SuspendLayout()
        CType(Me.R_RadGroupBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.R_RadGroupBox3.SuspendLayout()
        CType(Me.cmbRoundingMethod, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsRoundingMethod, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spinRoundingPlaces, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spinDecimalPlaces, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtGroupingSymbol, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbNumberFormat, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsNumberFormat, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblNumberFormat, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pageViewReportLang.SuspendLayout()
        CType(Me.R_RadGroupBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.R_RadGroupBox4.SuspendLayout()
        CType(Me.cmbReportLang, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsReportLang, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pageViewSettings.SuspendLayout()
        CType(Me.cmbEnableSaveConfirm, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'R_RadGroupBox1
        '
        Me.R_RadGroupBox1.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping
        Me.R_RadGroupBox1.Controls.Add(Me.lblLongDate)
        Me.R_RadGroupBox1.Controls.Add(Me.lblShortDate)
        Me.R_RadGroupBox1.Controls.Add(Me.cmbLongDate)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel4)
        Me.R_RadGroupBox1.Controls.Add(Me.cmbShortDate)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel2)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel1)
        Me.R_RadGroupBox1.Font = New System.Drawing.Font("Calibri", 15.0!)
        Me.R_RadGroupBox1.HeaderText = "Date Format"
        Me.R_RadGroupBox1.Location = New System.Drawing.Point(3, 14)
        Me.R_RadGroupBox1.Name = "R_RadGroupBox1"
        Me.R_RadGroupBox1.R_ConductorGridSource = Nothing
        Me.R_RadGroupBox1.R_ConductorSource = Nothing
        Me.R_RadGroupBox1.R_ResourceId = "_DateFormat"
        Me.R_RadGroupBox1.Size = New System.Drawing.Size(299, 184)
        Me.R_RadGroupBox1.TabIndex = 0
        Me.R_RadGroupBox1.Text = "Date Format"
        '
        'lblLongDate
        '
        Me.lblLongDate.AutoSize = False
        Me.lblLongDate.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblLongDate.Location = New System.Drawing.Point(36, 161)
        Me.lblLongDate.Name = "lblLongDate"
        Me.lblLongDate.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblLongDate.R_ResourceId = Nothing
        Me.lblLongDate.Size = New System.Drawing.Size(187, 18)
        Me.lblLongDate.TabIndex = 5
        Me.lblLongDate.Text = "R_RadLabel6"
        '
        'lblShortDate
        '
        Me.lblShortDate.AutoSize = False
        Me.lblShortDate.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblShortDate.Location = New System.Drawing.Point(36, 137)
        Me.lblShortDate.Name = "lblShortDate"
        Me.lblShortDate.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblShortDate.R_ResourceId = Nothing
        Me.lblShortDate.Size = New System.Drawing.Size(187, 18)
        Me.lblShortDate.TabIndex = 4
        Me.lblShortDate.Text = "R_RadLabel5"
        '
        'cmbLongDate
        '
        Me.cmbLongDate.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.bsDetail, "_CDATE_LONG_FORMAT", True))
        Me.cmbLongDate.DataSource = Me.bsLongDate
        Me.cmbLongDate.DisplayMember = "cFormat"
        Me.cmbLongDate.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cmbLongDate.Location = New System.Drawing.Point(92, 55)
        Me.cmbLongDate.Name = "cmbLongDate"
        Me.cmbLongDate.R_ConductorGridSource = Nothing
        Me.cmbLongDate.R_ConductorSource = Nothing
        Me.cmbLongDate.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cmbLongDate.Size = New System.Drawing.Size(192, 20)
        Me.cmbLongDate.TabIndex = 60
        Me.cmbLongDate.ValueMember = "cFormat"
        '
        'bsDetail
        '
        Me.bsDetail.DataSource = GetType(SAM01000Front.SAM01000ServiceRef.SAM01000DTO)
        '
        'bsLongDate
        '
        Me.bsLongDate.DataSource = GetType(SAM01000Front.FormatDTO)
        '
        'R_RadLabel4
        '
        Me.R_RadLabel4.AutoSize = False
        Me.R_RadLabel4.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel4.Location = New System.Drawing.Point(36, 109)
        Me.R_RadLabel4.Name = "R_RadLabel4"
        Me.R_RadLabel4.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel4.R_ResourceId = "_Example"
        Me.R_RadLabel4.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel4.TabIndex = 3
        Me.R_RadLabel4.Text = "R_RadLabel4"
        '
        'cmbShortDate
        '
        Me.cmbShortDate.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.bsDetail, "_CDATE_SHORT_FORMAT", True))
        Me.cmbShortDate.DataSource = Me.bsShortDate
        Me.cmbShortDate.DisplayMember = "cFormat"
        Me.cmbShortDate.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cmbShortDate.Location = New System.Drawing.Point(92, 31)
        Me.cmbShortDate.Name = "cmbShortDate"
        Me.cmbShortDate.R_ConductorGridSource = Nothing
        Me.cmbShortDate.R_ConductorSource = Nothing
        Me.cmbShortDate.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cmbShortDate.Size = New System.Drawing.Size(192, 20)
        Me.cmbShortDate.TabIndex = 59
        Me.cmbShortDate.ValueMember = "cFormat"
        '
        'bsShortDate
        '
        Me.bsShortDate.DataSource = GetType(SAM01000Front.FormatDTO)
        '
        'R_RadLabel2
        '
        Me.R_RadLabel2.AutoSize = False
        Me.R_RadLabel2.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel2.Location = New System.Drawing.Point(8, 55)
        Me.R_RadLabel2.Name = "R_RadLabel2"
        Me.R_RadLabel2.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel2.R_ResourceId = "_LongDate"
        Me.R_RadLabel2.Size = New System.Drawing.Size(78, 18)
        Me.R_RadLabel2.TabIndex = 1
        Me.R_RadLabel2.Text = "Long Date"
        '
        'R_RadLabel1
        '
        Me.R_RadLabel1.AutoSize = False
        Me.R_RadLabel1.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel1.Location = New System.Drawing.Point(8, 31)
        Me.R_RadLabel1.Name = "R_RadLabel1"
        Me.R_RadLabel1.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel1.R_ResourceId = "_ShortDate"
        Me.R_RadLabel1.Size = New System.Drawing.Size(78, 18)
        Me.R_RadLabel1.TabIndex = 0
        Me.R_RadLabel1.Text = "Short Date"
        '
        'cmbLongTime
        '
        Me.cmbLongTime.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.bsDetail, "_CTIME_LONG_FORMAT", True))
        Me.cmbLongTime.DataSource = Me.bsLongTime
        Me.cmbLongTime.DisplayMember = "cFormat"
        Me.cmbLongTime.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cmbLongTime.Location = New System.Drawing.Point(92, 56)
        Me.cmbLongTime.Name = "cmbLongTime"
        Me.cmbLongTime.R_ConductorGridSource = Nothing
        Me.cmbLongTime.R_ConductorSource = Nothing
        Me.cmbLongTime.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cmbLongTime.Size = New System.Drawing.Size(192, 20)
        Me.cmbLongTime.TabIndex = 62
        Me.cmbLongTime.ValueMember = "cFormat"
        '
        'bsLongTime
        '
        Me.bsLongTime.DataSource = GetType(SAM01000Front.FormatDTO)
        '
        'cmbShortTime
        '
        Me.cmbShortTime.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.bsDetail, "_CTIME_SHORT_FORMAT", True))
        Me.cmbShortTime.DataSource = Me.bsShortTime
        Me.cmbShortTime.DisplayMember = "cFormat"
        Me.cmbShortTime.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cmbShortTime.Location = New System.Drawing.Point(92, 33)
        Me.cmbShortTime.Name = "cmbShortTime"
        Me.cmbShortTime.R_ConductorGridSource = Nothing
        Me.cmbShortTime.R_ConductorSource = Nothing
        Me.cmbShortTime.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cmbShortTime.Size = New System.Drawing.Size(192, 20)
        Me.cmbShortTime.TabIndex = 61
        Me.cmbShortTime.ValueMember = "cFormat"
        '
        'bsShortTime
        '
        Me.bsShortTime.DataSource = GetType(SAM01000Front.FormatDTO)
        '
        'R_RadGroupBox2
        '
        Me.R_RadGroupBox2.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping
        Me.R_RadGroupBox2.Controls.Add(Me.lblLongTime)
        Me.R_RadGroupBox2.Controls.Add(Me.cmbLongTime)
        Me.R_RadGroupBox2.Controls.Add(Me.lblShortTime)
        Me.R_RadGroupBox2.Controls.Add(Me.cmbShortTime)
        Me.R_RadGroupBox2.Controls.Add(Me.R_RadLabel7)
        Me.R_RadGroupBox2.Controls.Add(Me.R_RadLabel9)
        Me.R_RadGroupBox2.Controls.Add(Me.R_RadLabel10)
        Me.R_RadGroupBox2.Font = New System.Drawing.Font("Calibri", 15.0!)
        Me.R_RadGroupBox2.HeaderText = "Time Format"
        Me.R_RadGroupBox2.Location = New System.Drawing.Point(3, 13)
        Me.R_RadGroupBox2.Name = "R_RadGroupBox2"
        Me.R_RadGroupBox2.R_ConductorGridSource = Nothing
        Me.R_RadGroupBox2.R_ConductorSource = Nothing
        Me.R_RadGroupBox2.R_ResourceId = "_TimeFormat"
        Me.R_RadGroupBox2.Size = New System.Drawing.Size(299, 185)
        Me.R_RadGroupBox2.TabIndex = 63
        Me.R_RadGroupBox2.Text = "Time Format"
        '
        'lblLongTime
        '
        Me.lblLongTime.AutoSize = False
        Me.lblLongTime.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblLongTime.Location = New System.Drawing.Point(37, 162)
        Me.lblLongTime.Name = "lblLongTime"
        Me.lblLongTime.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblLongTime.R_ResourceId = Nothing
        Me.lblLongTime.Size = New System.Drawing.Size(100, 18)
        Me.lblLongTime.TabIndex = 5
        Me.lblLongTime.Text = "R_RadLabel6"
        '
        'lblShortTime
        '
        Me.lblShortTime.AutoSize = False
        Me.lblShortTime.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblShortTime.Location = New System.Drawing.Point(37, 138)
        Me.lblShortTime.Name = "lblShortTime"
        Me.lblShortTime.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblShortTime.R_ResourceId = Nothing
        Me.lblShortTime.Size = New System.Drawing.Size(100, 18)
        Me.lblShortTime.TabIndex = 4
        Me.lblShortTime.Text = "R_RadLabel5"
        '
        'R_RadLabel7
        '
        Me.R_RadLabel7.AutoSize = False
        Me.R_RadLabel7.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel7.Location = New System.Drawing.Point(37, 110)
        Me.R_RadLabel7.Name = "R_RadLabel7"
        Me.R_RadLabel7.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel7.R_ResourceId = "_Example"
        Me.R_RadLabel7.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel7.TabIndex = 3
        Me.R_RadLabel7.Text = "R_RadLabel7"
        '
        'R_RadLabel9
        '
        Me.R_RadLabel9.AutoSize = False
        Me.R_RadLabel9.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel9.Location = New System.Drawing.Point(8, 57)
        Me.R_RadLabel9.Name = "R_RadLabel9"
        Me.R_RadLabel9.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel9.R_ResourceId = "_LongTime"
        Me.R_RadLabel9.Size = New System.Drawing.Size(78, 18)
        Me.R_RadLabel9.TabIndex = 1
        Me.R_RadLabel9.Text = "Long Time"
        '
        'R_RadLabel10
        '
        Me.R_RadLabel10.AutoSize = False
        Me.R_RadLabel10.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel10.Location = New System.Drawing.Point(8, 33)
        Me.R_RadLabel10.Name = "R_RadLabel10"
        Me.R_RadLabel10.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel10.R_ResourceId = "_ShortTime"
        Me.R_RadLabel10.Size = New System.Drawing.Size(78, 18)
        Me.R_RadLabel10.TabIndex = 0
        Me.R_RadLabel10.Text = "Short Time"
        '
        'rtnPopup
        '
        Me.rtnPopup.Location = New System.Drawing.Point(171, 263)
        Me.rtnPopup.Name = "rtnPopup"
        Me.rtnPopup.Size = New System.Drawing.Size(162, 31)
        Me.rtnPopup.TabIndex = 64
        '
        'pageView
        '
        Me.pageView.Controls.Add(Me.pageViewDate)
        Me.pageView.Controls.Add(Me.pageViewTime)
        Me.pageView.Controls.Add(Me.pageViewNumber)
        Me.pageView.Controls.Add(Me.pageViewReportLang)
        Me.pageView.Controls.Add(Me.pageViewSettings)
        Me.pageView.Location = New System.Drawing.Point(12, 12)
        Me.pageView.Name = "pageView"
        Me.pageView.R_ConductorGridSource = Nothing
        Me.pageView.R_ConductorSource = Nothing
        Me.pageView.SelectedPage = Me.pageViewNumber
        Me.pageView.Size = New System.Drawing.Size(332, 245)
        Me.pageView.TabIndex = 65
        Me.pageView.Text = "R_RadPageView1"
        '
        'pageViewDate
        '
        Me.pageViewDate.Controls.Add(Me.R_RadGroupBox1)
        Me.pageViewDate.ItemSize = New System.Drawing.SizeF(115.0!, 28.0!)
        Me.pageViewDate.Location = New System.Drawing.Point(10, 37)
        Me.pageViewDate.Name = "pageViewDate"
        Me.pageViewDate.Size = New System.Drawing.Size(311, 197)
        Me.pageViewDate.Text = "RadPageViewPage1"
        '
        'pageViewTime
        '
        Me.pageViewTime.Controls.Add(Me.R_RadGroupBox2)
        Me.pageViewTime.ItemSize = New System.Drawing.SizeF(115.0!, 28.0!)
        Me.pageViewTime.Location = New System.Drawing.Point(10, 37)
        Me.pageViewTime.Name = "pageViewTime"
        Me.pageViewTime.Size = New System.Drawing.Size(311, 197)
        Me.pageViewTime.Text = "RadPageViewPage2"
        '
        'pageViewNumber
        '
        Me.pageViewNumber.Controls.Add(Me.R_RadGroupBox3)
        Me.pageViewNumber.ItemSize = New System.Drawing.SizeF(115.0!, 28.0!)
        Me.pageViewNumber.Location = New System.Drawing.Point(10, 37)
        Me.pageViewNumber.Name = "pageViewNumber"
        Me.pageViewNumber.Size = New System.Drawing.Size(311, 197)
        Me.pageViewNumber.Text = "RadPageViewPage1"
        '
        'R_RadGroupBox3
        '
        Me.R_RadGroupBox3.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping
        Me.R_RadGroupBox3.Controls.Add(Me.cmbRoundingMethod)
        Me.R_RadGroupBox3.Controls.Add(Me.spinRoundingPlaces)
        Me.R_RadGroupBox3.Controls.Add(Me.R_RadLabel13)
        Me.R_RadGroupBox3.Controls.Add(Me.R_RadLabel12)
        Me.R_RadGroupBox3.Controls.Add(Me.spinDecimalPlaces)
        Me.R_RadGroupBox3.Controls.Add(Me.R_RadLabel11)
        Me.R_RadGroupBox3.Controls.Add(Me.txtGroupingSymbol)
        Me.R_RadGroupBox3.Controls.Add(Me.cmbNumberFormat)
        Me.R_RadGroupBox3.Controls.Add(Me.lblNumberFormat)
        Me.R_RadGroupBox3.Controls.Add(Me.R_RadLabel6)
        Me.R_RadGroupBox3.Controls.Add(Me.R_RadLabel5)
        Me.R_RadGroupBox3.Controls.Add(Me.R_RadLabel3)
        Me.R_RadGroupBox3.HeaderText = "R_RadGroupBox3"
        Me.R_RadGroupBox3.Location = New System.Drawing.Point(4, 13)
        Me.R_RadGroupBox3.Name = "R_RadGroupBox3"
        Me.R_RadGroupBox3.R_ConductorGridSource = Nothing
        Me.R_RadGroupBox3.R_ConductorSource = Nothing
        Me.R_RadGroupBox3.R_ResourceId = "_NumberFormat"
        Me.R_RadGroupBox3.Size = New System.Drawing.Size(304, 185)
        Me.R_RadGroupBox3.TabIndex = 0
        Me.R_RadGroupBox3.Text = "R_RadGroupBox3"
        '
        'cmbRoundingMethod
        '
        Me.cmbRoundingMethod.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.bsDetail, "_CROUNDING_METHOD", True))
        Me.cmbRoundingMethod.DataSource = Me.bsRoundingMethod
        Me.cmbRoundingMethod.DisplayMember = "cFormat"
        Me.cmbRoundingMethod.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cmbRoundingMethod.Location = New System.Drawing.Point(145, 126)
        Me.cmbRoundingMethod.Name = "cmbRoundingMethod"
        Me.cmbRoundingMethod.R_ConductorGridSource = Nothing
        Me.cmbRoundingMethod.R_ConductorSource = Nothing
        Me.cmbRoundingMethod.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cmbRoundingMethod.Size = New System.Drawing.Size(143, 20)
        Me.cmbRoundingMethod.TabIndex = 11
        Me.cmbRoundingMethod.ValueMember = "cFormat"
        '
        'bsRoundingMethod
        '
        Me.bsRoundingMethod.DataSource = GetType(SAM01000Front.FormatDTO)
        '
        'spinRoundingPlaces
        '
        Me.spinRoundingPlaces.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.bsDetail, "_IROUNDING_PLACES", True))
        Me.spinRoundingPlaces.Location = New System.Drawing.Point(145, 101)
        Me.spinRoundingPlaces.Maximum = New Decimal(New Integer() {2, 0, 0, 0})
        Me.spinRoundingPlaces.Name = "spinRoundingPlaces"
        Me.spinRoundingPlaces.R_ConductorGridSource = Nothing
        Me.spinRoundingPlaces.R_ConductorSource = Nothing
        Me.spinRoundingPlaces.Size = New System.Drawing.Size(143, 20)
        Me.spinRoundingPlaces.TabIndex = 10
        Me.spinRoundingPlaces.TabStop = False
        Me.spinRoundingPlaces.ThousandsSeparator = True
        '
        'R_RadLabel13
        '
        Me.R_RadLabel13.AutoSize = False
        Me.R_RadLabel13.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel13.Location = New System.Drawing.Point(16, 126)
        Me.R_RadLabel13.Name = "R_RadLabel13"
        Me.R_RadLabel13.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel13.R_ResourceId = "_RoundingMethod"
        Me.R_RadLabel13.Size = New System.Drawing.Size(120, 18)
        Me.R_RadLabel13.TabIndex = 9
        Me.R_RadLabel13.Text = "R_RadLabel13"
        '
        'R_RadLabel12
        '
        Me.R_RadLabel12.AutoSize = False
        Me.R_RadLabel12.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel12.Location = New System.Drawing.Point(16, 102)
        Me.R_RadLabel12.Name = "R_RadLabel12"
        Me.R_RadLabel12.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel12.R_ResourceId = "_RoundingPlaces"
        Me.R_RadLabel12.Size = New System.Drawing.Size(120, 18)
        Me.R_RadLabel12.TabIndex = 8
        Me.R_RadLabel12.Text = "R_RadLabel12"
        '
        'spinDecimalPlaces
        '
        Me.spinDecimalPlaces.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.bsDetail, "_IDECIMAL_PLACES", True))
        Me.spinDecimalPlaces.Location = New System.Drawing.Point(145, 77)
        Me.spinDecimalPlaces.Maximum = New Decimal(New Integer() {2, 0, 0, 0})
        Me.spinDecimalPlaces.Name = "spinDecimalPlaces"
        Me.spinDecimalPlaces.R_ConductorGridSource = Nothing
        Me.spinDecimalPlaces.R_ConductorSource = Nothing
        Me.spinDecimalPlaces.Size = New System.Drawing.Size(143, 20)
        Me.spinDecimalPlaces.TabIndex = 7
        Me.spinDecimalPlaces.TabStop = False
        Me.spinDecimalPlaces.ThousandsSeparator = True
        '
        'R_RadLabel11
        '
        Me.R_RadLabel11.AutoSize = False
        Me.R_RadLabel11.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel11.Location = New System.Drawing.Point(16, 78)
        Me.R_RadLabel11.Name = "R_RadLabel11"
        Me.R_RadLabel11.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel11.R_ResourceId = "_DecimalPlaces"
        Me.R_RadLabel11.Size = New System.Drawing.Size(120, 18)
        Me.R_RadLabel11.TabIndex = 6
        Me.R_RadLabel11.Text = "R_RadLabel11"
        '
        'txtGroupingSymbol
        '
        Me.txtGroupingSymbol.Location = New System.Drawing.Point(145, 53)
        Me.txtGroupingSymbol.Name = "txtGroupingSymbol"
        Me.txtGroupingSymbol.R_ConductorGridSource = Nothing
        Me.txtGroupingSymbol.R_ConductorSource = Nothing
        Me.txtGroupingSymbol.R_UDT = Nothing
        Me.txtGroupingSymbol.ReadOnly = True
        Me.txtGroupingSymbol.Size = New System.Drawing.Size(143, 20)
        Me.txtGroupingSymbol.TabIndex = 5
        Me.txtGroupingSymbol.TabStop = False
        '
        'cmbNumberFormat
        '
        Me.cmbNumberFormat.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.bsDetail, "_CNUMBER_FORMAT", True))
        Me.cmbNumberFormat.DataSource = Me.bsNumberFormat
        Me.cmbNumberFormat.DisplayMember = "cFormat"
        Me.cmbNumberFormat.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cmbNumberFormat.Location = New System.Drawing.Point(145, 30)
        Me.cmbNumberFormat.Name = "cmbNumberFormat"
        Me.cmbNumberFormat.R_ConductorGridSource = Nothing
        Me.cmbNumberFormat.R_ConductorSource = Nothing
        Me.cmbNumberFormat.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cmbNumberFormat.Size = New System.Drawing.Size(143, 20)
        Me.cmbNumberFormat.TabIndex = 4
        Me.cmbNumberFormat.ValueMember = "cFormat"
        '
        'bsNumberFormat
        '
        Me.bsNumberFormat.DataSource = GetType(SAM01000Front.FormatDTO)
        '
        'lblNumberFormat
        '
        Me.lblNumberFormat.AutoSize = False
        Me.lblNumberFormat.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblNumberFormat.Location = New System.Drawing.Point(145, 162)
        Me.lblNumberFormat.Name = "lblNumberFormat"
        Me.lblNumberFormat.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblNumberFormat.R_ResourceId = Nothing
        Me.lblNumberFormat.Size = New System.Drawing.Size(100, 18)
        Me.lblNumberFormat.TabIndex = 3
        Me.lblNumberFormat.Text = "R_RadLabel8"
        '
        'R_RadLabel6
        '
        Me.R_RadLabel6.AutoSize = False
        Me.R_RadLabel6.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel6.Location = New System.Drawing.Point(16, 162)
        Me.R_RadLabel6.Name = "R_RadLabel6"
        Me.R_RadLabel6.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel6.R_ResourceId = "_Example"
        Me.R_RadLabel6.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel6.TabIndex = 2
        Me.R_RadLabel6.Text = "R_RadLabel6"
        '
        'R_RadLabel5
        '
        Me.R_RadLabel5.AutoSize = False
        Me.R_RadLabel5.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel5.Location = New System.Drawing.Point(16, 54)
        Me.R_RadLabel5.Name = "R_RadLabel5"
        Me.R_RadLabel5.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel5.R_ResourceId = "_DigitGroupingSymbol"
        Me.R_RadLabel5.Size = New System.Drawing.Size(120, 18)
        Me.R_RadLabel5.TabIndex = 1
        Me.R_RadLabel5.Text = "R_RadLabel5"
        '
        'R_RadLabel3
        '
        Me.R_RadLabel3.AutoSize = False
        Me.R_RadLabel3.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel3.Location = New System.Drawing.Point(16, 30)
        Me.R_RadLabel3.Name = "R_RadLabel3"
        Me.R_RadLabel3.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel3.R_ResourceId = "_DecimalSymbol"
        Me.R_RadLabel3.Size = New System.Drawing.Size(120, 18)
        Me.R_RadLabel3.TabIndex = 0
        Me.R_RadLabel3.Text = "R_RadLabel3"
        '
        'pageViewReportLang
        '
        Me.pageViewReportLang.Controls.Add(Me.R_RadGroupBox4)
        Me.pageViewReportLang.ItemSize = New System.Drawing.SizeF(115.0!, 28.0!)
        Me.pageViewReportLang.Location = New System.Drawing.Point(10, 37)
        Me.pageViewReportLang.Name = "pageViewReportLang"
        Me.pageViewReportLang.Size = New System.Drawing.Size(311, 197)
        Me.pageViewReportLang.Text = "RadPageViewPage1"
        '
        'R_RadGroupBox4
        '
        Me.R_RadGroupBox4.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping
        Me.R_RadGroupBox4.Controls.Add(Me.cmbReportLang)
        Me.R_RadGroupBox4.Controls.Add(Me.R_RadLabel8)
        Me.R_RadGroupBox4.HeaderText = "R_RadGroupBox4"
        Me.R_RadGroupBox4.Location = New System.Drawing.Point(3, 13)
        Me.R_RadGroupBox4.Name = "R_RadGroupBox4"
        Me.R_RadGroupBox4.R_ConductorGridSource = Nothing
        Me.R_RadGroupBox4.R_ConductorSource = Nothing
        Me.R_RadGroupBox4.R_ResourceId = "_ReportLang"
        Me.R_RadGroupBox4.Size = New System.Drawing.Size(304, 161)
        Me.R_RadGroupBox4.TabIndex = 0
        Me.R_RadGroupBox4.Text = "R_RadGroupBox4"
        '
        'cmbReportLang
        '
        Me.cmbReportLang.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.bsDetail, "_CREPORT_CULTURE", True))
        Me.cmbReportLang.DataSource = Me.bsReportLang
        Me.cmbReportLang.DisplayMember = "CDESC"
        Me.cmbReportLang.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cmbReportLang.Location = New System.Drawing.Point(127, 36)
        Me.cmbReportLang.Name = "cmbReportLang"
        Me.cmbReportLang.R_ConductorGridSource = Nothing
        Me.cmbReportLang.R_ConductorSource = Nothing
        Me.cmbReportLang.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cmbReportLang.Size = New System.Drawing.Size(152, 20)
        Me.cmbReportLang.TabIndex = 1
        Me.cmbReportLang.ValueMember = "CCODE"
        '
        'bsReportLang
        '
        Me.bsReportLang.DataSource = GetType(SAM01000Front.CultureDTO)
        '
        'R_RadLabel8
        '
        Me.R_RadLabel8.AutoSize = False
        Me.R_RadLabel8.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel8.Location = New System.Drawing.Point(21, 36)
        Me.R_RadLabel8.Name = "R_RadLabel8"
        Me.R_RadLabel8.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel8.R_ResourceId = "_ReportLang"
        Me.R_RadLabel8.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel8.TabIndex = 0
        Me.R_RadLabel8.Text = "R_RadLabel8"
        '
        'pageViewSettings
        '
        Me.pageViewSettings.Controls.Add(Me.cmbEnableSaveConfirm)
        Me.pageViewSettings.ItemSize = New System.Drawing.SizeF(105.0!, 28.0!)
        Me.pageViewSettings.Location = New System.Drawing.Point(10, 33)
        Me.pageViewSettings.Name = "pageViewSettings"
        Me.pageViewSettings.Size = New System.Drawing.Size(311, 201)
        Me.pageViewSettings.Text = "pageViewSettings"
        '
        'cmbEnableSaveConfirm
        '
        Me.cmbEnableSaveConfirm.DataBindings.Add(New System.Windows.Forms.Binding("IsChecked", Me.bsDetail, "_LENABLE_SAVE_CONFIRMATION", True))
        Me.cmbEnableSaveConfirm.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cmbEnableSaveConfirm.Location = New System.Drawing.Point(26, 20)
        Me.cmbEnableSaveConfirm.Name = "cmbEnableSaveConfirm"
        Me.cmbEnableSaveConfirm.R_ConductorGridSource = Nothing
        Me.cmbEnableSaveConfirm.R_ConductorSource = Nothing
        Me.cmbEnableSaveConfirm.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cmbEnableSaveConfirm.R_ResourceId = "_EnableSaveConfirmation"
        Me.cmbEnableSaveConfirm.Size = New System.Drawing.Size(107, 18)
        Me.cmbEnableSaveConfirm.TabIndex = 0
        Me.cmbEnableSaveConfirm.Text = "R_RadCheckBox1"
        '
        'DateAndTime
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(354, 306)
        Me.Controls.Add(Me.pageView)
        Me.Controls.Add(Me.rtnPopup)
        Me.Name = "DateAndTime"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "Date and Time Setting"
        CType(Me.R_RadGroupBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.R_RadGroupBox1.ResumeLayout(False)
        Me.R_RadGroupBox1.PerformLayout()
        CType(Me.lblLongDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblShortDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbLongDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsDetail, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsLongDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbShortDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsShortDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbLongTime, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsLongTime, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbShortTime, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsShortTime, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadGroupBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.R_RadGroupBox2.ResumeLayout(False)
        Me.R_RadGroupBox2.PerformLayout()
        CType(Me.lblLongTime, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblShortTime, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pageView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pageView.ResumeLayout(False)
        Me.pageViewDate.ResumeLayout(False)
        Me.pageViewTime.ResumeLayout(False)
        Me.pageViewNumber.ResumeLayout(False)
        CType(Me.R_RadGroupBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.R_RadGroupBox3.ResumeLayout(False)
        Me.R_RadGroupBox3.PerformLayout()
        CType(Me.cmbRoundingMethod, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsRoundingMethod, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spinRoundingPlaces, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spinDecimalPlaces, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtGroupingSymbol, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbNumberFormat, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsNumberFormat, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblNumberFormat, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pageViewReportLang.ResumeLayout(False)
        CType(Me.R_RadGroupBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.R_RadGroupBox4.ResumeLayout(False)
        Me.R_RadGroupBox4.PerformLayout()
        CType(Me.cmbReportLang, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsReportLang, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel8, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pageViewSettings.ResumeLayout(False)
        Me.pageViewSettings.PerformLayout()
        CType(Me.cmbEnableSaveConfirm, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents R_RadGroupBox1 As R_FrontEnd.R_RadGroupBox
    Friend WithEvents lblLongDate As R_FrontEnd.R_RadLabel
    Friend WithEvents lblShortDate As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel4 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel2 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel1 As R_FrontEnd.R_RadLabel
    Friend WithEvents bsShortDate As System.Windows.Forms.BindingSource
    Friend WithEvents bsLongDate As System.Windows.Forms.BindingSource
    Friend WithEvents bsShortTime As System.Windows.Forms.BindingSource
    Friend WithEvents bsLongTime As System.Windows.Forms.BindingSource
    Friend WithEvents cmbLongTime As R_FrontEnd.R_RadDropDownList
    Friend WithEvents cmbShortTime As R_FrontEnd.R_RadDropDownList
    Friend WithEvents cmbLongDate As R_FrontEnd.R_RadDropDownList
    Friend WithEvents cmbShortDate As R_FrontEnd.R_RadDropDownList
    Friend WithEvents R_RadGroupBox2 As R_FrontEnd.R_RadGroupBox
    Friend WithEvents lblLongTime As R_FrontEnd.R_RadLabel
    Friend WithEvents lblShortTime As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel7 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel9 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel10 As R_FrontEnd.R_RadLabel
    Friend WithEvents rtnPopup As R_FrontEnd.R_ReturnPopUp
    Friend WithEvents bsDetail As System.Windows.Forms.BindingSource
    Friend WithEvents pageView As R_FrontEnd.R_RadPageView
    Friend WithEvents pageViewDate As Telerik.WinControls.UI.RadPageViewPage
    Friend WithEvents pageViewTime As Telerik.WinControls.UI.RadPageViewPage
    Friend WithEvents pageViewNumber As Telerik.WinControls.UI.RadPageViewPage
    Friend WithEvents R_RadGroupBox3 As R_FrontEnd.R_RadGroupBox
    Friend WithEvents lblNumberFormat As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel6 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel5 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel3 As R_FrontEnd.R_RadLabel
    Friend WithEvents cmbNumberFormat As R_FrontEnd.R_RadDropDownList
    Friend WithEvents txtGroupingSymbol As R_FrontEnd.R_RadTextBox
    Friend WithEvents bsNumberFormat As System.Windows.Forms.BindingSource
    Friend WithEvents pageViewReportLang As Telerik.WinControls.UI.RadPageViewPage
    Friend WithEvents R_RadGroupBox4 As R_FrontEnd.R_RadGroupBox
    Friend WithEvents cmbReportLang As R_FrontEnd.R_RadDropDownList
    Friend WithEvents R_RadLabel8 As R_FrontEnd.R_RadLabel
    Friend WithEvents bsReportLang As System.Windows.Forms.BindingSource
    Friend WithEvents spinDecimalPlaces As R_FrontEnd.R_RadSpinEditor
    Friend WithEvents R_RadLabel11 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel13 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel12 As R_FrontEnd.R_RadLabel
    Friend WithEvents spinRoundingPlaces As R_FrontEnd.R_RadSpinEditor
    Friend WithEvents cmbRoundingMethod As R_FrontEnd.R_RadDropDownList
    Friend WithEvents bsRoundingMethod As System.Windows.Forms.BindingSource
    Friend WithEvents pageViewSettings As Telerik.WinControls.UI.RadPageViewPage
    Friend WithEvents cmbEnableSaveConfirm As R_FrontEnd.R_RadCheckBox

End Class
