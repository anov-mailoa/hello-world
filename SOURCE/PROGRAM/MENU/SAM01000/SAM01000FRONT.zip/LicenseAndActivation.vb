﻿Imports SAM01000Front.SAM01000ServiceRef
Imports R_FrontEnd
Imports R_Common
Imports System.Globalization

Public Class LicenseAndActivation

    Dim C_ServiceName As String = "SAM01000Service/SAM01000Service.svc"

    Private Sub LicenseAndActivation_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        bsDetail.DataSource = loadData(poParameter)

        With CType(bsDetail.Current, LicenseDTO)
            lblFrom.Text = DateTime.ParseExact(._CSTART_DATE.ToString, "yyyyMMdd", CultureInfo.CurrentUICulture)
            lblTo.Text = DateTime.ParseExact(._CEXPIRED_DATE.ToString, "yyyyMMdd", CultureInfo.CurrentUICulture)
        End With
    End Sub

    Private Function loadData(pcCompId As String) As LicenseDTO
        Dim loService As SAM01000ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01000Service, SAM01000ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            Return loService.getLicenseActivation(pcCompId)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Function
End Class
