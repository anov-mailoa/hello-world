﻿Imports R_FrontEnd
Imports SAM01000Front.SAM01000ServiceRef
Imports SAM01000Front.SAM01000StreamingServiceRef
Imports R_Common
Imports System.ServiceModel.Channels
Imports ClientHelper
Imports SAM01000FrontResources
Imports HelperStreamExtensionLibrary

Public Class SAM01000

#Region " VARIABLE "
    Dim C_ServiceName As String = "SAM01000Service/SAM01000Service.svc"
    Dim C_ServiceNameStream As String = "SAM01000Service/SAM01000StreamingService/SAM01000StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Private Const CHUNK_SIZE As Integer = 200 * 1024
#End Region

#Region " INIT "
    Private Sub SAM01000_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim loService As SAM01000ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01000Service, SAM01000ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim oRes As New Resources_Dummy_Class

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            bsCmbLOB.DataSource = loService.getCmbLOB()
            loService.Close()

            gvCompany.R_RefreshGrid(New SAM01000DTO)

            If Not Me.R_Access.Contains("U") Then
                btnUpload.Enabled = False
                btnPopupDateTimeSetting.Enabled = False
            End If

            If U_GlobalVar.LicenseMode <> "CONCURRENT USER" Then
                lblTimeout.Visible = False
                spinTimeout.Visible = False
                lblMinutes.Visible = False
            End If
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
#End Region

    Private Sub gvCompany_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvCompany.R_ServiceGetListRecord
        Dim loServiceStream As SAM01000StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01000StreamingService, SAM01000StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of SAM01000GridDTO)
        Dim loListEntity As New List(Of SAM01000GridDTO)

        Try
            loRtn = loServiceStream.getCompList()
            loStreaming = R_StreamUtility(Of SAM01000GridDTO).ReadFromMessage(loRtn)

            For Each loDto As SAM01000GridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

#Region "CONDUCTOR SECTION"
    Private Sub conDetail_R_ConvertToGridEntity(poEntity As Object, ByRef poGridEntity As Object) Handles conDetail.R_ConvertToGridEntity
        Dim loGridEntity As New SAM01000GridDTO
        With loGridEntity
            .CCOMPANY_ID = CType(poEntity, SAM01000DTO)._CCOMPANY_ID
            .CCOMPANY_NAME = CType(poEntity, SAM01000DTO)._CCOMPANY_NAME
        End With
        poGridEntity = loGridEntity
    End Sub

    Private Sub conDetail_R_Display(poEntity As Object, peMode As R_FrontEnd.R_Conductor.e_Mode) Handles conDetail.R_Display
        If peMode = R_Conductor.e_Mode.NormalMode Then
            With CType(poEntity, SAM01000DTO)
                If String.IsNullOrWhiteSpace(._CLOB_CODE) Then
                    cmbLOB.SelectedIndex = -1
                    txtLOBName.Text = ""
                Else
                    txtLOBName.Text = CType(bsCmbLOB.Current, SAM01000CmbDTO)._CLOB_NAME
                End If
            End With
        End If
    End Sub

    Private Sub conDetail_R_Saving(ByRef poEntity As Object, peMode As R_FrontEnd.R_Conductor.e_Mode) Handles conDetail.R_Saving
        With CType(poEntity, SAM01000DTO)
            ._DDATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            ._CUSER_ID = _CUSERID
        End With
    End Sub

    Private Sub conDetail_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles conDetail.R_ServiceGetRecord
        Dim loService As SAM01000ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01000Service, SAM01000ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New SAM01000DTO With {._CCOMPANY_ID = CType(poEntity, SAM01000GridDTO).CCOMPANY_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub conDetail_R_ServiceSave(poEntity As Object, peMode As R_FrontEnd.R_Conductor.e_Mode, ByRef poEntityResult As Object) Handles conDetail.R_ServiceSave
        Dim loService As SAM01000ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01000Service, SAM01000ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
#End Region

    Private Sub SAM01000_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        Dim loParLock As R_LockPar
        Dim loRtn As R_LockingResult
        Dim loParUnlock As R_UnlockPar
        Dim loEntity As SAM01000DTO = poEntity
        'lock action if edit and delete a record
        If peLockUnlock = R_eLockUnlock.Lock Then
            With loParLock
                .Company_Id = _CCOMPID
                .User_Id = _CUSERID
                .Program_Id = "SAM01000"
                .Table_Name = "SAM_COMPANIES"
                .Key_Value = CType(bsGvComp.Current, SAM01000GridDTO).CCOMPANY_ID
            End With

            loRtn = R_LockingClient.R_Lock(loParLock)
        ElseIf peLockUnlock = R_eLockUnlock.Unlock Then
            With loParUnlock
                .Company_Id = _CCOMPID
                .User_Id = _CUSERID
                .Program_Id = "SAM01000"
                .Table_Name = "SAM_COMPANIES"
                .Key_Value = CType(bsGvComp.Current, SAM01000GridDTO).CCOMPANY_ID
            End With

            loRtn = R_LockingClient.R_Unlock(loParUnlock)
        End If

        If loRtn.IsSuccess Then
            plSuccessLockUnlock = True
        Else
            plSuccessLockUnlock = False
            Throw loRtn.Exception
        End If
    End Sub

#Region "LOOKUP SMTP"
    Private Sub btnLookupSMTP_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnLookupSMTP.R_Before_Open_Form
        poTargetForm = New LookupSMTP
    End Sub

    Private Sub btnLookupSMTP_R_Return_LookUp(poReturnObject As Object) Handles btnLookupSMTP.R_Return_LookUp
        'txtSMTP.Text = poReturnObject.CSMTP_ID
    End Sub
#End Region

#Region "POPUP SECTION"
#Region "UPLOAD COMPANY LOGO"
    Private Sub btnUpload_R_After_Open_Form(poPopUpResult As System.Windows.Forms.DialogResult, poPopUpEntityResult As Object) Handles btnUpload.R_After_Open_Form
        Dim loService As SAM01000ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01000Service, SAM01000ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loUpload As New SliceDTO
        Dim loEx As New R_Exception()
        Dim loList As ArrayList
        Dim loDatas As Byte()

        Try
            If poPopUpResult = Windows.Forms.DialogResult.Cancel Then
                Exit Try
            End If

            If poPopUpEntityResult IsNot Nothing Then
                Dim oData As SliceDTO = poPopUpEntityResult

                loUpload = oData

                With loUpload
                    ._COMPANY_ID = U_GlobalVar.CompId
                    ._KEY_GUID = Guid.NewGuid().ToString("N")
                End With

                'Slice Big Object
                If loUpload._DATA IsNot Nothing Then
                    loList = New ArrayList()
                    loDatas = R_Utility.Serialize(loUpload._DATA)

                    For Each loItem In loDatas.Slices(CHUNK_SIZE).Select(Function(x, i) Tuple.Create(i, x))
                        loList.Add(loItem)
                    Next

                    For Each loItem As Tuple(Of Integer, Byte()) In loList
                        With loUpload
                            ._SEQ_NO = loItem.Item1
                            ._DATA = loItem.Item2
                        End With

                        loService.SliceFiles(U_GlobalVar.UserId, loUpload)
                    Next
                End If

                loService.SaveImage(U_GlobalVar.UserId, loUpload, CType(bsDetail.Current, SAM01000DTO)._CCOMPANY_ID)
            End If

            loService.Close()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If
    End Sub

    Private Sub btnUpload_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnUpload.R_Before_Open_Form
        Dim loService As SAM01000ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01000Service, SAM01000ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loParam As New SliceDTO
        Dim loEx As New R_Exception()

        Try
            poTargetForm = New UploadForm

            loParam = loService.GetImage(CType(bsDetail.Current, SAM01000DTO)._CCOMPANY_ID)
            loService.Close()

            poParameter = loParam
            btnUpload.R_Title = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_UploadForm")
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
#End Region

#Region "DATETIME SETTING"
    Private Sub btnPopupDateTimeSetting_R_After_Open_Form(poPopUpResult As System.Windows.Forms.DialogResult, poPopUpEntityResult As Object) Handles btnPopupDateTimeSetting.R_After_Open_Form
        Dim loService As SAM01000ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01000Service, SAM01000ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception()
        Dim loSave As New SAM01000DTO

        Try
            If poPopUpResult = Windows.Forms.DialogResult.Cancel Or poPopUpEntityResult Is Nothing Then
                Exit Sub
            End If

            loSave = poPopUpEntityResult
            With loSave
                ._CCOMPANY_ID = CType(bsDetail.Current, SAM01000DTO)._CCOMPANY_ID
                ._CUSER_ID = _CUSERID
                ._DDATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            End With

            loService.SaveDateTime(loSave)
            conDetail.R_GetEntity(New SAM01000GridDTO With {.CCOMPANY_ID = loSave._CCOMPANY_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If
    End Sub

    Private Sub btnPopupDateTimeSetting_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnPopupDateTimeSetting.R_Before_Open_Form
        poTargetForm = New DateAndTime

        poParameter = New SAM01000DTO With {._CDATE_SHORT_FORMAT = CType(bsDetail.Current, SAM01000DTO)._CDATE_SHORT_FORMAT,
                                            ._CDATE_LONG_FORMAT = CType(bsDetail.Current, SAM01000DTO)._CDATE_LONG_FORMAT,
                                            ._CTIME_SHORT_FORMAT = CType(bsDetail.Current, SAM01000DTO)._CTIME_SHORT_FORMAT,
                                            ._CTIME_LONG_FORMAT = CType(bsDetail.Current, SAM01000DTO)._CTIME_LONG_FORMAT,
                                            ._CNUMBER_FORMAT = CType(bsDetail.Current, SAM01000DTO)._CNUMBER_FORMAT,
                                            ._CREPORT_CULTURE = CType(bsDetail.Current, SAM01000DTO)._CREPORT_CULTURE,
                                            ._IDECIMAL_PLACES = CType(bsDetail.Current, SAM01000DTO)._IDECIMAL_PLACES,
                                            ._IROUNDING_PLACES = CType(bsDetail.Current, SAM01000DTO)._IROUNDING_PLACES,
                                            ._CROUNDING_METHOD = CType(bsDetail.Current, SAM01000DTO)._CROUNDING_METHOD,
                                            ._LENABLE_SAVE_CONFIRMATION = CType(bsDetail.Current, SAM01000DTO)._LENABLE_SAVE_CONFIRMATION}

        btnPopupDateTimeSetting.R_Title = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_DateTimeSetting")
    End Sub
#End Region

#Region "PRODUCT KEY"
    Private Sub btnPopupProductKey_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnPopupProductKey.R_Before_Open_Form
        poTargetForm = New LicenseAndActivation

        poParameter = CType(bsDetail.Current, SAM01000DTO)._CCOMPANY_ID
        btnPopupProductKey.R_Title = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_ProductKey")
    End Sub
#End Region
#End Region

    Private Sub conDetail_R_Validation(poEntity As Object, peMode As R_FrontEnd.R_Conductor.e_Mode, ByRef plCancel As Boolean) Handles conDetail.R_Validation
        Dim loEx As New R_Exception()

        If peMode = R_Conductor.e_Mode.EditMode Then
            With CType(poEntity, SAM01000DTO)
                'address
                If ._CADDRESS.Length > 150 Then
                    loEx.Add(R_Utility.R_GetError(GetType(Resources_Dummy_Class), "PS002"))
                End If
                If String.IsNullOrWhiteSpace(._CADDRESS) Then
                    loEx.Add(R_Utility.R_GetError(GetType(Resources_Dummy_Class), "PS001"))
                End If

                'city
                'If ._CCITY.Length > 50 Then
                '    loEx.Add(R_Utility.R_GetError(GetType(Resources_Dummy_Class), "PS003"))
                'End If
                'If String.IsNullOrWhiteSpace(._CCITY) Then
                '    loEx.Add(R_Utility.R_GetError(GetType(Resources_Dummy_Class), "PS004"))
                'End If

                'country
                'If ._CCOUNTRY.Length > 50 Then
                '    loEx.Add(R_Utility.R_GetError(GetType(Resources_Dummy_Class), "PS005"))
                'End If
                'If String.IsNullOrWhiteSpace(._CCOUNTRY) Then
                '    loEx.Add(R_Utility.R_GetError(GetType(Resources_Dummy_Class), "PS006"))
                'End If

                'phone no 1
                'If ._CPHONE_1.Length > 20 Then
                '    loEx.Add(R_Utility.R_GetError(GetType(Resources_Dummy_Class), "PS007"))
                'End If
                'If String.IsNullOrWhiteSpace(._CPHONE_1) Then
                '    loEx.Add(R_Utility.R_GetError(GetType(Resources_Dummy_Class), "PS008"))
                'End If

                'tax name
                'If ._CTAX_NAME.Length > 50 Then
                '    loEx.Add(R_Utility.R_GetError(GetType(Resources_Dummy_Class), "PS009"))
                'End If
                'If String.IsNullOrWhiteSpace(._CTAX_NAME) Then
                '    loEx.Add(R_Utility.R_GetError(GetType(Resources_Dummy_Class), "PS010"))
                'End If

                'tax register id
                'If ._CTAX_REGISTER_ID.Length > 30 Then
                '    loEx.Add(R_Utility.R_GetError(GetType(Resources_Dummy_Class), "PS011"))
                'End If
                'If String.IsNullOrWhiteSpace(._CTAX_REGISTER_ID) Then
                '    loEx.Add(R_Utility.R_GetError(GetType(Resources_Dummy_Class), "PS012"))
                'End If
            End With
        End If

        If loEx.Haserror Then
            plCancel = True
            Me.R_DisplayException(loEx)
        End If
    End Sub

    Private Sub cmbLOB_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cmbLOB.SelectedValueChanged
        txtLOBName.Text = cmbLOB.SelectedText
    End Sub
End Class
