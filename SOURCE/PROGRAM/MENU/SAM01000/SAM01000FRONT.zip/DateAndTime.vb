﻿Imports R_FrontEnd
Imports R_Common
Imports System.ServiceModel.Channels
Imports System.Data.Common
Imports System.Threading
Imports SAM01000FrontResources

Public Class DateAndTime

    Private Sub DateAndTime_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        'Dim a As New DateAndTimeFormat()
        Dim oRes As New Resources_Dummy_Class

        'bsShortDate.DataSource = a.oShortDate
        'bsLongDate.DataSource = a.oLongDate
        'bsShortTime.DataSource = a.oShortTime
        'bsLongTime.DataSource = a.oLongTime
        'bsNumberFormat.DataSource = a.oNumberFormat

        bsLongTime.DataSource = GetLongTimeFormat()
        bsShortTime.DataSource = GetShortTimeFormat()
        bsShortDate.DataSource = GetShortDateFormat()
        bsLongDate.DataSource = GetLongDateFormat()
        bsReportLang.DataSource = GetCultures()
        bsNumberFormat.DataSource = GetNumberFormat()
        bsRoundingMethod.DataSource = GetRoundingMethod()
        bsDetail.DataSource = poParameter

        pageViewDate.Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_Date")
        pageViewTime.Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_Time")
        pageViewNumber.Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_Number")
        pageViewReportLang.Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_ReportLang")
        pageViewSettings.Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_Settings")

        pageView.SelectedPage = pageViewDate
    End Sub

#Region "LABEL VALUE"
    Private Sub cmbShortDate_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cmbShortDate.SelectedValueChanged
        If cmbShortDate.SelectedValue Is Nothing Then
            cmbShortDate.SelectedIndex = -1
            lblShortDate.Text = ""
        Else
            lblShortDate.Text = Date.Now.ToString(cmbShortDate.SelectedValue)
        End If
    End Sub

    Private Sub cmbLongDate_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cmbLongDate.SelectedValueChanged
        If cmbLongDate.SelectedValue Is Nothing Then
            cmbLongDate.SelectedIndex = -1
            lblLongDate.Text = ""
        Else
            lblLongDate.Text = Date.Now.ToString(cmbLongDate.SelectedValue)
        End If
    End Sub

    Private Sub cmbShortTime_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cmbShortTime.SelectedValueChanged
        If cmbShortTime.SelectedValue Is Nothing Then
            cmbShortDate.SelectedIndex = -1
            lblShortTime.Text = ""
        Else
            lblShortTime.Text = TimeOfDay.ToString(cmbShortTime.SelectedValue)
        End If
    End Sub

    Private Sub cmbLongTime_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cmbLongTime.SelectedValueChanged
        If cmbLongTime.SelectedValue Is Nothing Then
            cmbShortTime.SelectedIndex = -1
            lblLongTime.Text = ""
        Else
            lblLongTime.Text = TimeOfDay.ToString(cmbLongTime.SelectedValue)
        End If
    End Sub

    Private Sub cmbNumberFormat_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cmbNumberFormat.SelectedValueChanged
        If cmbNumberFormat.SelectedValue Is Nothing Then
            cmbNumberFormat.SelectedIndex = -1
            lblNumberFormat.Text = ""
            txtGroupingSymbol.Text = ""
        Else
            If cmbNumberFormat.SelectedValue = "." Then
                lblNumberFormat.Text = "123,456,789" & cmbNumberFormat.SelectedValue & "00"
                txtGroupingSymbol.Text = ","
            Else
                lblNumberFormat.Text = "123.456.789" & cmbNumberFormat.SelectedValue & "00"
                txtGroupingSymbol.Text = "."
            End If
        End If
    End Sub

    Private Sub cmbReportLang_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cmbReportLang.SelectedValueChanged
        If cmbReportLang.SelectedValue Is Nothing Then
            cmbReportLang.SelectedIndex = -1
        End If
    End Sub

    Private Sub spinDecimalPlaces_ValueChanged(sender As Object, e As System.EventArgs) Handles spinDecimalPlaces.ValueChanged
        If spinDecimalPlaces.Value = 0 Then
            lblNumberFormat.Text = "123,456,789" & cmbNumberFormat.SelectedValue
        ElseIf spinDecimalPlaces.Value = 1 Then
            lblNumberFormat.Text = "123,456,789" & cmbNumberFormat.SelectedValue & "0"
        Else
            lblNumberFormat.Text = "123,456,789" & cmbNumberFormat.SelectedValue & "00"
        End If
    End Sub

    Private Sub spinRoundingPlaces_ValueChanged(sender As Object, e As System.EventArgs) Handles spinRoundingPlaces.ValueChanged

    End Sub

    Private Sub cmbRoundingMethod_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cmbRoundingMethod.SelectedValueChanged

    End Sub
#End Region

    Private Sub rtnPopup_R_ValidationPopUpResult(ByRef plCancel As Boolean, poButton As System.Windows.Forms.DialogResult) Handles rtnPopup.R_ValidationPopUpResult
        Dim loEx As New R_Exception

        Try
            If poButton = Windows.Forms.DialogResult.OK Then
                If String.IsNullOrEmpty(cmbShortDate.SelectedValue) Then
                    loEx.Add(R_Utility.R_GetError(GetType(Resources_Dummy_Class), "PS015"))
                End If

                If String.IsNullOrEmpty(cmbLongDate.SelectedValue) Then
                    loEx.Add(R_Utility.R_GetError(GetType(Resources_Dummy_Class), "PS016"))
                End If

                If String.IsNullOrEmpty(cmbShortTime.SelectedValue) Then
                    loEx.Add(R_Utility.R_GetError(GetType(Resources_Dummy_Class), "PS013"))
                End If

                If String.IsNullOrEmpty(cmbLongTime.SelectedValue) Then
                    loEx.Add(R_Utility.R_GetError(GetType(Resources_Dummy_Class), "PS014"))
                End If

                If String.IsNullOrEmpty(cmbNumberFormat.SelectedValue) Then
                    loEx.Add(R_Utility.R_GetError(GetType(Resources_Dummy_Class), "PS018"))
                End If

                If String.IsNullOrEmpty(cmbReportLang.SelectedValue) Then
                    loEx.Add(R_Utility.R_GetError(GetType(Resources_Dummy_Class), "PS019"))
                End If
            End If

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        If loEx.Haserror Then
            plCancel = True
            loEx.ThrowExceptionIfErrors()
        End If
    End Sub

    Private Sub rtnPopup_R_SetPopUpResult(ByRef poEntityResult As Object) Handles rtnPopup.R_SetPopUpResult
        poEntityResult = bsDetail.Current
    End Sub

#Region "INTERNAL METHOD"
    Private Function GetCultures() As List(Of CultureDTO)
        Dim laNameValues As R_NameValue()
        Dim oRtn As New List(Of CultureDTO)

        laNameValues = R_Culture.R_GetAvailableCultures

        For Each avail As R_NameValue In laNameValues
            oRtn.Add(New CultureDTO With {.CCODE = IIf(avail.Value = 1, "en", "id"),
                                          .CDESC = avail.Name})
        Next

        Return oRtn
    End Function

    Private Function GetShortDateFormat() As List(Of FormatDTO)
        Dim oRtn As New List(Of FormatDTO)
        Dim oRtnShort As List(Of R_FormatValue)

        oRtnShort = R_DateTimeFormat.R_GetAvailableShortDateFormat

        For Each oShort As R_FormatValue In oRtnShort
            oRtn.Add(New FormatDTO With {.cFormat = oShort.OFORMAT})
        Next

        Return oRtn
    End Function

    Private Function GetLongDateFormat() As List(Of FormatDTO)
        Dim oRtn As New List(Of FormatDTO)
        Dim oRtnShort As List(Of R_FormatValue)

        oRtnShort = R_DateTimeFormat.R_GetAvailableLongDateFormat

        For Each oShort As R_FormatValue In oRtnShort
            oRtn.Add(New FormatDTO With {.cFormat = oShort.OFORMAT})
        Next

        Return oRtn
    End Function

    Private Function GetNumberFormat() As List(Of FormatDTO)
        Dim oRtn As New List(Of FormatDTO)
        Dim oRtnNumber As List(Of R_FormatValue)

        oRtnNumber = R_DateTimeFormat.R_GetAvailableNumberFormat

        For Each oShort As R_FormatValue In oRtnNumber
            oRtn.Add(New FormatDTO With {.cFormat = oShort.OFORMAT})
        Next

        Return oRtn
    End Function

    Private Function GetShortTimeFormat() As List(Of FormatDTO)
        Dim oRtn As New List(Of FormatDTO)
        Dim oRtnShort As List(Of R_FormatValue)

        oRtnShort = R_DateTimeFormat.R_GetAvailableShortTimeFormat

        For Each oShort As R_FormatValue In oRtnShort
            oRtn.Add(New FormatDTO With {.cFormat = oShort.OFORMAT})
        Next

        Return oRtn
    End Function

    Private Function GetLongTimeFormat() As List(Of FormatDTO)
        Dim oRtn As New List(Of FormatDTO)
        Dim oRtnShort As List(Of R_FormatValue)

        oRtnShort = R_DateTimeFormat.R_GetAvailableLongTimeFormat

        For Each oShort As R_FormatValue In oRtnShort
            oRtn.Add(New FormatDTO With {.cFormat = oShort.OFORMAT})
        Next

        Return oRtn
    End Function

    Private Function GetRoundingMethod() As List(Of FormatDTO)
        Dim oRtn As New List(Of FormatDTO)
        Dim oRtnRounding As List(Of R_FormatValue)

        oRtnRounding = R_DateTimeFormat.R_GetAvailableRoundingMethod

        For Each oShort As R_FormatValue In oRtnRounding
            oRtn.Add(New FormatDTO With {.cFormat = oShort.OFORMAT})
        Next

        Return oRtn
    End Function
#End Region

End Class
