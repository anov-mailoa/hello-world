﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UploadForm
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.R_RadGroupBox1 = New R_FrontEnd.R_RadGroupBox(Me.components)
        Me.btnEditPhoto = New R_FrontEnd.R_RadButton(Me.components)
        Me.btnCancelPhoto = New R_FrontEnd.R_RadButton(Me.components)
        Me.btnBrowsePhoto = New R_FrontEnd.R_RadButton(Me.components)
        Me.txtPhotoPath = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.pbLogo = New System.Windows.Forms.PictureBox()
        Me.txtCompany = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.R_RadLabel1 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.rtnPopup = New R_FrontEnd.R_ReturnPopUp()
        CType(Me.R_RadGroupBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.R_RadGroupBox1.SuspendLayout()
        CType(Me.btnEditPhoto, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnCancelPhoto, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnBrowsePhoto, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPhotoPath, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCompany, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.rtnPopup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'R_RadGroupBox1
        '
        Me.R_RadGroupBox1.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping
        Me.R_RadGroupBox1.Controls.Add(Me.btnEditPhoto)
        Me.R_RadGroupBox1.Controls.Add(Me.btnCancelPhoto)
        Me.R_RadGroupBox1.Controls.Add(Me.btnBrowsePhoto)
        Me.R_RadGroupBox1.Controls.Add(Me.txtPhotoPath)
        Me.R_RadGroupBox1.Controls.Add(Me.pbLogo)
        Me.R_RadGroupBox1.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadGroupBox1.HeaderText = "Photo"
        Me.R_RadGroupBox1.Location = New System.Drawing.Point(12, 38)
        Me.R_RadGroupBox1.Name = "R_RadGroupBox1"
        Me.R_RadGroupBox1.R_ConductorGridSource = Nothing
        Me.R_RadGroupBox1.R_ConductorSource = Nothing
        Me.R_RadGroupBox1.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadGroupBox1.R_ResourceId = "_Logo"
        Me.R_RadGroupBox1.Size = New System.Drawing.Size(370, 349)
        Me.R_RadGroupBox1.TabIndex = 0
        Me.R_RadGroupBox1.Text = "Photo"
        '
        'btnEditPhoto
        '
        Me.btnEditPhoto.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnEditPhoto.Location = New System.Drawing.Point(16, 271)
        Me.btnEditPhoto.Name = "btnEditPhoto"
        Me.btnEditPhoto.R_ConductorGridSource = Nothing
        Me.btnEditPhoto.R_ConductorSource = Nothing
        Me.btnEditPhoto.R_DescriptionId = Nothing
        Me.btnEditPhoto.R_ResourceId = "_EditLogo"
        Me.btnEditPhoto.Size = New System.Drawing.Size(337, 24)
        Me.btnEditPhoto.TabIndex = 7
        Me.btnEditPhoto.Text = "Edit Photo"
        '
        'btnCancelPhoto
        '
        Me.btnCancelPhoto.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnCancelPhoto.Location = New System.Drawing.Point(304, 312)
        Me.btnCancelPhoto.Name = "btnCancelPhoto"
        Me.btnCancelPhoto.R_ConductorGridSource = Nothing
        Me.btnCancelPhoto.R_ConductorSource = Nothing
        Me.btnCancelPhoto.R_DescriptionId = Nothing
        Me.btnCancelPhoto.R_ResourceId = "_Cancel"
        Me.btnCancelPhoto.Size = New System.Drawing.Size(49, 24)
        Me.btnCancelPhoto.TabIndex = 3
        Me.btnCancelPhoto.Text = "Cancel"
        Me.btnCancelPhoto.Visible = False
        '
        'btnBrowsePhoto
        '
        Me.btnBrowsePhoto.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnBrowsePhoto.Location = New System.Drawing.Point(273, 312)
        Me.btnBrowsePhoto.Name = "btnBrowsePhoto"
        Me.btnBrowsePhoto.R_ConductorGridSource = Nothing
        Me.btnBrowsePhoto.R_ConductorSource = Nothing
        Me.btnBrowsePhoto.R_DescriptionId = Nothing
        Me.btnBrowsePhoto.R_ResourceId = Nothing
        Me.btnBrowsePhoto.Size = New System.Drawing.Size(28, 24)
        Me.btnBrowsePhoto.TabIndex = 2
        Me.btnBrowsePhoto.Text = "..."
        Me.btnBrowsePhoto.Visible = False
        '
        'txtPhotoPath
        '
        Me.txtPhotoPath.Enabled = False
        Me.txtPhotoPath.Location = New System.Drawing.Point(16, 314)
        Me.txtPhotoPath.Name = "txtPhotoPath"
        Me.txtPhotoPath.R_ConductorGridSource = Nothing
        Me.txtPhotoPath.R_ConductorSource = Nothing
        Me.txtPhotoPath.R_UDT = Nothing
        Me.txtPhotoPath.Size = New System.Drawing.Size(251, 20)
        Me.txtPhotoPath.TabIndex = 1
        Me.txtPhotoPath.Visible = False
        '
        'pbLogo
        '
        Me.pbLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pbLogo.Location = New System.Drawing.Point(16, 21)
        Me.pbLogo.Name = "pbLogo"
        Me.pbLogo.Size = New System.Drawing.Size(337, 274)
        Me.pbLogo.TabIndex = 0
        Me.pbLogo.TabStop = False
        '
        'txtCompany
        '
        Me.txtCompany.Enabled = False
        Me.txtCompany.Location = New System.Drawing.Point(120, 12)
        Me.txtCompany.Name = "txtCompany"
        Me.txtCompany.R_ConductorGridSource = Nothing
        Me.txtCompany.R_ConductorSource = Nothing
        Me.txtCompany.R_UDT = Nothing
        Me.txtCompany.Size = New System.Drawing.Size(262, 20)
        Me.txtCompany.TabIndex = 2
        '
        'R_RadLabel1
        '
        Me.R_RadLabel1.AutoSize = False
        Me.R_RadLabel1.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel1.Location = New System.Drawing.Point(12, 13)
        Me.R_RadLabel1.Name = "R_RadLabel1"
        Me.R_RadLabel1.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel1.R_ResourceId = "_CCOMPANY_ID"
        Me.R_RadLabel1.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel1.TabIndex = 3
        Me.R_RadLabel1.Text = "R_RadLabel1"
        '
        'rtnPopup
        '
        Me.rtnPopup.Location = New System.Drawing.Point(220, 393)
        Me.rtnPopup.Name = "rtnPopup"
        Me.rtnPopup.Size = New System.Drawing.Size(162, 31)
        Me.rtnPopup.TabIndex = 6
        '
        'UploadForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(394, 426)
        Me.Controls.Add(Me.rtnPopup)
        Me.Controls.Add(Me.R_RadLabel1)
        Me.Controls.Add(Me.txtCompany)
        Me.Controls.Add(Me.R_RadGroupBox1)
        Me.Name = "UploadForm"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "Upload Form"
        CType(Me.R_RadGroupBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.R_RadGroupBox1.ResumeLayout(False)
        Me.R_RadGroupBox1.PerformLayout()
        CType(Me.btnEditPhoto, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnCancelPhoto, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnBrowsePhoto, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPhotoPath, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbLogo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCompany, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.rtnPopup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents R_RadGroupBox1 As R_FrontEnd.R_RadGroupBox
    Friend WithEvents pbLogo As System.Windows.Forms.PictureBox
    Friend WithEvents txtPhotoPath As R_FrontEnd.R_RadTextBox
    Friend WithEvents btnBrowsePhoto As R_FrontEnd.R_RadButton
    Friend WithEvents txtCompany As R_FrontEnd.R_RadTextBox
    Friend WithEvents R_RadLabel1 As R_FrontEnd.R_RadLabel
    Friend WithEvents rtnPopup As R_FrontEnd.R_ReturnPopUp
    Friend WithEvents btnEditPhoto As R_FrontEnd.R_RadButton
    Friend WithEvents btnCancelPhoto As R_FrontEnd.R_RadButton

End Class
