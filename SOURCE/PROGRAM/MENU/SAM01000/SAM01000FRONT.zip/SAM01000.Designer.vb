﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SAM01000
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn6 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.gvCompany = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvComp = New System.Windows.Forms.BindingSource(Me.components)
        Me.conDetail = New R_FrontEnd.R_Conductor(Me.components)
        Me.bsDetail = New System.Windows.Forms.BindingSource(Me.components)
        Me.R_RadGroupBox1 = New R_FrontEnd.R_RadGroupBox(Me.components)
        Me.btnAdd = New R_FrontEnd.R_Add(Me.components)
        Me.spinTimeout = New R_FrontEnd.R_RadSpinEditor(Me.components)
        Me.lblMinutes = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblTimeout = New R_FrontEnd.R_RadLabel(Me.components)
        Me.btnPopupProductKey = New R_FrontEnd.R_PopUp(Me.components)
        Me.btnPopupDateTimeSetting = New R_FrontEnd.R_PopUp(Me.components)
        Me.btnUpload = New R_FrontEnd.R_PopUp(Me.components)
        Me.btnLookupSMTP = New R_FrontEnd.R_LookUp(Me.components)
        Me.txtSMTP = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.R_RadLabel23 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtBaseCurr = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.R_RadLabel22 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtLocalCurr = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.R_RadLabel21 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtUpdateDate = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtExpDate = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtRegisDate = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtFaxNo = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtZip = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txUpdateBy = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtTaxBusinessName = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtTaxBusinessType = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtTaxID = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtTaxName = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtLOBName = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.cmbLOB = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsCmbLOB = New System.Windows.Forms.BindingSource(Me.components)
        Me.txtWebPage = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtPhone2 = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtPhone1 = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtCountry = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtCity = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtAddress = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtCompName = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtCompId = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblNoUser = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblCompStatus = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel20 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.btnCancel = New R_FrontEnd.R_Cancel(Me.components)
        Me.btnSave = New R_FrontEnd.R_Save(Me.components)
        Me.btnEdit = New R_FrontEnd.R_Edit(Me.components)
        Me.R_RadLabel19 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel17 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel18 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel16 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel15 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel14 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel12 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel13 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel8 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel9 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel10 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel11 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel7 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel6 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel5 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel4 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel3 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel2 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel1 = New R_FrontEnd.R_RadLabel(Me.components)
        CType(Me.gvCompany, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvCompany.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvComp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conDetail, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsDetail, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadGroupBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.R_RadGroupBox1.SuspendLayout()
        CType(Me.btnAdd, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spinTimeout, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblMinutes, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblTimeout, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnPopupProductKey, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnPopupDateTimeSetting, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnUpload, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnLookupSMTP, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSMTP, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel23, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtBaseCurr, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel22, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtLocalCurr, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel21, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtUpdateDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtExpDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtRegisDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtFaxNo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtZip, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txUpdateBy, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTaxBusinessName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTaxBusinessType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTaxID, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTaxName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtLOBName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbLOB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsCmbLOB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtWebPage, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPhone2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPhone1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCountry, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCity, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtAddress, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCompName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCompId, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblNoUser, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCompStatus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel20, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnCancel, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnSave, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnEdit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel19, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel18, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'gvCompany
        '
        Me.gvCompany.Location = New System.Drawing.Point(13, 13)
        '
        '
        '
        Me.gvCompany.MasterTemplate.AllowAddNewRow = False
        Me.gvCompany.MasterTemplate.AllowDeleteRow = False
        Me.gvCompany.MasterTemplate.AllowEditRow = False
        Me.gvCompany.MasterTemplate.AutoGenerateColumns = False
        Me.gvCompany.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn5.FieldName = "CCOMPANY_ID"
        R_GridViewTextBoxColumn5.HeaderText = "CCOMPANY_ID"
        R_GridViewTextBoxColumn5.IsAutoGenerated = True
        R_GridViewTextBoxColumn5.Name = "CCOMPANY_ID"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CCOMPANY_ID"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 471
        R_GridViewTextBoxColumn6.FieldName = "CCOMPANY_NAME"
        R_GridViewTextBoxColumn6.HeaderText = "CCOMPANY_NAME"
        R_GridViewTextBoxColumn6.IsAutoGenerated = True
        R_GridViewTextBoxColumn6.Name = "CCOMPANY_NAME"
        R_GridViewTextBoxColumn6.R_ResourceId = "_CCOMPANY_NAME"
        R_GridViewTextBoxColumn6.R_UDT = Nothing
        R_GridViewTextBoxColumn6.Width = 471
        Me.gvCompany.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn5, R_GridViewTextBoxColumn6})
        Me.gvCompany.MasterTemplate.DataSource = Me.bsGvComp
        Me.gvCompany.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvCompany.MasterTemplate.EnableFiltering = True
        Me.gvCompany.MasterTemplate.EnableGrouping = False
        Me.gvCompany.MasterTemplate.ShowFilteringRow = False
        Me.gvCompany.MasterTemplate.ShowGroupedColumns = True
        Me.gvCompany.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvCompany.Name = "gvCompany"
        Me.gvCompany.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvCompany.R_ConductorGridSource = Nothing
        Me.gvCompany.R_ConductorSource = Me.conDetail
        Me.gvCompany.R_DataAdded = False
        Me.gvCompany.R_EnableOTHER = True
        Me.gvCompany.R_GridType = R_FrontEnd.R_eGridType.Navigator
        Me.gvCompany.R_NewRowText = Nothing
        Me.gvCompany.ShowHeaderCellButtons = True
        Me.gvCompany.Size = New System.Drawing.Size(961, 113)
        Me.gvCompany.TabIndex = 0
        Me.gvCompany.Text = "R_RadGridView1"
        '
        'bsGvComp
        '
        Me.bsGvComp.DataSource = GetType(SAM01000Front.SAM01000StreamingServiceRef.SAM01000GridDTO)
        '
        'conDetail
        '
        Me.conDetail.R_BindingSource = Me.bsDetail
        Me.conDetail.R_ConductorParent = Nothing
        Me.conDetail.R_DisableCancelConfirmation = False
        Me.conDetail.R_DisableDeleteConfirmation = True
        Me.conDetail.R_IsHeader = True
        Me.conDetail.R_RadGroupBox = Nothing
        '
        'bsDetail
        '
        Me.bsDetail.DataSource = GetType(SAM01000Front.SAM01000ServiceRef.SAM01000DTO)
        '
        'R_RadGroupBox1
        '
        Me.R_RadGroupBox1.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping
        Me.R_RadGroupBox1.Controls.Add(Me.btnAdd)
        Me.R_RadGroupBox1.Controls.Add(Me.spinTimeout)
        Me.R_RadGroupBox1.Controls.Add(Me.lblMinutes)
        Me.R_RadGroupBox1.Controls.Add(Me.lblTimeout)
        Me.R_RadGroupBox1.Controls.Add(Me.btnPopupProductKey)
        Me.R_RadGroupBox1.Controls.Add(Me.btnPopupDateTimeSetting)
        Me.R_RadGroupBox1.Controls.Add(Me.btnUpload)
        Me.R_RadGroupBox1.Controls.Add(Me.btnLookupSMTP)
        Me.R_RadGroupBox1.Controls.Add(Me.txtSMTP)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel23)
        Me.R_RadGroupBox1.Controls.Add(Me.txtBaseCurr)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel22)
        Me.R_RadGroupBox1.Controls.Add(Me.txtLocalCurr)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel21)
        Me.R_RadGroupBox1.Controls.Add(Me.txtUpdateDate)
        Me.R_RadGroupBox1.Controls.Add(Me.txtExpDate)
        Me.R_RadGroupBox1.Controls.Add(Me.txtRegisDate)
        Me.R_RadGroupBox1.Controls.Add(Me.txtFaxNo)
        Me.R_RadGroupBox1.Controls.Add(Me.txtZip)
        Me.R_RadGroupBox1.Controls.Add(Me.txUpdateBy)
        Me.R_RadGroupBox1.Controls.Add(Me.txtTaxBusinessName)
        Me.R_RadGroupBox1.Controls.Add(Me.txtTaxBusinessType)
        Me.R_RadGroupBox1.Controls.Add(Me.txtTaxID)
        Me.R_RadGroupBox1.Controls.Add(Me.txtTaxName)
        Me.R_RadGroupBox1.Controls.Add(Me.txtLOBName)
        Me.R_RadGroupBox1.Controls.Add(Me.cmbLOB)
        Me.R_RadGroupBox1.Controls.Add(Me.txtWebPage)
        Me.R_RadGroupBox1.Controls.Add(Me.txtPhone2)
        Me.R_RadGroupBox1.Controls.Add(Me.txtPhone1)
        Me.R_RadGroupBox1.Controls.Add(Me.txtCountry)
        Me.R_RadGroupBox1.Controls.Add(Me.txtCity)
        Me.R_RadGroupBox1.Controls.Add(Me.txtAddress)
        Me.R_RadGroupBox1.Controls.Add(Me.txtCompName)
        Me.R_RadGroupBox1.Controls.Add(Me.txtCompId)
        Me.R_RadGroupBox1.Controls.Add(Me.lblNoUser)
        Me.R_RadGroupBox1.Controls.Add(Me.lblCompStatus)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel20)
        Me.R_RadGroupBox1.Controls.Add(Me.btnCancel)
        Me.R_RadGroupBox1.Controls.Add(Me.btnSave)
        Me.R_RadGroupBox1.Controls.Add(Me.btnEdit)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel19)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel17)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel18)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel16)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel15)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel14)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel12)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel13)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel8)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel9)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel10)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel11)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel7)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel6)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel5)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel4)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel3)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel2)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel1)
        Me.R_RadGroupBox1.Font = New System.Drawing.Font("Calibri", 15.0!)
        Me.R_RadGroupBox1.HeaderText = "Company Detail"
        Me.R_RadGroupBox1.Location = New System.Drawing.Point(13, 132)
        Me.R_RadGroupBox1.Name = "R_RadGroupBox1"
        Me.R_RadGroupBox1.R_ConductorGridSource = Nothing
        Me.R_RadGroupBox1.R_ConductorSource = Nothing
        Me.R_RadGroupBox1.R_ResourceId = "_HeaderGroupBox"
        Me.R_RadGroupBox1.Size = New System.Drawing.Size(961, 170)
        Me.R_RadGroupBox1.TabIndex = 1
        Me.R_RadGroupBox1.Text = "Company Detail"
        '
        'btnAdd
        '
        Me.btnAdd.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnAdd.Location = New System.Drawing.Point(23, 131)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.R_ConductorSource = Me.conDetail
        Me.btnAdd.R_ResourceId = Nothing
        Me.btnAdd.Size = New System.Drawing.Size(110, 24)
        Me.btnAdd.TabIndex = 65
        Me.btnAdd.Text = "&Add"
        '
        'spinTimeout
        '
        Me.spinTimeout.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.bsDetail, "_NTIMEOUT", True))
        Me.spinTimeout.Enabled = False
        Me.spinTimeout.Location = New System.Drawing.Point(162, 385)
        Me.spinTimeout.Name = "spinTimeout"
        Me.spinTimeout.R_ConductorGridSource = Nothing
        Me.spinTimeout.R_ConductorSource = Me.conDetail
        Me.spinTimeout.Size = New System.Drawing.Size(61, 20)
        Me.spinTimeout.TabIndex = 64
        Me.spinTimeout.TabStop = False
        Me.spinTimeout.ThousandsSeparator = True
        Me.spinTimeout.Visible = False
        '
        'lblMinutes
        '
        Me.lblMinutes.AutoSize = False
        Me.lblMinutes.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblMinutes.Location = New System.Drawing.Point(229, 386)
        Me.lblMinutes.Name = "lblMinutes"
        Me.lblMinutes.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblMinutes.R_ResourceId = "_Minute"
        Me.lblMinutes.Size = New System.Drawing.Size(93, 18)
        Me.lblMinutes.TabIndex = 63
        Me.lblMinutes.Text = "Base Currency"
        Me.lblMinutes.Visible = False
        '
        'lblTimeout
        '
        Me.lblTimeout.AutoSize = False
        Me.lblTimeout.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblTimeout.Location = New System.Drawing.Point(23, 386)
        Me.lblTimeout.Name = "lblTimeout"
        Me.lblTimeout.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblTimeout.R_ResourceId = "_TimeOut"
        Me.lblTimeout.Size = New System.Drawing.Size(110, 18)
        Me.lblTimeout.TabIndex = 61
        Me.lblTimeout.Text = "Tax Business Name"
        Me.lblTimeout.Visible = False
        '
        'btnPopupProductKey
        '
        Me.btnPopupProductKey.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnPopupProductKey.Location = New System.Drawing.Point(792, 404)
        Me.btnPopupProductKey.Name = "btnPopupProductKey"
        Me.btnPopupProductKey.R_ConductorGridSource = Nothing
        Me.btnPopupProductKey.R_ConductorSource = Me.conDetail
        Me.btnPopupProductKey.R_DescriptionId = "DESC01"
        Me.btnPopupProductKey.R_ResourceId = "_ProductKey"
        Me.btnPopupProductKey.R_Title = Nothing
        Me.btnPopupProductKey.Size = New System.Drawing.Size(164, 24)
        Me.btnPopupProductKey.TabIndex = 60
        Me.btnPopupProductKey.Text = "R_PopUp1"
        Me.btnPopupProductKey.Visible = False
        '
        'btnPopupDateTimeSetting
        '
        Me.btnPopupDateTimeSetting.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnPopupDateTimeSetting.Location = New System.Drawing.Point(309, 131)
        Me.btnPopupDateTimeSetting.Name = "btnPopupDateTimeSetting"
        Me.btnPopupDateTimeSetting.R_ConductorGridSource = Nothing
        Me.btnPopupDateTimeSetting.R_ConductorSource = Me.conDetail
        Me.btnPopupDateTimeSetting.R_DescriptionId = Nothing
        Me.btnPopupDateTimeSetting.R_EnableHASDATA = True
        Me.btnPopupDateTimeSetting.R_ResourceId = "_DateTimeFormat"
        Me.btnPopupDateTimeSetting.R_Title = Nothing
        Me.btnPopupDateTimeSetting.Size = New System.Drawing.Size(164, 24)
        Me.btnPopupDateTimeSetting.TabIndex = 59
        Me.btnPopupDateTimeSetting.Text = "Change Date and Time Format"
        '
        'btnUpload
        '
        Me.btnUpload.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnUpload.Location = New System.Drawing.Point(567, 131)
        Me.btnUpload.Name = "btnUpload"
        Me.btnUpload.R_ConductorGridSource = Nothing
        Me.btnUpload.R_ConductorSource = Me.conDetail
        Me.btnUpload.R_DescriptionId = Nothing
        Me.btnUpload.R_EnableHASDATA = True
        Me.btnUpload.R_ResourceId = "_UploadCompanyLogo"
        Me.btnUpload.R_Title = Nothing
        Me.btnUpload.Size = New System.Drawing.Size(157, 24)
        Me.btnUpload.TabIndex = 54
        Me.btnUpload.Text = "Upload Photo and Signature "
        '
        'btnLookupSMTP
        '
        Me.btnLookupSMTP.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnLookupSMTP.Location = New System.Drawing.Point(286, 106)
        Me.btnLookupSMTP.Name = "btnLookupSMTP"
        Me.btnLookupSMTP.R_ConductorGridSource = Nothing
        Me.btnLookupSMTP.R_ConductorSource = Me.conDetail
        Me.btnLookupSMTP.R_DescriptionId = Nothing
        Me.btnLookupSMTP.R_EnableADD = True
        Me.btnLookupSMTP.R_EnableEDIT = True
        Me.btnLookupSMTP.R_Field_Description = ""
        Me.btnLookupSMTP.R_Field_Value = "CSMTP_ID"
        Me.btnLookupSMTP.R_ResourceId = Nothing
        Me.btnLookupSMTP.R_TextBox_Description = Nothing
        Me.btnLookupSMTP.R_TextBox_Value = Me.txtSMTP
        Me.btnLookupSMTP.R_Title = Nothing
        Me.btnLookupSMTP.Size = New System.Drawing.Size(30, 20)
        Me.btnLookupSMTP.TabIndex = 53
        Me.btnLookupSMTP.Text = "..."
        '
        'txtSMTP
        '
        Me.txtSMTP.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_CSMTP_ID", True))
        Me.txtSMTP.Enabled = False
        Me.txtSMTP.Location = New System.Drawing.Point(162, 106)
        Me.txtSMTP.Name = "txtSMTP"
        Me.txtSMTP.R_ConductorGridSource = Nothing
        Me.txtSMTP.R_ConductorSource = Me.conDetail
        Me.txtSMTP.R_UDT = Nothing
        Me.txtSMTP.Size = New System.Drawing.Size(118, 20)
        Me.txtSMTP.TabIndex = 52
        '
        'R_RadLabel23
        '
        Me.R_RadLabel23.AutoSize = False
        Me.R_RadLabel23.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel23.Location = New System.Drawing.Point(23, 107)
        Me.R_RadLabel23.Name = "R_RadLabel23"
        Me.R_RadLabel23.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel23.R_ResourceId = "_SMTPID"
        Me.R_RadLabel23.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel23.TabIndex = 51
        Me.R_RadLabel23.Text = "SMTP"
        '
        'txtBaseCurr
        '
        Me.txtBaseCurr.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_CBASE_CURRENCY", True))
        Me.txtBaseCurr.Enabled = False
        Me.txtBaseCurr.Location = New System.Drawing.Point(445, 337)
        Me.txtBaseCurr.Name = "txtBaseCurr"
        Me.txtBaseCurr.R_ConductorGridSource = Nothing
        Me.txtBaseCurr.R_ConductorSource = Me.conDetail
        Me.txtBaseCurr.R_UDT = Nothing
        Me.txtBaseCurr.Size = New System.Drawing.Size(159, 20)
        Me.txtBaseCurr.TabIndex = 50
        Me.txtBaseCurr.Visible = False
        '
        'R_RadLabel22
        '
        Me.R_RadLabel22.AutoSize = False
        Me.R_RadLabel22.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel22.Location = New System.Drawing.Point(346, 338)
        Me.R_RadLabel22.Name = "R_RadLabel22"
        Me.R_RadLabel22.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel22.R_ResourceId = "_BaseCurr"
        Me.R_RadLabel22.Size = New System.Drawing.Size(93, 18)
        Me.R_RadLabel22.TabIndex = 49
        Me.R_RadLabel22.Text = "Base Currency"
        Me.R_RadLabel22.Visible = False
        '
        'txtLocalCurr
        '
        Me.txtLocalCurr.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_CLOCAL_CURRENCY", True))
        Me.txtLocalCurr.Enabled = False
        Me.txtLocalCurr.Location = New System.Drawing.Point(445, 313)
        Me.txtLocalCurr.Name = "txtLocalCurr"
        Me.txtLocalCurr.R_ConductorGridSource = Nothing
        Me.txtLocalCurr.R_ConductorSource = Me.conDetail
        Me.txtLocalCurr.R_UDT = Nothing
        Me.txtLocalCurr.Size = New System.Drawing.Size(159, 20)
        Me.txtLocalCurr.TabIndex = 48
        Me.txtLocalCurr.Visible = False
        '
        'R_RadLabel21
        '
        Me.R_RadLabel21.AutoSize = False
        Me.R_RadLabel21.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel21.Location = New System.Drawing.Point(346, 314)
        Me.R_RadLabel21.Name = "R_RadLabel21"
        Me.R_RadLabel21.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel21.R_ResourceId = "_LocalCurr"
        Me.R_RadLabel21.Size = New System.Drawing.Size(93, 18)
        Me.R_RadLabel21.TabIndex = 47
        Me.R_RadLabel21.Text = "Local Currency"
        Me.R_RadLabel21.Visible = False
        '
        'txtUpdateDate
        '
        Me.txtUpdateDate.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_DUPDATE_DATE", True))
        Me.txtUpdateDate.Enabled = False
        Me.txtUpdateDate.Location = New System.Drawing.Point(781, 362)
        Me.txtUpdateDate.Name = "txtUpdateDate"
        Me.txtUpdateDate.R_ConductorGridSource = Nothing
        Me.txtUpdateDate.R_ConductorSource = Me.conDetail
        Me.txtUpdateDate.R_UDT = Nothing
        Me.txtUpdateDate.Size = New System.Drawing.Size(159, 20)
        Me.txtUpdateDate.TabIndex = 46
        Me.txtUpdateDate.Visible = False
        '
        'txtExpDate
        '
        Me.txtExpDate.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_DEXPIRED_DATE", True))
        Me.txtExpDate.Enabled = False
        Me.txtExpDate.Location = New System.Drawing.Point(781, 313)
        Me.txtExpDate.Name = "txtExpDate"
        Me.txtExpDate.R_ConductorGridSource = Nothing
        Me.txtExpDate.R_ConductorSource = Me.conDetail
        Me.txtExpDate.R_UDT = Nothing
        Me.txtExpDate.Size = New System.Drawing.Size(118, 20)
        Me.txtExpDate.TabIndex = 45
        Me.txtExpDate.Visible = False
        '
        'txtRegisDate
        '
        Me.txtRegisDate.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_DREGISTERED_DATE", True))
        Me.txtRegisDate.Enabled = False
        Me.txtRegisDate.Location = New System.Drawing.Point(781, 289)
        Me.txtRegisDate.Name = "txtRegisDate"
        Me.txtRegisDate.R_ConductorGridSource = Nothing
        Me.txtRegisDate.R_ConductorSource = Me.conDetail
        Me.txtRegisDate.R_UDT = Nothing
        Me.txtRegisDate.Size = New System.Drawing.Size(118, 20)
        Me.txtRegisDate.TabIndex = 44
        Me.txtRegisDate.Visible = False
        '
        'txtFaxNo
        '
        Me.txtFaxNo.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_CFAX_NO", True))
        Me.txtFaxNo.Enabled = False
        Me.txtFaxNo.Location = New System.Drawing.Point(730, 208)
        Me.txtFaxNo.Name = "txtFaxNo"
        Me.txtFaxNo.R_ConductorGridSource = Nothing
        Me.txtFaxNo.R_ConductorSource = Me.conDetail
        Me.txtFaxNo.R_UDT = Nothing
        Me.txtFaxNo.Size = New System.Drawing.Size(159, 20)
        Me.txtFaxNo.TabIndex = 43
        Me.txtFaxNo.Visible = False
        '
        'txtZip
        '
        Me.txtZip.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_CZIP_CODE", True))
        Me.txtZip.Enabled = False
        Me.txtZip.Location = New System.Drawing.Point(730, 160)
        Me.txtZip.Name = "txtZip"
        Me.txtZip.R_ConductorGridSource = Nothing
        Me.txtZip.R_ConductorSource = Me.conDetail
        Me.txtZip.R_UDT = Nothing
        Me.txtZip.Size = New System.Drawing.Size(159, 20)
        Me.txtZip.TabIndex = 42
        Me.txtZip.Visible = False
        '
        'txUpdateBy
        '
        Me.txUpdateBy.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_CUPDATE_BY", True))
        Me.txUpdateBy.Enabled = False
        Me.txUpdateBy.Location = New System.Drawing.Point(781, 337)
        Me.txUpdateBy.Name = "txUpdateBy"
        Me.txUpdateBy.R_ConductorGridSource = Nothing
        Me.txUpdateBy.R_ConductorSource = Me.conDetail
        Me.txUpdateBy.R_UDT = Nothing
        Me.txUpdateBy.Size = New System.Drawing.Size(159, 20)
        Me.txUpdateBy.TabIndex = 40
        Me.txUpdateBy.Visible = False
        '
        'txtTaxBusinessName
        '
        Me.txtTaxBusinessName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_CTAX_BUSINESS_NAME", True))
        Me.txtTaxBusinessName.Enabled = False
        Me.txtTaxBusinessName.Location = New System.Drawing.Point(162, 361)
        Me.txtTaxBusinessName.Name = "txtTaxBusinessName"
        Me.txtTaxBusinessName.R_ConductorGridSource = Nothing
        Me.txtTaxBusinessName.R_ConductorSource = Me.conDetail
        Me.txtTaxBusinessName.R_UDT = Nothing
        Me.txtTaxBusinessName.Size = New System.Drawing.Size(473, 20)
        Me.txtTaxBusinessName.TabIndex = 39
        Me.txtTaxBusinessName.Visible = False
        '
        'txtTaxBusinessType
        '
        Me.txtTaxBusinessType.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_CTAX_BUSINESS_TYPE", True))
        Me.txtTaxBusinessType.Enabled = False
        Me.txtTaxBusinessType.Location = New System.Drawing.Point(162, 337)
        Me.txtTaxBusinessType.Name = "txtTaxBusinessType"
        Me.txtTaxBusinessType.R_ConductorGridSource = Nothing
        Me.txtTaxBusinessType.R_ConductorSource = Me.conDetail
        Me.txtTaxBusinessType.R_UDT = Nothing
        Me.txtTaxBusinessType.Size = New System.Drawing.Size(159, 20)
        Me.txtTaxBusinessType.TabIndex = 38
        Me.txtTaxBusinessType.Visible = False
        '
        'txtTaxID
        '
        Me.txtTaxID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_CTAX_REGISTER_ID", True))
        Me.txtTaxID.Enabled = False
        Me.txtTaxID.Location = New System.Drawing.Point(162, 313)
        Me.txtTaxID.Name = "txtTaxID"
        Me.txtTaxID.R_ConductorGridSource = Nothing
        Me.txtTaxID.R_ConductorSource = Me.conDetail
        Me.txtTaxID.R_UDT = Nothing
        Me.txtTaxID.Size = New System.Drawing.Size(159, 20)
        Me.txtTaxID.TabIndex = 37
        Me.txtTaxID.Visible = False
        '
        'txtTaxName
        '
        Me.txtTaxName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_CTAX_NAME", True))
        Me.txtTaxName.Enabled = False
        Me.txtTaxName.Location = New System.Drawing.Point(162, 289)
        Me.txtTaxName.Name = "txtTaxName"
        Me.txtTaxName.R_ConductorGridSource = Nothing
        Me.txtTaxName.R_ConductorSource = Me.conDetail
        Me.txtTaxName.R_UDT = Nothing
        Me.txtTaxName.Size = New System.Drawing.Size(473, 20)
        Me.txtTaxName.TabIndex = 36
        Me.txtTaxName.Visible = False
        '
        'txtLOBName
        '
        Me.txtLOBName.Enabled = False
        Me.txtLOBName.Location = New System.Drawing.Point(327, 256)
        Me.txtLOBName.Name = "txtLOBName"
        Me.txtLOBName.R_ConductorGridSource = Nothing
        Me.txtLOBName.R_ConductorSource = Me.conDetail
        Me.txtLOBName.R_UDT = Nothing
        Me.txtLOBName.Size = New System.Drawing.Size(308, 20)
        Me.txtLOBName.TabIndex = 35
        Me.txtLOBName.Visible = False
        '
        'cmbLOB
        '
        Me.cmbLOB.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.bsDetail, "_CLOB_CODE", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.cmbLOB.DataSource = Me.bsCmbLOB
        Me.cmbLOB.DisplayMember = "_CLOB_NAME"
        Me.cmbLOB.Enabled = False
        Me.cmbLOB.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cmbLOB.Location = New System.Drawing.Point(162, 257)
        Me.cmbLOB.Name = "cmbLOB"
        Me.cmbLOB.R_ConductorGridSource = Nothing
        Me.cmbLOB.R_ConductorSource = Me.conDetail
        Me.cmbLOB.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cmbLOB.Size = New System.Drawing.Size(159, 20)
        Me.cmbLOB.TabIndex = 34
        Me.cmbLOB.ValueMember = "_CLOB_CODE"
        Me.cmbLOB.Visible = False
        '
        'bsCmbLOB
        '
        Me.bsCmbLOB.DataSource = GetType(SAM01000Front.SAM01000ServiceRef.SAM01000CmbDTO)
        '
        'txtWebPage
        '
        Me.txtWebPage.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_CWEB_SITE", True))
        Me.txtWebPage.Enabled = False
        Me.txtWebPage.Location = New System.Drawing.Point(162, 232)
        Me.txtWebPage.Name = "txtWebPage"
        Me.txtWebPage.R_ConductorGridSource = Nothing
        Me.txtWebPage.R_ConductorSource = Me.conDetail
        Me.txtWebPage.R_UDT = Nothing
        Me.txtWebPage.Size = New System.Drawing.Size(473, 20)
        Me.txtWebPage.TabIndex = 33
        Me.txtWebPage.Visible = False
        '
        'txtPhone2
        '
        Me.txtPhone2.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_CPHONE_2", True))
        Me.txtPhone2.Enabled = False
        Me.txtPhone2.Location = New System.Drawing.Point(407, 208)
        Me.txtPhone2.Name = "txtPhone2"
        Me.txtPhone2.R_ConductorGridSource = Nothing
        Me.txtPhone2.R_ConductorSource = Me.conDetail
        Me.txtPhone2.R_UDT = Nothing
        Me.txtPhone2.Size = New System.Drawing.Size(159, 20)
        Me.txtPhone2.TabIndex = 32
        Me.txtPhone2.Visible = False
        '
        'txtPhone1
        '
        Me.txtPhone1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_CPHONE_1", True))
        Me.txtPhone1.Enabled = False
        Me.txtPhone1.Location = New System.Drawing.Point(162, 208)
        Me.txtPhone1.Name = "txtPhone1"
        Me.txtPhone1.R_ConductorGridSource = Nothing
        Me.txtPhone1.R_ConductorSource = Me.conDetail
        Me.txtPhone1.R_UDT = Nothing
        Me.txtPhone1.Size = New System.Drawing.Size(159, 20)
        Me.txtPhone1.TabIndex = 31
        Me.txtPhone1.Visible = False
        '
        'txtCountry
        '
        Me.txtCountry.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_CCOUNTRY", True))
        Me.txtCountry.Enabled = False
        Me.txtCountry.Location = New System.Drawing.Point(162, 184)
        Me.txtCountry.Name = "txtCountry"
        Me.txtCountry.R_ConductorGridSource = Nothing
        Me.txtCountry.R_ConductorSource = Me.conDetail
        Me.txtCountry.R_UDT = Nothing
        Me.txtCountry.Size = New System.Drawing.Size(473, 20)
        Me.txtCountry.TabIndex = 30
        Me.txtCountry.Visible = False
        '
        'txtCity
        '
        Me.txtCity.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_CCITY", True))
        Me.txtCity.Enabled = False
        Me.txtCity.Location = New System.Drawing.Point(162, 160)
        Me.txtCity.Name = "txtCity"
        Me.txtCity.R_ConductorGridSource = Nothing
        Me.txtCity.R_ConductorSource = Me.conDetail
        Me.txtCity.R_UDT = Nothing
        Me.txtCity.Size = New System.Drawing.Size(473, 20)
        Me.txtCity.TabIndex = 29
        Me.txtCity.Visible = False
        '
        'txtAddress
        '
        Me.txtAddress.AcceptsReturn = True
        Me.txtAddress.AutoSize = False
        Me.txtAddress.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_CADDRESS", True))
        Me.txtAddress.Location = New System.Drawing.Point(162, 44)
        Me.txtAddress.Multiline = True
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.R_ConductorGridSource = Nothing
        Me.txtAddress.R_ConductorSource = Me.conDetail
        Me.txtAddress.R_EnableADD = True
        Me.txtAddress.R_EnableEDIT = True
        Me.txtAddress.R_UDT = Nothing
        Me.txtAddress.Size = New System.Drawing.Size(473, 56)
        Me.txtAddress.TabIndex = 28
        '
        'txtCompName
        '
        Me.txtCompName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_CCOMPANY_NAME", True))
        Me.txtCompName.Enabled = False
        Me.txtCompName.Location = New System.Drawing.Point(316, 20)
        Me.txtCompName.Name = "txtCompName"
        Me.txtCompName.R_ConductorGridSource = Nothing
        Me.txtCompName.R_ConductorSource = Me.conDetail
        Me.txtCompName.R_EnableADD = True
        Me.txtCompName.R_EnableEDIT = True
        Me.txtCompName.R_UDT = Nothing
        Me.txtCompName.Size = New System.Drawing.Size(573, 20)
        Me.txtCompName.TabIndex = 27
        '
        'txtCompId
        '
        Me.txtCompId.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_CCOMPANY_ID", True))
        Me.txtCompId.Enabled = False
        Me.txtCompId.Location = New System.Drawing.Point(162, 20)
        Me.txtCompId.Name = "txtCompId"
        Me.txtCompId.R_ConductorGridSource = Nothing
        Me.txtCompId.R_ConductorSource = Me.conDetail
        Me.txtCompId.R_EnableADD = True
        Me.txtCompId.R_UDT = Nothing
        Me.txtCompId.Size = New System.Drawing.Size(148, 20)
        Me.txtCompId.TabIndex = 26
        '
        'lblNoUser
        '
        Me.lblNoUser.AutoSize = False
        Me.lblNoUser.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_INO_USERS", True))
        Me.lblNoUser.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblNoUser.Location = New System.Drawing.Point(814, 70)
        Me.lblNoUser.Name = "lblNoUser"
        Me.lblNoUser.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblNoUser.R_ResourceId = Nothing
        Me.lblNoUser.Size = New System.Drawing.Size(100, 18)
        Me.lblNoUser.TabIndex = 25
        Me.lblNoUser.Text = "R_RadLabel21"
        Me.lblNoUser.Visible = False
        '
        'lblCompStatus
        '
        Me.lblCompStatus.AutoSize = False
        Me.lblCompStatus.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_CCOMPANY_STATUS", True))
        Me.lblCompStatus.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCompStatus.Location = New System.Drawing.Point(814, 46)
        Me.lblCompStatus.Name = "lblCompStatus"
        Me.lblCompStatus.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCompStatus.R_ResourceId = Nothing
        Me.lblCompStatus.Size = New System.Drawing.Size(100, 18)
        Me.lblCompStatus.TabIndex = 24
        Me.lblCompStatus.Text = "R_RadLabel22"
        Me.lblCompStatus.Visible = False
        '
        'R_RadLabel20
        '
        Me.R_RadLabel20.AutoSize = False
        Me.R_RadLabel20.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel20.Location = New System.Drawing.Point(327, 209)
        Me.R_RadLabel20.Name = "R_RadLabel20"
        Me.R_RadLabel20.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel20.R_ResourceId = "_Phone2"
        Me.R_RadLabel20.Size = New System.Drawing.Size(74, 18)
        Me.R_RadLabel20.TabIndex = 23
        Me.R_RadLabel20.Text = "Phone No 2"
        Me.R_RadLabel20.Visible = False
        '
        'btnCancel
        '
        Me.btnCancel.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnCancel.Location = New System.Drawing.Point(846, 131)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.R_ConductorSource = Me.conDetail
        Me.btnCancel.R_ResourceId = Nothing
        Me.btnCancel.Size = New System.Drawing.Size(110, 24)
        Me.btnCancel.TabIndex = 22
        Me.btnCancel.Text = "&Cancel"
        '
        'btnSave
        '
        Me.btnSave.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnSave.Location = New System.Drawing.Point(730, 131)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.R_ConductorSource = Me.conDetail
        Me.btnSave.R_ResourceId = Nothing
        Me.btnSave.Size = New System.Drawing.Size(110, 24)
        Me.btnSave.TabIndex = 21
        Me.btnSave.Text = "&Save"
        '
        'btnEdit
        '
        Me.btnEdit.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnEdit.Location = New System.Drawing.Point(139, 131)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.R_ConductorSource = Me.conDetail
        Me.btnEdit.R_ResourceId = Nothing
        Me.btnEdit.Size = New System.Drawing.Size(110, 24)
        Me.btnEdit.TabIndex = 19
        Me.btnEdit.Text = "&Edit"
        '
        'R_RadLabel19
        '
        Me.R_RadLabel19.AutoSize = False
        Me.R_RadLabel19.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel19.Location = New System.Drawing.Point(675, 363)
        Me.R_RadLabel19.Name = "R_RadLabel19"
        Me.R_RadLabel19.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel19.R_ResourceId = "_DUPDATE_DATE"
        Me.R_RadLabel19.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel19.TabIndex = 18
        Me.R_RadLabel19.Text = "Last Update Date"
        Me.R_RadLabel19.Visible = False
        '
        'R_RadLabel17
        '
        Me.R_RadLabel17.AutoSize = False
        Me.R_RadLabel17.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel17.Location = New System.Drawing.Point(675, 314)
        Me.R_RadLabel17.Name = "R_RadLabel17"
        Me.R_RadLabel17.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel17.R_ResourceId = "_ExpDate"
        Me.R_RadLabel17.Size = New System.Drawing.Size(81, 18)
        Me.R_RadLabel17.TabIndex = 17
        Me.R_RadLabel17.Text = "Expired Date"
        Me.R_RadLabel17.Visible = False
        '
        'R_RadLabel18
        '
        Me.R_RadLabel18.AutoSize = False
        Me.R_RadLabel18.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel18.Location = New System.Drawing.Point(675, 290)
        Me.R_RadLabel18.Name = "R_RadLabel18"
        Me.R_RadLabel18.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel18.R_ResourceId = "_RegisDate"
        Me.R_RadLabel18.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel18.TabIndex = 16
        Me.R_RadLabel18.Text = "Registered Date"
        Me.R_RadLabel18.Visible = False
        '
        'R_RadLabel16
        '
        Me.R_RadLabel16.AutoSize = False
        Me.R_RadLabel16.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel16.Location = New System.Drawing.Point(675, 209)
        Me.R_RadLabel16.Name = "R_RadLabel16"
        Me.R_RadLabel16.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel16.R_ResourceId = "_Fax No."
        Me.R_RadLabel16.Size = New System.Drawing.Size(49, 18)
        Me.R_RadLabel16.TabIndex = 15
        Me.R_RadLabel16.Text = "Fax No."
        Me.R_RadLabel16.Visible = False
        '
        'R_RadLabel15
        '
        Me.R_RadLabel15.AutoSize = False
        Me.R_RadLabel15.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel15.Location = New System.Drawing.Point(675, 161)
        Me.R_RadLabel15.Name = "R_RadLabel15"
        Me.R_RadLabel15.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel15.R_ResourceId = "_Zip"
        Me.R_RadLabel15.Size = New System.Drawing.Size(49, 18)
        Me.R_RadLabel15.TabIndex = 14
        Me.R_RadLabel15.Text = "Zip"
        Me.R_RadLabel15.Visible = False
        '
        'R_RadLabel14
        '
        Me.R_RadLabel14.AutoSize = False
        Me.R_RadLabel14.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel14.Location = New System.Drawing.Point(675, 338)
        Me.R_RadLabel14.Name = "R_RadLabel14"
        Me.R_RadLabel14.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel14.R_ResourceId = "_CUPDATE_BY"
        Me.R_RadLabel14.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel14.TabIndex = 13
        Me.R_RadLabel14.Text = "Last Update By"
        Me.R_RadLabel14.Visible = False
        '
        'R_RadLabel12
        '
        Me.R_RadLabel12.AutoSize = False
        Me.R_RadLabel12.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel12.Location = New System.Drawing.Point(675, 70)
        Me.R_RadLabel12.Name = "R_RadLabel12"
        Me.R_RadLabel12.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel12.R_ResourceId = "_NoUser"
        Me.R_RadLabel12.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel12.TabIndex = 12
        Me.R_RadLabel12.Text = "No of User(s)"
        Me.R_RadLabel12.Visible = False
        '
        'R_RadLabel13
        '
        Me.R_RadLabel13.AutoSize = False
        Me.R_RadLabel13.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel13.Location = New System.Drawing.Point(675, 46)
        Me.R_RadLabel13.Name = "R_RadLabel13"
        Me.R_RadLabel13.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel13.R_ResourceId = "_CompanyStatus"
        Me.R_RadLabel13.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel13.TabIndex = 11
        Me.R_RadLabel13.Text = "Company Status"
        Me.R_RadLabel13.Visible = False
        '
        'R_RadLabel8
        '
        Me.R_RadLabel8.AutoSize = False
        Me.R_RadLabel8.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel8.Location = New System.Drawing.Point(23, 362)
        Me.R_RadLabel8.Name = "R_RadLabel8"
        Me.R_RadLabel8.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel8.R_ResourceId = "_TaxBusinessName"
        Me.R_RadLabel8.Size = New System.Drawing.Size(110, 18)
        Me.R_RadLabel8.TabIndex = 10
        Me.R_RadLabel8.Text = "Tax Business Name"
        Me.R_RadLabel8.Visible = False
        '
        'R_RadLabel9
        '
        Me.R_RadLabel9.AutoSize = False
        Me.R_RadLabel9.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel9.Location = New System.Drawing.Point(23, 338)
        Me.R_RadLabel9.Name = "R_RadLabel9"
        Me.R_RadLabel9.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel9.R_ResourceId = "_TaxBusinessType"
        Me.R_RadLabel9.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel9.TabIndex = 9
        Me.R_RadLabel9.Text = "Tax Business Type"
        Me.R_RadLabel9.Visible = False
        '
        'R_RadLabel10
        '
        Me.R_RadLabel10.AutoSize = False
        Me.R_RadLabel10.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel10.Location = New System.Drawing.Point(23, 314)
        Me.R_RadLabel10.Name = "R_RadLabel10"
        Me.R_RadLabel10.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel10.R_ResourceId = "_TaxID"
        Me.R_RadLabel10.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel10.TabIndex = 8
        Me.R_RadLabel10.Text = "Tax ID*"
        Me.R_RadLabel10.Visible = False
        '
        'R_RadLabel11
        '
        Me.R_RadLabel11.AutoSize = False
        Me.R_RadLabel11.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel11.Location = New System.Drawing.Point(23, 290)
        Me.R_RadLabel11.Name = "R_RadLabel11"
        Me.R_RadLabel11.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel11.R_ResourceId = "_TaxName"
        Me.R_RadLabel11.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel11.TabIndex = 7
        Me.R_RadLabel11.Text = "Tax Name*"
        Me.R_RadLabel11.Visible = False
        '
        'R_RadLabel7
        '
        Me.R_RadLabel7.AutoSize = False
        Me.R_RadLabel7.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel7.Location = New System.Drawing.Point(23, 257)
        Me.R_RadLabel7.Name = "R_RadLabel7"
        Me.R_RadLabel7.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel7.R_ResourceId = "_LOB"
        Me.R_RadLabel7.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel7.TabIndex = 6
        Me.R_RadLabel7.Text = "Line of Business"
        Me.R_RadLabel7.Visible = False
        '
        'R_RadLabel6
        '
        Me.R_RadLabel6.AutoSize = False
        Me.R_RadLabel6.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel6.Location = New System.Drawing.Point(23, 233)
        Me.R_RadLabel6.Name = "R_RadLabel6"
        Me.R_RadLabel6.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel6.R_ResourceId = "_WebPage"
        Me.R_RadLabel6.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel6.TabIndex = 5
        Me.R_RadLabel6.Text = "Web Page"
        Me.R_RadLabel6.Visible = False
        '
        'R_RadLabel5
        '
        Me.R_RadLabel5.AutoSize = False
        Me.R_RadLabel5.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel5.Location = New System.Drawing.Point(23, 209)
        Me.R_RadLabel5.Name = "R_RadLabel5"
        Me.R_RadLabel5.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel5.R_ResourceId = "_Phone1"
        Me.R_RadLabel5.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel5.TabIndex = 4
        Me.R_RadLabel5.Text = "Phone No 1*"
        Me.R_RadLabel5.Visible = False
        '
        'R_RadLabel4
        '
        Me.R_RadLabel4.AutoSize = False
        Me.R_RadLabel4.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel4.Location = New System.Drawing.Point(23, 185)
        Me.R_RadLabel4.Name = "R_RadLabel4"
        Me.R_RadLabel4.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel4.R_ResourceId = "_Country"
        Me.R_RadLabel4.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel4.TabIndex = 3
        Me.R_RadLabel4.Text = "Country*"
        Me.R_RadLabel4.Visible = False
        '
        'R_RadLabel3
        '
        Me.R_RadLabel3.AutoSize = False
        Me.R_RadLabel3.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel3.Location = New System.Drawing.Point(23, 161)
        Me.R_RadLabel3.Name = "R_RadLabel3"
        Me.R_RadLabel3.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel3.R_ResourceId = "_City"
        Me.R_RadLabel3.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel3.TabIndex = 2
        Me.R_RadLabel3.Text = "City*"
        Me.R_RadLabel3.Visible = False
        '
        'R_RadLabel2
        '
        Me.R_RadLabel2.AutoSize = False
        Me.R_RadLabel2.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel2.Location = New System.Drawing.Point(23, 45)
        Me.R_RadLabel2.Name = "R_RadLabel2"
        Me.R_RadLabel2.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel2.R_ResourceId = "_Address"
        Me.R_RadLabel2.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel2.TabIndex = 1
        Me.R_RadLabel2.Text = "Address*"
        '
        'R_RadLabel1
        '
        Me.R_RadLabel1.AutoSize = False
        Me.R_RadLabel1.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel1.Location = New System.Drawing.Point(23, 21)
        Me.R_RadLabel1.Name = "R_RadLabel1"
        Me.R_RadLabel1.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel1.R_ResourceId = "_Company"
        Me.R_RadLabel1.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel1.TabIndex = 0
        Me.R_RadLabel1.Text = "Company"
        '
        'SAM01000
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(986, 312)
        Me.Controls.Add(Me.R_RadGroupBox1)
        Me.Controls.Add(Me.gvCompany)
        Me.Name = "SAM01000"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.gvCompany.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvCompany, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvComp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conDetail, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsDetail, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadGroupBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.R_RadGroupBox1.ResumeLayout(False)
        Me.R_RadGroupBox1.PerformLayout()
        CType(Me.btnAdd, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spinTimeout, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblMinutes, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblTimeout, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnPopupProductKey, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnPopupDateTimeSetting, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnUpload, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnLookupSMTP, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSMTP, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel23, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtBaseCurr, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel22, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtLocalCurr, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel21, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtUpdateDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtExpDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtRegisDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtFaxNo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtZip, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txUpdateBy, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTaxBusinessName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTaxBusinessType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTaxID, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTaxName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtLOBName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbLOB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsCmbLOB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtWebPage, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPhone2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPhone1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCountry, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCity, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtAddress, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCompName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCompId, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblNoUser, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCompStatus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel20, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnCancel, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnSave, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnEdit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel19, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel18, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents gvCompany As R_FrontEnd.R_RadGridView
    Friend WithEvents R_RadGroupBox1 As R_FrontEnd.R_RadGroupBox
    Friend WithEvents R_RadLabel14 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel12 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel13 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel8 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel9 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel10 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel11 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel7 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel6 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel5 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel4 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel3 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel2 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel1 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel19 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel17 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel18 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel16 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel15 As R_FrontEnd.R_RadLabel
    Friend WithEvents btnCancel As R_FrontEnd.R_Cancel
    Friend WithEvents btnSave As R_FrontEnd.R_Save
    Friend WithEvents btnEdit As R_FrontEnd.R_Edit
    Friend WithEvents txtCompName As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtCompId As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblNoUser As R_FrontEnd.R_RadLabel
    Friend WithEvents lblCompStatus As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel20 As R_FrontEnd.R_RadLabel
    Friend WithEvents txtCity As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtAddress As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtCountry As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtPhone2 As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtPhone1 As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtLOBName As R_FrontEnd.R_RadTextBox
    Friend WithEvents cmbLOB As R_FrontEnd.R_RadDropDownList
    Friend WithEvents txtWebPage As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtTaxName As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtTaxBusinessName As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtTaxBusinessType As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtTaxID As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtExpDate As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtRegisDate As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtFaxNo As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtZip As R_FrontEnd.R_RadTextBox
    Friend WithEvents txUpdateBy As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtUpdateDate As R_FrontEnd.R_RadTextBox
    Friend WithEvents conDetail As R_FrontEnd.R_Conductor
    Friend WithEvents bsDetail As System.Windows.Forms.BindingSource
    Friend WithEvents bsGvComp As System.Windows.Forms.BindingSource
    Friend WithEvents bsCmbLOB As System.Windows.Forms.BindingSource
    Friend WithEvents txtBaseCurr As R_FrontEnd.R_RadTextBox
    Friend WithEvents R_RadLabel22 As R_FrontEnd.R_RadLabel
    Friend WithEvents txtLocalCurr As R_FrontEnd.R_RadTextBox
    Friend WithEvents R_RadLabel21 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel23 As R_FrontEnd.R_RadLabel
    Friend WithEvents txtSMTP As R_FrontEnd.R_RadTextBox
    Friend WithEvents btnLookupSMTP As R_FrontEnd.R_LookUp
    Friend WithEvents btnUpload As R_FrontEnd.R_PopUp
    Friend WithEvents btnPopupDateTimeSetting As R_FrontEnd.R_PopUp
    Friend WithEvents btnPopupProductKey As R_FrontEnd.R_PopUp
    Friend WithEvents lblTimeout As R_FrontEnd.R_RadLabel
    Friend WithEvents lblMinutes As R_FrontEnd.R_RadLabel
    Friend WithEvents spinTimeout As R_FrontEnd.R_RadSpinEditor
    Friend WithEvents btnAdd As R_FrontEnd.R_Add

End Class
