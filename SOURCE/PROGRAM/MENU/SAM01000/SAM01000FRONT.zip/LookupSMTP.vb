﻿Imports R_FrontEnd
Imports SAM01000Front.SAM01000ServiceRef
Imports SAM01000Front.SAM01000StreamingServiceRef
Imports R_Common
Imports System.ServiceModel.Channels
Imports ClientHelper
Imports SAM01000FrontResources

Public Class LookupSMTP

#Region " VARIABLE "
    Dim C_ServiceName As String = "SAM01000Service/SAM01000Service.svc"
    Dim C_ServiceNameStream As String = "SAM01000Service/SAM01000StreamingService/SAM01000StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
#End Region

    Private Sub LookupSMTP_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class

        gvSMTP.R_RefreshGrid(New SMTPDTO)
    End Sub

    Private Sub gvSMTP_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvSMTP.R_ServiceGetListRecord
        Dim loServiceStream As SAM01000StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01000StreamingService, SAM01000StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of SMTPDTO)
        Dim loListEntity As New List(Of SMTPDTO)

        Try
            loRtn = loServiceStream.getSMTPList()
            loStreaming = R_StreamUtility(Of SMTPDTO).ReadFromMessage(loRtn)

            For Each loDto As SMTPDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub
End Class