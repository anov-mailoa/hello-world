﻿Imports R_FrontEnd
Imports R_Common
Imports System.ServiceModel.Channels
Imports ClientHelper
Imports SAM01000Front.SAM01000ServiceRef
Imports System.Windows.Forms
Imports System.Drawing
Imports SAM01000FrontResources
Imports System.IO

Public Class UploadForm
#Region " VARIABLE "
    Dim oParam As SliceDTO
    Dim loRtn As SliceDTO
    Dim _cOldImgPhoto As String
    Dim _cOldImgSign As String
#End Region

#Region " INIT "

    Private Sub UploadForm_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim loEx As New R_Exception()
        Dim lcNoImgPath As String = My.Application.Info.DirectoryPath + "\Image\no-image.png"
        Dim oRes As New Resources_Dummy_Class

        Try
            If poParameter IsNot Nothing Then
                oParam = poParameter

                txtCompany.Text = oParam._COMPANY_ID

                Dim oPhoto As Byte() = oParam._DATA
                Dim cPhotoFilename As String = U_GlobalVar.TemporaryPath + "\" + U_GlobalVar.UserId + "_" + Guid.NewGuid().ToString("N") + ".jpg"
                If oPhoto IsNot Nothing Then
                    oPhoto = R_Utility.Deserialize(oPhoto)
                    R_Utility.ConvertByteToFile(cPhotoFilename, oPhoto)
                End If

                If My.Computer.FileSystem.FileExists(cPhotoFilename) Then
                    pbLogo.BackgroundImage = SafeImageFromFile(cPhotoFilename)
                    _cOldImgPhoto = cPhotoFilename
                Else
                    If My.Computer.FileSystem.FileExists(lcNoImgPath) Then
                        pbLogo.BackgroundImage = SafeImageFromFile(lcNoImgPath)
                        _cOldImgPhoto = lcNoImgPath
                    Else
                        pbLogo.BackgroundImage = My.Resources.no_image
                        _cOldImgPhoto = Path.Combine(Application.UserAppDataPath, "no-image.png")
                    End If
                End If

            End If
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
#End Region

#Region "BUTTON REGION"
    Private Sub btnBrowsePhoto_Click(sender As System.Object, e As System.EventArgs) Handles btnBrowsePhoto.Click
        Dim openFileDialog1 As New OpenFileDialog()
        openFileDialog1.Filter = "Image Files (*.png, *.jpg, *.jpeg)|*.png;*.jpg;*.jpeg"
        openFileDialog1.Title = "Select a picture file"

        If openFileDialog1.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
            txtPhotoPath.Text = openFileDialog1.FileName
            loRtn = New SliceDTO With {._DATA = R_Utility.GetByteFromFile(txtPhotoPath.Text)}
            Dim oImg As Image = Image.FromFile(txtPhotoPath.Text)
            pbLogo.BackgroundImage = oImg
        End If
    End Sub

    Private Sub btnEditPhoto_Click(sender As System.Object, e As System.EventArgs) Handles btnEditPhoto.Click
        CType(sender, R_RadButton).Visible = False
        DisablePhoto(True)
    End Sub

    Private Sub btnCancelPhoto_Click(sender As Object, e As System.EventArgs) Handles btnCancelPhoto.Click
        Dim oCheckImg As SliceDTO = loRtn
        If oCheckImg IsNot Nothing Then
            loRtn = Nothing
        End If

        If My.Computer.FileSystem.FileExists(_cOldImgPhoto) Then
            pbLogo.BackgroundImage = SafeImageFromFile(_cOldImgPhoto)
        Else
            pbLogo.BackgroundImage = My.Resources.no_image
        End If

        DisablePhoto(False)
    End Sub

#End Region

#Region "INTERNAL METHOD"
    Private Sub DisablePhoto(plVisible As Boolean)
        txtPhotoPath.Visible = plVisible
        btnBrowsePhoto.Visible = plVisible
        btnCancelPhoto.Visible = plVisible
        txtPhotoPath.Text = ""
        btnEditPhoto.Visible = Not plVisible
    End Sub

    Public Shared Function SafeImageFromFile(path As String) As Image
        Using fs As New FileStream(path, FileMode.Open, FileAccess.Read)
            Dim img = Image.FromStream(fs)
            Return img
        End Using
    End Function
#End Region

    Private Sub rtnPopup_R_SetPopUpResult(ByRef poEntityResult As Object) Handles rtnPopup.R_SetPopUpResult
        poEntityResult = loRtn
    End Sub

    Private Sub rtnPopup_R_ValidationPopUpResult(ByRef plCancel As Boolean, poButton As System.Windows.Forms.DialogResult) Handles rtnPopup.R_ValidationPopUpResult
        If poButton = Windows.Forms.DialogResult.OK And loRtn Is Nothing Then
            plCancel = True
        End If
    End Sub
End Class
