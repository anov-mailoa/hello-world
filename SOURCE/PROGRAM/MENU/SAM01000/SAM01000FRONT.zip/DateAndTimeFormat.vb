﻿Public Class DateAndTimeFormat
    'Public oShortDate As List(Of FormatDTO)
    'Public oLongDate As List(Of FormatDTO)
    'Public oShortTime As List(Of FormatDTO)
    'Public oLongTime As List(Of FormatDTO)
    'Public oNumberFormat As List(Of FormatDTO)

    Public Sub New()
        'fillShortDate()
        'fillLongDate()
        'fillShortTime()
        'fillLongTime()
        'fillNumberFormat()
    End Sub

    'Private Sub fillShortDate()
    '    Dim oShort As New List(Of FormatDTO)

    '    oShort.Add(New FormatDTO With {.cFormat = "M/d/yyyy"})
    '    oShort.Add(New FormatDTO With {.cFormat = "M/d/yy"})
    '    oShort.Add(New FormatDTO With {.cFormat = "MM/dd/yy"})
    '    oShort.Add(New FormatDTO With {.cFormat = "MM/dd/yyyy"})
    '    oShort.Add(New FormatDTO With {.cFormat = "yy/MM/dd"})
    '    oShort.Add(New FormatDTO With {.cFormat = "yyyy-MM-dd"})
    '    oShort.Add(New FormatDTO With {.cFormat = "dd-MMM-yy"})

    '    oShort.Add(New FormatDTO With {.cFormat = "dd/MM/yyyy"})
    '    oShort.Add(New FormatDTO With {.cFormat = "dd/MM/yy"})
    '    oShort.Add(New FormatDTO With {.cFormat = "d-MMM-yy"})
    '    oShort.Add(New FormatDTO With {.cFormat = "d-MMM-yyyy"})
    '    oShort.Add(New FormatDTO With {.cFormat = "dd-MMM-yyyy"})

    '    oShortDate = oShort
    'End Sub

    'Private Sub fillLongDate()
    '    Dim oLong As New List(Of FormatDTO)

    '    oLong.Add(New FormatDTO With {.cFormat = "dddd, MMMM d, yyyy"})
    '    oLong.Add(New FormatDTO With {.cFormat = "MMMM d, yyyy"})
    '    oLong.Add(New FormatDTO With {.cFormat = "dddd, d MMMM, yyyy"})
    '    oLong.Add(New FormatDTO With {.cFormat = "d MMMM, yyyy"})
    '    oLongDate = oLong
    'End Sub

    'Private Sub fillShortTime()
    '    Dim oShort As New List(Of FormatDTO)

    '    oShort.Add(New FormatDTO With {.cFormat = "h:mm tt"})
    '    oShort.Add(New FormatDTO With {.cFormat = "hh:mm tt"})
    '    oShort.Add(New FormatDTO With {.cFormat = "H:mm"})
    '    oShort.Add(New FormatDTO With {.cFormat = "HH:mm"})
    '    oShortTime = oShort
    'End Sub

    'Private Sub fillLongTime()
    '    Dim oLong As New List(Of FormatDTO)

    '    oLong.Add(New FormatDTO With {.cFormat = "h:mm:ss tt"})
    '    oLong.Add(New FormatDTO With {.cFormat = "hh:mm:ss tt"})
    '    oLong.Add(New FormatDTO With {.cFormat = "H:mm:ss"})
    '    oLong.Add(New FormatDTO With {.cFormat = "HH:mm:ss"})
    '    oLongTime = oLong
    'End Sub

    'Private Sub fillNumberFormat()
    '    Dim oNumber As New List(Of FormatDTO)

    '    oNumber.Add(New FormatDTO With {.cFormat = "."})
    '    oNumber.Add(New FormatDTO With {.cFormat = ","})
    '    oNumberFormat = oNumber
    'End Sub
End Class

Public Class FormatDTO
    Public Property cFormat As String
End Class
