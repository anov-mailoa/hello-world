﻿Imports R_Common
Imports SAM01000Back
Imports System.ServiceModel.Channels
' NOTE: You can use the "Rename" command on the context menu to change the class name "SAM01000StreamingService" in code, svc and config file together.
Public Class SAM01000StreamingService
    Implements ISAM01000StreamingService

    Public Function getCompList() As System.ServiceModel.Channels.Message Implements ISAM01000StreamingService.getCompList
        Dim loException As New R_Exception
        Dim loCls As New SAM01000Cls
        Dim loRtnTemp As List(Of SAM01000GridDTO)
        Dim loRtn As Message

        Try
            loRtnTemp = loCls.getCompList()

            loRtn = R_StreamUtility(Of SAM01000GridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getCompList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub Dummy(poPar As System.Collections.Generic.List(Of SAM01000Back.SAM01000GridDTO), poPar1 As System.Collections.Generic.List(Of SAM01000Back.SMTPDTO)) Implements ISAM01000StreamingService.Dummy

    End Sub

    Public Function getSMTPList() As System.ServiceModel.Channels.Message Implements ISAM01000StreamingService.getSMTPList
        Dim loException As New R_Exception
        Dim loCls As New SAM01000Cls
        Dim loRtnTemp As List(Of SMTPDTO)
        Dim loRtn As Message

        Try
            loRtnTemp = loCls.getSMTPList()

            loRtn = R_StreamUtility(Of SMTPDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getSMTPList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
