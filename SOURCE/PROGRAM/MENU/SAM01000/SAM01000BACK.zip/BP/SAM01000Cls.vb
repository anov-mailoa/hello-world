﻿Imports R_Common
Imports R_BackEnd
Imports System.Data.Common

Public Class SAM01000Cls
    Inherits R_BusinessObject(Of SAM01000DTO)

    Protected Overrides Sub R_Deleting(poEntity As SAM01000DTO)

    End Sub

    Protected Overrides Function R_Display(poEntity As SAM01000DTO) As SAM01000DTO
        Dim lcQuery As String
        Dim loResult As SAM01000DTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT "
            lcQuery += "A.CCOMPANY_ID, A.CCOMPANY_NAME, A.CADDRESS, A.CZIP_CODE, A.CCITY, A.CCOUNTRY, A.CPHONE_1, A.CPHONE_2, "
            lcQuery += "A.CFAX_NO, A.CLOB_CODE, A.CWEB_SITE, A.CTAX_NAME, A.CTAX_REGISTER_ID, A.DTAX_REGISTER_DATE, A.CTAX_BUSINESS_TYPE, "
            lcQuery += "A.CTAX_BUSINESS_NAME, A.CLOCAL_CURRENCY, A.CBASE_CURRENCY, "
            lcQuery += "A.CUPDATE_BY, A.DUPDATE_DATE, A.CSMTP_ID, A.CDATE_LONG_FORMAT, A.CDATE_SHORT_FORMAT, A.CTIME_LONG_FORMAT, "
            lcQuery += "A.CTIME_SHORT_FORMAT, A.CNUMBER_FORMAT, A.CREPORT_CULTURE, B.NTIMEOUT, A.IDECIMAL_PLACES, A.IROUNDING_PLACES, A.CROUNDING_METHOD, A.LENABLE_SAVE_CONFIRMATION "
            lcQuery += "FROM "
            lcQuery += "SAM_COMPANIES A (NOLOCK) "
            lcQuery += "LEFT JOIN GST_LICENSE B (NOLOCK) "
            lcQuery += "ON B.CCOMPANY_ID = A.CCOMPANY_ID "
            lcQuery += "WHERE A.CCOMPANY_ID = '{0}' "
            lcQuery = String.Format(lcQuery, poEntity.CCOMPANY_ID)

            loResult = loDb.SqlExecObjectQuery(Of SAM01000DTO)(lcQuery).FirstOrDefault
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As SAM01000DTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As SAM01000DTO

        Try
            loConn = loDb.GetConnection()

            If poCRUDMode = eCRUDMode.AddMode Then
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "SAM_COMPANIES (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery = String.Format(lcQuery, poNewEntity.CCOMPANY_ID)

                loResult = loDb.SqlExecObjectQuery(Of SAM01000DTO)(lcQuery, loConn, False).FirstOrDefault
                If loResult IsNot Nothing Then
                    Throw New Exception("Company Id " + poNewEntity.CCOMPANY_ID.Trim + " Already Exist")
                End If

                lcQuery = "INSERT INTO SAM_COMPANIES (CCOMPANY_ID, CCOMPANY_NAME, CADDRESS, CSMTP_ID, CCREATE_BY, DCREATE_DATE, CUPDATE_BY, DUPDATE_DATE) "
                lcQuery += "VALUES ('{0}', N'{1}', N'{2}', '{3}', '{4}', GETDATE(), '{4}', GETDATE())"
                lcQuery = String.Format(lcQuery, poNewEntity.CCOMPANY_ID, _
                                        poNewEntity.CCOMPANY_NAME, _
                                        poNewEntity.CADDRESS, _
                                        poNewEntity.CSMTP_ID, _
                                        poNewEntity.CUSER_ID)

                loDb.SqlExecNonQuery(lcQuery, loConn, False)

                lcQuery = "INSERT INTO GST_LICENSE (CCOMPANY_ID, CCREATE_BY, DCREATE_DATE, CUPDATE_BY, DUPDATE_DATE) "
                lcQuery += "VALUES ('{0}', '{1}', GETDATE(), '{1}', GETDATE())"
                lcQuery = String.Format(lcQuery, poNewEntity.CCOMPANY_ID, _
                                        poNewEntity.CUSER_ID)

                loDb.SqlExecNonQuery(lcQuery, loConn, False)

            ElseIf poCRUDMode = eCRUDMode.EditMode Then
                lcQuery = "UPDATE SAM_COMPANIES "
                lcQuery += "SET "
                lcQuery += "CCOMPANY_NAME = N'{1}', "
                lcQuery += "CADDRESS = N'{2}', "
                lcQuery += "CSMTP_ID = '{3}', "
                lcQuery += "CUPDATE_BY = '{4}', "
                lcQuery += "DUPDATE_DATE = {5} "
                lcQuery += "WHERE CCOMPANY_ID = '{0}'"
                lcQuery = String.Format(lcQuery, poNewEntity.CCOMPANY_ID, _
                                        poNewEntity.CCOMPANY_NAME, _
                                        poNewEntity.CADDRESS, _
                                        poNewEntity.CSMTP_ID, _
                                        poNewEntity.CUSER_ID, getDate(poNewEntity.DDATE))
                loDb.SqlExecNonQuery(lcQuery, loConn, False)

                lcQuery = "UPDATE GST_LICENSE "
                lcQuery += "SET "
                lcQuery += "NTIMEOUT = '{0}', "
                lcQuery += "CUPDATE_BY = '{1}', "
                lcQuery += "DUPDATE_DATE = {2} "
                lcQuery += "WHERE CCOMPANY_ID = '{3}'"
                lcQuery = String.Format(lcQuery, poNewEntity.NTIMEOUT, poNewEntity.CUSER_ID, _
                                        getDate(poNewEntity.DDATE), poNewEntity.CCOMPANY_ID)
                loDb.SqlExecNonQuery(lcQuery, loConn, False)
            End If

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Function getCompList() As List(Of SAM01000GridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of SAM01000GridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "SAM_COMPANIES (NOLOCK)"

            loResult = loDb.SqlExecObjectQuery(Of SAM01000GridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function getCmbLOB() As List(Of SAM01000CmbDTO)
        Dim lcQuery As String
        Dim loResult As List(Of SAM01000CmbDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT CLOB_CODE, CLOB_NAME "
            lcQuery += "FROM "
            lcQuery += "SAM_LOB (NOLOCK)"

            loResult = loDb.SqlExecObjectQuery(Of SAM01000CmbDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function getSMTPList() As List(Of SMTPDTO)
        Dim lcQuery As String
        Dim loResult As List(Of SMTPDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "GSM_SMTP_CONFIG (NOLOCK)"

            loResult = loDb.SqlExecObjectQuery(Of SMTPDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Private Function getDate(pcDate As String) As String
        Return String.Format("CONVERT(DATETIME, '{0}')", pcDate)
    End Function

    Public Function GetImage(pcCompId As String) As SliceDTO
        Dim lcQuery As String
        Dim loResult As New SliceDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection

        Try
            loConn = loDb.GetConnection()

            lcQuery = "SELECT OCOMPANY_LOGO AS DATA, CCOMPANY_ID AS COMPANY_ID "
            lcQuery += "FROM "
            lcQuery += "SAM_COMPANIES (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}'"
            lcQuery = String.Format(lcQuery, pcCompId)

            loResult = loDb.SqlExecObjectQuery(Of SliceDTO)(lcQuery, loConn, False).FirstOrDefault

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Sub SliceFiles(pcUpdateBy As String, poSlice As SliceDTO)
        Dim loException As New R_Exception
        Dim loDb As New R_Db()
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcCmd As String

        Try
            loCmd = loDb.GetCommand()
            lcCmd = "insert into GST_SPLIT_UPLOAD(CCOMPANY_ID,CUSER_ID,CKEY_GUID,ISEQ_NO,ODATA) VALUES('{0}','{1}','{2}',{3},@Data)"
            lcCmd = String.Format(lcCmd, poSlice.COMPANY_ID, pcUpdateBy, poSlice.KEY_GUID, poSlice.SEQ_NO.ToString())
            loCmd.CommandText = lcCmd
            loPar = loDb.GetParameter()
            With loPar
                .ParameterName = "@Data"
                .DbType = DbType.Binary
                .Value = IIf(poSlice.DATA Is Nothing, DBNull.Value, poSlice.DATA)
            End With
            loCmd.Parameters.Add(loPar)
            loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd, True)

        Catch ex As Exception
            loException.Add(ex)
        Finally
            If loCmd IsNot Nothing Then
                loCmd.Parameters.Clear()
                loCmd.Connection = Nothing
                loCmd.Dispose()
                loCmd = Nothing
            End If
            If loDb IsNot Nothing Then
                loDb = Nothing
            End If
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Public Sub SaveImage(pcUpdateBy As String, poSlice As SliceDTO, pcCompId As String)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loCmd As DbCommand
        Dim loPar As DbParameter

        Try
            loConn = loDb.GetConnection()

            lcQuery = "Select dbo.RFN_CombineByte('" + poSlice.COMPANY_ID.Trim + "','" + pcUpdateBy + "','" + poSlice.KEY_GUID.Trim + "') as DATA "
            Dim loHasil As Byte() = loDb.SqlExecObjectQuery(Of SliceDTO)(lcQuery).FirstOrDefault.DATA

            loCmd = loDb.GetCommand()
            lcQuery = "UPDATE SAM_COMPANIES "
            lcQuery += "SET "
            lcQuery += "OCOMPANY_LOGO = @Data, "
            lcQuery += "CUPDATE_BY = '{0}', "
            lcQuery += "DUPDATE_DATE = GETDATE() "
            lcQuery += "WHERE CCOMPANY_ID = '{2}'"
            lcQuery = String.Format(lcQuery, pcUpdateBy, getDate(DateTime.Now.ToString), pcCompId)
            loCmd.CommandText = lcQuery

            loPar = loDb.GetParameter()
            With loPar
                .ParameterName = "@Data"
                .DbType = DbType.Binary
                .Value = IIf(loHasil Is Nothing, DBNull.Value, loHasil)
            End With
            loCmd.Parameters.Add(loPar)
            loDb.SqlExecNonQuery(loConn, loCmd, True)

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Sub SaveDateTime(poNewEntity As SAM01000DTO)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As SAM01000DTO

        Try
            loConn = loDb.GetConnection()

            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "SAM_COMPANIES (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery = String.Format(lcQuery, poNewEntity.CCOMPANY_ID)
            loResult = loDb.SqlExecObjectQuery(Of SAM01000DTO)(lcQuery, loConn, False).FirstOrDefault
            If loResult Is Nothing Then
                Throw New Exception("Company Id " + poNewEntity.CCOMPANY_ID.Trim + " is not exist")
            Else
                lcQuery = "UPDATE SAM_COMPANIES "
                lcQuery += "SET "
                lcQuery += "CDATE_LONG_FORMAT = '{0}', "
                lcQuery += "CDATE_SHORT_FORMAT = '{1}', "
                lcQuery += "CTIME_LONG_FORMAT = '{2}', "
                lcQuery += "CTIME_SHORT_FORMAT = '{3}', "
                lcQuery += "CNUMBER_FORMAT = '{7}', "
                lcQuery += "CREPORT_CULTURE = '{8}', "
                lcQuery += "IDECIMAL_PLACES = '{9}', "
                lcQuery += "IROUNDING_PLACES = '{10}', "
                lcQuery += "CROUNDING_METHOD = '{11}', "
                lcQuery += "LENABLE_SAVE_CONFIRMATION = '{12}', "
                lcQuery += "CUPDATE_BY = '{4}', "
                lcQuery += "DUPDATE_DATE = {5} "
                lcQuery += "WHERE CCOMPANY_ID = '{6}'"
                lcQuery = String.Format(lcQuery, poNewEntity.CDATE_LONG_FORMAT, poNewEntity.CDATE_SHORT_FORMAT, _
                                        poNewEntity.CTIME_LONG_FORMAT, poNewEntity.CTIME_SHORT_FORMAT, _
                                        poNewEntity.CUSER_ID, getDate(poNewEntity.DDATE), poNewEntity.CCOMPANY_ID, _
                                        poNewEntity.CNUMBER_FORMAT, poNewEntity.CREPORT_CULTURE, _
                                        poNewEntity.IDECIMAL_PLACES, poNewEntity.IROUNDING_PLACES, _
                                        poNewEntity.CROUNDING_METHOD, poNewEntity.LENABLE_SAVE_CONFIRMATION)
                loDb.SqlExecNonQuery(lcQuery, loConn, False)
            End If

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Function getLicenseActivation(pcCompId As String) As LicenseDTO
        Dim lcQuery As String
        Dim loResult As LicenseDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT "
            lcQuery += "A.CCOMPANY_ID, B.NTIMEOUT, B.CLICENSE_MODE, B.NLICENSEE, C.CSTART_DATE, C.CEXPIRED_DATE, C.NGRACE_DAYS, C.NWARNING_DAYS "
            lcQuery += "FROM "
            lcQuery += "SAM_COMPANIES A (NOLOCK) "
            lcQuery += "INNER JOIN GST_LICENSE B (NOLOCK) "
            lcQuery += "ON B.CCOMPANY_ID = A.CCOMPANY_ID "
            lcQuery += "INNER JOIN GST_ACTIVATION C (NOLOCK) "
            lcQuery += "ON C.CCOMPANY_ID = A.CCOMPANY_ID "
            lcQuery += "WHERE A.CCOMPANY_ID = '{0}' "
            lcQuery = String.Format(lcQuery, pcCompId)

            loResult = loDb.SqlExecObjectQuery(Of LicenseDTO)(lcQuery).FirstOrDefault
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function
End Class
