﻿Public Class SAM01000GridDTO
    Public Property CCOMPANY_ID As String
    Public Property CCOMPANY_NAME As String
End Class
