﻿Imports R_BackEnd

<Serializable()> _
Public Class SliceDTO
    Inherits R_DTOBase

    Public Property COMPANY_ID As String
    Public Property USER_ID As String
    Public Property USER_NAME As String
    Public Property KEY_GUID As String
    Public Property SEQ_NO As Integer
    Public Property DATA As Byte()
    'Public Property TYPE As Integer '1 - photo, 2- signature
End Class
