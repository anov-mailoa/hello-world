﻿Imports R_BackEnd

<Serializable()> _
Public Class SAM01000CmbDTO
    Inherits R_DTOBase

    Public Property CLOB_CODE As String
    Public Property CLOB_NAME As String
End Class
