﻿Imports R_BackEnd

<Serializable()> _
Public Class LicenseDTO
    Inherits R_DTOBase

    Public Property CCOMPANY_ID As String
    'activation
    Public Property CSTART_DATE As String
    Public Property CEXPIRED_DATE As String
    Public Property NGRACE_DAYS As Integer
    Public Property NWARNING_DAYS As Integer
    'license
    Public Property CLICENSE_MODE As String
    Public Property NLICENSEE As Integer

End Class
