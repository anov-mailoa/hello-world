﻿Imports R_BackEnd

'<Serializable()> _
Public Class SMTPDTO
    Inherits R_DTOBase

    Public Property CSMTP_ID As String
    Public Property CSMTP_SERVER As String
    Public Property CSMTP_PORT As String
    Public Property LSUPPORT_SSL As Boolean
    Public Property CSMTP_CREDENTIAL_USER As String
End Class
