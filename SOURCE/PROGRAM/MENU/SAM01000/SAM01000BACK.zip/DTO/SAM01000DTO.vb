﻿Imports R_BackEnd

<Serializable()> _
Public Class SAM01000DTO
    Inherits R_DTOBase

    Public Property CCOMPANY_ID As String
    Public Property CCOMPANY_NAME As String
    Public Property CADDRESS As String
    Public Property CZIP_CODE As String
    Public Property CCITY As String
    Public Property CCOUNTRY As String
    Public Property CPHONE_1 As String
    Public Property CPHONE_2 As String
    Public Property CFAX_NO As String
    Public Property CLOB_CODE As String
    Public Property CWEB_SITE As String
    Public Property CTAX_NAME As String
    Public Property CTAX_REGISTER_ID As String
    Public Property DTAX_REGISTER_DATE As Nullable(Of Date)
    Public Property CTAX_BUSINESS_TYPE As String
    Public Property CTAX_BUSINESS_NAME As String
    'Public Property CCOMPANY_STATUS As String
    'Public Property INO_USERS As Integer
    'Public Property BREGISTERED_ID As Byte()
    'Public Property DREGISTERED_DATE As Nullable(Of DateTime)
    'Public Property DEXPIRED_DATE As Nullable(Of Date)
    Public Property CLOCAL_CURRENCY As String
    Public Property CBASE_CURRENCY As String
    'Public Property CPERIOD As String
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)
    Public Property CSMTP_ID As String
    Public Property CDATE_LONG_FORMAT As String
    Public Property CDATE_SHORT_FORMAT As String
    Public Property CTIME_LONG_FORMAT As String
    Public Property CTIME_SHORT_FORMAT As String
    Public Property CNUMBER_FORMAT As String
    Public Property CREPORT_CULTURE As String
    Public Property NTIMEOUT As Integer

    Public Property IDECIMAL_PLACES As Integer
    Public Property IROUNDING_PLACES As Integer
    Public Property CROUNDING_METHOD As String

    Public Property LENABLE_SAVE_CONFIRMATION As Boolean

    Public Property CUSER_ID As String
    Public Property DDATE As String
End Class
