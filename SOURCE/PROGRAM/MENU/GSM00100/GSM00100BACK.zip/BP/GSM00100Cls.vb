﻿Imports R_Common
Imports R_BackEnd
Imports System.Data.Common

Public Class GSM00100Cls
    Inherits R_BusinessObject(Of GSM00100DTO)

    Protected Overrides Sub R_Deleting(poEntity As GSM00100DTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "DELETE GSM_SMTP_CONFIG "
            lcQuery += "WHERE "
            lcQuery += "CSMTP_ID = '{0}' "
            lcQuery = String.Format(lcQuery, poEntity.CSMTP_ID)

            loDb.SqlExecNonQuery(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As GSM00100DTO) As GSM00100DTO
        Dim lcQuery As String
        Dim loResult As GSM00100DTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "GSM_SMTP_CONFIG (NOLOCK) "
            lcQuery += "WHERE CSMTP_ID = '{0}' "
            lcQuery = String.Format(lcQuery, poEntity.CSMTP_ID)

            loResult = loDb.SqlExecObjectQuery(Of GSM00100DTO)(lcQuery).FirstOrDefault
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As GSM00100DTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As GSM00100DTO

        Try
            loConn = loDb.GetConnection()

            If poCRUDMode = eCRUDMode.AddMode Then
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "GSM_SMTP_CONFIG (NOLOCK) "
                lcQuery += "WHERE CSMTP_ID = '{0}' "
                lcQuery = String.Format(lcQuery, poNewEntity.CSMTP_ID)

                loResult = loDb.SqlExecObjectQuery(Of GSM00100DTO)(lcQuery, loConn, False).FirstOrDefault
                If loResult IsNot Nothing Then
                    Throw New Exception("SMTP ID " + poNewEntity.CSMTP_ID.Trim + " Already Exist")
                End If

                lcQuery = "INSERT INTO GSM_SMTP_CONFIG (CSMTP_ID, CSMTP_SERVER, CSMTP_PORT, LSUPPORT_SSL, CSMTP_CREDENTIAL_USER, CSMTP_CREDENTIAL_PASSWORD, CGENERAL_EMAIL_ADDRESS) "
                lcQuery += "VALUES('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}')"
                lcQuery = String.Format(lcQuery, poNewEntity.CSMTP_ID, poNewEntity.CSMTP_SERVER, poNewEntity.CSMTP_PORT, poNewEntity.LSUPPORT_SSL, poNewEntity.CSMTP_CREDENTIAL_USER, poNewEntity.CSMTP_CREDENTIAL_PASSWORD, poNewEntity.CGENERAL_EMAIL_ADDRESS)
                loDb.SqlExecNonQuery(lcQuery, loConn, False)

            ElseIf poCRUDMode = eCRUDMode.EditMode Then
                lcQuery = "UPDATE GSM_SMTP_CONFIG "
                lcQuery += "SET "
                lcQuery += "CSMTP_SERVER = '{0}', "
                lcQuery += "CSMTP_PORT = '{1}', "
                lcQuery += "LSUPPORT_SSL = '{2}', "
                lcQuery += "CSMTP_CREDENTIAL_USER = '{3}', "
                lcQuery += "CSMTP_CREDENTIAL_PASSWORD = '{4}', "
                lcQuery += "CGENERAL_EMAIL_ADDRESS = '{6}' "
                lcQuery += "WHERE CSMTP_ID = '{5}'"
                lcQuery = String.Format(lcQuery, poNewEntity.CSMTP_SERVER, poNewEntity.CSMTP_PORT, poNewEntity.LSUPPORT_SSL, poNewEntity.CSMTP_CREDENTIAL_USER, poNewEntity.CSMTP_CREDENTIAL_PASSWORD, poNewEntity.CSMTP_ID, poNewEntity.CGENERAL_EMAIL_ADDRESS)

                loDb.SqlExecNonQuery(lcQuery, loConn, False)
            End If

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Function getSMTPList() As List(Of GSM00100DTOnon)
        Dim lcQuery As String
        Dim loResult As List(Of GSM00100DTOnon)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "GSM_SMTP_CONFIG (NOLOCK)"

            loResult = loDb.SqlExecObjectQuery(Of GSM00100DTOnon)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function CheckDelete(poParam As GSM00100DTO) As Boolean
        Dim lcQuery As String
        Dim loResult As GSM00100DTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loRtn As Boolean

        Try
            lcQuery = "SELECT CSMTP_ID "
            lcQuery += "FROM "
            lcQuery += "SAM_COMPANIES (NOLOCK) "
            lcQuery += "WHERE CSMTP_ID = '{0}' "
            lcQuery = String.Format(lcQuery, poParam.CSMTP_ID)

            loResult = loDb.SqlExecObjectQuery(Of GSM00100DTO)(lcQuery).FirstOrDefault
            If loResult IsNot Nothing Then
                loRtn = True
            End If
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loRtn
    End Function
End Class
