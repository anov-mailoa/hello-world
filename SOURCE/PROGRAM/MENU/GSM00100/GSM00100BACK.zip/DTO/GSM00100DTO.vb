﻿Imports R_BackEnd

<Serializable()> _
Public Class GSM00100DTO
    Inherits R_DTOBase

    Public Property CSMTP_ID As String
    Public Property CSMTP_SERVER As String
    Public Property CSMTP_PORT As String
    Public Property LSUPPORT_SSL As Boolean
    Public Property CSMTP_CREDENTIAL_USER As String
    Public Property CSMTP_CREDENTIAL_PASSWORD As String
    Public Property CGENERAL_EMAIL_ADDRESS As String
End Class
