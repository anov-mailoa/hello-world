﻿Imports R_FrontEnd
Imports GSM00100Front.GSM00100ServiceRef
Imports GSM00100Front.GSM00100StreamingServiceRef
Imports R_Common
Imports System.ServiceModel.Channels
Imports ClientHelper
Imports GSM00100FrontResources
Imports System.Text.RegularExpressions
Imports Telerik.WinControls.UI

Public Class GSM00100

#Region " VARIABLE "
    Dim C_ServiceName As String = "GSM00100Service/GSM00100Service.svc"
    Dim C_ServiceNameStream As String = "GSM00100Service/GSM00100StreamingService/GSM00100StreamingService.svc"
    Dim _CUSERID As String
#End Region

    Private Sub GSM00100_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim loEx As New R_Exception
        Dim oRes As New Resources_Dummy_Class

        Try
            _CUSERID = U_GlobalVar.UserId

            gvSMTP.R_RefreshGrid(New GSM00100DTO)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSMTP_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvSMTP.R_ServiceGetListRecord
        Dim loServiceStream As GSM00100StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IGSM00100StreamingService, GSM00100StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of GSM00100DTOnon)
        Dim loListEntity As New List(Of GSM00100DTO)

        Try
            loRtn = loServiceStream.getSMTPList()
            loStreaming = R_StreamUtility(Of GSM00100DTOnon).ReadFromMessage(loRtn)

            For Each loDto As GSM00100DTOnon In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New GSM00100DTO With {._CSMTP_ID = loDto.CSMTP_ID,
                                                           ._CSMTP_SERVER = loDto.CSMTP_SERVER,
                                                           ._CSMTP_PORT = loDto.CSMTP_PORT,
                                                           ._LSUPPORT_SSL = loDto.LSUPPORT_SSL,
                                                           ._CSMTP_CREDENTIAL_USER = loDto.CSMTP_CREDENTIAL_USER,
                                                           ._CSMTP_CREDENTIAL_PASSWORD = loDto.CSMTP_CREDENTIAL_PASSWORD,
                                                           ._CGENERAL_EMAIL_ADDRESS = loDto.CGENERAL_EMAIL_ADDRESS})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

#Region "CONDUCTOR"
    Private Sub conDetail_R_AfterAdd(ByRef poEntity As Object) Handles conDetail.R_AfterAdd
        With CType(poEntity, GSM00100DTO)
            ._LSUPPORT_SSL = True
        End With
    End Sub

    Private Sub conDetail_R_BeforeCancel(ByRef poEntity As Object, peMode As R_FrontEnd.R_Conductor.e_Mode, ByRef plCancel As Boolean) Handles conDetail.R_BeforeCancel
        For Each ctrl As Windows.Forms.Control In R_RadGroupBox1.Controls
            If TypeOf (ctrl) Is R_RadTextBox Then
                errProvider.SetError(ctrl, "")
            End If
        Next
    End Sub

    Private Sub conDetail_R_BeforeDelete(poEntity As Object, ByRef plCancel As Boolean) Handles conDetail.R_BeforeDelete
        Dim loService As GSM00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IGSM00100Service, GSM00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            If loService.CheckDelete(poEntity) Then
                Throw New Exception(getResMsg("_err009"))
            End If
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub conDetail_R_ServiceDelete(poEntity As Object) Handles conDetail.R_ServiceDelete
        Dim loService As GSM00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IGSM00100Service, GSM00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub conDetail_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles conDetail.R_ServiceGetRecord
        Dim loService As GSM00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IGSM00100Service, GSM00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub conDetail_R_ServiceSave(poEntity As Object, peMode As R_FrontEnd.R_Conductor.e_Mode, ByRef poEntityResult As Object) Handles conDetail.R_ServiceSave
        Dim loService As GSM00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IGSM00100Service, GSM00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub conDetail_R_Validation(poEntity As Object, peMode As R_FrontEnd.R_Conductor.e_Mode, ByRef plCancel As Boolean) Handles conDetail.R_Validation
        If String.IsNullOrWhiteSpace(txtSMTPID.Text) Then
            errProvider.SetError(txtSMTPID, getResMsg("_err001"))
            'plCancel = True
        Else
            errProvider.SetError(txtSMTPID, "")
        End If

        If String.IsNullOrWhiteSpace(txtServer.Text) Then
            errProvider.SetError(txtServer, getResMsg("_err002"))
            'plCancel = True
        Else
            errProvider.SetError(txtServer, "")
        End If

        If String.IsNullOrWhiteSpace(txtPort.Text) Then
            errProvider.SetError(txtPort, getResMsg("_err003"))
            'plCancel = True
        Else
            errProvider.SetError(txtPort, "")
        End If

        If String.IsNullOrWhiteSpace(txtUser.Text) Then
            errProvider.SetError(txtUser, getResMsg("_err004"))
            'plCancel = True
        Else
            errProvider.SetError(txtUser, "")
        End If

        If String.IsNullOrWhiteSpace(txtPass.Text) Then
            errProvider.SetError(txtPass, getResMsg("_err006"))
            'plCancel = True
        Else
            errProvider.SetError(txtPass, "")
        End If

        If String.IsNullOrWhiteSpace(txtGeneralEmail.Text) Then
            errProvider.SetError(txtGeneralEmail, getResMsg("_err007"))
            'plCancel = True
        Else
            If IsEmail(txtGeneralEmail.Text) = False Then
                errProvider.SetError(txtGeneralEmail, getResMsg("_err008"))
                'plCancel = True
            Else
                errProvider.SetError(txtGeneralEmail, "")
            End If
        End If

        'Me.R_DisplayException(errProvider.GetErrorList)
    End Sub
#End Region

    Private Sub GSM00100_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

    Private Function IsEmail(ByVal email As String) As Boolean
        Dim pattern As String = "^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"
        Dim emailAddressMatch As Match = Regex.Match(email, pattern)
        If emailAddressMatch.Success Then
            Return True
        Else
            Return False
        End If
    End Function

    Private Sub txtPort_KeyPress(sender As Object, e As System.Windows.Forms.KeyPressEventArgs) Handles txtPort.KeyPress
        If Asc(e.KeyChar) <> 8 Then
            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                e.Handled = True
            End If
        End If
    End Sub

    Private Function getResMsg(pcErrNo As String) As String
        Return R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), pcErrNo).ToString
    End Function
End Class
