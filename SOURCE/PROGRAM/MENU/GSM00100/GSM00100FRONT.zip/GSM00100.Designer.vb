﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class GSM00100
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn1 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.gvSMTP = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvSMTP = New System.Windows.Forms.BindingSource(Me.components)
        Me.conDetail = New R_FrontEnd.R_Conductor(Me.components)
        Me.bsDetail = New System.Windows.Forms.BindingSource(Me.components)
        Me.R_RadGroupBox1 = New R_FrontEnd.R_RadGroupBox(Me.components)
        Me.txtGeneralEmail = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.R_RadLabel6 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtPass = New R_FrontEnd.R_RadPasswordBox()
        Me.btnCancel = New R_FrontEnd.R_Cancel(Me.components)
        Me.btnDelete = New R_FrontEnd.R_Delete(Me.components)
        Me.btnEdit = New R_FrontEnd.R_Edit(Me.components)
        Me.btnAdd = New R_FrontEnd.R_Add(Me.components)
        Me.btnSave = New R_FrontEnd.R_Save(Me.components)
        Me.txtUser = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtPort = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtServer = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtSMTPID = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.R_RadLabel5 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel4 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.cbSSL = New R_FrontEnd.R_RadCheckBox(Me.components)
        Me.R_RadLabel3 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel2 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel1 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.errProvider = New R_FrontEnd.R_ErrorProvider(Me.components)
        CType(Me.gvSMTP, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvSMTP.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvSMTP, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conDetail, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsDetail, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadGroupBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.R_RadGroupBox1.SuspendLayout()
        CType(Me.txtGeneralEmail, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPass, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnCancel, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnDelete, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnEdit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnAdd, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnSave, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtUser, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtPort, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtServer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSMTPID, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cbSSL, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.errProvider, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'gvSMTP
        '
        Me.gvSMTP.Location = New System.Drawing.Point(12, 12)
        '
        '
        '
        Me.gvSMTP.MasterTemplate.AllowAddNewRow = False
        Me.gvSMTP.MasterTemplate.AllowDeleteRow = False
        Me.gvSMTP.MasterTemplate.AllowEditRow = False
        Me.gvSMTP.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn1.FieldName = "_CSMTP_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CSMTP_ID"
        R_GridViewTextBoxColumn1.IsAutoGenerated = True
        R_GridViewTextBoxColumn1.MaxWidth = 100
        R_GridViewTextBoxColumn1.MinWidth = 100
        R_GridViewTextBoxColumn1.Name = "_CSMTP_ID"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CSMTP_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 100
        R_GridViewTextBoxColumn2.FieldName = "_CSMTP_SERVER"
        R_GridViewTextBoxColumn2.HeaderText = "_CSMTP_SERVER"
        R_GridViewTextBoxColumn2.IsAutoGenerated = True
        R_GridViewTextBoxColumn2.MaxWidth = 150
        R_GridViewTextBoxColumn2.MinWidth = 150
        R_GridViewTextBoxColumn2.Name = "_CSMTP_SERVER"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CSMTP_SERVER"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 150
        R_GridViewTextBoxColumn3.FieldName = "_CSMTP_PORT"
        R_GridViewTextBoxColumn3.HeaderText = "_CSMTP_PORT"
        R_GridViewTextBoxColumn3.IsAutoGenerated = True
        R_GridViewTextBoxColumn3.MaxWidth = 100
        R_GridViewTextBoxColumn3.MinWidth = 100
        R_GridViewTextBoxColumn3.Name = "_CSMTP_PORT"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CSMTP_PORT"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 100
        R_GridViewCheckBoxColumn1.FieldName = "_LSUPPORT_SSL"
        R_GridViewCheckBoxColumn1.HeaderText = "_LSUPPORT_SSL"
        R_GridViewCheckBoxColumn1.IsAutoGenerated = True
        R_GridViewCheckBoxColumn1.MaxWidth = 100
        R_GridViewCheckBoxColumn1.MinWidth = 100
        R_GridViewCheckBoxColumn1.Name = "_LSUPPORT_SSL"
        R_GridViewCheckBoxColumn1.R_ResourceId = "_LSUPPORT_SSL"
        R_GridViewCheckBoxColumn1.Width = 100
        R_GridViewTextBoxColumn4.FieldName = "_CSMTP_CREDENTIAL_USER"
        R_GridViewTextBoxColumn4.HeaderText = "_CSMTP_CREDENTIAL_USER"
        R_GridViewTextBoxColumn4.IsAutoGenerated = True
        R_GridViewTextBoxColumn4.MaxWidth = 150
        R_GridViewTextBoxColumn4.MinWidth = 150
        R_GridViewTextBoxColumn4.Name = "_CSMTP_CREDENTIAL_USER"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CSMTP_CREDENTIAL_USER"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 150
        R_GridViewTextBoxColumn5.FieldName = "_CGENERAL_EMAIL_ADDRESS"
        R_GridViewTextBoxColumn5.HeaderText = "_CGENERAL_EMAIL_ADDRESS"
        R_GridViewTextBoxColumn5.MaxWidth = 150
        R_GridViewTextBoxColumn5.MinWidth = 150
        R_GridViewTextBoxColumn5.Name = "_CGENERAL_EMAIL_ADDRESS"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CGENERAL_EMAIL_ADDRESS"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 150
        Me.gvSMTP.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewCheckBoxColumn1, R_GridViewTextBoxColumn4, R_GridViewTextBoxColumn5})
        Me.gvSMTP.MasterTemplate.DataSource = Me.bsGvSMTP
        Me.gvSMTP.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvSMTP.MasterTemplate.EnableFiltering = True
        Me.gvSMTP.MasterTemplate.EnableGrouping = False
        Me.gvSMTP.MasterTemplate.ShowFilteringRow = False
        Me.gvSMTP.MasterTemplate.ShowGroupedColumns = True
        Me.gvSMTP.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvSMTP.Name = "gvSMTP"
        Me.gvSMTP.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvSMTP.R_ConductorGridSource = Nothing
        Me.gvSMTP.R_ConductorSource = Me.conDetail
        Me.gvSMTP.R_DataAdded = False
        Me.gvSMTP.R_EnableOTHER = True
        Me.gvSMTP.R_GridType = R_FrontEnd.R_eGridType.Navigator
        Me.gvSMTP.R_NewRowText = Nothing
        Me.gvSMTP.ShowHeaderCellButtons = True
        Me.gvSMTP.Size = New System.Drawing.Size(704, 166)
        Me.gvSMTP.TabIndex = 0
        Me.gvSMTP.Text = "R_RadGridView1"
        '
        'bsGvSMTP
        '
        Me.bsGvSMTP.DataSource = GetType(GSM00100Front.GSM00100ServiceRef.GSM00100DTO)
        '
        'conDetail
        '
        Me.conDetail.R_BindingSource = Me.bsDetail
        Me.conDetail.R_ConductorParent = Nothing
        Me.conDetail.R_DisableDeleteConfirmation = True
        Me.conDetail.R_IsHeader = True
        Me.conDetail.R_RadGroupBox = Nothing
        '
        'bsDetail
        '
        Me.bsDetail.DataSource = GetType(GSM00100Front.GSM00100ServiceRef.GSM00100DTO)
        '
        'R_RadGroupBox1
        '
        Me.R_RadGroupBox1.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping
        Me.R_RadGroupBox1.Controls.Add(Me.txtGeneralEmail)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel6)
        Me.R_RadGroupBox1.Controls.Add(Me.txtPass)
        Me.R_RadGroupBox1.Controls.Add(Me.btnCancel)
        Me.R_RadGroupBox1.Controls.Add(Me.btnDelete)
        Me.R_RadGroupBox1.Controls.Add(Me.btnEdit)
        Me.R_RadGroupBox1.Controls.Add(Me.btnAdd)
        Me.R_RadGroupBox1.Controls.Add(Me.btnSave)
        Me.R_RadGroupBox1.Controls.Add(Me.txtUser)
        Me.R_RadGroupBox1.Controls.Add(Me.txtPort)
        Me.R_RadGroupBox1.Controls.Add(Me.txtServer)
        Me.R_RadGroupBox1.Controls.Add(Me.txtSMTPID)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel5)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel4)
        Me.R_RadGroupBox1.Controls.Add(Me.cbSSL)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel3)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel2)
        Me.R_RadGroupBox1.Controls.Add(Me.R_RadLabel1)
        Me.R_RadGroupBox1.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadGroupBox1.HeaderText = "SMTP Detail"
        Me.R_RadGroupBox1.Location = New System.Drawing.Point(13, 193)
        Me.R_RadGroupBox1.Name = "R_RadGroupBox1"
        Me.R_RadGroupBox1.R_ConductorGridSource = Nothing
        Me.R_RadGroupBox1.R_ConductorSource = Nothing
        Me.R_RadGroupBox1.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadGroupBox1.R_ResourceId = "_HeaderGroupBox"
        Me.R_RadGroupBox1.Size = New System.Drawing.Size(703, 170)
        Me.R_RadGroupBox1.TabIndex = 1
        Me.R_RadGroupBox1.Text = "SMTP Detail"
        '
        'txtGeneralEmail
        '
        Me.txtGeneralEmail.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_CGENERAL_EMAIL_ADDRESS", True))
        Me.txtGeneralEmail.Location = New System.Drawing.Point(472, 85)
        Me.txtGeneralEmail.Name = "txtGeneralEmail"
        Me.txtGeneralEmail.R_ConductorGridSource = Nothing
        Me.txtGeneralEmail.R_ConductorSource = Me.conDetail
        Me.txtGeneralEmail.R_EnableADD = True
        Me.txtGeneralEmail.R_EnableEDIT = True
        Me.txtGeneralEmail.R_UDT = Nothing
        Me.txtGeneralEmail.Size = New System.Drawing.Size(217, 20)
        Me.txtGeneralEmail.TabIndex = 11
        '
        'R_RadLabel6
        '
        Me.R_RadLabel6.AutoSize = False
        Me.R_RadLabel6.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel6.Location = New System.Drawing.Point(346, 86)
        Me.R_RadLabel6.Name = "R_RadLabel6"
        Me.R_RadLabel6.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel6.R_ResourceId = "_CGENERAL_EMAIL_ADDRESS"
        Me.R_RadLabel6.Size = New System.Drawing.Size(120, 18)
        Me.R_RadLabel6.TabIndex = 17
        Me.R_RadLabel6.Text = "General Email Address"
        '
        'txtPass
        '
        Me.txtPass.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_CSMTP_CREDENTIAL_PASSWORD", True))
        Me.txtPass.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txtPass.Location = New System.Drawing.Point(472, 54)
        Me.txtPass.Name = "txtPass"
        Me.txtPass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(8226)
        Me.txtPass.R_ConductorGridSource = Nothing
        Me.txtPass.R_ConductorSource = Me.conDetail
        Me.txtPass.R_EnableADD = True
        Me.txtPass.R_EnableEDIT = True
        Me.txtPass.R_UDT = Nothing
        Me.txtPass.Size = New System.Drawing.Size(217, 25)
        Me.txtPass.TabIndex = 10
        '
        'btnCancel
        '
        Me.btnCancel.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnCancel.Location = New System.Drawing.Point(588, 142)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.R_ConductorSource = Me.conDetail
        Me.btnCancel.R_ResourceId = "Cancel"
        Me.btnCancel.Size = New System.Drawing.Size(110, 24)
        Me.btnCancel.TabIndex = 15
        Me.btnCancel.Text = "Cancel"
        '
        'btnDelete
        '
        Me.btnDelete.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnDelete.Location = New System.Drawing.Point(252, 141)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.R_ConductorSource = Me.conDetail
        Me.btnDelete.R_ResourceId = "Delete"
        Me.btnDelete.Size = New System.Drawing.Size(110, 24)
        Me.btnDelete.TabIndex = 14
        Me.btnDelete.Text = "Delete"
        '
        'btnEdit
        '
        Me.btnEdit.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnEdit.Location = New System.Drawing.Point(136, 141)
        Me.btnEdit.Name = "btnEdit"
        Me.btnEdit.R_ConductorSource = Me.conDetail
        Me.btnEdit.R_ResourceId = Nothing
        Me.btnEdit.Size = New System.Drawing.Size(110, 24)
        Me.btnEdit.TabIndex = 13
        Me.btnEdit.Text = "&Edit"
        '
        'btnAdd
        '
        Me.btnAdd.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnAdd.Location = New System.Drawing.Point(20, 141)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.R_ConductorSource = Me.conDetail
        Me.btnAdd.R_ResourceId = Nothing
        Me.btnAdd.Size = New System.Drawing.Size(110, 24)
        Me.btnAdd.TabIndex = 12
        Me.btnAdd.Text = "&Add New"
        '
        'btnSave
        '
        Me.btnSave.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnSave.Location = New System.Drawing.Point(472, 142)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.R_ConductorSource = Me.conDetail
        Me.btnSave.R_ResourceId = "Save"
        Me.btnSave.Size = New System.Drawing.Size(110, 24)
        Me.btnSave.TabIndex = 13
        Me.btnSave.Text = "Save"
        '
        'txtUser
        '
        Me.txtUser.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_CSMTP_CREDENTIAL_USER", True))
        Me.txtUser.Location = New System.Drawing.Point(472, 31)
        Me.txtUser.Name = "txtUser"
        Me.txtUser.R_ConductorGridSource = Nothing
        Me.txtUser.R_ConductorSource = Me.conDetail
        Me.txtUser.R_EnableADD = True
        Me.txtUser.R_EnableEDIT = True
        Me.txtUser.R_UDT = Nothing
        Me.txtUser.Size = New System.Drawing.Size(217, 20)
        Me.txtUser.TabIndex = 9
        '
        'txtPort
        '
        Me.txtPort.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_CSMTP_PORT", True))
        Me.txtPort.Location = New System.Drawing.Point(111, 84)
        Me.txtPort.Name = "txtPort"
        Me.txtPort.R_ConductorGridSource = Nothing
        Me.txtPort.R_ConductorSource = Me.conDetail
        Me.txtPort.R_EnableADD = True
        Me.txtPort.R_EnableEDIT = True
        Me.txtPort.R_UDT = Nothing
        Me.txtPort.Size = New System.Drawing.Size(217, 20)
        Me.txtPort.TabIndex = 8
        '
        'txtServer
        '
        Me.txtServer.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_CSMTP_SERVER", True))
        Me.txtServer.Location = New System.Drawing.Point(111, 55)
        Me.txtServer.Name = "txtServer"
        Me.txtServer.R_ConductorGridSource = Nothing
        Me.txtServer.R_ConductorSource = Me.conDetail
        Me.txtServer.R_EnableADD = True
        Me.txtServer.R_EnableEDIT = True
        Me.txtServer.R_UDT = Nothing
        Me.txtServer.Size = New System.Drawing.Size(217, 20)
        Me.txtServer.TabIndex = 7
        '
        'txtSMTPID
        '
        Me.txtSMTPID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsDetail, "_CSMTP_ID", True))
        Me.txtSMTPID.Location = New System.Drawing.Point(111, 31)
        Me.txtSMTPID.Name = "txtSMTPID"
        Me.txtSMTPID.R_ConductorGridSource = Nothing
        Me.txtSMTPID.R_ConductorSource = Me.conDetail
        Me.txtSMTPID.R_EnableADD = True
        Me.txtSMTPID.R_UDT = Nothing
        Me.txtSMTPID.Size = New System.Drawing.Size(119, 20)
        Me.txtSMTPID.TabIndex = 6
        '
        'R_RadLabel5
        '
        Me.R_RadLabel5.AutoSize = False
        Me.R_RadLabel5.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel5.Location = New System.Drawing.Point(346, 56)
        Me.R_RadLabel5.Name = "R_RadLabel5"
        Me.R_RadLabel5.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel5.R_ResourceId = "_CSMTP_CREDENTIAL_PASS"
        Me.R_RadLabel5.Size = New System.Drawing.Size(120, 18)
        Me.R_RadLabel5.TabIndex = 5
        Me.R_RadLabel5.Text = "Credential Password"
        '
        'R_RadLabel4
        '
        Me.R_RadLabel4.AutoSize = False
        Me.R_RadLabel4.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel4.Location = New System.Drawing.Point(346, 32)
        Me.R_RadLabel4.Name = "R_RadLabel4"
        Me.R_RadLabel4.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel4.R_ResourceId = "_CSMTP_CREDENTIAL_USER"
        Me.R_RadLabel4.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel4.TabIndex = 4
        Me.R_RadLabel4.Text = "Credential User"
        '
        'cbSSL
        '
        Me.cbSSL.DataBindings.Add(New System.Windows.Forms.Binding("IsChecked", Me.bsDetail, "_LSUPPORT_SSL", True))
        Me.cbSSL.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cbSSL.Location = New System.Drawing.Point(609, 111)
        Me.cbSSL.Name = "cbSSL"
        Me.cbSSL.R_ConductorGridSource = Nothing
        Me.cbSSL.R_ConductorSource = Me.conDetail
        Me.cbSSL.R_EnableADD = True
        Me.cbSSL.R_EnableEDIT = True
        Me.cbSSL.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cbSSL.R_ResourceId = "_LSUPPORT_SSL"
        Me.cbSSL.Size = New System.Drawing.Size(80, 18)
        Me.cbSSL.TabIndex = 12
        Me.cbSSL.Text = "Support SSL"
        '
        'R_RadLabel3
        '
        Me.R_RadLabel3.AutoSize = False
        Me.R_RadLabel3.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel3.Location = New System.Drawing.Point(20, 85)
        Me.R_RadLabel3.Name = "R_RadLabel3"
        Me.R_RadLabel3.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel3.R_ResourceId = "_CSMTP_PORT"
        Me.R_RadLabel3.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel3.TabIndex = 2
        Me.R_RadLabel3.Text = "SMTP Port"
        '
        'R_RadLabel2
        '
        Me.R_RadLabel2.AutoSize = False
        Me.R_RadLabel2.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel2.Location = New System.Drawing.Point(20, 56)
        Me.R_RadLabel2.Name = "R_RadLabel2"
        Me.R_RadLabel2.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel2.R_ResourceId = "_CSMTP_SERVER"
        Me.R_RadLabel2.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel2.TabIndex = 1
        Me.R_RadLabel2.Text = "SMTP Server"
        '
        'R_RadLabel1
        '
        Me.R_RadLabel1.AutoSize = False
        Me.R_RadLabel1.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel1.Location = New System.Drawing.Point(20, 32)
        Me.R_RadLabel1.Name = "R_RadLabel1"
        Me.R_RadLabel1.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel1.R_ResourceId = "_CSMTP_ID"
        Me.R_RadLabel1.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel1.TabIndex = 0
        Me.R_RadLabel1.Text = "SMTP ID"
        '
        'errProvider
        '
        Me.errProvider.ContainerControl = Me
        Me.errProvider.R_ConductorSource = Me.conDetail
        '
        'GSM00100
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(728, 375)
        Me.Controls.Add(Me.R_RadGroupBox1)
        Me.Controls.Add(Me.gvSMTP)
        Me.Name = "GSM00100"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.gvSMTP.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvSMTP, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvSMTP, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conDetail, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsDetail, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadGroupBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.R_RadGroupBox1.ResumeLayout(False)
        Me.R_RadGroupBox1.PerformLayout()
        CType(Me.txtGeneralEmail, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPass, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnCancel, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnDelete, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnEdit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnAdd, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnSave, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtUser, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtPort, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtServer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSMTPID, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cbSSL, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.errProvider, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents gvSMTP As R_FrontEnd.R_RadGridView
    Friend WithEvents R_RadGroupBox1 As R_FrontEnd.R_RadGroupBox
    Friend WithEvents R_RadLabel5 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel4 As R_FrontEnd.R_RadLabel
    Friend WithEvents cbSSL As R_FrontEnd.R_RadCheckBox
    Friend WithEvents R_RadLabel3 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel2 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel1 As R_FrontEnd.R_RadLabel
    Friend WithEvents txtUser As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtPort As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtServer As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtSMTPID As R_FrontEnd.R_RadTextBox
    Friend WithEvents btnCancel As R_FrontEnd.R_Cancel
    Friend WithEvents btnDelete As R_FrontEnd.R_Delete
    Friend WithEvents btnEdit As R_FrontEnd.R_Edit
    Friend WithEvents btnAdd As R_FrontEnd.R_Add
    Friend WithEvents btnSave As R_FrontEnd.R_Save
    Friend WithEvents conDetail As R_FrontEnd.R_Conductor
    Friend WithEvents bsGvSMTP As System.Windows.Forms.BindingSource
    Friend WithEvents bsDetail As System.Windows.Forms.BindingSource
    Friend WithEvents txtPass As R_FrontEnd.R_RadPasswordBox
    Friend WithEvents errProvider As R_FrontEnd.R_ErrorProvider
    Friend WithEvents txtGeneralEmail As R_FrontEnd.R_RadTextBox
    Friend WithEvents R_RadLabel6 As R_FrontEnd.R_RadLabel

End Class
