﻿Imports R_BackEnd
Imports R_Common
Imports System.Data.Common
Imports ServerHelper.General
Imports System.Transactions
Imports System.IO
Imports Ionic.Zip

Public Class CSM00310Cls
    Inherits R_BusinessObject(Of CSM00310DTO)

#Region " VARIABLES "
    Private Shared C_ZipPath As String = "D:\RealCode\Temp\Zips"
    Private Shared C_RootPath As String = "D:\RealCodeRelease"
#End Region

    Public Function GetProgramCustList(poKey As CSM00310KeyDTO) As List(Of CSM00310GridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00310GridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CSM_PROGRAMS_CUST (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                lcQuery += "AND CCUSTOMER_CODE = '{3}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP, .CCUSTOMER_CODE)
            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00310GridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetStandardProgramList(poKey As CSM00310KeyDTO) As List(Of CSM00310ItemListDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00310ItemListDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "SELECT A.CPROGRAM_ID AS CITEM_ID, A.CPROGRAM_NAME AS CITEM_NAME "
                lcQuery += "FROM CSM_PROGRAMS A (NOLOCK) "
                lcQuery += "LEFT JOIN CSM_PROGRAMS_CUST B (NOLOCK) "
                lcQuery += "ON B.CCOMPANY_ID = A.CCOMPANY_ID "
                lcQuery += "AND B.CAPPS_CODE = A.CAPPS_CODE "
                lcQuery += "AND B.CATTRIBUTE_GROUP = A.CATTRIBUTE_GROUP "
                lcQuery += "AND B.CATTRIBUTE_ID = A.CATTRIBUTE_ID "
                lcQuery += "AND B.CPROGRAM_ID = A.CPROGRAM_ID "
                lcQuery += "AND B.CCUSTOMER_CODE = '{4}' "
                lcQuery += "WHERE A.CCOMPANY_ID = '{0}' "
                lcQuery += "AND A.CAPPS_CODE = '{1}' "
                lcQuery += "AND A.CATTRIBUTE_GROUP = '{2}' "
                lcQuery += "AND A.CATTRIBUTE_ID = '{3}' "
                lcQuery += "AND B.CPROGRAM_ID IS NULL "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CCUSTOMER_CODE)
            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00310ItemListDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetCustList(pcCompany_ID As String) As List(Of CSM00310CustListDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00310CustListDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT CCUSTOMER_CODE, "
            lcQuery += "RTRIM(CCUSTOMER_NAME) AS CCUSTOMER_NAME "
            lcQuery += "FROM "
            lcQuery += "LAM_CUSTOMER (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery = String.Format(lcQuery, pcCompany_ID)

            loResult = loDb.SqlExecObjectQuery(Of CSM00310CustListDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Sub AddFromStandard(poProgramList As List(Of CSM00310AddStdDTO))
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db
        Dim lcQuery As String
        Dim loConn As DbConnection
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcRtn As String = "OK"

        Try
            ' mark selected issues
            For Each program As CSM00310AddStdDTO In poProgramList
                'update issue schedule with characters &&&
                With program
                    lcQuery = "INSERT INTO CSM_PROGRAMS_CUST ("
                    lcQuery += "CCOMPANY_ID, "
                    lcQuery += "CAPPS_CODE, "
                    lcQuery += "CATTRIBUTE_GROUP, "
                    lcQuery += "CATTRIBUTE_ID, "
                    lcQuery += "CPROGRAM_ID, "
                    lcQuery += "CCUSTOMER_CODE, "
                    lcQuery += "CPROGRAM_NAME, "
                    lcQuery += "CDESCRIPTION, "
                    lcQuery += "LSPEC, "
                    lcQuery += "CCUSTOM_TYPE, "
                    lcQuery += "OBINARY_ICON_DATA, "
                    lcQuery += "LOBSOLETE, "
                    lcQuery += "CUPDATE_BY, "
                    lcQuery += "DUPDATE_DATE, "
                    lcQuery += "CCREATE_BY, "
                    lcQuery += "DCREATE_DATE) "
                    lcQuery += "SELECT "
                    lcQuery += "CCOMPANY_ID, "
                    lcQuery += "CAPPS_CODE, "
                    lcQuery += "CATTRIBUTE_GROUP, "
                    lcQuery += "CATTRIBUTE_ID, "
                    lcQuery += "CPROGRAM_ID, "
                    lcQuery += "'{5}', "
                    lcQuery += "CPROGRAM_NAME, "
                    lcQuery += "CDESCRIPTION, "
                    lcQuery += "LSPEC, "
                    lcQuery += "'STD', "
                    lcQuery += "OBINARY_ICON_DATA, "
                    lcQuery += "0, "
                    lcQuery += "'{6}', GETDATE(), '{7}', GETDATE() "
                    lcQuery += "FROM CSM_PROGRAMS "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                    lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                    lcQuery += "AND CPROGRAM_ID = '{4}' "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CATTRIBUTE_GROUP,
                    .CATTRIBUTE_ID,
                    .CPROGRAM_ID,
                    .CCUSTOMER_CODE,
                    .CUPDATE_BY,
                    .CCREATE_BY)
                End With
                loDb.SqlExecNonQuery(lcQuery, loConn, False)
            Next

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Sub R_Deleting(poEntity As CSM00310DTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcRtn As String

        Try
            loConn = loDb.GetConnection()

            With poEntity

                'validation
                loCmd = loDb.GetCommand()
                lcQuery = "EXEC RSP_Delete_Program_Cust_Validation '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', @CRET_MSG OUTPUT "
                With poEntity
                    lcQuery = String.Format(lcQuery, _
                                            .CCOMPANY_ID, _
                                            .CAPPS_CODE, _
                                            .CATTRIBUTE_GROUP, _
                                            .CATTRIBUTE_ID, _
                                            .CPROGRAM_ID, _
                                            .CCUSTOMER_CODE)
                End With
                loCmd.CommandText = lcQuery
                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@CRET_MSG"
                    .DbType = DbType.String
                    .Size = 50
                    .Direction = ParameterDirection.Output
                End With
                loCmd.Parameters.Add(loPar)
                loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)

                If loCmd.Parameters("@CRET_MSG") Is Nothing Then
                    lcRtn = "UNKNOWN_ERROR"
                Else
                    lcRtn = loCmd.Parameters("@CRET_MSG").Value
                End If

                If Not lcRtn.Equals("OK") Then
                    Throw New Exception(lcRtn)
                End If

                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "CSM_PROGRAMS_CUST "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                lcQuery += "AND CPROGRAM_ID = '{4}' "
                lcQuery += "AND CCUSTOMER_CODE = '{5}' "

                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CPROGRAM_ID, .CCUSTOMER_CODE)

                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As CSM00310DTO) As CSM00310DTO
        Dim lcQuery As String
        Dim loResult As CSM00310DTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CSM_PROGRAMS_CUST (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                lcQuery += "AND CPROGRAM_ID = '{4}' "
                lcQuery += "AND CCUSTOMER_CODE = '{5}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CPROGRAM_ID, .CCUSTOMER_CODE)

                loResult = loDb.SqlExecObjectQuery(Of CSM00310DTO)(lcQuery).FirstOrDefault

            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As CSM00310DTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim lcResult As String

        Try
            loConn = loDb.GetConnection()

            With poNewEntity
                If poCRUDMode = eCRUDMode.AddMode Then

                    ' validation
                    lcQuery = "SELECT CPROGRAM_ID "
                    lcQuery += "FROM CSM_PROGRAMS (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                    lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                    lcQuery += "AND CPROGRAM_ID = '{4}' "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CPROGRAM_ID, .CCUSTOMER_CODE)
                    lcResult = loDb.SqlExecObjectQuery(Of String)(lcQuery, loConn, False).FirstOrDefault
                    If lcResult IsNot Nothing Then
                        loEx.Add("STANDARD_EXISTS", "Program ID has been used in standard program. Please use Add From Standard.")
                        Exit Try
                    End If

                    .CCREATE_BY = .CUPDATE_BY

                    lcQuery = "INSERT INTO CSM_PROGRAMS_CUST ("
                    lcQuery += "CCOMPANY_ID, "
                    lcQuery += "CAPPS_CODE, "
                    lcQuery += "CATTRIBUTE_GROUP, "
                    lcQuery += "CATTRIBUTE_ID, "
                    lcQuery += "CPROGRAM_ID, "
                    lcQuery += "CCUSTOMER_CODE, "
                    lcQuery += "CPROGRAM_NAME, "
                    lcQuery += "CDESCRIPTION, "
                    lcQuery += "LSPEC, "
                    lcQuery += "CCUSTOM_TYPE, "
                    lcQuery += "LOBSOLETE, "
                    lcQuery += "CUPDATE_BY, "
                    lcQuery += "DUPDATE_DATE, "
                    lcQuery += "CCREATE_BY, "
                    lcQuery += "DCREATE_DATE) "
                    lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', {8}, 'FULL', 0, '{9}', GETDATE(), '{10}', GETDATE()) "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CATTRIBUTE_GROUP,
                    .CATTRIBUTE_ID,
                    .CPROGRAM_ID,
                    .CCUSTOMER_CODE,
                    .CPROGRAM_NAME,
                    .CDESCRIPTION,
                    getBit(.LSPEC),
                    .CUPDATE_BY,
                    .CCREATE_BY)

                ElseIf poCRUDMode = eCRUDMode.EditMode Then

                    lcQuery = "UPDATE CSM_PROGRAMS "
                    lcQuery += "SET "
                    lcQuery += "CPROGRAM_NAME = '{6}', "
                    lcQuery += "CDESCRIPTION = '{7}', "
                    lcQuery += "LSPEC = {8}, "
                    lcQuery += "LOBSOLETE = {9}, "
                    lcQuery += "CUPDATE_BY = '{10}', "
                    lcQuery += "DUPDATE_DATE = GETDATE() "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                    lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                    lcQuery += "AND CPROGRAM_ID = '{4}' "
                    lcQuery += "AND CCUSTOMER_CODE = '{5}' "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CATTRIBUTE_GROUP,
                    .CATTRIBUTE_ID,
                    .CPROGRAM_ID,
                    .CCUSTOMER_CODE,
                    .CPROGRAM_NAME,
                    .CDESCRIPTION,
                    getBit(.LSPEC),
                    getBit(.LOBSOLETE),
                    .CUPDATE_BY)

                End If
            End With
            loDb.SqlExecNonQuery(lcQuery, loConn, True)
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Function DumpFiles(poKey As CSM00310ReleaseDTO) As String
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim lcRtn As String = "OK"
        Dim loAppInfo As CSM00310ReleaseDTO
        Dim loTempByte As List(Of CSM00310ReleaseFilesDTO)
        Dim lcSourceFilePath As String
        Dim lcZipFilePath As String

        Try
            With poKey

                ' find application type first
                lcQuery = "SELECT TOP 1 CAPPLICATION_TYPE "
                lcQuery += "FROM "
                lcQuery += "RVM_APPLICATION (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE)

                loAppInfo = loDb.SqlExecObjectQuery(Of CSM00310ReleaseDTO)(lcQuery).FirstOrDefault
                If loAppInfo Is Nothing OrElse loAppInfo.CAPPLICATION_TYPE.Trim.Equals("") Then
                    Throw New Exception("Please set application type for Application " + .CAPPS_CODE.Trim + ".")
                End If

                ' dump files
                If loAppInfo.CAPPLICATION_TYPE.Trim.Equals("002") Then

                    ' Get files
                    lcQuery = "EXEC RSP_Get_Custom_Files '{0}', '{1}', '{2}'  "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, _
                                            .CAPPS_CODE, _
                                            .CVERSION)
                    loTempByte = loDb.SqlExecObjectQuery(Of CSM00310ReleaseFilesDTO)(lcQuery)

                    If loTempByte Is Nothing OrElse loTempByte.Count = 0 Then
                        Throw New Exception("Cannot find any releasable program of Application " + .CAPPS_CODE.Trim + " for Customer " + .CVERSION.Trim + ".")
                    End If

                    ' Save files
                    ' Check and make sure if Realta temp zip folder exists
                    If Not Directory.Exists(C_ZipPath) Then
                        Directory.CreateDirectory(C_ZipPath)
                    End If
                    For Each loFile As CSM00310ReleaseFilesDTO In loTempByte
                        lcZipFilePath = C_ZipPath.Trim & "\" & loFile.CSOURCE_ID.Trim & ".zip"
                        ' Create folder if not exists
                        lcSourceFilePath = C_RootPath.Trim & loFile.CPATH.Trim
                        If Not Directory.Exists(lcSourceFilePath) Then
                            Directory.CreateDirectory(lcSourceFilePath)
                        End If
                        ' save zip file
                        R_Utility.ConvertByteToFile(lcZipFilePath, loFile.OFILE_BYTE)
                        ' ***** Extract file *****
                        ' Extract file only if exists
                        Using zip As ZipFile = ZipFile.Read(lcZipFilePath)
                            zip.ExtractAll(lcSourceFilePath, ExtractExistingFileAction.OverwriteSilently)
                        End Using
                        ' Delete Zip File
                        File.Delete(lcZipFilePath)
                    Next

                    ' End of smart client file handling
                End If

            End With

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return lcRtn
    End Function
End Class
