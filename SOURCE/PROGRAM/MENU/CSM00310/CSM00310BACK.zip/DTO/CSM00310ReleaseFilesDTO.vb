﻿Public Class CSM00310ReleaseFilesDTO
    Public Property CPATH As String
    Public Property CREVISION As String
    Public Property CSOURCE_ID As String
    Public Property OFILE_BYTE As Byte()
End Class
