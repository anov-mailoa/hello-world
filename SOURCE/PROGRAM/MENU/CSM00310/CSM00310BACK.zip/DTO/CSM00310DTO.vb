﻿Imports R_BackEnd

<Serializable()> _
Public Class CSM00310DTO
    Inherits R_DTOBase

    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CATTRIBUTE_GROUP As String
    Public Property CATTRIBUTE_ID As String
    Public Property CPROGRAM_ID As String
    Public Property CCUSTOMER_CODE As String
    Public Property CPROGRAM_NAME As String
    Public Property CDESCRIPTION As String
    Public Property LSPEC As Boolean
    Public Property CCUSTOM_TYPE As String
    Public Property LOBSOLETE As Boolean
    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)

End Class
