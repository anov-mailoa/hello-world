﻿Public Class CSM00310KeyDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CATTRIBUTE_GROUP As String
    Public Property CATTRIBUTE_ID As String
    Public Property CPROGRAM_ID As String
    Public Property CCUSTOMER_CODE As String
End Class
