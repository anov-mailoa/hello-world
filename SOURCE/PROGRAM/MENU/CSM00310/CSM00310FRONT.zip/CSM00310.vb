﻿Imports CSM00310Front.CSM00310ServiceRef
Imports R_FrontEnd
Imports CSM00310FrontResources
Imports R_Common
Imports ClientHelper
Imports CSM00310Front.CSM00310StreamingServiceRef
Imports System.ServiceModel.Channels
Imports RCustDBFrontHelper
Imports System.Drawing
Imports System.IO
Imports System.ServiceModel

Public Class CSM00310

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSM00310Service/CSM00310Service.svc"
    Dim C_ServiceNameStream As String = "CSM00310Service/CSM00310StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _CFILE As String
    Dim _CFILE_NAME As String
    Dim _CCUSTOMER_CODE As String
    Dim loGridKey As New CSM00310KeyDTO
#End Region

#Region " SUB and FUNCTION "

    Private Sub RefreshGrids()
        Dim loTableKey As New CSM00310KeyDTO

        With loTableKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = cboApplication.SelectedValue.Trim
            .CATTRIBUTE_GROUP = "PROGRAM"
            .CCUSTOMER_CODE = _CCUSTOMER_CODE
        End With

        With gvProgram
            .R_RefreshGrid(loTableKey)
            .Columns(0).Sort(Telerik.WinControls.UI.RadSortOrder.Ascending, False)
        End With
    End Sub

    Private Function GetIconByte(poKey As CSM00310KeyDTO) As Byte()
        Dim loException As New R_Exception
        Dim loFileHandler As New FileHandler
        Dim loKey As New FileServiceRef.RCustDBFileKeyDTO
        Dim loReturn As Byte()

        Try
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor

            With loKey
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = poKey.CAPPS_CODE
                .CATTRIBUTE_GROUP = poKey.CATTRIBUTE_GROUP
                .CATTRIBUTE_ID = poKey.CATTRIBUTE_ID
                .CITEM_ID = poKey.CPROGRAM_ID
                .CACTION = "VIEWICON"
                .CUSER_ID = _CUSERID
                .CFILE_GROUP = "PROGRAM_ICON"
            End With
            With loFileHandler
                .CCOMPANY_ID = _CCOMPID
                .CUSER_ID = _CUSERID
                loReturn = .DownloadByte(loKey)
            End With
        Catch ex As Exception
            loException.Add(ex)
        Finally
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        End Try
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        If loException.Haserror Then
            Me.R_DisplayException(loException)
        End If
        Return loReturn
    End Function

#End Region

#Region " Form Methods "

    Private Sub CSM00310_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Dim loSvc As CSM00310ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00310Service, CSM00310ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loAppCombo As New List(Of RLicenseAppComboDTO)

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            _CCUSTOMER_CODE = ""

            ' Application
            loAppCombo = loSvc.GetAppCombo(_CCOMPID, _CUSERID)
            If loAppCombo.Count <= 0 Then
                cboApplication.Items.Clear()
                gvProgram.Enabled = False
            End If
            bsApps.DataSource = loAppCombo

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub CSM00310_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " COMBO Actions "

    Private Sub cboApplication_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboApplication.SelectedValueChanged
        Dim loEx As New R_Exception

        Try
            _CAPPSCODE = CType(sender, R_RadDropDownList).SelectedValue
            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " GRIDVIEW Events "

    Private Sub gvProgram_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvProgram.DataBindingComplete
        gvProgram.BestFitColumns()
    End Sub

    Private Sub gvProgram_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvProgram.R_Display
        Dim loIconByte As Byte()

        With loGridKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = poEntity._CAPPS_CODE
            .CATTRIBUTE_GROUP = "PROGRAM"
            .CATTRIBUTE_ID = poEntity._CATTRIBUTE_ID
            .CPROGRAM_ID = poEntity._CPROGRAM_ID
        End With
        With pbIcon
            ' Download icon byte
            loIconByte = GetIconByte(loGridKey)
            If loIconByte IsNot Nothing Then
                Using mStream As New MemoryStream(loIconByte)
                    .Image = Image.FromStream(mStream)
                End Using
            Else
                .Image = Nothing
            End If
        End With
    End Sub

    Private Sub gvProgram_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvProgram.R_Saving
        With CType(poEntity, CSM00310DTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = cboApplication.SelectedValue.Trim
            ._CCUSTOMER_CODE = _CCUSTOMER_CODE
            ._CATTRIBUTE_GROUP = "PROGRAM"
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With
    End Sub

    Private Sub gvProgram_R_ServiceDelete(poEntity As Object) Handles gvProgram.R_ServiceDelete
        Dim loService As CSM00310ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00310Service, CSM00310ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String

        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As FaultException
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loService IsNot Nothing Then
            loService.Close()
        End If

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvProgram_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvProgram.R_ServiceGetListRecord
        Dim loServiceStream As CSM00310StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00310StreamingService, CSM00310StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00310GridDTO)
        Dim loListEntity As New List(Of CSM00310DTO)

        Try
            With CType(poEntity, CSM00310KeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cAttributeGroup", .CATTRIBUTE_GROUP)
                R_Utility.R_SetStreamingContext("cCustomerCode", .CCUSTOMER_CODE)
            End With

            loRtn = loServiceStream.GetProgramCustList()
            loStreaming = R_StreamUtility(Of CSM00310GridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00310GridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New CSM00310DTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                           ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                           ._CATTRIBUTE_GROUP = loDto.CATTRIBUTE_GROUP,
                                                           ._CATTRIBUTE_ID = loDto.CATTRIBUTE_ID,
                                                           ._CPROGRAM_ID = loDto.CPROGRAM_ID,
                                                           ._CCUSTOMER_CODE = _CCUSTOMER_CODE,
                                                           ._CPROGRAM_NAME = loDto.CPROGRAM_NAME,
                                                           ._CDESCRIPTION = loDto.CDESCRIPTION,
                                                           ._LSPEC = loDto.LSPEC,
                                                           ._CCUSTOM_TYPE = loDto.CCUSTOM_TYPE,
                                                           ._LOBSOLETE = loDto.LOBSOLETE,
                                                           ._CCREATE_BY = loDto.CCREATE_BY,
                                                           ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                           ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                           ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        If loServiceStream IsNot Nothing Then
            loServiceStream.Close()
        End If

        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvProgram_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvProgram.R_ServiceGetRecord
        Dim loService As CSM00310ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00310Service, CSM00310ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New CSM00310DTO With {._CCOMPANY_ID = _CCOMPID,
                                                                             ._CAPPS_CODE = cboApplication.SelectedValue.Trim,
                                                                             ._CATTRIBUTE_GROUP = "PROGRAM",
                                                                             ._CATTRIBUTE_ID = CType(bsGvProgram.Current, CSM00310DTO)._CATTRIBUTE_ID,
                                                                             ._CCUSTOMER_CODE = _CCUSTOMER_CODE,
                                                                             ._CPROGRAM_ID = CType(bsGvProgram.Current, CSM00310DTO)._CPROGRAM_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loService IsNot Nothing Then
            loService.Close()
        End If

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvProgram_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvProgram.R_ServiceSave
        Dim loService As CSM00310ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00310Service, CSM00310ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As FaultException
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrNo
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loService IsNot Nothing Then
            loService.Close()
        End If

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvProgram_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvProgram.R_Validation
        Dim loEx As New R_Exception()

        Try
            ' Customer
            If String.IsNullOrWhiteSpace(_CCUSTOMER_CODE) Then
                loEx.Add("CSM00310_04", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00310_04"))
                plCancel = True
            End If

            With poGridCellCollection
                If String.IsNullOrWhiteSpace(.Item("_CPROGRAM_ID").Value) Then
                    loEx.Add("CSM00310_01", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00310_01"))
                    plCancel = True
                End If

                If String.IsNullOrWhiteSpace(.Item("_CPROGRAM_NAME").Value) Then
                    loEx.Add("CSM00310_02", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00310_02"))
                    plCancel = True
                End If

                If String.IsNullOrWhiteSpace(.Item("_CATTRIBUTE_ID").Value) Then
                    loEx.Add("CSM00310_03", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00310_03"))
                    plCancel = True
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " Icon Actions "

    Private Sub btnBrowse_Click(sender As Object, e As System.EventArgs) Handles btnBrowse.Click
        With ofdIcon
            .InitialDirectory = IO.Path.Combine(My.Application.Info.DirectoryPath, "Data")
            .Filter = "PNG Images|*.png"
            .ShowDialog()
        End With
    End Sub

    Private Sub btnUpload_Click(sender As Object, e As System.EventArgs) Handles btnUpload.Click
        Dim loException As New R_Exception
        Dim loFileHandler As New FileHandler
        Dim lnImageSize As Integer

        Try
            ' Check filename
            If _CFILE.Trim.Equals("") Then
                loException.Add("Err001", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "Err001").Trim)
                Exit Try
            End If
            ' Check image size
            lnImageSize = pbIcon.Image.Width
            If lnImageSize <> 113 Then
                loException.Add("Err001", "Invalid image size.")
                Exit Try
            End If

            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
            With loFileHandler
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = loGridKey.CAPPS_CODE
                .CATTRIBUTE_GROUP = loGridKey.CATTRIBUTE_GROUP
                .CATTRIBUTE_ID = loGridKey.CATTRIBUTE_ID
                .CITEM_ID = loGridKey.CPROGRAM_ID
                .CACTION = "SAVEICON"
                .CUSER_ID = _CUSERID
                .CFILE_NAME = _CFILE_NAME
                .CDESCRIPTION = ""
                .CPROGRAM_ID = "CSM00310"
                .CFILE_GROUP = "PROGRAM_ICON"
                .ProcessSingleFile(_CFILE)
                Threading.Thread.Sleep(5000)
            End With
            RefreshGrids()
        Catch ex As Exception
            loException.Add(ex)
        Finally
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            _CFILE = ""
        End Try
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        If loException.Haserror Then
            Me.R_DisplayException(loException)
        End If
    End Sub

    Private Sub ofdIcon_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles ofdIcon.FileOk
        Dim loImageByte As Byte()
        _CFILE = ofdIcon.FileName
        _CFILE_NAME = ofdIcon.SafeFileName
        With pbIcon
            loImageByte = R_Utility.GetByteFromFile(_CFILE)
            Using mStream As New MemoryStream(loImageByte)
                .Image = Image.FromStream(mStream)
            End Using
        End With
    End Sub

#End Region

#Region " LOOKUP Events "

    Private Sub R_LookUp1_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles lupCustomer.R_Before_Open_Form
        poTargetForm = New CustList
        poParameter = New FileStreamingServiceRef.RCustDBFileKeyDTO With {.CCOMPANY_ID = _CCOMPID}
    End Sub

    Private Sub R_LookUp1_R_Return_LookUp(poReturnObject As Object) Handles lupCustomer.R_Return_LookUp
        txtCustomerCode.Text = poReturnObject.CCUSTOMER_CODE
        txtCustomerName.Text = poReturnObject.CCUSTOMER_NAME
        _CCUSTOMER_CODE = txtCustomerCode.Text
        RefreshGrids()
    End Sub

#End Region

#Region " ADD FROM STANDARD "

    Private Sub btnAddStandard_R_After_Open_Form(poPopUpResult As System.Windows.Forms.DialogResult, poPopUpEntityResult As Object) Handles btnAddStandard.R_After_Open_Form
        RefreshGrids()
    End Sub

    Private Sub btnAddStandard_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnAddStandard.R_Before_Open_Form
        ' Customer Code tidak boleh kosong
        If _CCUSTOMER_CODE.Trim.Equals("") Then
            Dim loException As New R_Exception
            loException.Add("CSM00310_04", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00310_04"))
            If loException.Haserror Then
                Me.R_DisplayException(loException)
            End If

        Else
            poTargetForm = New CSM00310ItemList
            With CType(poTargetForm, CSM00310ItemList)
                .Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "btnAddStandard")
            End With

            poParameter = New CSM00310KeyDTO With {.CCOMPANY_ID = _CCOMPID, .CAPPS_CODE = _CAPPSCODE, .CCUSTOMER_CODE = _CCUSTOMER_CODE}
        End If
    End Sub

#End Region

#Region " RELEASE "
    Private Sub btnRerelease_Click(sender As Object, e As System.EventArgs) Handles btnRerelease.Click
        Dim loEx As New R_Exception
        Dim loSvc As CSM00310ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00310Service, CSM00310ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loLicense As CSM00310ReleaseDTO
        Dim lcRtn As String

        Try
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor

            ' Process
            If bsGvProgram.Count > 0 Then
                loLicense = New CSM00310ReleaseDTO
                With loLicense
                    .CCOMPANY_ID = _CCOMPID
                    .CAPPS_CODE = cboApplication.SelectedValue.Trim
                    .CVERSION = _CCUSTOMER_CODE
                    .CUSER_ID = _CUSERID
                End With
                lcRtn = loSvc.DumpFiles(loLicense)
                If Not lcRtn.Equals("OK") Then
                    loEx.Add(lcRtn, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcRtn))
                    Exit Try
                End If
            End If

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        End Try
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default

        If loEx.Haserror Then
            R_DisplayException(loEx)
        Else
            MsgBox("Process Complete", , Me.Text)
        End If
    End Sub
#End Region

End Class
