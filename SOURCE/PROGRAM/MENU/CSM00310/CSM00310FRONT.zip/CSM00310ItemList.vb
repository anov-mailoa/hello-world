﻿Imports CSM00310FrontResources
Imports R_Common
Imports CSM00310Front.CSM00310StreamingServiceRef
Imports R_FrontEnd
Imports System.ServiceModel.Channels
Imports CSM00310Front.CSM00310ServiceRef
Imports ClientHelper

Public Class CSM00310ItemList

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSM00310Service/CSM00310Service.svc"
    Dim C_ServiceNameStream As String = "CSM00310Service/CSM00310StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _CATTRIBUTEID As String
    Dim _INIT As Boolean = False
    Dim loParameter As New CSM00310KeyDTO
#End Region

#Region " FORM Events "

    Private Sub CSM00500Manager_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loSvc As CSM00310ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00310Service, CSM00310ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loAttributeCombo As New List(Of RCustDBAttributeComboDTO)

        Try
            _CUSERID = U_GlobalVar.UserId
            With CType(poParameter, CSM00310KeyDTO)
                _CCOMPID = .CCOMPANY_ID
                _CAPPSCODE = .CAPPS_CODE
                _INIT = True
                ' Combos
                loAttributeCombo = loSvc.GetAttributeCombo(_CCOMPID, _CAPPSCODE, "PROGRAM")
                bsAttribute.DataSource = loAttributeCombo
                loSvc.Close()
                If .CATTRIBUTE_ID IsNot Nothing Then
                    cboAttribute.SelectedValue = .CATTRIBUTE_ID
                End If
            End With
            loParameter = poParameter
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub
#End Region

#Region " GRIDVIEW Events "

    Private Sub gvManager_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvItems.DataBindingComplete
        gvItems.BestFitColumns()
    End Sub

    Private Sub gvManager_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvItems.R_ServiceGetListRecord
        Dim loServiceStream As CSM00310StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00310StreamingService, CSM00310StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00310ItemListDTO)
        Dim loListEntity As New List(Of CSM00310ItemListDTO)

        Try
            With CType(poEntity, CSM00310KeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cAttributeGroup", .CATTRIBUTE_GROUP)
                R_Utility.R_SetStreamingContext("cAttributeId", .CATTRIBUTE_ID)

                loRtn = loServiceStream.GetStandardProgramList()
                loStreaming = R_StreamUtility(Of CSM00310ItemListDTO).ReadFromMessage(loRtn)

                For Each loDto As CSM00310ItemListDTO In loStreaming
                    If loDto IsNot Nothing Then
                        loDto.CATTRIBUTE_GROUP = "PROGRAM"
                        loDto.CATTRIBUTE_ID = cboAttribute.SelectedValue
                        loListEntity.Add(loDto)
                    Else
                        Exit For
                    End If
                Next
                poListEntityResult = loListEntity

            End With
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loServiceStream.Close()
        loException.ThrowExceptionIfErrors()
    End Sub
#End Region

#Region " COMBO Actions "

    Private Sub cboAttribute_TextChanged(sender As Object, e As System.EventArgs) Handles cboAttribute.SelectedValueChanged
        Dim loKey As New CSM00310KeyDTO

        If _INIT Then
            With loKey
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = _CAPPSCODE
                .CATTRIBUTE_GROUP = "PROGRAM"
                .CATTRIBUTE_ID = sender.SelectedValue
                _CATTRIBUTEID = sender.SelectedValue
            End With
            gvItems.R_RefreshGrid(loKey)
        End If
    End Sub

#End Region

#Region " BUTTON Actions "

    Private Sub R_ReturnPopUp1_R_SetPopUpResult(ByRef poEntityResult As Object) Handles R_ReturnPopUp1.R_SetPopUpResult
        Dim loException As New R_Exception
        Dim loService As CSM00310ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00310Service, CSM00310ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loItems As New List(Of CSM00310AddStdDTO)

        Me.Cursor = Windows.Forms.Cursors.WaitCursor
        Try
            Dim loItemList = From item In CType(bsItems.List, List(Of CSM00310ItemListDTO)) _
                             Where item.LSELECT = True

            If loItemList.ToList.Count = 0 Then
                loException.Add("CSM00310_05", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00310_05"))
                Exit Try
            End If

            For Each program As CSM00310ItemListDTO In loItemList
                loItems.Add(New CSM00310AddStdDTO With {.CCOMPANY_ID = loParameter.CCOMPANY_ID, _
                                                        .CAPPS_CODE = loParameter.CAPPS_CODE, _
                                                        .CATTRIBUTE_GROUP = "PROGRAM", _
                                                        .CATTRIBUTE_ID = _CATTRIBUTEID, _
                                                        .CPROGRAM_ID = program.CITEM_ID, _
                                                        .CCUSTOMER_CODE = loParameter.CCUSTOMER_CODE, _
                                                        .CCREATE_BY = _CUSERID, _
                                                        .CUPDATE_BY = _CUSERID})

            Next

            loService.AddFromStandard(loItems)

        Catch ex As Exception
            loException.Add(ex)
        Finally
            Me.Cursor = Windows.Forms.Cursors.Default
        End Try

        If loException.Haserror Then
            Me.R_DisplayException(loException)
        End If

    End Sub

    Private Sub R_ReturnPopUp1_R_ValidationPopUpResult(ByRef plCancel As Boolean, poButton As System.Windows.Forms.DialogResult) Handles R_ReturnPopUp1.R_ValidationPopUpResult
        Dim loMsgBoxResult As MsgBoxResult

        If poButton = Windows.Forms.DialogResult.Cancel Then
            loMsgBoxResult = MsgBox("If you cancel, your selection will be reset. Are you sure?", MsgBoxStyle.YesNo)
            plCancel = loMsgBoxResult = MsgBoxResult.No
        Else
            loMsgBoxResult = MsgBox("Process selected item(s)?", MsgBoxStyle.YesNo)
            plCancel = loMsgBoxResult = MsgBoxResult.No
        End If
    End Sub

#End Region

End Class
