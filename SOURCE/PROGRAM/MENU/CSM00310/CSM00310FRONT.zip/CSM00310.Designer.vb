﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSM00310
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewComboBoxColumn1 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn1 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn2 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnAddStandard = New R_FrontEnd.R_PopUp(Me.components)
        Me.lblCustomer = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtCustomerName = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtCustomerCode = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lupCustomer = New R_FrontEnd.R_LookUp(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.cboApplication = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridProgram = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.gvProgram = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvProgram = New System.Windows.Forms.BindingSource(Me.components)
        Me.btnUpload = New R_FrontEnd.R_RadButton(Me.components)
        Me.btnBrowse = New R_FrontEnd.R_RadButton(Me.components)
        Me.pbIcon = New System.Windows.Forms.PictureBox()
        Me.lblIconTitle = New R_FrontEnd.R_RadLabel(Me.components)
        Me.ofdIcon = New System.Windows.Forms.OpenFileDialog()
        Me.btnRerelease = New R_FrontEnd.R_RadButton(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.btnAddStandard, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCustomerName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCustomerCode, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lupCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridProgram, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.gvProgram, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvProgram.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvProgram, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnUpload, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnBrowse, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblIconTitle, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnRerelease, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnRerelease)
        Me.Panel1.Controls.Add(Me.btnAddStandard)
        Me.Panel1.Controls.Add(Me.lblCustomer)
        Me.Panel1.Controls.Add(Me.txtCustomerName)
        Me.Panel1.Controls.Add(Me.txtCustomerCode)
        Me.Panel1.Controls.Add(Me.lupCustomer)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Controls.Add(Me.cboApplication)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 84)
        Me.Panel1.TabIndex = 0
        '
        'btnAddStandard
        '
        Me.btnAddStandard.Location = New System.Drawing.Point(115, 55)
        Me.btnAddStandard.Name = "btnAddStandard"
        Me.btnAddStandard.R_ConductorGridSource = Me.conGridProgram
        Me.btnAddStandard.R_ConductorSource = Nothing
        Me.btnAddStandard.R_DescriptionId = Nothing
        Me.btnAddStandard.R_ResourceId = "btnAddStandard"
        Me.btnAddStandard.R_Title = Nothing
        Me.btnAddStandard.Size = New System.Drawing.Size(164, 24)
        Me.btnAddStandard.TabIndex = 20
        Me.btnAddStandard.Text = "R_PopUp1"
        '
        'lblCustomer
        '
        Me.lblCustomer.AutoSize = False
        Me.lblCustomer.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustomer.Location = New System.Drawing.Point(9, 30)
        Me.lblCustomer.Name = "lblCustomer"
        Me.lblCustomer.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustomer.R_ResourceId = "lblCustomer"
        Me.lblCustomer.Size = New System.Drawing.Size(100, 18)
        Me.lblCustomer.TabIndex = 19
        Me.lblCustomer.Text = "Application..."
        '
        'txtCustomerName
        '
        Me.txtCustomerName.Enabled = False
        Me.txtCustomerName.Location = New System.Drawing.Point(257, 29)
        Me.txtCustomerName.Name = "txtCustomerName"
        Me.txtCustomerName.R_ConductorGridSource = Nothing
        Me.txtCustomerName.R_ConductorSource = Nothing
        Me.txtCustomerName.R_UDT = Nothing
        Me.txtCustomerName.Size = New System.Drawing.Size(258, 20)
        Me.txtCustomerName.TabIndex = 17
        '
        'txtCustomerCode
        '
        Me.txtCustomerCode.Location = New System.Drawing.Point(115, 29)
        Me.txtCustomerCode.Name = "txtCustomerCode"
        Me.txtCustomerCode.R_ConductorGridSource = Nothing
        Me.txtCustomerCode.R_ConductorSource = Nothing
        Me.txtCustomerCode.R_UDT = Nothing
        Me.txtCustomerCode.Size = New System.Drawing.Size(100, 20)
        Me.txtCustomerCode.TabIndex = 16
        '
        'lupCustomer
        '
        Me.lupCustomer.Location = New System.Drawing.Point(221, 29)
        Me.lupCustomer.Name = "lupCustomer"
        Me.lupCustomer.R_ConductorGridSource = Nothing
        Me.lupCustomer.R_ConductorSource = Nothing
        Me.lupCustomer.R_DescriptionId = Nothing
        Me.lupCustomer.R_Field_Description = ""
        Me.lupCustomer.R_Field_Value = ""
        Me.lupCustomer.R_ResourceId = Nothing
        Me.lupCustomer.R_TextBox_Description = Me.txtCustomerName
        Me.lupCustomer.R_TextBox_Value = Me.txtCustomerCode
        Me.lupCustomer.R_Title = Nothing
        Me.lupCustomer.Size = New System.Drawing.Size(30, 20)
        Me.lupCustomer.TabIndex = 15
        Me.lupCustomer.Text = "..."
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 3)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 13
        Me.lblApplication.Text = "Application..."
        '
        'cboApplication
        '
        Me.cboApplication.DataSource = Me.bsApps
        Me.cboApplication.DisplayMember = "CAPPS_NAME"
        Me.cboApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboApplication.Location = New System.Drawing.Point(115, 3)
        Me.cboApplication.Name = "cboApplication"
        Me.cboApplication.R_ConductorGridSource = Me.conGridProgram
        Me.cboApplication.R_ConductorSource = Nothing
        Me.cboApplication.R_EnableOTHER = True
        Me.cboApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboApplication.Size = New System.Drawing.Size(400, 20)
        Me.cboApplication.TabIndex = 14
        Me.cboApplication.Text = "R_RadDropDownList1"
        Me.cboApplication.ValueMember = "CAPPS_CODE"
        '
        'bsApps
        '
        Me.bsApps.DataSource = GetType(CSM00310Front.CSM00310ServiceRef.RLicenseAppComboDTO)
        '
        'conGridProgram
        '
        Me.conGridProgram.R_ConductorParent = Nothing
        Me.conGridProgram.R_IsHeader = True
        Me.conGridProgram.R_RadGroupBox = Nothing
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.gvProgram)
        Me.Panel2.Controls.Add(Me.btnUpload)
        Me.Panel2.Controls.Add(Me.btnBrowse)
        Me.Panel2.Controls.Add(Me.pbIcon)
        Me.Panel2.Controls.Add(Me.lblIconTitle)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 93)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1271, 479)
        Me.Panel2.TabIndex = 1
        '
        'gvProgram
        '
        Me.gvProgram.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gvProgram.EnableFastScrolling = True
        Me.gvProgram.Location = New System.Drawing.Point(3, 3)
        '
        '
        '
        Me.gvProgram.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn1.FieldName = "_CPROGRAM_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CPROGRAM_ID"
        R_GridViewTextBoxColumn1.Name = "_CPROGRAM_ID"
        R_GridViewTextBoxColumn1.R_EnableADD = True
        R_GridViewTextBoxColumn1.R_ResourceId = "_CPROGRAM_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 103
        R_GridViewComboBoxColumn1.DisplayMember = "CATTRIBUTE_NAME"
        R_GridViewComboBoxColumn1.FieldName = "_CATTRIBUTE_ID"
        R_GridViewComboBoxColumn1.HeaderText = "_CATTRIBUTE_ID"
        R_GridViewComboBoxColumn1.Name = "_CATTRIBUTE_ID"
        R_GridViewComboBoxColumn1.R_EnableADD = True
        R_GridViewComboBoxColumn1.R_ResourceId = "_CATTRIBUTE_ID"
        R_GridViewComboBoxColumn1.ValueMember = "CATTRIBUTE_ID"
        R_GridViewComboBoxColumn1.Width = 104
        R_GridViewTextBoxColumn2.FieldName = "_CPROGRAM_NAME"
        R_GridViewTextBoxColumn2.HeaderText = "_CPROGRAM_NAME"
        R_GridViewTextBoxColumn2.Name = "_CPROGRAM_NAME"
        R_GridViewTextBoxColumn2.R_EnableADD = True
        R_GridViewTextBoxColumn2.R_EnableEDIT = True
        R_GridViewTextBoxColumn2.R_ResourceId = "_CPROGRAM_NAME"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 124
        R_GridViewTextBoxColumn3.FieldName = "_CDESCRIPTION"
        R_GridViewTextBoxColumn3.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxColumn3.Name = "_CDESCRIPTION"
        R_GridViewTextBoxColumn3.R_EnableADD = True
        R_GridViewTextBoxColumn3.R_EnableEDIT = True
        R_GridViewTextBoxColumn3.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 103
        R_GridViewCheckBoxColumn1.FieldName = "_LSPEC"
        R_GridViewCheckBoxColumn1.HeaderText = "_LSPEC"
        R_GridViewCheckBoxColumn1.Name = "_LSPEC"
        R_GridViewCheckBoxColumn1.R_EnableADD = True
        R_GridViewCheckBoxColumn1.R_EnableEDIT = True
        R_GridViewCheckBoxColumn1.R_ResourceId = "_LSPEC"
        R_GridViewCheckBoxColumn1.Width = 72
        R_GridViewTextBoxColumn4.FieldName = "_CCUSTOM_TYPE"
        R_GridViewTextBoxColumn4.HeaderText = "_CCUSTOM_TYPE"
        R_GridViewTextBoxColumn4.Name = "_CCUSTOM_TYPE"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CCUSTOM_TYPE"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 108
        R_GridViewCheckBoxColumn2.FieldName = "_LOBSOLETE"
        R_GridViewCheckBoxColumn2.HeaderText = "_LOBSOLETE"
        R_GridViewCheckBoxColumn2.Name = "_LOBSOLETE"
        R_GridViewCheckBoxColumn2.R_EnableEDIT = True
        R_GridViewCheckBoxColumn2.R_ResourceId = "_LOBSOLETE"
        R_GridViewCheckBoxColumn2.Width = 100
        Me.gvProgram.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewComboBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewCheckBoxColumn1, R_GridViewTextBoxColumn4, R_GridViewCheckBoxColumn2})
        Me.gvProgram.MasterTemplate.DataSource = Me.bsGvProgram
        Me.gvProgram.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvProgram.MasterTemplate.EnableFiltering = True
        Me.gvProgram.MasterTemplate.EnableGrouping = False
        Me.gvProgram.MasterTemplate.ShowFilteringRow = False
        Me.gvProgram.MasterTemplate.ShowGroupedColumns = True
        Me.gvProgram.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvProgram.Name = "gvProgram"
        Me.gvProgram.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvProgram.R_ConductorGridSource = Me.conGridProgram
        Me.gvProgram.R_ConductorSource = Nothing
        Me.gvProgram.R_DataAdded = False
        Me.gvProgram.R_NewRowText = Nothing
        Me.gvProgram.ShowHeaderCellButtons = True
        Me.gvProgram.Size = New System.Drawing.Size(1143, 473)
        Me.gvProgram.TabIndex = 3
        Me.gvProgram.Text = "R_RadGridView1"
        '
        'bsGvProgram
        '
        Me.bsGvProgram.DataSource = GetType(CSM00310Front.CSM00310ServiceRef.CSM00310DTO)
        '
        'btnUpload
        '
        Me.btnUpload.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnUpload.Location = New System.Drawing.Point(1152, 176)
        Me.btnUpload.Name = "btnUpload"
        Me.btnUpload.R_ConductorGridSource = Nothing
        Me.btnUpload.R_ConductorSource = Nothing
        Me.btnUpload.R_DescriptionId = Nothing
        Me.btnUpload.R_ResourceId = "btnUpload"
        Me.btnUpload.Size = New System.Drawing.Size(113, 24)
        Me.btnUpload.TabIndex = 3
        Me.btnUpload.Text = "R_RadButton2"
        '
        'btnBrowse
        '
        Me.btnBrowse.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnBrowse.Location = New System.Drawing.Point(1152, 146)
        Me.btnBrowse.Name = "btnBrowse"
        Me.btnBrowse.R_ConductorGridSource = Nothing
        Me.btnBrowse.R_ConductorSource = Nothing
        Me.btnBrowse.R_DescriptionId = Nothing
        Me.btnBrowse.R_ResourceId = "btnBrowse"
        Me.btnBrowse.Size = New System.Drawing.Size(113, 24)
        Me.btnBrowse.TabIndex = 2
        Me.btnBrowse.Text = "R_RadButton1"
        '
        'pbIcon
        '
        Me.pbIcon.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pbIcon.Location = New System.Drawing.Point(1152, 27)
        Me.pbIcon.Name = "pbIcon"
        Me.pbIcon.Size = New System.Drawing.Size(113, 113)
        Me.pbIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbIcon.TabIndex = 1
        Me.pbIcon.TabStop = False
        '
        'lblIconTitle
        '
        Me.lblIconTitle.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblIconTitle.AutoSize = False
        Me.lblIconTitle.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblIconTitle.Location = New System.Drawing.Point(1152, 3)
        Me.lblIconTitle.Name = "lblIconTitle"
        Me.lblIconTitle.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblIconTitle.R_ResourceId = "lblIconTitle"
        Me.lblIconTitle.Size = New System.Drawing.Size(100, 18)
        Me.lblIconTitle.TabIndex = 0
        Me.lblIconTitle.Text = "R_RadLabel1"
        '
        'ofdIcon
        '
        '
        'btnRerelease
        '
        Me.btnRerelease.Location = New System.Drawing.Point(285, 55)
        Me.btnRerelease.Name = "btnRerelease"
        Me.btnRerelease.R_ConductorGridSource = Me.conGridProgram
        Me.btnRerelease.R_ConductorSource = Nothing
        Me.btnRerelease.R_DescriptionId = Nothing
        Me.btnRerelease.R_ResourceId = "btnRerelease"
        Me.btnRerelease.Size = New System.Drawing.Size(110, 24)
        Me.btnRerelease.TabIndex = 21
        Me.btnRerelease.Text = "R_RadButton1"
        '
        'CSM00310
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CSM00310"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.btnAddStandard, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCustomerName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCustomerCode, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lupCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridProgram, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        CType(Me.gvProgram.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvProgram, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvProgram, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnUpload, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnBrowse, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbIcon, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblIconTitle, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnRerelease, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents cboApplication As R_FrontEnd.R_RadDropDownList
    Friend WithEvents conGridProgram As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource
    Friend WithEvents bsGvProgram As System.Windows.Forms.BindingSource
    Friend WithEvents gvProgram As R_FrontEnd.R_RadGridView
    Friend WithEvents lblIconTitle As R_FrontEnd.R_RadLabel
    Friend WithEvents pbIcon As System.Windows.Forms.PictureBox
    Friend WithEvents btnUpload As R_FrontEnd.R_RadButton
    Friend WithEvents btnBrowse As R_FrontEnd.R_RadButton
    Friend WithEvents ofdIcon As System.Windows.Forms.OpenFileDialog
    Friend WithEvents txtCustomerName As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtCustomerCode As R_FrontEnd.R_RadTextBox
    Friend WithEvents lupCustomer As R_FrontEnd.R_LookUp
    Friend WithEvents lblCustomer As R_FrontEnd.R_RadLabel
    Friend WithEvents btnAddStandard As R_FrontEnd.R_PopUp
    Friend WithEvents btnRerelease As R_FrontEnd.R_RadButton

End Class
