﻿Imports R_FrontEnd
Imports LAT00120Front.LAT00120ServiceRef
Imports LAT00120Front.LAT00120StreamingServiceRef
Imports R_Common
Imports System.ServiceModel.Channels
Imports ClientHelper
Imports LAT00120FrontResources
Imports RCustDBFrontHelper.General

Public Class LAT00120

#Region " VARIABLE "
    Dim C_ServiceName As String = "LAT00120Service/LAT00120Service.svc"
    Dim C_ServiceNameStream As String = "LAT00120Service/LAT00120StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim llInitialized As Boolean = False
    Dim _curActivationDTO As New LAT00100ActivationDTO
    Dim _CLAST_EXPIRY_DATE As String
#End Region

#Region " SUBS and FUNCTIONS "

    Private Sub RefreshGrids()
        Dim loTableKey As New LAT00100KeyDTO
        Dim loSvc As LAT00120ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00120Service, LAT00120ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)

        With loTableKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = cboApplication.SelectedValue.Trim
            .CCUSTOMER_CODE = cboCustomer.SelectedValue.Trim
            .CSERVER_TYPE = IIf(rdbLive.IsChecked, "1", "0")
        End With

        _CLAST_EXPIRY_DATE = Today.ToString("yyyyMMdd")
        gvActivation.R_RefreshGrid(loTableKey)
        ' initiate input objects
        txtInstallationID.Text = loSvc.GetServerID(loTableKey)
    End Sub

    Private Sub ShowSaveDialog(pcFilename As String, pcFileContent As String)
        Dim loFile As System.IO.StreamWriter

        fbdSaveToFile.RootFolder = Environment.SpecialFolder.MyComputer
        fbdSaveToFile.Description = "Save file " & pcFilename.Trim & " to folder below..."
        If fbdSaveToFile.ShowDialog = Windows.Forms.DialogResult.OK Then
            loFile = My.Computer.FileSystem.OpenTextFileWriter(fbdSaveToFile.SelectedPath.Trim & _
                        IIf(fbdSaveToFile.SelectedPath.EndsWith("\"), "", "\") & pcFilename, True)
            loFile.WriteLine(pcFileContent)
            loFile.Close()
        End If

    End Sub

    Private Sub RefreshCustomerCombo()
        Dim lnComboIndex As Integer = 0
        Dim loSvc As LAT00120ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00120Service, LAT00120ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loCustCombo As New List(Of RLicenseCustComboDTO)

        If cboCustomer.SelectedIndex >= 0 Then
            llInitialized = False
            lnComboIndex = cboCustomer.SelectedIndex
            loCustCombo = loSvc.GetCustCombo(_CCOMPID)
            bsCust.DataSource = loCustCombo
            cboCustomer.Rebind()
            cboCustomer.SelectedIndex = lnComboIndex
            llInitialized = True
        End If
    End Sub

#End Region

#Region " FORMS "

    Private Sub cboApplication_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboApplication.SelectedValueChanged
        If llInitialized Then
            RefreshGrids()
        End If
    End Sub

    Private Sub cboCustomer_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboCustomer.SelectedValueChanged
        If llInitialized Then
            RefreshGrids()
        End If
    End Sub

    Private Sub rdbLive_CheckStateChanged(sender As Object, e As System.EventArgs) Handles rdbLive.CheckStateChanged
        If CType(sender, R_RadRadioButton).IsChecked And llInitialized Then
            RefreshGrids()
        End If
    End Sub

    Private Sub rdbTest_CheckStateChanged(sender As Object, e As System.EventArgs) Handles rdbTest.CheckStateChanged
        If CType(sender, R_RadRadioButton).IsChecked And llInitialized Then
            RefreshGrids()
        End If
    End Sub

    Private Sub LAT00120_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loSvc As LAT00120ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00120Service, LAT00120ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loAppCombo As New List(Of RLicenseAppComboDTO)
        Dim loCustCombo As New List(Of RLicenseCustComboDTO)
        Dim loLicenseMode As New List(Of String)

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            ' Application
            loAppCombo = loSvc.GetAppCombo(_CCOMPID, _CUSERID)
            If loAppCombo.Count <= 0 Then
                cboApplication.Items.Clear()
                loEx.Add("LAT00100_06", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "LAT00100_06"))
                Exit Try
            End If
            bsApps.DataSource = loAppCombo

            ' Customer
            loCustCombo = loSvc.GetCustCombo(_CCOMPID)
            If loCustCombo.Count <= 0 Then
                cboCustomer.Items.Clear()
                loEx.Add("LAT00100_05", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "LAT00100_05"))
                Exit Try
            End If
            bsCust.DataSource = loCustCombo

            llInitialized = True
            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        If loEx.Haserror Then
            btnGenerateActivation.Enabled = False
            btnSaveActivation.Enabled = False
        End If
        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " BUTTONS "

    Private Sub btnSaveActivation_Click(sender As System.Object, e As System.EventArgs) Handles btnSaveActivation.Click
        Dim lcFilename As String
        Dim lcFileContent As String

        lcFileContent = _curActivationDTO._CACTIVATION_CODE

        ' save to file: appid+custid+generatetime(yyyy.MM.dd.hh.mm.ss)+.activation

        lcFilename = cboApplication.SelectedValue.ToString.ToUpper.Trim + "_"
        lcFilename += cboCustomer.SelectedValue.ToString.ToUpper.Trim + "_"
        lcFilename += _curActivationDTO._CGENERATE_TIME.Trim
        lcFilename += ".activation"

        ShowSaveDialog(lcFilename, lcFileContent)

    End Sub

    Private Sub btnGenerateActivation_Click(sender As System.Object, e As System.EventArgs) Handles btnGenerateActivation.Click
        Dim loEx As New R_Exception
        Dim loSvc As LAT00120ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00120Service, LAT00120ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loActivation As LAT00100ActivationDTO

        Try
            ' Validation
            ' Installation ID
            If txtInstallationID.Text.Trim.Equals("") Then
                loEx.Add("LAT00100_01", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "LAT00100_01"))
                Exit Try
            End If

            ' Save
            loActivation = New LAT00100ActivationDTO
            With loActivation
                ._CCOMPANY_ID = _CCOMPID
                ._CAPPS_CODE = cboApplication.SelectedValue.Trim
                ._CCUSTOMER_CODE = cboCustomer.SelectedValue.Trim
                ._CGENERATE_TIME = "" 'digenerate di backend
                ._CSERVER_TYPE = IIf(rdbLive.IsChecked, "1", "0")
                ._CSERVER_UID = txtInstallationID.Text.Trim
                ._CSTART_DATE = ""
                ._CEXPIRY_DATE = ""
                ._NGRACE_DAYS = 0
                ._NWARNING_DAYS = 0
                ._CACTIVATION_CODE = "" 'digenerate di backend
                ._CUPDATE_BY = _CUSERID
                ._DUPDATE_DATE = Now
                ._CCREATE_BY = _CUSERID
                ._DCREATE_DATE = Now
            End With
            loSvc.RenewActivation(loActivation)

            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loEx.Haserror Then
            R_DisplayException(loEx)
        End If
    End Sub
#End Region

#Region " GRIDVIEW "

    Private Sub gvActivation_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvActivation.DataBindingComplete
        gvActivation.BestFitColumns()
    End Sub

    Private Sub gvActivation_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvActivation.R_Display
        If poEntity IsNot Nothing Then
            With CType(poEntity, LAT00100ActivationDTO)
                _curActivationDTO = poEntity
            End With
        End If

    End Sub

    Private Sub gvActivation_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvActivation.R_ServiceGetListRecord
        Dim loServiceStream As LAT00120StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00120StreamingService, LAT00120StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of LAT00100ActivationGridDTO)
        Dim loListEntity As New List(Of LAT00100ActivationDTO)

        Try
            With poEntity
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cCustomerCode", .CCUSTOMER_CODE)
                R_Utility.R_SetStreamingContext("cServerType", .CSERVER_TYPE)
            End With

            loRtn = loServiceStream.GetActivationData()
            loStreaming = R_StreamUtility(Of LAT00100ActivationGridDTO).ReadFromMessage(loRtn)

            For Each loDto As LAT00100ActivationGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New LAT00100ActivationDTO With {._CAPPS_CODE = loDto.CAPPS_CODE,
                                                                     ._CCUSTOMER_CODE = loDto.CCUSTOMER_CODE,
                                                                     ._CGENERATE_TIME = loDto.CGENERATE_TIME,
                                                                     ._CACTIVATION_CODE = loDto.CACTIVATION_CODE,
                                                                     ._CSTART_DATE = loDto.CSTART_DATE,
                                                                     ._CEXPIRY_DATE = loDto.CEXPIRY_DATE,
                                                                     ._DSTART_DATE = StrToDate(loDto.CSTART_DATE),
                                                                     ._DEXPIRY_DATE = StrToDate(loDto.CEXPIRY_DATE),
                                                                     ._NGRACE_DAYS = loDto.NGRACE_DAYS,
                                                                     ._NWARNING_DAYS = loDto.NWARNING_DAYS,
                                                                     ._CCREATE_BY = loDto.CCREATE_BY,
                                                                     ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                                     ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                                     ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                    If _CLAST_EXPIRY_DATE.Trim.Equals(Today.ToString("yyyyMMdd")) Then
                        _CLAST_EXPIRY_DATE = StrToDate(loDto.CEXPIRY_DATE).Value.AddDays(1).ToString("yyyyMMdd")
                    End If
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity

        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub
#End Region

End Class
