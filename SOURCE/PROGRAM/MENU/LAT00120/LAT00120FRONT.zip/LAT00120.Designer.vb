﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LAT00120
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn2 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDecimalColumn1 As R_FrontEnd.R_GridViewDecimalColumn = New R_FrontEnd.R_GridViewDecimalColumn()
        Dim R_GridViewDecimalColumn2 As R_FrontEnd.R_GridViewDecimalColumn = New R_FrontEnd.R_GridViewDecimalColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn3 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn4 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.gvActivation = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsActivation = New System.Windows.Forms.BindingSource(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnSaveActivation = New R_FrontEnd.R_RadButton(Me.components)
        Me.grpServerType = New R_FrontEnd.R_RadGroupBox(Me.components)
        Me.rdbLive = New R_FrontEnd.R_RadRadioButton(Me.components)
        Me.rdbTest = New R_FrontEnd.R_RadRadioButton(Me.components)
        Me.cboCustomer = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsCust = New System.Windows.Forms.BindingSource(Me.components)
        Me.txtInstallationID = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.btnGenerateActivation = New R_FrontEnd.R_RadButton(Me.components)
        Me.cboApplication = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblInstallationId = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblCustomer = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.fbdSaveToFile = New System.Windows.Forms.FolderBrowserDialog()
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.gvActivation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvActivation.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsActivation, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.btnSaveActivation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grpServerType, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpServerType.SuspendLayout()
        CType(Me.rdbLive, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.rdbTest, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsCust, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtInstallationID, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnGenerateActivation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblInstallationId, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 739.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.gvActivation, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 180.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'gvActivation
        '
        Me.gvActivation.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gvActivation.EnableFastScrolling = True
        Me.gvActivation.Location = New System.Drawing.Point(3, 183)
        '
        '
        '
        Me.gvActivation.MasterTemplate.AllowAddNewRow = False
        Me.gvActivation.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn1.FieldName = "_CGENERATE_TIME"
        R_GridViewTextBoxColumn1.HeaderText = "_CGENERATE_TIME"
        R_GridViewTextBoxColumn1.Name = "_CGENERATE_TIME"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CGENERATE_TIME"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 51
        R_GridViewTextBoxColumn2.FieldName = "_CACTIVATION_CODE"
        R_GridViewTextBoxColumn2.HeaderText = "_CACTIVATION_CODE"
        R_GridViewTextBoxColumn2.Name = "_CACTIVATION_CODE"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CACTIVATION_CODE"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 56
        R_GridViewDateTimeColumn1.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn1.FieldName = "_DSTART_DATE"
        R_GridViewDateTimeColumn1.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn1.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn1.HeaderText = "_DSTART_DATE"
        R_GridViewDateTimeColumn1.Name = "_DSTART_DATE"
        R_GridViewDateTimeColumn1.R_ResourceId = "_DSTART_DATE"
        R_GridViewDateTimeColumn2.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn2.FieldName = "_DEXPIRY_DATE"
        R_GridViewDateTimeColumn2.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn2.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn2.HeaderText = "_DEXPIRY_DATE"
        R_GridViewDateTimeColumn2.Name = "_DEXPIRY_DATE"
        R_GridViewDateTimeColumn2.R_ResourceId = "_DEXPIRY_DATE"
        R_GridViewDecimalColumn1.DataType = GetType(Integer)
        R_GridViewDecimalColumn1.DecimalPlaces = 0
        R_GridViewDecimalColumn1.FieldName = "_NGRACE_DAYS"
        R_GridViewDecimalColumn1.FormatString = "{0:N}"
        R_GridViewDecimalColumn1.HeaderText = "_NGRACE_DAYS"
        R_GridViewDecimalColumn1.Name = "_NGRACE_DAYS"
        R_GridViewDecimalColumn1.R_ResourceId = "_NGRACE_DAYS"
        R_GridViewDecimalColumn1.ThousandsSeparator = True
        R_GridViewDecimalColumn2.DataType = GetType(Integer)
        R_GridViewDecimalColumn2.DecimalPlaces = 0
        R_GridViewDecimalColumn2.FieldName = "_NWARNING_DAYS"
        R_GridViewDecimalColumn2.FormatString = "{0:N}"
        R_GridViewDecimalColumn2.HeaderText = "_NWARNING_DAYS"
        R_GridViewDecimalColumn2.Name = "_NWARNING_DAYS"
        R_GridViewDecimalColumn2.R_ResourceId = "_NWARNING_DAYS"
        R_GridViewDecimalColumn2.ThousandsSeparator = True
        R_GridViewTextBoxColumn3.FieldName = "_CUPDATE_BY"
        R_GridViewTextBoxColumn3.HeaderText = "_CUPDATE_BY"
        R_GridViewTextBoxColumn3.Name = "_CUPDATE_BY"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CUPDATE_BY"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 53
        R_GridViewDateTimeColumn3.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn3.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn3.FieldName = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn3.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn3.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn3.HeaderText = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn3.Name = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn3.R_ResourceId = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn3.Width = 42
        R_GridViewTextBoxColumn4.FieldName = "_CCREATE_BY"
        R_GridViewTextBoxColumn4.HeaderText = "_CCREATE_BY"
        R_GridViewTextBoxColumn4.Name = "_CCREATE_BY"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CCREATE_BY"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 39
        R_GridViewDateTimeColumn4.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn4.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn4.FieldName = "_DCREATE_DATE"
        R_GridViewDateTimeColumn4.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn4.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn4.HeaderText = "_DCREATE_DATE"
        R_GridViewDateTimeColumn4.Name = "_DCREATE_DATE"
        R_GridViewDateTimeColumn4.R_ResourceId = "_DCREATE_DATE"
        R_GridViewDateTimeColumn4.Width = 38
        Me.gvActivation.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewDateTimeColumn1, R_GridViewDateTimeColumn2, R_GridViewDecimalColumn1, R_GridViewDecimalColumn2, R_GridViewTextBoxColumn3, R_GridViewDateTimeColumn3, R_GridViewTextBoxColumn4, R_GridViewDateTimeColumn4})
        Me.gvActivation.MasterTemplate.DataSource = Me.bsActivation
        Me.gvActivation.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvActivation.MasterTemplate.EnableFiltering = True
        Me.gvActivation.MasterTemplate.EnableGrouping = False
        Me.gvActivation.MasterTemplate.ShowFilteringRow = False
        Me.gvActivation.MasterTemplate.ShowGroupedColumns = True
        Me.gvActivation.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvActivation.MasterTemplate.ShowRowHeaderColumn = False
        Me.gvActivation.Name = "gvActivation"
        Me.gvActivation.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvActivation.R_ConductorGridSource = Nothing
        Me.gvActivation.R_ConductorSource = Nothing
        Me.gvActivation.R_DataAdded = False
        Me.gvActivation.R_NewRowText = Nothing
        Me.gvActivation.ShowHeaderCellButtons = True
        Me.gvActivation.Size = New System.Drawing.Size(1271, 389)
        Me.gvActivation.TabIndex = 23
        Me.gvActivation.Text = "R_RadGridView2"
        '
        'bsActivation
        '
        Me.bsActivation.DataSource = GetType(LAT00120Front.LAT00120ServiceRef.LAT00100ActivationDTO)
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnSaveActivation)
        Me.Panel1.Controls.Add(Me.grpServerType)
        Me.Panel1.Controls.Add(Me.cboCustomer)
        Me.Panel1.Controls.Add(Me.txtInstallationID)
        Me.Panel1.Controls.Add(Me.btnGenerateActivation)
        Me.Panel1.Controls.Add(Me.cboApplication)
        Me.Panel1.Controls.Add(Me.lblInstallationId)
        Me.Panel1.Controls.Add(Me.lblCustomer)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 174)
        Me.Panel1.TabIndex = 1
        '
        'btnSaveActivation
        '
        Me.btnSaveActivation.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSaveActivation.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnSaveActivation.Location = New System.Drawing.Point(174, 146)
        Me.btnSaveActivation.Name = "btnSaveActivation"
        Me.btnSaveActivation.R_ConductorGridSource = Nothing
        Me.btnSaveActivation.R_ConductorSource = Nothing
        Me.btnSaveActivation.R_DescriptionId = Nothing
        Me.btnSaveActivation.R_ResourceId = "btnSaveToFile"
        Me.btnSaveActivation.Size = New System.Drawing.Size(158, 24)
        Me.btnSaveActivation.TabIndex = 24
        Me.btnSaveActivation.Text = "R_RadButton1"
        '
        'grpServerType
        '
        Me.grpServerType.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping
        Me.grpServerType.Controls.Add(Me.rdbLive)
        Me.grpServerType.Controls.Add(Me.rdbTest)
        Me.grpServerType.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.grpServerType.HeaderText = "R_RadGroupBox1"
        Me.grpServerType.Location = New System.Drawing.Point(115, 61)
        Me.grpServerType.Name = "grpServerType"
        Me.grpServerType.R_ConductorGridSource = Nothing
        Me.grpServerType.R_ConductorSource = Nothing
        Me.grpServerType.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.grpServerType.R_ResourceId = "grpServerType"
        Me.grpServerType.Size = New System.Drawing.Size(269, 53)
        Me.grpServerType.TabIndex = 11
        Me.grpServerType.Text = "R_RadGroupBox1"
        '
        'rdbLive
        '
        Me.rdbLive.CheckState = System.Windows.Forms.CheckState.Checked
        Me.rdbLive.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.rdbLive.Location = New System.Drawing.Point(130, 24)
        Me.rdbLive.Name = "rdbLive"
        Me.rdbLive.R_ConductorGridSource = Nothing
        Me.rdbLive.R_ConductorSource = Nothing
        Me.rdbLive.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.rdbLive.R_ResourceId = "rdbLive"
        Me.rdbLive.Size = New System.Drawing.Size(122, 18)
        Me.rdbLive.TabIndex = 8
        Me.rdbLive.Text = "R_RadRadioButton1"
        Me.rdbLive.ToggleState = Telerik.WinControls.Enumerations.ToggleState.[On]
        '
        'rdbTest
        '
        Me.rdbTest.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.rdbTest.Location = New System.Drawing.Point(5, 24)
        Me.rdbTest.Name = "rdbTest"
        Me.rdbTest.R_ConductorGridSource = Nothing
        Me.rdbTest.R_ConductorSource = Nothing
        Me.rdbTest.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.rdbTest.R_ResourceId = "rdbTest"
        Me.rdbTest.Size = New System.Drawing.Size(122, 18)
        Me.rdbTest.TabIndex = 9
        Me.rdbTest.TabStop = False
        Me.rdbTest.Text = "R_RadRadioButton2"
        '
        'cboCustomer
        '
        Me.cboCustomer.DataSource = Me.bsCust
        Me.cboCustomer.DisplayMember = "CCUSTOMER_NAME"
        Me.cboCustomer.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList
        Me.cboCustomer.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboCustomer.Location = New System.Drawing.Point(115, 35)
        Me.cboCustomer.Name = "cboCustomer"
        Me.cboCustomer.R_ConductorGridSource = Nothing
        Me.cboCustomer.R_ConductorSource = Nothing
        Me.cboCustomer.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboCustomer.Size = New System.Drawing.Size(400, 20)
        Me.cboCustomer.TabIndex = 3
        Me.cboCustomer.Text = "R_RadDropDownList1"
        Me.cboCustomer.ValueMember = "CCUSTOMER_CODE"
        '
        'bsCust
        '
        Me.bsCust.DataSource = GetType(LAT00120Front.LAT00120ServiceRef.RLicenseCustComboDTO)
        '
        'txtInstallationID
        '
        Me.txtInstallationID.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtInstallationID.Location = New System.Drawing.Point(116, 120)
        Me.txtInstallationID.Name = "txtInstallationID"
        Me.txtInstallationID.R_ConductorGridSource = Nothing
        Me.txtInstallationID.R_ConductorSource = Nothing
        Me.txtInstallationID.R_UDT = Nothing
        Me.txtInstallationID.ReadOnly = True
        Me.txtInstallationID.Size = New System.Drawing.Size(1147, 20)
        Me.txtInstallationID.TabIndex = 3
        Me.txtInstallationID.TabStop = False
        '
        'btnGenerateActivation
        '
        Me.btnGenerateActivation.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnGenerateActivation.Location = New System.Drawing.Point(10, 146)
        Me.btnGenerateActivation.Name = "btnGenerateActivation"
        Me.btnGenerateActivation.R_ConductorGridSource = Nothing
        Me.btnGenerateActivation.R_ConductorSource = Nothing
        Me.btnGenerateActivation.R_DescriptionId = Nothing
        Me.btnGenerateActivation.R_ResourceId = "btnGenerateActivation"
        Me.btnGenerateActivation.Size = New System.Drawing.Size(158, 24)
        Me.btnGenerateActivation.TabIndex = 19
        Me.btnGenerateActivation.Text = "R_RadButton1"
        '
        'cboApplication
        '
        Me.cboApplication.DataMember = Nothing
        Me.cboApplication.DataSource = Me.bsApps
        Me.cboApplication.DisplayMember = "CAPPS_NAME"
        Me.cboApplication.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList
        Me.cboApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboApplication.Location = New System.Drawing.Point(115, 9)
        Me.cboApplication.Name = "cboApplication"
        Me.cboApplication.R_ConductorGridSource = Nothing
        Me.cboApplication.R_ConductorSource = Nothing
        Me.cboApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboApplication.Size = New System.Drawing.Size(400, 20)
        Me.cboApplication.TabIndex = 2
        Me.cboApplication.Text = "R_RadDropDownList1"
        Me.cboApplication.ValueMember = "CAPPS_CODE"
        '
        'bsApps
        '
        Me.bsApps.DataSource = GetType(LAT00120Front.LAT00120ServiceRef.RLicenseAppComboDTO)
        '
        'lblInstallationId
        '
        Me.lblInstallationId.AutoSize = False
        Me.lblInstallationId.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblInstallationId.Location = New System.Drawing.Point(10, 121)
        Me.lblInstallationId.Name = "lblInstallationId"
        Me.lblInstallationId.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblInstallationId.R_ResourceId = "lblInstallationId"
        Me.lblInstallationId.Size = New System.Drawing.Size(100, 18)
        Me.lblInstallationId.TabIndex = 2
        Me.lblInstallationId.Text = "R_RadLabel1"
        '
        'lblCustomer
        '
        Me.lblCustomer.AutoSize = False
        Me.lblCustomer.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustomer.Location = New System.Drawing.Point(9, 33)
        Me.lblCustomer.Name = "lblCustomer"
        Me.lblCustomer.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustomer.R_ResourceId = "lblCustomer"
        Me.lblCustomer.Size = New System.Drawing.Size(100, 18)
        Me.lblCustomer.TabIndex = 1
        Me.lblCustomer.Text = "Customer..."
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 0
        Me.lblApplication.Text = "Application..."
        '
        'LAT00120
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "LAT00120"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.TableLayoutPanel1.ResumeLayout(False)
        CType(Me.gvActivation.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvActivation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsActivation, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.btnSaveActivation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grpServerType, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpServerType.ResumeLayout(False)
        Me.grpServerType.PerformLayout()
        CType(Me.rdbLive, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.rdbTest, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsCust, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtInstallationID, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnGenerateActivation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblInstallationId, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(false)

End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents cboCustomer As R_FrontEnd.R_RadDropDownList
    Friend WithEvents cboApplication As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblCustomer As R_FrontEnd.R_RadLabel
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource
    Friend WithEvents bsCust As System.Windows.Forms.BindingSource
    Friend WithEvents lblInstallationId As R_FrontEnd.R_RadLabel
    Friend WithEvents txtInstallationID As R_FrontEnd.R_RadTextBox
    Friend WithEvents bsActivation As System.Windows.Forms.BindingSource
    Friend WithEvents fbdSaveToFile As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents grpServerType As R_FrontEnd.R_RadGroupBox
    Friend WithEvents rdbLive As R_FrontEnd.R_RadRadioButton
    Friend WithEvents rdbTest As R_FrontEnd.R_RadRadioButton
    Friend WithEvents btnSaveActivation As R_FrontEnd.R_RadButton
    Friend WithEvents gvActivation As R_FrontEnd.R_RadGridView
    Friend WithEvents btnGenerateActivation As R_FrontEnd.R_RadButton

End Class
