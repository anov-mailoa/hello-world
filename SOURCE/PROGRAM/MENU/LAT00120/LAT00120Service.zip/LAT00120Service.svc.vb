﻿Imports R_Common
Imports RLicenseBack
Imports LAT00100Back
Imports LAT00120Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "LAT00120Service" in code, svc and config file together.
Public Class LAT00120Service
    Implements ILAT00120Service

    Public Function Dummy() As System.Collections.Generic.List(Of LAT00100Back.LAT00100ActivationDTO) Implements ILAT00120Service.Dummy

    End Function

    Public Function GetAppCombo(companyId As String, userId As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseAppComboDTO) Implements ILAT00120Service.GetAppCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseAppComboDTO)

        Try
            loRtn = loCls.GetAppCombo(companyId, userId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetCustCombo(companyId As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseCustComboDTO) Implements ILAT00120Service.GetCustCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseCustComboDTO)

        Try
            loRtn = loCls.GetCustCombo(companyId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetServerID(poPar As LAT00100Back.LAT00100KeyDTO) As String Implements ILAT00120Service.GetServerID
        Dim loException As New R_Exception
        Dim loCls As New LAT00100Cls
        Dim loRtn As String

        Try
            loRtn = loCls.GetServerID(poPar)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub RenewActivation(poNewEntity As LAT00100Back.LAT00100ActivationDTO) Implements ILAT00120Service.RenewActivation
        Dim loEx As New R_Exception
        Dim loCls As New LAT00120Cls

        Try
            loCls.RenewActivation(poNewEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub
End Class
