﻿Public Class LAT00120LastActivationDTO

    Public Property CAPPS_CODE As String
    Public Property CCUSTOMER_CODE As String
    Public Property CSTART_DATE As String
    Public Property CEXPIRY_DATE As String
    Public Property NGRACE_DAYS As Integer
    Public Property NWARNING_DAYS As Integer
    Public Property CNEXT_START_DATE As String
    Public Property CNEXT_EXPIRY_DATE As String

End Class
