﻿Imports LAT00100Back
Imports R_Common
Imports R_BackEnd
Imports System.Data.Common

Public Class LAT00120Cls

    Public Sub RenewActivation(poNewEntity As LAT00100ActivationDTO)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loLastActivation As LAT00120LastActivationDTO
        Dim loCls As New LAT00100Cls


        Try
            loConn = loDb.GetConnection()

            ' Get last activation

            lcQuery = "SELECT TOP 1 "
            lcQuery += "CAPPS_CODE, CCUSTOMER_CODE, "
            lcQuery += "CSTART_DATE, CEXPIRY_DATE, "
            lcQuery += "NGRACE_DAYS, NWARNING_DAYS, "
            lcQuery += "CONVERT(VARCHAR(8), DATEADD(day, 1, CONVERT(DATE, CEXPIRY_DATE, 112)), 112) AS CNEXT_START_DATE, "
            lcQuery += "CASE "
            lcQuery += "	WHEN DATEDIFF(year, CONVERT(DATE, CSTART_DATE, 112), DATEADD(day, 1, CONVERT(DATE, CEXPIRY_DATE, 112))) > 0 "
            lcQuery += "	THEN CONVERT(VARCHAR(8), DATEADD(year, DATEDIFF(year, CONVERT(DATE, CSTART_DATE, 112), DATEADD(day, 1, CONVERT(DATE, CEXPIRY_DATE, 112))), CONVERT(DATE, CEXPIRY_DATE, 112)), 112) "
            lcQuery += "ELSE "
            lcQuery += "	CASE WHEN DATEDIFF(month, CONVERT(DATE, CSTART_DATE, 112), DATEADD(day, 1, CONVERT(DATE, CEXPIRY_DATE, 112))) > 0 "
            lcQuery += "	THEN CONVERT(VARCHAR(8), DATEADD(month, DATEDIFF(month, CONVERT(DATE, CSTART_DATE, 112), DATEADD(day, 1, CONVERT(DATE, CEXPIRY_DATE, 112))), CONVERT(DATE, CEXPIRY_DATE, 112)), 112) "
            lcQuery += "ELSE "
            lcQuery += "	CASE WHEN DATEDIFF(day, CONVERT(DATE, CSTART_DATE, 112), DATEADD(day, 1, CONVERT(DATE, CEXPIRY_DATE, 112))) > 0 "
            lcQuery += "	THEN CONVERT(VARCHAR(8), DATEADD(day, DATEDIFF(day, CONVERT(DATE, CSTART_DATE, 112), DATEADD(day, 1, CONVERT(DATE, CEXPIRY_DATE, 112))), CONVERT(DATE, CEXPIRY_DATE, 112)), 112) "
            lcQuery += "ELSE CONVERT(VARCHAR(8), DATEADD(day, 1, CONVERT(DATE, CEXPIRY_DATE, 112)), 112) END END END AS CNEXT_EXPIRY_DATE "
            lcQuery += "FROM LAT_ACTIVATION(NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery += "AND CAPPS_CODE = '{1}' "
            lcQuery += "AND CCUSTOMER_CODE = '{2}' "
            lcQuery += "AND CSERVER_TYPE = '{3}' "
            lcQuery += "ORDER BY CGENERATE_TIME DESC "
            lcQuery = String.Format(lcQuery, _
                                    poNewEntity.CCOMPANY_ID, _
                                    poNewEntity.CAPPS_CODE, _
                                    poNewEntity.CCUSTOMER_CODE, _
                                    poNewEntity.CSERVER_TYPE)
            loLastActivation = loDb.SqlExecObjectQuery(Of LAT00120LastActivationDTO)(lcQuery).FirstOrDefault
            If loLastActivation IsNot Nothing Then
                With loLastActivation
                    poNewEntity.CSTART_DATE = .CNEXT_START_DATE
                    poNewEntity.CEXPIRY_DATE = .CNEXT_EXPIRY_DATE
                    poNewEntity.NGRACE_DAYS = .NGRACE_DAYS
                    poNewEntity.NWARNING_DAYS = .NWARNING_DAYS
                End With
                loCls.SaveActivation(poNewEntity)
            End If
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

End Class
