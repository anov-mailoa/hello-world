﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSM00200
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cboAttribute = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsAttribute = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridDesign = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.lblAttribute = New R_FrontEnd.R_RadLabel(Me.components)
        Me.cboApplication = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvDesign = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvDesign = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsVersion = New System.Windows.Forms.BindingSource(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.cboAttribute, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsAttribute, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridDesign, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblAttribute, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvDesign, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvDesign.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvDesign, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.gvDesign, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 72.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.cboAttribute)
        Me.Panel1.Controls.Add(Me.lblAttribute)
        Me.Panel1.Controls.Add(Me.cboApplication)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 66)
        Me.Panel1.TabIndex = 0
        '
        'cboAttribute
        '
        Me.cboAttribute.DataSource = Me.bsAttribute
        Me.cboAttribute.DisplayMember = "CATTRIBUTE_NAME"
        Me.cboAttribute.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboAttribute.Location = New System.Drawing.Point(115, 35)
        Me.cboAttribute.Name = "cboAttribute"
        Me.cboAttribute.R_ConductorGridSource = Me.conGridDesign
        Me.cboAttribute.R_ConductorSource = Nothing
        Me.cboAttribute.R_EnableOTHER = True
        Me.cboAttribute.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboAttribute.Size = New System.Drawing.Size(400, 20)
        Me.cboAttribute.TabIndex = 14
        Me.cboAttribute.Text = "R_RadDropDownList1"
        Me.cboAttribute.ValueMember = "CATTRIBUTE_ID"
        '
        'bsAttribute
        '
        Me.bsAttribute.DataSource = GetType(CSM00200Front.CSM00200ServiceRef.RCustDBAttributeComboDTO)
        '
        'conGridDesign
        '
        Me.conGridDesign.R_ConductorParent = Nothing
        Me.conGridDesign.R_IsHeader = True
        Me.conGridDesign.R_RadGroupBox = Nothing
        '
        'lblAttribute
        '
        Me.lblAttribute.AutoSize = False
        Me.lblAttribute.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblAttribute.Location = New System.Drawing.Point(9, 35)
        Me.lblAttribute.Name = "lblAttribute"
        Me.lblAttribute.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblAttribute.R_ResourceId = "lblAttribute"
        Me.lblAttribute.Size = New System.Drawing.Size(100, 18)
        Me.lblAttribute.TabIndex = 13
        Me.lblAttribute.Text = "Application..."
        '
        'cboApplication
        '
        Me.cboApplication.DataSource = Me.bsApps
        Me.cboApplication.DisplayMember = "CAPPS_NAME"
        Me.cboApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboApplication.Location = New System.Drawing.Point(115, 9)
        Me.cboApplication.Name = "cboApplication"
        Me.cboApplication.R_ConductorGridSource = Me.conGridDesign
        Me.cboApplication.R_ConductorSource = Nothing
        Me.cboApplication.R_EnableOTHER = True
        Me.cboApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboApplication.Size = New System.Drawing.Size(400, 20)
        Me.cboApplication.TabIndex = 10
        Me.cboApplication.Text = "R_RadDropDownList1"
        Me.cboApplication.ValueMember = "CAPPS_CODE"
        '
        'bsApps
        '
        Me.bsApps.DataSource = GetType(CSM00200Front.CSM00200ServiceRef.RLicenseAppComboDTO)
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 9
        Me.lblApplication.Text = "Application..."
        '
        'gvDesign
        '
        Me.gvDesign.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvDesign.EnableFastScrolling = True
        Me.gvDesign.Location = New System.Drawing.Point(3, 75)
        '
        '
        '
        Me.gvDesign.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn1.FieldName = "_CDOCUMENT_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CDOCUMENT_ID"
        R_GridViewTextBoxColumn1.Name = "_CDOCUMENT_ID"
        R_GridViewTextBoxColumn1.R_EnableADD = True
        R_GridViewTextBoxColumn1.R_ResourceId = "_CDOCUMENT_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 111
        R_GridViewTextBoxColumn2.FieldName = "_CDOCUMENT_NAME"
        R_GridViewTextBoxColumn2.HeaderText = "_CDOCUMENT_NAME"
        R_GridViewTextBoxColumn2.Name = "_CDOCUMENT_NAME"
        R_GridViewTextBoxColumn2.R_EnableADD = True
        R_GridViewTextBoxColumn2.R_EnableEDIT = True
        R_GridViewTextBoxColumn2.R_ResourceId = "_CDOCUMENT_NAME"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 132
        R_GridViewTextBoxColumn3.FieldName = "_CINITIAL_VERSION"
        R_GridViewTextBoxColumn3.HeaderText = "_CINITIAL_VERSION"
        R_GridViewTextBoxColumn3.Name = "_CINITIAL_VERSION"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CINITIAL_VERSION"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 120
        Me.gvDesign.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3})
        Me.gvDesign.MasterTemplate.DataSource = Me.bsGvDesign
        Me.gvDesign.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvDesign.MasterTemplate.EnableFiltering = True
        Me.gvDesign.MasterTemplate.EnableGrouping = False
        Me.gvDesign.MasterTemplate.ShowFilteringRow = False
        Me.gvDesign.MasterTemplate.ShowGroupedColumns = True
        Me.gvDesign.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvDesign.Name = "gvDesign"
        Me.gvDesign.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvDesign.R_ConductorGridSource = Me.conGridDesign
        Me.gvDesign.R_ConductorSource = Nothing
        Me.gvDesign.R_DataAdded = False
        Me.gvDesign.R_NewRowText = Nothing
        Me.gvDesign.ShowHeaderCellButtons = True
        Me.gvDesign.Size = New System.Drawing.Size(1271, 497)
        Me.gvDesign.TabIndex = 1
        Me.gvDesign.Text = "R_RadGridView1"
        '
        'bsGvDesign
        '
        Me.bsGvDesign.DataSource = GetType(CSM00200Front.CSM00200ServiceRef.CSM00200DTO)
        '
        'bsVersion
        '
        Me.bsVersion.DataSource = GetType(CSM00200Front.CSM00200ServiceRef.RCustDBVersionComboDTO)
        '
        'CSM00200
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CSM00200"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.cboAttribute, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsAttribute, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridDesign, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblAttribute, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvDesign.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvDesign, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvDesign, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents gvDesign As R_FrontEnd.R_RadGridView
    Friend WithEvents conGridDesign As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource
    Friend WithEvents bsVersion As System.Windows.Forms.BindingSource
    Friend WithEvents bsAttribute As System.Windows.Forms.BindingSource
    Friend WithEvents bsGvDesign As System.Windows.Forms.BindingSource
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents cboAttribute As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblAttribute As R_FrontEnd.R_RadLabel
    Friend WithEvents cboApplication As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel

End Class
