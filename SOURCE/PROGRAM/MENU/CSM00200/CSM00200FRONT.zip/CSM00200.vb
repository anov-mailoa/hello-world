﻿Imports CSM00200Front.CSM00200ServiceRef
Imports CSM00200FrontResources
Imports R_Common
Imports R_FrontEnd
Imports ClientHelper
Imports CSM00200Front.CSM00200StreamingServiceRef
Imports System.ServiceModel.Channels
Imports System.ServiceModel

Public Class CSM00200

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSM00200Service/CSM00200Service.svc"
    Dim C_ServiceNameStream As String = "CSM00200Service/CSM00200StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim llInitialized As Boolean = False
#End Region

#Region " SUB and FUNCTION "

    Private Sub RefreshGrids()
        Dim loTableKey As New CSM00200KeyDTO

        With loTableKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = cboApplication.SelectedValue.Trim
            .CATTRIBUTE_GROUP = "DESIGN"
            .CATTRIBUTE_ID = cboAttribute.SelectedValue.Trim
        End With

        With gvDesign
            .R_RefreshGrid(loTableKey)
            .Columns(0).Sort(Telerik.WinControls.UI.RadSortOrder.Ascending, False)
        End With
    End Sub

    Private Sub RefreshAttributeCombo()
        Dim loService As CSM00200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00200Service, CSM00200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)

        bsAttribute.DataSource = loService.GetAttributeCombo(_CCOMPID, cboApplication.SelectedValue.Trim, "DESIGN")
        loService.Close()
    End Sub

#End Region

#Region " FORM Methods "

    Private Sub CSM00200_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Dim loSvc As CSM00200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00200Service, CSM00200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loAppCombo As New List(Of RLicenseAppComboDTO)

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            ' Application
            loAppCombo = loSvc.GetAppCombo(_CCOMPID, _CUSERID)
            If loAppCombo.Count <= 0 Then
                cboApplication.Items.Clear()
                gvDesign.Enabled = False
            End If
            bsApps.DataSource = loAppCombo

            ' Predefined dock
            Me.R_Components = Me.components
            'preVersion.R_HeaderTitle = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00200VersionTitle")
            If loSvc IsNot Nothing Then
                loSvc.Close()
            End If

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub CSM00200_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " COMBO Actions "

    Private Sub cboApplication_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboApplication.SelectedValueChanged
        Dim loEx As New R_Exception
        Dim loSvc As CSM00200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00200Service, CSM00200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loVersionCombo As New List(Of RCustDBVersionComboDTO)
        Dim loAttributeCombo As New List(Of RCustDBAttributeComboDTO)

        Try
            ' Attribute Field
            loAttributeCombo = loSvc.GetAttributeCombo(_CCOMPID, CType(sender, R_RadDropDownList).SelectedValue, "DESIGN")
            If loAttributeCombo.Count <= 0 Then
                cboAttribute.Items.Clear()
            End If
            bsAttribute.DataSource = loAttributeCombo
            loSvc.Close()
            If cboAttribute.Items.Count > 0 Then
                llInitialized = True
            Else
                llInitialized = False
            End If
            gvDesign.Enabled = llInitialized
            If llInitialized Then
                RefreshGrids()
            End If
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loSvc IsNot Nothing Then
            loSvc.Close()
        End If
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub cboAttribute_TextChanged(sender As Object, e As System.EventArgs) Handles cboAttribute.TextChanged
        If llInitialized Then
            RefreshGrids()
        End If
    End Sub
#End Region

#Region " GRIDVIEW Events "

    Private Sub gvDesign_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvDesign.R_Saving
        With CType(poEntity, CSM00200DTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = cboApplication.SelectedValue.Trim
            ._CATTRIBUTE_GROUP = "DESIGN"
            ._CATTRIBUTE_ID = cboAttribute.SelectedValue.Trim
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With

    End Sub

    Private Sub gvDesign_R_ServiceDelete(poEntity As Object) Handles gvDesign.R_ServiceDelete
        Dim loService As CSM00200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00200Service, CSM00200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String

        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As FaultException
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loService IsNot Nothing Then
            loService.Close()
        End If

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvDesign_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvDesign.R_ServiceGetListRecord
        Dim loServiceStream As CSM00200StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00200StreamingService, CSM00200StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00200GridDTO)
        Dim loListEntity As New List(Of CSM00200DTO)

        Try
            With CType(poEntity, CSM00200KeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cAttributeGroup", .CATTRIBUTE_GROUP)
                R_Utility.R_SetStreamingContext("cAttributeId", .CATTRIBUTE_ID)
            End With

            loRtn = loServiceStream.GetDesignList()
            loStreaming = R_StreamUtility(Of CSM00200GridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00200GridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New CSM00200DTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                                  ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                                  ._CATTRIBUTE_GROUP = loDto.CATTRIBUTE_GROUP,
                                                           ._CATTRIBUTE_ID = loDto.CATTRIBUTE_ID,
                                                           ._CDOCUMENT_ID = loDto.CDOCUMENT_ID,
                                                           ._CDOCUMENT_NAME = loDto.CDOCUMENT_NAME,
                                                           ._CINITIAL_VERSION = loDto.CINITIAL_VERSION,
                                                                  ._CCREATE_BY = loDto.CCREATE_BY,
                                                                  ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                                  ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                                  ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        If loServiceStream IsNot Nothing Then
            loServiceStream.Close()
        End If
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvDesign_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvDesign.R_ServiceGetRecord
        Dim loService As CSM00200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00200Service, CSM00200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New CSM00200DTO With {._CCOMPANY_ID = _CCOMPID,
                                                                             ._CAPPS_CODE = cboApplication.SelectedValue.Trim,
                                                                             ._CATTRIBUTE_GROUP = "DESIGN",
                                                                             ._CATTRIBUTE_ID = cboAttribute.SelectedValue.Trim,
                                                                             ._CDOCUMENT_ID = CType(bsGvDesign.Current, CSM00200DTO)._CDOCUMENT_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loService IsNot Nothing Then
            loService.Close()
        End If

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvDesign_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvDesign.R_ServiceSave
        Dim loService As CSM00200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00200Service, CSM00200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loService IsNot Nothing Then
            loService.Close()
        End If

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvDesign_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvDesign.R_Validation
        Dim loEx As New R_Exception()

        Try
            pcError = ""
            With poGridCellCollection
                If String.IsNullOrWhiteSpace(.Item("_CDOCUMENT_ID").Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00200_01")
                    loEx.Add("CSM00200_01", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00200_01"))
                    plCancel = True
                End If

                If String.IsNullOrWhiteSpace(.Item("_CDOCUMENT_NAME").Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00200_02")
                    loEx.Add("CSM00200_02", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00200_02"))
                    plCancel = True
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " PREDEFINED DOCK Events "

    Private Sub preVersion_R_InstantiateDock(ByRef poTargetForm As R_FrontEnd.R_FormBase)
        poTargetForm = New CSM00200Version
    End Sub

    Private Sub preVersion_R_PassParameter(ByRef poParameter As Object)
        Dim loParam As New CSM00200ParamDTO

        With loParam
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = cboApplication.SelectedValue.Trim
            .CAPPS_NAME = cboApplication.Text.Trim
            .CATTRIBUTE_GROUP = "DESIGN"
            .CATTRIBUTE_ID = cboAttribute.SelectedValue.Trim
            .CATTRIBUTE_NAME = cboAttribute.Text.Trim
            .CDOCUMENT_ID = CType(bsGvDesign.Current, CSM00200DTO)._CDOCUMENT_ID
            .CDOCUMENT_NAME = CType(bsGvDesign.Current, CSM00200DTO)._CDOCUMENT_NAME
        End With

        poParameter = loParam
    End Sub

#End Region

End Class
