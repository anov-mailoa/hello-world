﻿Public Class CSM00200ParamDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CAPPS_NAME As String
    Public Property CATTRIBUTE_GROUP As String
    Public Property CATTRIBUTE_ID As String
    Public Property CATTRIBUTE_NAME As String
    Public Property CDOCUMENT_ID As String
    Public Property CDOCUMENT_NAME As String
End Class
