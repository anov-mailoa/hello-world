﻿Imports CSM00200FrontResources
Imports R_Common
Imports ClientHelper

Public Class CSM00200Version

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSM00200Service/CSM00200Service.svc"
    Dim C_ServiceNameStream As String = "CSM00200Service/CSM00200StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
#End Region

#Region " FORM Methods "

    Private Sub CSM00200Version_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            With CType(poParameter, CSM00200ParamDTO)
                _CAPPSCODE = .CAPPS_CODE
                lblHeader.Text = .CAPPS_NAME.Trim & " / " & _
                    .CATTRIBUTE_NAME.Trim & " / " & _
                    .CDOCUMENT_NAME.Trim & " - Version List"
            End With

            'RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

#End Region

End Class
