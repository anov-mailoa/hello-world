﻿Public Class CSM00200VersionGridDTO

    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CATTRIBUTE_GROUP As String
    Public Property CATTRIBUTE_ID As String
    Public Property CDOCUMENT_ID As String
    Public Property CVERSION As String
    Public Property CDOCUMENT_STATUS As String
    Public Property CCURRENT_PROJECT As String
    Public Property CCURRENT_SESSION As String
    Public Property CPROJECT_STATUS As String
    Public Property CLAST_ACTION As String
    Public Property CLAST_ACTION_BY As String
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)
    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)

End Class
