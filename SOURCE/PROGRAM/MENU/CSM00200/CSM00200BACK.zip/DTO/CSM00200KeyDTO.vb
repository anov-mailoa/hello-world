﻿Public Class CSM00200KeyDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CATTRIBUTE_GROUP As String
    Public Property CATTRIBUTE_ID As String
    Public Property CDOCUMENT_ID As String
    Public Property CVERSION As String
End Class
