﻿Imports R_BackEnd
Imports R_Common
Imports System.Data.Common
Imports ServerHelper.General

Public Class CSM00200Cls
    Inherits R_BusinessObject(Of CSM00200DTO)

    Public Function GetDesignList(poKey As CSM00200KeyDTO) As List(Of CSM00200GridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00200GridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CSM_DESIGNS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID)
            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00200GridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetDesignVersionList(poKey As CSM00200KeyDTO) As List(Of CSM00200VersionGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00200VersionGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CSM_DESIGN_VERSIONS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                lcQuery += "AND CDOCUMENT_ID = '{4}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CDOCUMENT_ID)
            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00200VersionGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetDesignRevisionList(poKey As CSM00200KeyDTO) As List(Of Object)

    End Function

    Protected Overrides Sub R_Deleting(poEntity As CSM00200DTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcRtn As String

        Try
            loConn = loDb.GetConnection()

            With poEntity

                'validation
                loCmd = loDb.GetCommand()
                lcQuery = "EXEC RSP_Delete_Design_Validation '{0}', '{1}', '{2}', '{3}', '{4}', @CRET_MSG OUTPUT "
                With poEntity
                    lcQuery = String.Format(lcQuery, _
                                            .CCOMPANY_ID, _
                                            .CAPPS_CODE, _
                                            .CATTRIBUTE_GROUP, _
                                            .CATTRIBUTE_ID,
                                            .CDOCUMENT_ID)
                End With
                loCmd.CommandText = lcQuery
                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@CRET_MSG"
                    .DbType = DbType.String
                    .Size = 50
                    .Direction = ParameterDirection.Output
                End With
                loCmd.Parameters.Add(loPar)
                loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)

                If loCmd.Parameters("@CRET_MSG") Is Nothing Then
                    lcRtn = "UNKNOWN_ERROR"
                Else
                    lcRtn = loCmd.Parameters("@CRET_MSG").Value
                End If

                If Not lcRtn.Equals("OK") Then
                    Throw New Exception(lcRtn)
                End If

                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "CSM_DESIGNS "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                lcQuery += "AND CDOCUMENT_ID = '{4}' "

                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CDOCUMENT_ID)

                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As CSM00200DTO) As CSM00200DTO
        Dim lcQuery As String
        Dim loResult As CSM00200DTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CSM_DESIGNS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                lcQuery += "AND CDOCUMENT_ID = '{4}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CDOCUMENT_ID)

                loResult = loDb.SqlExecObjectQuery(Of CSM00200DTO)(lcQuery).FirstOrDefault

            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As CSM00200DTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim lcVersion As String

        Try
            loConn = loDb.GetConnection()

            With poNewEntity
                If poCRUDMode = eCRUDMode.AddMode Then

                    .CUPDATE_BY = .CUPDATE_BY
                    .CCREATE_BY = .CUPDATE_BY

                    ' cari current open version
                    lcQuery = "SELECT CVERSION = dbo.RFN_Get_Current_Version('{0}', '{1}') "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE)

                    lcVersion = loDb.SqlExecObjectQuery(Of String)(lcQuery).FirstOrDefault
                    .CINITIAL_VERSION = lcVersion

                    lcQuery = "INSERT INTO CSM_DESIGNS ("
                    lcQuery += "CCOMPANY_ID, "
                    lcQuery += "CAPPS_CODE, "
                    lcQuery += "CATTRIBUTE_GROUP, "
                    lcQuery += "CATTRIBUTE_ID, "
                    lcQuery += "CDOCUMENT_ID, "
                    lcQuery += "CDOCUMENT_NAME, "
                    lcQuery += "CINITIAL_VERSION, "
                    lcQuery += "CUPDATE_BY, "
                    lcQuery += "DUPDATE_DATE, "
                    lcQuery += "CCREATE_BY, "
                    lcQuery += "DCREATE_DATE) "
                    lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', GETDATE(), '{8}', GETDATE()) "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CATTRIBUTE_GROUP,
                    .CATTRIBUTE_ID,
                    .CDOCUMENT_ID,
                    .CDOCUMENT_NAME,
                    .CINITIAL_VERSION,
                    .CUPDATE_BY,
                    .CCREATE_BY)

                ElseIf poCRUDMode = eCRUDMode.EditMode Then
                    lcQuery = "UPDATE CSM_DESIGNS "
                    lcQuery += "SET "
                    lcQuery += "CDOCUMENT_NAME = '{5}', "
                    lcQuery += "CUPDATE_BY = '{6}', "
                    lcQuery += "DUPDATE_DATE = GETDATE() "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                    lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                    lcQuery += "AND CDOCUMENT_ID = '{4}' "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CATTRIBUTE_GROUP,
                    .CATTRIBUTE_ID,
                    .CDOCUMENT_ID,
                    .CDOCUMENT_NAME,
                    .CUPDATE_BY)

                End If
            End With
            loDb.SqlExecNonQuery(lcQuery, loConn, True)
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

End Class
