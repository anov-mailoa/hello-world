﻿Imports R_Common
Imports R_BackEnd
Imports System.Data.Common
Imports System.Transactions
Imports ServerHelper.General

Public Class LAM00100Cls
    Inherits R_BusinessObject(Of LAM00100DTO)

    Protected Overrides Sub R_Deleting(poEntity As LAM00100DTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loResult As LAM00100DTO

        Try
            loConn = loDb.GetConnection()

            ' validasi
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "LAM_APP_CUST (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery += "AND CAPPS_CODE = '{1}' "
            lcQuery = String.Format(lcQuery, poEntity.CCOMPANY_ID, poEntity.CAPPS_CODE)

            loResult = loDb.SqlExecObjectQuery(Of LAM00100DTO)(lcQuery, loConn, False).FirstOrDefault
            If loResult IsNot Nothing Then
                Throw New Exception("Application Code " + poEntity.CAPPS_CODE.Trim + " has already been used.")
            End If

            Using TransScope As New TransactionScope(TransactionScopeOption.Required)
                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "LAM_APPS "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' AND CAPPS_CODE = '{1}' "
                lcQuery = String.Format(lcQuery, poEntity.CCOMPANY_ID, poEntity.CAPPS_CODE)

                loDb.SqlExecNonQuery(lcQuery, loConn, True)

                TransScope.Complete()
            End Using

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As LAM00100DTO) As LAM00100DTO
        Dim lcQuery As String
        Dim loResult As LAM00100DTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "LAM_APPS (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery += "AND CAPPS_CODE = '{1}' "
            lcQuery = String.Format(lcQuery, poEntity.CCOMPANY_ID, poEntity.CAPPS_CODE)

            loResult = loDb.SqlExecObjectQuery(Of LAM00100DTO)(lcQuery).FirstOrDefault
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As LAM00100DTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As LAM00100DTO

        Try
            loConn = loDb.GetConnection()

            If poCRUDMode = eCRUDMode.AddMode Then
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "LAM_APPS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery = String.Format(lcQuery, poNewEntity.CCOMPANY_ID, poNewEntity.CAPPS_CODE)

                loResult = loDb.SqlExecObjectQuery(Of LAM00100DTO)(lcQuery, loConn, True).FirstOrDefault
                If loResult IsNot Nothing Then
                    Throw New Exception("Application Code " + poNewEntity.CAPPS_CODE.Trim + " is already exist")
                End If

                With poNewEntity
                    .CCREATE_BY = .CUPDATE_BY
                    .DUPDATE_DATE = Now
                    .DCREATE_DATE = Now
                End With

                lcQuery = "INSERT INTO LAM_APPS ("
                lcQuery += "CCOMPANY_ID, "
                lcQuery += "CAPPS_CODE, "
                lcQuery += "CAPPS_NAME, "
                lcQuery += "CDESCRIPTION, "
                lcQuery += "CUPDATE_BY, "
                lcQuery += "DUPDATE_DATE, "
                lcQuery += "CCREATE_BY, "
                lcQuery += "DCREATE_DATE) "
                lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', {5}, '{6}', {7}) "
                lcQuery = String.Format(lcQuery,
                poNewEntity.CCOMPANY_ID,
                poNewEntity.CAPPS_CODE,
                poNewEntity.CAPPS_NAME,
                poNewEntity.CDESCRIPTION,
                poNewEntity.CUPDATE_BY,
                getDate(poNewEntity.DUPDATE_DATE),
                poNewEntity.CCREATE_BY,
                getDate(poNewEntity.DCREATE_DATE))

                loDb.SqlExecNonQuery(lcQuery)

            ElseIf poCRUDMode = eCRUDMode.EditMode Then
                lcQuery = "UPDATE LAM_APPS "
                lcQuery += "SET "
                lcQuery += "CAPPS_NAME = '{2}', "
                lcQuery += "CDESCRIPTION = '{3}', "
                lcQuery += "CUPDATE_BY = '{4}', "
                lcQuery += "DUPDATE_DATE = {5} "
                lcQuery += "WHERE "
                lcQuery += "CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery = String.Format(lcQuery,
                poNewEntity.CCOMPANY_ID,
                poNewEntity.CAPPS_CODE,
                poNewEntity.CAPPS_NAME,
                poNewEntity.CDESCRIPTION,
                poNewEntity.CUPDATE_BY,
                getDate(poNewEntity.DUPDATE_DATE))

                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End If

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Function getAppList(pcCompany_ID As String) As List(Of LAM00100GridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of LAM00100GridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "LAM_APPS (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery = String.Format(lcQuery, pcCompany_ID)

            loResult = loDb.SqlExecObjectQuery(Of LAM00100GridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

End Class
