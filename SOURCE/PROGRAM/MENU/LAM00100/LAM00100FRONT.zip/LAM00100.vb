﻿Imports R_FrontEnd
Imports LAM00100Front.LAM00100ServiceRef
Imports LAM00100Front.LAM00100StreamingServiceRef
Imports R_Common
Imports System.ServiceModel.Channels
Imports ClientHelper
Imports LAM00100FrontResources

Public Class LAM00100

#Region " VARIABLE "
    Dim C_ServiceName As String = "LAM00100Service/LAM00100Service.svc"
    Dim C_ServiceNameStream As String = "LAM00100Service/LAM00100StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
#End Region

    Private Sub LAM00100_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            gvApps.R_RefreshGrid(_CCOMPID)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#Region "GRIDVIEW APPLICATIONS"

    Private Sub gvApps_R_AfterAdd(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection) Handles gvApps.R_AfterAdd
        poGridCellCollection(5).Value = _CUSERID
        poGridCellCollection(6).Value = DateTime.Now
    End Sub

    Private Sub gvApps_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvApps.R_Saving
        With CType(poEntity, LAM00100DTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With
    End Sub

    Private Sub gvApps_R_ServiceDelete(poEntity As Object) Handles gvApps.R_ServiceDelete
        Dim loService As LAM00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00100Service, LAM00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            With CType(poEntity, LAM00100DTO)
                ._CCOMPANY_ID = _CCOMPID
            End With

            loService.Svc_R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvApps_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvApps.R_ServiceGetListRecord
        Dim loServiceStream As LAM00100StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00100StreamingService, LAM00100StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of LAM00100GridDTO)
        Dim loListEntity As New List(Of LAM00100DTO)

        Try
            R_Utility.R_SetStreamingContext("cCompId", poEntity)

            loRtn = loServiceStream.GetAppList()
            loStreaming = R_StreamUtility(Of LAM00100GridDTO).ReadFromMessage(loRtn)

            For Each loDto As LAM00100GridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New LAM00100DTO With {._CAPPS_CODE = loDto.CAPPS_CODE,
                                                           ._CAPPS_NAME = loDto.CAPPS_NAME,
                                                           ._CCREATE_BY = loDto.CCREATE_BY,
                                                           ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                           ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                           ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()

    End Sub


    Private Sub gvApps_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvApps.R_ServiceGetRecord
        Dim loService As LAM00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00100Service, LAM00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New LAM00100DTO With {._CCOMPANY_ID = _CCOMPID,
                                                                            ._CAPPS_CODE = CType(bsGvApps.Current, LAM00100DTO)._CAPPS_CODE})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

    Private Sub gvApps_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvApps.R_ServiceSave
        Dim loService As LAM00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00100Service, LAM00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvApps_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvApps.R_Validation
        Dim loEx As New R_Exception()

        Try
            pcError = ""
            With poGridCellCollection
                If String.IsNullOrWhiteSpace(.Item(0).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS001")
                    loEx.Add("PS001", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS001"))
                    plCancel = True
                End If

                If String.IsNullOrWhiteSpace(.Item(1).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS002")
                    loEx.Add("PS002", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS002"))
                    plCancel = True
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
#End Region

    Private Sub LAM00100_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub
End Class
