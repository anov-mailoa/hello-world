﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LAM00100
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn2 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Me.gvApps = New R_FrontEnd.R_RadGridView(Me.components)
        Me.conGridApps = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.bsGvApps = New System.Windows.Forms.BindingSource(Me.components)
        CType(Me.gvApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvApps.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'gvApps
        '
        Me.gvApps.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvApps.Location = New System.Drawing.Point(0, 0)
        '
        '
        '
        Me.gvApps.MasterTemplate.AutoGenerateColumns = False
        Me.gvApps.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn1.FieldName = "_CAPPS_CODE"
        R_GridViewTextBoxColumn1.HeaderText = "_CAPPS_CODE"
        R_GridViewTextBoxColumn1.Name = "_CAPPS_CODE"
        R_GridViewTextBoxColumn1.R_EnableADD = True
        R_GridViewTextBoxColumn1.R_ResourceId = "_CAPPS_CODE"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 161
        R_GridViewTextBoxColumn2.FieldName = "_CAPPS_NAME"
        R_GridViewTextBoxColumn2.HeaderText = "_CAPPS_NAME"
        R_GridViewTextBoxColumn2.Name = "_CAPPS_NAME"
        R_GridViewTextBoxColumn2.R_EnableADD = True
        R_GridViewTextBoxColumn2.R_EnableEDIT = True
        R_GridViewTextBoxColumn2.R_ResourceId = "_CAPPS_NAME"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 23
        R_GridViewTextBoxColumn3.FieldName = "_CDESCRIPTION"
        R_GridViewTextBoxColumn3.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxColumn3.Name = "_CDESCRIPTION"
        R_GridViewTextBoxColumn3.R_EnableADD = True
        R_GridViewTextBoxColumn3.R_EnableEDIT = True
        R_GridViewTextBoxColumn3.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 308
        R_GridViewTextBoxColumn4.FieldName = "_CUPDATE_BY"
        R_GridViewTextBoxColumn4.HeaderText = "_CUPDATE_BY"
        R_GridViewTextBoxColumn4.Name = "_CUPDATE_BY"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CUPDATE_BY"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 53
        R_GridViewDateTimeColumn1.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn1.FieldName = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.HeaderText = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.Name = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.R_ResourceId = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.Width = 62
        R_GridViewTextBoxColumn5.FieldName = "_CCREATE_BY"
        R_GridViewTextBoxColumn5.HeaderText = "_CCREATE_BY"
        R_GridViewTextBoxColumn5.Name = "_CCREATE_BY"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CCREATE_BY"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 62
        R_GridViewDateTimeColumn2.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn2.FieldName = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.HeaderText = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.Name = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.R_ResourceId = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.Width = 68
        Me.gvApps.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewTextBoxColumn4, R_GridViewDateTimeColumn1, R_GridViewTextBoxColumn5, R_GridViewDateTimeColumn2})
        Me.gvApps.MasterTemplate.DataSource = Me.bsGvApps
        Me.gvApps.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvApps.MasterTemplate.EnableFiltering = True
        Me.gvApps.MasterTemplate.EnableGrouping = False
        Me.gvApps.MasterTemplate.ShowGroupedColumns = True
        Me.gvApps.Name = "gvApps"
        Me.gvApps.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvApps.R_ConductorGridSource = Me.conGridApps
        Me.gvApps.R_ConductorSource = Nothing
        Me.gvApps.R_DataAdded = False
        Me.gvApps.R_NewRowText = Nothing
        Me.gvApps.Size = New System.Drawing.Size(751, 308)
        Me.gvApps.TabIndex = 0
        Me.gvApps.Text = "R_RadGridView1"
        '
        'conGridApps
        '
        Me.conGridApps.R_ConductorParent = Nothing
        Me.conGridApps.R_IsHeader = True
        Me.conGridApps.R_RadGroupBox = Nothing
        '
        'bsGvApps
        '
        Me.bsGvApps.DataSource = GetType(LAM00100Front.LAM00100ServiceRef.LAM00100DTO)
        '
        'LAM00100
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(751, 308)
        Me.Controls.Add(Me.gvApps)
        Me.Name = "LAM00100"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.gvApps.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents gvApps As R_FrontEnd.R_RadGridView
    Friend WithEvents bsGvApps As System.Windows.Forms.BindingSource
    Friend WithEvents conGridApps As R_FrontEnd.R_ConductorGrid

End Class
