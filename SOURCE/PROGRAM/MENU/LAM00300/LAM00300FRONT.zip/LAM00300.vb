﻿Imports R_FrontEnd
Imports LAM00300Front.LAM00300ServiceRef
Imports LAM00300Front.LAM00300StreamingServiceRef
Imports R_Common
Imports System.ServiceModel.Channels
Imports ClientHelper
Imports LAM00300FrontResources

Public Class LAM00300

#Region " VARIABLE "
    Dim C_ServiceName As String = "LAM00300Service/LAM00300Service.svc"
    Dim C_ServiceNameStream As String = "LAM00300Service/LAM00300StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPS_CODE As String
    Dim _CCUSTOMER_CODE As String
    Dim _CSQL_INSTANCE As String
    Dim _CSQL_USER As String
    Dim llInitialized As Boolean = False
#End Region

    Private Sub LAM00300_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loSvc As LAM00300ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00300Service, LAM00300ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loAppCombo As New List(Of RLicenseAppComboDTO)
        Dim loCustCombo As New List(Of RLicenseCustComboDTO)

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            ' Application
            loAppCombo = loSvc.GetAppCombo(_CCOMPID, _CUSERID)
            bsApps.DataSource = loAppCombo

            ' Customer
            loCustCombo = loSvc.GetCustCombo(_CCOMPID)
            bsCust.DataSource = loCustCombo

            llInitialized = True
            RefreshGrids()

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub RefreshGrids()
        Dim loTableKey As New LAM00300DTO
        Dim loSvc As LAM00300ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00300Service, LAM00300ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)

        _CAPPS_CODE = cboApplication.SelectedValue.Trim
        With loTableKey
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = _CAPPS_CODE
        End With

        gvSqlUser.R_RefreshGrid(loTableKey)

    End Sub

    Private Sub DisplayEncryptedPassword(pcPassword As String)
        Dim STR_SaltKey As String = "K3YR34LT43861772_K3YRND101601778"
        If pcPassword.Trim.Equals("") Then
            txtEncryptedPassword.Text = ""
            btnSaveToFile.Enabled = False
        Else
            txtEncryptedPassword.Text = R_Utility.Encrypt(pcPassword, STR_SaltKey)
            btnSaveToFile.Enabled = True
        End If
    End Sub

#Region "GRIDVIEW SQL CREDENTIALS"

    Private Sub gvSqlUser_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvSqlUser.R_Display
        With CType(poEntity, LAM00300DTO)
            DisplayEncryptedPassword(._CSQL_PASSWORD)
            _CCUSTOMER_CODE = ._CCUSTOMER_CODE
            _CSQL_INSTANCE = ._CSQL_INSTANCE
            _CSQL_USER = ._CSQL_USER
        End With
    End Sub

    Private Sub gvSqlUser_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvSqlUser.R_Saving
        With CType(poEntity, LAM00300DTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = _CAPPS_CODE
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With

    End Sub

    Private Sub gvSqlUser_R_ServiceDelete(poEntity As Object) Handles gvSqlUser.R_ServiceDelete
        Dim loService As LAM00300ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00300Service, LAM00300ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            With CType(poEntity, LAM00300DTO)
                ._CCOMPANY_ID = _CCOMPID
                ._CAPPS_CODE = _CAPPS_CODE
            End With

            loService.Svc_R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSqlUser_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvSqlUser.R_ServiceGetListRecord
        Dim loServiceStream As LAM00300StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00300StreamingService, LAM00300StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of LAM00300GridDTO)
        Dim loListEntity As New List(Of LAM00300DTO)

        Try
            With poEntity
                R_Utility.R_SetStreamingContext("cCompanyId", ._CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", ._CAPPS_CODE)
            End With

            loRtn = loServiceStream.GetCustAppSqlList()
            loStreaming = R_StreamUtility(Of LAM00300GridDTO).ReadFromMessage(loRtn)

            For Each loDto As LAM00300GridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New LAM00300DTO With {._CAPPS_CODE = loDto.CAPPS_CODE,
                                                           ._CCUSTOMER_CODE = loDto.CCUSTOMER_CODE,
                                                           ._CSQL_INSTANCE = loDto.CSQL_INSTANCE,
                                                           ._CSQL_USER = loDto.CSQL_USER,
                                                           ._CSQL_PASSWORD = loDto.CSQL_PASSWORD,
                                                           ._CNOTE = loDto.CNOTE,
                                                           ._CCREATE_BY = loDto.CCREATE_BY,
                                                           ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                           ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                           ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity

            If poListEntityResult.Count = 0 Then
                DisplayEncryptedPassword("")
            End If
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSqlUser_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvSqlUser.R_ServiceGetRecord
        Dim loService As LAM00300ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00300Service, LAM00300ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New LAM00300DTO With {._CCOMPANY_ID = _CCOMPID,
                                                                            ._CAPPS_CODE = CType(bsGvSqlUser.Current, LAM00300DTO)._CAPPS_CODE,
                                                                             ._CCUSTOMER_CODE = CType(bsGvSqlUser.Current, LAM00300DTO)._CCUSTOMER_CODE,
                                                                             ._CSQL_INSTANCE = CType(bsGvSqlUser.Current, LAM00300DTO)._CSQL_INSTANCE,
                                                                             ._CSQL_USER = CType(bsGvSqlUser.Current, LAM00300DTO)._CSQL_USER})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSqlUser_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvSqlUser.R_ServiceSave
        Dim loService As LAM00300ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00300Service, LAM00300ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSqlUser_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvSqlUser.R_Validation
        Dim loEx As New R_Exception()

        Try
            pcError = ""
            With poGridCellCollection
                If String.IsNullOrWhiteSpace(.Item(0).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS001")
                    loEx.Add("PS001", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS001"))
                    plCancel = True
                End If

                If String.IsNullOrWhiteSpace(.Item(1).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS002")
                    loEx.Add("PS002", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS002"))
                    plCancel = True
                End If

                If String.IsNullOrWhiteSpace(.Item(2).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS003")
                    loEx.Add("PS003", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS003"))
                    plCancel = True
                End If

                'If String.IsNullOrWhiteSpace(.Item(3).Value) Then
                '    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS004")
                '    loEx.Add("PS004", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS004"))
                '    plCancel = True
                'End If

                If String.IsNullOrWhiteSpace(.Item(4).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS005")
                    loEx.Add("PS005", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS005"))
                    plCancel = True
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
#End Region


    Private Sub cboApplication_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboApplication.SelectedValueChanged
        If llInitialized Then
            RefreshGrids()
        End If
    End Sub

    Private Sub LAM00300_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

    Private Sub btnSaveToFile_Click(sender As System.Object, e As System.EventArgs) Handles btnSaveToFile.Click
        Dim loFile As System.IO.StreamWriter
        Dim lcFilename As String
        Dim lcFileContent As String
        Dim ldGenerateTime As DateTime

        ' save to file: appid+custid+enc+yyyyMMddhhmmss
        ldGenerateTime = Now
        lcFilename = cboApplication.SelectedValue.ToString.ToUpper.Trim + "_"
        lcFilename += _CCUSTOMER_CODE.ToUpper.Trim + "_"
        lcFilename += "ENC_"
        lcFilename += ldGenerateTime.ToString("yyyyMMddHHmmss")
        lcFilename += ".epwd"

        fbdSaveToFile.RootFolder = Environment.SpecialFolder.MyComputer
        fbdSaveToFile.Description = "Save file " & lcFilename.Trim & " to folder below..."
        If fbdSaveToFile.ShowDialog = Windows.Forms.DialogResult.OK Then
            loFile = My.Computer.FileSystem.OpenTextFileWriter(fbdSaveToFile.SelectedPath.Trim & _
                        IIf(fbdSaveToFile.SelectedPath.EndsWith("\"), "", "\") & lcFilename, True)

            lcFileContent = _CSQL_INSTANCE.Trim & "|"
            lcFileContent += _CSQL_USER.Trim & "|"
            lcFileContent += txtEncryptedPassword.Text.Trim

            loFile.WriteLine(lcFileContent)
            loFile.Close()

        End If
    End Sub
End Class
