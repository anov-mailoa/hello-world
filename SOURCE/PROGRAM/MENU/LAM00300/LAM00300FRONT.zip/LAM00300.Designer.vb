﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LAM00300
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewComboBoxColumn1 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn6 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn2 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Me.bsCust = New System.Windows.Forms.BindingSource(Me.components)
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cboApplication = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvSqlUser = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvSqlUser = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridSqlUser = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnSaveToFile = New R_FrontEnd.R_RadButton(Me.components)
        Me.txtEncryptedPassword = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblEncryptedPassword = New R_FrontEnd.R_RadLabel(Me.components)
        Me.fbdSaveToFile = New System.Windows.Forms.FolderBrowserDialog()
        CType(Me.bsCust, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvSqlUser, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvSqlUser.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvSqlUser, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridSqlUser, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.btnSaveToFile, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtEncryptedPassword, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblEncryptedPassword, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'bsCust
        '
        Me.bsCust.DataSource = GetType(LAM00300Front.LAM00300ServiceRef.RLicenseCustComboDTO)
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.gvSqlUser, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 0, 2)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.cboApplication)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 30)
        Me.Panel1.TabIndex = 0
        '
        'cboApplication
        '
        Me.cboApplication.DataSource = Me.bsApps
        Me.cboApplication.DisplayMember = "CAPPS_NAME"
        Me.cboApplication.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList
        Me.cboApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboApplication.Location = New System.Drawing.Point(115, 3)
        Me.cboApplication.Name = "cboApplication"
        Me.cboApplication.R_ConductorGridSource = Nothing
        Me.cboApplication.R_ConductorSource = Nothing
        Me.cboApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboApplication.Size = New System.Drawing.Size(400, 20)
        Me.cboApplication.TabIndex = 4
        Me.cboApplication.Text = "R_RadDropDownList1"
        Me.cboApplication.ValueMember = "CAPPS_CODE"
        '
        'bsApps
        '
        Me.bsApps.DataSource = GetType(LAM00300Front.LAM00300ServiceRef.RLicenseAppComboDTO)
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 3)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 3
        Me.lblApplication.Text = "Application..."
        '
        'gvSqlUser
        '
        Me.gvSqlUser.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvSqlUser.EnableFastScrolling = True
        Me.gvSqlUser.Location = New System.Drawing.Point(3, 39)
        '
        '
        '
        Me.gvSqlUser.MasterTemplate.AutoGenerateColumns = False
        Me.gvSqlUser.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewComboBoxColumn1.DataSource = Me.bsCust
        R_GridViewComboBoxColumn1.DisplayMember = "CCUSTOMER_NAME"
        R_GridViewComboBoxColumn1.FieldName = "_CCUSTOMER_CODE"
        R_GridViewComboBoxColumn1.HeaderText = "_CCUSTOMER_CODE"
        R_GridViewComboBoxColumn1.Name = "cboCustomer"
        R_GridViewComboBoxColumn1.R_EnableADD = True
        R_GridViewComboBoxColumn1.R_ResourceId = "_CCUSTOMER_CODE"
        R_GridViewComboBoxColumn1.ValueMember = "CCUSTOMER_CODE"
        R_GridViewComboBoxColumn1.Width = 124
        R_GridViewTextBoxColumn1.FieldName = "_CSQL_INSTANCE"
        R_GridViewTextBoxColumn1.HeaderText = "_CSQL_INSTANCE"
        R_GridViewTextBoxColumn1.Name = "_CSQL_INSTANCE"
        R_GridViewTextBoxColumn1.R_EnableADD = True
        R_GridViewTextBoxColumn1.R_ResourceId = "_CSQL_INSTANCE"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 105
        R_GridViewTextBoxColumn2.FieldName = "_CSQL_USER"
        R_GridViewTextBoxColumn2.HeaderText = "_CSQL_USER"
        R_GridViewTextBoxColumn2.Name = "_CSQL_USER"
        R_GridViewTextBoxColumn2.R_EnableADD = True
        R_GridViewTextBoxColumn2.R_ResourceId = "_CSQL_USER"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 83
        R_GridViewTextBoxColumn3.FieldName = "_CSQL_PASSWORD"
        R_GridViewTextBoxColumn3.HeaderText = "_CSQL_PASSWORD"
        R_GridViewTextBoxColumn3.Name = "_CSQL_PASSWORD"
        R_GridViewTextBoxColumn3.R_EnableADD = True
        R_GridViewTextBoxColumn3.R_EnableEDIT = True
        R_GridViewTextBoxColumn3.R_ResourceId = "_CSQL_PASSWORD"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 115
        R_GridViewTextBoxColumn4.FieldName = "_CNOTE"
        R_GridViewTextBoxColumn4.HeaderText = "_CNOTE"
        R_GridViewTextBoxColumn4.Name = "_CNOTE"
        R_GridViewTextBoxColumn4.R_EnableADD = True
        R_GridViewTextBoxColumn4.R_EnableEDIT = True
        R_GridViewTextBoxColumn4.R_ResourceId = "_CNOTE"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 83
        R_GridViewTextBoxColumn5.FieldName = "_CUPDATE_BY"
        R_GridViewTextBoxColumn5.HeaderText = "_CUPDATE_BY"
        R_GridViewTextBoxColumn5.Name = "_CUPDATE_BY"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CUPDATE_BY"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 110
        R_GridViewDateTimeColumn1.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn1.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn1.FieldName = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn1.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn1.HeaderText = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.Name = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.R_ResourceId = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.Width = 111
        R_GridViewTextBoxColumn6.FieldName = "_CCREATE_BY"
        R_GridViewTextBoxColumn6.HeaderText = "_CCREATE_BY"
        R_GridViewTextBoxColumn6.Name = "_CCREATE_BY"
        R_GridViewTextBoxColumn6.R_ResourceId = "_CCREATE_BY"
        R_GridViewTextBoxColumn6.R_UDT = Nothing
        R_GridViewTextBoxColumn6.Width = 110
        R_GridViewDateTimeColumn2.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn2.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn2.FieldName = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn2.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn2.HeaderText = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.Name = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.R_ResourceId = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.Width = 418
        Me.gvSqlUser.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewComboBoxColumn1, R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewTextBoxColumn4, R_GridViewTextBoxColumn5, R_GridViewDateTimeColumn1, R_GridViewTextBoxColumn6, R_GridViewDateTimeColumn2})
        Me.gvSqlUser.MasterTemplate.DataSource = Me.bsGvSqlUser
        Me.gvSqlUser.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvSqlUser.MasterTemplate.EnableFiltering = True
        Me.gvSqlUser.MasterTemplate.EnableGrouping = False
        Me.gvSqlUser.MasterTemplate.ShowFilteringRow = False
        Me.gvSqlUser.MasterTemplate.ShowGroupedColumns = True
        Me.gvSqlUser.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvSqlUser.Name = "gvSqlUser"
        Me.gvSqlUser.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvSqlUser.R_ConductorGridSource = Me.conGridSqlUser
        Me.gvSqlUser.R_ConductorSource = Nothing
        Me.gvSqlUser.R_DataAdded = False
        Me.gvSqlUser.R_NewRowText = Nothing
        Me.gvSqlUser.ShowHeaderCellButtons = True
        Me.gvSqlUser.Size = New System.Drawing.Size(1271, 497)
        Me.gvSqlUser.TabIndex = 1
        Me.gvSqlUser.Text = "R_RadGridView1"
        '
        'bsGvSqlUser
        '
        Me.bsGvSqlUser.DataSource = GetType(LAM00300Front.LAM00300ServiceRef.LAM00300DTO)
        '
        'conGridSqlUser
        '
        Me.conGridSqlUser.R_ConductorParent = Nothing
        Me.conGridSqlUser.R_IsHeader = True
        Me.conGridSqlUser.R_RadGroupBox = Nothing
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.btnSaveToFile)
        Me.Panel2.Controls.Add(Me.txtEncryptedPassword)
        Me.Panel2.Controls.Add(Me.lblEncryptedPassword)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 542)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1271, 30)
        Me.Panel2.TabIndex = 2
        '
        'btnSaveToFile
        '
        Me.btnSaveToFile.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnSaveToFile.Location = New System.Drawing.Point(636, 1)
        Me.btnSaveToFile.Name = "btnSaveToFile"
        Me.btnSaveToFile.R_ConductorGridSource = Nothing
        Me.btnSaveToFile.R_ConductorSource = Nothing
        Me.btnSaveToFile.R_DescriptionId = Nothing
        Me.btnSaveToFile.R_ResourceId = "btnSaveToFile"
        Me.btnSaveToFile.Size = New System.Drawing.Size(110, 24)
        Me.btnSaveToFile.TabIndex = 6
        Me.btnSaveToFile.Text = "R_RadButton1"
        '
        'txtEncryptedPassword
        '
        Me.txtEncryptedPassword.Location = New System.Drawing.Point(115, 3)
        Me.txtEncryptedPassword.Name = "txtEncryptedPassword"
        Me.txtEncryptedPassword.R_ConductorGridSource = Nothing
        Me.txtEncryptedPassword.R_ConductorSource = Nothing
        Me.txtEncryptedPassword.R_UDT = Nothing
        Me.txtEncryptedPassword.ReadOnly = True
        Me.txtEncryptedPassword.Size = New System.Drawing.Size(515, 20)
        Me.txtEncryptedPassword.TabIndex = 5
        Me.txtEncryptedPassword.TabStop = False
        '
        'lblEncryptedPassword
        '
        Me.lblEncryptedPassword.AutoSize = False
        Me.lblEncryptedPassword.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblEncryptedPassword.Location = New System.Drawing.Point(9, 4)
        Me.lblEncryptedPassword.Name = "lblEncryptedPassword"
        Me.lblEncryptedPassword.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblEncryptedPassword.R_ResourceId = "lblEncryptedPassword"
        Me.lblEncryptedPassword.Size = New System.Drawing.Size(100, 18)
        Me.lblEncryptedPassword.TabIndex = 4
        Me.lblEncryptedPassword.Text = "Application..."
        '
        'LAM00300
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "LAM00300"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.bsCust, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvSqlUser.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvSqlUser, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvSqlUser, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridSqlUser, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.btnSaveToFile, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtEncryptedPassword, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblEncryptedPassword, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents cboApplication As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents gvSqlUser As R_FrontEnd.R_RadGridView
    Friend WithEvents bsGvSqlUser As System.Windows.Forms.BindingSource
    Friend WithEvents conGridSqlUser As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource
    Friend WithEvents bsCust As System.Windows.Forms.BindingSource
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents txtEncryptedPassword As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblEncryptedPassword As R_FrontEnd.R_RadLabel
    Friend WithEvents fbdSaveToFile As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents btnSaveToFile As R_FrontEnd.R_RadButton

End Class
