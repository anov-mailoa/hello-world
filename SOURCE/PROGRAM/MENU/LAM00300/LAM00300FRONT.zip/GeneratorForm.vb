﻿Imports R_Common
Public Class GeneratorForm
    Private Const STR_SaltKey As String = "K3YR34LT43861772_K3YRND101601778"

   
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        txtResult.Text = ""
        txtResult.Text = R_Utility.Encrypt(txtData.Text.Trim, STR_SaltKey)
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        MsgBox(R_Utility.Decrypt(txtResult.Text.Trim, STR_SaltKey))
    End Sub

End Class