﻿Imports R_Common
Imports LAM00300Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "LAM00300StreamingService" in code, svc and config file together.
Public Class LAM00300StreamingService
    Implements ILAM00300StreamingService


    Public Sub Dummy(poPar As System.Collections.Generic.List(Of LAM00300Back.LAM00300GridDTO)) Implements ILAM00300StreamingService.Dummy

    End Sub

    Public Function GetCustAppSqlList() As System.ServiceModel.Channels.Message Implements ILAM00300StreamingService.GetCustAppSqlList
        Dim loException As New R_Exception
        Dim loCls As New LAM00300Cls
        Dim loRtnTemp As List(Of LAM00300GridDTO)
        Dim loRtn As Message
        Dim loTableKey As New LAM00300KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
            End With

            loRtnTemp = loCls.getCustAppSqlList(loTableKey)

            loRtn = R_StreamUtility(Of LAM00300GridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getCustAppSqlList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()
        Return loRtn
    End Function
End Class
