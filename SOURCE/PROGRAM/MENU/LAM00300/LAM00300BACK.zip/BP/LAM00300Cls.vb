﻿Imports R_Common
Imports R_BackEnd
Imports System.Data.Common
Imports ServerHelper.General
Imports System.Transactions

Public Class LAM00300Cls
    Inherits R_BusinessObject(Of LAM00300DTO)

    Protected Overrides Sub R_Deleting(poEntity As LAM00300DTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection

        Try
            loConn = loDb.GetConnection()

            Using TransScope As New TransactionScope(TransactionScopeOption.Required)
                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "LAM_APP_CUST_SQL "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                lcQuery += "AND CSQL_INSTANCE = '{3}' "
                lcQuery += "AND CSQL_USER = '{4}' "
                lcQuery = String.Format(lcQuery, poEntity.CCOMPANY_ID, _
                                    poEntity.CAPPS_CODE, _
                                    poEntity.CCUSTOMER_CODE, _
                                    poEntity.CSQL_INSTANCE, _
                                    poEntity.CSQL_USER)

                loDb.SqlExecNonQuery(lcQuery, loConn, True)

                TransScope.Complete()
            End Using

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As LAM00300DTO) As LAM00300DTO
        Dim lcQuery As String
        Dim loResult As LAM00300DTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "LAM_APP_CUST_SQL (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery += "AND CAPPS_CODE = '{1}' "
            lcQuery += "AND CCUSTOMER_CODE = '{2}' "
            lcQuery += "AND CSQL_INSTANCE = '{3}' "
            lcQuery += "AND CSQL_USER = '{4}' "
            lcQuery = String.Format(lcQuery, poEntity.CCOMPANY_ID, _
                                    poEntity.CAPPS_CODE, _
                                    poEntity.CCUSTOMER_CODE, _
                                    poEntity.CSQL_INSTANCE, _
                                    poEntity.CSQL_USER)

            loResult = loDb.SqlExecObjectQuery(Of LAM00300DTO)(lcQuery).FirstOrDefault
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As LAM00300DTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As LAM00300DTO

        Try
            loConn = loDb.GetConnection()

            If poCRUDMode = eCRUDMode.AddMode Then
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "LAM_APP_CUST_SQL (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                lcQuery += "AND CSQL_INSTANCE = '{3}' "
                lcQuery += "AND CSQL_USER = '{4}' "
                lcQuery = String.Format(lcQuery, poNewEntity.CCOMPANY_ID,
                                        poNewEntity.CAPPS_CODE, _
                                    poNewEntity.CCUSTOMER_CODE, _
                                    poNewEntity.CSQL_INSTANCE, _
                                    poNewEntity.CSQL_USER)

                loResult = loDb.SqlExecObjectQuery(Of LAM00300DTO)(lcQuery, loConn, True).FirstOrDefault
                If loResult IsNot Nothing Then
                    With poNewEntity
                        Throw New Exception("SQL credential for application " & .CAPPS_CODE.Trim & _
                                            ", customer " & .CCUSTOMER_CODE.Trim & _
                                            ", server/instance " & .CSQL_INSTANCE.Trim & _
                                            ", user " & .CSQL_USER.Trim & " is already exist")
                    End With
                End If

                With poNewEntity
                    .CCREATE_BY = .CUPDATE_BY
                    .DUPDATE_DATE = Now
                    .DCREATE_DATE = Now
                End With

                lcQuery = "INSERT INTO LAM_APP_CUST_SQL ("
                lcQuery += "CCOMPANY_ID, "
                lcQuery += "CAPPS_CODE, "
                lcQuery += "CCUSTOMER_CODE, "
                lcQuery += "CSQL_INSTANCE, "
                lcQuery += "CSQL_USER, "
                lcQuery += "CSQL_PASSWORD, "
                lcQuery += "CNOTE, "
                lcQuery += "CUPDATE_BY, "
                lcQuery += "DUPDATE_DATE, "
                lcQuery += "CCREATE_BY, "
                lcQuery += "DCREATE_DATE) "
                lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', {8}, '{9}', {10}) "
                lcQuery = String.Format(lcQuery,
                poNewEntity.CCOMPANY_ID,
                poNewEntity.CAPPS_CODE,
                poNewEntity.CCUSTOMER_CODE,
                poNewEntity.CSQL_INSTANCE,
                poNewEntity.CSQL_USER,
                poNewEntity.CSQL_PASSWORD,
                poNewEntity.CNOTE,
                poNewEntity.CUPDATE_BY,
                getDate(poNewEntity.DUPDATE_DATE),
                poNewEntity.CCREATE_BY,
                getDate(poNewEntity.DCREATE_DATE))

                loDb.SqlExecNonQuery(lcQuery)

            ElseIf poCRUDMode = eCRUDMode.EditMode Then

                lcQuery = "UPDATE LAM_APP_CUST_SQL "
                lcQuery += "SET "
                lcQuery += "CSQL_PASSWORD = '{5}', "
                lcQuery += "CNOTE = '{6}', "
                lcQuery += "CUPDATE_BY = '{7}', "
                lcQuery += "DUPDATE_DATE = {8} "
                lcQuery += "WHERE "
                lcQuery += "CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                lcQuery += "AND CSQL_INSTANCE = '{3}' "
                lcQuery += "AND CSQL_USER = '{4}' "
                lcQuery = String.Format(lcQuery,
                poNewEntity.CCOMPANY_ID,
                poNewEntity.CAPPS_CODE,
                poNewEntity.CCUSTOMER_CODE,
                poNewEntity.CSQL_INSTANCE,
                poNewEntity.CSQL_USER,
                poNewEntity.CSQL_PASSWORD,
                poNewEntity.CNOTE,
                poNewEntity.CUPDATE_BY,
                getDate(poNewEntity.DUPDATE_DATE))

                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End If

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Function getCustAppSqlList(poKey As LAM00300KeyDTO) As List(Of LAM00300GridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of LAM00300GridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "LAM_APP_CUST_SQL (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery += "AND CAPPS_CODE = '{1}' "
            lcQuery = String.Format(lcQuery, poKey.CCOMPANY_ID, poKey.CAPPS_CODE)

            loResult = loDb.SqlExecObjectQuery(Of LAM00300GridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function
End Class
