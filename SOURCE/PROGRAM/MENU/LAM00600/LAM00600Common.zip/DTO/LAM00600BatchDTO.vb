﻿<Serializable()> _
Public Class LAM00600BatchDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CFIELD_NAME As String
    Public Property CFIELD_GROUP As String
End Class
