﻿Imports R_Common
Imports R_BackEnd
Imports LAM00600Common
Imports System.Data.Common
Imports System.Transactions

Public Class LAM00600BatchCls
    Implements R_IBatchProcess

    Public Sub R_BatchProcess(poBatchProcessPar As R_Common.R_BatchProcessPar) Implements R_Common.R_IBatchProcess.R_BatchProcess
        Dim loEx As New R_Exception()
        Dim loObject As List(Of LAM00600BatchDTO)
        Dim loDb As New R_Db
        Dim lcQuery As String
        Dim loResult As LAM00600DTO
        Dim loConn As DbConnection
        Dim CUSER_ID As String
        Dim loMapping As New Dictionary(Of String, String)()
        Dim countLoop As Integer = 0
        Dim CCOMP_ID As String

        Try
            'get all program
            loObject = R_Utility.Deserialize(poBatchProcessPar.BigObject)
            CCOMP_ID = poBatchProcessPar.Key.COMPANY_ID
            CUSER_ID = poBatchProcessPar.Key.USER_ID

            Using TransScope As New TransactionScope(TransactionScopeOption.Required)
                loConn = loDb.GetConnection()

                For Each save As LAM00600BatchDTO In loObject
                    lcQuery = "exec RSP_WriteUploadProcessStatus '{0}', '{1}', '{2}', '{3}', '{4}'"
                    lcQuery = String.Format(lcQuery, CCOMP_ID, CUSER_ID, poBatchProcessPar.Key.KEY_GUID.Trim, countLoop, "Save " + save.CFIELD_NAME)
                    loDb.SqlExecNonQuery(lcQuery, loConn, False)

                    If loResult Is Nothing Then
                        'update into LAM_COMPANY_LICENSE_MODE
                        lcQuery = "UPDATE LAM_COMPANY_LICENSE_MODE "
                        lcQuery += "SET CFIELD_GROUP = '{3}' "
                        lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                        lcQuery += "AND CAPPS_CODE = '{1}' "
                        lcQuery += "AND CFIELD_NAME = '{2}' "
                        lcQuery = String.Format(lcQuery, CCOMP_ID, save.CAPPS_CODE, save.CFIELD_NAME, save.CFIELD_GROUP)
                        loDb.SqlExecNonQuery(lcQuery, loConn, False)
                    End If

                    countLoop += 1
                Next

                lcQuery = "exec RSP_WriteUploadProcessStatus '{0}', '{1}', '{2}', '{3}', '{4}', '{5}'"
                lcQuery = String.Format(lcQuery, CCOMP_ID, CUSER_ID, poBatchProcessPar.Key.KEY_GUID.Trim, countLoop, "Save Complete", 1)
                loDb.SqlExecNonQuery(lcQuery, loConn, True)

                TransScope.Complete()
            End Using

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

    End Sub
End Class
