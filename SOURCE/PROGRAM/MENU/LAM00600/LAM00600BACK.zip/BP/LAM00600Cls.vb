﻿Imports R_Common
Imports R_BackEnd
Imports System.Data.Common
Imports ServerHelper.General

Public Class LAM00600Cls
    Inherits R_BusinessObject(Of LAM00600DTO)

    Protected Overrides Sub R_Deleting(poEntity As LAM00600DTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loResult As LAM00600DTO

        Try
            loConn = loDb.GetConnection()

            With poEntity
                ' validasi
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "LAM_CUSTOMER_CONFIG_DETAIL (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CFIELD_NAME = '{2}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CFIELD_NAME)

                loResult = loDb.SqlExecObjectQuery(Of LAM00600DTO)(lcQuery, loConn, False).FirstOrDefault
                If loResult IsNot Nothing Then
                    Throw New Exception("Field " + .CFIELD_NAME.Trim + " has already been used in customer configuration.")
                End If

                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "LAM_APPS_CONFIG_FIELD "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CFIELD_NAME = '{2}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CFIELD_NAME)

                loDb.SqlExecNonQuery(lcQuery, loConn, True)


            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As LAM00600DTO) As LAM00600DTO
        Dim lcQuery As String
        Dim loResult As LAM00600DTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "LAM_APPS_CONFIG_FIELD (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CFIELD_NAME = '{2}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CFIELD_NAME)

                loResult = loDb.SqlExecObjectQuery(Of LAM00600DTO)(lcQuery).FirstOrDefault

            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As LAM00600DTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As LAM00600DTO

        Try
            loConn = loDb.GetConnection()

            With poNewEntity

                If poCRUDMode = eCRUDMode.AddMode Then
                lcQuery = "SELECT * "
                    lcQuery += "FROM "
                    lcQuery += "LAM_APPS_CONFIG_FIELD (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CFIELD_NAME = '{2}' "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CFIELD_NAME)

                    loResult = loDb.SqlExecObjectQuery(Of LAM00600DTO)(lcQuery, loConn, True).FirstOrDefault
                    If loResult IsNot Nothing Then
                        Throw New Exception("Field " + .CFIELD_NAME.Trim + " is already exist")
                    End If

                    ' Set CFIELD_GROUP
                    If .CFIELD_GROUP Is Nothing Then
                        If .LFIELD_GROUP Then
                            .CFIELD_GROUP = .CFIELD_NAME
                        Else
                            .CFIELD_GROUP = ""
                        End If
                    End If
                    ' Set Print Label

                    .CCREATE_BY = .CUPDATE_BY
                    .DUPDATE_DATE = Now
                    .DCREATE_DATE = Now
                    If .CPRINT_LABEL Is Nothing Then
                        .CPRINT_LABEL = .CFIELD_NAME
                    End If
                    lcQuery = "INSERT INTO LAM_APPS_CONFIG_FIELD ("
                    lcQuery += "CCOMPANY_ID, "
                    lcQuery += "CAPPS_CODE, "
                    lcQuery += "CFIELD_NAME, "
                    lcQuery += "CSEQUENCE, "
                    lcQuery += "LFIELD_GROUP, "
                    lcQuery += "CFIELD_GROUP, "
                    lcQuery += "CPRINT_LABEL, "
                    lcQuery += "CUPDATE_BY, "
                    lcQuery += "DUPDATE_DATE, "
                    lcQuery += "CCREATE_BY, "
                    lcQuery += "DCREATE_DATE) "
                    lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', {4}, '{5}', '{6}', '{7}', {8}, '{9}', {10}) "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CFIELD_NAME,
                    .CSEQUENCE,
                    IIf(.LFIELD_GROUP, 1, 0),
                    .CFIELD_GROUP,
                    .CPRINT_LABEL,
                    .CUPDATE_BY,
                    getDate(.DUPDATE_DATE),
                    .CCREATE_BY,
                    getDate(.DCREATE_DATE))

                    loDb.SqlExecNonQuery(lcQuery)

                ElseIf poCRUDMode = eCRUDMode.EditMode Then
                    If .CPRINT_LABEL Is Nothing Then
                        .CPRINT_LABEL = .CFIELD_NAME
                    Else
                        If .CPRINT_LABEL.Trim.Equals("") Then
                            .CPRINT_LABEL = .CFIELD_NAME
                        End If
                    End If

                    lcQuery = "UPDATE LAM_APPS_CONFIG_FIELD "
                    lcQuery += "SET "
                    lcQuery += "CSEQUENCE = '{3}', "
                    lcQuery += "LFIELD_GROUP = {4}, "
                    lcQuery += "CFIELD_GROUP = '{5}', "
                    lcQuery += "CPRINT_LABEL = '{6}', "
                    lcQuery += "CUPDATE_BY = '{7}', "
                    lcQuery += "DUPDATE_DATE = {8} "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CFIELD_NAME = '{2}' "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CFIELD_NAME,
                    .CSEQUENCE,
                    IIf(.LFIELD_GROUP, 1, 0),
                    .CFIELD_GROUP,
                    .CPRINT_LABEL,
                    .CUPDATE_BY,
                    getDate(poNewEntity.DUPDATE_DATE))
                    loDb.SqlExecNonQuery(lcQuery, loConn, True)
                End If

            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Function GetAppsConfigField(poTableKey As LAM00600KeyDTO) As List(Of LAM00600GridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of LAM00600GridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poTableKey

                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "LAM_APPS_CONFIG_FIELD (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                If .CAPPS_CODE IsNot Nothing Then
                    If Not .CAPPS_CODE.Trim.Equals("") Then
                        lcQuery += "AND CAPPS_CODE = '{1}' "
                    End If
                End If
                If .CFIELD_NAME IsNot Nothing Then
                    If Not .CFIELD_NAME.Trim.Equals("") Then
                        lcQuery += "AND CFIELD_NAME = '{2}' "
                    End If
                End If
                lcQuery += "ORDER BY CSEQUENCE "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CFIELD_NAME)
            End With

            loResult = loDb.SqlExecObjectQuery(Of LAM00600GridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Function GetAppsFieldCombo(poTableKey As LAM00600KeyDTO) As List(Of LAM00600GridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of LAM00600GridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poTableKey

                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "LAM_APPS_CONFIG_FIELD (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND LFIELD_GROUP = {2} "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, IIf(.LFIELD_GROUP, 1, 0))
            End With

            loResult = loDb.SqlExecObjectQuery(Of LAM00600GridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetAvailableFieldName(poTableKey As LAM00600KeyDTO) As List(Of FieldNameDTO)
        Dim loResult As List(Of FieldNameDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poTableKey
                lcQuery = "SELECT CFIELD_NAME "
                lcQuery += "FROM LAM_APPS_CONFIG_FIELD (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CFIELD_GROUP <> '{2}' "
                lcQuery += "ORDER BY CSEQUENCE "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CFIELD_GROUP)
            End With

            loResult = loDb.SqlExecObjectQuery(Of FieldNameDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

        Return loResult
    End Function

    Public Function GetSelectedFieldName(poTableKey As LAM00600KeyDTO) As List(Of FieldNameDTO)
        Dim loResult As List(Of FieldNameDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poTableKey
                lcQuery = "SELECT CFIELD_NAME "
                lcQuery += "FROM LAM_APPS_CONFIG_FIELD (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CFIELD_GROUP = '{2}' "
                lcQuery += "ORDER BY CSEQUENCE "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CFIELD_GROUP)
            End With

            loResult = loDb.SqlExecObjectQuery(Of FieldNameDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

        Return loResult
    End Function

End Class
