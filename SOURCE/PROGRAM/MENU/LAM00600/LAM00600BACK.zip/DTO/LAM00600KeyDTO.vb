﻿Public Class LAM00600KeyDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CFIELD_NAME As String
    Public Property LFIELD_GROUP As Boolean
    Public Property CFIELD_GROUP As String
End Class
