﻿Public Class FieldNameDTO
    Public Property CFIELD_NAME As String
End Class
