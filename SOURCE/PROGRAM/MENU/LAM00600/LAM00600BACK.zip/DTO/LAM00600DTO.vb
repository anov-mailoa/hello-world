﻿Imports R_BackEnd

<Serializable()> _
Public Class LAM00600DTO
    Inherits R_DTOBase

    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CFIELD_NAME As String
    Public Property CSEQUENCE As String
    Public Property LFIELD_GROUP As Boolean
    Public Property CFIELD_GROUP As String
    Public Property CPRINT_LABEL As String
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)
    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)
End Class
