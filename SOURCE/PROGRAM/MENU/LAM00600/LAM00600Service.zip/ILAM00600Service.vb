﻿Imports System.ServiceModel
Imports R_BackEnd
Imports R_Common
Imports LAM00600Back
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ILAM00600Service" in both code and config file together.
<ServiceContract()>
Public Interface ILAM00600Service
    Inherits R_IServicebase(Of LAM00600DTO)

    <OperationContract(Action:="getAppCombo", ReplyAction:="getAppCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAppCombo(companyId As String, userId As String) As List(Of RLicenseAppComboDTO)

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function Dummy1() As List(Of LAM00600KeyDTO)

End Interface
