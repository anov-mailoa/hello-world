﻿Imports R_Common
Imports LAM00600Front.LAM00600StreamingServiceRef
Imports R_FrontEnd
Imports System.ServiceModel.Channels
Imports LAM00600FrontResources

Public Class LAM00600FldGrp

#Region " VARIABLE "
    Dim C_ServiceNameStream As String = "LAM00600Service/LAM00600StreamingService.svc"
#End Region

    Private Sub LAM00600FldGrp_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Try
            gvFldGrp.R_RefreshGrid(poParameter)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub


    Private Sub gvFldGrp_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvFldGrp.R_ServiceGetListRecord
        Dim loServiceStream As LAM00600StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00600StreamingService, LAM00600StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of LAM00600GridDTO)
        Dim loListEntity As New List(Of LAM00600GridDTO)

        Try
            With poEntity
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("lFieldGroup", .LFIELD_GROUP)
            End With

            loRtn = loServiceStream.GetAppsFieldCombo()
            loStreaming = R_StreamUtility(Of LAM00600GridDTO).ReadFromMessage(loRtn)

            For Each loDto As LAM00600GridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub
End Class
