﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LAM00600FldGrp
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.gvFldGrp = New R_FrontEnd.R_RadGridView(Me.components)
        Me.R_ReturnLookUpAndFind1 = New R_FrontEnd.R_ReturnLookUpAndFind()
        Me.bsFldGrp = New System.Windows.Forms.BindingSource(Me.components)
        CType(Me.gvFldGrp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvFldGrp.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsFldGrp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'gvFldGrp
        '
        Me.gvFldGrp.Location = New System.Drawing.Point(12, 12)
        '
        '
        '
        Me.gvFldGrp.MasterTemplate.AutoGenerateColumns = False
        Me.gvFldGrp.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn1.FieldName = "CFIELD_NAME"
        R_GridViewTextBoxColumn1.HeaderText = "_CFIELD_NAME"
        R_GridViewTextBoxColumn1.Name = "_CFIELD_NAME"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CFIELD_NAME"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 400
        Me.gvFldGrp.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1})
        Me.gvFldGrp.MasterTemplate.DataSource = Me.bsFldGrp
        Me.gvFldGrp.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvFldGrp.MasterTemplate.EnableFiltering = True
        Me.gvFldGrp.MasterTemplate.EnableGrouping = False
        Me.gvFldGrp.MasterTemplate.ShowFilteringRow = False
        Me.gvFldGrp.MasterTemplate.ShowGroupedColumns = True
        Me.gvFldGrp.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvFldGrp.Name = "gvFldGrp"
        Me.gvFldGrp.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvFldGrp.R_ConductorGridSource = Nothing
        Me.gvFldGrp.R_ConductorSource = Nothing
        Me.gvFldGrp.R_DataAdded = False
        Me.gvFldGrp.R_NewRowText = Nothing
        Me.gvFldGrp.ShowHeaderCellButtons = True
        Me.gvFldGrp.Size = New System.Drawing.Size(420, 150)
        Me.gvFldGrp.TabIndex = 0
        Me.gvFldGrp.Text = "R_RadGridView1"
        '
        'R_ReturnLookUpAndFind1
        '
        Me.R_ReturnLookUpAndFind1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.R_ReturnLookUpAndFind1.Location = New System.Drawing.Point(270, 176)
        Me.R_ReturnLookUpAndFind1.Name = "R_ReturnLookUpAndFind1"
        Me.R_ReturnLookUpAndFind1.R_BindingSource = Me.bsFldGrp
        Me.R_ReturnLookUpAndFind1.Size = New System.Drawing.Size(162, 31)
        Me.R_ReturnLookUpAndFind1.TabIndex = 1
        '
        'bsFldGrp
        '
        Me.bsFldGrp.DataSource = GetType(LAM00600Front.LAM00600ServiceRef.LAM00600DTO)
        '
        'LAM00600FldGrp
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(444, 219)
        Me.Controls.Add(Me.R_ReturnLookUpAndFind1)
        Me.Controls.Add(Me.gvFldGrp)
        Me.Name = "LAM00600FldGrp"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.gvFldGrp.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvFldGrp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsFldGrp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents gvFldGrp As R_FrontEnd.R_RadGridView
    Friend WithEvents bsFldGrp As System.Windows.Forms.BindingSource
    Friend WithEvents R_ReturnLookUpAndFind1 As R_FrontEnd.R_ReturnLookUpAndFind

End Class
