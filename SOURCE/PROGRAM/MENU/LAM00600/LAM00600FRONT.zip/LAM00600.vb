﻿Imports LAM00600FrontResources
Imports R_Common
Imports LAM00600Front.LAM00600ServiceRef
Imports LAM00600Front.LAM00600StreamingServiceRef
Imports System.ServiceModel.Channels
Imports ClientHelper
Imports R_FrontEnd

Public Class LAM00600

#Region " VARIABLE "
    Dim C_ServiceName As String = "LAM00600Service/LAM00600Service.svc"
    Dim C_ServiceNameStream As String = "LAM00600Service/LAM00600StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim llInitialized As Boolean = False
#End Region


    Private Sub LAM00600_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loSvc As LAM00600ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00600Service, LAM00600ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loAppCombo As New List(Of RLicenseAppComboDTO)

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            ' Application
            cboApplication.Items.Clear()
            loAppCombo = loSvc.GetAppCombo(_CCOMPID, _CUSERID)
            bsApps.DataSource = loAppCombo

            llInitialized = True
            RefreshGrids()
            gvAppsConfig.Columns(0).Sort(Telerik.WinControls.UI.RadSortOrder.Ascending, False)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub RefreshGrids()
        Dim loEx As New R_Exception
        Dim loTableKey As New LAM00600KeyDTO
        Dim lcApplication As String

        Try

            lcApplication = ""
            If cboApplication.SelectedValue IsNot Nothing Then
                lcApplication = cboApplication.SelectedValue.Trim
                gvAppsConfig.Enabled = True
            Else
                gvAppsConfig.Enabled = False
                Exit Try
            End If
            With loTableKey
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = lcApplication
            End With

            gvAppsConfig.R_RefreshGrid(loTableKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvAppsConfig_R_Before_Open_LookUpForm(sender As Object, e As Telerik.WinControls.UI.EditorRequiredEventArgs, ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles gvAppsConfig.R_Before_Open_LookUpForm
        poTargetForm = New LAM00600FldGrp
        poParameter = New LAM00600KeyDTO With {.CCOMPANY_ID = _CCOMPID,
                                               .CAPPS_CODE = cboApplication.SelectedValue.Trim,
                                               .LFIELD_GROUP = True}

    End Sub

    Private Sub gvAppsConfig_R_Return_LookUp(sender As Object, e As Telerik.WinControls.UI.EditorRequiredEventArgs, poReturnObject As Object) Handles gvAppsConfig.R_Return_LookUp
        e.Editor.Value = poReturnObject.CFIELD_NAME
    End Sub

    Private Sub gvAppsConfig_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvAppsConfig.R_Saving
        With CType(poEntity, LAM00600DTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = cboApplication.SelectedValue.Trim
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With
    End Sub

    Private Sub gvAppsConfig_R_ServiceDelete(poEntity As Object) Handles gvAppsConfig.R_ServiceDelete
        Dim loService As LAM00600ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00600Service, LAM00600ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            With CType(poEntity, LAM00600DTO)
                ._CCOMPANY_ID = _CCOMPID
            End With

            loService.Svc_R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvAppsConfig_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvAppsConfig.R_ServiceGetListRecord
        Dim loServiceStream As LAM00600StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00600StreamingService, LAM00600StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of LAM00600GridDTO)
        Dim loListEntity As New List(Of LAM00600DTO)

        Try
            With poEntity
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
            End With

            loRtn = loServiceStream.GetAppsConfigField()
            loStreaming = R_StreamUtility(Of LAM00600GridDTO).ReadFromMessage(loRtn)

            For Each loDto As LAM00600GridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New LAM00600DTO With {._CAPPS_CODE = loDto.CAPPS_CODE,
                                                           ._CFIELD_NAME = loDto.CFIELD_NAME,
                                                           ._CSEQUENCE = loDto.CSEQUENCE,
                                                           ._LFIELD_GROUP = loDto.LFIELD_GROUP,
                                                           ._CFIELD_GROUP = loDto.CFIELD_GROUP,
                                                           ._CPRINT_LABEL = loDto.CPRINT_LABEL,
                                                           ._CCREATE_BY = loDto.CCREATE_BY,
                                                           ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                           ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                           ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub cboApplication_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboApplication.SelectedValueChanged
        If llInitialized Then
            RefreshGrids()
        End If
    End Sub

    Private Sub LAM00600_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

    Private Sub gvAppsConfig_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvAppsConfig.R_ServiceGetRecord
        Dim loService As LAM00600ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00600Service, LAM00600ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New LAM00600DTO With {._CCOMPANY_ID = _CCOMPID,
                                                                             ._CAPPS_CODE = cboApplication.SelectedValue.Trim,
                                                                             ._CFIELD_NAME = CType(bsGvAppsConfig.Current, LAM00600DTO)._CFIELD_NAME})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvAppsConfig_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvAppsConfig.R_ServiceSave
        Dim loService As LAM00600ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00600Service, LAM00600ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvAppsConfig_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvAppsConfig.R_Validation
        Dim loEx As New R_Exception()

        Try
            pcError = ""
            With poGridCellCollection
                ' Field Name
                If String.IsNullOrWhiteSpace(.Item(1).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS001")
                    loEx.Add("PS001", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS001"))
                    plCancel = True
                End If

                ' Sequence
                If String.IsNullOrWhiteSpace(.Item(0).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS002")
                    loEx.Add("PS002", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS002"))
                    plCancel = True
                End If

                ' Field Group, mandatory if Is Field Group = False
                If Not .Item(2).Value Then
                    If String.IsNullOrWhiteSpace(.Item(3).Value) Then
                        pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS003")
                        loEx.Add("PS003", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS003"))
                        plCancel = True
                    End If
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
End Class
