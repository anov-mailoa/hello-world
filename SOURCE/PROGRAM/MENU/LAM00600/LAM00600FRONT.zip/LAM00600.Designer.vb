﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LAM00600
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn1 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewLookUpColumn1 As R_FrontEnd.R_GridViewLookUpColumn = New R_FrontEnd.R_GridViewLookUpColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.gvAppsConfig = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvAppsConfig = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGvAppsConfig = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cboApplication = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        CType(Me.gvAppsConfig, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvAppsConfig.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvAppsConfig, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGvAppsConfig, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'gvAppsConfig
        '
        Me.gvAppsConfig.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvAppsConfig.EnableFastScrolling = True
        Me.gvAppsConfig.Location = New System.Drawing.Point(3, 43)
        '
        '
        '
        Me.gvAppsConfig.MasterTemplate.AllowColumnReorder = False
        Me.gvAppsConfig.MasterTemplate.AutoGenerateColumns = False
        Me.gvAppsConfig.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn1.FieldName = "_CSEQUENCE"
        R_GridViewTextBoxColumn1.HeaderText = "_CSEQUENCE"
        R_GridViewTextBoxColumn1.Name = "_CSEQUENCE"
        R_GridViewTextBoxColumn1.R_EnableADD = True
        R_GridViewTextBoxColumn1.R_EnableEDIT = True
        R_GridViewTextBoxColumn1.R_ResourceId = "_CSEQUENCE"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 47
        R_GridViewTextBoxColumn2.FieldName = "_CFIELD_NAME"
        R_GridViewTextBoxColumn2.HeaderText = "_CFIELD_NAME"
        R_GridViewTextBoxColumn2.Name = "_CFIELD_NAME"
        R_GridViewTextBoxColumn2.R_EnableADD = True
        R_GridViewTextBoxColumn2.R_ResourceId = "_CFIELD_NAME"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 1053
        R_GridViewCheckBoxColumn1.FieldName = "_LFIELD_GROUP"
        R_GridViewCheckBoxColumn1.HeaderText = "_LFIELD_GROUP"
        R_GridViewCheckBoxColumn1.Name = "_LFIELD_GROUP"
        R_GridViewCheckBoxColumn1.R_EnableADD = True
        R_GridViewCheckBoxColumn1.R_EnableEDIT = True
        R_GridViewCheckBoxColumn1.R_ResourceId = "_LFIELD_GROUP"
        R_GridViewCheckBoxColumn1.Width = 49
        R_GridViewLookUpColumn1.FieldName = "_CFIELD_GROUP"
        R_GridViewLookUpColumn1.HeaderText = "_CFIELD_GROUP"
        R_GridViewLookUpColumn1.Name = "_CFIELD_GROUP"
        R_GridViewLookUpColumn1.R_EnableADD = True
        R_GridViewLookUpColumn1.R_EnableEDIT = True
        R_GridViewLookUpColumn1.R_ResourceId = "_CFIELD_GROUP"
        R_GridViewLookUpColumn1.R_Title = Nothing
        R_GridViewLookUpColumn1.Width = 52
        R_GridViewTextBoxColumn3.FieldName = "_CPRINT_LABEL"
        R_GridViewTextBoxColumn3.HeaderText = "_CPRINT_LABEL"
        R_GridViewTextBoxColumn3.Name = "_CPRINT_LABEL"
        R_GridViewTextBoxColumn3.R_EnableADD = True
        R_GridViewTextBoxColumn3.R_EnableEDIT = True
        R_GridViewTextBoxColumn3.R_ResourceId = "_CPRINT_LABEL"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 54
        Me.gvAppsConfig.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewCheckBoxColumn1, R_GridViewLookUpColumn1, R_GridViewTextBoxColumn3})
        Me.gvAppsConfig.MasterTemplate.DataSource = Me.bsGvAppsConfig
        Me.gvAppsConfig.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvAppsConfig.MasterTemplate.EnableFiltering = True
        Me.gvAppsConfig.MasterTemplate.EnableGrouping = False
        Me.gvAppsConfig.MasterTemplate.ShowFilteringRow = False
        Me.gvAppsConfig.MasterTemplate.ShowGroupedColumns = True
        Me.gvAppsConfig.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvAppsConfig.Name = "gvAppsConfig"
        Me.gvAppsConfig.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvAppsConfig.R_ConductorGridSource = Me.conGvAppsConfig
        Me.gvAppsConfig.R_ConductorSource = Nothing
        Me.gvAppsConfig.R_DataAdded = False
        Me.gvAppsConfig.R_NewRowText = Nothing
        Me.gvAppsConfig.ShowHeaderCellButtons = True
        Me.gvAppsConfig.Size = New System.Drawing.Size(1271, 529)
        Me.gvAppsConfig.TabIndex = 0
        Me.gvAppsConfig.Text = "R_RadGridView1"
        '
        'bsGvAppsConfig
        '
        Me.bsGvAppsConfig.DataSource = GetType(LAM00600Front.LAM00600ServiceRef.LAM00600DTO)
        '
        'conGvAppsConfig
        '
        Me.conGvAppsConfig.R_ConductorParent = Nothing
        Me.conGvAppsConfig.R_IsHeader = True
        Me.conGvAppsConfig.R_RadGroupBox = Nothing
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.gvAppsConfig, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 1
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.cboApplication)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 34)
        Me.Panel1.TabIndex = 1
        '
        'cboApplication
        '
        Me.cboApplication.DataSource = Me.bsApps
        Me.cboApplication.DisplayMember = "CAPPS_NAME"
        Me.cboApplication.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList
        Me.cboApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboApplication.Location = New System.Drawing.Point(115, 9)
        Me.cboApplication.Name = "cboApplication"
        Me.cboApplication.R_ConductorGridSource = Nothing
        Me.cboApplication.R_ConductorSource = Nothing
        Me.cboApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboApplication.Size = New System.Drawing.Size(400, 20)
        Me.cboApplication.TabIndex = 8
        Me.cboApplication.Text = "R_RadDropDownList1"
        Me.cboApplication.ValueMember = "CAPPS_CODE"
        '
        'bsApps
        '
        Me.bsApps.DataSource = GetType(LAM00600Front.LAM00600ServiceRef.RLicenseAppComboDTO)
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 7
        Me.lblApplication.Text = "Application..."
        '
        'LAM00600
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "LAM00600"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.gvAppsConfig.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvAppsConfig, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvAppsConfig, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGvAppsConfig, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents gvAppsConfig As R_FrontEnd.R_RadGridView
    Friend WithEvents bsGvAppsConfig As System.Windows.Forms.BindingSource
    Friend WithEvents conGvAppsConfig As R_FrontEnd.R_ConductorGrid
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents cboApplication As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource

End Class
