﻿Public Class Resources_Dummy_Class

End Class
