﻿Imports R_Common
Imports LAT00300Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "LAT00300StreamingService" in code, svc and config file together.
Public Class LAT00300StreamingService
    Implements ILAT00300StreamingService

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of LAT00300Back.LAT00300NameGridDTO)) Implements ILAT00300StreamingService.Dummy

    End Sub

    Public Function GetNameChangeData() As System.ServiceModel.Channels.Message Implements ILAT00300StreamingService.GetNameChangeData
        Dim loException As New R_Exception
        Dim loCls As New LAT00300Cls
        Dim loRtnTemp As List(Of LAT00300NameGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New LAT00300KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CCUSTOMER_CODE = R_Utility.R_GetStreamingContext("cCustomerCode")
            End With

            loRtnTemp = loCls.GetNameChangeData(loTableKey)

            loRtn = R_StreamUtility(Of LAT00300NameGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getNameChangeData")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
