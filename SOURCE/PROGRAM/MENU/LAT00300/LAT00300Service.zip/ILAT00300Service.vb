﻿Imports System.ServiceModel
Imports R_Common
Imports RLicenseBack
Imports LAT00300Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ILAT00300Service" in both code and config file together.
<ServiceContract()>
Public Interface ILAT00300Service

    <OperationContract(Action:="getCustCombo", ReplyAction:="getCustCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetCustCombo(companyId As String) As List(Of RLicenseCustComboDTO)

    <OperationContract(Action:="changeCustomerName", ReplyAction:="changeCustomerName")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub ChangeCustomerName(ByVal poNewEntity As LAT00300NameDTO)

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function Dummy1() As List(Of LAT00300KeyDTO)

End Interface
