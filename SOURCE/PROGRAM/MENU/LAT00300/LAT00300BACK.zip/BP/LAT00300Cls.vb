﻿Imports R_BackEnd
Imports R_Common
Imports System.Data.Common
Imports ServerHelper.General

Public Class LAT00300Cls

    Public Sub ChangeCustomerName(poNewEntity As LAT00300NameDTO)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim lcQuery As String
        Dim loConn As DbConnection

        Try
            loConn = loDb.GetConnection()

            ' Set CREGISTRATION_ID
            poNewEntity.CREGISTRATION_ID = Now.ToString("yyyyMMdd-HHmmss")

            ' Save customer name changes data
            lcQuery = "INSERT INTO LAT_CUST_NAME ("
            lcQuery += "CCOMPANY_ID, "
            lcQuery += "CCUSTOMER_CODE, "
            lcQuery += "CREGISTRATION_ID, "
            lcQuery += "CCUSTOMER_NAME, "
            lcQuery += "CNOTE, "
            lcQuery += "CUPDATE_BY, "
            lcQuery += "DUPDATE_DATE, "
            lcQuery += "CCREATE_BY, "
            lcQuery += "DCREATE_DATE) "
            lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', {6}, '{7}', {8}) "
            lcQuery = String.Format(lcQuery,
            poNewEntity.CCOMPANY_ID,
            poNewEntity.CCUSTOMER_CODE,
            poNewEntity.CREGISTRATION_ID,
            poNewEntity.CCUSTOMER_NAME,
            poNewEntity.CNOTE,
            poNewEntity.CUPDATE_BY,
            getDate(poNewEntity.DUPDATE_DATE),
            poNewEntity.CCREATE_BY,
            getDate(poNewEntity.DCREATE_DATE))

            loDb.SqlExecNonQuery(lcQuery)

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Function GetNameChangeData(poTableKey As LAT00300KeyDTO) As List(Of LAT00300NameGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of LAT00300NameGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poTableKey

                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "LAT_CUST_NAME (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                If .CCUSTOMER_CODE IsNot Nothing Then
                    If Not .CCUSTOMER_CODE.Trim.Equals("") Then
                        lcQuery += "AND CCUSTOMER_CODE = '{1}' "
                    End If
                End If
                If .CREGISTRATION_ID IsNot Nothing Then
                    If Not .CREGISTRATION_ID.Trim.Equals("") Then
                        lcQuery += "AND CREGISTRATION_ID = '{2}' "
                    End If
                End If
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CCUSTOMER_CODE, .CREGISTRATION_ID)
            End With

            loResult = loDb.SqlExecObjectQuery(Of LAT00300NameGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function
End Class
