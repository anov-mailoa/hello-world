﻿Imports LAT00300FrontResources
Imports R_Common
Imports LAT00300Front.LAT00300ServiceRef
Imports LAT00300Front.LAT00300StreamingServiceRef
Imports System.ServiceModel.Channels
Imports ClientHelper
Imports R_FrontEnd

Public Class LAT00300

#Region " VARIABLE "
    Dim C_ServiceName As String = "LAT00300Service/LAT00300Service.svc"
    Dim C_ServiceNameStream As String = "LAT00300Service/LAT00300StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim llInitialized As Boolean = False

#End Region

    Private Sub LAT00300_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loSvc As LAT00300ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00300Service, LAT00300ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loCustCombo As New List(Of RLicenseCustComboDTO)

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            ' Customer
            loCustCombo = loSvc.GetCustCombo(_CCOMPID)
            bsCust.DataSource = loCustCombo

            llInitialized = True
            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvServer_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvName.R_ServiceGetListRecord
        Dim loServiceStream As LAT00300StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00300StreamingService, LAT00300StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of LAT00300NameGridDTO)
        Dim loListEntity As New List(Of LAT00300NameDTO)

        Try
            With poEntity
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cCustomerCode", .CCUSTOMER_CODE)
            End With

            loRtn = loServiceStream.GetNameChangeData()
            loStreaming = R_StreamUtility(Of LAT00300NameGridDTO).ReadFromMessage(loRtn)

            For Each loDto As LAT00300NameGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New LAT00300NameDTO With {._CCUSTOMER_CODE = loDto.CCUSTOMER_CODE,
                                                                 ._CREGISTRATION_ID = loDto.CREGISTRATION_ID,
                                                                 ._CCUSTOMER_NAME = loDto.CCUSTOMER_NAME,
                                                                 ._CNOTE = loDto.CNOTE,
                                                                 ._CCREATE_BY = loDto.CCREATE_BY,
                                                                 ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                                 ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                                 ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub RefreshGrids()
        Dim loTableKey As New LAT00300KeyDTO
        Dim loSvc As LAT00300ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00300Service, LAT00300ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)

        With loTableKey
            .CCOMPANY_ID = _CCOMPID
            .CCUSTOMER_CODE = cboCustomer.SelectedValue.Trim
        End With

        gvName.R_RefreshGrid(loTableKey)
    End Sub

    Private Sub RefreshCustomerCombo(pcCustomerName As String)
        Dim lnComboIndex As Integer = 0

        If cboCustomer.SelectedIndex >= 0 Then
            lnComboIndex = cboCustomer.SelectedIndex
            bsCust.DataSource(lnComboIndex).CCUSTOMER_NAME = pcCustomerName
            llInitialized = False
            cboCustomer.Rebind()
            llInitialized = True
            cboCustomer.SelectedIndex = lnComboIndex
        End If
    End Sub

    Private Sub cboCustomer_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboCustomer.SelectedValueChanged
        If llInitialized Then
            RefreshGrids()
        End If
    End Sub

    Private Sub btnRegisterServer_Click(sender As System.Object, e As System.EventArgs) Handles btnChangeName.Click
        Dim loEx As New R_Exception
        Dim loSvc As LAT00300ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00300Service, LAT00300ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loServer As LAT00300NameDTO
        Dim lcInstallationID_Decrypted As String = ""

        Try
            ' Validation
            ' Customer Name
            If txtCustomerName.Text.Trim.Equals("") Then
                loEx.Add("LAT00300_01", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "LAT00300_01"))
                Exit Try
            End If

            ' Save
            loServer = New LAT00300NameDTO
            With loServer
                ._CCOMPANY_ID = _CCOMPID
                ._CCUSTOMER_CODE = cboCustomer.SelectedValue.Trim
                ._CCUSTOMER_NAME = txtCustomerName.Text.Trim
                ._CNOTE = txtNote.Text.Trim
                ._CUPDATE_BY = _CUSERID
                ._DUPDATE_DATE = Now
                ._CCREATE_BY = _CUSERID
                ._DCREATE_DATE = Now
            End With
            loSvc.ChangeCustomerName(loServer)

            RefreshCustomerCombo(cboCustomer.SelectedValue.Trim & " | " & txtCustomerName.Text.Trim)
            RefreshGrids()

            ' clear input
            txtCustomerName.Text = ""
            txtNote.Text = ""
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loEx.Haserror Then
            R_DisplayException(loEx)
        End If
    End Sub
End Class
