﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LAT00300
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn2 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cboCustomer = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsCust = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblCustomer = New R_FrontEnd.R_RadLabel(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.lblNote = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtNote = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.btnChangeName = New R_FrontEnd.R_RadButton(Me.components)
        Me.txtCustomerName = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblCustomerName = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvName = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsName = New System.Windows.Forms.BindingSource(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.cboCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsCust, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.lblNote, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtNote, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnChangeName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCustomerName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCustomerName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvName.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.gvName, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.cboCustomer)
        Me.Panel1.Controls.Add(Me.lblCustomer)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 34)
        Me.Panel1.TabIndex = 0
        '
        'cboCustomer
        '
        Me.cboCustomer.DataSource = Me.bsCust
        Me.cboCustomer.DisplayMember = "CCUSTOMER_NAME"
        Me.cboCustomer.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList
        Me.cboCustomer.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboCustomer.Location = New System.Drawing.Point(115, 6)
        Me.cboCustomer.Name = "cboCustomer"
        Me.cboCustomer.R_ConductorGridSource = Nothing
        Me.cboCustomer.R_ConductorSource = Nothing
        Me.cboCustomer.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboCustomer.Size = New System.Drawing.Size(400, 20)
        Me.cboCustomer.TabIndex = 7
        Me.cboCustomer.Text = "R_RadDropDownList1"
        Me.cboCustomer.ValueMember = "CCUSTOMER_CODE"
        '
        'bsCust
        '
        Me.bsCust.DataSource = GetType(LAT00300Front.LAT00300ServiceRef.RLicenseCustComboDTO)
        '
        'lblCustomer
        '
        Me.lblCustomer.AutoSize = False
        Me.lblCustomer.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustomer.Location = New System.Drawing.Point(9, 6)
        Me.lblCustomer.Name = "lblCustomer"
        Me.lblCustomer.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustomer.R_ResourceId = "lblCustomer"
        Me.lblCustomer.Size = New System.Drawing.Size(100, 18)
        Me.lblCustomer.TabIndex = 5
        Me.lblCustomer.Text = "Customer..."
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.lblNote)
        Me.Panel2.Controls.Add(Me.txtNote)
        Me.Panel2.Controls.Add(Me.btnChangeName)
        Me.Panel2.Controls.Add(Me.txtCustomerName)
        Me.Panel2.Controls.Add(Me.lblCustomerName)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 478)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1271, 94)
        Me.Panel2.TabIndex = 1
        '
        'lblNote
        '
        Me.lblNote.AutoSize = False
        Me.lblNote.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblNote.Location = New System.Drawing.Point(9, 33)
        Me.lblNote.Name = "lblNote"
        Me.lblNote.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblNote.R_ResourceId = "lblNote"
        Me.lblNote.Size = New System.Drawing.Size(100, 18)
        Me.lblNote.TabIndex = 8
        Me.lblNote.Text = "R_RadLabel1"
        '
        'txtNote
        '
        Me.txtNote.AcceptsReturn = True
        Me.txtNote.AutoSize = False
        Me.txtNote.Location = New System.Drawing.Point(115, 32)
        Me.txtNote.Multiline = True
        Me.txtNote.Name = "txtNote"
        Me.txtNote.R_ConductorGridSource = Nothing
        Me.txtNote.R_ConductorSource = Nothing
        Me.txtNote.R_UDT = Nothing
        Me.txtNote.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtNote.Size = New System.Drawing.Size(609, 59)
        Me.txtNote.TabIndex = 7
        '
        'btnChangeName
        '
        Me.btnChangeName.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnChangeName.Location = New System.Drawing.Point(730, 4)
        Me.btnChangeName.Name = "btnChangeName"
        Me.btnChangeName.R_ConductorGridSource = Nothing
        Me.btnChangeName.R_ConductorSource = Nothing
        Me.btnChangeName.R_DescriptionId = Nothing
        Me.btnChangeName.R_ResourceId = "btnChangeName"
        Me.btnChangeName.Size = New System.Drawing.Size(110, 24)
        Me.btnChangeName.TabIndex = 6
        Me.btnChangeName.Text = "R_RadButton1"
        '
        'txtCustomerName
        '
        Me.txtCustomerName.Location = New System.Drawing.Point(115, 6)
        Me.txtCustomerName.Name = "txtCustomerName"
        Me.txtCustomerName.R_ConductorGridSource = Nothing
        Me.txtCustomerName.R_ConductorSource = Nothing
        Me.txtCustomerName.R_UDT = Nothing
        Me.txtCustomerName.Size = New System.Drawing.Size(609, 20)
        Me.txtCustomerName.TabIndex = 5
        '
        'lblCustomerName
        '
        Me.lblCustomerName.AutoSize = False
        Me.lblCustomerName.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustomerName.Location = New System.Drawing.Point(9, 7)
        Me.lblCustomerName.Name = "lblCustomerName"
        Me.lblCustomerName.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustomerName.R_ResourceId = "lblCustomerName"
        Me.lblCustomerName.Size = New System.Drawing.Size(100, 18)
        Me.lblCustomerName.TabIndex = 4
        Me.lblCustomerName.Text = "R_RadLabel1"
        '
        'gvName
        '
        Me.gvName.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gvName.EnableFastScrolling = True
        Me.gvName.Location = New System.Drawing.Point(3, 43)
        '
        '
        '
        Me.gvName.MasterTemplate.AllowAddNewRow = False
        Me.gvName.MasterTemplate.AutoGenerateColumns = False
        Me.gvName.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn1.FieldName = "_CREGISTRATION_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CREGISTRATION_ID"
        R_GridViewTextBoxColumn1.Name = "_CREGISTRATION_ID"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CREGISTRATION_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 55
        R_GridViewTextBoxColumn2.FieldName = "_CCUSTOMER_NAME"
        R_GridViewTextBoxColumn2.HeaderText = "_CCUSTOMER_NAME"
        R_GridViewTextBoxColumn2.Name = "_CCUSTOMER_NAME"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CCUSTOMER_NAME"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 955
        R_GridViewTextBoxColumn3.FieldName = "_CNOTE"
        R_GridViewTextBoxColumn3.HeaderText = "_CNOTE"
        R_GridViewTextBoxColumn3.Name = "_CNOTE"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CNOTE"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 44
        R_GridViewTextBoxColumn4.FieldName = "_CUPDATE_BY"
        R_GridViewTextBoxColumn4.HeaderText = "_CUPDATE_BY"
        R_GridViewTextBoxColumn4.Name = "_CUPDATE_BY"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CUPDATE_BY"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 47
        R_GridViewDateTimeColumn1.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn1.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn1.FieldName = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn1.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn1.HeaderText = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.Name = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.R_ResourceId = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.Width = 49
        R_GridViewTextBoxColumn5.FieldName = "_CCREATE_BY"
        R_GridViewTextBoxColumn5.HeaderText = "_CCREATE_BY"
        R_GridViewTextBoxColumn5.Name = "_CCREATE_BY"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CCREATE_BY"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 52
        R_GridViewDateTimeColumn2.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn2.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn2.FieldName = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn2.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn2.HeaderText = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.Name = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.R_ResourceId = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.Width = 55
        Me.gvName.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewTextBoxColumn4, R_GridViewDateTimeColumn1, R_GridViewTextBoxColumn5, R_GridViewDateTimeColumn2})
        Me.gvName.MasterTemplate.DataSource = Me.bsName
        Me.gvName.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvName.MasterTemplate.EnableFiltering = True
        Me.gvName.MasterTemplate.EnableGrouping = False
        Me.gvName.MasterTemplate.ShowFilteringRow = False
        Me.gvName.MasterTemplate.ShowGroupedColumns = True
        Me.gvName.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvName.Name = "gvName"
        Me.gvName.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvName.R_ConductorGridSource = Nothing
        Me.gvName.R_ConductorSource = Nothing
        Me.gvName.R_DataAdded = False
        Me.gvName.R_NewRowText = Nothing
        Me.gvName.ReadOnly = True
        Me.gvName.ShowHeaderCellButtons = True
        Me.gvName.Size = New System.Drawing.Size(1271, 429)
        Me.gvName.TabIndex = 2
        Me.gvName.Text = "R_RadGridView1"
        '
        'bsName
        '
        Me.bsName.DataSource = GetType(LAT00300Front.LAT00300ServiceRef.LAT00300NameDTO)
        '
        'LAT00300
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "LAT00300"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.cboCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsCust, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.lblNote, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtNote, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnChangeName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCustomerName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCustomerName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvName.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents cboCustomer As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblCustomer As R_FrontEnd.R_RadLabel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents txtCustomerName As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblCustomerName As R_FrontEnd.R_RadLabel
    Friend WithEvents gvName As R_FrontEnd.R_RadGridView
    Friend WithEvents bsCust As System.Windows.Forms.BindingSource
    Friend WithEvents bsName As System.Windows.Forms.BindingSource
    Friend WithEvents btnChangeName As R_FrontEnd.R_RadButton
    Friend WithEvents lblNote As R_FrontEnd.R_RadLabel
    Friend WithEvents txtNote As R_FrontEnd.R_RadTextBox

End Class
