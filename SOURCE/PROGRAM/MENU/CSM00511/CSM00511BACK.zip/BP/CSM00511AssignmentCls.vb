﻿Imports R_BackEnd
Imports R_Common
Imports System.Data.Common
Imports ServerHelper.General
Imports System.Transactions

Public Class CSM00511AssignmentCls
    Inherits R_BusinessObject(Of CSM00511ItemDTO)

    Public Function GetItemScheduleList(poKey As CSM00511ItemKeyDTO) As List(Of CSM00511ItemScheduleGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00511ItemScheduleGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "EXEC RSP_CSM00511_Grid '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '', '', '', '{7}', 'ASSIGNMENT_LIST' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID, .CSESSION_ID, .CSCHEDULE_ID, .CFUNCTION_ID, .CUSER_ID)

            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00511ItemScheduleGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Deleting(poEntity As CSM00511ItemDTO)
        ' Do nothing
    End Sub

    Protected Overrides Function R_Display(poEntity As CSM00511ItemDTO) As CSM00511ItemDTO
        Dim lcQuery As String
        Dim loResult As CSM00511ItemDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity

                lcQuery = "EXEC RSP_CSM00511_Grid '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', 'ASSIGNMENT_ROW' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID, .CSESSION_ID, .CSCHEDULE_ID, .CFUNCTION_ID, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CITEM_ID, .CUSER_ID)

                loResult = loDb.SqlExecObjectQuery(Of CSM00511ItemDTO)(lcQuery).FirstOrDefault

            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As CSM00511ItemDTO, poCRUDMode As R_Common.eCRUDMode)
        ' Edit only
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As List(Of CSM00511ItemDTO)
        Dim lnValidation As Integer

        Try
            loConn = loDb.GetConnection()

            With poNewEntity
                If poCRUDMode = eCRUDMode.EditMode Then

                    ' Validation for self reassignment
                    If .CREASSIGNMENT_ID = .CUPDATE_BY Then
                        lcQuery = "SELECT COUNT(1) AS IASSIGNMENT "
                        lcQuery += "FROM CST_PROJECT_ASSIGNMENT A (NOLOCK) "
                        lcQuery += "JOIN CSM_PROJECT_USERS B (NOLOCK) "
                        lcQuery += "ON B.CCOMPANY_ID = A.CCOMPANY_ID "
                        lcQuery += "AND B.CAPPS_CODE = A.CAPPS_CODE "
                        lcQuery += "AND B.CVERSION = A.CVERSION "
                        lcQuery += "AND B.CPROJECT_ID = A.CPROJECT_ID "
                        lcQuery += "AND B.CSESSION_ID = A.CSESSION_ID "
                        lcQuery += "AND B.CUSER_ID = A.CREASSIGNMENT_ID "
                        lcQuery += "AND B.CFUNCTION_ID = A.CFUNCTION_ID "
                        lcQuery += "WHERE A.CCOMPANY_ID = '{0}' "
                        lcQuery += "AND A.CAPPS_CODE = '{1}' "
                        lcQuery += "AND A.CVERSION = '{2}' "
                        lcQuery += "AND A.CPROJECT_ID = '{3}' "
                        lcQuery += "AND A.CSESSION_ID = '{4}' "
                        lcQuery += "AND A.CREASSIGNMENT_ID = '{5}' "
                        lcQuery += "AND NOT (A.CSCHEDULE_ID = '{6}' "
                        lcQuery += "	AND A.CFUNCTION_ID = '{7}' "
                        lcQuery += "	AND A.CATTRIBUTE_GROUP = '{8}' "
                        lcQuery += "	AND A.CATTRIBUTE_ID = '{9}' "
                        lcQuery += "	AND A.CITEM_ID = '{10}') "
                        lcQuery += "AND A.CSTATUS NOT IN ('QCCI','QCCCO','DONE') "
                        lcQuery += "AND B.LMANAGER = 0 "
                        lcQuery = String.Format(lcQuery, _
                                                .CCOMPANY_ID, _
                                                .CAPPS_CODE, _
                                                .CVERSION, _
                                                .CPROJECT_ID, _
                                                .CSESSION_ID, _
                                                .CREASSIGNMENT_ID, _
                                                .CSCHEDULE_ID, _
                                                .CFUNCTION_ID, _
                                                .CATTRIBUTE_GROUP, _
                                                .CATTRIBUTE_ID, _
                                                .CITEM_ID)

                        lnValidation = loDb.SqlExecObjectQuery(Of Integer)(lcQuery, loConn, False).FirstOrDefault
                        If lnValidation > 0 Then
                            loEx.Add("AsgnValid001", "Self assignment is not allowed for user with active assignment.")
                            Exit Try
                        End If
                    End If


                    lcQuery = "UPDATE CST_PROJECT_ASSIGNMENT "
                    lcQuery += "SET "
                    lcQuery += "CLOCATION_ID = '{10}', "
                    lcQuery += "CPLAN_START_DATE = '{11}', "
                    lcQuery += "CPLAN_END_DATE = '{12}', "
                    lcQuery += "NMANDAYS = {13}, "
                    lcQuery += "CREVISED_START_DATE = '{14}', "
                    lcQuery += "CREVISED_END_DATE = '{15}', "
                    lcQuery += "NREVISED_MANDAYS = {16}, "
                    lcQuery += "CUSER_ID = '{17}', "
                    lcQuery += "CREASSIGNMENT_ID = '{18}', "
                    lcQuery += "CGANTT_SEQUENCE = '{19}', "
                    lcQuery += "CUPDATE_BY = '{20}', "
                    lcQuery += "DUPDATE_DATE = GETDATE() "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CVERSION = '{2}' "
                    lcQuery += "AND CPROJECT_ID = '{3}' "
                    lcQuery += "AND CSESSION_ID = '{4}' "
                    lcQuery += "AND CSCHEDULE_ID = '{5}' "
                    lcQuery += "AND CFUNCTION_ID = '{6}' "
                    lcQuery += "AND CATTRIBUTE_GROUP = '{7}' "
                    lcQuery += "AND CATTRIBUTE_ID = '{8}' "
                    lcQuery += "AND CITEM_ID = '{9}' "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CVERSION,
                    .CPROJECT_ID,
                    .CSESSION_ID,
                    .CSCHEDULE_ID,
                    .CFUNCTION_ID,
                    .CATTRIBUTE_GROUP,
                    .CATTRIBUTE_ID,
                    .CITEM_ID,
                    .CLOCATION_ID,
                    .CPLAN_START_DATE,
                    .CPLAN_END_DATE,
                    .NMANDAYS,
                    .CREVISED_START_DATE,
                    .CREVISED_END_DATE,
                    .NREVISED_MANDAYS,
                    .CUSER_ID,
                    .CREASSIGNMENT_ID,
                    .CGANTT_SEQUENCE,
                    .CUPDATE_BY)
                End If
                loDb.SqlExecNonQuery(lcQuery, loConn, True)

            End With
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Sub EstimateSchedule(poKey As CSM00511ItemKeyDTO)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loCmd As DbCommand
        Dim loPar As DbParameter

        Try
            Using TransScope As New TransactionScope(TransactionScopeOption.Required)
                loCmd = loDb.GetCommand()
                lcQuery = "EXEC RSP_Estimate_Gantt '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', @CERR_NO OUTPUT, @CERR_MSG OUTPUT "
                With poKey
                    lcQuery = String.Format(lcQuery, _
                                            .CCOMPANY_ID, _
                                            .CAPPS_CODE, _
                                            .CVERSION, _
                                            .CPROJECT_ID, _
                                            .CSESSION_ID, _
                                            .CSCHEDULE_ID, _
                                            .CFUNCTION_ID, _
                                            .CUSER_ID)
                End With
                loCmd.CommandText = lcQuery
                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@CERR_NO"
                    .DbType = DbType.String
                    .Size = 50
                    .Direction = ParameterDirection.Output
                End With
                loCmd.Parameters.Add(loPar)
                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@CERR_MSG"
                    .DbType = DbType.String
                    .Size = 100
                    .Direction = ParameterDirection.Output
                End With
                loCmd.Parameters.Add(loPar)
                loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)

                If loCmd.Parameters("@CERR_MSG") Is Nothing Then
                    loEx.Add("999", "UNKNOWN_ERROR")
                    Exit Try
                Else
                    If Not loCmd.Parameters("@CERR_MSG").Value.Equals("OK") Then
                        loEx.Add(loCmd.Parameters("@CERR_NO").Value, loCmd.Parameters("@CERR_MSG").Value)
                        Exit Try
                    End If
                End If
                TransScope.Complete()
            End Using

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try
        loEx.ThrowExceptionIfErrors()

    End Sub

End Class
