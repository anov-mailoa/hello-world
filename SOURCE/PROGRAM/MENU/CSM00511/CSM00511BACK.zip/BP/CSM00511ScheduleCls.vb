﻿Imports R_BackEnd
Imports R_Common
Imports System.Data.Common
Imports System.Transactions

Public Class CSM00511ScheduleCls
    Inherits R_BusinessObject(Of CSM00511ScheduleDTO)

    Public Function GetScheduleList(poKey As CSM00511KeyDTO) As List(Of CSM00511ScheduleGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00511ScheduleGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "EXEC RSP_CSM00511_Grid '{0}', '{1}', '{2}', '{3}', '{4}', '', '', '', '', '', '', 'SCHEDULE_LIST' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID, .CSESSION_ID)

            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00511ScheduleGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    'Public Sub StartSchedule(poKey As CSM00511KeyDTO)
    '    Dim loEx As New R_Exception()
    '    Dim loDb As New R_Db()
    '    Dim loConn As DbConnection
    '    Dim lcQuery As String
    '    Dim loCmd As DbCommand
    '    Dim loPar As DbParameter

    '    Try
    '        Using TransScope As New TransactionScope(TransactionScopeOption.Required)
    '            loCmd = loDb.GetCommand()
    '            lcQuery = "EXEC RSP_Start_Schedule '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', @CERR_NO OUTPUT, @CERR_MSG OUTPUT "
    '            With poKey
    '                lcQuery = String.Format(lcQuery, _
    '                                        .CCOMPANY_ID, _
    '                                        .CAPPS_CODE, _
    '                                        .CVERSION, _
    '                                        .CPROJECT_ID, _
    '                                        .CSESSION_ID, _
    '                                        .CSCHEDULE_ID, _
    '                                        .CUSER_ID)
    '            End With
    '            loCmd.CommandText = lcQuery
    '            loPar = loDb.GetParameter()
    '            With loPar
    '                .ParameterName = "@CERR_NO"
    '                .DbType = DbType.String
    '                .Size = 50
    '                .Direction = ParameterDirection.Output
    '            End With
    '            loCmd.Parameters.Add(loPar)
    '            loPar = loDb.GetParameter()
    '            With loPar
    '                .ParameterName = "@CERR_MSG"
    '                .DbType = DbType.String
    '                .Size = 100
    '                .Direction = ParameterDirection.Output
    '            End With
    '            loCmd.Parameters.Add(loPar)
    '            loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)

    '            If loCmd.Parameters("@CERR_MSG") Is Nothing Then
    '                loEx.Add("999", "UNKNOWN_ERROR")
    '                Exit Try
    '            Else
    '                If Not loCmd.Parameters("@CERR_MSG").Value.Equals("OK") Then
    '                    loEx.Add(loCmd.Parameters("@CERR_NO").Value, loCmd.Parameters("@CERR_MSG").Value)
    '                    Exit Try
    '                End If
    '            End If
    '            TransScope.Complete()
    '        End Using

    '    Catch ex As Exception
    '        loEx.Add(ex)
    '    Finally
    '        If loConn IsNot Nothing Then
    '            If Not (loConn.State = ConnectionState.Closed) Then
    '                loConn.Close()
    '            End If
    '            loConn.Dispose()
    '            loConn = Nothing
    '        End If
    '    End Try
    '    loEx.ThrowExceptionIfErrors()

    'End Sub

    'Public Sub CloseSchedule(poKey As CSM00511KeyDTO)
    '    Dim loEx As New R_Exception()
    '    Dim loDb As New R_Db()
    '    Dim loConn As DbConnection
    '    Dim lcQuery As String
    '    Dim loCmd As DbCommand
    '    Dim loPar As DbParameter

    '    Try
    '        Using TransScope As New TransactionScope(TransactionScopeOption.Required)
    '            loCmd = loDb.GetCommand()
    '            lcQuery = "EXEC RSP_Close_Schedule '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', @CERR_NO OUTPUT, @CERR_MSG OUTPUT "
    '            With poKey
    '                lcQuery = String.Format(lcQuery, _
    '                                        .CCOMPANY_ID, _
    '                                        .CAPPS_CODE, _
    '                                        .CVERSION, _
    '                                        .CPROJECT_ID, _
    '                                        .CSESSION_ID, _
    '                                        .CSCHEDULE_ID, _
    '                                        .CUSER_ID)
    '            End With
    '            loCmd.CommandText = lcQuery
    '            loPar = loDb.GetParameter()
    '            With loPar
    '                .ParameterName = "@CERR_NO"
    '                .DbType = DbType.String
    '                .Size = 50
    '                .Direction = ParameterDirection.Output
    '            End With
    '            loCmd.Parameters.Add(loPar)
    '            loPar = loDb.GetParameter()
    '            With loPar
    '                .ParameterName = "@CERR_MSG"
    '                .DbType = DbType.String
    '                .Size = 100
    '                .Direction = ParameterDirection.Output
    '            End With
    '            loCmd.Parameters.Add(loPar)
    '            loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)

    '            If loCmd.Parameters("@CERR_MSG") Is Nothing Then
    '                loEx.Add("999", "UNKNOWN_ERROR")
    '                Exit Try
    '            Else
    '                If Not loCmd.Parameters("@CERR_MSG").Value.Equals("OK") Then
    '                    loEx.Add(loCmd.Parameters("@CERR_NO").Value, loCmd.Parameters("@CERR_MSG").Value)
    '                    Exit Try
    '                End If
    '            End If
    '            TransScope.Complete()
    '        End Using

    '    Catch ex As Exception
    '        loEx.Add(ex)
    '    Finally
    '        If loConn IsNot Nothing Then
    '            If Not (loConn.State = ConnectionState.Closed) Then
    '                loConn.Close()
    '            End If
    '            loConn.Dispose()
    '            loConn = Nothing
    '        End If
    '    End Try
    '    loEx.ThrowExceptionIfErrors()

    'End Sub

    Protected Overrides Sub R_Deleting(poEntity As CSM00511ScheduleDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcRtn As String

        Try
            loConn = loDb.GetConnection()

            With poEntity

                'validation
                loCmd = loDb.GetCommand()
                lcQuery = "EXEC RSP_Delete_Schedule_Validation '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', @CRET_MSG OUTPUT "
                With poEntity
                    lcQuery = String.Format(lcQuery, _
                                .CCOMPANY_ID, _
                                .CAPPS_CODE, _
                                .CVERSION, _
                                .CPROJECT_ID, _
                                .CSESSION_ID, _
                                .CSCHEDULE_ID)
                End With
                loCmd.CommandText = lcQuery
                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@CRET_MSG"
                    .DbType = DbType.String
                    .Size = 50
                    .Direction = ParameterDirection.Output
                End With
                loCmd.Parameters.Add(loPar)
                loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)

                If loCmd.Parameters("@CRET_MSG") Is Nothing Then
                    lcRtn = "UNKNOWN_ERROR"
                Else
                    lcRtn = loCmd.Parameters("@CRET_MSG").Value
                End If

                If Not lcRtn.Equals("OK") Then
                    Throw New Exception(lcRtn)
                End If

                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "CST_PROJECT_SCHEDULE "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery += "AND CPROJECT_ID = '{3}' "
                lcQuery += "AND CSESSION_ID = '{4}' "
                lcQuery += "AND CSCHEDULE_ID = '{5}' "
                lcQuery = String.Format(lcQuery, _
                            .CCOMPANY_ID, _
                            .CAPPS_CODE, _
                            .CVERSION, _
                            .CPROJECT_ID, _
                            .CSESSION_ID, _
                            .CSCHEDULE_ID)
                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As CSM00511ScheduleDTO) As CSM00511ScheduleDTO
        Dim lcQuery As String
        Dim loResult As CSM00511ScheduleDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity

                lcQuery = "EXEC RSP_CSM00511_Grid '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '', '', '', '', 'SCHEDULE_ROW' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID, .CSESSION_ID, .CSCHEDULE_ID)

                loResult = loDb.SqlExecObjectQuery(Of CSM00511ScheduleDTO)(lcQuery).FirstOrDefault

            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As CSM00511ScheduleDTO, poCRUDMode As R_Common.eCRUDMode)
        ' Edit only
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String

        Try
            loConn = loDb.GetConnection()

            With poNewEntity
                If poCRUDMode = eCRUDMode.EditMode Then

                    lcQuery = "UPDATE CST_PROJECT_SCHEDULE "
                    lcQuery += "SET "
                    lcQuery += "CNOTE = '{6}', "
                    lcQuery += "CUPDATE_BY = '{7}', "
                    lcQuery += "DUPDATE_DATE = GETDATE() "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CVERSION = '{2}' "
                    lcQuery += "AND CPROJECT_ID = '{3}' "
                    lcQuery += "AND CSESSION_ID = '{4}' "
                    lcQuery += "AND CSCHEDULE_ID = '{5}' "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CVERSION,
                    .CPROJECT_ID,
                    .CSESSION_ID,
                    .CSCHEDULE_ID,
                    .CNOTE,
                    .CUPDATE_BY)
                End If
                loDb.SqlExecNonQuery(lcQuery, loConn, True)

            End With
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

End Class
