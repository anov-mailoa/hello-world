﻿Imports R_BackEnd

<Serializable()> _
Public Class CSM00511ItemDTO
    Inherits R_DTOBase

    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CVERSION As String
    Public Property CPROJECT_ID As String
    Public Property CSESSION_ID As String
    Public Property CSCHEDULE_ID As String
    Public Property CFUNCTION_ID As String
    Public Property CATTRIBUTE_GROUP As String
    Public Property CATTRIBUTE_ID As String
    Public Property CITEM_ID As String
    Public Property CUSER_ID As String
    Public Property CREASSIGNMENT_ID As String
    Public Property CLOCATION_ID As String
    Public Property NMANDAYS As Decimal
    Public Property CPLAN_START_DATE As String
    Public Property CPLAN_END_DATE As String
    Public Property DPLAN_START_DATE As Nullable(Of DateTime)
    Public Property DPLAN_END_DATE As Nullable(Of DateTime)
    Public Property NREVISED_MANDAYS As Decimal
    Public Property CREVISED_START_DATE As String
    Public Property CREVISED_END_DATE As String
    Public Property DREVISED_START_DATE As Nullable(Of DateTime)
    Public Property DREVISED_END_DATE As Nullable(Of DateTime)
    Public Property CACTUAL_START_DATE As String
    Public Property CACTUAL_END_DATE As String
    Public Property CSTATUS As String
    Public Property CSEQUENCE As String
    Public Property CLAST_ACTION As String
    Public Property CLAST_ACTION_BY As String
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)
    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)

    Public Property CITEM_NAME As String

    Public Property NDESIGN_MANDAYS As Decimal
    Public Property DDESIGN_PLAN_START As Nullable(Of DateTime)
    Public Property DDESIGN_PLAN_END As Nullable(Of DateTime)
    Public Property NREVISED_DESIGN_MANDAYS As Decimal
    Public Property DDESIGN_REVISED_START As Nullable(Of DateTime)
    Public Property DDESIGN_REVISED_END As Nullable(Of DateTime)

    Public Property NDEVELOPMENT_MANDAYS As Decimal
    Public Property DDEVELOPMENT_PLAN_START As Nullable(Of DateTime)
    Public Property DDEVELOPMENT_PLAN_END As Nullable(Of DateTime)
    Public Property NREVISED_DEVELOPMENT_MANDAYS As Decimal
    Public Property DDEVELOPMENT_REVISED_START As Nullable(Of DateTime)
    Public Property DDEVELOPMENT_REVISED_END As Nullable(Of DateTime)

    ' Helper
    Public Property LREVISION As Boolean
    Public Property LACTUAL_START As Boolean
    Public Property LACTUAL_END As Boolean

    Public Property CUSER_NAME As String
    Public Property CREASSIGNMENT_NAME As String
    Public Property LMANAGER As Boolean

    ' Gantt Estimation
    Public Property CGANTT_SEQUENCE As String

End Class
