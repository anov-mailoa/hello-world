﻿Imports System.ServiceModel
Imports R_Common
Imports R_BackEnd
Imports CSM00500Back
Imports CSM00511BACK
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00511AssignmentService" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00511AssignmentService
    Inherits R_IServicebase(Of CSM00511ItemDTO)

    <OperationContract(Action:="getFunctionCombo", ReplyAction:="getFunctionCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetFunctionCombo(key As RCustDBProjectKeyDTO) As List(Of RCustDBFunctionComboDTO)

    <OperationContract(Action:="getLocationCombo", ReplyAction:="getLocationCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetLocationCombo() As List(Of RCustDBLocationComboDTO)

    <OperationContract(Action:="estimateSchedule", ReplyAction:="estimateSchedule")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub EstimateSchedule(poKey As CSM00500ItemKeyDTO)

    <OperationContract()> _
        <FaultContract(GetType(R_ServiceExceptions))> _
    Function Dummy1() As List(Of CSM00500ItemKeyDTO)

End Interface
