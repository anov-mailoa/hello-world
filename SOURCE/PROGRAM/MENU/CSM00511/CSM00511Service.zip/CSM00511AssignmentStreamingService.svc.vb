﻿Imports R_Common
Imports CSM00511BACK
Imports System.ServiceModel.Channels
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00511AssignmentStreamingService" in code, svc and config file together.
Public Class CSM00511AssignmentStreamingService
    Implements ICSM00511AssignmentStreamingService

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of CSM00511BACK.CSM00511ItemScheduleGridDTO), poPar3 As RLicenseBack.RCustDBIssueListDTO, poPar4 As RLicenseBack.RCustDBIssueKeyDTO) Implements ICSM00511AssignmentStreamingService.Dummy

    End Sub

    Public Function GetIssueList() As System.ServiceModel.Channels.Message Implements ICSM00511AssignmentStreamingService.GetIssueList
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtnTemp As List(Of RCustDBIssueListDTO)
        Dim loRtn As Message
        Dim loTableKey As New RCustDBIssueKeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .CPROJECT_ID = R_Utility.R_GetStreamingContext("cProjectId")
                .CSESSION_ID = R_Utility.R_GetStreamingContext("cSessionId")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CATTRIBUTE_ID = R_Utility.R_GetStreamingContext("cAttributeId")
                .CITEM_ID = R_Utility.R_GetStreamingContext("cItemId")
                .CSCHEDULE_ID = R_Utility.R_GetStreamingContext("cScheduleId")
                .CPREV_SCHEDULE_ID = R_Utility.R_GetStreamingContext("cPrevScheduleId")
                .LOUTSTANDING_ONLY = False
            End With

            loRtnTemp = loCls.GetIssueList(loTableKey)

            loRtn = R_StreamUtility(Of RCustDBIssueListDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getIssueList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetItemScheduleList() As System.ServiceModel.Channels.Message Implements ICSM00511AssignmentStreamingService.GetItemScheduleList
        Dim loException As New R_Exception
        Dim loCls As New CSM00511AssignmentCls
        Dim loRtnTemp As List(Of CSM00511ItemScheduleGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00511ItemKeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .CPROJECT_ID = R_Utility.R_GetStreamingContext("cProjectId")
                .CSESSION_ID = R_Utility.R_GetStreamingContext("cSessionId")
                .CSCHEDULE_ID = R_Utility.R_GetStreamingContext("cScheduleId")
                .CFUNCTION_ID = R_Utility.R_GetStreamingContext("cFunctionId")
                .CUSER_ID = R_Utility.R_GetStreamingContext("cUserId")
            End With

            loRtnTemp = loCls.GetItemScheduleList(loTableKey)

            loRtn = R_StreamUtility(Of CSM00511ItemScheduleGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getItemScheduleList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
