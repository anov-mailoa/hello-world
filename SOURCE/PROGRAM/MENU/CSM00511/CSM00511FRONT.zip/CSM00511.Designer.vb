﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSM00511
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn6 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewLookUpColumn1 As R_FrontEnd.R_GridViewLookUpColumn = New R_FrontEnd.R_GridViewLookUpColumn()
        Dim R_GridViewLookUpColumn2 As R_FrontEnd.R_GridViewLookUpColumn = New R_FrontEnd.R_GridViewLookUpColumn()
        Dim R_GridViewTextBoxColumn7 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn1 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewComboBoxColumn1 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Dim R_GridViewDecimalColumn1 As R_FrontEnd.R_GridViewDecimalColumn = New R_FrontEnd.R_GridViewDecimalColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn2 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDecimalColumn2 As R_FrontEnd.R_GridViewDecimalColumn = New R_FrontEnd.R_GridViewDecimalColumn()
        Dim R_GridViewDateTimeColumn3 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn4 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn8 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn9 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn10 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn11 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn12 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn13 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.bsLocation = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsFunction = New System.Windows.Forms.BindingSource(Me.components)
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.gvItemSchedule = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvItemSchedule = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridItemSchedule = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.conGridSchedule = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblCustom = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblCustomer = New R_FrontEnd.R_RadLabel(Me.components)
        Me.btnClose = New R_FrontEnd.R_RadButton(Me.components)
        Me.txtSession = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtProject = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtVersion = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtApplication = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.btnFilter = New R_FrontEnd.R_PopUp(Me.components)
        Me.btnStart = New R_FrontEnd.R_RadButton(Me.components)
        Me.lblSession = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblProject = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblVersion = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvSchedule = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvSchedule = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsSession = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsProject = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsVersion = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.preAssign = New R_FrontEnd.R_PredefinedDock(Me.components)
        CType(Me.bsLocation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsFunction, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.gvItemSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvItemSchedule.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvItemSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridItemSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.lblCustom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnClose, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnFilter, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnStart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvSchedule.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'bsLocation
        '
        Me.bsLocation.DataSource = GetType(CSM00500Front.CSM00500UsersServiceRef.RCustDBLocationComboDTO)
        '
        'bsFunction
        '
        Me.bsFunction.DataSource = GetType(CSM00511Front.CSM00511AssignmentServiceRef.RCustDBFunctionComboDTO)
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.gvItemSchedule, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.SplitContainer1, 0, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 156.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'gvItemSchedule
        '
        Me.gvItemSchedule.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvItemSchedule.EnableFastScrolling = True
        Me.gvItemSchedule.Location = New System.Drawing.Point(3, 159)
        '
        '
        '
        Me.gvItemSchedule.MasterTemplate.AllowAddNewRow = False
        Me.gvItemSchedule.MasterTemplate.AllowDeleteRow = False
        Me.gvItemSchedule.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn1.FieldName = "_CGANTT_SEQUENCE"
        R_GridViewTextBoxColumn1.HeaderText = "_CGANTT_SEQUENCE"
        R_GridViewTextBoxColumn1.MaxLength = 5
        R_GridViewTextBoxColumn1.Name = "_CGANTT_SEQUENCE"
        R_GridViewTextBoxColumn1.R_EnableEDIT = True
        R_GridViewTextBoxColumn1.R_ResourceId = "_CGANTT_SEQUENCE"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 129
        R_GridViewTextBoxColumn2.FieldName = "_CITEM_ID"
        R_GridViewTextBoxColumn2.HeaderText = "_CITEM_ID"
        R_GridViewTextBoxColumn2.IsPinned = True
        R_GridViewTextBoxColumn2.Name = "_CITEM_ID"
        R_GridViewTextBoxColumn2.PinPosition = Telerik.WinControls.UI.PinnedColumnPosition.Left
        R_GridViewTextBoxColumn2.R_ResourceId = "_CITEM_ID"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 74
        R_GridViewTextBoxColumn3.FieldName = "_CITEM_NAME"
        R_GridViewTextBoxColumn3.HeaderText = "_CITEM_NAME"
        R_GridViewTextBoxColumn3.IsPinned = True
        R_GridViewTextBoxColumn3.Name = "_CITEM_NAME"
        R_GridViewTextBoxColumn3.PinPosition = Telerik.WinControls.UI.PinnedColumnPosition.Left
        R_GridViewTextBoxColumn3.R_ResourceId = "_CITEM_NAME"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 95
        R_GridViewTextBoxColumn4.FieldName = "_CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn4.HeaderText = "_CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn4.IsVisible = False
        R_GridViewTextBoxColumn4.Name = "_CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 131
        R_GridViewTextBoxColumn5.FieldName = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn5.HeaderText = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn5.IsVisible = False
        R_GridViewTextBoxColumn5.Name = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 104
        R_GridViewTextBoxColumn6.FieldName = "_CFUNCTION_ID"
        R_GridViewTextBoxColumn6.HeaderText = "_CFUNCTION_ID"
        R_GridViewTextBoxColumn6.Name = "_CFUNCTION_ID"
        R_GridViewTextBoxColumn6.R_ResourceId = "_CFUNCTION_ID"
        R_GridViewTextBoxColumn6.R_UDT = Nothing
        R_GridViewTextBoxColumn6.Width = 104
        R_GridViewLookUpColumn1.FieldName = "_CUSER_NAME"
        R_GridViewLookUpColumn1.HeaderText = "_CUSER_NAME"
        R_GridViewLookUpColumn1.Name = "_CUSER_NAME"
        R_GridViewLookUpColumn1.R_EnableEDIT = True
        R_GridViewLookUpColumn1.R_ResourceId = "_CUSER_ID"
        R_GridViewLookUpColumn1.R_Title = Nothing
        R_GridViewLookUpColumn1.Width = 97
        R_GridViewLookUpColumn2.FieldName = "_CREASSIGNMENT_NAME"
        R_GridViewLookUpColumn2.HeaderText = "_CREASSIGNMENT_NAME"
        R_GridViewLookUpColumn2.Name = "_CREASSIGNMENT_NAME"
        R_GridViewLookUpColumn2.R_EnableEDIT = True
        R_GridViewLookUpColumn2.R_ResourceId = "_CREASSIGNMENT_NAME"
        R_GridViewLookUpColumn2.R_Title = Nothing
        R_GridViewLookUpColumn2.Width = 152
        R_GridViewTextBoxColumn7.FieldName = "_CSTATUS"
        R_GridViewTextBoxColumn7.HeaderText = "_CSTATUS"
        R_GridViewTextBoxColumn7.Name = "_CSTATUS"
        R_GridViewTextBoxColumn7.R_ResourceId = "_CSTATUS"
        R_GridViewTextBoxColumn7.R_UDT = Nothing
        R_GridViewTextBoxColumn7.Width = 73
        R_GridViewCheckBoxColumn1.FieldName = "_LMANAGER"
        R_GridViewCheckBoxColumn1.HeaderText = "_LMANAGER"
        R_GridViewCheckBoxColumn1.IsVisible = False
        R_GridViewCheckBoxColumn1.Name = "_LMANAGER"
        R_GridViewCheckBoxColumn1.R_ResourceId = Nothing
        R_GridViewCheckBoxColumn1.ReadOnly = True
        R_GridViewComboBoxColumn1.DataSource = Me.bsLocation
        R_GridViewComboBoxColumn1.DisplayMember = "CLOCATION_NAME"
        R_GridViewComboBoxColumn1.FieldName = "_CLOCATION_ID"
        R_GridViewComboBoxColumn1.HeaderText = "_CLOCATION_ID"
        R_GridViewComboBoxColumn1.Name = "_CLOCATION_ID"
        R_GridViewComboBoxColumn1.R_EnableEDIT = True
        R_GridViewComboBoxColumn1.R_ResourceId = "_CLOCATION_ID"
        R_GridViewComboBoxColumn1.ValueMember = "CLOCATION_ID"
        R_GridViewComboBoxColumn1.Width = 104
        R_GridViewDecimalColumn1.DecimalPlaces = 0
        R_GridViewDecimalColumn1.FieldName = "_NMANDAYS"
        R_GridViewDecimalColumn1.FormatString = "{0:N}"
        R_GridViewDecimalColumn1.HeaderText = "_NMANDAYS"
        R_GridViewDecimalColumn1.Maximum = New Decimal(New Integer() {4096, 0, 0, 0})
        R_GridViewDecimalColumn1.Minimum = New Decimal(New Integer() {0, 0, 0, 0})
        R_GridViewDecimalColumn1.Name = "_NMANDAYS"
        R_GridViewDecimalColumn1.R_EnableEDIT = True
        R_GridViewDecimalColumn1.R_ResourceId = "_NMANDAYS"
        R_GridViewDecimalColumn1.ThousandsSeparator = True
        R_GridViewDecimalColumn1.Width = 89
        R_GridViewDateTimeColumn1.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn1.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn1.FieldName = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn1.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn1.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn1.HeaderText = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn1.Name = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn1.R_EnableEDIT = True
        R_GridViewDateTimeColumn1.R_ResourceId = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn1.Width = 131
        R_GridViewDateTimeColumn2.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn2.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn2.FieldName = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn2.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn2.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn2.HeaderText = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn2.Name = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn2.R_ResourceId = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn2.Width = 121
        R_GridViewDecimalColumn2.DecimalPlaces = 0
        R_GridViewDecimalColumn2.FieldName = "_NREVISED_MANDAYS"
        R_GridViewDecimalColumn2.FormatString = "{0:N}"
        R_GridViewDecimalColumn2.HeaderText = "_NREVISED_MANDAYS"
        R_GridViewDecimalColumn2.Maximum = New Decimal(New Integer() {4096, 0, 0, 0})
        R_GridViewDecimalColumn2.Minimum = New Decimal(New Integer() {0, 0, 0, 0})
        R_GridViewDecimalColumn2.Name = "_NREVISED_MANDAYS"
        R_GridViewDecimalColumn2.R_ResourceId = "_NREVISED_MANDAYS"
        R_GridViewDecimalColumn2.ThousandsSeparator = True
        R_GridViewDecimalColumn2.Width = 136
        R_GridViewDateTimeColumn3.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn3.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn3.FieldName = "_DREVISED_START_DATE"
        R_GridViewDateTimeColumn3.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn3.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn3.HeaderText = "_DREVISED_START_DATE"
        R_GridViewDateTimeColumn3.Name = "_DREVISED_START_DATE"
        R_GridViewDateTimeColumn3.R_EnableEDIT = True
        R_GridViewDateTimeColumn3.R_ResourceId = "_DREVISED_START_DATE"
        R_GridViewDateTimeColumn3.Width = 145
        R_GridViewDateTimeColumn4.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn4.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn4.FieldName = "_DREVISED_END_DATE"
        R_GridViewDateTimeColumn4.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn4.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn4.HeaderText = "_DREVISED_END_DATE"
        R_GridViewDateTimeColumn4.Name = "_DREVISED_END_DATE"
        R_GridViewDateTimeColumn4.R_ResourceId = "_DREVISED_END_DATE"
        R_GridViewDateTimeColumn4.Width = 136
        R_GridViewTextBoxColumn8.FieldName = "_CUSER_ID"
        R_GridViewTextBoxColumn8.HeaderText = "_CUSER_ID"
        R_GridViewTextBoxColumn8.IsVisible = False
        R_GridViewTextBoxColumn8.Name = "_CUSER_ID"
        R_GridViewTextBoxColumn8.R_ResourceId = Nothing
        R_GridViewTextBoxColumn8.R_UDT = Nothing
        R_GridViewTextBoxColumn9.FieldName = "_CREASSIGNMENT_ID"
        R_GridViewTextBoxColumn9.HeaderText = "_CREASSIGNMENT_ID"
        R_GridViewTextBoxColumn9.IsVisible = False
        R_GridViewTextBoxColumn9.Name = "_CREASSIGNMENT_ID"
        R_GridViewTextBoxColumn9.R_ResourceId = Nothing
        R_GridViewTextBoxColumn9.R_UDT = Nothing
        Me.gvItemSchedule.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewTextBoxColumn4, R_GridViewTextBoxColumn5, R_GridViewTextBoxColumn6, R_GridViewLookUpColumn1, R_GridViewLookUpColumn2, R_GridViewTextBoxColumn7, R_GridViewCheckBoxColumn1, R_GridViewComboBoxColumn1, R_GridViewDecimalColumn1, R_GridViewDateTimeColumn1, R_GridViewDateTimeColumn2, R_GridViewDecimalColumn2, R_GridViewDateTimeColumn3, R_GridViewDateTimeColumn4, R_GridViewTextBoxColumn8, R_GridViewTextBoxColumn9})
        Me.gvItemSchedule.MasterTemplate.DataSource = Me.bsGvItemSchedule
        Me.gvItemSchedule.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvItemSchedule.MasterTemplate.EnableFiltering = True
        Me.gvItemSchedule.MasterTemplate.ShowFilteringRow = False
        Me.gvItemSchedule.MasterTemplate.ShowGroupedColumns = True
        Me.gvItemSchedule.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvItemSchedule.Name = "gvItemSchedule"
        Me.gvItemSchedule.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvItemSchedule.R_ConductorGridSource = Me.conGridItemSchedule
        Me.gvItemSchedule.R_ConductorSource = Nothing
        Me.gvItemSchedule.R_DataAdded = False
        Me.gvItemSchedule.R_EnableGrouping = True
        Me.gvItemSchedule.R_NewRowText = Nothing
        Me.gvItemSchedule.ShowGroupPanel = False
        Me.gvItemSchedule.ShowHeaderCellButtons = True
        Me.gvItemSchedule.Size = New System.Drawing.Size(1271, 413)
        Me.gvItemSchedule.TabIndex = 4
        Me.gvItemSchedule.Text = "R_RadGridView1"
        '
        'bsGvItemSchedule
        '
        Me.bsGvItemSchedule.DataSource = GetType(CSM00511Front.CSM00511AssignmentServiceRef.CSM00511ItemDTO)
        '
        'conGridItemSchedule
        '
        Me.conGridItemSchedule.R_ConductorParent = Me.conGridSchedule
        Me.conGridItemSchedule.R_RadGroupBox = Nothing
        '
        'conGridSchedule
        '
        Me.conGridSchedule.R_ConductorParent = Nothing
        Me.conGridSchedule.R_IsHeader = True
        Me.conGridSchedule.R_RadGroupBox = Nothing
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(3, 3)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.Panel1)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.gvSchedule)
        Me.SplitContainer1.Size = New System.Drawing.Size(1271, 150)
        Me.SplitContainer1.SplitterDistance = 641
        Me.SplitContainer1.TabIndex = 1
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lblCustom)
        Me.Panel1.Controls.Add(Me.lblCustomer)
        Me.Panel1.Controls.Add(Me.btnClose)
        Me.Panel1.Controls.Add(Me.txtSession)
        Me.Panel1.Controls.Add(Me.txtProject)
        Me.Panel1.Controls.Add(Me.txtVersion)
        Me.Panel1.Controls.Add(Me.txtApplication)
        Me.Panel1.Controls.Add(Me.btnFilter)
        Me.Panel1.Controls.Add(Me.btnStart)
        Me.Panel1.Controls.Add(Me.lblSession)
        Me.Panel1.Controls.Add(Me.lblProject)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Controls.Add(Me.lblVersion)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(641, 150)
        Me.Panel1.TabIndex = 0
        '
        'lblCustom
        '
        Me.lblCustom.AutoSize = False
        Me.lblCustom.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustom.Location = New System.Drawing.Point(521, 61)
        Me.lblCustom.Name = "lblCustom"
        Me.lblCustom.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustom.R_ResourceId = ""
        Me.lblCustom.Size = New System.Drawing.Size(100, 18)
        Me.lblCustom.TabIndex = 50
        Me.lblCustom.Text = "Application..."
        '
        'lblCustomer
        '
        Me.lblCustomer.AutoSize = False
        Me.lblCustomer.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustomer.Location = New System.Drawing.Point(9, 35)
        Me.lblCustomer.Name = "lblCustomer"
        Me.lblCustomer.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustomer.R_ResourceId = "lblCustomer"
        Me.lblCustomer.Size = New System.Drawing.Size(100, 18)
        Me.lblCustomer.TabIndex = 49
        Me.lblCustomer.Text = "Application..."
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(125, 113)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.R_ConductorGridSource = Me.conGridSchedule
        Me.btnClose.R_ConductorSource = Nothing
        Me.btnClose.R_DescriptionId = Nothing
        Me.btnClose.R_EnableHASDATA = True
        Me.btnClose.R_ResourceId = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(110, 24)
        Me.btnClose.TabIndex = 48
        Me.btnClose.Text = "R_RadButton1"
        '
        'txtSession
        '
        Me.txtSession.Location = New System.Drawing.Point(115, 86)
        Me.txtSession.Name = "txtSession"
        Me.txtSession.R_ConductorGridSource = Nothing
        Me.txtSession.R_ConductorSource = Nothing
        Me.txtSession.R_UDT = Nothing
        Me.txtSession.ReadOnly = True
        Me.txtSession.Size = New System.Drawing.Size(200, 20)
        Me.txtSession.TabIndex = 47
        Me.txtSession.TabStop = False
        '
        'txtProject
        '
        Me.txtProject.Location = New System.Drawing.Point(115, 60)
        Me.txtProject.Name = "txtProject"
        Me.txtProject.R_ConductorGridSource = Nothing
        Me.txtProject.R_ConductorSource = Nothing
        Me.txtProject.R_UDT = Nothing
        Me.txtProject.ReadOnly = True
        Me.txtProject.Size = New System.Drawing.Size(400, 20)
        Me.txtProject.TabIndex = 46
        Me.txtProject.TabStop = False
        '
        'txtVersion
        '
        Me.txtVersion.Location = New System.Drawing.Point(115, 34)
        Me.txtVersion.Name = "txtVersion"
        Me.txtVersion.R_ConductorGridSource = Nothing
        Me.txtVersion.R_ConductorSource = Nothing
        Me.txtVersion.R_UDT = Nothing
        Me.txtVersion.ReadOnly = True
        Me.txtVersion.Size = New System.Drawing.Size(200, 20)
        Me.txtVersion.TabIndex = 45
        Me.txtVersion.TabStop = False
        '
        'txtApplication
        '
        Me.txtApplication.Location = New System.Drawing.Point(115, 8)
        Me.txtApplication.Name = "txtApplication"
        Me.txtApplication.R_ConductorGridSource = Nothing
        Me.txtApplication.R_ConductorSource = Nothing
        Me.txtApplication.R_UDT = Nothing
        Me.txtApplication.ReadOnly = True
        Me.txtApplication.Size = New System.Drawing.Size(400, 20)
        Me.txtApplication.TabIndex = 44
        Me.txtApplication.TabStop = False
        '
        'btnFilter
        '
        Me.btnFilter.Location = New System.Drawing.Point(521, 6)
        Me.btnFilter.Name = "btnFilter"
        Me.btnFilter.R_ConductorGridSource = Nothing
        Me.btnFilter.R_ConductorSource = Nothing
        Me.btnFilter.R_DescriptionId = Nothing
        Me.btnFilter.R_ResourceId = "btnFilter"
        Me.btnFilter.R_Title = "Schedule Filter"
        Me.btnFilter.Size = New System.Drawing.Size(110, 24)
        Me.btnFilter.TabIndex = 36
        Me.btnFilter.Text = "R_PopUp1"
        '
        'btnStart
        '
        Me.btnStart.Location = New System.Drawing.Point(9, 113)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.R_ConductorGridSource = Me.conGridSchedule
        Me.btnStart.R_ConductorSource = Nothing
        Me.btnStart.R_DescriptionId = Nothing
        Me.btnStart.R_EnableHASDATA = True
        Me.btnStart.R_ResourceId = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(110, 24)
        Me.btnStart.TabIndex = 33
        Me.btnStart.Text = "R_RadButton1"
        '
        'lblSession
        '
        Me.lblSession.AutoSize = False
        Me.lblSession.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblSession.Location = New System.Drawing.Point(9, 87)
        Me.lblSession.Name = "lblSession"
        Me.lblSession.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblSession.R_ResourceId = "lblSession"
        Me.lblSession.Size = New System.Drawing.Size(100, 18)
        Me.lblSession.TabIndex = 32
        Me.lblSession.Text = "Application..."
        '
        'lblProject
        '
        Me.lblProject.AutoSize = False
        Me.lblProject.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblProject.Location = New System.Drawing.Point(9, 61)
        Me.lblProject.Name = "lblProject"
        Me.lblProject.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblProject.R_ResourceId = "lblProject"
        Me.lblProject.Size = New System.Drawing.Size(100, 18)
        Me.lblProject.TabIndex = 28
        Me.lblProject.Text = "Application..."
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 25
        Me.lblApplication.Text = "Application..."
        '
        'lblVersion
        '
        Me.lblVersion.AutoSize = False
        Me.lblVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblVersion.Location = New System.Drawing.Point(9, 35)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblVersion.R_ResourceId = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(100, 18)
        Me.lblVersion.TabIndex = 27
        Me.lblVersion.Text = "Application..."
        '
        'gvSchedule
        '
        Me.gvSchedule.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvSchedule.EnableFastScrolling = True
        Me.gvSchedule.Location = New System.Drawing.Point(0, 0)
        '
        '
        '
        Me.gvSchedule.MasterTemplate.AllowAddNewRow = False
        Me.gvSchedule.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn10.FieldName = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn10.HeaderText = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn10.Name = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn10.R_ResourceId = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn10.R_UDT = Nothing
        R_GridViewTextBoxColumn10.Width = 103
        R_GridViewTextBoxColumn11.FieldName = "_CSCHEDULE_TYPE_NAME"
        R_GridViewTextBoxColumn11.HeaderText = "_CSCHEDULE_TYPE_NAME"
        R_GridViewTextBoxColumn11.Name = "_CSCHEDULE_TYPE_NAME"
        R_GridViewTextBoxColumn11.R_ResourceId = "_CSCHEDULE_TYPE_NAME"
        R_GridViewTextBoxColumn11.R_UDT = Nothing
        R_GridViewTextBoxColumn11.Width = 153
        R_GridViewTextBoxColumn12.FieldName = "_CSTATUS"
        R_GridViewTextBoxColumn12.HeaderText = "_CSTATUS"
        R_GridViewTextBoxColumn12.Name = "_CSTATUS"
        R_GridViewTextBoxColumn12.R_ResourceId = "_CSTATUS"
        R_GridViewTextBoxColumn12.R_UDT = Nothing
        R_GridViewTextBoxColumn12.Width = 73
        R_GridViewTextBoxColumn13.FieldName = "_CNOTE"
        R_GridViewTextBoxColumn13.HeaderText = "_CNOTE"
        R_GridViewTextBoxColumn13.MaxLength = 200
        R_GridViewTextBoxColumn13.Name = "_CNOTE"
        R_GridViewTextBoxColumn13.R_EnableEDIT = True
        R_GridViewTextBoxColumn13.R_ResourceId = "_CNOTE"
        R_GridViewTextBoxColumn13.R_UDT = Nothing
        R_GridViewTextBoxColumn13.Width = 63
        Me.gvSchedule.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn10, R_GridViewTextBoxColumn11, R_GridViewTextBoxColumn12, R_GridViewTextBoxColumn13})
        Me.gvSchedule.MasterTemplate.DataSource = Me.bsGvSchedule
        Me.gvSchedule.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvSchedule.MasterTemplate.EnableFiltering = True
        Me.gvSchedule.MasterTemplate.EnableGrouping = False
        Me.gvSchedule.MasterTemplate.ShowFilteringRow = False
        Me.gvSchedule.MasterTemplate.ShowGroupedColumns = True
        Me.gvSchedule.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvSchedule.Name = "gvSchedule"
        Me.gvSchedule.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvSchedule.R_ConductorGridSource = Me.conGridSchedule
        Me.gvSchedule.R_ConductorSource = Nothing
        Me.gvSchedule.R_DataAdded = False
        Me.gvSchedule.R_NewRowText = Nothing
        Me.gvSchedule.ShowHeaderCellButtons = True
        Me.gvSchedule.Size = New System.Drawing.Size(626, 150)
        Me.gvSchedule.TabIndex = 2
        Me.gvSchedule.Text = "R_RadGridView1"
        '
        'bsGvSchedule
        '
        Me.bsGvSchedule.DataSource = GetType(CSM00511Front.CSM00511ServiceRef.CSM00511ScheduleDTO)
        '
        'bsSession
        '
        Me.bsSession.DataSource = GetType(CSM00511Front.CSM00511ServiceRef.RCustDBSessionComboDTO)
        '
        'bsProject
        '
        Me.bsProject.DataSource = GetType(CSM00511Front.CSM00511ServiceRef.RCustDBProjectComboDTO)
        '
        'bsVersion
        '
        Me.bsVersion.DataSource = GetType(CSM00511Front.CSM00511ServiceRef.RCustDBVersionComboDTO)
        '
        'bsApps
        '
        Me.bsApps.DataSource = GetType(CSM00511Front.CSM00511ServiceRef.RLicenseAppComboDTO)
        '
        'preAssign
        '
        Me.preAssign.R_ConductorGridSource = Me.conGridSchedule
        Me.preAssign.R_ConductorSource = Nothing
        Me.preAssign.R_CopyAccess = True
        Me.preAssign.R_DockIndex = 0
        Me.preAssign.R_EnableHASDATA = True
        Me.preAssign.R_HeaderTitle = ""
        '
        'CSM00511
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CSM00511"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.bsLocation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsFunction, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        CType(Me.gvItemSchedule.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvItemSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvItemSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridItemSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.lblCustom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnClose, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnFilter, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnStart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvSchedule.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(false)

End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource
    Friend WithEvents bsVersion As System.Windows.Forms.BindingSource
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents lblVersion As R_FrontEnd.R_RadLabel
    Friend WithEvents bsFunction As System.Windows.Forms.BindingSource
    Friend WithEvents bsProject As System.Windows.Forms.BindingSource
    Friend WithEvents bsSession As System.Windows.Forms.BindingSource
    Friend WithEvents conGridSchedule As R_FrontEnd.R_ConductorGrid
    Friend WithEvents gvSchedule As R_FrontEnd.R_RadGridView
    Friend WithEvents bsGvSchedule As System.Windows.Forms.BindingSource
    Friend WithEvents lblSession As R_FrontEnd.R_RadLabel
    Friend WithEvents lblProject As R_FrontEnd.R_RadLabel
    Friend WithEvents preAssign As R_FrontEnd.R_PredefinedDock
    Friend WithEvents btnStart As R_FrontEnd.R_RadButton
    Friend WithEvents btnFilter As R_FrontEnd.R_PopUp
    Friend WithEvents txtSession As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtProject As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtVersion As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtApplication As R_FrontEnd.R_RadTextBox
    Friend WithEvents btnClose As R_FrontEnd.R_RadButton
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents lblCustom As R_FrontEnd.R_RadLabel
    Friend WithEvents lblCustomer As R_FrontEnd.R_RadLabel
    Friend WithEvents gvItemSchedule As R_FrontEnd.R_RadGridView
    Friend WithEvents bsGvItemSchedule As System.Windows.Forms.BindingSource
    Friend WithEvents conGridItemSchedule As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsLocation As System.Windows.Forms.BindingSource

End Class
