﻿Imports CSM00511FrontResources
Imports R_Common
Imports CSM00511Front.CSM00511ServiceRef
Imports R_FrontEnd
Imports ClientHelper
Imports CSM00511Front.CSM00511StreamingServiceRef
Imports System.ServiceModel.Channels
Imports System.ServiceModel
Imports Telerik.WinControls.Data
Imports System.ComponentModel
Imports CSM00500Front
Imports CSM00511Front.CSM00511AssignmentServiceRef
Imports CSM00511Front.CSM00511AssignmentStreamingServiceRef
Imports RCustDBFrontHelper.General

Public Class CSM00511

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSM00511Service/CSM00511Service.svc"
    Dim C_ServiceNameStream As String = "CSM00511Service/CSM00511StreamingService.svc"
    Dim C_AssignmentServiceName As String = "CSM00511Service/CSM00511AssignmentService.svc"
    Dim C_AssignmentServiceNameStream As String = "CSM00511Service/CSM00511AssignmentStreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _CVERSION As String
    Dim _CPROJECTID As String
    Dim _CSESSIONID As String
    Dim _CSCHEDULEID As String
    Dim _CUSER_NAME As String
    Dim _CFUNCTIONID As String
    Dim _CSESSION_STATUS As String
    Dim _LDONE_COMBO_SETTING As Boolean = False
    Dim _LREADY_TO_REFRESH As Boolean = False
    Dim _LINIT As Boolean
    Dim _IGRID_MODE As Integer
    Dim _LMANAGER As Boolean
    Dim _CCUSTOMER_NAME As String
    Dim _LCUSTOM As Boolean
    Dim loFilterParam As New CSM00511FilterParameterDTO

#End Region

#Region " SUBs and FUNCTIONs "

    Private Sub RefreshGrids(poTableKey As CSM00500KeyDTO)
        With gvSchedule
            .R_RefreshGrid(poTableKey)
            .Columns(0).Sort(Telerik.WinControls.UI.RadSortOrder.Ascending, False)
        End With
    End Sub

    Private Sub RefreshAssignmentGrid(poTableKey As CSM00500ItemKeyDTO)
        With gvItemSchedule
            .R_RefreshGrid(poTableKey)
            .Columns(0).Sort(Telerik.WinControls.UI.RadSortOrder.Ascending, False)
        End With
    End Sub

#End Region

#Region " FORM Events "

    Private Sub CSM00511_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loSvc As CSM00511AssignmentServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00511AssignmentService, CSM00511AssignmentServiceClient)(e_ServiceClientType.RegularService, C_AssignmentServiceName)
        Dim loComboKey As New CSM00511Front.CSM00511ServiceRef.RCustDBProjectKeyDTO
        Dim loLocationCombo As New List(Of RCustDBLocationComboDTO)

        Try
            _LINIT = False
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            _LINIT = True
            ' Predefined dock
            Me.R_Components = Me.components
            preAssign.R_HeaderTitle = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00511AssignTitle")
            loFilterParam.OFILTER_KEY.CCOMPANY_ID = _CCOMPID
            loFilterParam.OFILTER_KEY.CUSER_ID = _CUSERID
            loLocationCombo = loSvc.GetLocationCombo()
            bsLocation.DataSource = loLocationCombo

            ' Item grid
            Dim loItemGroupDescriptor As New GroupDescriptor()
            loItemGroupDescriptor.GroupNames.Add("_CATTRIBUTE_GROUP", ListSortDirection.Ascending)
            loItemGroupDescriptor.GroupNames.Add("_CATTRIBUTE_ID", ListSortDirection.Descending)
            loItemGroupDescriptor.GroupNames.Add("_CITEM_ID", ListSortDirection.Descending)
            Me.gvItemSchedule.GroupDescriptors.Clear()
            Me.gvItemSchedule.GroupDescriptors.Add(loItemGroupDescriptor)
            Me.gvItemSchedule.AutoExpandGroups = True

            btnFilter.PerformClick()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub CSM00511_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " GRIDVIEW Events "

    Private Sub gvSchedule_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvSchedule.DataBindingComplete
        gvSchedule.BestFitColumns()
    End Sub

    Private Sub gvSchedule_R_CheckDelete(poEntity As Object, ByRef plAllowDelete As Boolean) Handles gvSchedule.R_CheckDelete
        With CType(poEntity, CSM00511ScheduleDTO)
            plAllowDelete = (._CSCHEDULE_TYPE = "0" Or ._CSCHEDULE_TYPE = "1" Or ._CSCHEDULE_TYPE = "2" Or ._CSCHEDULE_TYPE = "3") And Not ._CSTATUS = "CLOSED"
        End With
    End Sub

    Private Sub gvSchedule_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvSchedule.R_Display
        Dim loEx As New R_Exception
        Dim loTableKey As New CSM00500ItemKeyDTO

        Try
            With CType(poEntity, CSM00511ScheduleDTO)
                loTableKey.CCOMPANY_ID = ._CCOMPANY_ID
                loTableKey.CAPPS_CODE = ._CAPPS_CODE
                loTableKey.CVERSION = ._CVERSION
                loTableKey.CPROJECT_ID = ._CPROJECT_ID
                loTableKey.CSESSION_ID = ._CSESSION_ID
                loTableKey.CSCHEDULE_ID = ._CSCHEDULE_ID
                _CAPPSCODE = ._CAPPS_CODE
                _CVERSION = ._CVERSION
                _CPROJECTID = ._CPROJECT_ID
                _CSESSIONID = ._CSESSION_ID
                _CSCHEDULEID = ._CSCHEDULE_ID
            End With
            gvItemSchedule.R_RefreshGrid(loTableKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

    Private Sub gvSchedule_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvSchedule.R_Saving
        With CType(poEntity, CSM00511ScheduleDTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With
    End Sub

    Private Sub gvSchedule_R_ServiceDelete(poEntity As Object) Handles gvSchedule.R_ServiceDelete
        Dim loService As CSM00511ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00511Service, CSM00511ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String
        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As FaultException
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

    Private Sub gvSchedule_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvSchedule.R_ServiceGetListRecord
        Dim loServiceStream As CSM00511StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00511StreamingService, CSM00511StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00511ScheduleGridDTO)
        Dim loListEntity As New List(Of CSM00511ScheduleDTO)

        Try
            With CType(poEntity, CSM00500KeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
                R_Utility.R_SetStreamingContext("cProjectId", .CPROJECT_ID)
                R_Utility.R_SetStreamingContext("cSessionId", .CSESSION_ID)
            End With

            loRtn = loServiceStream.GetProjectScheduleList()
            loStreaming = R_StreamUtility(Of CSM00511ScheduleGridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00511ScheduleGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New CSM00511ScheduleDTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                                   ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                                   ._CVERSION = loDto.CVERSION,
                                                                   ._CPROJECT_ID = loDto.CPROJECT_ID,
                                                                   ._CSESSION_ID = loDto.CSESSION_ID,
                                                                   ._CSCHEDULE_ID = loDto.CSCHEDULE_ID,
                                                                   ._CSCHEDULE_TYPE = loDto.CSCHEDULE_TYPE,
                                                                   ._CSCHEDULE_TYPE_NAME = loDto.CSCHEDULE_TYPE_NAME,
                                                                   ._CSTATUS = loDto.CSTATUS,
                                                                   ._CNOTE = loDto.CNOTE,
                                                                   ._CCREATE_BY = loDto.CCREATE_BY,
                                                                   ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                                   ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                                   ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSchedule_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvSchedule.R_ServiceGetRecord
        Dim loService As CSM00511ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00511Service, CSM00511ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New CSM00511ScheduleDTO With {._CCOMPANY_ID = _CCOMPID,
                                                                                     ._CAPPS_CODE = loFilterParam.OFILTER_KEY.CAPPS_CODE,
                                                                                     ._CVERSION = loFilterParam.OFILTER_KEY.CVERSION,
                                                                                     ._CPROJECT_ID = loFilterParam.OFILTER_KEY.CPROJECT_ID,
                                                                                     ._CSESSION_ID = loFilterParam.OFILTER_KEY.CSESSION_ID,
                                                                                     ._CSCHEDULE_ID = CType(bsGvSchedule.Current, CSM00511ScheduleDTO)._CSCHEDULE_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSchedule_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvSchedule.R_ServiceSave
        Dim loService As CSM00511ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00511Service, CSM00511ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            With CType(poEntity, CSM00511ScheduleDTO)
                poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " PREDEFINED DOCK Events "

    'Private Sub preAssign_R_InstantiateDock(ByRef poTargetForm As R_FrontEnd.R_FormBase) Handles preAssign.R_InstantiateDock
    '    poTargetForm = New CSM00511Assign
    'End Sub

    Private Sub preAssign_R_PassParameter(ByRef poParameter As Object) Handles preAssign.R_PassParameter
        loFilterParam.OFILTER_KEY.CSCHEDULE_ID = CType(bsGvSchedule.Current, CSM00511ScheduleDTO)._CSCHEDULE_ID
        loFilterParam.CSCHEDULE_TYPE = CType(bsGvSchedule.Current, CSM00511ScheduleDTO)._CSCHEDULE_TYPE
        poParameter = loFilterParam
    End Sub

#End Region

#Region " FILTER "

    Private Sub btnFilter_R_After_Open_Form(poPopUpResult As System.Windows.Forms.DialogResult, poPopUpEntityResult As Object) Handles btnFilter.R_After_Open_Form

        If poPopUpResult = Windows.Forms.DialogResult.OK Then
            loFilterParam = poPopUpEntityResult
            With loFilterParam
                txtApplication.Text = .CAPPS_NAME
                txtVersion.Text = IIf(.LCUSTOM, .CCUSTOMER_NAME, .CCODE_NAME)
                txtProject.Text = .CPROJECT_NAME
                txtSession.Text = .OFILTER_KEY.CSESSION_ID
                lblVersion.Visible = Not .LCUSTOM
                lblCustomer.Visible = .LCUSTOM
                lblCustom.Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), IIf(.LCUSTOM, "rdbCustom", "rdbStandard"))
                RefreshGrids(.OFILTER_KEY)
            End With
        End If
    End Sub

    Private Sub btnFilter_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnFilter.R_Before_Open_Form
        poTargetForm = New CSM00511Filter
        poParameter = loFilterParam
    End Sub

#End Region

#Region " GRIDVIEW ITEM ASSIGNMENT Events "

    Private Sub gvItemSchedule_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvItemSchedule.DataBindingComplete
        gvItemSchedule.BestFitColumns()
    End Sub

    Private Sub gvItemSchedule_R_Before_Open_LookUpForm(sender As Object, e As Telerik.WinControls.UI.EditorRequiredEventArgs, ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles gvItemSchedule.R_Before_Open_LookUpForm
        poTargetForm = New CSM00500UserList
        poParameter = New CSM00500UserListParameterDTO With {.CCOMPANY_ID = _CCOMPID, _
                                                             .CAPPS_CODE = _CAPPSCODE, _
                                                             .CVERSION = _CVERSION, _
                                                             .CPROJECT_ID = _CPROJECTID, _
                                                             .CFUNCTION_ID = _CFUNCTIONID, _
                                                             .CSESSION_ID = _CSESSIONID}
    End Sub

    Private Sub gvItemSchedule_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvItemSchedule.R_Display
        Dim loEx As New R_Exception
        Dim loTableKey As New RCustDBIssueKeyDTO

        Try
            With CType(poEntity, CSM00511ItemDTO)
                _LMANAGER = ._LMANAGER
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()


    End Sub

    Private Sub gvItemSchedule_R_Return_LookUp(sender As Object, e As Telerik.WinControls.UI.EditorRequiredEventArgs, poReturnObject As Object) Handles gvItemSchedule.R_Return_LookUp
        If gvItemSchedule.CurrentColumn.Name.Trim.Equals("_CUSER_NAME") Then
            With gvItemSchedule.CurrentRow
                .Cells("_CUSER_ID").Value = poReturnObject.CUSER_ID
                .Cells("_CREASSIGNMENT_ID").Value = poReturnObject.CUSER_ID
                .Cells("_CUSER_NAME").Value = poReturnObject.CUSER_NAME
                .Cells("_CREASSIGNMENT_NAME").Value = poReturnObject.CUSER_NAME
                .Cells("_CLOCATION_ID").Value = poReturnObject.CLOCATION_ID
            End With
        End If
        If gvItemSchedule.CurrentColumn.Name.Trim.Equals("_CREASSIGNMENT_NAME") Then
            With gvItemSchedule.CurrentRow
                .Cells("_CREASSIGNMENT_ID").Value = poReturnObject.CUSER_ID
                .Cells("_CREASSIGNMENT_NAME").Value = poReturnObject.CUSER_NAME
                .Cells("_CLOCATION_ID").Value = poReturnObject.CLOCATION_ID
            End With
        End If
    End Sub

    Private Sub gvItemSchedule_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvItemSchedule.R_Saving
        With CType(poEntity, CSM00511ItemDTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With
    End Sub

    Private Sub gvItemSchedule_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvItemSchedule.R_ServiceGetListRecord
        Dim loServiceStream As CSM00511AssignmentStreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00511AssignmentStreamingService, CSM00511AssignmentStreamingServiceClient)(e_ServiceClientType.StreamingService, C_AssignmentServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00511ItemScheduleGridDTO)
        Dim loListEntity As New List(Of CSM00511ItemDTO)

        Try
            With CType(poEntity, CSM00500ItemKeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
                R_Utility.R_SetStreamingContext("cProjectId", .CPROJECT_ID)
                R_Utility.R_SetStreamingContext("cSessionId", .CSESSION_ID)
                R_Utility.R_SetStreamingContext("cScheduleId", .CSCHEDULE_ID)
                R_Utility.R_SetStreamingContext("cFunctionId", .CFUNCTION_ID)
                R_Utility.R_SetStreamingContext("cUserId", _CUSERID)
            End With

            loRtn = loServiceStream.GetItemScheduleList()
            loStreaming = R_StreamUtility(Of CSM00511ItemScheduleGridDTO).ReadFromMessage(loRtn)

            Dim loTempEntity = From item In loStreaming

            'loListEntity = R_Utility.R_ConvertCollectionToCollection(Of CSM00511ItemScheduleGridDTO, CSM00511ItemDTO)(loStreaming)

            For Each loDto As CSM00511ItemScheduleGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New CSM00511ItemDTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                                  ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                                ._CVERSION = loDto.CVERSION,
                                                               ._CPROJECT_ID = loDto.CPROJECT_ID,
                                                               ._CSESSION_ID = loDto.CSESSION_ID,
                                                               ._CSCHEDULE_ID = loDto.CSCHEDULE_ID,
                                                               ._CFUNCTION_ID = loDto.CFUNCTION_ID,
                                                               ._CUSER_ID = loDto.CUSER_ID,
                                                               ._CUSER_NAME = loDto.CUSER_NAME,
                                                               ._CLOCATION_ID = loDto.CLOCATION_ID,
                                                               ._CATTRIBUTE_GROUP = loDto.CATTRIBUTE_GROUP,
                                                               ._CATTRIBUTE_ID = loDto.CATTRIBUTE_ID,
                                                               ._CITEM_ID = loDto.CITEM_ID,
                                                               ._CITEM_NAME = loDto.CITEM_NAME,
                                                               ._NMANDAYS = loDto.NMANDAYS,
                                                               ._CPLAN_START_DATE = loDto.CPLAN_START_DATE,
                                                               ._CPLAN_END_DATE = loDto.CPLAN_END_DATE,
                                                               ._DPLAN_START_DATE = StrToDate(loDto.CPLAN_START_DATE),
                                                               ._DPLAN_END_DATE = StrToDate(loDto.CPLAN_END_DATE),
                                                               ._NREVISED_MANDAYS = loDto.NREVISED_MANDAYS,
                                                               ._CREVISED_START_DATE = loDto.CREVISED_START_DATE,
                                                               ._CREVISED_END_DATE = loDto.CREVISED_END_DATE,
                                                               ._DREVISED_START_DATE = StrToDate(loDto.CREVISED_START_DATE),
                                                               ._DREVISED_END_DATE = StrToDate(loDto.CREVISED_END_DATE),
                                                               ._CREASSIGNMENT_ID = loDto.CREASSIGNMENT_ID,
                                                               ._CREASSIGNMENT_NAME = loDto.CREASSIGNMENT_NAME,
                                                               ._CSTATUS = loDto.CSTATUS,
                                                               ._CGANTT_SEQUENCE = loDto.CGANTT_SEQUENCE,
                                                               ._LREVISION = Not (loDto.CREVISED_START_DATE.Trim.Equals("")),
                                                               ._LACTUAL_START = loDto.LACTUAL_START,
                                                               ._LACTUAL_END = loDto.LACTUAL_END,
                                                               ._LMANAGER = loDto.LMANAGER,
                                                                  ._CCREATE_BY = loDto.CCREATE_BY,
                                                                  ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                                  ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                                  ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvItemSchedule_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvItemSchedule.R_ServiceGetRecord
        Dim loService As CSM00511AssignmentServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00511AssignmentService, CSM00511AssignmentServiceClient)(e_ServiceClientType.RegularService, C_AssignmentServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New CSM00511ItemDTO With {._CCOMPANY_ID = _CCOMPID,
                                                                                     ._CAPPS_CODE = _CAPPSCODE,
                                                                                     ._CVERSION = _CVERSION,
                                                                                     ._CPROJECT_ID = _CPROJECTID,
                                                                                     ._CSESSION_ID = _CSESSIONID,
                                                                                 ._CSCHEDULE_ID = _CSCHEDULEID,
                                                                                 ._CFUNCTION_ID = CType(bsGvItemSchedule.Current, CSM00511ItemDTO)._CFUNCTION_ID,
                                                                                 ._CATTRIBUTE_GROUP = CType(bsGvItemSchedule.Current, CSM00511ItemDTO)._CATTRIBUTE_GROUP,
                                                                                 ._CATTRIBUTE_ID = CType(bsGvItemSchedule.Current, CSM00511ItemDTO)._CATTRIBUTE_ID,
                                                                                     ._CITEM_ID = CType(bsGvItemSchedule.Current, CSM00511ItemDTO)._CITEM_ID,
                                                                                 ._CUSER_ID = _CUSERID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvItemSchedule_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvItemSchedule.R_ServiceSave
        Dim loService As CSM00511AssignmentServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00511AssignmentService, CSM00511AssignmentServiceClient)(e_ServiceClientType.RegularService, C_AssignmentServiceName)
        Dim loEx As New R_Exception
        Dim llEnableEditPlan As Boolean
        Dim llEnableReviseStart As Boolean
        Dim llEnableReviseEnd As Boolean

        Try
            With CType(poEntity, CSM00511ItemDTO)
                llEnableEditPlan = (._CSTATUS = "PLAN") And _LMANAGER
                llEnableReviseStart = Not (._CSTATUS = "PLAN") And Not ._LACTUAL_START And ._CUSER_ID = _CUSERID
                llEnableReviseEnd = Not (._CSTATUS = "PLAN") And Not ._LACTUAL_END And ._CUSER_ID = _CUSERID
                If llEnableEditPlan Then
                    ._CREASSIGNMENT_ID = ._CUSER_ID
                    If ._DPLAN_START_DATE IsNot Nothing Then
                        ._CPLAN_START_DATE = ._DPLAN_START_DATE.Value.ToString("yyyyMMdd")
                    End If
                End If
                If llEnableReviseStart Then
                    If ._DREVISED_START_DATE IsNot Nothing Then
                        ._CREVISED_START_DATE = ._DREVISED_START_DATE.Value.ToString("yyyyMMdd")
                    End If
                End If
                If llEnableReviseEnd Then
                    If ._DREVISED_END_DATE IsNot Nothing Then
                        ._CREVISED_END_DATE = ._DREVISED_END_DATE.Value.ToString("yyyyMMdd")
                    End If
                End If
                poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
            End With
            With CType(poEntityResult, CSM00511ItemDTO)
                ._DPLAN_START_DATE = StrToDate(._CPLAN_START_DATE)
                ._DPLAN_END_DATE = StrToDate(._CPLAN_END_DATE)
                ._DREVISED_START_DATE = StrToDate(._CREVISED_START_DATE)
                ._DREVISED_END_DATE = StrToDate(._CREVISED_END_DATE)
                ._LMANAGER = _LMANAGER
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvItemSchedule_R_SetEditGridColumn(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, poGridColumnCollection As Telerik.WinControls.UI.GridViewColumnCollection) Handles gvItemSchedule.R_SetEditGridColumn
        Dim llEnableEditPlan As Boolean
        Dim llEnableReviseStart As Boolean
        Dim llEnableReviseEnd As Boolean
        Dim llEnableReassign As Boolean

        With CType(poEntity, CSM00511ItemDTO)
            llEnableEditPlan = (._CSTATUS = "PLAN") And _LMANAGER
            llEnableReassign = Not (._CSTATUS = "PLAN") And Not (._CSTATUS = "DONE") 'And _LMANAGER
            llEnableReviseStart = Not (._CSTATUS = "PLAN") And Not ._LACTUAL_START And ._CREASSIGNMENT_ID = _CUSERID
            llEnableReviseEnd = Not (._CSTATUS = "PLAN") And Not ._LACTUAL_END And ._CREASSIGNMENT_ID = _CUSERID
        End With

        CType(poGridColumnCollection("_CUSER_NAME"), R_GridViewLookUpColumn).ReadOnly = Not llEnableEditPlan
        CType(poGridColumnCollection("_CREASSIGNMENT_NAME"), R_GridViewLookUpColumn).ReadOnly = Not llEnableReassign
        CType(poGridColumnCollection("_CLOCATION_ID"), R_GridViewComboBoxColumn).ReadOnly = Not llEnableEditPlan
        CType(poGridColumnCollection("_NMANDAYS"), R_GridViewDecimalColumn).ReadOnly = Not llEnableEditPlan
        CType(poGridColumnCollection("_DPLAN_START_DATE"), R_GridViewDateTimeColumn).ReadOnly = Not llEnableEditPlan
        CType(poGridColumnCollection("_DREVISED_START_DATE"), R_GridViewDateTimeColumn).ReadOnly = Not llEnableReviseStart
        CType(poGridColumnCollection("_DREVISED_END_DATE"), R_GridViewDateTimeColumn).ReadOnly = Not llEnableReviseEnd
    End Sub

    Private Sub gvItemSchedule_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvItemSchedule.R_Validation
        Dim loEx As New R_Exception()

        Try
            With poGridCellCollection
                If Not _LMANAGER And Not .Item("_CREASSIGNMENT_ID").Value.Equals(_CUSERID) Then
                    loEx.Add("CSM00510_01", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00510_01"))
                    plCancel = True
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " OTHER "

    Private Sub btnStart_Click(sender As Object, e As System.EventArgs) Handles btnStart.Click
        Dim loException As New R_Exception
        Dim loService As CSM00511ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00511Service, CSM00511ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loTableKey As New CSM00500ItemKeyDTO

        Try
            loFilterParam.OFILTER_KEY.CSCHEDULE_ID = _CSCHEDULEID
            loService.StartSchedule(loFilterParam.OFILTER_KEY)
            With loTableKey
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = _CAPPSCODE
                .CVERSION = _CVERSION
                .CPROJECT_ID = _CPROJECTID
                .CSESSION_ID = _CSESSIONID
                .CSCHEDULE_ID = _CSCHEDULEID
                .CFUNCTION_ID = _CFUNCTIONID
            End With
            RefreshAssignmentGrid(loTableKey)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        If loException.Haserror Then
            Me.R_DisplayException(loException)
        End If
    End Sub

    Private Sub btnClose_Click(sender As Object, e As System.EventArgs) Handles btnClose.Click
        Dim loException As New R_Exception
        Dim loService As CSM00511ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00511Service, CSM00511ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)

        Try
            loFilterParam.OFILTER_KEY.CSCHEDULE_ID = CType(bsGvSchedule.Current, CSM00511ScheduleDTO)._CSCHEDULE_ID
            loService.CloseSchedule(loFilterParam.OFILTER_KEY)
            RefreshGrids(loFilterParam.OFILTER_KEY)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        If loException.Haserror Then
            Me.R_DisplayException(loException)
        End If
    End Sub

#End Region


End Class
