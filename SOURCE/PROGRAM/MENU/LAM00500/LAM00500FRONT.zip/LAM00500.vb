﻿Imports R_FrontEnd
Imports LAM00500Front.LAM00500ServiceRef
Imports LAM00500Front.LAM00500StreamingServiceRef
Imports R_Common
Imports System.ServiceModel.Channels
Imports ClientHelper
Imports LAM00500FrontResources

Public Class LAM00500

#Region " VARIABLE "
    Dim C_ServiceName As String = "LAM00500Service/LAM00500Service.svc"
    Dim C_ServiceNameStream As String = "LAM00500Service/LAM00500StreamingService.svc"
    Dim _CUSERID As String
#End Region

    Private Sub LAM00500_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Try
            _CUSERID = U_GlobalVar.UserId

            gvCustGrp.R_RefreshGrid("")
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

    Private Sub gvCustGrp_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvCustGrp.R_Saving
        With CType(poEntity, LAM00500DTO)
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With
    End Sub

    Private Sub gvCustGrp_R_ServiceDelete(poEntity As Object) Handles gvCustGrp.R_ServiceDelete
        Dim loService As LAM00500ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00500Service, LAM00500ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvCustGrp_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvCustGrp.R_ServiceGetListRecord
        Dim loServiceStream As LAM00500StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00500StreamingService, LAM00500StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of LAM00500GridDTO)
        Dim loListEntity As New List(Of LAM00500DTO)

        Try

            loRtn = loServiceStream.GetCustGrpList()
            loStreaming = R_StreamUtility(Of LAM00500GridDTO).ReadFromMessage(loRtn)

            For Each loDto As LAM00500GridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New LAM00500DTO With {._CCUSTOMER_GROUP = loDto.CCUSTOMER_GROUP,
                                                           ._CCUSTOMER_GROUP_NAME = loDto.CCUSTOMER_GROUP_NAME,
                                                           ._CCREATE_BY = loDto.CCREATE_BY,
                                                           ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                           ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                           ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvCustGrp_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvCustGrp.R_ServiceGetRecord
        Dim loService As LAM00500ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00500Service, LAM00500ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New LAM00500DTO With {._CCUSTOMER_GROUP = CType(bsGvCustGrp.Current, LAM00500DTO)._CCUSTOMER_GROUP})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvCustGrp_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvCustGrp.R_ServiceSave
        Dim loService As LAM00500ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00500Service, LAM00500ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvCustGrp_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvCustGrp.R_Validation
        Dim loEx As New R_Exception()

        Try
            pcError = ""
            With poGridCellCollection
                If String.IsNullOrWhiteSpace(.Item(0).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS001")
                    loEx.Add("PS001", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS001"))
                    plCancel = True
                End If

                If String.IsNullOrWhiteSpace(.Item(1).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS002")
                    loEx.Add("PS002", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS002"))
                    plCancel = True
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub LAM00500_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub
End Class
