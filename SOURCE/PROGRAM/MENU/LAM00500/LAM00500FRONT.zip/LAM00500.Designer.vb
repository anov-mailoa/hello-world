﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LAM00500
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn2 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Me.gvCustGrp = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvCustGrp = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridCustGrp = New R_FrontEnd.R_ConductorGrid(Me.components)
        CType(Me.gvCustGrp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvCustGrp.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvCustGrp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridCustGrp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'gvCustGrp
        '
        Me.gvCustGrp.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvCustGrp.EnableFastScrolling = True
        Me.gvCustGrp.Location = New System.Drawing.Point(0, 0)
        '
        '
        '
        Me.gvCustGrp.MasterTemplate.AutoGenerateColumns = False
        Me.gvCustGrp.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn1.FieldName = "_CCUSTOMER_GROUP"
        R_GridViewTextBoxColumn1.HeaderText = "_CCUSTOMER_GROUP"
        R_GridViewTextBoxColumn1.Name = "_CCUSTOMER_GROUP"
        R_GridViewTextBoxColumn1.R_EnableADD = True
        R_GridViewTextBoxColumn1.R_ResourceId = "_CCUSTOMER_GROUP"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 211
        R_GridViewTextBoxColumn2.FieldName = "_CCUSTOMER_GROUP_NAME"
        R_GridViewTextBoxColumn2.HeaderText = "_CCUSTOMER_GROUP_NAME"
        R_GridViewTextBoxColumn2.Name = "_CCUSTOMER_GROUP_NAME"
        R_GridViewTextBoxColumn2.R_EnableADD = True
        R_GridViewTextBoxColumn2.R_EnableEDIT = True
        R_GridViewTextBoxColumn2.R_ResourceId = "_CCUSTOMER_GROUP_NAME"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 211
        R_GridViewTextBoxColumn3.FieldName = "_CUPDATE_BY"
        R_GridViewTextBoxColumn3.HeaderText = "_CUPDATE_BY"
        R_GridViewTextBoxColumn3.Name = "_CUPDATE_BY"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CUPDATE_BY"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 211
        R_GridViewDateTimeColumn1.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn1.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn1.FieldName = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn1.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn1.HeaderText = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.Name = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.R_ResourceId = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.Width = 211
        R_GridViewTextBoxColumn4.FieldName = "_CCREATE_BY"
        R_GridViewTextBoxColumn4.HeaderText = "_CCREATE_BY"
        R_GridViewTextBoxColumn4.Name = "_CCREATE_BY"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CCREATE_BY"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 211
        R_GridViewDateTimeColumn2.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn2.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn2.FieldName = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn2.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn2.HeaderText = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.Name = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.R_ResourceId = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.Width = 207
        Me.gvCustGrp.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewDateTimeColumn1, R_GridViewTextBoxColumn4, R_GridViewDateTimeColumn2})
        Me.gvCustGrp.MasterTemplate.DataSource = Me.bsGvCustGrp
        Me.gvCustGrp.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvCustGrp.MasterTemplate.EnableFiltering = True
        Me.gvCustGrp.MasterTemplate.EnableGrouping = False
        Me.gvCustGrp.MasterTemplate.ShowFilteringRow = False
        Me.gvCustGrp.MasterTemplate.ShowGroupedColumns = True
        Me.gvCustGrp.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvCustGrp.Name = "gvCustGrp"
        Me.gvCustGrp.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvCustGrp.R_ConductorGridSource = Me.conGridCustGrp
        Me.gvCustGrp.R_ConductorSource = Nothing
        Me.gvCustGrp.R_DataAdded = False
        Me.gvCustGrp.R_NewRowText = Nothing
        Me.gvCustGrp.ShowHeaderCellButtons = True
        Me.gvCustGrp.Size = New System.Drawing.Size(1277, 575)
        Me.gvCustGrp.TabIndex = 0
        Me.gvCustGrp.Text = "R_RadGridView1"
        '
        'bsGvCustGrp
        '
        Me.bsGvCustGrp.DataSource = GetType(LAM00500Front.LAM00500ServiceRef.LAM00500DTO)
        '
        'conGridCustGrp
        '
        Me.conGridCustGrp.R_ConductorParent = Nothing
        Me.conGridCustGrp.R_IsHeader = True
        Me.conGridCustGrp.R_RadGroupBox = Nothing
        '
        'LAM00500
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.gvCustGrp)
        Me.Name = "LAM00500"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.gvCustGrp.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvCustGrp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvCustGrp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridCustGrp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents gvCustGrp As R_FrontEnd.R_RadGridView
    Friend WithEvents bsGvCustGrp As System.Windows.Forms.BindingSource
    Friend WithEvents conGridCustGrp As R_FrontEnd.R_ConductorGrid

End Class
