﻿Imports R_Common
Imports R_BackEnd
Imports System.Data.Common
Imports ServerHelper.General
Imports System.Transactions

Public Class LAM00500Cls
    Inherits R_BusinessObject(Of LAM00500DTO)

    Protected Overrides Sub R_Deleting(poEntity As LAM00500DTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loResult As LAM00500DTO

        Try
            loConn = loDb.GetConnection()

            ' validasi
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "LAM_CUSTOMER (NOLOCK) "
            lcQuery += "WHERE CCUSTOMER_GROUP = '{0}' "
            lcQuery = String.Format(lcQuery, poEntity.CCUSTOMER_GROUP)

            loResult = loDb.SqlExecObjectQuery(Of LAM00500DTO)(lcQuery, loConn, False).FirstOrDefault
            If loResult IsNot Nothing Then
                Throw New Exception("Customer Group " + poEntity.CCUSTOMER_GROUP.Trim + " has already been used in customer master.")
            End If

            Using TransScope As New TransactionScope(TransactionScopeOption.Required)
                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "LAM_CUSTOMER_GROUP "
                lcQuery += "WHERE CCUSTOMER_GROUP = '{0}' "
                lcQuery = String.Format(lcQuery, poEntity.CCUSTOMER_GROUP)

                loDb.SqlExecNonQuery(lcQuery, loConn, True)

                TransScope.Complete()
            End Using

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As LAM00500DTO) As LAM00500DTO
        Dim lcQuery As String
        Dim loResult As LAM00500DTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "LAM_CUSTOMER_GROUP (NOLOCK) "
            lcQuery += "WHERE CCUSTOMER_GROUP = '{0}' "
            lcQuery = String.Format(lcQuery, poEntity.CCUSTOMER_GROUP)

            loResult = loDb.SqlExecObjectQuery(Of LAM00500DTO)(lcQuery).FirstOrDefault
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult

    End Function

    Protected Overrides Sub R_Saving(poNewEntity As LAM00500DTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As LAM00500DTO

        Try
            loConn = loDb.GetConnection()

            If poCRUDMode = eCRUDMode.AddMode Then
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "LAM_CUSTOMER_GROUP (NOLOCK) "
                lcQuery += "WHERE CCUSTOMER_GROUP = '{0}' "
                lcQuery = String.Format(lcQuery, poNewEntity.CCUSTOMER_GROUP)

                loResult = loDb.SqlExecObjectQuery(Of LAM00500DTO)(lcQuery, loConn, True).FirstOrDefault
                If loResult IsNot Nothing Then
                    Throw New Exception("Customer Group " + poNewEntity.CCUSTOMER_GROUP.Trim + " is already exist")
                End If

                With poNewEntity
                    .CCREATE_BY = .CUPDATE_BY
                    .DUPDATE_DATE = Now
                    .DCREATE_DATE = Now
                End With

                lcQuery = "INSERT INTO LAM_CUSTOMER_GROUP ("
                lcQuery += "CCUSTOMER_GROUP, "
                lcQuery += "CCUSTOMER_GROUP_NAME, "
                lcQuery += "CUPDATE_BY, "
                lcQuery += "DUPDATE_DATE, "
                lcQuery += "CCREATE_BY, "
                lcQuery += "DCREATE_DATE) "
                lcQuery += "VALUES ('{0}', '{1}', '{2}', {3}, '{4}', {5}) "
                lcQuery = String.Format(lcQuery,
                poNewEntity.CCUSTOMER_GROUP,
                poNewEntity.CCUSTOMER_GROUP_NAME,
                poNewEntity.CUPDATE_BY,
                getDate(poNewEntity.DUPDATE_DATE),
                poNewEntity.CCREATE_BY,
                getDate(poNewEntity.DCREATE_DATE))

                loDb.SqlExecNonQuery(lcQuery)

            ElseIf poCRUDMode = eCRUDMode.EditMode Then



                lcQuery = "UPDATE LAM_CUSTOMER "
                lcQuery += "SET "
                lcQuery += "CCUSTOMER_GROUP_NAME = '{1}', "
                lcQuery += "CUPDATE_BY = '{2}', "
                lcQuery += "DUPDATE_DATE = {3} "
                lcQuery += "WHERE "
                lcQuery += "CCUSTOMER_GROUP = '{0}', "
                lcQuery = String.Format(lcQuery,
                poNewEntity.CCUSTOMER_GROUP,
                poNewEntity.CCUSTOMER_GROUP_NAME,
                poNewEntity.CUPDATE_BY,
                getDate(poNewEntity.DUPDATE_DATE))

                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End If

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

    Public Function getCustGrpList() As List(Of LAM00500GridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of LAM00500GridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "LAM_CUSTOMER_GROUP (NOLOCK) "

            loResult = loDb.SqlExecObjectQuery(Of LAM00500GridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function
End Class
