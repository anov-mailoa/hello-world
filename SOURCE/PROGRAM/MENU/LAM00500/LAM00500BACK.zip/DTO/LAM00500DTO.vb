﻿Imports R_BackEnd

<Serializable()> _
Public Class LAM00500DTO
    Inherits R_DTOBase

    Public Property CCUSTOMER_GROUP As String
    Public Property CCUSTOMER_GROUP_NAME As String
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)
    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)
End Class
