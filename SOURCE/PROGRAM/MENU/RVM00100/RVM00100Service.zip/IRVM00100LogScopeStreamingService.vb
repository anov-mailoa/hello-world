﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports RVM00100Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IRVM00100LogScopeStreamingService" in both code and config file together.
<ServiceContract()>
Public Interface IRVM00100LogScopeStreamingService

    <OperationContract(Action:="getLogScope", ReplyAction:="getLogScope")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetLogScope() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of RVM00100LogScopeGridDTO), ByVal poPar2 As RVM00100KeyDTO)


End Interface
