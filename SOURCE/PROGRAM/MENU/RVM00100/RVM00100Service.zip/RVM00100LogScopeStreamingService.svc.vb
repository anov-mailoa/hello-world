﻿Imports R_Common
Imports RVM00100Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "RVM00100LogScopeStreamingService" in code, svc and config file together.
Public Class RVM00100LogScopeStreamingService
    Implements IRVM00100LogScopeStreamingService

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of RVM00100Back.RVM00100LogScopeGridDTO), poPar2 As RVM00100KeyDTO) Implements IRVM00100LogScopeStreamingService.Dummy

    End Sub

    Public Function GetLogScope() As System.ServiceModel.Channels.Message Implements IRVM00100LogScopeStreamingService.GetLogScope
        Dim loException As New R_Exception
        Dim loCls As New RVM00100LogScopeCls
        Dim loRtnTemp As List(Of RVM00100LogScopeGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New RVM00100KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
            End With

            loRtnTemp = loCls.GetLogScope(loTableKey)

            loRtn = R_StreamUtility(Of RVM00100LogScopeGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getLogScope")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
