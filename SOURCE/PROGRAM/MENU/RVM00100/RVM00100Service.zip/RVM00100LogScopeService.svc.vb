﻿Imports R_Common
Imports RVM00100Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "RVM00100LogScopeService" in code, svc and config file together.
Public Class RVM00100LogScopeService
    Implements IRVM00100LogScopeService

    Public Sub Svc_R_Delete(poEntity As RVM00100Back.RVM00100LogScopeDTO) Implements R_BackEnd.R_IServicebase(Of RVM00100Back.RVM00100LogScopeDTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New RVM00100LogScopeCls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As RVM00100Back.RVM00100LogScopeDTO) As RVM00100Back.RVM00100LogScopeDTO Implements R_BackEnd.R_IServicebase(Of RVM00100Back.RVM00100LogScopeDTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New RVM00100LogScopeCls
        Dim loRtn As RVM00100LogScopeDTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As RVM00100Back.RVM00100LogScopeDTO, poCRUDMode As R_Common.eCRUDMode) As RVM00100Back.RVM00100LogScopeDTO Implements R_BackEnd.R_IServicebase(Of RVM00100Back.RVM00100LogScopeDTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New RVM00100LogScopeCls
        Dim loRtn As RVM00100LogScopeDTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
