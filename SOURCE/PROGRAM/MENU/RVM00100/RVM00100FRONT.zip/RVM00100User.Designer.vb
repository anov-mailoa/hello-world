﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RVM00100User
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim R_GridViewCheckBoxSelectColumn1 As R_FrontEnd.R_GridViewCheckBoxSelectColumn = New R_FrontEnd.R_GridViewCheckBoxSelectColumn()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnDeleteUser = New R_FrontEnd.R_RadButton()
        Me.btnProcess = New R_FrontEnd.R_RadButton()
        Me.txtApplication = New R_FrontEnd.R_RadTextBox()
        Me.lblApplication = New R_FrontEnd.R_RadLabel()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.gvAvailableItems = New R_FrontEnd.R_RadGridView()
        Me.bsGvAvailableItems = New System.Windows.Forms.BindingSource()
        Me.conAvailable = New R_FrontEnd.R_ConductorGrid()
        Me.lblAvailableItems = New R_FrontEnd.R_RadLabel()
        Me.lblSelectedItems = New R_FrontEnd.R_RadLabel()
        Me.gvSelectedItems = New R_FrontEnd.R_RadGridView()
        Me.bsGvSelectedItems = New System.Windows.Forms.BindingSource()
        Me.bwRVM00100 = New System.ComponentModel.BackgroundWorker()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.btnDeleteUser, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnProcess, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.gvAvailableItems, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvAvailableItems.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvAvailableItems, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conAvailable, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblAvailableItems, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblSelectedItems, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvSelectedItems, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvSelectedItems.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvSelectedItems, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.SplitContainer1, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnDeleteUser)
        Me.Panel1.Controls.Add(Me.btnProcess)
        Me.Panel1.Controls.Add(Me.txtApplication)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 30)
        Me.Panel1.TabIndex = 0
        '
        'btnDeleteUser
        '
        Me.btnDeleteUser.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDeleteUser.Location = New System.Drawing.Point(1158, 3)
        Me.btnDeleteUser.Name = "btnDeleteUser"
        Me.btnDeleteUser.R_ConductorGridSource = Nothing
        Me.btnDeleteUser.R_ConductorSource = Nothing
        Me.btnDeleteUser.R_DescriptionId = Nothing
        Me.btnDeleteUser.R_ResourceId = "btnDeleteUser"
        Me.btnDeleteUser.Size = New System.Drawing.Size(110, 24)
        Me.btnDeleteUser.TabIndex = 34
        Me.btnDeleteUser.Text = "R_RadButton1"
        '
        'btnProcess
        '
        Me.btnProcess.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnProcess.Location = New System.Drawing.Point(1042, 3)
        Me.btnProcess.Name = "btnProcess"
        Me.btnProcess.R_ConductorGridSource = Nothing
        Me.btnProcess.R_ConductorSource = Nothing
        Me.btnProcess.R_DescriptionId = Nothing
        Me.btnProcess.R_ResourceId = "btnProcess"
        Me.btnProcess.Size = New System.Drawing.Size(110, 24)
        Me.btnProcess.TabIndex = 33
        Me.btnProcess.Text = "R_RadButton1"
        '
        'txtApplication
        '
        Me.txtApplication.Location = New System.Drawing.Point(116, 5)
        Me.txtApplication.Name = "txtApplication"
        Me.txtApplication.R_ConductorGridSource = Nothing
        Me.txtApplication.R_ConductorSource = Nothing
        Me.txtApplication.R_UDT = Nothing
        Me.txtApplication.ReadOnly = True
        Me.txtApplication.Size = New System.Drawing.Size(333, 20)
        Me.txtApplication.TabIndex = 32
        Me.txtApplication.TabStop = False
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(10, 6)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "_CAPPS_NAME"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 30
        Me.lblApplication.Text = "Application..."
        '
        'SplitContainer1
        '
        Me.SplitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(3, 39)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.gvAvailableItems)
        Me.SplitContainer1.Panel1.Controls.Add(Me.lblAvailableItems)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.lblSelectedItems)
        Me.SplitContainer1.Panel2.Controls.Add(Me.gvSelectedItems)
        Me.SplitContainer1.Size = New System.Drawing.Size(1271, 533)
        Me.SplitContainer1.SplitterDistance = 629
        Me.SplitContainer1.TabIndex = 1
        '
        'gvAvailableItems
        '
        Me.gvAvailableItems.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gvAvailableItems.EnableFastScrolling = True
        Me.gvAvailableItems.Location = New System.Drawing.Point(3, 27)
        '
        '
        '
        Me.gvAvailableItems.MasterTemplate.AllowAddNewRow = False
        Me.gvAvailableItems.MasterTemplate.AllowDeleteRow = False
        Me.gvAvailableItems.MasterTemplate.AutoGenerateColumns = False
        R_GridViewCheckBoxSelectColumn1.EditMode = Telerik.WinControls.UI.EditMode.OnValueChange
        R_GridViewCheckBoxSelectColumn1.EnableHeaderCheckBox = True
        R_GridViewCheckBoxSelectColumn1.FieldName = "LSELECT"
        R_GridViewCheckBoxSelectColumn1.HeaderText = ""
        R_GridViewCheckBoxSelectColumn1.Name = "_LSELECT"
        R_GridViewCheckBoxSelectColumn1.R_EnableEDIT = True
        R_GridViewCheckBoxSelectColumn1.R_ResourceId = "_"
        R_GridViewCheckBoxSelectColumn1.Width = 33
        R_GridViewTextBoxColumn1.FieldName = "CUSER_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CUSER_ID"
        R_GridViewTextBoxColumn1.Name = "_CUSER_ID"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CUSER_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.ReadOnly = True
        R_GridViewTextBoxColumn1.Width = 76
        R_GridViewTextBoxColumn2.FieldName = "CUSER_NAME"
        R_GridViewTextBoxColumn2.HeaderText = "_CUSER_NAME"
        R_GridViewTextBoxColumn2.Name = "_CUSER_NAME"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CUSER_NAME"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.ReadOnly = True
        R_GridViewTextBoxColumn2.Width = 97
        Me.gvAvailableItems.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewCheckBoxSelectColumn1, R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2})
        Me.gvAvailableItems.MasterTemplate.DataSource = Me.bsGvAvailableItems
        Me.gvAvailableItems.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvAvailableItems.MasterTemplate.EnableFiltering = True
        Me.gvAvailableItems.MasterTemplate.EnableGrouping = False
        Me.gvAvailableItems.MasterTemplate.ShowFilteringRow = False
        Me.gvAvailableItems.MasterTemplate.ShowGroupedColumns = True
        Me.gvAvailableItems.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvAvailableItems.Name = "gvAvailableItems"
        Me.gvAvailableItems.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvAvailableItems.R_ConductorGridSource = Me.conAvailable
        Me.gvAvailableItems.R_ConductorSource = Nothing
        Me.gvAvailableItems.R_DataAdded = False
        Me.gvAvailableItems.R_GridType = R_FrontEnd.R_eGridType.BatchUpdating
        Me.gvAvailableItems.R_NewRowText = Nothing
        Me.gvAvailableItems.ShowHeaderCellButtons = True
        Me.gvAvailableItems.Size = New System.Drawing.Size(619, 499)
        Me.gvAvailableItems.TabIndex = 1
        Me.gvAvailableItems.Text = "R_RadGridView1"
        '
        'bsGvAvailableItems
        '
        Me.bsGvAvailableItems.DataSource = GetType(RVM00100Front.RVM00100UserStreamingServiceRef.RVM00100UserGridDTO)
        '
        'conAvailable
        '
        Me.conAvailable.R_ConductorParent = Nothing
        Me.conAvailable.R_IsHeader = True
        Me.conAvailable.R_RadGroupBox = Nothing
        '
        'lblAvailableItems
        '
        Me.lblAvailableItems.AutoSize = False
        Me.lblAvailableItems.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblAvailableItems.Location = New System.Drawing.Point(10, 3)
        Me.lblAvailableItems.Name = "lblAvailableItems"
        Me.lblAvailableItems.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblAvailableItems.R_ResourceId = "lblAvailableItems"
        Me.lblAvailableItems.Size = New System.Drawing.Size(100, 18)
        Me.lblAvailableItems.TabIndex = 0
        Me.lblAvailableItems.Text = "R_RadLabel1"
        '
        'lblSelectedItems
        '
        Me.lblSelectedItems.AutoSize = False
        Me.lblSelectedItems.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblSelectedItems.Location = New System.Drawing.Point(3, 3)
        Me.lblSelectedItems.Name = "lblSelectedItems"
        Me.lblSelectedItems.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblSelectedItems.R_ResourceId = "lblSelectedItems"
        Me.lblSelectedItems.Size = New System.Drawing.Size(100, 18)
        Me.lblSelectedItems.TabIndex = 3
        Me.lblSelectedItems.Text = "R_RadLabel2"
        '
        'gvSelectedItems
        '
        Me.gvSelectedItems.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gvSelectedItems.EnableFastScrolling = True
        Me.gvSelectedItems.Location = New System.Drawing.Point(3, 27)
        '
        '
        '
        Me.gvSelectedItems.MasterTemplate.AllowAddNewRow = False
        Me.gvSelectedItems.MasterTemplate.AllowDeleteRow = False
        Me.gvSelectedItems.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn3.FieldName = "CUSER_ID"
        R_GridViewTextBoxColumn3.HeaderText = "_CUSER_ID"
        R_GridViewTextBoxColumn3.Name = "_CUSER_ID"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CUSER_ID"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 76
        R_GridViewTextBoxColumn4.FieldName = "CUSER_NAME"
        R_GridViewTextBoxColumn4.HeaderText = "_CUSER_NAME"
        R_GridViewTextBoxColumn4.Name = "_CUSER_NAME"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CUSER_NAME"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 97
        Me.gvSelectedItems.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn3, R_GridViewTextBoxColumn4})
        Me.gvSelectedItems.MasterTemplate.DataSource = Me.bsGvSelectedItems
        Me.gvSelectedItems.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvSelectedItems.MasterTemplate.EnableFiltering = True
        Me.gvSelectedItems.MasterTemplate.EnableGrouping = False
        Me.gvSelectedItems.MasterTemplate.ShowFilteringRow = False
        Me.gvSelectedItems.MasterTemplate.ShowGroupedColumns = True
        Me.gvSelectedItems.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvSelectedItems.Name = "gvSelectedItems"
        Me.gvSelectedItems.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvSelectedItems.R_ConductorGridSource = Nothing
        Me.gvSelectedItems.R_ConductorSource = Nothing
        Me.gvSelectedItems.R_DataAdded = False
        Me.gvSelectedItems.R_NewRowText = Nothing
        Me.gvSelectedItems.ReadOnly = True
        Me.gvSelectedItems.ShowHeaderCellButtons = True
        Me.gvSelectedItems.Size = New System.Drawing.Size(630, 499)
        Me.gvSelectedItems.TabIndex = 2
        Me.gvSelectedItems.Text = "R_RadGridView2"
        '
        'bsGvSelectedItems
        '
        Me.bsGvSelectedItems.DataSource = GetType(RVM00100Front.RVM00100UserStreamingServiceRef.RVM00100UserGridDTO)
        '
        'RVM00100User
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "RVM00100User"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "Add User"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.btnDeleteUser, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnProcess, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.gvAvailableItems.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvAvailableItems, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvAvailableItems, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conAvailable, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblAvailableItems, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblSelectedItems, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvSelectedItems.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvSelectedItems, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvSelectedItems, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents txtApplication As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents lblAvailableItems As R_FrontEnd.R_RadLabel
    Friend WithEvents lblSelectedItems As R_FrontEnd.R_RadLabel
    Friend WithEvents gvSelectedItems As R_FrontEnd.R_RadGridView
    Friend WithEvents bsGvAvailableItems As System.Windows.Forms.BindingSource
    Friend WithEvents bsGvSelectedItems As System.Windows.Forms.BindingSource
    Friend WithEvents bwRVM00100 As System.ComponentModel.BackgroundWorker
    Friend WithEvents gvAvailableItems As R_FrontEnd.R_RadGridView
    Friend WithEvents btnProcess As R_FrontEnd.R_RadButton
    Friend WithEvents conAvailable As R_FrontEnd.R_ConductorGrid
    Friend WithEvents btnDeleteUser As R_FrontEnd.R_RadButton

End Class
