﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RVM00100
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn1 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewComboBoxColumn1 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Dim R_GridViewComboBoxColumn2 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Me.bsActivationType = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridApps = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.gvApps = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.preUser = New R_FrontEnd.R_PredefinedDock(Me.components)
        Me.preProvider = New R_FrontEnd.R_PredefinedDock(Me.components)
        Me.preLogScope = New R_FrontEnd.R_PredefinedDock(Me.components)
        Me.bsApplicationType = New System.Windows.Forms.BindingSource(Me.components)
        CType(Me.bsActivationType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvApps.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvApps, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.bsApplicationType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'bsActivationType
        '
        Me.bsActivationType.DataSource = GetType(RVM00100Front.RVM00100ServiceRef.RVM00100ActivationTypeComboDTO)
        '
        'conGridApps
        '
        Me.conGridApps.R_ConductorParent = Nothing
        Me.conGridApps.R_IsHeader = True
        Me.conGridApps.R_RadGroupBox = Nothing
        '
        'gvApps
        '
        Me.gvApps.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvApps.EnableFastScrolling = True
        Me.gvApps.Location = New System.Drawing.Point(3, 3)
        '
        '
        '
        Me.gvApps.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn1.FieldName = "_CAPPS_CODE"
        R_GridViewTextBoxColumn1.HeaderText = "_CAPPS_CODE"
        R_GridViewTextBoxColumn1.Name = "_CAPPS_CODE"
        R_GridViewTextBoxColumn1.R_EnableADD = True
        R_GridViewTextBoxColumn1.R_ResourceId = "_CAPPS_CODE"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 94
        R_GridViewTextBoxColumn2.FieldName = "_CAPPS_NAME"
        R_GridViewTextBoxColumn2.HeaderText = "_CAPPS_NAME"
        R_GridViewTextBoxColumn2.Name = "_CAPPS_NAME"
        R_GridViewTextBoxColumn2.R_EnableADD = True
        R_GridViewTextBoxColumn2.R_EnableEDIT = True
        R_GridViewTextBoxColumn2.R_ResourceId = "_CAPPS_NAME"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 96
        R_GridViewTextBoxColumn3.FieldName = "_CDESCRIPTION"
        R_GridViewTextBoxColumn3.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxColumn3.Name = "_CDESCRIPTION"
        R_GridViewTextBoxColumn3.R_EnableADD = True
        R_GridViewTextBoxColumn3.R_EnableEDIT = True
        R_GridViewTextBoxColumn3.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 103
        R_GridViewCheckBoxColumn1.FieldName = "_LCOMMERCIAL"
        R_GridViewCheckBoxColumn1.HeaderText = "_LCOMMERCIAL"
        R_GridViewCheckBoxColumn1.Name = "_LCOMMERCIAL"
        R_GridViewCheckBoxColumn1.R_EnableADD = True
        R_GridViewCheckBoxColumn1.R_EnableEDIT = True
        R_GridViewCheckBoxColumn1.R_ResourceId = "_LCOMMERCIAL"
        R_GridViewCheckBoxColumn1.Width = 118
        R_GridViewComboBoxColumn1.DataSource = Me.bsApplicationType
        R_GridViewComboBoxColumn1.DisplayMember = "CDESCRIPTION"
        R_GridViewComboBoxColumn1.FieldName = "_CAPPLICATION_TYPE"
        R_GridViewComboBoxColumn1.HeaderText = "_CAPPLICATION_TYPE"
        R_GridViewComboBoxColumn1.Name = "_CAPPLICATION_TYPE"
        R_GridViewComboBoxColumn1.R_EnableADD = True
        R_GridViewComboBoxColumn1.R_EnableEDIT = True
        R_GridViewComboBoxColumn1.R_ResourceId = "_CAPPLICATION_TYPE"
        R_GridViewComboBoxColumn1.ValueMember = "CAPPLICATION_TYPE"
        R_GridViewComboBoxColumn2.DataSource = Me.bsActivationType
        R_GridViewComboBoxColumn2.DisplayMember = "CDESCRIPTION"
        R_GridViewComboBoxColumn2.FieldName = "_CACTIVATION_TYPE"
        R_GridViewComboBoxColumn2.HeaderText = "_CACTIVATION_TYPE"
        R_GridViewComboBoxColumn2.Name = "_CACTIVATION_TYPE"
        R_GridViewComboBoxColumn2.R_EnableADD = True
        R_GridViewComboBoxColumn2.R_EnableEDIT = True
        R_GridViewComboBoxColumn2.R_ResourceId = "_CACTIVATION_TYPE"
        R_GridViewComboBoxColumn2.ValueMember = "CACTIVATION_TYPE"
        R_GridViewComboBoxColumn2.Width = 131
        Me.gvApps.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewCheckBoxColumn1, R_GridViewComboBoxColumn1, R_GridViewComboBoxColumn2})
        Me.gvApps.MasterTemplate.DataSource = Me.bsGvApps
        Me.gvApps.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvApps.MasterTemplate.EnableFiltering = True
        Me.gvApps.MasterTemplate.EnableGrouping = False
        Me.gvApps.MasterTemplate.ShowFilteringRow = False
        Me.gvApps.MasterTemplate.ShowGroupedColumns = True
        Me.gvApps.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvApps.Name = "gvApps"
        Me.gvApps.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvApps.R_ConductorGridSource = Me.conGridApps
        Me.gvApps.R_ConductorSource = Nothing
        Me.gvApps.R_DataAdded = False
        Me.gvApps.R_NewRowText = Nothing
        Me.gvApps.ShowHeaderCellButtons = True
        Me.gvApps.Size = New System.Drawing.Size(1271, 533)
        Me.gvApps.TabIndex = 1
        Me.gvApps.Text = "R_RadGridView1"
        '
        'bsGvApps
        '
        Me.bsGvApps.DataSource = GetType(RVM00100Front.RVM00100ServiceRef.RVM00100DTO)
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.gvApps, 0, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 2
        '
        'preUser
        '
        Me.preUser.R_ConductorGridSource = Me.conGridApps
        Me.preUser.R_ConductorSource = Nothing
        Me.preUser.R_CopyAccess = True
        Me.preUser.R_DockIndex = 0
        Me.preUser.R_EnableHASDATA = True
        Me.preUser.R_HeaderTitle = ""
        '
        'preProvider
        '
        Me.preProvider.R_ConductorGridSource = Me.conGridApps
        Me.preProvider.R_ConductorSource = Nothing
        Me.preProvider.R_CopyAccess = True
        Me.preProvider.R_DockIndex = 2
        Me.preProvider.R_EnableHASDATA = True
        Me.preProvider.R_HeaderTitle = ""
        '
        'preLogScope
        '
        Me.preLogScope.R_ConductorGridSource = Me.conGridApps
        Me.preLogScope.R_ConductorSource = Nothing
        Me.preLogScope.R_CopyAccess = True
        Me.preLogScope.R_DockIndex = 3
        Me.preLogScope.R_EnableHASDATA = True
        Me.preLogScope.R_HeaderTitle = ""
        '
        'bsApplicationType
        '
        Me.bsApplicationType.DataSource = GetType(RVM00100Front.RVM00100ServiceRef.RVM00100ApplicationTypeComboDTO)
        '
        'RVM00100
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "RVM00100"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.bsActivationType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvApps.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvApps, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        CType(Me.bsApplicationType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(false)

End Sub
    Friend WithEvents bsGvApps As System.Windows.Forms.BindingSource
    Friend WithEvents conGridApps As R_FrontEnd.R_ConductorGrid
    Friend WithEvents gvApps As R_FrontEnd.R_RadGridView
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents preUser As R_FrontEnd.R_PredefinedDock
    Friend WithEvents preProvider As R_FrontEnd.R_PredefinedDock
    Friend WithEvents preLogScope As R_FrontEnd.R_PredefinedDock
    Friend WithEvents bsActivationType As System.Windows.Forms.BindingSource
    Friend WithEvents bsApplicationType As System.Windows.Forms.BindingSource

End Class
