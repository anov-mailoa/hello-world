﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RVM00100LogScope
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxMultilineColumn1 As R_FrontEnd.R_GridViewTextBoxMultilineColumn = New R_FrontEnd.R_GridViewTextBoxMultilineColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblApp = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvLogScope = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvLogScope = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridLogScope = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.lblApp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvLogScope, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvLogScope.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvLogScope, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridLogScope, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.gvLogScope, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lblApp)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 24)
        Me.Panel1.TabIndex = 0
        '
        'lblApp
        '
        Me.lblApp.AutoSize = False
        Me.lblApp.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApp.Location = New System.Drawing.Point(9, 3)
        Me.lblApp.Name = "lblApp"
        Me.lblApp.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApp.R_ResourceId = Nothing
        Me.lblApp.Size = New System.Drawing.Size(564, 18)
        Me.lblApp.TabIndex = 0
        Me.lblApp.Text = "R_RadLabel1"
        '
        'gvLogScope
        '
        Me.gvLogScope.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvLogScope.EnableFastScrolling = True
        Me.gvLogScope.Location = New System.Drawing.Point(3, 33)
        '
        '
        '
        Me.gvLogScope.MasterTemplate.AutoGenerateColumns = False
        Me.gvLogScope.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn1.FieldName = "_CAPP_UNIT"
        R_GridViewTextBoxColumn1.HeaderText = "_CAPP_UNIT"
        R_GridViewTextBoxColumn1.Name = "_CAPP_UNIT"
        R_GridViewTextBoxColumn1.R_EnableADD = True
        R_GridViewTextBoxColumn1.R_ResourceId = "_CAPP_UNIT"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 84
        R_GridViewTextBoxMultilineColumn1.FieldName = "_CDESCRIPTION"
        R_GridViewTextBoxMultilineColumn1.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxMultilineColumn1.Name = "_CDESCRIPTION"
        R_GridViewTextBoxMultilineColumn1.R_EnableADD = True
        R_GridViewTextBoxMultilineColumn1.R_EnableEDIT = True
        R_GridViewTextBoxMultilineColumn1.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxMultilineColumn1.R_UDT = Nothing
        R_GridViewTextBoxMultilineColumn1.ReadOnly = True
        R_GridViewTextBoxMultilineColumn1.Width = 1168
        R_GridViewTextBoxMultilineColumn1.WrapText = True
        Me.gvLogScope.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxMultilineColumn1})
        Me.gvLogScope.MasterTemplate.DataSource = Me.bsGvLogScope
        Me.gvLogScope.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvLogScope.MasterTemplate.EnableFiltering = True
        Me.gvLogScope.MasterTemplate.EnableGrouping = False
        Me.gvLogScope.MasterTemplate.ShowFilteringRow = False
        Me.gvLogScope.MasterTemplate.ShowGroupedColumns = True
        Me.gvLogScope.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvLogScope.Name = "gvLogScope"
        Me.gvLogScope.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvLogScope.R_ConductorGridSource = Me.conGridLogScope
        Me.gvLogScope.R_ConductorSource = Nothing
        Me.gvLogScope.R_DataAdded = False
        Me.gvLogScope.R_NewRowText = Nothing
        Me.gvLogScope.ShowHeaderCellButtons = True
        Me.gvLogScope.Size = New System.Drawing.Size(1271, 539)
        Me.gvLogScope.TabIndex = 1
        Me.gvLogScope.Text = "R_RadGridView1"
        '
        'bsGvLogScope
        '
        Me.bsGvLogScope.DataSource = GetType(RVM00100Front.RVM00100LogScopeServiceRef.RVM00100LogScopeDTO)
        '
        'conGridLogScope
        '
        Me.conGridLogScope.R_ConductorParent = Nothing
        Me.conGridLogScope.R_IsHeader = True
        Me.conGridLogScope.R_RadGroupBox = Nothing
        '
        'RVM00100LogScope
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "RVM00100LogScope"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "Log"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me.lblApp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvLogScope.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvLogScope, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvLogScope, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridLogScope, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblApp As R_FrontEnd.R_RadLabel
    Friend WithEvents gvLogScope As R_FrontEnd.R_RadGridView
    Friend WithEvents bsGvLogScope As System.Windows.Forms.BindingSource
    Friend WithEvents conGridLogScope As R_FrontEnd.R_ConductorGrid

End Class
