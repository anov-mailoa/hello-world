﻿Imports R_Common
Imports ClientHelper
Imports R_FrontEnd
Imports RVM00100Front.RVM00100ProviderStreamingServiceRef
Imports System.ServiceModel.Channels
Imports RVM00100Common
Imports RVM00100FrontResources
Imports RVM00100Front.RVM00100ProviderServiceRef

Public Class RVM00100Provider


#Region " VARIABLE "
    Dim C_ServiceName As String = "RVM00100Service/RVM00100ProviderService.svc"
    Dim C_ServiceNameStream As String = "RVM00100Service/RVM00100ProviderStreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
#End Region

#Region " SUB and FUNCTION "

    Private Sub RefreshGrids()
        gvAvailableItems.R_RefreshGrid(_CCOMPID)
        gvSelectedItems.R_RefreshGrid(_CCOMPID)
    End Sub

#End Region

#Region " FORM Events "

    Private Sub RVM00100Item_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub RVM00100Item_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " GRIDVIEW Events "

    Private Sub gvAvailableItems_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvAvailableItems.R_ServiceGetListRecord
        Dim loServiceStream As RVM00100ProviderStreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVM00100ProviderStreamingService, RVM00100ProviderStreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of RVM00100ProviderGridDTO)
        Dim loListEntity As New List(Of RVM00100ProviderGridDTO)

        Try
            R_Utility.R_SetStreamingContext("cCompanyId", _CCOMPID)

            loRtn = loServiceStream.GetAvailableItems()
            loStreaming = R_StreamUtility(Of RVM00100ProviderGridDTO).ReadFromMessage(loRtn)

            For Each loDto As RVM00100ProviderGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvAvailableItems_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvAvailableItems.R_ServiceGetRecord
        Dim loEx As New R_Exception

        Try
            poEntityResult = poEntity
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSelectedItems_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvSelectedItems.R_ServiceGetListRecord
        Dim loServiceStream As RVM00100ProviderStreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVM00100ProviderStreamingService, RVM00100ProviderStreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of RVM00100ProviderGridDTO)
        Dim loListEntity As New List(Of RVM00100ProviderGridDTO)

        Try
            R_Utility.R_SetStreamingContext("cCompanyId", _CCOMPID)

            loRtn = loServiceStream.GetSelectedItems()
            loStreaming = R_StreamUtility(Of RVM00100ProviderGridDTO).ReadFromMessage(loRtn)

            For Each loDto As RVM00100ProviderGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " Process "

    Private Sub btnProcess_Click(sender As Object, e As System.EventArgs) Handles btnProcess.Click
        Dim loEx As New R_Exception
        Dim loBatchPar As R_BatchParameter
        Dim loSvc As R_ProcessAndUploadClient
        Dim loBigObject As New List(Of RVM00100BatchDTO)
        Dim lcKeyGuid As String
        Dim loUserParameters As New List(Of R_KeyValue)

        Try
            Dim loCheckedItems = From item In CType(bsGvAvailableItems.List, List(Of RVM00100ProviderGridDTO)) _
                             Where item.LSELECT = True

            If loCheckedItems.ToList.Count = 0 Then
                loEx.Add("RVM00100_04", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "RVM00100_04"))
                Exit Try
            End If

            'Instantiate FrontHelper
            loSvc = New R_ProcessAndUploadClient(Nothing, Nothing, Nothing)
            AddHandler loSvc.ProcessError, AddressOf ProcessError
            AddHandler loSvc.ProcessComplete, AddressOf ProcessComplete

            'Generate selected list
            loBigObject.AddRange(loCheckedItems.Select(Function(x) New RVM00100BatchDTO() _
                    With {.CCOMPANY_ID = _CCOMPID, _
                          .CPROVIDER_COMPANY_ID = x.CPROVIDER_COMPANY_ID}).ToList())

            If loBigObject.Count = 0 Then
                Exit Try
            End If

            With loBatchPar
                .COMPANY_ID = _CCOMPID
                .USER_ID = _CUSERID
                .ClassName = "RVM00100Back.RVM00100ProviderCls"
                .BigObject = loBigObject
                .UserParameters = loUserParameters
            End With
            lcKeyGuid = loSvc.R_BatchProcess(loBatchPar, loBigObject.Count)

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If

    End Sub

    Private Sub ProcessComplete(pcKeyGuid As String, poProcessResultMode As eProcessResultMode)
        Dim loEx As New R_Exception()

        Select Case poProcessResultMode
            Case eProcessResultMode.Success
                MsgBox("Process Complete")
                RefreshGrids()
            Case eProcessResultMode.Fail
                Dim loException As New R_Exception
                Dim loRtn As List(Of R_ErrorStatusReturn)
                Dim loHelp As New R_ProcessAndUploadClient(bwRVM00100, Nothing, Nothing)
                Dim loPar As R_UploadAndProcessKey

                Try
                    With loPar
                        .COMPANY_ID = _CCOMPID
                        .USER_ID = _CUSERID
                        .KEY_GUID = pcKeyGuid
                    End With
                    loRtn = loHelp.R_GetErrorProcess(loPar)

                    For Each loError As R_ErrorStatusReturn In loRtn
                        loEx.Add(loError.SeqNo.ToString, loError.ErrorMessage)
                    Next
                Catch ex As Exception
                    loException.Add(ex)
                End Try

                If loException.Haserror Then
                    loEx.ThrowExceptionIfErrors()
                End If
        End Select
    End Sub

    Private Sub ProcessError(pcKeyGuid As String, ex As R_Exception)
        Dim loEx As New R_Exception()

        If ex.Haserror Then
            Me.R_DisplayException(ex)
        End If
        RefreshGrids()
    End Sub

    Private Sub btnDeleteUser_Click(sender As System.Object, e As System.EventArgs) Handles btnDeleteUser.Click
        Dim loEx As New R_Exception()
        Dim loSvc As RVM00100ProviderServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVM00100ProviderService, RVM00100ProviderServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loKey As New RVM00100KeyDTO

        Try
            With loKey
                .CCOMPANY_ID = _CCOMPID
                .CPROVIDER_COMPANY_ID = CType(bsGvSelectedItems.Current, RVM00100ProviderGridDTO).CPROVIDER_COMPANY_ID
            End With
            loSvc.DeleteItem(loKey)
            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If
    End Sub
#End Region

End Class
