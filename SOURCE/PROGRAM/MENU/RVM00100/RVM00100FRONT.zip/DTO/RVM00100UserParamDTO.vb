﻿Public Class RVM00100DetailParamDTO
    Property CCOMPANY_ID As String
    Property CAPPS_CODE As String
    Property CAPPS_NAME As String
End Class
