﻿Imports R_BackEnd
Imports R_Common
Imports System.Data.Common

Public Class RVM00100LogScopeCls
    Inherits R_BusinessObject(Of RVM00100LogScopeDTO)

    Public Function GetLogScope(poTableKey As RVM00100KeyDTO) As List(Of RVM00100LogScopeGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RVM00100LogScopeGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poTableKey
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "RVM_APP_UNIT (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE)
            End With

            loResult = loDb.SqlExecObjectQuery(Of RVM00100LogScopeGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Deleting(poEntity As RVM00100LogScopeDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loResult As RVM00100LogScopeDTO

        Try
            loConn = loDb.GetConnection()

            With poEntity
                ' validasi
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "RVT_APP_VERSION_LOG (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CAPP_UNIT = '{2}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CAPP_UNIT)

                loResult = loDb.SqlExecObjectQuery(Of RVM00100LogScopeDTO)(lcQuery, loConn, False).FirstOrDefault
                If loResult IsNot Nothing Then
                    Throw New Exception("Log scope " + .CAPP_UNIT.Trim + " (" + .CDESCRIPTION.Trim + ") is used.")
                End If

                'delete main table
                lcQuery = "DELETE RVM_APP_UNIT "
                lcQuery += "WHERE "
                lcQuery += "CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CAPP_UNIT = '{2}' "
                lcQuery = String.Format(lcQuery,
                .CCOMPANY_ID,
                .CAPPS_CODE,
                .CAPP_UNIT)

                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As RVM00100LogScopeDTO) As RVM00100LogScopeDTO
        Dim lcQuery As String
        Dim loResult As RVM00100LogScopeDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity

                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "RVM_APP_UNIT (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CAPP_UNIT = '{2}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CAPP_UNIT)
            End With

            loResult = loDb.SqlExecObjectQuery(Of RVM00100LogScopeDTO)(lcQuery).FirstOrDefault
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As RVM00100LogScopeDTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As RVM00100LogScopeDTO

        Try
            loConn = loDb.GetConnection()

            With poNewEntity

                If poCRUDMode = eCRUDMode.AddMode Then
                    lcQuery = "SELECT * "
                    lcQuery += "FROM "
                    lcQuery += "RVM_APP_UNIT (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CAPP_UNIT = '{2}' "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CAPP_UNIT)

                    loResult = loDb.SqlExecObjectQuery(Of RVM00100LogScopeDTO)(lcQuery, loConn, True).FirstOrDefault
                    If loResult IsNot Nothing Then
                        Throw New Exception("Log scope " + .CAPP_UNIT.Trim + " already exists")
                    End If

                    .CCREATE_BY = .CUPDATE_BY
                    .DUPDATE_DATE = Now
                    .DCREATE_DATE = Now

                    lcQuery = "INSERT INTO RVM_APP_UNIT ("
                    lcQuery += "CCOMPANY_ID, "
                    lcQuery += "CAPPS_CODE, "
                    lcQuery += "CAPP_UNIT, "
                    lcQuery += "CDESCRIPTION, "
                    lcQuery += "CUPDATE_BY, "
                    lcQuery += "DUPDATE_DATE, "
                    lcQuery += "CCREATE_BY, "
                    lcQuery += "DCREATE_DATE) "
                    lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', GETDATE(), '{5}', GETDATE()) "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CAPP_UNIT,
                    .CDESCRIPTION,
                    .CUPDATE_BY,
                    .CCREATE_BY)

                    loDb.SqlExecNonQuery(lcQuery)

                ElseIf poCRUDMode = eCRUDMode.EditMode Then

                    lcQuery = "UPDATE RVM_APP_UNIT "
                    lcQuery += "SET "
                    lcQuery += "CDESCRIPTION = '{3}', "
                    lcQuery += "CUPDATE_BY = '{4}', "
                    lcQuery += "DUPDATE_DATE = GETDATE() "
                    lcQuery += "WHERE "
                    lcQuery += "CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CAPP_UNIT = '{2}' "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CAPP_UNIT,
                    .CDESCRIPTION,
                    .CUPDATE_BY)

                    loDb.SqlExecNonQuery(lcQuery, loConn, True)
                End If
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
End Class
