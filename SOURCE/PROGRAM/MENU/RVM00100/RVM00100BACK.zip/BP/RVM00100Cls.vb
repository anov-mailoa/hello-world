﻿Imports R_Common
Imports R_BackEnd
Imports System.Data.Common
Imports ServerHelper.General

Public Class RVM00100Cls
    Inherits R_BusinessObject(Of RVM00100DTO)

    Protected Overrides Sub R_Deleting(poEntity As RVM00100DTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loResult As RVM00100DTO

        Try
            loConn = loDb.GetConnection()

            With poEntity
                ' validasi
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "LAM_APP_CUST (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery = String.Format(lcQuery, poEntity.CCOMPANY_ID, poEntity.CAPPS_CODE)

                loResult = loDb.SqlExecObjectQuery(Of RVM00100DTO)(lcQuery, loConn, False).FirstOrDefault
                If loResult IsNot Nothing Then
                    Throw New Exception("Application Code " + poEntity.CAPPS_CODE.Trim + " has already been used.")
                End If

                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "RVT_APP_VERSION (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE)

                loResult = loDb.SqlExecObjectQuery(Of RVM00100DTO)(lcQuery, loConn, False).FirstOrDefault
                If loResult IsNot Nothing Then
                    Throw New Exception("Application " + .CAPPS_CODE.Trim + " has already been versioned.")
                End If

                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "RVM_APPLICATION "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE)

                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As RVM00100DTO) As RVM00100DTO
        Dim lcQuery As String
        Dim loResult As RVM00100DTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "RVM_APPLICATION (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery += "AND CAPPS_CODE = '{1}' "
            lcQuery = String.Format(lcQuery, poEntity.CCOMPANY_ID, poEntity.CAPPS_CODE)

            loResult = loDb.SqlExecObjectQuery(Of RVM00100DTO)(lcQuery).FirstOrDefault
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As RVM00100DTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As RVM00100DTO

        Try
            loConn = loDb.GetConnection()

            With poNewEntity

                If poCRUDMode = eCRUDMode.AddMode Then
                    lcQuery = "SELECT * "
                    lcQuery += "FROM "
                    lcQuery += "RVM_APPLICATION (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery = String.Format(lcQuery, poNewEntity.CCOMPANY_ID, poNewEntity.CAPPS_CODE)

                    loResult = loDb.SqlExecObjectQuery(Of RVM00100DTO)(lcQuery, loConn, True).FirstOrDefault
                    If loResult IsNot Nothing Then
                        Throw New Exception("Application Code " + poNewEntity.CAPPS_CODE.Trim + " is already exist")
                    End If

                    .CCREATE_BY = .CUPDATE_BY
                    .DUPDATE_DATE = Now
                    .DCREATE_DATE = Now

                    lcQuery = "INSERT INTO RVM_APPLICATION ("
                    lcQuery += "CCOMPANY_ID, "
                    lcQuery += "CAPPS_CODE, "
                    lcQuery += "CAPPS_NAME, "
                    lcQuery += "CDESCRIPTION, "
                    lcQuery += "LCOMMERCIAL, "
                    lcQuery += "CAPPLICATION_TYPE, "
                    lcQuery += "CACTIVATION_TYPE, "
                    lcQuery += "CUPDATE_BY, "
                    lcQuery += "DUPDATE_DATE, "
                    lcQuery += "CCREATE_BY, "
                    lcQuery += "DCREATE_DATE) "
                    lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', {4}, '{5}', '{6}', '{7}', GETDATE(), '{8}', GETDATE()) "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CAPPS_NAME,
                    .CDESCRIPTION,
                    getBit(.LCOMMERCIAL),
                    .CAPPLICATION_TYPE,
                    .CACTIVATION_TYPE,
                    .CUPDATE_BY,
                    .CCREATE_BY)

                    loDb.SqlExecNonQuery(lcQuery)

                ElseIf poCRUDMode = eCRUDMode.EditMode Then
                    lcQuery = "UPDATE RVM_APPLICATION "
                    lcQuery += "SET "
                    lcQuery += "CAPPS_NAME = '{2}', "
                    lcQuery += "CDESCRIPTION = '{3}', "
                    lcQuery += "LCOMMERCIAL = {4}, "
                    lcQuery += "CAPPLICATION_TYPE = '{5}', "
                    lcQuery += "CACTIVATION_TYPE = '{6}', "
                    lcQuery += "CUPDATE_BY = '{7}', "
                    lcQuery += "DUPDATE_DATE = GETDATE() "
                    lcQuery += "WHERE "
                    lcQuery += "CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CAPPS_NAME,
                    .CDESCRIPTION,
                    getBit(.LCOMMERCIAL),
                    .CAPPLICATION_TYPE,
                    .CACTIVATION_TYPE,
                    .CUPDATE_BY)

                    loDb.SqlExecNonQuery(lcQuery, loConn, True)
                End If
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Function GetApplications(poTableKey As RVM00100GridDTO) As List(Of RVM00100GridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RVM00100GridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poTableKey

                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "RVM_APPLICATION (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                If .CAPPS_CODE IsNot Nothing Then
                    If Not .CAPPS_CODE.Trim.Equals("") Then
                        lcQuery += "AND CAPPS_CODE = '{1}' "
                    End If
                End If
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE)
            End With

            loResult = loDb.SqlExecObjectQuery(Of RVM00100GridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetActivationTypeCombo() As List(Of RVM00100ActivationTypeComboDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RVM00100ActivationTypeComboDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT * "
            lcQuery += "FROM RVM_ACTIVATION_TYPE (NOLOCK) "
            lcQuery = String.Format(lcQuery)

            loResult = loDb.SqlExecObjectQuery(Of RVM00100ActivationTypeComboDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetApplicationTypeCombo() As List(Of RVM00100ApplicationTypeComboDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RVM00100ApplicationTypeComboDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT * "
            lcQuery += "FROM RVM_APPLICATION_TYPE (NOLOCK) "
            lcQuery = String.Format(lcQuery)

            loResult = loDb.SqlExecObjectQuery(Of RVM00100ApplicationTypeComboDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function
End Class
