﻿Imports R_BackEnd
Imports R_Common
Imports System.Data.Common
Imports ServerHelper.General

Public Class RVM00100CustomerCls
    Inherits R_BusinessObject(Of RVM00100CustomerDTO)

    Protected Overrides Sub R_Deleting(poEntity As RVM00100CustomerDTO)

    End Sub

    Protected Overrides Function R_Display(poEntity As RVM00100CustomerDTO) As RVM00100CustomerDTO
        Dim lcQuery As String
        Dim loResult As RVM00100CustomerDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "LAM_APP_CUST (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery += "AND CAPPS_CODE = '{1}' "
            lcQuery += "AND CCUSTOMER_CODE = '{2}' "
            lcQuery += "AND CSERVER_TYPE = '{3}' "
            lcQuery = String.Format(lcQuery, poEntity.CCOMPANY_ID, _
                                    poEntity.CAPPS_CODE, _
                                    poEntity.CCUSTOMER_CODE, _
                                    poEntity.CSERVER_TYPE)

            loResult = loDb.SqlExecObjectQuery(Of RVM00100CustomerDTO)(lcQuery).FirstOrDefault
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As RVM00100CustomerDTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String

        Try
            loConn = loDb.GetConnection()

            With poNewEntity

                If poCRUDMode = eCRUDMode.EditMode Then
                    lcQuery = "UPDATE LAM_APP_CUST "
                    lcQuery += "SET "
                    lcQuery += "LACTIVE = {4}, "
                    lcQuery += "NINTERVAL = {5}, "
                    lcQuery += "NGRACE_DAYS = {6}, "
                    lcQuery += "NWARNING_DAYS = {7}, "
                    lcQuery += "CUPDATE_BY = '{8}', "
                    lcQuery += "DUPDATE_DATE = GETDATE() "
                    lcQuery += "WHERE "
                    lcQuery += "CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                    lcQuery += "AND CSERVER_TYPE = '{3}' "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CCUSTOMER_CODE,
                    .CSERVER_TYPE,
                    getBit(.LACTIVE),
                    .NINTERVAL.ToString,
                    .NGRACE_DAYS.ToString,
                    .NWARNING_DAYS.ToString,
                    .CUPDATE_BY)

                    loDb.SqlExecNonQuery(lcQuery, loConn, True)
                End If
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Function GetApplicationCustomers(poTableKey As RVM00100CustomerGridDTO) As List(Of RVM00100CustomerGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RVM00100CustomerGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poTableKey

                lcQuery = "SELECT A.*, B.CCUSTOMER_NAME, "
                lcQuery += "CASE A.CSERVER_TYPE WHEN '0' THEN 'Test' WHEN '1' THEN 'Live' WHEN '2' THEN 'Training' ELSE '???' END AS CSERVER_TYPE_NAME "
                lcQuery += "FROM LAM_APP_CUST A (NOLOCK) "
                lcQuery += "JOIN LAM_CUSTOMER B (NOLOCK) "
                lcQuery += "ON B.CCOMPANY_ID = A.CCOMPANY_ID "
                lcQuery += "AND B.CCUSTOMER_CODE = A.CCUSTOMER_CODE "
                lcQuery += "WHERE A.CCOMPANY_ID = '{0}' "
                lcQuery += "AND A.CAPPS_CODE = '{1}' "
                lcQuery += "AND A.CSERVER_TYPE IN ('1', '2') "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE)
            End With

            loResult = loDb.SqlExecObjectQuery(Of RVM00100CustomerGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetApplicationCombo(pcCompany_ID As String, pcUser_ID As String) As List(Of RVM00100AppComboDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RVM00100AppComboDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT A.CAPPS_CODE, A.CAPPS_NAME, "
            lcQuery += "ISNULL(B.CDESCRIPTION,'(undefined)') AS CACTIVATION_TYPE_NAME "
            lcQuery += "FROM RVM_APPLICATION A (NOLOCK) "
            lcQuery += "JOIN RVM_ACTIVATION_TYPE B (NOLOCK) "
            lcQuery += "ON B.CACTIVATION_TYPE = A.CACTIVATION_TYPE "
            lcQuery += "JOIN RVM_APP_USER C (NOLOCK) "
            lcQuery += "ON C.CCOMPANY_ID = A.CCOMPANY_ID "
            lcQuery += "AND C.CAPPS_CODE = A.CAPPS_CODE "
            lcQuery += "AND C.CUSER_ID = '{1}' "
            lcQuery += "WHERE A.CCOMPANY_ID = '{0}' "
            lcQuery += "AND A.LCOMMERCIAL = 1 "
            lcQuery = String.Format(lcQuery, pcCompany_ID, pcUser_ID)
            loResult = loDb.SqlExecObjectQuery(Of RVM00100AppComboDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

End Class
