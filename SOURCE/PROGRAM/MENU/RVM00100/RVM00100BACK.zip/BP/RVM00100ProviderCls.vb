﻿Imports R_BackEnd
Imports R_Common
Imports System.Data.Common
Imports System.Transactions
Imports RVM00100Common

Public Class RVM00100ProviderCls
    Implements R_IBatchProcess

    Public Function GetAvailableItems(poKey As RVM00100ProviderDTO) As List(Of RVM00100ProviderGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RVM00100ProviderGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "SELECT A.CCOMPANY_ID AS CPROVIDER_COMPANY_ID, A.CCOMPANY_NAME AS CPROVIDER_COMPANY_NAME "
                lcQuery += "FROM SAM_COMPANIES A (NOLOCK) "
                lcQuery += "WHERE A.CCOMPANY_ID <> '{0}' "
                lcQuery += "AND NOT EXISTS ( "
                lcQuery += "SELECT C.CPROVIDER_COMPANY_ID "
                lcQuery += "FROM RVM_PROVIDER C (NOLOCK) "
                lcQuery += "WHERE C.CCOMPANY_ID = '{0}' "
                lcQuery += "AND C.CPROVIDER_COMPANY_ID = A.CCOMPANY_ID "
                lcQuery += ")"

                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID)

            End With
            loResult = loDb.SqlExecObjectQuery(Of RVM00100ProviderGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetSelectedItems(poKey As RVM00100ProviderDTO) As List(Of RVM00100ProviderGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RVM00100ProviderGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "SELECT A.CPROVIDER_COMPANY_ID, B.CCOMPANY_NAME AS CPROVIDER_COMPANY_NAME "
                lcQuery += "FROM RVM_PROVIDER A (NOLOCK) "
                lcQuery += "JOIN SAM_COMPANIES B (NOLOCK) "
                lcQuery += "ON B.CCOMPANY_ID = A.CPROVIDER_COMPANY_ID "
                lcQuery += "WHERE A.CCOMPANY_ID = '{0}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID)

            End With
            loResult = loDb.SqlExecObjectQuery(Of RVM00100ProviderGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Sub DeleteItem(poKey As RVM00100KeyDTO)
        Dim loEx As New R_Exception()
        Dim loConn As DbConnection
        Dim loDb As New R_Db
        Dim lcQuery As String
        Dim loResult As RVM00100ProviderDTO

        Try
            loConn = loDb.GetConnection()
            With poKey
                ' validasi
                lcQuery = "SELECT TOP 1 CCOMPANY_ID "
                lcQuery += "FROM "
                lcQuery += "RVT_APP_INCLUDES (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CINCL_COMPANY_ID = '{1}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CPROVIDER_COMPANY_ID)

                loResult = loDb.SqlExecObjectQuery(Of RVM00100ProviderDTO)(lcQuery, loConn, False).FirstOrDefault
                If loResult IsNot Nothing Then
                    Throw New Exception("Company ID " + .CPROVIDER_COMPANY_ID.Trim + " has already provided some libraries/includes.")
                    Exit Try
                End If

                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "RVM_PROVIDER "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CPROVIDER_COMPANY_ID = '{1}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CPROVIDER_COMPANY_ID)

                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End With
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Sub R_BatchProcess(poBatchProcessPar As R_Common.R_BatchProcessPar) Implements R_Common.R_IBatchProcess.R_BatchProcess
        Dim loEx As New R_Exception()
        Dim loObject As List(Of RVM00100BatchDTO)
        Dim loDb As New R_Db
        Dim lcQuery As String
        Dim loConn As DbConnection
        Dim CUSER_ID As String
        Dim countLoop As Integer = 0
        Dim CCOMP_ID As String

        Try
            'get all program
            loObject = R_Utility.Deserialize(poBatchProcessPar.BigObject)
            CCOMP_ID = poBatchProcessPar.Key.COMPANY_ID
            CUSER_ID = poBatchProcessPar.Key.USER_ID

            Using TransScope As New TransactionScope(TransactionScopeOption.Required)
                loConn = loDb.GetConnection()

                For Each save As RVM00100BatchDTO In loObject.OrderBy(Function(x) x.CUSER_ID)
                    countLoop += 1

                    lcQuery = "exec RSP_WriteUploadProcessStatus '{0}', '{1}', '{2}', '{3}', '{4}'"
                    lcQuery = String.Format(lcQuery, CCOMP_ID, CUSER_ID, poBatchProcessPar.Key.KEY_GUID.Trim, countLoop, "Save " + save.CUSER_ID)
                    loDb.SqlExecNonQuery(lcQuery, loConn, False)

                    'insert into application user
                    With save
                        lcQuery = "INSERT INTO RVM_PROVIDER ("
                        lcQuery += "CCOMPANY_ID, "
                        lcQuery += "CPROVIDER_COMPANY_ID, "
                        lcQuery += "CUPDATE_BY, "
                        lcQuery += "DUPDATE_DATE, "
                        lcQuery += "CCREATE_BY, "
                        lcQuery += "DCREATE_DATE) "
                        lcQuery += "VALUES ('{0}', '{1}', '{2}', GETDATE(), '{2}', GETDATE()) "
                        lcQuery = String.Format(lcQuery,
                        .CCOMPANY_ID,
                        .CPROVIDER_COMPANY_ID,
                        .CCREATE_BY)
                    End With
                    loDb.SqlExecNonQuery(lcQuery, loConn, False)
                Next

                lcQuery = "exec RSP_WriteUploadProcessStatus '{0}', '{1}', '{2}', '{3}', '{4}', '{5}'"
                lcQuery = String.Format(lcQuery, CCOMP_ID, CUSER_ID, poBatchProcessPar.Key.KEY_GUID.Trim, countLoop, "Save Complete", 1)
                loDb.SqlExecNonQuery(lcQuery, loConn, True)

                TransScope.Complete()
            End Using

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
End Class
