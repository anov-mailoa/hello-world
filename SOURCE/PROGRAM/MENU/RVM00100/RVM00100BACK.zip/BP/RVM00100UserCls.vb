﻿Imports R_BackEnd
Imports R_Common
Imports System.Data.Common
Imports RVM00100Common
Imports System.Transactions

Public Class RVM00100UserCls
    Implements R_IBatchProcess

    Public Sub R_BatchProcess(poBatchProcessPar As R_Common.R_BatchProcessPar) Implements R_Common.R_IBatchProcess.R_BatchProcess
        Dim loEx As New R_Exception()
        Dim loObject As List(Of RVM00100BatchDTO)
        Dim loDb As New R_Db
        Dim lcQuery As String
        Dim loConn As DbConnection
        Dim CUSER_ID As String
        Dim loMapping As New Dictionary(Of String, String)()
        Dim countLoop As Integer = 0
        Dim CCOMP_ID As String

        Try
            'get all program
            loObject = R_Utility.Deserialize(poBatchProcessPar.BigObject)
            CCOMP_ID = poBatchProcessPar.Key.COMPANY_ID
            CUSER_ID = poBatchProcessPar.Key.USER_ID

            Using TransScope As New TransactionScope(TransactionScopeOption.Required)
                loConn = loDb.GetConnection()

                For Each save As RVM00100BatchDTO In loObject.OrderBy(Function(x) x.CUSER_ID)
                    countLoop += 1

                    lcQuery = "exec RSP_WriteUploadProcessStatus '{0}', '{1}', '{2}', '{3}', '{4}'"
                    lcQuery = String.Format(lcQuery, CCOMP_ID, CUSER_ID, poBatchProcessPar.Key.KEY_GUID.Trim, countLoop, "Save " + save.CUSER_ID)
                    loDb.SqlExecNonQuery(lcQuery, loConn, False)

                    'insert into application user
                    With save
                        lcQuery = "INSERT INTO RVM_APP_USER ("
                        lcQuery += "CCOMPANY_ID, "
                        lcQuery += "CAPPS_CODE, "
                        lcQuery += "CUSER_ID, "
                        lcQuery += "CUPDATE_BY, "
                        lcQuery += "DUPDATE_DATE, "
                        lcQuery += "CCREATE_BY, "
                        lcQuery += "DCREATE_DATE) "
                        lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', GETDATE(), '{3}', GETDATE()) "
                        lcQuery = String.Format(lcQuery,
                        .CCOMPANY_ID,
                        .CAPPS_CODE,
                        .CUSER_ID,
                        .CCREATE_BY)
                    End With
                    loDb.SqlExecNonQuery(lcQuery, loConn, False)
                Next

                lcQuery = "exec RSP_WriteUploadProcessStatus '{0}', '{1}', '{2}', '{3}', '{4}', '{5}'"
                lcQuery = String.Format(lcQuery, CCOMP_ID, CUSER_ID, poBatchProcessPar.Key.KEY_GUID.Trim, countLoop, "Save Complete", 1)
                loDb.SqlExecNonQuery(lcQuery, loConn, True)

                TransScope.Complete()
            End Using

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Function GetAvailableItems(poKey As RVM00100UserDTO) As List(Of RVM00100UserGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RVM00100UserGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "SELECT A.CUSER_ID, A.CUSER_NAME "
                lcQuery += "FROM SAM_USER A (NOLOCK) "
                lcQuery += "JOIN SAM_USER_COMPANY B (NOLOCK) "
                lcQuery += "ON B.CUSER_ID = A.CUSER_ID "
                lcQuery += "WHERE B.CCOMPANY_ID = '{0}' "
                lcQuery += "AND NOT EXISTS ( "
                lcQuery += "SELECT C.CUSER_ID "
                lcQuery += "FROM RVM_APP_USER C (NOLOCK) "
                lcQuery += "WHERE C.CCOMPANY_ID = B.CCOMPANY_ID "
                lcQuery += "AND C.CAPPS_CODE = '{1}' "
                lcQuery += "AND C.CUSER_ID = A.CUSER_ID "
                lcQuery += ")"
                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE)

            End With
            loResult = loDb.SqlExecObjectQuery(Of RVM00100UserGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetSelectedItems(poKey As RVM00100UserDTO) As List(Of RVM00100UserGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RVM00100UserGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "SELECT A.CUSER_ID, A.CUSER_NAME "
                lcQuery += "FROM SAM_USER A (NOLOCK) "
                lcQuery += "JOIN RVM_APP_USER B (NOLOCK) "
                lcQuery += "ON B.CUSER_ID = A.CUSER_ID "
                lcQuery += "WHERE B.CCOMPANY_ID = '{0}' "
                lcQuery += "AND B.CAPPS_CODE = '{1}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, _
                                        .CAPPS_CODE)

            End With
            loResult = loDb.SqlExecObjectQuery(Of RVM00100UserGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Sub DeleteItem(poKey As RVM00100UserDTO)
        Dim loEx As New R_Exception()
        Dim loConn As DbConnection
        Dim loDb As New R_Db
        Dim lcQuery As String

        Try
            loConn = loDb.GetConnection()
            With poKey
                ' delete item
                lcQuery = "DELETE FROM "
                lcQuery += "RVM_APP_USER "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' AND CAPPS_CODE = '{1}' AND CUSER_ID = '{2}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CUSER_ID)
                loDb.SqlExecNonQuery(lcQuery)
            End With
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

End Class
