﻿Public Class RVM00100ActivationTypeComboDTO
    Public Property CACTIVATION_TYPE As String
    Public Property CDESCRIPTION As String
End Class
