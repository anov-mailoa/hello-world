﻿Imports R_BackEnd

<Serializable()> _
Public Class RVM00100ProviderDTO
    Inherits R_DTOBase

    Public Property CCOMPANY_ID As String
    Public Property CPROVIDER_COMPANY_ID As String
    Public Property CPROVIDER_COMPANY_NAME As String
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)
    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)
End Class
