﻿Public Class RVM00100KeyDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CPROVIDER_COMPANY_ID As String
End Class
