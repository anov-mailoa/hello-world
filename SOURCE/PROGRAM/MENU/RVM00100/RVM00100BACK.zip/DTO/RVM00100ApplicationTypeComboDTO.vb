﻿Public Class RVM00100ApplicationTypeComboDTO
    Public Property CAPPLICATION_TYPE As String
    Public Property CDESCRIPTION As String
End Class
