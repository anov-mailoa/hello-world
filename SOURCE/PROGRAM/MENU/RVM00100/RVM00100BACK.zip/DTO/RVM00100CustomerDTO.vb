﻿Imports R_BackEnd

<Serializable()> _
Public Class RVM00100CustomerDTO
    Inherits R_DTOBase

    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CCUSTOMER_CODE As String
    Public Property CCUSTOMER_NAME As String
    Public Property CSERVER_TYPE As String
    Public Property CSERVER_TYPE_NAME As String
    Public Property CSERVER_UID As String
    Public Property LACTIVE As Boolean
    Public Property NINTERVAL As Integer
    Public Property NGRACE_DAYS As Integer
    Public Property NWARNING_DAYS As Integer
    Public Property CLAST_EXPIRY_DATE As String
    Public Property CCURRENT_EXPIRY_DATE As String
    Public Property CREACTIVATION_STATUS As String
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)
    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)

    Public Property DLAST_EXPIRY_DATE As Nullable(Of DateTime)
    Public Property DCURRENT_EXPIRY_DATE As Nullable(Of DateTime)
End Class
