﻿Public Class RVM00100ProviderGridDTO

    Public Property LSELECT As Boolean
    Public Property CPROVIDER_COMPANY_ID As String
    Public Property CPROVIDER_COMPANY_NAME As String

End Class
