﻿Public Class RVM00100UserGridDTO

    Public Property LSELECT As Boolean
    Public Property CUSER_ID As String
    Public Property CUSER_NAME As String

End Class
