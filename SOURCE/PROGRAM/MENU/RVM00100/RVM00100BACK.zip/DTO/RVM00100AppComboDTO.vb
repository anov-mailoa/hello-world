﻿Public Class RVM00100AppComboDTO
    Public Property CAPPS_CODE As String
    Public Property CAPPS_NAME As String
    Public Property CACTIVATION_TYPE_NAME As String
End Class
