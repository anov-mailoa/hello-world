﻿Imports LAT00110FrontResources
Imports R_Common
Imports LAT00110Front.LAT00110ServiceRef
Imports R_FrontEnd
Imports ClientHelper
Imports LAT00110Front.LAT00110StreamingServiceRef
Imports System.ServiceModel.Channels
Imports RCustDBFrontHelper

Public Class LAT00110

#Region " VARIABLE "
    Dim C_ServiceName As String = "LAT00110Service/LAT00110Service.svc"
    Dim C_ServiceNameStream As String = "LAT00110Service/LAT00110StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _CVERSION As String
    Dim _CPROJECTID As String
    Dim _CSESSIONID As String
    Dim _CUSER_NAME As String
    Dim _CFUNCTIONID As String
    Dim _CSESSION_STATUS As String
    Dim _LDONE_COMBO_SETTING As Boolean = False
    Dim _LREADY_TO_REFRESH As Boolean = False
    Dim _LINIT As Boolean
    Dim _IGRID_MODE As Integer
    Dim _LMANAGER As Boolean

#End Region

#Region " SUBs and FUNCTIONs "

    Private Sub RefreshGrids()
        Dim loTableKey As New LAT00110KeyDTO
        loTableKey.CCOMPANY_ID = _CCOMPID
        loTableKey.CAPPS_CODE = cboApplication.SelectedValue

        With gvStaging
            .R_RefreshGrid(loTableKey)
            .Columns(0).Sort(Telerik.WinControls.UI.RadSortOrder.Ascending, False)
        End With
    End Sub

#End Region

#Region " FORM Events "

    Private Sub LAT00110_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loSvc As LAT00110ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00110Service, LAT00110ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loAppCombo As New List(Of RLicenseAppComboDTO)

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            ' Application
            loAppCombo = loSvc.GetAppCombo(_CCOMPID, _CUSERID)
            If loAppCombo.Count <= 0 Then
                cboApplication.Items.Clear()
                loEx.Add("LAT00100_06", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "LAT00100_06"))
                Exit Try
            End If
            bsApps.DataSource = loAppCombo

            'RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub LAT00110_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As System.EventArgs) Handles btnRefresh.Click
        RefreshGrids()
    End Sub

    Private Sub cboApplication_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboApplication.SelectedValueChanged
        RefreshGrids()
    End Sub

#End Region

#Region " GRIDVIEW Events "

    Private Sub gvStaging_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvStaging.DataBindingComplete
        gvStaging.BestFitColumns()
    End Sub


    Private Sub gvStaging_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvStaging.R_ServiceGetListRecord
        Dim loServiceStream As LAT00110StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00110StreamingService, LAT00110StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of LAT00110StagingDTO)
        Dim loListEntity As New List(Of LAT00110StagingDTO)

        Try
            With CType(poEntity, LAT00110KeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
            End With

            loRtn = loServiceStream.GetStagingData()
            loStreaming = R_StreamUtility(Of LAT00110StagingDTO).ReadFromMessage(loRtn)

            For Each loDto As LAT00110StagingDTO In loStreaming
                If loDto IsNot Nothing Then
                    loDto.DSTART_DATE = General.StrToDate(loDto.CSTART_DATE)
                    loDto.DEXPIRY_DATE = General.StrToDate(loDto.CEXPIRY_DATE)
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()

    End Sub

    Private Sub gvSchedule_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object)
        'Dim loService As LAT00110ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00110Service, LAT00110ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        'Dim loEx As New R_Exception

        'Try
        '    poEntityResult = loService.Svc_R_GetRecord(New LAT00110StagingDTO With {._CCOMPANY_ID = _CCOMPID,
        '                                                                             ._CAPPS_CODE = loFilterParam.OFILTER_KEY.CAPPS_CODE,
        '                                                                             ._CVERSION = loFilterParam.OFILTER_KEY.CVERSION,
        '                                                                             ._CPROJECT_ID = loFilterParam.OFILTER_KEY.CPROJECT_ID,
        '                                                                             ._CSESSION_ID = loFilterParam.OFILTER_KEY.CSESSION_ID,
        '                                                                             ._CSCHEDULE_ID = CType(bsGvSchedule.Current, CSM00500ScheduleDTO)._CSCHEDULE_ID})
        'Catch ex As Exception
        '    loEx.Add(ex)
        'End Try

        'loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

End Class
