﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LAT00110
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn2 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewCheckBoxColumn1 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewDateTimeColumn3 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewCheckBoxColumn2 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewDateTimeColumn4 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.gvStaging = New R_FrontEnd.R_RadGridView(Me.components)
        Me.conGridStaging = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnRefresh = New R_FrontEnd.R_RadButton(Me.components)
        Me.cboApplication = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.bsGvStaging = New System.Windows.Forms.BindingSource(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.gvStaging, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvStaging.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridStaging, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.btnRefresh, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvStaging, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.gvStaging, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 42.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'gvStaging
        '
        Me.gvStaging.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvStaging.EnableFastScrolling = True
        Me.gvStaging.Location = New System.Drawing.Point(3, 45)
        '
        '
        '
        Me.gvStaging.MasterTemplate.AllowAddNewRow = False
        Me.gvStaging.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn1.FieldName = "CCUSTOMER_NAME"
        R_GridViewTextBoxColumn1.HeaderText = "_CCUSTOMER_NAME"
        R_GridViewTextBoxColumn1.Name = "_CCUSTOMER_NAME"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CCUSTOMER_NAME"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 128
        R_GridViewTextBoxColumn2.FieldName = "CGENERATE_TIME"
        R_GridViewTextBoxColumn2.HeaderText = "_CGENERATE_TIME"
        R_GridViewTextBoxColumn2.Name = "_CGENERATE_TIME"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CGENERATE_TIME"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 117
        R_GridViewTextBoxColumn3.FieldName = "CREFERENCE_NO"
        R_GridViewTextBoxColumn3.HeaderText = "_CREFERENCE_NO"
        R_GridViewTextBoxColumn3.Name = "_CREFERENCE_NO"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CREFERENCE_NO"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 113
        R_GridViewDateTimeColumn1.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn1.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn1.FieldName = "DSTART_DATE"
        R_GridViewDateTimeColumn1.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn1.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn1.HeaderText = "_DSTART_DATE"
        R_GridViewDateTimeColumn1.Name = "_DSTART_DATE"
        R_GridViewDateTimeColumn1.R_ResourceId = "_DSTART_DATE"
        R_GridViewDateTimeColumn1.Width = 98
        R_GridViewDateTimeColumn2.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn2.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn2.FieldName = "DEXPIRY_DATE"
        R_GridViewDateTimeColumn2.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn2.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn2.HeaderText = "_DEXPIRY_DATE"
        R_GridViewDateTimeColumn2.Name = "_DEXPIRY_DATE"
        R_GridViewDateTimeColumn2.R_ResourceId = "_DEXPIRY_DATE"
        R_GridViewDateTimeColumn2.Width = 101
        R_GridViewCheckBoxColumn1.FieldName = "LFETCHED"
        R_GridViewCheckBoxColumn1.HeaderText = "_LFETCHED"
        R_GridViewCheckBoxColumn1.Name = "_LFETCHED"
        R_GridViewCheckBoxColumn1.R_ResourceId = "_LFETCHED"
        R_GridViewCheckBoxColumn1.Width = 93
        R_GridViewDateTimeColumn3.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn3.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.GeneralDate
        R_GridViewDateTimeColumn3.FieldName = "DFETCH_DATE"
        R_GridViewDateTimeColumn3.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn3.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        R_GridViewDateTimeColumn3.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn3.HeaderText = "_DFETCH_DATE"
        R_GridViewDateTimeColumn3.Name = "_DFETCH_DATE"
        R_GridViewDateTimeColumn3.R_ResourceId = "_DFETCH_DATE"
        R_GridViewDateTimeColumn3.Width = 99
        R_GridViewCheckBoxColumn2.FieldName = "LINSTALLED"
        R_GridViewCheckBoxColumn2.HeaderText = "_LINSTALLED"
        R_GridViewCheckBoxColumn2.Name = "_LINSTALLED"
        R_GridViewCheckBoxColumn2.R_ResourceId = "_LINSTALLED"
        R_GridViewCheckBoxColumn2.Width = 102
        R_GridViewDateTimeColumn4.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn4.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.GeneralDate
        R_GridViewDateTimeColumn4.FieldName = "DINSTALL_DATE"
        R_GridViewDateTimeColumn4.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn4.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        R_GridViewDateTimeColumn4.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn4.HeaderText = "_DINSTALL_DATE"
        R_GridViewDateTimeColumn4.Name = "_DINSTALL_DATE"
        R_GridViewDateTimeColumn4.R_ResourceId = "_DINSTALL_DATE"
        R_GridViewDateTimeColumn4.Width = 108
        R_GridViewTextBoxColumn4.FieldName = "CACTIVATION_CODE"
        R_GridViewTextBoxColumn4.HeaderText = "_CACTIVATION_CODE"
        R_GridViewTextBoxColumn4.Name = "_CACTIVATION_CODE"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CACTIVATION_CODE"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 131
        Me.gvStaging.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewDateTimeColumn1, R_GridViewDateTimeColumn2, R_GridViewCheckBoxColumn1, R_GridViewDateTimeColumn3, R_GridViewCheckBoxColumn2, R_GridViewDateTimeColumn4, R_GridViewTextBoxColumn4})
        Me.gvStaging.MasterTemplate.DataSource = Me.bsGvStaging
        Me.gvStaging.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvStaging.MasterTemplate.EnableFiltering = True
        Me.gvStaging.MasterTemplate.ShowFilteringRow = False
        Me.gvStaging.MasterTemplate.ShowGroupedColumns = True
        Me.gvStaging.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvStaging.Name = "gvStaging"
        Me.gvStaging.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvStaging.R_ConductorGridSource = Me.conGridStaging
        Me.gvStaging.R_ConductorSource = Nothing
        Me.gvStaging.R_DataAdded = False
        Me.gvStaging.R_EnableGrouping = True
        Me.gvStaging.R_NewRowText = Nothing
        Me.gvStaging.ShowGroupPanel = False
        Me.gvStaging.ShowHeaderCellButtons = True
        Me.gvStaging.Size = New System.Drawing.Size(1271, 527)
        Me.gvStaging.TabIndex = 4
        Me.gvStaging.Text = "R_RadGridView1"
        '
        'conGridStaging
        '
        Me.conGridStaging.R_ConductorParent = Nothing
        Me.conGridStaging.R_IsHeader = True
        Me.conGridStaging.R_RadGroupBox = Nothing
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnRefresh)
        Me.Panel1.Controls.Add(Me.cboApplication)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 36)
        Me.Panel1.TabIndex = 0
        '
        'btnRefresh
        '
        Me.btnRefresh.Location = New System.Drawing.Point(521, 6)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.R_ConductorGridSource = Nothing
        Me.btnRefresh.R_ConductorSource = Nothing
        Me.btnRefresh.R_DescriptionId = Nothing
        Me.btnRefresh.R_ResourceId = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(110, 24)
        Me.btnRefresh.TabIndex = 61
        Me.btnRefresh.Text = "R_RadButton1"
        '
        'cboApplication
        '
        Me.cboApplication.DataMember = Nothing
        Me.cboApplication.DataSource = Me.bsApps
        Me.cboApplication.DisplayMember = "CAPPS_NAME"
        Me.cboApplication.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList
        Me.cboApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboApplication.Location = New System.Drawing.Point(115, 9)
        Me.cboApplication.Name = "cboApplication"
        Me.cboApplication.R_ConductorGridSource = Nothing
        Me.cboApplication.R_ConductorSource = Nothing
        Me.cboApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboApplication.Size = New System.Drawing.Size(400, 20)
        Me.cboApplication.TabIndex = 49
        Me.cboApplication.Text = "R_RadDropDownList1"
        Me.cboApplication.ValueMember = "CAPPS_CODE"
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 25
        Me.lblApplication.Text = "Application..."
        '
        'bsGvStaging
        '
        Me.bsGvStaging.DataSource = GetType(LAT00110Front.LAT00110StreamingServiceRef.LAT00110StagingDTO)
        '
        'LAT00110
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "LAT00110"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.TableLayoutPanel1.ResumeLayout(False)
        CType(Me.gvStaging.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvStaging, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridStaging, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.btnRefresh, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvStaging, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(false)

End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents conGridStaging As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsGvStaging As System.Windows.Forms.BindingSource
    Friend WithEvents cboApplication As R_FrontEnd.R_RadDropDownList
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnRefresh As R_FrontEnd.R_RadButton
    Friend WithEvents gvStaging As R_FrontEnd.R_RadGridView

End Class
