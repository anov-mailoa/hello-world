﻿Imports R_Common
Imports R_BackEnd
Imports LAT00100Back
Imports System.Data.Common

Public Class LAT00110Cls

    Public Function ActivationRequest(poPar As ActivationRequestParamDTO) As ActivationRequestReturnDTO
        Dim loReturn As New ActivationRequestReturnDTO
        Dim lcResult As String = Nothing
        Dim lnResult As Integer
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim lcInstallationKey As String

        Try
            With loReturn
                .CRETURN_CODE = "000"
                .CDESCRIPTION = "Success."
                .CRETURN_TYPE = "0"

                ' Validation
                ' Company ID
                If Len(poPar.CCOMPANY_ID.Trim) = 0 Then
                    .CRETURN_CODE = "100"
                    .CDESCRIPTION = "Company ID is empty."
                    .CRETURN_TYPE = "1"
                    Exit Try
                End If
                If Len(poPar.CCOMPANY_ID.Trim) > 8 Then
                    .CRETURN_CODE = "101"
                    .CDESCRIPTION = "Company ID exceeds maximum length."
                    .CRETURN_TYPE = "1"
                    Exit Try
                End If
                lcQuery = "SELECT CCOMPANY_ID "
                lcQuery += "FROM SAM_COMPANIES (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery = String.Format(lcQuery, poPar.CCOMPANY_ID)
                lcResult = loDb.SqlExecObjectQuery(Of String)(lcQuery, loDb.GetConnection, False).FirstOrDefault
                If lcResult Is Nothing Then
                    .CRETURN_CODE = "102"
                    .CDESCRIPTION = "Company ID does not exist."
                    .CRETURN_TYPE = "1"
                    Exit Try
                End If

                ' Application Code
                If Len(poPar.CAPPS_CODE.Trim) = 0 Then
                    .CRETURN_CODE = "200"
                    .CDESCRIPTION = "Application Code is empty."
                    .CRETURN_TYPE = "1"
                    Exit Try
                End If
                If Len(poPar.CAPPS_CODE.Trim) > 20 Then
                    .CRETURN_CODE = "201"
                    .CDESCRIPTION = "Application Code exceeds maximum length."
                    .CRETURN_TYPE = "1"
                    Exit Try
                End If
                lcQuery = "SELECT CACTIVATION_TYPE "
                lcQuery += "FROM RVM_APPLICATION (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery = String.Format(lcQuery, poPar.CCOMPANY_ID, poPar.CAPPS_CODE)
                lcResult = loDb.SqlExecObjectQuery(Of String)(lcQuery, loDb.GetConnection, False).FirstOrDefault
                If lcResult Is Nothing Then
                    .CRETURN_CODE = "202"
                    .CDESCRIPTION = "Application Code does not exist."
                    .CRETURN_TYPE = "1"
                    Exit Try
                Else
                    .CACTIVATION_TYPE = lcResult
                End If

                ' Customer Code
                If Len(poPar.CCUSTOMER_CODE.Trim) = 0 Then
                    .CRETURN_CODE = "300"
                    .CDESCRIPTION = "Customer Code is empty."
                    .CRETURN_TYPE = "1"
                    Exit Try
                End If
                If Len(poPar.CCUSTOMER_CODE.Trim) > 20 Then
                    .CRETURN_CODE = "301"
                    .CDESCRIPTION = "Customer Code exceeds maximum length."
                    .CRETURN_TYPE = "1"
                    Exit Try
                End If
                lcQuery = "SELECT CSERVER_UID "
                lcQuery += "FROM LAM_APP_CUST (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                lcQuery += "AND CSERVER_TYPE = '1' "
                lcQuery = String.Format(lcQuery, poPar.CCOMPANY_ID, poPar.CAPPS_CODE, poPar.CCUSTOMER_CODE)
                lcResult = loDb.SqlExecObjectQuery(Of String)(lcQuery, loDb.GetConnection, False).FirstOrDefault
                If lcResult Is Nothing Then
                    .CRETURN_CODE = "302"
                    .CDESCRIPTION = "Customer Code does not exist or use the application."
                    .CRETURN_TYPE = "1"
                    Exit Try
                Else
                    lcInstallationKey = lcResult.Trim
                End If

                ' Code 5
                'lcQuery = "SELECT COUNT(1) AS NRESULT "
                'lcQuery += "FROM LAT_ACTIVATION (NOLOCK) "
                'lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                'lcQuery += "AND CAPPS_CODE = '{1}' "
                'lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                'lcQuery += "AND CSERVER_TYPE = '1' "
                'lcQuery += "AND CGENERATE_TIME = ( "
                'lcQuery += "SELECT TOP 1 CGENERATE_TIME "
                'lcQuery += "FROM LAT_ACTIVATION (NOLOCK) "
                'lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                'lcQuery += "AND CAPPS_CODE = '{1}' "
                'lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                'lcQuery += "AND CSERVER_TYPE = '1' "
                'lcQuery += "ORDER BY CGENERATE_TIME DESC) "
                'lcQuery += "AND NOT (CSTART_DATE < '{3}' AND CEXPIRY_DATE < '{4}') "
                'lcQuery = String.Format(lcQuery, poPar.CCOMPANY_ID, poPar.CAPPS_CODE, poPar.CCUSTOMER_CODE, poPar.CSTART_DATE, poPar.CEXPIRY_DATE)
                'lnResult = loDb.SqlExecObjectQuery(Of Integer)(lcQuery, loDb.GetConnection, False).FirstOrDefault
                'If lnResult > 0 Then
                '    .CRETURN_CODE = "500"
                '    .CDESCRIPTION = "Period overlap."
                '    .CRETURN_TYPE = "1"
                '    Exit Try
                'End If
                lcQuery = "SELECT COUNT(1) AS NRESULT "
                lcQuery += "FROM LAT_ACTIVATION_CLOUD (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                lcQuery += "AND CREFERENCE_NO = '{3}' "
                lcQuery = String.Format(lcQuery, poPar.CCOMPANY_ID, poPar.CAPPS_CODE, poPar.CCUSTOMER_CODE, poPar.CREFERENCE_NO)
                lnResult = loDb.SqlExecObjectQuery(Of Integer)(lcQuery, loDb.GetConnection, False).FirstOrDefault
                If lnResult > 0 Then
                    .CRETURN_CODE = "501"
                    .CDESCRIPTION = "Request has been made for the reference no."
                    .CRETURN_TYPE = "1"
                    Exit Try
                End If
                If Len(poPar.CREFERENCE_NO.Trim) = 0 Then
                    .CRETURN_CODE = "502"
                    .CDESCRIPTION = "Reference No. is empty."
                    .CRETURN_TYPE = "1"
                    Exit Try
                End If
                If Len(poPar.CREFERENCE_NO.Trim) > 50 Then
                    .CRETURN_CODE = "503"
                    .CDESCRIPTION = "Reference No. exceeds maximum length."
                    .CRETURN_TYPE = "1"
                    Exit Try
                End If
            End With

            ' Save Activation
            Dim loCls As New LAT00100Cls
            Dim loActivation As New LAT00100ActivationDTO

            With loActivation
                .CCOMPANY_ID = poPar.CCOMPANY_ID
                .CAPPS_CODE = poPar.CAPPS_CODE
                .CCUSTOMER_CODE = poPar.CCUSTOMER_CODE
                .CSERVER_TYPE = "1"
                .CSERVER_UID = lcInstallationKey
                .CSTART_DATE = poPar.CSTART_DATE
                .CEXPIRY_DATE = poPar.CEXPIRY_DATE
                .NGRACE_DAYS = poPar.NGRACE_DAYS
                .NWARNING_DAYS = poPar.NWARNING_DAYS
                .CREFERENCE_NO = poPar.CREFERENCE_NO
                .LACTIVATION_REQUEST = True
                .CUPDATE_BY = "OTCA" ' over-the-cloud activation
                .CCREATE_BY = "OTCA"
            End With

            loCls.SaveActivation(loActivation)

        Catch ex As Exception
            With loReturn
                .CRETURN_CODE = "999"
                .CDESCRIPTION = ex.Message
                .CRETURN_TYPE = "1"
            End With
        End Try

        Return loReturn
    End Function

    Public Function ActivationStatus(poPar As ActivationStatusParamDTO) As ActivationStatusReturnDTO
        Dim loReturn As New ActivationStatusReturnDTO
        Dim lcResult As String = Nothing
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim lcCheckPoint As String = "000"
        Try
            With loReturn
                .CRETURN_CODE = "000"
                .CDESCRIPTION = "Success."
                .CRETURN_TYPE = "0"

                lcCheckPoint = "001"
                lcQuery = "SELECT CACTIVATION_TYPE "
                lcQuery += "FROM RVM_APPLICATION (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery = String.Format(lcQuery, poPar.CCOMPANY_ID, poPar.CAPPS_CODE)
                lcResult = loDb.SqlExecObjectQuery(Of String)(lcQuery, loDb.GetConnection, False).FirstOrDefault
                If lcResult Is Nothing Then
                    .CRETURN_CODE = "202"
                    .CDESCRIPTION = "Application Code does not exist."
                    .CRETURN_TYPE = "1"
                    Exit Try
                Else
                    lcCheckPoint += "-lcResult"
                    .CACTIVATION_TYPE = lcResult
                End If

                lcCheckPoint = "002"
                lcQuery = "SELECT CASE LINSTALLED WHEN 1 THEN '1' ELSE '0' END + CASE LFETCHED WHEN 1 THEN '1' ELSE '0' END + '1' AS CRESULT "
                lcQuery += "FROM LAT_ACTIVATION_CLOUD (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                lcQuery += "AND CREFERENCE_NO = '{3}' "
                lcQuery = String.Format(lcQuery, poPar.CCOMPANY_ID, poPar.CAPPS_CODE, poPar.CCUSTOMER_CODE, poPar.CREFERENCE_NO)
                lcResult = loDb.SqlExecObjectQuery(Of String)(lcQuery, loDb.GetConnection, False).FirstOrDefault
                If lcResult Is Nothing Then
                    .CRETURN_CODE = "000"
                    .CDESCRIPTION = "Activation Code has not been generated."
                    .CRETURN_TYPE = "0"
                Else
                    .CRETURN_CODE = lcResult.Trim
                    .CRETURN_TYPE = "0"
                    Select Case lcResult
                        Case "001"
                            .CDESCRIPTION = "Activation Code is generated but no further action."
                        Case "011"
                            .CDESCRIPTION = "Activation Code has been fetched but not yet successfully installed."
                        Case "111"
                            .CDESCRIPTION = "Activation Code has been successfully installed."
                    End Select
                End If

            End With

        Catch ex As Exception
            With loReturn
                .CRETURN_CODE = "999"
                .CDESCRIPTION = ex.Message.Trim + " (CP: " + lcCheckPoint.Trim + ")"
                .CRETURN_TYPE = "1"
            End With
        End Try

        Return loReturn
    End Function

    Public Function ActivationCodeInstall(poPar As ActivationCodeInstallParamDTO) As ActivationCodeInstallReturnDTO
        Dim loReturn As New ActivationCodeInstallReturnDTO
        Dim lcResult As String = Nothing
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim lnResult As Integer
        Dim loResult As ActivationCodeInstallReturnDTO

        Try
            With loReturn
                .CRETURN_CODE = "000"
                .CDESCRIPTION = "Success."
                .CACTIVATION_CODE = ""
                .CRETURN_TYPE = "0"

                lcQuery = "SELECT CACTIVATION_TYPE "
                lcQuery += "FROM RVM_APPLICATION (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery = String.Format(lcQuery, poPar.CCOMPANY_ID, poPar.CAPPS_CODE)
                lcResult = loDb.SqlExecObjectQuery(Of String)(lcQuery, loDb.GetConnection, False).FirstOrDefault
                If lcResult Is Nothing Then
                    .CRETURN_CODE = "202"
                    .CDESCRIPTION = "Application Code does not exist."
                    .CRETURN_TYPE = "1"
                    Exit Try
                Else
                    .CACTIVATION_TYPE = lcResult
                End If

                lcQuery = "SELECT "
                lcQuery += "B.CACTIVATION_CODE AS CACTIVATION_CODE, B.CSERVER_UID AS CSERIAL_NO, B.CEXPIRY_DATE, "
                lcQuery += "B.NGRACE_DAYS, B.NWARNING_DAYS "
                lcQuery += "FROM LAT_ACTIVATION_CLOUD A (NOLOCK) "
                lcQuery += "JOIN LAT_ACTIVATION B (NOLOCK) "
                lcQuery += "ON B.CCOMPANY_ID = A.CCOMPANY_ID "
                lcQuery += "AND B.CAPPS_CODE = A.CAPPS_CODE "
                lcQuery += "AND B.CCUSTOMER_CODE = A.CCUSTOMER_CODE "
                lcQuery += "AND B.CGENERATE_TIME = A.CGENERATE_TIME "
                lcQuery += "WHERE A.CCOMPANY_ID = '{0}' "
                lcQuery += "AND A.CAPPS_CODE = '{1}' "
                lcQuery += "AND A.CCUSTOMER_CODE = '{2}' "
                lcQuery += "AND A.CREFERENCE_NO = '{3}' "
                lcQuery = String.Format(lcQuery, poPar.CCOMPANY_ID, poPar.CAPPS_CODE, poPar.CCUSTOMER_CODE, poPar.CREFERENCE_NO)
                loResult = loDb.SqlExecObjectQuery(Of ActivationCodeInstallReturnDTO)(lcQuery, loDb.GetConnection, False).FirstOrDefault
                If lcResult Is Nothing Then
                    .CRETURN_CODE = "000"
                    .CDESCRIPTION = "Activation Code has not been generated."
                    .CACTIVATION_CODE = ""
                    .CRETURN_TYPE = "0"
                Else
                    If poPar.CACTION = "FETCH_CODE" Then
                        .CACTIVATION_CODE = loResult.CACTIVATION_CODE
                        .CSERIAL_NO = loResult.CSERIAL_NO
                        .CEXPIRY_DATE = loResult.CEXPIRY_DATE
                        .NGRACE_DAYS = loResult.NGRACE_DAYS
                        .NWARNING_DAYS = loResult.NWARNING_DAYS
                    End If
                End If

                If Not (poPar.CACTION.Trim = "FETCH_CODE" Or poPar.CACTION.Trim = "INSTALL_SUCCESS") Then
                    .CRETURN_CODE = "200"
                    .CDESCRIPTION = "Invalid action code."
                    .CACTIVATION_CODE = ""
                    .CRETURN_TYPE = "0"
                End If

                ' Change status
                lcQuery = "UPDATE LAT_ACTIVATION_CLOUD "
                If poPar.CACTION = "FETCH_CODE" Then
                    lcQuery += "SET LFETCHED = 1, DFETCH_DATE = GETDATE(), "
                ElseIf poPar.CACTION = "INSTALL_SUCCESS" Then
                    lcQuery += "SET LINSTALLED = 1, DINSTALL_DATE = GETDATE(), "
                End If
                lcQuery += "CUPDATE_BY = 'OTCA', DUPDATE_DATE = GETDATE() "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                lcQuery += "AND CREFERENCE_NO = '{3}' "
                lcQuery = String.Format(lcQuery, poPar.CCOMPANY_ID, poPar.CAPPS_CODE, poPar.CCUSTOMER_CODE, poPar.CREFERENCE_NO)
                lnResult = loDb.SqlExecNonQuery(lcQuery)

                If poPar.CACTION = "FETCH_CODE" Then
                    .CRETURN_CODE = "011"
                    .CDESCRIPTION = "Activation Code status is FETCHED."
                    .CRETURN_TYPE = "0"
                ElseIf poPar.CACTION = "INSTALL_SUCCESS" Then
                    .CRETURN_CODE = "111"
                    .CDESCRIPTION = "Activation Code status is INSTALLED."
                    .CRETURN_TYPE = "0"
                End If

            End With

        Catch ex As Exception
            With loReturn
                .CRETURN_CODE = "999"
                .CDESCRIPTION = ex.Message
                .CRETURN_TYPE = "1"
            End With
        End Try

        Return loReturn

    End Function

    Public Function GetStagingData(poTableKey As LAT00110KeyDTO) As List(Of LAT00110StagingDTO)
        Dim lcQuery As String
        Dim loResult As List(Of LAT00110StagingDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poTableKey

                lcQuery = "SELECT B.CCUSTOMER_NAME, C.CSTART_DATE, C.CEXPIRY_DATE, C.CACTIVATION_CODE, A.* "
                lcQuery += "FROM LAT_ACTIVATION_CLOUD A (NOLOCK) "
                lcQuery += "JOIN LAM_CUSTOMER B (NOLOCK) "
                lcQuery += "ON B.CCOMPANY_ID = A.CCOMPANY_ID "
                lcQuery += "AND B.CCUSTOMER_CODE = A.CCUSTOMER_CODE "
                lcQuery += "JOIN LAT_ACTIVATION C (NOLOCK) "
                lcQuery += "ON C.CCOMPANY_ID = A.CCOMPANY_ID "
                lcQuery += "AND C.CAPPS_CODE = A.CAPPS_CODE "
                lcQuery += "AND C.CCUSTOMER_CODE = A.CCUSTOMER_CODE "
                lcQuery += "AND C.CGENERATE_TIME = A.CGENERATE_TIME "
                lcQuery += "WHERE A.CCOMPANY_ID = '{0}' "
                lcQuery += "AND A.CAPPS_CODE = '{1}' "
                lcQuery += "ORDER BY CGENERATE_TIME DESC "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE)
            End With

            loResult = loDb.SqlExecObjectQuery(Of LAT00110StagingDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

End Class
