﻿Public Class ActivationStatusParamDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CCUSTOMER_CODE As String
    Public Property CREFERENCE_NO As String
End Class
