﻿Public Class LAT00110StagingDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CCUSTOMER_CODE As String
    Public Property CGENERATE_TIME As String
    Public Property CREFERENCE_NO As String
    Public Property CCUSTOMER_NAME As String
    Public Property CSTART_DATE As String
    Public Property CEXPIRY_DATE As String
    Public Property CACTIVATION_CODE As String
    Public Property LFETCHED As Boolean
    Public Property DFETCH_DATE As Nullable(Of DateTime)
    Public Property LINSTALLED As Boolean
    Public Property DINSTALL_DATE As Nullable(Of DateTime)

    Public Property DSTART_DATE As Nullable(Of DateTime)
    Public Property DEXPIRY_DATE As Nullable(Of DateTime)

End Class
