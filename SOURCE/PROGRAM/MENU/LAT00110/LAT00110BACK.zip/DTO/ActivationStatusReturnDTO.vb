﻿Public Class ActivationStatusReturnDTO
    Public Property CRETURN_CODE As String
    Public Property CDESCRIPTION As String
    Public Property CACTIVATION_TYPE As String
    Public Property CRETURN_TYPE As String
End Class
