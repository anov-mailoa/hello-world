﻿Imports R_BackEnd

'<Serializable()> _
Public Class ButtonDTO
    Inherits R_DTOBase

    Public Property LSELECTED As Boolean
    Public Property CBUTTON_ID As String
    Public Property CBUTTON_DESCRIPTION_ID As String
    Public Property CBUTTON_DESCRIPTION As String
End Class
