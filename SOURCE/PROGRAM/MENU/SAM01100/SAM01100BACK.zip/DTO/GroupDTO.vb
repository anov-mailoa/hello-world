﻿Imports R_BackEnd

<Serializable()> _
Public Class GroupDTO
    Inherits R_DTOBase

    Public Property CGROUP_ID As String
    Public Property CGROUP_NAME As String
End Class
