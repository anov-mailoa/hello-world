﻿Imports R_BackEnd

'<Serializable()> _
Public Class ProgramDTO
    Inherits R_DTOBase

    Public Property CPROGRAM_ID As String
    Public Property CPROGRAM_NAME As String
    Public Property CMODULE_NAME As String
End Class
