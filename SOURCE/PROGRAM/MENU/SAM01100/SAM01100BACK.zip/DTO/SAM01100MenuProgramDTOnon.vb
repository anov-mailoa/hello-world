﻿Imports R_BackEnd

Public Class SAM01100MenuProgramDTOnon
    Inherits R_DTOBase

    Public Property CPROGRAM_ID As String
    Public Property CPROGRAM_NAME As String
    Public Property CPROGRAM_ACCESS As String
    Public Property CBUTTON_ACCESS As String

    Public Property CFLAG_SENDER As String
    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)
End Class
