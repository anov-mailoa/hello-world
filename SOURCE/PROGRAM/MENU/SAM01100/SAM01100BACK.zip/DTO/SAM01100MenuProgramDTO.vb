﻿Imports R_BackEnd

<Serializable()> _
Public Class SAM01100MenuProgramDTO
    Inherits R_DTOBase

    Public Property CCOMPANY_ID As String
    Public Property CMENU_ID As String
    Public Property CPROGRAM_ID As String
    Public Property CPROGRAM_NAME As String
    Public Property CPROGRAM_ACCESS As String
    Public Property CBUTTON_ACCESS As String

    Public Property CACCESS_ID As String

    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)

    Public Property DDATE As String
    Public Property CUSERID As String
End Class
