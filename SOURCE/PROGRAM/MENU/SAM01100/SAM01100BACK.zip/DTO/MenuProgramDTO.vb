﻿Public Class MenuProgramDTO
    Public Property CUSER_ID As String
    Public Property CSUB_MENU_ID As String
    Public Property IGROUP_INDEX As Integer
    Public Property IMAXCOL As Integer
    Public Property IMAXROW As Integer
End Class
