﻿Imports R_Common
Imports R_BackEnd
Imports System.Data.Common
Imports SAM01100Common
Imports System.Transactions

Public Class SAM01100MenuProgramCls
    Inherits R_BusinessObject(Of SAM01100MenuProgramDTO)

    Implements R_IBatchProcess

    Protected Overrides Sub R_Deleting(poEntity As SAM01100MenuProgramDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim lcGroupName As String
        Dim loResult As SAM01100MenuProgramDTO
        Dim loUser As New List(Of MenuProgramDTO)

        Try
            loConn = loDb.GetConnection()

            With poEntity
                'delete from SAM_MENU_PROGRAM
                lcQuery = "DELETE SAM_MENU_PROGRAM "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' AND CMENU_ID = '{1}' AND CPROGRAM_ID = '{2}'"
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CMENU_ID, .CPROGRAM_ID)
                loDb.SqlExecNonQuery(lcQuery, loConn, False)

                'delete from SAM_PROGRAM_ACCESS
                'lcQuery = "DELETE SAM_PROGRAM_ACCESS "
                'lcQuery += "WHERE CCOMPANY_ID = '{0}' AND CPROGRAM_ID = '{1}'"
                'lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CPROGRAM_ID)
                'loDb.SqlExecNonQuery(lcQuery, loConn, False)

                'delete from SAM_USER_PROGRAM
                lcQuery = "DELETE SAM_USER_PROGRAM "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' AND CMENU_ID = '{1}' AND CSUB_MENU_ID = '{2}'"
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CMENU_ID, .CPROGRAM_ID)
                loDb.SqlExecNonQuery(lcQuery, loConn, False)

                'get program module
                lcGroupName = .CPROGRAM_ID.Substring(2, 1)
                If lcGroupName = "M" Then
                    lcGroupName = "MASTER"
                ElseIf lcGroupName = "T" Then
                    lcGroupName = "TRANS"
                ElseIf lcGroupName = "I" Then
                    lcGroupName = "INQUI"
                ElseIf lcGroupName = "B" Then
                    lcGroupName = "BATCH"
                ElseIf lcGroupName = "R" Then
                    lcGroupName = "REPORT"
                End If

                'delete group if all program has been deleted on that group
                lcQuery = "SELECT A.CSUB_MENU_ID AS CPROGRAM_ID "
                lcQuery += "FROM SAM_USER_PROGRAM A (NOLOCK) "
                lcQuery += "WHERE A.CCOMPANY_ID = '{0}' AND A.CMENU_ID = '{1}' AND A.CPARENT_SUB_MENU_ID = '{2}' AND A.CSUB_MENU_TYPE = '{3}'"
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CMENU_ID, lcGroupName, "P")
                loResult = loDb.SqlExecObjectQuery(Of SAM01100MenuProgramDTO)(lcQuery, loConn, False).FirstOrDefault

                If loResult Is Nothing Then
                    'select all user have permission to access menu
                    lcQuery = "SELECT A.CUSER_ID "
                    lcQuery += "FROM SAM_USER_PROGRAM A (NOLOCK) "
                    lcQuery += "WHERE A.CCOMPANY_ID = '{0}' AND A.CMENU_ID = '{1}' AND A.CPARENT_SUB_MENU_ID = '{2}' AND A.CSUB_MENU_TYPE = '{3}' AND A.CSUB_MENU_ID = '{4}' "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CMENU_ID, "ROOT", "G", lcGroupName)
                    loUser = loDb.SqlExecObjectQuery(Of MenuProgramDTO)(lcQuery, loConn, False)

                    For Each oUser As MenuProgramDTO In loUser
                        'update all group index
                        lcQuery = "UPDATE SAM_USER_PROGRAM "
                        lcQuery += "SET IGROUP_INDEX = IGROUP_INDEX - 1 "
                        lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                        lcQuery += "AND CUSER_ID = '{1}' "
                        lcQuery += "AND CMENU_ID = '{2}' "
                        lcQuery += "AND CPARENT_SUB_MENU_ID = ( "
                        lcQuery += "SELECT CPARENT_SUB_MENU_ID "
                        lcQuery += "FROM SAM_USER_PROGRAM (NOLOCK) "
                        lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                        lcQuery += "AND CUSER_ID = '{1}' "
                        lcQuery += "AND CMENU_ID = '{2}' "
                        lcQuery += "AND CSUB_MENU_TYPE = '{3}' "
                        lcQuery += "AND CSUB_MENU_ID = '{4}') "
                        lcQuery += "AND IGROUP_INDEX > ( "
                        lcQuery += "SELECT IGROUP_INDEX FROM SAM_USER_PROGRAM (NOLOCK) "
                        lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                        lcQuery += "AND CUSER_ID = '{1}' "
                        lcQuery += "AND CMENU_ID = '{2}' "
                        lcQuery += "AND CSUB_MENU_TYPE = '{3}' "
                        lcQuery += "AND CSUB_MENU_ID = '{4}') "
                        lcQuery = String.Format(lcQuery, .CCOMPANY_ID, oUser.CUSER_ID, .CMENU_ID, "G", lcGroupName)
                        loDb.SqlExecNonQuery(lcQuery, loConn, False)
                    Next

                    'delete group
                    lcQuery = "DELETE SAM_USER_PROGRAM "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' AND CMENU_ID = '{1}' AND CSUB_MENU_TYPE = '{2}' AND CSUB_MENU_ID = '{3}' AND CPARENT_SUB_MENU_ID = '{4}'"
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CMENU_ID, "G", lcGroupName, "ROOT")
                    loDb.SqlExecNonQuery(lcQuery, loConn, False)
                End If
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As SAM01100MenuProgramDTO) As SAM01100MenuProgramDTO
        Dim lcQuery As String
        Dim loResult As SAM01100MenuProgramDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT A.CPROGRAM_ID, B.CPROGRAM_NAME, A.CPROGRAM_ACCESS, "
            lcQuery += "A.CCREATE_BY, A.DCREATE_DATE, A.CUPDATE_BY, A.DUPDATE_DATE "
            lcQuery += "FROM SAM_MENU_PROGRAM A (NOLOCK) "
            lcQuery += "INNER JOIN SAM_PROGRAM B (NOLOCK) "
            lcQuery += "ON B.CPROGRAM_ID = A.CPROGRAM_ID "
            lcQuery += "WHERE A.CCOMPANY_ID = '{0}' AND A.CMENU_ID = '{1}' AND A.CPROGRAM_ID = '{2}'"
            lcQuery = String.Format(lcQuery, poEntity.CCOMPANY_ID, poEntity.CMENU_ID, poEntity.CPROGRAM_ID)

            loResult = loDb.SqlExecObjectQuery(Of SAM01100MenuProgramDTO)(lcQuery).FirstOrDefault
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As SAM01100MenuProgramDTO, poCRUDMode As R_Common.eCRUDMode)
        
    End Sub

    Public Sub R_BatchProcess(poBatchProcessPar As R_Common.R_BatchProcessPar) Implements R_Common.R_IBatchProcess.R_BatchProcess
        Dim loEx As New R_Exception()
        Dim loObject As List(Of SAM01100BatchDTO)
        Dim loDb As New R_Db
        Dim lcQuery As String
        Dim loResult As SAM01100MenuProgramDTO
        Dim loConn As DbConnection
        Dim CUSER_ID As String
        Dim DDATE As DateTime
        Dim loMapping As New Dictionary(Of String, String)()
        Dim countLoop As Integer = 0
        Dim CMENU_ID As String
        Dim CCOMP_ID As String
        Dim oCls As New SAM01100Cls
        Dim loRtn As New List(Of SAM01100MenuProgramDTOnon)

        Try
            'get all program
            loObject = R_Utility.Deserialize(poBatchProcessPar.BigObject)
            DDATE = poBatchProcessPar.UserParameters.Where(Function(x) x.Key.Equals("DDATE")).FirstOrDefault.Value
            CMENU_ID = poBatchProcessPar.UserParameters.Where(Function(x) x.Key.Equals("CMENU_ID")).FirstOrDefault.Value
            CCOMP_ID = poBatchProcessPar.Key.COMPANY_ID
            CUSER_ID = poBatchProcessPar.Key.USER_ID

            'delete program if not exist in loObject
            Using TransScope As New TransactionScope(TransactionScopeOption.Required)
                loRtn = oCls.getMenuProgramList(CCOMP_ID, CMENU_ID)
                loConn = loDb.GetConnection()

                For Each save As SAM01100MenuProgramDTOnon In loRtn
                    Dim loQuery = loObject.Where(Function(x) x.CPROGRAM_ID = save.CPROGRAM_ID).FirstOrDefault
                    Dim lcGroupName As String

                    'check deleted program
                    If loQuery Is Nothing Then
                        'delete from SAM_MENU_PROGRAM
                        lcQuery = "DELETE SAM_MENU_PROGRAM "
                        lcQuery += "WHERE CCOMPANY_ID = '{0}' AND CMENU_ID = '{1}' AND CPROGRAM_ID = '{2}'"
                        lcQuery = String.Format(lcQuery, CCOMP_ID, CMENU_ID, save.CPROGRAM_ID)
                        loDb.SqlExecNonQuery(lcQuery, loConn, False)

                        'delete from SAM_PROGRAM_ACCESS
                        'lcQuery = "DELETE SAM_PROGRAM_ACCESS "
                        'lcQuery += "WHERE CCOMPANY_ID = '{0}' AND CPROGRAM_ID = '{1}'"
                        'lcQuery = String.Format(lcQuery, CCOMP_ID, save.CPROGRAM_ID)
                        'loDb.SqlExecNonQuery(lcQuery, loConn, False)

                        'delete from SAM_USER_PROGRAM
                        lcQuery = "DELETE SAM_USER_PROGRAM "
                        lcQuery += "WHERE CCOMPANY_ID = '{0}' AND CMENU_ID = '{1}' AND CSUB_MENU_ID = '{2}'"
                        lcQuery = String.Format(lcQuery, CCOMP_ID, CMENU_ID, save.CPROGRAM_ID)
                        loDb.SqlExecNonQuery(lcQuery, loConn, False)

                        'get program module
                        lcGroupName = save.CPROGRAM_ID.Substring(2, 1)
                        If lcGroupName = "M" Then
                            lcGroupName = "MASTER"
                        ElseIf lcGroupName = "T" Then
                            lcGroupName = "TRANS"
                        ElseIf lcGroupName = "I" Then
                            lcGroupName = "INQUI"
                        ElseIf lcGroupName = "B" Then
                            lcGroupName = "BATCH"
                        ElseIf lcGroupName = "R" Then
                            lcGroupName = "REPORT"
                        End If

                        'delete group if all program has been deleted on that group
                        lcQuery = "SELECT A.CSUB_MENU_ID AS CPROGRAM_ID "
                        lcQuery += "FROM SAM_USER_PROGRAM A (NOLOCK) "
                        lcQuery += "WHERE A.CCOMPANY_ID = '{0}' AND A.CMENU_ID = '{1}' AND A.CPARENT_SUB_MENU_ID = '{2}' AND A.CSUB_MENU_TYPE = '{3}'"
                        lcQuery = String.Format(lcQuery, CCOMP_ID, CMENU_ID, lcGroupName, "P")
                        loResult = loDb.SqlExecObjectQuery(Of SAM01100MenuProgramDTO)(lcQuery, loConn, False).FirstOrDefault

                        If loResult Is Nothing Then
                            'update all group index
                            lcQuery = "UPDATE SAM_USER_PROGRAM "
                            lcQuery += "SET IGROUP_INDEX = IGROUP_INDEX - 1 "
                            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                            lcQuery += "AND CUSER_ID = '{1}' "
                            lcQuery += "AND CMENU_ID = '{2}' "
                            lcQuery += "AND CPARENT_SUB_MENU_ID = ( "
                            lcQuery += "SELECT CPARENT_SUB_MENU_ID "
                            lcQuery += "FROM SAM_USER_PROGRAM (NOLOCK) "
                            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                            lcQuery += "AND CUSER_ID = '{1}' "
                            lcQuery += "AND CMENU_ID = '{2}' "
                            lcQuery += "AND CSUB_MENU_TYPE = '{3}' "
                            lcQuery += "AND CSUB_MENU_ID = '{4}') "
                            lcQuery += "AND IGROUP_INDEX > ( "
                            lcQuery += "SELECT IGROUP_INDEX FROM SAM_USER_PROGRAM (NOLOCK) "
                            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                            lcQuery += "AND CUSER_ID = '{1}' "
                            lcQuery += "AND CMENU_ID = '{2}' "
                            lcQuery += "AND CSUB_MENU_TYPE = '{3}' "
                            lcQuery += "AND CSUB_MENU_ID = '{4}') "
                            lcQuery = String.Format(lcQuery, CCOMP_ID, CUSER_ID, CMENU_ID, "G", lcGroupName)
                            loDb.SqlExecNonQuery(lcQuery, loConn, False)

                            'delete group
                            lcQuery = "DELETE SAM_USER_PROGRAM "
                            lcQuery += "WHERE CCOMPANY_ID = '{0}' AND CMENU_ID = '{1}' AND CSUB_MENU_TYPE = '{2}' AND CSUB_MENU_ID = '{3}' AND CPARENT_SUB_MENU_ID = '{4}'"
                            lcQuery = String.Format(lcQuery, CCOMP_ID, CMENU_ID, "G", lcGroupName, "ROOT")
                            loDb.SqlExecNonQuery(lcQuery, loConn, False)
                        End If
                    End If
                Next

                TransScope.Complete()
            End Using

            Using TransScope As New TransactionScope(TransactionScopeOption.Required)
                Dim iRow As Integer = 0
                Dim iCol As Integer = 0
                For Each save As SAM01100BatchDTO In loObject
                    Dim lcGroupName As String
                    lcQuery = "exec RSP_WriteUploadProcessStatus '{0}', '{1}', '{2}', '{3}', '{4}'"
                    lcQuery = String.Format(lcQuery, CCOMP_ID, CUSER_ID, poBatchProcessPar.Key.KEY_GUID.Trim, countLoop, "Save " + save.CPROGRAM_ID)
                    loDb.SqlExecNonQuery(lcQuery, loConn, False)

                    lcQuery = "SELECT A.CPROGRAM_ID, B.CPROGRAM_NAME, B.CMODULE_NAME, "
                    lcQuery += "A.CCREATE_BY, A.DCREATE_DATE, A.CUPDATE_BY, A.DUPDATE_DATE "
                    lcQuery += "FROM SAM_MENU_PROGRAM A (NOLOCK) "
                    lcQuery += "INNER JOIN SAM_PROGRAM B "
                    lcQuery += "ON B.CPROGRAM_ID = A.CPROGRAM_ID "
                    lcQuery += "WHERE A.CCOMPANY_ID = '{0}' AND A.CMENU_ID = '{1}' AND A.CPROGRAM_ID = '{2}'"
                    lcQuery = String.Format(lcQuery, CCOMP_ID, CMENU_ID, save.CPROGRAM_ID)
                    loResult = loDb.SqlExecObjectQuery(Of SAM01100MenuProgramDTO)(lcQuery, loConn, False).FirstOrDefault

                    If loResult Is Nothing Then
                        Dim oAccessResult As New SAM01100MenuProgramDTO
                        'select access from SAM_PROGRAM_ACCESS to get default access
                        lcQuery = "SELECT CPROGRAM_ACCESS = A.CACCESS_ID, CBUTTON_ACCESS = B.CACCESS_ID "
                        lcQuery += "FROM SAM_PROGRAM_ACCESS A "
                        lcQuery += "INNER JOIN SAM_PROGRAM_ACCESS B "
                        lcQuery += "ON B.CPROGRAM_ID = A.CPROGRAM_ID AND B.CCOMPANY_ID = A.CCOMPANY_ID "
                        lcQuery += "WHERE A.CCOMPANY_ID = '{0}' AND A.CPROGRAM_ID = '{1}' AND A.CACCESS_TYPE = 'GENERAL' AND B.CACCESS_TYPE = 'BUTTON' "
                        lcQuery = String.Format(lcQuery, CCOMP_ID, save.CPROGRAM_ID)
                        oAccessResult = loDb.SqlExecObjectQuery(Of SAM01100MenuProgramDTO)(lcQuery, loConn, False).FirstOrDefault

                        If oAccessResult Is Nothing Then
                            oAccessResult = New SAM01100MenuProgramDTO
                            'insert into SAM_PROGRAM_ACCESS if not exist (GENERAL)
                            'If oAccessResult.CPROGRAM_ACCESS Is Nothing Then
                            lcQuery = "INSERT INTO SAM_PROGRAM_ACCESS "
                            lcQuery += "(CCOMPANY_ID, CPROGRAM_ID, CACCESS_TYPE, CACCESS_ID, CCREATE_BY, DCREATE_DATE) "
                            lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', GETDATE()) "
                            lcQuery = String.Format(lcQuery, CCOMP_ID, save.CPROGRAM_ID, "GENERAL", "A,U,D,P,V", "System")
                            loDb.SqlExecNonQuery(lcQuery, loConn, False)
                            oAccessResult.CPROGRAM_ACCESS = "A,U,D,P,V"
                            'End If

                            'insert into SAM_PROGRAM_ACCESS if not exist (BUTTON)
                            'If oAccessResult.CBUTTON_ACCESS Is Nothing Then
                            lcQuery = "INSERT INTO SAM_PROGRAM_ACCESS "
                            lcQuery += "(CCOMPANY_ID, CPROGRAM_ID, CACCESS_TYPE, CACCESS_ID, CCREATE_BY, DCREATE_DATE) "
                            lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', GETDATE()) "
                            lcQuery = String.Format(lcQuery, CCOMP_ID, save.CPROGRAM_ID, "BUTTON", "", "System")
                            loDb.SqlExecNonQuery(lcQuery, loConn, False)
                            oAccessResult.CBUTTON_ACCESS = ""
                            'End If
                        End If

                        'insert into SAM_MENU_PROGRAM
                        lcQuery = "INSERT INTO SAM_MENU_PROGRAM (CCOMPANY_ID, CMENU_ID, CPROGRAM_ID, CCREATE_BY, DCREATE_DATE, CPROGRAM_ACCESS, CPROGRAM_ACCESS_BUTTON, CUPDATE_BY, DUPDATE_DATE) "
                        lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', GETDATE(), '{4}', '{5}', '{3}', GETDATE())"
                        lcQuery = String.Format(lcQuery, CCOMP_ID, CMENU_ID, save.CPROGRAM_ID, CUSER_ID, oAccessResult.CPROGRAM_ACCESS, oAccessResult.CBUTTON_ACCESS)
                        loDb.SqlExecNonQuery(lcQuery, loConn, False)

                        'insert into SAM_PROGRAM_ACCESS

                        'get program module
                        Dim loMenuGroupList As New List(Of GroupDTO)
                        Dim loGroup As New GroupDTO
                        Dim loUserList As New List(Of MenuProgramDTO)
                        Dim loUser As New MenuProgramDTO

                        loMenuGroupList = getGroup()

                        lcGroupName = save.CPROGRAM_ID.Substring(2, 1)
                        If lcGroupName = "M" Then
                            loGroup = loMenuGroupList.Where(Function(x) x.CGROUP_ID = "MASTER").Select(Function(x) x).FirstOrDefault
                        ElseIf lcGroupName = "T" Then
                            loGroup = loMenuGroupList.Where(Function(x) x.CGROUP_ID = "TRANS").Select(Function(x) x).FirstOrDefault
                        ElseIf lcGroupName = "I" Then
                            loGroup = loMenuGroupList.Where(Function(x) x.CGROUP_ID = "INQUI").Select(Function(x) x).FirstOrDefault
                        ElseIf lcGroupName = "B" Then
                            loGroup = loMenuGroupList.Where(Function(x) x.CGROUP_ID = "BATCH").Select(Function(x) x).FirstOrDefault
                        ElseIf lcGroupName = "R" Then
                            loGroup = loMenuGroupList.Where(Function(x) x.CGROUP_ID = "REPORT").Select(Function(x) x).FirstOrDefault
                        End If

                        'get all user 
                        lcQuery = "SELECT DISTINCT A.CUSER_ID "
                        lcQuery += "FROM SAM_USER_PROGRAM A (NOLOCK) "
                        lcQuery += "WHERE A.CCOMPANY_ID = '{0}' AND A.CMENU_ID = '{1}'"
                        lcQuery = String.Format(lcQuery, CCOMP_ID, CMENU_ID)
                        loUserList = loDb.SqlExecObjectQuery(Of MenuProgramDTO)(lcQuery, loConn, False)

                        For Each oUser As MenuProgramDTO In loUserList
                            'check group if exist
                            lcQuery = "SELECT A.CSUB_MENU_ID, A.IGROUP_INDEX "
                            lcQuery += "FROM SAM_USER_PROGRAM A (NOLOCK) "
                            lcQuery += "WHERE A.CCOMPANY_ID = '{0}' AND A.CMENU_ID = '{1}' AND A.CSUB_MENU_TYPE = '{2}' AND A.CSUB_MENU_ID = '{3}' AND A.CUSER_ID = '{4}'"
                            lcQuery = String.Format(lcQuery, CCOMP_ID, CMENU_ID, "G", loGroup.CGROUP_ID, oUser.CUSER_ID)
                            loUser = loDb.SqlExecObjectQuery(Of MenuProgramDTO)(lcQuery, loConn, False).FirstOrDefault

                            If loUser Is Nothing Then

                                'get last group index
                                lcQuery = "SELECT A.IGROUP_INDEX "
                                lcQuery += "FROM SAM_USER_PROGRAM A (NOLOCK) "
                                lcQuery += "WHERE A.CCOMPANY_ID = '{0}' AND A.CMENU_ID = '{1}' AND A.CSUB_MENU_TYPE = '{2}' AND A.CUSER_ID = '{3}' "
                                lcQuery += "ORDER BY IGROUP_INDEX DESC "
                                lcQuery = String.Format(lcQuery, CCOMP_ID, CMENU_ID, "G", oUser.CUSER_ID)
                                Dim loGrpIndex = loDb.SqlExecObjectQuery(Of MenuProgramDTO)(lcQuery, loConn, False).FirstOrDefault

                                'insert group if not exist
                                lcQuery = "INSERT INTO SAM_USER_PROGRAM (CCOMPANY_ID, CUSER_ID, CMENU_ID, CSUB_MENU_TYPE, CSUB_MENU_ID, "
                                lcQuery += "CSUB_MENU_NAME, IGROUP_INDEX, IROW_INDEX, ICOLUMN_INDEX, LFAVORITE, IFAVORITE_INDEX, CPARENT_SUB_MENU_ID, "
                                lcQuery += "ILEVEL, CCREATE_BY, DCREATE_DATE) "
                                lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}', '{13}', {14}) "
                                lcQuery = String.Format(lcQuery, CCOMP_ID, oUser.CUSER_ID, CMENU_ID, "G", loGroup.CGROUP_ID, loGroup.CGROUP_NAME, loGrpIndex.IGROUP_INDEX + 1, _
                                                        0, 0, 0, 0, "ROOT", 1, CUSER_ID, getDate(DDATE))
                                loDb.SqlExecNonQuery(lcQuery, loConn, False)

                                'get program name 
                                lcQuery = "SELECT A.CPROGRAM_NAME "
                                lcQuery += "FROM SAM_PROGRAM A (NOLOCK) "
                                lcQuery += "WHERE A.CPROGRAM_ID = '{0}' "
                                lcQuery = String.Format(lcQuery, save.CPROGRAM_ID)
                                Dim loProgName = loDb.SqlExecObjectQuery(Of SAM01100MenuProgramDTO)(lcQuery, loConn, False).FirstOrDefault

                                'insert into SAM_USER_PROGRAM into group
                                lcQuery = "INSERT INTO SAM_USER_PROGRAM (CCOMPANY_ID, CUSER_ID, CMENU_ID, CSUB_MENU_TYPE, CSUB_MENU_ID, "
                                lcQuery += "CSUB_MENU_NAME, IGROUP_INDEX, IROW_INDEX, ICOLUMN_INDEX, LFAVORITE, IFAVORITE_INDEX, CPARENT_SUB_MENU_ID, "
                                lcQuery += "ILEVEL, CCREATE_BY, DCREATE_DATE) "
                                lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}', '{13}', {14}) "
                                lcQuery = String.Format(lcQuery, CCOMP_ID, oUser.CUSER_ID, CMENU_ID, "P", save.CPROGRAM_ID, loProgName.CPROGRAM_NAME, loGrpIndex.IGROUP_INDEX + 1, _
                                                        0, 0, 0, 0, loGroup.CGROUP_ID, 1, CUSER_ID, getDate(DDATE))
                                loDb.SqlExecNonQuery(lcQuery, loConn, False)
                            Else
                                'get program name 
                                lcQuery = "SELECT A.CPROGRAM_NAME "
                                lcQuery += "FROM SAM_PROGRAM A (NOLOCK) "
                                lcQuery += "WHERE A.CPROGRAM_ID = '{0}' "
                                lcQuery = String.Format(lcQuery, save.CPROGRAM_ID)
                                Dim loProgName = loDb.SqlExecObjectQuery(Of SAM01100MenuProgramDTO)(lcQuery, loConn, False).FirstOrDefault

                                lcQuery = "SELECT A.CMENU_ID, MAX(A.ICOLUMN_INDEX) AS IMAXCOL "
                                lcQuery += "FROM SAM_USER_PROGRAM A (NOLOCK) "
                                lcQuery += "WHERE A.CCOMPANY_ID = '{0}' AND A.CMENU_ID = '{1}' AND A.CSUB_MENU_TYPE = '{2}' AND A.CUSER_ID = '{3}' AND A.IGROUP_INDEX = '{4}' "
                                lcQuery += "GROUP BY CMENU_ID "
                                lcQuery = String.Format(lcQuery, CCOMP_ID, CMENU_ID, "P", oUser.CUSER_ID, loUser.IGROUP_INDEX)
                                Dim loMaxIndex = loDb.SqlExecObjectQuery(Of MenuProgramDTO)(lcQuery, loConn, False).FirstOrDefault

                                If loMaxIndex Is Nothing Then
                                    iCol = 0
                                Else
                                    iCol = loMaxIndex.IMAXCOL
                                End If

                                lcQuery = "SELECT A.CMENU_ID, MAX(A.IROW_INDEX) AS IMAXROW "
                                lcQuery += "FROM SAM_USER_PROGRAM A (NOLOCK) "
                                lcQuery += "WHERE A.CCOMPANY_ID = '{0}' AND A.CMENU_ID = '{1}' AND A.CSUB_MENU_TYPE = '{2}' AND A.CUSER_ID = '{3}' AND A.IGROUP_INDEX = '{4}' AND A.ICOLUMN_INDEX = '{5}' "
                                lcQuery += "GROUP BY CMENU_ID "
                                lcQuery = String.Format(lcQuery, CCOMP_ID, CMENU_ID, "P", oUser.CUSER_ID, loUser.IGROUP_INDEX, iCol)
                                Dim loMaxRow = loDb.SqlExecObjectQuery(Of MenuProgramDTO)(lcQuery, loConn, False).FirstOrDefault

                                If loMaxRow Is Nothing Then
                                    iRow = 0
                                Else
                                    iRow = loMaxRow.IMAXROW

                                    If iRow = 3 Then
                                        iCol += 1
                                        iRow = 0
                                    Else
                                        iRow += 1
                                    End If
                                End If

                                'insert into SAM_USER_PROGRAM into group
                                lcQuery = "INSERT INTO SAM_USER_PROGRAM (CCOMPANY_ID, CUSER_ID, CMENU_ID, CSUB_MENU_TYPE, CSUB_MENU_ID, "
                                lcQuery += "CSUB_MENU_NAME, IGROUP_INDEX, IROW_INDEX, ICOLUMN_INDEX, LFAVORITE, IFAVORITE_INDEX, CPARENT_SUB_MENU_ID, "
                                lcQuery += "ILEVEL, CCREATE_BY, DCREATE_DATE) "
                                lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}', '{13}', {14}) "
                                lcQuery = String.Format(lcQuery, CCOMP_ID, oUser.CUSER_ID, CMENU_ID, "P", save.CPROGRAM_ID, loProgName.CPROGRAM_NAME, loUser.IGROUP_INDEX, _
                                                        iRow, iCol, 0, 0, loGroup.CGROUP_ID, 1, CUSER_ID, getDate(DDATE))
                                loDb.SqlExecNonQuery(lcQuery, loConn, False)
                            End If
                        Next
                    End If

                    countLoop += 1
                Next

                lcQuery = "exec RSP_WriteUploadProcessStatus '{0}', '{1}', '{2}', '{3}', '{4}', '{5}'"
                lcQuery = String.Format(lcQuery, CCOMP_ID, CUSER_ID, poBatchProcessPar.Key.KEY_GUID.Trim, countLoop, "Save Complete", 1)
                loDb.SqlExecNonQuery(lcQuery, loConn, True)

                TransScope.Complete()
            End Using

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Private Function getDate(pcDate As String) As String
        Return String.Format("CONVERT(DATETIME, '{0}')", pcDate)
    End Function

    Private Function getGroup() As List(Of GroupDTO)
        Dim loRtn As New List(Of GroupDTO)

        loRtn.Add(New GroupDTO With {.CGROUP_ID = "MASTER",
                                     .CGROUP_NAME = "Master"})

        loRtn.Add(New GroupDTO With {.CGROUP_ID = "TRANS",
                                     .CGROUP_NAME = "Transaction"})

        loRtn.Add(New GroupDTO With {.CGROUP_ID = "INQUI",
                                     .CGROUP_NAME = "Inquiry"})

        loRtn.Add(New GroupDTO With {.CGROUP_ID = "BATCH",
                                     .CGROUP_NAME = "Batch"})

        loRtn.Add(New GroupDTO With {.CGROUP_ID = "REPORT",
                                     .CGROUP_NAME = "Report"})

        Return loRtn
    End Function

    Public Sub saveButtonAccess(poParam As SAM01100MenuProgramDTO)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As SAM01100MenuProgramDTO
        'Dim oAccess As String()

        Try
            loConn = loDb.GetConnection()

            Using TransScope As New TransactionScope(TransactionScopeOption.Required)
                'get access from sam_program_access for restriction
                lcQuery = "SELECT A.CPROGRAM_ACCESS_BUTTON AS CACCESS_ID "
                lcQuery += "FROM SAM_MENU_PROGRAM A (NOLOCK) "
                lcQuery += "WHERE A.CCOMPANY_ID = '{0}' AND A.CPROGRAM_ID = '{1}' AND A.CMENU_ID = '{2}'"
                lcQuery = String.Format(lcQuery, poParam.CCOMPANY_ID, poParam.CPROGRAM_ID, poParam.CMENU_ID)
                loResult = loDb.SqlExecObjectQuery(Of SAM01100MenuProgramDTO)(lcQuery, loConn, False).FirstOrDefault

                If loResult IsNot Nothing Then
                    lcQuery = "UPDATE SAM_MENU_PROGRAM "
                    lcQuery += "SET "
                    lcQuery += "CPROGRAM_ACCESS_BUTTON = '{0}', "
                    lcQuery += "CUPDATE_BY = '{1}', "
                    lcQuery += "DUPDATE_DATE = {2} "
                    lcQuery += "WHERE CCOMPANY_ID = '{3}' AND CPROGRAM_ID = '{4}' AND CMENU_ID = '{5}'"
                    lcQuery = String.Format(lcQuery, poParam.CACCESS_ID, poParam.CUSERID, _
                                            getDate(poParam.DDATE), poParam.CCOMPANY_ID, poParam.CPROGRAM_ID, poParam.CMENU_ID)
                    loDb.SqlExecNonQuery(lcQuery, loConn, False)
                End If

                TransScope.Complete()
            End Using

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Sub saveGeneralAccess(poparam As SAM01100MenuProgramDTO)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As SAM01100MenuProgramDTO
        Dim oAccess As String()

        Try
            loConn = loDb.GetConnection()

            'get access from sam_program_access for restriction
            lcQuery = "SELECT A.CACCESS_ID "
            lcQuery += "FROM SAM_PROGRAM_ACCESS A (NOLOCK) "
            lcQuery += "WHERE A.CCOMPANY_ID = '{0}' AND A.CPROGRAM_ID = '{1}' AND A.CACCESS_TYPE = '{2}'"
            lcQuery = String.Format(lcQuery, poparam.CCOMPANY_ID, poparam.CPROGRAM_ID, "GENERAL")
            loResult = loDb.SqlExecObjectQuery(Of SAM01100MenuProgramDTO)(lcQuery, loConn, False).FirstOrDefault

            If loResult IsNot Nothing Then
                oAccess = poparam.CPROGRAM_ACCESS.Split(",")

                For Each access As String In oAccess
                    If Not loResult.CACCESS_ID.Contains(access) Then
                        Throw New Exception("Access " + access + " is restricted")
                    End If
                Next

                lcQuery = "UPDATE SAM_MENU_PROGRAM "
                lcQuery += "SET "
                lcQuery += "CPROGRAM_ACCESS = '{0}', "
                lcQuery += "CUPDATE_BY = '{1}', "
                lcQuery += "DUPDATE_DATE = {2} "
                lcQuery += "WHERE CCOMPANY_ID = '{3}' AND CPROGRAM_ID = '{4}' AND CMENU_ID = '{5}'"
                lcQuery = String.Format(lcQuery, poparam.CPROGRAM_ACCESS, poparam.CUSERID, _
                                        getDate(poparam.DDATE), poparam.CCOMPANY_ID, poparam.CPROGRAM_ID, poparam.CMENU_ID)
                loDb.SqlExecNonQuery(lcQuery, loConn, False)
            End If

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
End Class
