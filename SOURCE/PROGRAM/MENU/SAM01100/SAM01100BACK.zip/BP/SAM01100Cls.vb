﻿Imports R_Common
Imports R_BackEnd
Imports System.Data.Common
Imports System.Transactions
Imports SAM01100Common

Public Class SAM01100Cls
    Inherits R_BusinessObject(Of SAM01100DTO)

    Protected Overrides Sub R_Deleting(poEntity As SAM01100DTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection

        Try
            loConn = loDb.GetConnection()

            Using TransScope As New TransactionScope(TransactionScopeOption.Required)
                'delete header
                lcQuery = "DELETE FROM "
                lcQuery += "SAM_MENU "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' AND CMENU_ID = '{1}' "
                lcQuery = String.Format(lcQuery, poEntity.CCOMPANY_ID, poEntity.CMENU_ID)
                loDb.SqlExecNonQuery(lcQuery, loConn, False)

                'delete detail
                lcQuery = "DELETE SAM_MENU_PROGRAM "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' AND CMENU_ID = '{1}' "
                lcQuery = String.Format(lcQuery, poEntity.CCOMPANY_ID, poEntity.CMENU_ID)
                loDb.SqlExecNonQuery(lcQuery, loConn, False)

                'delete from sam_user_program
                lcQuery = "DELETE SAM_USER_PROGRAM "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' AND CMENU_ID = '{1}' "
                lcQuery = String.Format(lcQuery, poEntity.CCOMPANY_ID, poEntity.CMENU_ID)
                loDb.SqlExecNonQuery(lcQuery, loConn, False)

                'delete from sam_user_menu
                lcQuery = "DELETE SAM_USER_MENU "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' AND CMENU_ID = '{1}' "
                lcQuery = String.Format(lcQuery, poEntity.CCOMPANY_ID, poEntity.CMENU_ID)
                loDb.SqlExecNonQuery(lcQuery, loConn, False)

                TransScope.Complete()
            End Using

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As SAM01100DTO) As SAM01100DTO
        Dim lcQuery As String
        Dim loResult As SAM01100DTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT * FROM SAM_MENU (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' AND CMENU_ID = '{1}' "
            lcQuery = String.Format(lcQuery, poEntity.CCOMPANY_ID, poEntity.CMENU_ID)

            loResult = loDb.SqlExecObjectQuery(Of SAM01100DTO)(lcQuery).FirstOrDefault
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As SAM01100DTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As SAM01100DTO

        Try
            loConn = loDb.GetConnection()

            If poCRUDMode = eCRUDMode.AddMode Then
                lcQuery = "SELECT * FROM SAM_MENU (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' AND CMENU_ID = '{1}' "
                lcQuery = String.Format(lcQuery, poNewEntity.CCOMPANY_ID, poNewEntity.CMENU_ID)
                loResult = loDb.SqlExecObjectQuery(Of SAM01100DTO)(lcQuery, loConn, True).FirstOrDefault

                If loResult IsNot Nothing Then
                    Throw New Exception("Menu Id " + poNewEntity.CCOMPANY_ID.Trim + " Already Exist")
                End If

                lcQuery = "INSERT INTO SAM_MENU (CCOMPANY_ID, CMENU_ID, CMENU_NAME, LSYSTEM_FLAG, CUPDATE_BY, DUPDATE_DATE, CCREATE_BY, DCREATE_DATE) values('{0}', '{1}', '{2}', {3}, '{4}', {5}, '{4}', {5})"
                lcQuery = String.Format(lcQuery, poNewEntity.CCOMPANY_ID, poNewEntity.CMENU_ID, poNewEntity.CMENU_NAME, CInt(poNewEntity.LSYSTEM_FLAG), poNewEntity.CUSER_ID, getDate(poNewEntity.DDATE))
                loDb.SqlExecNonQuery(lcQuery)

            ElseIf poCRUDMode = eCRUDMode.EditMode Then
                lcQuery = "UPDATE SAM_MENU "
                lcQuery += "SET "
                lcQuery += "CMENU_NAME = '{0}', "
                lcQuery += "LSYSTEM_FLAG = '{1}', "
                lcQuery += "CUPDATE_BY = '{2}', "
                lcQuery += "DUPDATE_DATE = " + getDate(poNewEntity.DDATE) + " "
                lcQuery += "WHERE CCOMPANY_ID = '{3}' AND CMENU_ID = '{4}' "
                lcQuery = String.Format(lcQuery, poNewEntity.CMENU_NAME, poNewEntity.LSYSTEM_FLAG, poNewEntity.CUSER_ID, _
                                        poNewEntity.CCOMPANY_ID, poNewEntity.CMENU_ID)
                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End If

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Function getMenuList(pcCompId As String) As List(Of SAM01100GridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of SAM01100GridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT * FROM SAM_MENU (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' AND CMENU_ID <> 'FAV'"
            lcQuery = String.Format(lcQuery, pcCompId)

            loResult = loDb.SqlExecObjectQuery(Of SAM01100GridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function getMenuProgramList(pcCompId As String, pcMenuId As String) As List(Of SAM01100MenuProgramDTOnon)
        Dim lcQuery As String
        Dim loResult As List(Of SAM01100MenuProgramDTOnon)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT A.CPROGRAM_ID, B.CPROGRAM_NAME, A.CPROGRAM_ACCESS, A.CPROGRAM_ACCESS_BUTTON AS CBUTTON_ACCESS, "
            lcQuery += "A.CCREATE_BY, A.DCREATE_DATE, A.CUPDATE_BY, A.DUPDATE_DATE "
            lcQuery += "FROM SAM_MENU_PROGRAM A (NOLOCK) "
            lcQuery += "INNER JOIN SAM_PROGRAM B (NOLOCK) "
            lcQuery += "ON B.CPROGRAM_ID = A.CPROGRAM_ID "
            lcQuery += "WHERE A.CCOMPANY_ID = '{0}' AND A.CMENU_ID = '{1}'"
            lcQuery = String.Format(lcQuery, pcCompId, pcMenuId)

            loResult = loDb.SqlExecObjectQuery(Of SAM01100MenuProgramDTOnon)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function getProgramList() As List(Of ProgramDTO)
        Dim lcQuery As String
        Dim loResult As List(Of ProgramDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "SAM_PROGRAM (NOLOCK) "
            lcQuery = String.Format(lcQuery)

            loResult = loDb.SqlExecObjectQuery(Of ProgramDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Sub saveGeneralAccess(poNewEntity As Dictionary(Of String, String))
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As SAM01100MenuProgramDTO

        Try
            loConn = loDb.GetConnection()

            With poNewEntity
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "SAM_PROGRAM_ACCESS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' AND CPROGRAM_ID = '{1}' "
                lcQuery = String.Format(lcQuery, .Item("CCOMPANY_ID"), .Item("CPROGRAM_ID"))

                loResult = loDb.SqlExecObjectQuery(Of SAM01100MenuProgramDTO)(lcQuery, loConn, False).FirstOrDefault
                If loResult Is Nothing Then
                    Throw New Exception("Item not found")
                End If

                lcQuery = "UPDATE SAM_PROGRAM_ACCESS "
                lcQuery += "SET "
                lcQuery += "CACCESS_ID = '{0}', "

                lcQuery += "CUPDATE_BY = '{1}', "
                lcQuery += "DUPDATE_DATE = '{2}' "
                lcQuery += "WHERE CCOMPANY_ID = '{3}' AND CPROGRAM_ID = '{4}' AND CACCESS_TYPE = '{5}'"
                lcQuery = String.Format(lcQuery, .Item("CACCESS_ID"), .Item("CUPDATE_BY"), .Item("DUPDATE_DATE"), .Item("CCOMPANY_ID"), _
                                        .Item("CPROGRAM_ID"), .Item("CACCESS_TYPE"))

                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Function getDate(pcDate As String) As String
        Return String.Format("CONVERT(DATETIME, '{0}')", pcDate)
    End Function

    Public Function getProgramButton(pcProgramId As String, pcCompId As String, pcMenuId As String) As List(Of ButtonDTO)
        Dim loEx As New R_Exception()
        Dim loRtn As New List(Of ButtonDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loConn As DbConnection

        Try
            loConn = loDb.GetConnection()

            lcQuery = "SELECT LSELECTED = CONVERT (BIT, CASE CHARINDEX(A.CBUTTON_ID, CASE WHEN C.CPROGRAM_ACCESS_BUTTON IS NULL THEN '' ELSE C.CPROGRAM_ACCESS_BUTTON END) WHEN 0 THEN 0 ELSE 1 END), A.CPROGRAM_ID, A.CBUTTON_ID, A.CBUTTON_DESCRIPTION_ID "
            lcQuery += "FROM SAM_PROGRAM_BUTTON A (NOLOCK) "
            lcQuery += "INNER JOIN SAM_PROGRAM_ACCESS B (NOLOCK) "
            lcQuery += "ON B.CPROGRAM_ID = A.CPROGRAM_ID "
            lcQuery += "LEFT JOIN SAM_MENU_PROGRAM C (NOLOCK) "
            lcQuery += "ON C.CCOMPANY_ID = B.CCOMPANY_ID AND C.CPROGRAM_ID = B.CPROGRAM_ID "
            lcQuery += "WHERE A.CPROGRAM_ID = '{0}' AND B.CACCESS_TYPE = '{2}' AND B.CCOMPANY_ID = '{1}' AND C.CMENU_ID = '{3}'"
            lcQuery = String.Format(lcQuery, pcProgramId, pcCompId, "BUTTON", pcMenuId)
            loRtn = loDb.SqlExecObjectQuery(Of ButtonDTO)(lcQuery, loConn, False)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loRtn
    End Function
End Class
