﻿<Serializable()> _
Public Class SAM01100BatchDTO
    Public Property CPROGRAM_ID As String
    Public Property CBUTTON_ID As String
End Class
