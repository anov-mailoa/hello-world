﻿Imports R_FrontEnd
Imports SAM01100Front.SAM01100ServiceRef
Imports SAM01100Front.SAM01100StreamingServiceRef
Imports SAM01100Front.MenuProgramServiceRef
Imports R_Common
Imports System.ServiceModel.Channels
Imports ClientHelper
Imports Telerik.WinControls.UI
Imports SAM01100FrontResources

Public Class GeneralAccess

    Private Sub GeneralAccess_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim loDetail As New DetailDTO
        Dim oRes As New Resources_Dummy_Class

        With CType(poParameter, SAM01100MenuProgramDTOnon)
            loDetail = New DetailDTO With {.CPROGRAM_ID = CType(poParameter, SAM01100MenuProgramDTOnon).CPROGRAM_ID,
                                           .CPROGRAM_NAME = CType(poParameter, SAM01100MenuProgramDTOnon).CPROGRAM_NAME}

            bsDetail.DataSource = loDetail
            gvAccess.R_RefreshGrid(poParameter)
        End With
    End Sub

    Private Sub gvAccess_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvAccess.R_ServiceGetListRecord
        Dim oListAccess As New List(Of GeneralAccessDTO)

        If String.IsNullOrWhiteSpace(CType(poEntity, SAM01100MenuProgramDTOnon).CPROGRAM_ACCESS) Then
            oListAccess.Add(New GeneralAccessDTO With {.LSELECTED = False,
                                                       .CACCESS = "Add"})

            oListAccess.Add(New GeneralAccessDTO With {.LSELECTED = False,
                                                       .CACCESS = "Update"})

            oListAccess.Add(New GeneralAccessDTO With {.LSELECTED = False,
                                                       .CACCESS = "Delete"})

            oListAccess.Add(New GeneralAccessDTO With {.LSELECTED = False,
                                                       .CACCESS = "Print"})
        Else
            oListAccess.Add(New GeneralAccessDTO With {.LSELECTED = CType(poEntity, SAM01100MenuProgramDTOnon).CPROGRAM_ACCESS.Contains("A"),
                                                       .CACCESS = "Add"})

            oListAccess.Add(New GeneralAccessDTO With {.LSELECTED = CType(poEntity, SAM01100MenuProgramDTOnon).CPROGRAM_ACCESS.Contains("U"),
                                                       .CACCESS = "Update"})

            oListAccess.Add(New GeneralAccessDTO With {.LSELECTED = CType(poEntity, SAM01100MenuProgramDTOnon).CPROGRAM_ACCESS.Contains("D"),
                                                       .CACCESS = "Delete"})

            oListAccess.Add(New GeneralAccessDTO With {.LSELECTED = CType(poEntity, SAM01100MenuProgramDTOnon).CPROGRAM_ACCESS.Contains("P"),
                                                       .CACCESS = "Print"})
        End If

        poListEntityResult = oListAccess
    End Sub

    Private Sub rtnPopUp_R_SetPopUpResult(ByRef poEntityResult As Object) Handles rtnPopUp.R_SetPopUpResult
        Dim loEx As New R_Exception()

        Try
            Dim oList As List(Of GeneralAccessDTO) = TryCast(bsAccess.DataSource, List(Of GeneralAccessDTO))

            oList = oList.Where(Function(x) x.LSELECTED).Select(Function(x) x).ToList

            Dim oArray As String() = oList.Select(Function(x) x.CACCESS.Substring(0, 1)).ToArray
            If oArray.Count = 0 Then
                poEntityResult = "V"
            Else
                poEntityResult = String.Join(",", oArray) & ",V"
            End If
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub rtnPopUp_R_ValidationPopUpResult(ByRef plCancel As Boolean, poButton As System.Windows.Forms.DialogResult) Handles rtnPopUp.R_ValidationPopUpResult
        Dim loEx As New R_Exception()

        Try
            If poButton = Windows.Forms.DialogResult.OK Then
                Dim oList As List(Of GeneralAccessDTO) = TryCast(bsAccess.DataSource, List(Of GeneralAccessDTO))
                oList = oList.Where(Function(x) x.LSELECTED).Select(Function(x) x).ToList

                If oList.Count = 0 Then
                    Select Case R_RadMessageBox.Show(R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS005"), R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_Confirm"), Windows.Forms.MessageBoxButtons.OKCancel)
                        Case Windows.Forms.DialogResult.Cancel
                            plCancel = True
                    End Select
                End If
            End If
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
End Class
