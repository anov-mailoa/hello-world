﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SAM01100
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn1 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn2 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn6 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewLookUpColumn1 As R_FrontEnd.R_GridViewLookUpColumn = New R_FrontEnd.R_GridViewLookUpColumn()
        Dim R_GridViewTextBoxColumn7 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn8 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn3 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn9 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn4 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Me.R_RadGroupBox1 = New R_FrontEnd.R_RadGroupBox(Me.components)
        Me.gvMenu = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvMenu = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridMenu = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.R_RadGroupBox2 = New R_FrontEnd.R_RadGroupBox(Me.components)
        Me.gvMenuPrograms = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvMenuPrograms = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridMenuPrograms = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.btnProgram = New R_FrontEnd.R_PopUp(Me.components)
        Me.bwSAM01100 = New System.ComponentModel.BackgroundWorker()
        Me.btnPopupBtnAccess = New R_FrontEnd.R_PopUp(Me.components)
        Me.btnPopUpGeneral = New R_FrontEnd.R_PopUp(Me.components)
        CType(Me.R_RadGroupBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.R_RadGroupBox1.SuspendLayout()
        CType(Me.gvMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvMenu.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadGroupBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.R_RadGroupBox2.SuspendLayout()
        CType(Me.gvMenuPrograms, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvMenuPrograms.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvMenuPrograms, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridMenuPrograms, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnProgram, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnPopupBtnAccess, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnPopUpGeneral, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'R_RadGroupBox1
        '
        Me.R_RadGroupBox1.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping
        Me.R_RadGroupBox1.Controls.Add(Me.gvMenu)
        Me.R_RadGroupBox1.Font = New System.Drawing.Font("Calibri", 15.0!)
        Me.R_RadGroupBox1.HeaderText = "Menu"
        Me.R_RadGroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.R_RadGroupBox1.Name = "R_RadGroupBox1"
        Me.R_RadGroupBox1.R_ConductorGridSource = Nothing
        Me.R_RadGroupBox1.R_ConductorSource = Nothing
        Me.R_RadGroupBox1.R_ResourceId = "_Menu"
        Me.R_RadGroupBox1.Size = New System.Drawing.Size(853, 216)
        Me.R_RadGroupBox1.TabIndex = 0
        Me.R_RadGroupBox1.Text = "Menu"
        '
        'gvMenu
        '
        Me.gvMenu.Location = New System.Drawing.Point(6, 32)
        '
        '
        '
        Me.gvMenu.MasterTemplate.AutoGenerateColumns = False
        Me.gvMenu.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn1.FieldName = "_CMENU_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CMENU_ID"
        R_GridViewTextBoxColumn1.IsAutoGenerated = True
        R_GridViewTextBoxColumn1.Name = "_CMENU_ID"
        R_GridViewTextBoxColumn1.R_EnableADD = True
        R_GridViewTextBoxColumn1.R_EnableEDIT = True
        R_GridViewTextBoxColumn1.R_ResourceId = "_CMENU_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 118
        R_GridViewTextBoxColumn2.FieldName = "_CMENU_NAME"
        R_GridViewTextBoxColumn2.HeaderText = "_CMENU_NAME"
        R_GridViewTextBoxColumn2.IsAutoGenerated = True
        R_GridViewTextBoxColumn2.Name = "_CMENU_NAME"
        R_GridViewTextBoxColumn2.R_EnableADD = True
        R_GridViewTextBoxColumn2.R_EnableEDIT = True
        R_GridViewTextBoxColumn2.R_ResourceId = "_CMENU_NAME"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 118
        R_GridViewCheckBoxColumn1.FieldName = "_LSYSTEM_FLAG"
        R_GridViewCheckBoxColumn1.HeaderText = "_LSYSTEM_FLAG"
        R_GridViewCheckBoxColumn1.IsAutoGenerated = True
        R_GridViewCheckBoxColumn1.Name = "_LSYSTEM_FLAG"
        R_GridViewCheckBoxColumn1.R_ResourceId = "_LSYSTEM_FLAG"
        R_GridViewCheckBoxColumn1.Width = 120
        R_GridViewTextBoxColumn3.FieldName = "_CUPDATE_BY"
        R_GridViewTextBoxColumn3.HeaderText = "_CUPDATE_BY"
        R_GridViewTextBoxColumn3.IsAutoGenerated = True
        R_GridViewTextBoxColumn3.Name = "_CUPDATE_BY"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CUPDATE_BY"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 118
        R_GridViewDateTimeColumn1.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn1.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.GeneralDate
        R_GridViewDateTimeColumn1.FieldName = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        R_GridViewDateTimeColumn1.FormatString = "{0: M/d/yyyy h:mm tt }"
        R_GridViewDateTimeColumn1.HeaderText = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.IsAutoGenerated = True
        R_GridViewDateTimeColumn1.Name = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.R_ResourceId = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.Width = 118
        R_GridViewTextBoxColumn4.FieldName = "_CCREATE_BY"
        R_GridViewTextBoxColumn4.HeaderText = "_CCREATE_BY"
        R_GridViewTextBoxColumn4.IsAutoGenerated = True
        R_GridViewTextBoxColumn4.Name = "_CCREATE_BY"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CCREATE_BY"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 118
        R_GridViewDateTimeColumn2.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn2.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.GeneralDate
        R_GridViewDateTimeColumn2.FieldName = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        R_GridViewDateTimeColumn2.FormatString = "{0: M/d/yyyy h:mm tt }"
        R_GridViewDateTimeColumn2.HeaderText = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.IsAutoGenerated = True
        R_GridViewDateTimeColumn2.Name = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.R_ResourceId = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.Width = 118
        Me.gvMenu.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewCheckBoxColumn1, R_GridViewTextBoxColumn3, R_GridViewDateTimeColumn1, R_GridViewTextBoxColumn4, R_GridViewDateTimeColumn2})
        Me.gvMenu.MasterTemplate.DataSource = Me.bsGvMenu
        Me.gvMenu.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvMenu.MasterTemplate.EnableFiltering = True
        Me.gvMenu.MasterTemplate.EnableGrouping = False
        Me.gvMenu.MasterTemplate.ShowFilteringRow = False
        Me.gvMenu.MasterTemplate.ShowGroupedColumns = True
        Me.gvMenu.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvMenu.Name = "gvMenu"
        Me.gvMenu.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvMenu.R_ConductorGridSource = Me.conGridMenu
        Me.gvMenu.R_ConductorSource = Nothing
        Me.gvMenu.R_DataAdded = False
        Me.gvMenu.R_NewRowText = Nothing
        Me.gvMenu.ShowHeaderCellButtons = True
        Me.gvMenu.Size = New System.Drawing.Size(842, 179)
        Me.gvMenu.TabIndex = 0
        Me.gvMenu.Text = "R_RadGridView1"
        '
        'bsGvMenu
        '
        Me.bsGvMenu.DataSource = GetType(SAM01100Front.SAM01100ServiceRef.SAM01100DTO)
        '
        'conGridMenu
        '
        Me.conGridMenu.R_ConductorParent = Nothing
        Me.conGridMenu.R_IsHeader = True
        Me.conGridMenu.R_RadGroupBox = Nothing
        '
        'R_RadGroupBox2
        '
        Me.R_RadGroupBox2.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping
        Me.R_RadGroupBox2.Controls.Add(Me.gvMenuPrograms)
        Me.R_RadGroupBox2.Font = New System.Drawing.Font("Calibri", 15.0!)
        Me.R_RadGroupBox2.HeaderText = "Menu Programs"
        Me.R_RadGroupBox2.Location = New System.Drawing.Point(12, 234)
        Me.R_RadGroupBox2.Name = "R_RadGroupBox2"
        Me.R_RadGroupBox2.R_ConductorGridSource = Nothing
        Me.R_RadGroupBox2.R_ConductorSource = Nothing
        Me.R_RadGroupBox2.R_ResourceId = "_MenuPrograms"
        Me.R_RadGroupBox2.Size = New System.Drawing.Size(853, 262)
        Me.R_RadGroupBox2.TabIndex = 1
        Me.R_RadGroupBox2.Text = "Menu Programs"
        '
        'gvMenuPrograms
        '
        Me.gvMenuPrograms.Location = New System.Drawing.Point(5, 30)
        '
        '
        '
        Me.gvMenuPrograms.MasterTemplate.AllowAddNewRow = False
        Me.gvMenuPrograms.MasterTemplate.AutoGenerateColumns = False
        Me.gvMenuPrograms.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn5.FieldName = "_CPROGRAM_ID"
        R_GridViewTextBoxColumn5.HeaderText = "CPROGRAM_ID"
        R_GridViewTextBoxColumn5.Name = "_CPROGRAM_ID"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CPROGRAM_ID"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 110
        R_GridViewTextBoxColumn6.FieldName = "_CPROGRAM_NAME"
        R_GridViewTextBoxColumn6.HeaderText = "CPROGRAM_NAME"
        R_GridViewTextBoxColumn6.IsAutoGenerated = True
        R_GridViewTextBoxColumn6.Name = "_CPROGRAM_NAME"
        R_GridViewTextBoxColumn6.R_ResourceId = "_CPROGRAM_NAME"
        R_GridViewTextBoxColumn6.R_UDT = Nothing
        R_GridViewTextBoxColumn6.Width = 110
        R_GridViewLookUpColumn1.FieldName = "_CPROGRAM_ACCESS"
        R_GridViewLookUpColumn1.HeaderText = "CPROGRAM_ACCESS"
        R_GridViewLookUpColumn1.Name = "_CPROGRAM_ACCESS"
        R_GridViewLookUpColumn1.R_ResourceId = "_CPROGRAM_ACCESS"
        R_GridViewLookUpColumn1.R_Title = Nothing
        R_GridViewLookUpColumn1.Width = 114
        R_GridViewTextBoxColumn7.FieldName = "_CBUTTON_ACCESS"
        R_GridViewTextBoxColumn7.HeaderText = "CBUTTON_ACCESS"
        R_GridViewTextBoxColumn7.Name = "_CBUTTON_ACCESS"
        R_GridViewTextBoxColumn7.R_ResourceId = "_BUTTON_ACCESS"
        R_GridViewTextBoxColumn7.R_UDT = Nothing
        R_GridViewTextBoxColumn8.FieldName = "_CUPDATE_BY"
        R_GridViewTextBoxColumn8.HeaderText = "CUPDATE_BY"
        R_GridViewTextBoxColumn8.IsAutoGenerated = True
        R_GridViewTextBoxColumn8.Name = "_CUPDATE_BY"
        R_GridViewTextBoxColumn8.R_ResourceId = "_CUPDATE_BY"
        R_GridViewTextBoxColumn8.R_UDT = Nothing
        R_GridViewTextBoxColumn8.Width = 110
        R_GridViewDateTimeColumn3.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn3.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.GeneralDate
        R_GridViewDateTimeColumn3.FieldName = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn3.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        R_GridViewDateTimeColumn3.FormatString = "{0: M/d/yyyy h:mm tt }"
        R_GridViewDateTimeColumn3.HeaderText = "DUPDATE_DATE"
        R_GridViewDateTimeColumn3.IsAutoGenerated = True
        R_GridViewDateTimeColumn3.Name = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn3.R_ResourceId = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn3.Width = 110
        R_GridViewTextBoxColumn9.FieldName = "_CCREATE_BY"
        R_GridViewTextBoxColumn9.HeaderText = "CCREATE_BY"
        R_GridViewTextBoxColumn9.IsAutoGenerated = True
        R_GridViewTextBoxColumn9.Name = "_CCREATE_BY"
        R_GridViewTextBoxColumn9.R_ResourceId = "_CCREATE_BY"
        R_GridViewTextBoxColumn9.R_UDT = Nothing
        R_GridViewTextBoxColumn9.Width = 110
        R_GridViewDateTimeColumn4.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn4.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.GeneralDate
        R_GridViewDateTimeColumn4.FieldName = "_DCREATE_DATE"
        R_GridViewDateTimeColumn4.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        R_GridViewDateTimeColumn4.FormatString = "{0: M/d/yyyy h:mm tt }"
        R_GridViewDateTimeColumn4.HeaderText = "DCREATE_DATE"
        R_GridViewDateTimeColumn4.IsAutoGenerated = True
        R_GridViewDateTimeColumn4.Name = "_DCREATE_DATE"
        R_GridViewDateTimeColumn4.R_ResourceId = "_DCREATE_DATE"
        R_GridViewDateTimeColumn4.Width = 115
        Me.gvMenuPrograms.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn5, R_GridViewTextBoxColumn6, R_GridViewLookUpColumn1, R_GridViewTextBoxColumn7, R_GridViewTextBoxColumn8, R_GridViewDateTimeColumn3, R_GridViewTextBoxColumn9, R_GridViewDateTimeColumn4})
        Me.gvMenuPrograms.MasterTemplate.DataSource = Me.bsGvMenuPrograms
        Me.gvMenuPrograms.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvMenuPrograms.MasterTemplate.EnableFiltering = True
        Me.gvMenuPrograms.MasterTemplate.EnableGrouping = False
        Me.gvMenuPrograms.MasterTemplate.ShowFilteringRow = False
        Me.gvMenuPrograms.MasterTemplate.ShowGroupedColumns = True
        Me.gvMenuPrograms.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvMenuPrograms.Name = "gvMenuPrograms"
        Me.gvMenuPrograms.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvMenuPrograms.R_ConductorGridSource = Me.conGridMenuPrograms
        Me.gvMenuPrograms.R_ConductorSource = Nothing
        Me.gvMenuPrograms.R_DataAdded = False
        Me.gvMenuPrograms.R_NewRowText = Nothing
        Me.gvMenuPrograms.ShowHeaderCellButtons = True
        Me.gvMenuPrograms.Size = New System.Drawing.Size(842, 224)
        Me.gvMenuPrograms.TabIndex = 1
        Me.gvMenuPrograms.Text = "R_RadGridView2"
        '
        'bsGvMenuPrograms
        '
        Me.bsGvMenuPrograms.DataSource = GetType(SAM01100Front.MenuProgramServiceRef.SAM01100MenuProgramDTO)
        '
        'conGridMenuPrograms
        '
        Me.conGridMenuPrograms.R_ConductorParent = Me.conGridMenu
        Me.conGridMenuPrograms.R_RadGroupBox = Nothing
        '
        'btnProgram
        '
        Me.btnProgram.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnProgram.Location = New System.Drawing.Point(755, 502)
        Me.btnProgram.Name = "btnProgram"
        Me.btnProgram.R_ConductorGridSource = Nothing
        Me.btnProgram.R_ConductorSource = Nothing
        Me.btnProgram.R_DescriptionId = Nothing
        Me.btnProgram.R_ResourceId = "_Program"
        Me.btnProgram.R_Title = Nothing
        Me.btnProgram.Size = New System.Drawing.Size(110, 24)
        Me.btnProgram.TabIndex = 4
        Me.btnProgram.Text = "Program"
        '
        'btnPopupBtnAccess
        '
        Me.btnPopupBtnAccess.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnPopupBtnAccess.Location = New System.Drawing.Point(639, 502)
        Me.btnPopupBtnAccess.Name = "btnPopupBtnAccess"
        Me.btnPopupBtnAccess.R_ConductorGridSource = Nothing
        Me.btnPopupBtnAccess.R_ConductorSource = Nothing
        Me.btnPopupBtnAccess.R_DescriptionId = Nothing
        Me.btnPopupBtnAccess.R_ResourceId = "_BUTTON_ACCESS"
        Me.btnPopupBtnAccess.R_Title = Nothing
        Me.btnPopupBtnAccess.Size = New System.Drawing.Size(110, 24)
        Me.btnPopupBtnAccess.TabIndex = 5
        Me.btnPopupBtnAccess.Text = "R_PopUp1"
        '
        'btnPopUpGeneral
        '
        Me.btnPopUpGeneral.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnPopUpGeneral.Location = New System.Drawing.Point(523, 502)
        Me.btnPopUpGeneral.Name = "btnPopUpGeneral"
        Me.btnPopUpGeneral.R_ConductorGridSource = Nothing
        Me.btnPopUpGeneral.R_ConductorSource = Nothing
        Me.btnPopUpGeneral.R_DescriptionId = Nothing
        Me.btnPopUpGeneral.R_ResourceId = "_CPROGRAM_ACCESS"
        Me.btnPopUpGeneral.R_Title = Nothing
        Me.btnPopUpGeneral.Size = New System.Drawing.Size(110, 24)
        Me.btnPopUpGeneral.TabIndex = 6
        Me.btnPopUpGeneral.Text = "R_PopUp1"
        '
        'SAM01100
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(877, 531)
        Me.Controls.Add(Me.btnPopUpGeneral)
        Me.Controls.Add(Me.btnPopupBtnAccess)
        Me.Controls.Add(Me.btnProgram)
        Me.Controls.Add(Me.R_RadGroupBox2)
        Me.Controls.Add(Me.R_RadGroupBox1)
        Me.Name = "SAM01100"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.R_RadGroupBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.R_RadGroupBox1.ResumeLayout(False)
        CType(Me.gvMenu.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvMenu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvMenu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridMenu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadGroupBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.R_RadGroupBox2.ResumeLayout(False)
        CType(Me.gvMenuPrograms.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvMenuPrograms, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvMenuPrograms, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridMenuPrograms, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnProgram, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnPopupBtnAccess, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnPopUpGeneral, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents R_RadGroupBox1 As R_FrontEnd.R_RadGroupBox
    Friend WithEvents gvMenu As R_FrontEnd.R_RadGridView
    Friend WithEvents R_RadGroupBox2 As R_FrontEnd.R_RadGroupBox
    Friend WithEvents gvMenuPrograms As R_FrontEnd.R_RadGridView
    Friend WithEvents btnProgram As R_FrontEnd.R_PopUp
    Friend WithEvents bsGvMenu As System.Windows.Forms.BindingSource
    Friend WithEvents bsGvMenuPrograms As System.Windows.Forms.BindingSource
    Friend WithEvents conGridMenu As R_FrontEnd.R_ConductorGrid
    Friend WithEvents conGridMenuPrograms As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bwSAM01100 As System.ComponentModel.BackgroundWorker
    Friend WithEvents btnPopupBtnAccess As R_FrontEnd.R_PopUp
    Friend WithEvents btnPopUpGeneral As R_FrontEnd.R_PopUp

End Class
