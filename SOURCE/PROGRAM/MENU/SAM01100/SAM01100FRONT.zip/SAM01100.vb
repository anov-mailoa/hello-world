﻿Imports R_FrontEnd
Imports SAM01100Front.SAM01100ServiceRef
Imports SAM01100Front.SAM01100StreamingServiceRef
Imports SAM01100Front.MenuProgramServiceRef
Imports R_Common
Imports System.ServiceModel.Channels
Imports ClientHelper
Imports SAM01100FrontResources
Imports Telerik.WinControls
Imports Telerik.WinControls.Data
Imports Telerik.WinControls.UI

Public Class SAM01100

#Region " VARIABLE "
    Dim C_ServiceName As String = "SAM01100Service/SAM01100Service.svc"
    Dim C_ServiceNameStream As String = "SAM01100Service/SAM01100StreamingService/SAM01100StreamingService.svc"
    Dim C_ServiceNameMenuStream As String = "SAM01100Service/MenuProgramService/MenuProgramService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
#End Region

    Private Sub SAM01100_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim loEx As New R_Exception
        Dim oRes As New Resources_Dummy_Class

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            gvMenu.R_RefreshGrid(_CCOMPID)

            'SET DEFAULT VALUE KE FILTER GRID GRADE
            'Dim filter As New FilterDescriptor()
            'filter.PropertyName = "_CMENU_ID"
            'filter.Operator = FilterOperator.IsEqualTo
            'filter.Value = "MA"
            'filter.IsFilterEditor = True
            'Me.gvMenu.FilterDescriptors.Add(filter)

            'Dim initialize As GridViewColumnValuesCollection = Me.gvMenu.Columns(filter.PropertyName).DistinctValuesWithFilter
            'Me.gvMenu.MasterTemplate.ExcelFilteredColumns.Add(Me.gvMenu.Columns(0))
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#Region "GRIDVIEW MENU"

    Private Sub gvMenu_R_AfterAdd(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection) Handles gvMenu.R_AfterAdd
        poGridCellCollection(3).Value = _CUSERID
        poGridCellCollection(4).Value = DateTime.Now
        poGridCellCollection(5).Value = _CUSERID
        poGridCellCollection(6).Value = DateTime.Now
    End Sub

    Private Sub gvMenu_R_CheckDelete(poEntity As Object, ByRef plAllowDelete As Boolean) Handles gvMenu.R_CheckDelete
        If CType(poEntity, SAM01100DTO)._LSYSTEM_FLAG Then
            plAllowDelete = False
        End If
    End Sub

    Private Sub gvMenu_R_CheckEdit(poEntity As Object, ByRef plAllowEdit As Boolean) Handles gvMenu.R_CheckEdit
        If CType(poEntity, SAM01100DTO)._CMENU_ID = "MA" Then
            plAllowEdit = False
        End If
    End Sub

    Private Sub gvMenu_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvMenu.R_Display
        If poEntity IsNot Nothing Then
            gvMenuPrograms.R_RefreshGrid(CType(poEntity, SAM01100DTO)._CMENU_ID)
        End If
    End Sub

    Private Sub gvMenu_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvMenu.R_Saving
        With CType(poEntity, SAM01100DTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CUSER_ID = _CUSERID
            ._DDATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With
    End Sub

    Private Sub gvMenu_R_ServiceDelete(poEntity As Object) Handles gvMenu.R_ServiceDelete
        Dim loService As SAM01100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01100Service, SAM01100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            With CType(poEntity, SAM01100DTO)
                ._CCOMPANY_ID = _CCOMPID
            End With

            loService.Svc_R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvMenu_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvMenu.R_ServiceGetListRecord
        Dim loServiceStream As SAM01100StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01100StreamingService, SAM01100StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of SAM01100GridDTO)
        Dim loListEntity As New List(Of SAM01100DTO)

        Try
            R_Utility.R_SetStreamingContext("cCompId", poEntity)

            loRtn = loServiceStream.getMenuList()
            loStreaming = R_StreamUtility(Of SAM01100GridDTO).ReadFromMessage(loRtn)

            For Each loDto As SAM01100GridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New SAM01100DTO With {._CMENU_ID = loDto.CMENU_ID,
                                                           ._CMENU_NAME = loDto.CMENU_NAME,
                                                           ._LSYSTEM_FLAG = loDto.LSYSTEM_FLAG,
                                                           ._CCREATE_BY = loDto.CCREATE_BY,
                                                           ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                           ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                           ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvMenu_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvMenu.R_ServiceGetRecord
        Dim loService As SAM01100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01100Service, SAM01100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New SAM01100DTO With {._CCOMPANY_ID = _CCOMPID,
                                                                            ._CMENU_ID = CType(bsGvMenu.Current, SAM01100DTO)._CMENU_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvMenu_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvMenu.R_ServiceSave
        Dim loService As SAM01100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01100Service, SAM01100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvMenu_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvMenu.R_Validation
        Dim loEx As New R_Exception()

        Try
            pcError = ""
            With poGridCellCollection
                If String.IsNullOrWhiteSpace(.Item(0).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS001")
                    loEx.Add(R_Utility.R_GetError(GetType(Resources_Dummy_Class), "PS001"))
                    plCancel = True
                End If

                If String.IsNullOrWhiteSpace(.Item(1).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS002")
                    loEx.Add(R_Utility.R_GetError(GetType(Resources_Dummy_Class), "PS002"))
                    plCancel = True
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#Region "CONDUCTOR MENU"
    Private Sub conGridMenu_R_SetAdd(plEnable As Boolean) Handles conGridMenu.R_SetAdd
        gvMenuPrograms.Enabled = Not plEnable
        btnProgram.Enabled = Not plEnable
    End Sub

    Private Sub conGridMenu_R_SetEdit(plEnable As Boolean) Handles conGridMenu.R_SetEdit
        gvMenuPrograms.Enabled = Not plEnable
        btnProgram.Enabled = Not plEnable
    End Sub
#End Region
#End Region

#Region "GRIDVIEW MENU PROGRAMS"
    Private Sub gvMenuPrograms_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvMenuPrograms.R_ServiceGetListRecord
        Dim loServiceStream As SAM01100StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01100StreamingService, SAM01100StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of SAM01100MenuProgramDTOnon)
        Dim loListEntity As New List(Of SAM01100MenuProgramDTO)

        Try
            R_Utility.R_SetStreamingContext("cCompId", _CCOMPID)
            R_Utility.R_SetStreamingContext("cMenuId", poEntity)

            loRtn = loServiceStream.getMenuProgramList()
            loStreaming = R_StreamUtility(Of SAM01100MenuProgramDTOnon).ReadFromMessage(loRtn)

            For Each loDto As SAM01100MenuProgramDTOnon In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New SAM01100MenuProgramDTO With {._CPROGRAM_ID = loDto.CPROGRAM_ID,
                                                                      ._CPROGRAM_NAME = loDto.CPROGRAM_NAME,
                                                                      ._CPROGRAM_ACCESS = loDto.CPROGRAM_ACCESS,
                                                                      ._CBUTTON_ACCESS = loDto.CBUTTON_ACCESS,
                                                                      ._CCREATE_BY = loDto.CCREATE_BY,
                                                                      ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                                      ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                                      ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvMenuPrograms_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvMenuPrograms.R_ServiceGetRecord
        Dim loService As MenuProgramServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IMenuProgramService, MenuProgramServiceClient)(e_ServiceClientType.RegularService, C_ServiceNameMenuStream)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New SAM01100MenuProgramDTO With {._CCOMPANY_ID = _CCOMPID,
                                                                                        ._CMENU_ID = CType(bsGvMenu.Current, SAM01100DTO)._CMENU_ID,
                                                                                        ._CPROGRAM_ID = CType(poEntity, SAM01100MenuProgramDTO)._CPROGRAM_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvMenuPrograms_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvMenuPrograms.R_Saving
        With CType(poEntity, SAM01100MenuProgramDTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CMENU_ID = CType(bsGvMenu.Current, SAM01100DTO)._CMENU_ID
            ._DDATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            ._CUSERID = _CUSERID
        End With
    End Sub

    Private Sub gvMenuPrograms_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvMenuPrograms.R_ServiceSave
        Dim loService As MenuProgramServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IMenuProgramService, MenuProgramServiceClient)(e_ServiceClientType.RegularService, C_ServiceNameMenuStream)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvMenuPrograms_R_ServiceDelete(poEntity As Object) Handles gvMenuPrograms.R_ServiceDelete
        Dim loService As MenuProgramServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IMenuProgramService, MenuProgramServiceClient)(e_ServiceClientType.RegularService, C_ServiceNameMenuStream)
        Dim loEx As New R_Exception

        Try
            With CType(poEntity, SAM01100MenuProgramDTO)
                ._CCOMPANY_ID = _CCOMPID
                ._CMENU_ID = CType(bsGvMenu.Current, SAM01100DTO)._CMENU_ID
            End With

            loService.Svc_R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#Region "CONDUCTOR MENU PROGRAMS"
    Private Sub conGridMenuPrograms_R_SetAdd(plEnable As Boolean) Handles conGridMenuPrograms.R_SetAdd
        gvMenu.Enabled = Not plEnable
        btnProgram.Enabled = Not plEnable
    End Sub

    Private Sub conGridMenuPrograms_R_SetEdit(plEnable As Boolean) Handles conGridMenuPrograms.R_SetEdit
        gvMenu.Enabled = Not plEnable
        btnProgram.Enabled = Not plEnable
    End Sub
#End Region
#End Region

    Private Sub SAM01100_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#Region "POPUP REGION"
#Region "POPUP PROGRAM"
    Private Sub btnProgram_R_After_Open_Form(poPopUpResult As System.Windows.Forms.DialogResult, poPopUpEntityResult As Object) Handles btnProgram.R_After_Open_Form
        Dim loEx As New R_Exception
        Dim loBatchPar As R_BatchParameter
        Dim loSvc As R_ProcessAndUploadClient
        Dim loBigObject As List(Of SAM01100Common.SAM01100BatchDTO)
        Dim lcKeyGuid As String
        Dim loUserPar As R_KeyValue
        Dim loUserParameters As New List(Of R_KeyValue)

        Try
            If poPopUpResult = Windows.Forms.DialogResult.OK Then
                If poPopUpEntityResult.Count = 0 Then
                    loEx.Add(R_Utility.R_GetError(GetType(Resources_Dummy_Class), "PS006"))
                    Exit Try
                End If

                With loUserPar
                    .Key = "CMENU_ID"
                    .Value = CType(bsGvMenu.Current, SAM01100DTO)._CMENU_ID
                End With
                loUserParameters.Add(loUserPar)

                With loUserPar
                    .Key = "DDATE"
                    .Value = DateTime.Now
                End With
                loUserParameters.Add(loUserPar)

                'Instantiate FrontHelper
                loSvc = New R_ProcessAndUploadClient(bwSAM01100, Nothing, Nothing)
                AddHandler loSvc.ProcessError, AddressOf ProcessError
                AddHandler loSvc.ProcessComplete, AddressOf ProcessComplete

                loBigObject = CType(poPopUpEntityResult, List(Of ProgramDTO)) _
                .Select(Function(x) New SAM01100Common.SAM01100BatchDTO() _
                        With {.CPROGRAM_ID = x.CPROGRAM_ID}).ToList()

                If loBigObject.Count = 0 Then
                    Exit Try
                End If

                With loBatchPar
                    .COMPANY_ID = _CCOMPID
                    .USER_ID = _CUSERID
                    .ClassName = "SAM01100Back.SAM01100MenuProgramCls"
                    .BigObject = loBigObject
                    .UserParameters = loUserParameters
                End With
                lcKeyGuid = loSvc.R_BatchProcess(loBatchPar, poPopUpEntityResult.Count)

                'gvMenuPrograms.R_RefreshGrid(CType(bsGvMenu.Current, SAM01100DTO)._CMENU_ID)
            End If
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If
    End Sub

    Private Sub btnProgram_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnProgram.R_Before_Open_Form
        poTargetForm = New ProgramForm

        Dim loPar As New Dictionary(Of String, Object)
        loPar.Item("CMENU_ID") = CType(bsGvMenu.Current, SAM01100DTO)._CMENU_ID
        loPar.Item("CCOMP_ID") = _CCOMPID
        loPar.Item("CUSER_ID") = _CUSERID

        poParameter = loPar

        btnProgram.R_Title = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_MenuPrograms")
    End Sub
#End Region

#Region "POPUP BUTTON ACCESS"
    Private Sub btnPopupBtnAccess_R_After_Open_Form(poPopUpResult As System.Windows.Forms.DialogResult, poPopUpEntityResult As Object) Handles btnPopupBtnAccess.R_After_Open_Form
        Dim loService As MenuProgramServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IMenuProgramService, MenuProgramServiceClient)(e_ServiceClientType.RegularService, C_ServiceNameMenuStream)
        Dim loSave As New SAM01100MenuProgramDTO
        Dim cAccessBtn As String
        Dim loEx As New R_Exception()
        Dim loAccessList As String()

        Try
            If poPopUpResult = Windows.Forms.DialogResult.Cancel Then
                Exit Sub
            End If

            With loSave
                ._CCOMPANY_ID = _CCOMPID
                ._CPROGRAM_ID = CType(bsGvMenuPrograms.Current, SAM01100MenuProgramDTO)._CPROGRAM_ID
                ._CMENU_ID = CType(bsGvMenu.Current, SAM01100DTO)._CMENU_ID

                loAccessList = CType(poPopUpEntityResult, List(Of ButtonDTO)).Select(Function(x) x.CBUTTON_ID).ToArray

                cAccessBtn = String.Join(",", loAccessList)

                ._CACCESS_ID = cAccessBtn
                ._CUSERID = _CUSERID
                ._DDATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            End With

            loService.saveButtonAccess(loSave)

            gvMenuPrograms.R_RefreshGrid(CType(bsGvMenu.Current, SAM01100DTO)._CMENU_ID)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub btnPopupBtnAccess_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnPopupBtnAccess.R_Before_Open_Form
        Dim loParam As New SAM01100MenuProgramDTO
        Dim loEx As New R_Exception()
        Dim loServiceStream As SAM01100StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01100StreamingService, SAM01100StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of ButtonDTO)
        Dim loListEntity As New List(Of ButtonDTO)

        Try
            With CType(bsGvMenuPrograms.Current, SAM01100MenuProgramDTO)
                R_Utility.R_SetStreamingContext("ProgID", ._CPROGRAM_ID)
                R_Utility.R_SetStreamingContext("CompID", _CCOMPID)
                R_Utility.R_SetStreamingContext("MenuID", CType(bsGvMenu.Current, SAM01100DTO)._CMENU_ID)
            End With

            loRtn = loServiceStream.getProgramButton()
            loStreaming = R_StreamUtility(Of ButtonDTO).ReadFromMessage(loRtn)

            For Each loDto As ButtonDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next

            If loListEntity.Count = 0 Then
                Throw New Exception(R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS003"))
            End If

            poTargetForm = New ButtonAccess

            loParam = bsGvMenuPrograms.Current

            loParam._CCOMPANY_ID = _CCOMPID
            loParam._CUSERID = _CUSERID

            poParameter = loParam
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If
    End Sub
#End Region

#Region "POPUP GENERAL ACCESS"
    Private Sub btnPopUpGeneral_R_Access_PopUp_Form(ByRef pcPopUpAccess As String) Handles btnPopUpGeneral.R_Access_PopUp_Form
        pcPopUpAccess = "U,V"
    End Sub

    Private Sub btnPopUpGeneral_R_After_Open_Form(poPopUpResult As System.Windows.Forms.DialogResult, poPopUpEntityResult As Object) Handles btnPopUpGeneral.R_After_Open_Form
        Dim loService As MenuProgramServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IMenuProgramService, MenuProgramServiceClient)(e_ServiceClientType.RegularService, C_ServiceNameMenuStream)
        Dim loSave As New SAM01100MenuProgramDTO
        Dim loEx As New R_Exception()

        Try
            If poPopUpResult = Windows.Forms.DialogResult.OK Then
                With loSave
                    ._CCOMPANY_ID = _CCOMPID
                    ._CPROGRAM_ID = CType(bsGvMenuPrograms.Current, SAM01100MenuProgramDTO)._CPROGRAM_ID
                    ._CMENU_ID = CType(bsGvMenu.Current, SAM01100DTO)._CMENU_ID
                    ._CPROGRAM_ACCESS = poPopUpEntityResult
                    ._CUSERID = _CUSERID
                    ._DDATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                End With

                loService.saveGeneralAccess(loSave)

                gvMenuPrograms.R_RefreshGrid(CType(bsGvMenu.Current, SAM01100DTO)._CMENU_ID)
            Else
                Exit Sub
            End If
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub btnPopUpGeneral_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnPopUpGeneral.R_Before_Open_Form
        poTargetForm = New GeneralAccess

        poParameter = New SAM01100MenuProgramDTOnon With {.CPROGRAM_ID = CType(bsGvMenuPrograms.Current, SAM01100MenuProgramDTO)._CPROGRAM_ID,
                                                            .CPROGRAM_NAME = CType(bsGvMenuPrograms.Current, SAM01100MenuProgramDTO)._CPROGRAM_NAME,
                                                            .CPROGRAM_ACCESS = CType(bsGvMenuPrograms.Current, SAM01100MenuProgramDTO)._CPROGRAM_ACCESS}

        btnPopUpGeneral.R_Title = R_Utility.R_GetMessage(GetType(SAM01100FrontResources.Resources_Dummy_Class), "_CPROGRAM_ACCESS")
    End Sub
#End Region
#End Region

    Private Sub ProcessComplete(pcKeyGuid As String, poProcessResultMode As eProcessResultMode)
        Dim loEx As New R_Exception()

        Select Case poProcessResultMode
            Case eProcessResultMode.Success
                R_RadMessageBox.Show(R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_Complete"), Windows.Forms.MessageBoxButtons.OK)
                gvMenuPrograms.R_RefreshGrid(CType(bsGvMenu.Current, SAM01100DTO)._CMENU_ID)
            Case eProcessResultMode.Fail
                Dim loException As New R_Exception
                Dim loRtn As List(Of R_ErrorStatusReturn)
                Dim loHelp As New R_ProcessAndUploadClient(bwSAM01100, Nothing, Nothing)
                Dim loPar As R_UploadAndProcessKey

                Try
                    With loPar
                        .COMPANY_ID = _CCOMPID
                        .USER_ID = _CUSERID
                        .KEY_GUID = pcKeyGuid
                    End With
                    loRtn = loHelp.R_GetErrorProcess(loPar)

                    For Each loError As R_ErrorStatusReturn In loRtn
                        loEx.Add(loError.SeqNo.ToString, loError.ErrorMessage)
                    Next
                Catch ex As Exception
                    loException.Add(ex)
                End Try

                If loException.Haserror Then
                    loEx.ThrowExceptionIfErrors()
                End If
        End Select
    End Sub

    Private Sub ProcessError(pcKeyGuid As String, ex As R_Exception)
        Dim loException As New R_Exception
        If ex.Haserror Then
            For Each loError As R_Error In ex.ErrorList
                loException.Add(loError)
            Next
        End If

        If loException.Haserror Then
            Me.R_DisplayException(loException)
        End If
    End Sub

End Class
