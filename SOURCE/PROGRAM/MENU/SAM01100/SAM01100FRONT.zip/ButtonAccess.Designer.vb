﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ButtonAccess
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewCheckBoxSelectColumn1 As R_FrontEnd.R_GridViewCheckBoxSelectColumn = New R_FrontEnd.R_GridViewCheckBoxSelectColumn()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.conGridBtnAccess = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.R_RadLabel1 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel2 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtProgId = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtProgName = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.gvProgButton = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsBtnAccess = New System.Windows.Forms.BindingSource(Me.components)
        Me.rtnPopup = New R_FrontEnd.R_ReturnPopUp()
        CType(Me.conGridBtnAccess, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtProgId, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtProgName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvProgButton, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvProgButton.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsBtnAccess, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'conGridBtnAccess
        '
        Me.conGridBtnAccess.R_ConductorParent = Nothing
        Me.conGridBtnAccess.R_IsHeader = True
        Me.conGridBtnAccess.R_RadGroupBox = Nothing
        '
        'R_RadLabel1
        '
        Me.R_RadLabel1.AutoSize = False
        Me.R_RadLabel1.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel1.Location = New System.Drawing.Point(13, 13)
        Me.R_RadLabel1.Name = "R_RadLabel1"
        Me.R_RadLabel1.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel1.R_ResourceId = "_CPROGRAM_ID"
        Me.R_RadLabel1.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel1.TabIndex = 1
        Me.R_RadLabel1.Text = "R_RadLabel1"
        '
        'R_RadLabel2
        '
        Me.R_RadLabel2.AutoSize = False
        Me.R_RadLabel2.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel2.Location = New System.Drawing.Point(13, 37)
        Me.R_RadLabel2.Name = "R_RadLabel2"
        Me.R_RadLabel2.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel2.R_ResourceId = "_CPROGRAM_NAME"
        Me.R_RadLabel2.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel2.TabIndex = 2
        Me.R_RadLabel2.Text = "R_RadLabel2"
        '
        'txtProgId
        '
        Me.txtProgId.Location = New System.Drawing.Point(119, 12)
        Me.txtProgId.Name = "txtProgId"
        Me.txtProgId.R_ConductorGridSource = Nothing
        Me.txtProgId.R_ConductorSource = Nothing
        Me.txtProgId.R_UDT = Nothing
        Me.txtProgId.ReadOnly = True
        Me.txtProgId.Size = New System.Drawing.Size(250, 20)
        Me.txtProgId.TabIndex = 3
        Me.txtProgId.TabStop = False
        '
        'txtProgName
        '
        Me.txtProgName.Location = New System.Drawing.Point(119, 36)
        Me.txtProgName.Name = "txtProgName"
        Me.txtProgName.R_ConductorGridSource = Nothing
        Me.txtProgName.R_ConductorSource = Nothing
        Me.txtProgName.R_UDT = Nothing
        Me.txtProgName.ReadOnly = True
        Me.txtProgName.Size = New System.Drawing.Size(250, 20)
        Me.txtProgName.TabIndex = 4
        Me.txtProgName.TabStop = False
        '
        'gvProgButton
        '
        Me.gvProgButton.Location = New System.Drawing.Point(12, 75)
        '
        '
        '
        Me.gvProgButton.MasterTemplate.AllowAddNewRow = False
        Me.gvProgButton.MasterTemplate.AllowDeleteRow = False
        Me.gvProgButton.MasterTemplate.AutoGenerateColumns = False
        Me.gvProgButton.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewCheckBoxSelectColumn1.EditMode = Telerik.WinControls.UI.EditMode.OnValueChange
        R_GridViewCheckBoxSelectColumn1.EnableHeaderCheckBox = True
        R_GridViewCheckBoxSelectColumn1.FieldName = "LSELECTED"
        R_GridViewCheckBoxSelectColumn1.HeaderText = ""
        R_GridViewCheckBoxSelectColumn1.MaxWidth = 20
        R_GridViewCheckBoxSelectColumn1.Name = "LSELECTED"
        R_GridViewCheckBoxSelectColumn1.R_EnableEDIT = True
        R_GridViewCheckBoxSelectColumn1.R_ResourceId = Nothing
        R_GridViewCheckBoxSelectColumn1.Width = 20
        R_GridViewTextBoxColumn1.FieldName = "CBUTTON_ID"
        R_GridViewTextBoxColumn1.HeaderText = "CBUTTON_ID"
        R_GridViewTextBoxColumn1.IsAutoGenerated = True
        R_GridViewTextBoxColumn1.Name = "CBUTTON_ID"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CBUTTON_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 104
        R_GridViewTextBoxColumn2.FieldName = "CBUTTON_DESCRIPTION_ID"
        R_GridViewTextBoxColumn2.HeaderText = "CBUTTON_DESCRIPTION_ID"
        R_GridViewTextBoxColumn2.IsAutoGenerated = True
        R_GridViewTextBoxColumn2.Name = "CBUTTON_DESCRIPTION_ID"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CBUTTON_DESCRIPTION_ID"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 104
        R_GridViewTextBoxColumn3.FieldName = "CBUTTON_DESCRIPTION"
        R_GridViewTextBoxColumn3.HeaderText = "CBUTTON_DESCRIPTION"
        R_GridViewTextBoxColumn3.IsAutoGenerated = True
        R_GridViewTextBoxColumn3.Name = "CBUTTON_DESCRIPTION"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CBUTTON_DESCRIPTION"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 139
        Me.gvProgButton.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewCheckBoxSelectColumn1, R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3})
        Me.gvProgButton.MasterTemplate.DataSource = Me.bsBtnAccess
        Me.gvProgButton.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvProgButton.MasterTemplate.EnableFiltering = True
        Me.gvProgButton.MasterTemplate.EnableGrouping = False
        Me.gvProgButton.MasterTemplate.ShowFilteringRow = False
        Me.gvProgButton.MasterTemplate.ShowGroupedColumns = True
        Me.gvProgButton.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvProgButton.Name = "gvProgButton"
        Me.gvProgButton.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvProgButton.R_ConductorGridSource = Me.conGridBtnAccess
        Me.gvProgButton.R_ConductorSource = Nothing
        Me.gvProgButton.R_DataAdded = False
        Me.gvProgButton.R_GridType = R_FrontEnd.R_eGridType.BatchUpdating
        Me.gvProgButton.R_NewRowText = Nothing
        Me.gvProgButton.ShowHeaderCellButtons = True
        Me.gvProgButton.Size = New System.Drawing.Size(384, 283)
        Me.gvProgButton.TabIndex = 0
        Me.gvProgButton.Text = "R_RadGridView1"
        '
        'bsBtnAccess
        '
        Me.bsBtnAccess.DataSource = GetType(SAM01100Front.SAM01100StreamingServiceRef.ButtonDTO)
        '
        'rtnPopup
        '
        Me.rtnPopup.Location = New System.Drawing.Point(234, 364)
        Me.rtnPopup.Name = "rtnPopup"
        Me.rtnPopup.Size = New System.Drawing.Size(162, 31)
        Me.rtnPopup.TabIndex = 9
        '
        'ButtonAccess
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(408, 397)
        Me.Controls.Add(Me.gvProgButton)
        Me.Controls.Add(Me.rtnPopup)
        Me.Controls.Add(Me.txtProgName)
        Me.Controls.Add(Me.txtProgId)
        Me.Controls.Add(Me.R_RadLabel2)
        Me.Controls.Add(Me.R_RadLabel1)
        Me.Name = "ButtonAccess"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "Button Access"
        CType(Me.conGridBtnAccess, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtProgId, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtProgName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvProgButton.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvProgButton, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsBtnAccess, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents conGridBtnAccess As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsBtnAccess As System.Windows.Forms.BindingSource
    Friend WithEvents R_RadLabel1 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel2 As R_FrontEnd.R_RadLabel
    Friend WithEvents txtProgId As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtProgName As R_FrontEnd.R_RadTextBox
    Friend WithEvents rtnPopup As R_FrontEnd.R_ReturnPopUp
    Friend WithEvents gvProgButton As R_FrontEnd.R_RadGridView

End Class
