﻿Imports R_FrontEnd
Imports SAM01100Front.SAM01100ServiceRef
Imports SAM01100Front.SAM01100StreamingServiceRef
Imports R_Common
Imports System.ServiceModel.Channels
Imports ClientHelper
Imports SAM01100Front.MenuProgramServiceRef
Imports SAM01100FrontResources

Public Class ProgramForm

#Region " VARIABLE "
    Dim C_ServiceName As String = "SAM01100Service/SAM01100Service.svc"
    Dim C_ServiceNameStream As String = "SAM01100Service/SAM01100StreamingService/SAM01100StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
#End Region

    Private Sub ProgramForm_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class

        _CCOMPID = poParameter.Item("CCOMP_ID")
        _CUSERID = poParameter.Item("CUSER_ID")

        gvSelected.R_RefreshGrid(poParameter.Item("CMENU_ID"))
        gvSource.R_RefreshGrid(New ProgramDTO)
    End Sub

    Private Sub gvSource_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvSource.R_ServiceGetListRecord
        Dim loServiceStream As SAM01100StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01100StreamingService, SAM01100StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of ProgramDTO)
        Dim loListEntity As New List(Of ProgramDTO)
        Dim loListSelected As IEnumerable(Of ProgramDTO)

        Try
            loRtn = loServiceStream.getProgramList()
            loStreaming = R_StreamUtility(Of ProgramDTO).ReadFromMessage(loRtn)
            loListSelected = bsSelected.List.Cast(Of ProgramDTO)()

            For Each loDto As ProgramDTO In loStreaming
                If loDto IsNot Nothing Then
                    Dim loQuery = (From A In loListSelected Where A.CPROGRAM_ID = loDto.CPROGRAM_ID Select A).FirstOrDefault

                    If loQuery Is Nothing Then
                        loListEntity.Add(loDto)
                    End If
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSelected_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvSelected.R_ServiceGetListRecord
        Dim loServiceStream As SAM01100StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01100StreamingService, SAM01100StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of SAM01100MenuProgramDTOnon)
        Dim loListEntity As New List(Of ProgramDTO)

        Try
            R_Utility.R_SetStreamingContext("cCompId", _CCOMPID)
            R_Utility.R_SetStreamingContext("cMenuId", poEntity)

            loRtn = loServiceStream.getMenuProgramList()
            loStreaming = R_StreamUtility(Of SAM01100MenuProgramDTOnon).ReadFromMessage(loRtn)

            For Each loDto As SAM01100MenuProgramDTOnon In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New ProgramDTO With {.CPROGRAM_ID = loDto.CPROGRAM_ID,
                                                          .CPROGRAM_NAME = loDto.CPROGRAM_NAME})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub R_ReturnPopUp1_R_SetPopUpResult(ByRef poEntityResult As Object) Handles R_ReturnPopUp1.R_SetPopUpResult
        poEntityResult = bsSelected.List
    End Sub

    Private Sub R_ReturnPopUp1_R_ValidationPopUpResult(ByRef plCancel As Boolean, poButton As System.Windows.Forms.DialogResult) Handles R_ReturnPopUp1.R_ValidationPopUpResult
        Dim loEx As New R_Exception()

        Try
            If poButton = Windows.Forms.DialogResult.OK Then
                If bsSelected.Count = 0 Then
                    loEx.Add(R_Utility.R_GetError(GetType(Resources_Dummy_Class), "PS006"))
                    plCancel = True
                End If
            End If

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If
    End Sub
End Class
