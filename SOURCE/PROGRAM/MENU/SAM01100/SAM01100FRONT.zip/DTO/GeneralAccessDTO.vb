﻿<Serializable()> _
Public Class GeneralAccessDTO
    Public Property LSELECTED As Boolean
    Public Property CACCESS As String
End Class
