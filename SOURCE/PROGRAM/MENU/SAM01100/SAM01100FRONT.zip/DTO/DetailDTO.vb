﻿<Serializable()> _
Public Class DetailDTO
    Public Property CPROGRAM_ID As String
    Public Property CPROGRAM_NAME As String
    Public Property CPROGRAM_ACCESS As String
    'Public Property GENERAL_ACCESS As String
    'Public Property BUTTON_ACCESS As String

    Public Property LADD As Boolean
    Public Property LUPDATE As Boolean
    Public Property LDELETE As Boolean
    Public Property LPRINT As Boolean
    Public Property LVIEW As Boolean
End Class
