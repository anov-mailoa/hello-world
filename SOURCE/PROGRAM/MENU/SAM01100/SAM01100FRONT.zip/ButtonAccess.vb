﻿Imports R_FrontEnd
Imports R_Common
Imports System.ServiceModel.Channels
Imports System.Data.Common
Imports System.Threading
Imports SAM01100Front.SAM01100StreamingServiceRef
Imports Telerik.WinControls.UI
Imports SAM01100Front.MenuProgramServiceRef

Public Class ButtonAccess

#Region " VARIABLE "
    Dim C_ServiceNameStream As String = "SAM01100Service/SAM01100StreamingService/SAM01100StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
#End Region

    Private Sub ButtonAccess_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        With CType(poParameter, SAM01100MenuProgramDTO)
            txtProgId.Text = ._CPROGRAM_ID
            txtProgName.Text = ._CPROGRAM_NAME

            _CUSERID = ._CUSERID
            _CCOMPID = ._CCOMPANY_ID

            gvProgButton.R_RefreshGrid(poParameter)
        End With
    End Sub

    Private Sub rtnPopup_R_SetPopUpResult(ByRef poEntityResult As Object) Handles rtnPopup.R_SetPopUpResult
        Dim loRtn As New List(Of ButtonDTO)

        loRtn = bsBtnAccess.List

        loRtn = loRtn.Where(Function(x) x.LSELECTED = True).Select(Function(x) x).ToList

        poEntityResult = loRtn
    End Sub

    Private Sub gvProgButton_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvProgButton.R_ServiceGetListRecord
        Dim loServiceStream As SAM01100StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01100StreamingService, SAM01100StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of ButtonDTO)
        Dim loListEntity As New List(Of ButtonDTO)
        Dim lcNamespace As String
        Dim loType As Type

        Try
            With CType(poEntity, SAM01100MenuProgramDTO)
                R_Utility.R_SetStreamingContext("ProgID", ._CPROGRAM_ID)
                R_Utility.R_SetStreamingContext("CompID", _CCOMPID)

                R_DeployUtility.R_DynamicLoadObject(._CPROGRAM_ID + "Front", ._CPROGRAM_ID + "Front", ._CPROGRAM_ID)

                lcNamespace = ._CPROGRAM_ID + "FrontResources"
                loType = Type.GetType(lcNamespace + ".Resources_Dummy_Class, " + lcNamespace)
                If loType Is Nothing Then
                    Throw New Exception("Resources " & ._CPROGRAM_ID & " not found")
                End If
            End With

            loRtn = loServiceStream.getProgramButton()
            loStreaming = R_StreamUtility(Of ButtonDTO).ReadFromMessage(loRtn)

            For Each loDto As ButtonDTO In loStreaming
                If loDto IsNot Nothing Then
                    loDto.CBUTTON_DESCRIPTION = R_Utility.R_GetMessage(loType, loDto.CBUTTON_DESCRIPTION_ID)

                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next

            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub
End Class
