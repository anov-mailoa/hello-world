﻿Imports LAR00100FrontResources
Imports R_Common
Imports LAR00100Front.LAR00100ServiceRef
Imports R_FrontEnd
Imports ClientHelper
Imports LAR00100Front.LAR00100StreamingServiceRef
Imports System.ServiceModel.Channels
Imports CrystalDecisions.CrystalReports.Engine

Public Class LAR00100

#Region " VARIABLE "
    Dim C_ServiceName As String = "LAR00100Service/LAR00100Service.svc"
    Dim C_ServiceNameStream As String = "LAR00100Service/LAR00100StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim llInitialized As Boolean = False
#End Region

    Private Sub LAR00100_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loSvc As LAR00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAR00100Service, LAR00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loAppCombo As New List(Of RLicenseAppComboDTO)

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            ' Application
            loAppCombo = loSvc.GetAppCombo(_CCOMPID, _CUSERID)
            bsApps.DataSource = loAppCombo

            llInitialized = True
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

    Private Sub cboApplication_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboApplication.SelectedValueChanged
        Dim loEx As New R_Exception
        Dim loSvc As LAR00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAR00100Service, LAR00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loCustCombo As New List(Of RLicenseCustComboDTO)

        Try
            ' Customer
            loCustCombo = loSvc.GetCustByAppsCombo(_CCOMPID, CType(sender, R_RadDropDownList).SelectedValue)
            bsCust.DataSource = loCustCombo
            loSvc.Close()
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loEx.ThrowExceptionIfErrors()
    End Sub

#Region " Customer Configuration Button "

    Private Sub btnRpt_R_GetData(ByRef poData As Object) Handles btnRpt.R_GetData
        Dim loSvc As LAR00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAR00100Service, LAR00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loException As New R_Exception
        Dim loRtn As New List(Of LAR00100CuCoDtlDTO)
        Dim loParam As New LAR00100CuCoDtlDTO

        Try
            With loParam
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = cboApplication.SelectedValue.Trim
                .CCUSTOMER_CODE = cboCustomer.SelectedValue.Trim
            End With
            loRtn = loSvc.GetCuco(loParam)
            poData = loRtn
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub btnRpt_R_GetSubReportData(ByRef poData As Object, pcSubReportName As String) Handles btnRpt.R_GetSubReportData
        Dim loSvc As LAR00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAR00100Service, LAR00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loException As New R_Exception
        Dim loRtn As Object
        Dim loParam As Object

        Try
            Select Case pcSubReportName
                Case "LAR00100Contacts.rpt"
                    loParam = New LAR00100ContactDTO
                    loRtn = New List(Of LAR00100ContactDTO)()
                    With CType(loParam, LAR00100ContactDTO)
                        .CCOMPANY_ID = _CCOMPID
                        .CCUSTOMER_CODE = cboCustomer.SelectedValue.Trim
                    End With
                    loRtn = loSvc.GetContacts(loParam)
                Case "LAR00100Contracts.rpt"
                    loParam = New LAR00100ContractDTO
                    loRtn = New List(Of LAR00100ContractDTO)()
                    With CType(loParam, LAR00100ContractDTO)
                        .CCOMPANY_ID = _CCOMPID
                        .CAPPS_CODE = cboApplication.SelectedValue.Trim
                        .CCUSTOMER_CODE = cboCustomer.SelectedValue.Trim
                    End With
                    loRtn = loSvc.GetContracts(loParam)
            End Select
            poData = loRtn
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub btnRpt_R_InstantiateReport(ByRef poTargetReport As CrystalDecisions.CrystalReports.Engine.ReportDocument) Handles btnRpt.R_InstantiateReport
        Dim loadReportDoc As New ReportDocument
        loadReportDoc.FileName = U_GlobalVar.DTO.cReportFilePath + "\LAR00100CuCo.rpt"
        poTargetReport = loadReportDoc
        btnRpt.R_ReportTitle = "Customer Configuration"
        btnRpt.R_UserAndFileName = ClientHelper.U_GlobalVar.UserId & "_ea22"

    End Sub

    Private Sub btnRpt_R_SetLanguageData(ByRef poLanguageData As Object) Handles btnRpt.R_SetLanguageData

    End Sub

    Private Sub btnRpt_R_SetOutputOption(ByRef peCrystalOutputOption As R_FrontEnd.R_eCrystalOutputOption) Handles btnRpt.R_SetOutputOption
        peCrystalOutputOption = R_eCrystalOutputOption.View
    End Sub

    Private Sub btnRpt_R_SetParameter(ByRef poReport As CrystalDecisions.CrystalReports.Engine.ReportDocument) Handles btnRpt.R_SetParameter
        Dim loSvc As LAR00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAR00100Service, LAR00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loException As New R_Exception
        Dim loRtn As New LAR00100CustInfoDTO
        Dim loParam As New LAR00100CustInfoDTO


        Try
            With loParam
                .CCOMPANY_ID = _CCOMPID
                .CCUSTOMER_CODE = cboCustomer.SelectedValue.Trim
            End With
            loRtn = loSvc.GetCustInfo(loParam)
            With poReport
                .SetParameterValue("p_AppsName", cboApplication.SelectedItem.DataBoundItem.CAPPS_NAME)
                .SetParameterValue("p_Customer", cboCustomer.SelectedItem.DataBoundItem.CCUSTOMER_NAME)
                .SetParameterValue("p_Address", loRtn.CADDRESS)
                .SetParameterValue("p_Phone1", loRtn.CPHONE_1)
                .SetParameterValue("p_Phone2", loRtn.CPHONE_2)
                .SetParameterValue("p_FaxNo", loRtn.CFAX_NO)
            End With
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()

    End Sub

#End Region

End Class
