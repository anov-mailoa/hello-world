﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LAR00100
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.cboCustomer = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.cboApplication = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.lblCustomer = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.btnRpt = New R_FrontEnd.R_CrystalButton(Me.components)
        Me.bsCust = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        CType(Me.cboCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnRpt, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsCust, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cboCustomer
        '
        Me.cboCustomer.DataSource = Me.bsCust
        Me.cboCustomer.DisplayMember = "CCUSTOMER_NAME"
        Me.cboCustomer.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboCustomer.Location = New System.Drawing.Point(118, 38)
        Me.cboCustomer.Name = "cboCustomer"
        Me.cboCustomer.R_ConductorGridSource = Nothing
        Me.cboCustomer.R_ConductorSource = Nothing
        Me.cboCustomer.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboCustomer.Size = New System.Drawing.Size(400, 20)
        Me.cboCustomer.TabIndex = 11
        Me.cboCustomer.Text = "R_RadDropDownList1"
        Me.cboCustomer.ValueMember = "CCUSTOMER_CODE"
        '
        'cboApplication
        '
        Me.cboApplication.DataSource = Me.bsApps
        Me.cboApplication.DisplayMember = "CAPPS_NAME"
        Me.cboApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboApplication.Location = New System.Drawing.Point(118, 12)
        Me.cboApplication.Name = "cboApplication"
        Me.cboApplication.R_ConductorGridSource = Nothing
        Me.cboApplication.R_ConductorSource = Nothing
        Me.cboApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboApplication.Size = New System.Drawing.Size(400, 20)
        Me.cboApplication.TabIndex = 10
        Me.cboApplication.Text = "R_RadDropDownList1"
        Me.cboApplication.ValueMember = "CAPPS_CODE"
        '
        'lblCustomer
        '
        Me.lblCustomer.AutoSize = False
        Me.lblCustomer.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustomer.Location = New System.Drawing.Point(12, 36)
        Me.lblCustomer.Name = "lblCustomer"
        Me.lblCustomer.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustomer.R_ResourceId = "lblCustomer"
        Me.lblCustomer.Size = New System.Drawing.Size(100, 18)
        Me.lblCustomer.TabIndex = 9
        Me.lblCustomer.Text = "Customer..."
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(12, 12)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 8
        Me.lblApplication.Text = "Application..."
        '
        'btnRpt
        '
        Me.btnRpt.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnRpt.Location = New System.Drawing.Point(368, 64)
        Me.btnRpt.Name = "btnRpt"
        Me.btnRpt.R_ConductorGridSource = Nothing
        Me.btnRpt.R_ConductorSource = Nothing
        Me.btnRpt.R_CrystalOption = Nothing
        Me.btnRpt.R_DescriptionId = Nothing
        Me.btnRpt.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.btnRpt.R_NoDataMessage = ""
        Me.btnRpt.R_ReportTitle = "test 123"
        Me.btnRpt.R_ResourceId = "btnRpt"
        Me.btnRpt.R_UserAndFileName = Nothing
        Me.btnRpt.Size = New System.Drawing.Size(150, 24)
        Me.btnRpt.TabIndex = 20
        Me.btnRpt.Text = "Report"
        '
        'bsCust
        '
        Me.bsCust.DataSource = GetType(LAR00100Front.LAR00100ServiceRef.RLicenseCustComboDTO)
        '
        'bsApps
        '
        Me.bsApps.DataSource = GetType(LAR00100Front.LAR00100ServiceRef.RLicenseAppComboDTO)
        '
        'LAR00100
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(525, 96)
        Me.Controls.Add(Me.btnRpt)
        Me.Controls.Add(Me.cboCustomer)
        Me.Controls.Add(Me.cboApplication)
        Me.Controls.Add(Me.lblCustomer)
        Me.Controls.Add(Me.lblApplication)
        Me.Name = "LAR00100"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.cboCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnRpt, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsCust, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cboCustomer As R_FrontEnd.R_RadDropDownList
    Friend WithEvents cboApplication As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblCustomer As R_FrontEnd.R_RadLabel
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents btnRpt As R_FrontEnd.R_CrystalButton
    Friend WithEvents bsCust As System.Windows.Forms.BindingSource
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource

End Class
