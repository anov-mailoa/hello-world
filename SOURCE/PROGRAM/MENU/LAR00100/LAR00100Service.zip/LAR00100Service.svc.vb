﻿Imports RLicenseBack
Imports R_Common
Imports LAR00100Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "LAR00100Service" in code, svc and config file together.
Public Class LAR00100Service
    Implements ILAR00100Service

    Public Function GetAppCombo(companyId As String, userId As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseAppComboDTO) Implements ILAR00100Service.GetAppCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseAppComboDTO)

        Try
            loRtn = loCls.GetAppCombo(companyId, userId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetCustByAppsCombo(companyId As String, appsCode As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseCustComboDTO) Implements ILAR00100Service.GetCustByAppsCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseCustComboDTO)

        Try
            loRtn = loCls.GetCustByAppsCombo(companyId, appsCode)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    'Public Function Dummy1() As System.Collections.Generic.List(Of LAR00100Back.LAR00100CuCoDtlDTO) Implements ILAR00100Service.Dummy1

    'End Function

    Public Function GetAppInfo(tableKey As LAR00100Back.LAR00100AppsDTO) As LAR00100Back.LAR00100AppsDTO Implements ILAR00100Service.GetAppInfo
        Dim loException As New R_Exception
        Dim loCls As New LAR00100Cls
        Dim loRtn As New LAR00100AppsDTO

        Try
            loRtn = loCls.GetAppInfo(tableKey)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetContacts(tableKey As LAR00100Back.LAR00100ContactDTO) As System.Collections.Generic.List(Of LAR00100Back.LAR00100ContactDTO) Implements ILAR00100Service.GetContacts
        Dim loException As New R_Exception
        Dim loCls As New LAR00100Cls
        Dim loRtn As List(Of LAR00100ContactDTO)

        Try
            loRtn = loCls.GetContacts(tableKey)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetContracts(tableKey As LAR00100Back.LAR00100ContractDTO) As System.Collections.Generic.List(Of LAR00100Back.LAR00100ContractDTO) Implements ILAR00100Service.GetContracts
        Dim loException As New R_Exception
        Dim loCls As New LAR00100Cls
        Dim loRtn As List(Of LAR00100ContractDTO)

        Try
            loRtn = loCls.GetContracts(tableKey)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetCustInfo(tableKey As LAR00100Back.LAR00100CustInfoDTO) As LAR00100Back.LAR00100CustInfoDTO Implements ILAR00100Service.GetCustInfo
        Dim loException As New R_Exception
        Dim loCls As New LAR00100Cls
        Dim loRtn As New LAR00100CustInfoDTO

        Try
            loRtn = loCls.GetCustInfo(tableKey)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetCuco(tableKey As LAR00100Back.LAR00100CuCoDtlDTO) As System.Collections.Generic.List(Of LAR00100Back.LAR00100CuCoDtlDTO) Implements ILAR00100Service.GetCuco
        Dim loException As New R_Exception
        Dim loCls As New LAR00100Cls
        Dim loRtn As List(Of LAR00100CuCoDtlDTO)

        Try
            loRtn = loCls.GetCuCo(tableKey)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()
        Return loRtn
    End Function

    Public Function GetCuCoHistory(tableKey As LAR00100Back.LAR00100CuCoDtlDTO) As System.Collections.Generic.List(Of LAR00100Back.LAR00100CuCoDtlDTO) Implements ILAR00100Service.GetCuCoHistory
        Dim loException As New R_Exception
        Dim loCls As New LAR00100Cls
        Dim loRtn As List(Of LAR00100CuCoDtlDTO)

        Try
            loRtn = loCls.GetCuCoHistory(tableKey)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()
        Return loRtn
    End Function
End Class
