﻿Public Class LAR00100CuCoDtlDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CCUSTOMER_CODE As String
    Public Property CCONFIG_ID As String
    Public Property CFIELD_NAME As String
    Public Property CLEVEL_1 As String
    Public Property CLEVEL_2 As String
    Public Property CLEVEL_3 As String
    Public Property CLEVEL_4 As String
    Public Property CLEVEL_5 As String
    Public Property CPRINT_LABEL As String
    Public Property CFIELD_VALUE As String
    Public Property CSEQUENCE As String
    ' History
    Public Property DCONFIG_DATE As DateTime
    Public Property CCONFIG_BY As String
    Public Property CNOTE As String
End Class
