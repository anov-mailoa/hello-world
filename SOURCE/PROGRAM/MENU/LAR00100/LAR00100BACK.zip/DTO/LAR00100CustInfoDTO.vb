﻿Public Class LAR00100CustInfoDTO
    Public Property CCOMPANY_ID As String
    Public Property CCUSTOMER_CODE As String
    Public Property CCUSTOMER_NAME As String
    Public Property CADDRESS As String
    Public Property CZIP_CODE As String
    Public Property CCITY As String
    Public Property CCOUNTRY As String
    Public Property CEMAIL_ADDRESS As String
    Public Property CPHONE_1 As String
    Public Property CPHONE_2 As String
    Public Property CFAX_NO As String
    Public Property CLOB_CODE As String
    Public Property CWEB_SITE As String
    Public Property CCUSTOMER_GROUP As String
End Class
