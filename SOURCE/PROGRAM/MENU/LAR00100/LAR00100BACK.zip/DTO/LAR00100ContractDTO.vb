﻿Public Class LAR00100ContractDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CCUSTOMER_CODE As String
    Public Property CCONTRACT_NO As String
    Public Property DCONTRACT_DATE As DateTime
    Public Property CDESCRIPTION As String
End Class
