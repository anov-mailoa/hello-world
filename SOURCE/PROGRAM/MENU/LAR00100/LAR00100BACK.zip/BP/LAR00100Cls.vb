﻿Imports R_Common
Imports R_BackEnd
Imports System.Data.Common

Public Class LAR00100Cls

    Public Function GetAppInfo(poTableKey As LAR00100AppsDTO) As LAR00100AppsDTO
        Dim lcQuery As String
        Dim loResult As New LAR00100AppsDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poTableKey

                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "LAM_APPS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                If .CAPPS_CODE IsNot Nothing Then
                    If Not .CAPPS_CODE.Trim.Equals("") Then
                        lcQuery += "AND CAPPS_CODE = '{1}' "
                    End If
                End If
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE)
            End With

            loResult = loDb.SqlExecObjectQuery(Of LAR00100AppsDTO)(lcQuery).FirstOrDefault
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetCustInfo(poTableKey As LAR00100CustInfoDTO) As LAR00100CustInfoDTO
        Dim lcQuery As String
        Dim loResult As New LAR00100CustInfoDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poTableKey

                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "LAM_CUSTOMER (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                If .CCUSTOMER_CODE IsNot Nothing Then
                    If Not .CCUSTOMER_CODE.Trim.Equals("") Then
                        lcQuery += "AND CCUSTOMER_CODE = '{1}' "
                    End If
                End If
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CCUSTOMER_CODE)
            End With

            loResult = loDb.SqlExecObjectQuery(Of LAR00100CustInfoDTO)(lcQuery).FirstOrDefault
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetContacts(poTableKey As LAR00100ContactDTO) As List(Of LAR00100ContactDTO)
        Dim lcQuery As String
        Dim loResult As List(Of LAR00100ContactDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poTableKey

                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "LAM_CUSTOMER_CONTACT (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                If .CCUSTOMER_CODE IsNot Nothing Then
                    If Not .CCUSTOMER_CODE.Trim.Equals("") Then
                        lcQuery += "AND CCUSTOMER_CODE = '{1}' "
                    End If
                End If
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CCUSTOMER_CODE)
            End With

            loResult = loDb.SqlExecObjectQuery(Of LAR00100ContactDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetContracts(poTableKey As LAR00100ContractDTO) As List(Of LAR00100ContractDTO)
        Dim lcQuery As String
        Dim loResult As List(Of LAR00100ContractDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poTableKey

                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "LAT_CONTRACT (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                If .CAPPS_CODE IsNot Nothing Then
                    If Not .CAPPS_CODE.Trim.Equals("") Then
                        lcQuery += "AND CAPPS_CODE = '{1}' "
                    End If
                End If
                If .CCUSTOMER_CODE IsNot Nothing Then
                    If Not .CCUSTOMER_CODE.Trim.Equals("") Then
                        lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                    End If
                End If
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CCUSTOMER_CODE)
            End With

            loResult = loDb.SqlExecObjectQuery(Of LAR00100ContractDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetCuCo(poTableKey As LAR00100CuCoDtlDTO) As List(Of LAR00100CuCoDtlDTO)
        Dim lcQuery As String
        Dim loResult As List(Of LAR00100CuCoDtlDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poTableKey
                lcQuery = "EXEC RSP_Customer_Configuration '{0}', '{1}', '{2}', '{3}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CCUSTOMER_CODE, "")
            End With

            loResult = loDb.SqlExecObjectQuery(Of LAR00100CuCoDtlDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetCuCoHistory(poTableKey As LAR00100CuCoDtlDTO) As List(Of LAR00100CuCoDtlDTO)
        Dim lcQuery As String
        Dim loResult As List(Of LAR00100CuCoDtlDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poTableKey
                lcQuery = "EXEC RSP_Customer_Configuration_History '{0}', '{1}', '{2}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CCUSTOMER_CODE)
            End With

            loResult = loDb.SqlExecObjectQuery(Of LAR00100CuCoDtlDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function
End Class
