﻿Imports R_Common
Imports CSM00100Back
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00100Service" in code, svc and config file together.
Public Class CSM00100Service
    Implements ICSM00100Service

    Public Sub Svc_R_Delete(poEntity As CSM00100Back.CSM00100AttrGrpDTO) Implements R_BackEnd.R_IServicebase(Of CSM00100Back.CSM00100AttrGrpDTO).Svc_R_Delete

    End Sub

    Public Function Svc_R_GetRecord(poEntity As CSM00100Back.CSM00100AttrGrpDTO) As CSM00100Back.CSM00100AttrGrpDTO Implements R_BackEnd.R_IServicebase(Of CSM00100Back.CSM00100AttrGrpDTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New CSM00100Cls
        Dim loRtn As CSM00100AttrGrpDTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As CSM00100Back.CSM00100AttrGrpDTO, poCRUDMode As R_Common.eCRUDMode) As CSM00100Back.CSM00100AttrGrpDTO Implements R_BackEnd.R_IServicebase(Of CSM00100Back.CSM00100AttrGrpDTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New CSM00100Cls
        Dim loRtn As CSM00100AttrGrpDTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetAppCombo(companyId As String, userId As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseAppComboDTO) Implements ICSM00100Service.GetAppCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseAppComboDTO)

        Try
            loRtn = loCls.GetAppCombo(companyId, userId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn

    End Function

    Public Function GetFromAppCombo(companyId As String, userId As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseAppComboDTO) Implements ICSM00100Service.GetFromAppCombo
        Dim loException As New R_Exception
        Dim loCls As New CSM00100Cls
        Dim loRtn As List(Of RLicenseAppComboDTO)

        Try
            loRtn = loCls.GetFromAppCombo(companyId, userId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub GenerateAttributeGroup(poNewEntity As CSM00100Back.CSM00100AttrGrpDTO, pcFrom_Apps_Code As String) Implements ICSM00100Service.GenerateAttributeGroup
        Dim loEx As New R_Exception
        Dim loCls As New CSM00100Cls

        Try
            loCls.GenerateAttributeGroup(poNewEntity, pcFrom_Apps_Code)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

    End Sub

    Public Function Dummy1() As System.Collections.Generic.List(Of CSM00100Back.CSM00100AttrGrpKeyDTO) Implements ICSM00100Service.Dummy1

    End Function
End Class
