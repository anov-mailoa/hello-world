﻿Imports System.ServiceModel
Imports CSM00100Back
Imports R_BackEnd
Imports R_Common

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00100SourceGroupService" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00100SourceGroupService
    Inherits R_IServicebase(Of CSM00100SourceGroupDTO)

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function Dummy1() As List(Of CSM00100SourceGroupKeyDTO)

End Interface
