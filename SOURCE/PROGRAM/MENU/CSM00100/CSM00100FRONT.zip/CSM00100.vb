﻿Imports CSM00100FrontResources
Imports R_Common
Imports ClientHelper
Imports CSM00100Front.CSM00100ServiceRef
Imports CSM00100Front.CSM00100StreamingServiceRef
Imports R_FrontEnd
Imports System.ServiceModel.Channels

Public Class CSM00100

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSM00100Service/CSM00100Service.svc"
    Dim C_ServiceNameStream As String = "CSM00100Service/CSM00100StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim llInitialized As Boolean = False
#End Region

    Private Sub RefreshGrids()
        Dim loTableKey As New CSM00100AttrGrpKeyDTO

        With loTableKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = cboApplication.SelectedValue.Trim
        End With

        gvAttributeGroup.R_RefreshGrid(loTableKey)
        btnGenerate.Enabled = (bsGvAttributeGroup.Count = 0)
    End Sub

    Private Sub CSM00100_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Dim loSvc As CSM00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00100Service, CSM00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loAppCombo As New List(Of RLicenseAppComboDTO)
        Dim loFromAppCombo As New List(Of RLicenseAppComboDTO)

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            ' Application
            loAppCombo = loSvc.GetAppCombo(_CCOMPID, _CUSERID)
            If loAppCombo.Count <= 0 Then
                cboApplication.Items.Clear()
                loEx.Add("CSM00100_05", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00100_05"))
                Exit Try
            End If
            bsApps.DataSource = loAppCombo

            ' From Application
            loFromAppCombo = loSvc.GetFromAppCombo(_CCOMPID, _CUSERID)
            If loFromAppCombo.Count <= 0 Then
                cboFromApplication.Items.Clear()
            End If
            bsFromApps.DataSource = loFromAppCombo

            ' Grid
            llInitialized = True
            RefreshGrids()
            gvAttributeGroup.Columns(0).Sort(Telerik.WinControls.UI.RadSortOrder.Ascending, False)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        If loSvc IsNot Nothing Then
            loSvc.Close()
        End If

        loEx.ThrowExceptionIfErrors()

    End Sub

    Private Sub CSM00100_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

    Private Sub gvAttributeGroup_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvAttributeGroup.R_Saving
        With CType(poEntity, CSM00100AttrGrpDTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = cboApplication.SelectedValue.Trim
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With
    End Sub

    Private Sub gvAttributeGroup_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvAttributeGroup.R_ServiceGetListRecord
        Dim loServiceStream As CSM00100StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00100StreamingService, CSM00100StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00100AttrGrpGridDTO)
        Dim loListEntity As New List(Of CSM00100AttrGrpDTO)

        Try
            With poEntity
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
            End With

            loRtn = loServiceStream.GetAttributeGroupList()
            loStreaming = R_StreamUtility(Of CSM00100AttrGrpGridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00100AttrGrpGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New CSM00100AttrGrpDTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                                  ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                                  ._CATTRIBUTE_GROUP = loDto.CATTRIBUTE_GROUP,
                                                                  ._LACTIVE = loDto.LACTIVE,
                                                                  ._CCREATE_BY = loDto.CCREATE_BY,
                                                                  ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                                  ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                                  ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        If loServiceStream IsNot Nothing Then
            loServiceStream.Close()
        End If

        loException.ThrowExceptionIfErrors()

    End Sub

    Private Sub cboApplication_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboApplication.SelectedValueChanged
        If llInitialized Then
            RefreshGrids()
        End If
    End Sub

    Private Sub gvAttributeGroup_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvAttributeGroup.R_ServiceGetRecord
        Dim loService As CSM00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00100Service, CSM00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New CSM00100AttrGrpDTO With {._CCOMPANY_ID = _CCOMPID,
                                                                             ._CAPPS_CODE = cboApplication.SelectedValue.Trim,
                                                                             ._CATTRIBUTE_GROUP = CType(bsGvAttributeGroup.Current, CSM00100AttrGrpDTO)._CATTRIBUTE_GROUP})
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loService IsNot Nothing Then
            loService.Close()
        End If
        loEx.ThrowExceptionIfErrors()

    End Sub

    Private Sub gvAttributeGroup_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvAttributeGroup.R_ServiceSave
        Dim loService As CSM00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00100Service, CSM00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loService IsNot Nothing Then
            loService.Close()
        End If
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub btnAttribute_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnAttribute.R_Before_Open_Form
        poTargetForm = New CSM00100Attributes
        poParameter = CType(bsGvAttributeGroup.Current, CSM00100AttrGrpDTO)
    End Sub

    Private Sub btnGenerate_Click(sender As System.Object, e As System.EventArgs) Handles btnGenerate.Click
        Dim loService As CSM00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00100Service, CSM00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim loPar As New CSM00100AttrGrpDTO
        Dim lcFromApplication As String

        Try
            With loPar
                ._CCOMPANY_ID = _CCOMPID
                ._CAPPS_CODE = cboApplication.SelectedValue
                ._LACTIVE = True
                ._CCREATE_BY = _CUSERID
                ._CUPDATE_BY = _CUSERID
            End With
            lcFromApplication = IIf(radAttributeGroupOnly.IsChecked, "", cboFromApplication.SelectedValue)
            loService.GenerateAttributeGroup(loPar, lcFromApplication)
            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loService IsNot Nothing Then
            loService.Close()
        End If
        loEx.ThrowExceptionIfErrors()
    End Sub
End Class
