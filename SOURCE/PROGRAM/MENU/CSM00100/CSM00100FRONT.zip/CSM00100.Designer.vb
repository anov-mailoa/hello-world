﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSM00100
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn1 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cboApplication = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnGenerate = New R_FrontEnd.R_RadButton(Me.components)
        Me.grpGenerate = New R_FrontEnd.R_RadGroupBox(Me.components)
        Me.cboFromApplication = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsFromApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.radCopyFromApplication = New R_FrontEnd.R_RadRadioButton(Me.components)
        Me.radAttributeGroupOnly = New R_FrontEnd.R_RadRadioButton(Me.components)
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btnAttribute = New R_FrontEnd.R_Detail(Me.components)
        Me.gvAttributeGroup = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvAttributeGroup = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridAttrGrp = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.lblAttributeGroup = New R_FrontEnd.R_RadLabel(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.btnGenerate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grpGenerate, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpGenerate.SuspendLayout()
        CType(Me.cboFromApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsFromApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.radCopyFromApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.radAttributeGroupOnly, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.btnAttribute, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvAttributeGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvAttributeGroup.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvAttributeGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridAttrGrp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblAttributeGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.TableLayoutPanel2, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 1
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.cboApplication)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 30)
        Me.Panel1.TabIndex = 0
        '
        'cboApplication
        '
        Me.cboApplication.DataSource = Me.bsApps
        Me.cboApplication.DisplayMember = "CAPPS_NAME"
        Me.cboApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboApplication.Location = New System.Drawing.Point(109, 5)
        Me.cboApplication.Name = "cboApplication"
        Me.cboApplication.R_ConductorGridSource = Nothing
        Me.cboApplication.R_ConductorSource = Nothing
        Me.cboApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboApplication.Size = New System.Drawing.Size(400, 20)
        Me.cboApplication.TabIndex = 8
        Me.cboApplication.Text = "R_RadDropDownList1"
        Me.cboApplication.ValueMember = "CAPPS_CODE"
        '
        'bsApps
        '
        Me.bsApps.DataSource = GetType(CSM00100Front.CSM00100ServiceRef.RLicenseAppComboDTO)
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(3, 5)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 7
        Me.lblApplication.Text = "Application..."
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 2
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 250.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.Panel2, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Panel3, 0, 0)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(3, 39)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(1271, 533)
        Me.TableLayoutPanel2.TabIndex = 1
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.btnGenerate)
        Me.Panel2.Controls.Add(Me.grpGenerate)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(253, 3)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1015, 527)
        Me.Panel2.TabIndex = 1
        '
        'btnGenerate
        '
        Me.btnGenerate.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnGenerate.Location = New System.Drawing.Point(17, 133)
        Me.btnGenerate.Name = "btnGenerate"
        Me.btnGenerate.R_ConductorGridSource = Nothing
        Me.btnGenerate.R_ConductorSource = Nothing
        Me.btnGenerate.R_DescriptionId = Nothing
        Me.btnGenerate.R_ResourceId = "btnGenerate"
        Me.btnGenerate.Size = New System.Drawing.Size(110, 24)
        Me.btnGenerate.TabIndex = 1
        Me.btnGenerate.Text = "R_RadButton1"
        '
        'grpGenerate
        '
        Me.grpGenerate.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping
        Me.grpGenerate.Controls.Add(Me.cboFromApplication)
        Me.grpGenerate.Controls.Add(Me.radCopyFromApplication)
        Me.grpGenerate.Controls.Add(Me.radAttributeGroupOnly)
        Me.grpGenerate.HeaderText = "R_RadGroupBox1"
        Me.grpGenerate.Location = New System.Drawing.Point(12, 27)
        Me.grpGenerate.Name = "grpGenerate"
        Me.grpGenerate.R_ConductorGridSource = Nothing
        Me.grpGenerate.R_ConductorSource = Nothing
        Me.grpGenerate.R_ResourceId = "grpGenerate"
        Me.grpGenerate.Size = New System.Drawing.Size(415, 100)
        Me.grpGenerate.TabIndex = 0
        Me.grpGenerate.Text = "R_RadGroupBox1"
        '
        'cboFromApplication
        '
        Me.cboFromApplication.DataSource = Me.bsFromApps
        Me.cboFromApplication.DisplayMember = "CAPPS_NAME"
        Me.cboFromApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboFromApplication.Location = New System.Drawing.Point(5, 69)
        Me.cboFromApplication.Name = "cboFromApplication"
        Me.cboFromApplication.R_ConductorGridSource = Nothing
        Me.cboFromApplication.R_ConductorSource = Nothing
        Me.cboFromApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboFromApplication.Size = New System.Drawing.Size(400, 20)
        Me.cboFromApplication.TabIndex = 9
        Me.cboFromApplication.Text = "R_RadDropDownList1"
        Me.cboFromApplication.ValueMember = "CAPPS_CODE"
        '
        'bsFromApps
        '
        Me.bsFromApps.DataSource = GetType(CSM00100Front.CSM00100ServiceRef.RLicenseAppComboDTO)
        '
        'radCopyFromApplication
        '
        Me.radCopyFromApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.radCopyFromApplication.Location = New System.Drawing.Point(5, 45)
        Me.radCopyFromApplication.Name = "radCopyFromApplication"
        Me.radCopyFromApplication.R_ConductorGridSource = Nothing
        Me.radCopyFromApplication.R_ConductorSource = Nothing
        Me.radCopyFromApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.radCopyFromApplication.R_ResourceId = "radCopyFromApplication"
        Me.radCopyFromApplication.Size = New System.Drawing.Size(122, 18)
        Me.radCopyFromApplication.TabIndex = 1
        Me.radCopyFromApplication.TabStop = False
        Me.radCopyFromApplication.Text = "R_RadRadioButton2"
        '
        'radAttributeGroupOnly
        '
        Me.radAttributeGroupOnly.CheckState = System.Windows.Forms.CheckState.Checked
        Me.radAttributeGroupOnly.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.radAttributeGroupOnly.Location = New System.Drawing.Point(5, 21)
        Me.radAttributeGroupOnly.Name = "radAttributeGroupOnly"
        Me.radAttributeGroupOnly.R_ConductorGridSource = Nothing
        Me.radAttributeGroupOnly.R_ConductorSource = Nothing
        Me.radAttributeGroupOnly.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.radAttributeGroupOnly.R_ResourceId = "radAttributeGroupOnly"
        Me.radAttributeGroupOnly.Size = New System.Drawing.Size(122, 18)
        Me.radAttributeGroupOnly.TabIndex = 0
        Me.radAttributeGroupOnly.Text = "R_RadRadioButton1"
        Me.radAttributeGroupOnly.ToggleState = Telerik.WinControls.Enumerations.ToggleState.[On]
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.btnAttribute)
        Me.Panel3.Controls.Add(Me.gvAttributeGroup)
        Me.Panel3.Controls.Add(Me.lblAttributeGroup)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(3, 3)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(244, 527)
        Me.Panel3.TabIndex = 2
        '
        'btnAttribute
        '
        Me.btnAttribute.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAttribute.Location = New System.Drawing.Point(6, 168)
        Me.btnAttribute.Name = "btnAttribute"
        Me.btnAttribute.R_ConductorGridSource = Me.conGridAttrGrp
        Me.btnAttribute.R_ConductorSource = Nothing
        Me.btnAttribute.R_DescriptionId = Nothing
        Me.btnAttribute.R_EnableHASDATA = True
        Me.btnAttribute.R_ResourceId = "btnAttribute"
        Me.btnAttribute.R_Title = Nothing
        Me.btnAttribute.Size = New System.Drawing.Size(110, 24)
        Me.btnAttribute.TabIndex = 2
        Me.btnAttribute.Text = "R_Detail1"
        '
        'gvAttributeGroup
        '
        Me.gvAttributeGroup.EnableFastScrolling = True
        Me.gvAttributeGroup.Location = New System.Drawing.Point(6, 27)
        '
        '
        '
        Me.gvAttributeGroup.MasterTemplate.AllowAddNewRow = False
        Me.gvAttributeGroup.MasterTemplate.AllowColumnReorder = False
        Me.gvAttributeGroup.MasterTemplate.AllowEditRow = False
        Me.gvAttributeGroup.MasterTemplate.AutoGenerateColumns = False
        Me.gvAttributeGroup.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn1.FieldName = "_CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn1.HeaderText = "_CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn1.Name = "_CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn1.R_EnableADD = True
        R_GridViewTextBoxColumn1.R_ResourceId = "_CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 197
        R_GridViewCheckBoxColumn1.FieldName = "_LACTIVE"
        R_GridViewCheckBoxColumn1.HeaderText = "_LACTIVE"
        R_GridViewCheckBoxColumn1.Name = "_LACTIVE"
        R_GridViewCheckBoxColumn1.R_EnableADD = True
        R_GridViewCheckBoxColumn1.R_EnableEDIT = True
        R_GridViewCheckBoxColumn1.R_ResourceId = "_LACTIVE"
        R_GridViewCheckBoxColumn1.Width = 22
        Me.gvAttributeGroup.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewCheckBoxColumn1})
        Me.gvAttributeGroup.MasterTemplate.DataSource = Me.bsGvAttributeGroup
        Me.gvAttributeGroup.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvAttributeGroup.MasterTemplate.EnableFiltering = True
        Me.gvAttributeGroup.MasterTemplate.EnableGrouping = False
        Me.gvAttributeGroup.MasterTemplate.ShowFilteringRow = False
        Me.gvAttributeGroup.MasterTemplate.ShowGroupedColumns = True
        Me.gvAttributeGroup.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvAttributeGroup.Name = "gvAttributeGroup"
        Me.gvAttributeGroup.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvAttributeGroup.R_ConductorGridSource = Me.conGridAttrGrp
        Me.gvAttributeGroup.R_ConductorSource = Nothing
        Me.gvAttributeGroup.R_DataAdded = False
        Me.gvAttributeGroup.R_NewRowText = Nothing
        Me.gvAttributeGroup.ShowHeaderCellButtons = True
        Me.gvAttributeGroup.Size = New System.Drawing.Size(238, 135)
        Me.gvAttributeGroup.TabIndex = 1
        Me.gvAttributeGroup.Text = "R_RadGridView1"
        '
        'bsGvAttributeGroup
        '
        Me.bsGvAttributeGroup.DataSource = GetType(CSM00100Front.CSM00100ServiceRef.CSM00100AttrGrpDTO)
        '
        'conGridAttrGrp
        '
        Me.conGridAttrGrp.R_ConductorParent = Nothing
        Me.conGridAttrGrp.R_IsHeader = True
        Me.conGridAttrGrp.R_RadGroupBox = Nothing
        '
        'lblAttributeGroup
        '
        Me.lblAttributeGroup.AutoSize = False
        Me.lblAttributeGroup.Font = New System.Drawing.Font("Calibri", 12.0!)
        Me.lblAttributeGroup.Location = New System.Drawing.Point(6, 3)
        Me.lblAttributeGroup.Name = "lblAttributeGroup"
        Me.lblAttributeGroup.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.GroupBox
        Me.lblAttributeGroup.R_ResourceId = "lblAttributeGroup"
        Me.lblAttributeGroup.Size = New System.Drawing.Size(100, 18)
        Me.lblAttributeGroup.TabIndex = 0
        Me.lblAttributeGroup.Text = "R_RadLabel1"
        '
        'CSM00100
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CSM00100"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        CType(Me.btnGenerate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grpGenerate, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpGenerate.ResumeLayout(False)
        Me.grpGenerate.PerformLayout()
        CType(Me.cboFromApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsFromApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.radCopyFromApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.radAttributeGroupOnly, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        CType(Me.btnAttribute, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvAttributeGroup.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvAttributeGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvAttributeGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridAttrGrp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblAttributeGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents conGridAttrGrp As R_FrontEnd.R_ConductorGrid
    Friend WithEvents cboApplication As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents lblAttributeGroup As R_FrontEnd.R_RadLabel
    Friend WithEvents grpGenerate As R_FrontEnd.R_RadGroupBox
    Friend WithEvents radCopyFromApplication As R_FrontEnd.R_RadRadioButton
    Friend WithEvents radAttributeGroupOnly As R_FrontEnd.R_RadRadioButton
    Friend WithEvents cboFromApplication As R_FrontEnd.R_RadDropDownList
    Friend WithEvents bsFromApps As System.Windows.Forms.BindingSource
    Friend WithEvents bsGvAttributeGroup As System.Windows.Forms.BindingSource
    Friend WithEvents gvAttributeGroup As R_FrontEnd.R_RadGridView
    Friend WithEvents btnGenerate As R_FrontEnd.R_RadButton
    Friend WithEvents btnAttribute As R_FrontEnd.R_Detail

End Class
