﻿Imports CSM00100FrontResources
Imports R_Common
Imports ClientHelper
Imports CSM00100Front.CSM00100AttributeStreamingServiceRef
Imports R_FrontEnd
Imports CSM00100Front.CSM00100StreamingServiceRef
Imports System.ServiceModel.Channels
Imports CSM00100Front.CSM00100AttributeServiceRef
Imports CSM00100Front.CSM00100ServiceRef
Imports CSM00100Front.CSM00100SourceGroupServiceRef
Imports CSM00100Front.CSM00100SourceGroupStreamingServiceRef
Imports System.ServiceModel

Public Class CSM00100Attributes

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSM00100Service/CSM00100AttributeService.svc"
    Dim C_ServiceNameStream As String = "CSM00100Service/CSM00100AttributeStreamingService.svc"
    Dim C_ServiceNameDetail As String = "CSM00100Service/CSM00100SourceGroupService.svc"
    Dim C_ServiceNameStreamDetail As String = "CSM00100Service/CSM00100SourceGroupStreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _CATTRIBUTEGROUP As String
    Dim _CATTRIBUTEID As String
#End Region

    Private Sub CSM00100Attributes_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim llMenu As Boolean

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            With CType(poParameter, CSM00100AttrGrpDTO)
                _CAPPSCODE = ._CAPPS_CODE
                _CATTRIBUTEGROUP = ._CATTRIBUTE_GROUP
            End With
            txtAttributeGroup.Text = _CATTRIBUTEGROUP
            gvAttributes.R_RefreshGrid(poParameter)
            llMenu = _CATTRIBUTEGROUP.Trim.Equals("PROGRAM")
            gvAttributes.Columns("_LMENU").IsVisible = llMenu

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

    Private Sub CSM00100Attributes_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#Region " GRID VIEW Attributes "

    Private Sub gvAttributes_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvAttributes.R_Display
        Dim loEx As New R_Exception
        Dim loTableKey As New CSM00100AttributeDTO

        Try
            loTableKey = CType(bsGvAttribute.Current, CSM00100AttributeDTO)
            _CATTRIBUTEID = loTableKey._CATTRIBUTE_ID
            gvSourceGroup.R_RefreshGrid(loTableKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvAttributes_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvAttributes.R_Saving
        With CType(poEntity, CSM00100AttributeDTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = _CAPPSCODE
            ._CATTRIBUTE_GROUP = _CATTRIBUTEGROUP
            If Not _CATTRIBUTEGROUP.Trim.Equals("PROGRAM") Then
                ._LMENU = False
            End If
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With
    End Sub

    Private Sub gvAttributes_R_ServiceDelete(poEntity As Object) Handles gvAttributes.R_ServiceDelete
        Dim loService As CSM00100AttributeServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00100AttributeService, CSM00100AttributeServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String

        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As FaultException
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loService IsNot Nothing Then
            loService.Close()
        End If
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvAttributes_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvAttributes.R_ServiceGetListRecord
        Dim loServiceStream As CSM00100AttributeStreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00100AttributeStreamingService, CSM00100AttributeStreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00100AttributeGridDTO)
        Dim loListEntity As New List(Of CSM00100AttributeDTO)

        Try
            With CType(poEntity, CSM00100AttrGrpDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", ._CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", ._CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cAttributeGroup", ._CATTRIBUTE_GROUP)
            End With

            loRtn = loServiceStream.GetAttributeList()
            loStreaming = R_StreamUtility(Of CSM00100AttributeGridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00100AttributeGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New CSM00100AttributeDTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                                    ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                                    ._CATTRIBUTE_GROUP = loDto.CATTRIBUTE_GROUP,
                                                                    ._CATTRIBUTE_ID = loDto.CATTRIBUTE_ID,
                                                                    ._CATTRIBUTE_NAME = loDto.CATTRIBUTE_NAME,
                                                                    ._LMENU = loDto.LMENU,
                                                                    ._CCREATE_BY = loDto.CCREATE_BY,
                                                                    ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                                    ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                                    ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        If loServiceStream IsNot Nothing Then
            loServiceStream.Close()
        End If
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvAttributes_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvAttributes.R_ServiceGetRecord
        Dim loService As CSM00100AttributeServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00100AttributeService, CSM00100AttributeServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New CSM00100AttributeDTO With {._CCOMPANY_ID = _CCOMPID,
                                                                                      ._CAPPS_CODE = _CAPPSCODE,
                                                                                      ._CATTRIBUTE_GROUP = _CATTRIBUTEGROUP,
                                                                                      ._CATTRIBUTE_ID = CType(bsGvAttribute.Current, CSM00100AttributeDTO)._CATTRIBUTE_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loService IsNot Nothing Then
            loService.Close()
        End If
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvAttributes_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvAttributes.R_ServiceSave
        Dim loService As CSM00100AttributeServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00100AttributeService, CSM00100AttributeServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loService IsNot Nothing Then
            loService.Close()
        End If
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvAttributes_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvAttributes.R_Validation
        Dim loEx As New R_Exception()

        Try
            pcError = ""
            With poGridCellCollection
                If String.IsNullOrWhiteSpace(.Item(0).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00100_01")
                    loEx.Add("CSM00100_01", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00100_01"))
                    plCancel = True
                End If

                If String.IsNullOrWhiteSpace(.Item(1).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00100_02")
                    loEx.Add("CSM00100_02", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00100_02"))
                    plCancel = True
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " GRID VIEW Source Group "
    Private Sub gvSourceGroup_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvSourceGroup.R_Saving
        With CType(poEntity, CSM00100SourceGroupDTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = _CAPPSCODE
            ._CATTRIBUTE_GROUP = _CATTRIBUTEGROUP
            ._CATTRIBUTE_ID = _CATTRIBUTEID
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With
    End Sub

    Private Sub gvSourceGroup_R_ServiceDelete(poEntity As Object) Handles gvSourceGroup.R_ServiceDelete
        Dim loService As CSM00100SourceGroupServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00100SourceGroupService, CSM00100SourceGroupServiceClient)(e_ServiceClientType.RegularService, C_ServiceNameDetail)
        Dim loEx As New R_Exception
        Dim lcErr As String

        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As FaultException
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loService IsNot Nothing Then
            loService.Close()
        End If
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSourceGroup_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvSourceGroup.R_ServiceGetListRecord
        Dim loServiceStream As CSM00100SourceGroupStreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00100SourceGroupStreamingService, CSM00100SourceGroupStreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStreamDetail)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00100SourceGroupGridDTO)
        Dim loListEntity As New List(Of CSM00100SourceGroupDTO)

        Try
            With CType(poEntity, CSM00100AttributeDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", ._CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", ._CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cAttributeGroup", ._CATTRIBUTE_GROUP)
                R_Utility.R_SetStreamingContext("cAttributeId", ._CATTRIBUTE_ID)
            End With

            loRtn = loServiceStream.GetSourceGroupList()
            loStreaming = R_StreamUtility(Of CSM00100SourceGroupGridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00100SourceGroupGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New CSM00100SourceGroupDTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                                      ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                                      ._CATTRIBUTE_GROUP = loDto.CATTRIBUTE_GROUP,
                                                                      ._CATTRIBUTE_ID = loDto.CATTRIBUTE_ID,
                                                                      ._CSOURCE_GROUP_ID = loDto.CSOURCE_GROUP_ID,
                                                                      ._CDESCRIPTION = loDto.CDESCRIPTION,
                                                                      ._CRELATIVE_PATH = loDto.CRELATIVE_PATH,
                                                                      ._LQC_CHECKOUT = loDto.LQC_CHECKOUT,
                                                                      ._CBUILD_PATH = loDto.CBUILD_PATH,
                                                                      ._CBUILD_EXTENSION = loDto.CBUILD_EXTENSION,
                                                                      ._LGENERATE = loDto.LGENERATE,
                                                                      ._CCREATE_BY = loDto.CCREATE_BY,
                                                                      ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                                      ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                                      ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        If loServiceStream IsNot Nothing Then
            loServiceStream.Close()
        End If
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSourceGroup_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvSourceGroup.R_ServiceGetRecord
        Dim loService As CSM00100SourceGroupServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00100SourceGroupService, CSM00100SourceGroupServiceClient)(e_ServiceClientType.RegularService, C_ServiceNameDetail)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New CSM00100SourceGroupDTO With {._CCOMPANY_ID = _CCOMPID,
                                                                                        ._CAPPS_CODE = _CAPPSCODE,
                                                                                        ._CATTRIBUTE_GROUP = _CATTRIBUTEGROUP,
                                                                                        ._CATTRIBUTE_ID = _CATTRIBUTEID,
                                                                                        ._CSOURCE_GROUP_ID = CType(bsGvSourceGroup.Current, CSM00100SourceGroupDTO)._CSOURCE_GROUP_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loService IsNot Nothing Then
            loService.Close()
        End If
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSourceGroup_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvSourceGroup.R_ServiceSave
        Dim loService As CSM00100SourceGroupServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00100SourceGroupService, CSM00100SourceGroupServiceClient)(e_ServiceClientType.RegularService, C_ServiceNameDetail)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loService IsNot Nothing Then
            loService.Close()
        End If
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSourceGroup_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvSourceGroup.R_Validation
        Dim loEx As New R_Exception()

        Try
            pcError = ""
            With poGridCellCollection
                If String.IsNullOrWhiteSpace(.Item("_CSOURCE_GROUP_ID").Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00100_03")
                    loEx.Add("CSM00100_03", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00100_03"))
                    plCancel = True
                End If

                If String.IsNullOrWhiteSpace(.Item(1).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00100_04")
                    loEx.Add("CSM00100_04", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00100_04"))
                    plCancel = True
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " Conductor "

    Private Sub conGridAttr_R_SetHasData(plEnable As Boolean) Handles conGridAttr.R_SetHasData
        gvSourceGroup.Enabled = plEnable
    End Sub

#End Region

End Class
