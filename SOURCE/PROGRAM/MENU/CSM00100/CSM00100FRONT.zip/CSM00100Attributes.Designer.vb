﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSM00100Attributes
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn1 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn2 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewCheckBoxColumn3 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewTextBoxColumn6 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn7 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn4 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewCheckBoxColumn5 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewTextBoxColumn8 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtAttributeGroup = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblAttributeGroup = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvAttributes = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvAttribute = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridAttr = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.gvSourceGroup = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvSourceGroup = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridSrcGrp = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.txtAttributeGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblAttributeGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvAttributes, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvAttributes.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvAttribute, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridAttr, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.gvSourceGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvSourceGroup.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvSourceGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridSrcGrp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.gvAttributes, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 0, 2)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.txtAttributeGroup)
        Me.Panel1.Controls.Add(Me.lblAttributeGroup)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 30)
        Me.Panel1.TabIndex = 0
        '
        'txtAttributeGroup
        '
        Me.txtAttributeGroup.Location = New System.Drawing.Point(115, 3)
        Me.txtAttributeGroup.Name = "txtAttributeGroup"
        Me.txtAttributeGroup.R_ConductorGridSource = Nothing
        Me.txtAttributeGroup.R_ConductorSource = Nothing
        Me.txtAttributeGroup.R_UDT = Nothing
        Me.txtAttributeGroup.ReadOnly = True
        Me.txtAttributeGroup.Size = New System.Drawing.Size(206, 20)
        Me.txtAttributeGroup.TabIndex = 1
        Me.txtAttributeGroup.TabStop = False
        '
        'lblAttributeGroup
        '
        Me.lblAttributeGroup.AutoSize = False
        Me.lblAttributeGroup.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblAttributeGroup.Location = New System.Drawing.Point(9, 4)
        Me.lblAttributeGroup.Name = "lblAttributeGroup"
        Me.lblAttributeGroup.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblAttributeGroup.R_ResourceId = "lblAttributeGroup"
        Me.lblAttributeGroup.Size = New System.Drawing.Size(100, 18)
        Me.lblAttributeGroup.TabIndex = 0
        Me.lblAttributeGroup.Text = "R_RadLabel1"
        '
        'gvAttributes
        '
        Me.gvAttributes.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvAttributes.EnableFastScrolling = True
        Me.gvAttributes.Location = New System.Drawing.Point(3, 39)
        '
        '
        '
        Me.gvAttributes.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn1.FieldName = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn1.Name = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn1.R_EnableADD = True
        R_GridViewTextBoxColumn1.R_ResourceId = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 132
        R_GridViewTextBoxColumn2.FieldName = "_CATTRIBUTE_NAME"
        R_GridViewTextBoxColumn2.HeaderText = "_CATTRIBUTE_NAME"
        R_GridViewTextBoxColumn2.Name = "_CATTRIBUTE_NAME"
        R_GridViewTextBoxColumn2.R_EnableADD = True
        R_GridViewTextBoxColumn2.R_EnableEDIT = True
        R_GridViewTextBoxColumn2.R_ResourceId = "_CATTRIBUTE_NAME"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 505
        R_GridViewCheckBoxColumn1.FieldName = "_LMENU"
        R_GridViewCheckBoxColumn1.HeaderText = "_LMENU"
        R_GridViewCheckBoxColumn1.Name = "_LMENU"
        R_GridViewCheckBoxColumn1.R_EnableADD = True
        R_GridViewCheckBoxColumn1.R_EnableEDIT = True
        R_GridViewCheckBoxColumn1.R_ResourceId = "_LMENU"
        R_GridViewCheckBoxColumn1.Width = 46
        Me.gvAttributes.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewCheckBoxColumn1})
        Me.gvAttributes.MasterTemplate.DataSource = Me.bsGvAttribute
        Me.gvAttributes.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvAttributes.MasterTemplate.EnableFiltering = True
        Me.gvAttributes.MasterTemplate.EnableGrouping = False
        Me.gvAttributes.MasterTemplate.ShowFilteringRow = False
        Me.gvAttributes.MasterTemplate.ShowGroupedColumns = True
        Me.gvAttributes.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvAttributes.Name = "gvAttributes"
        Me.gvAttributes.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvAttributes.R_ConductorGridSource = Me.conGridAttr
        Me.gvAttributes.R_ConductorSource = Nothing
        Me.gvAttributes.R_DataAdded = False
        Me.gvAttributes.R_NewRowText = Nothing
        Me.gvAttributes.ShowHeaderCellButtons = True
        Me.gvAttributes.Size = New System.Drawing.Size(1271, 263)
        Me.gvAttributes.TabIndex = 1
        Me.gvAttributes.Text = "R_RadGridView1"
        '
        'bsGvAttribute
        '
        Me.bsGvAttribute.DataSource = GetType(CSM00100Front.CSM00100AttributeServiceRef.CSM00100AttributeDTO)
        '
        'conGridAttr
        '
        Me.conGridAttr.R_ConductorParent = Nothing
        Me.conGridAttr.R_IsHeader = True
        Me.conGridAttr.R_RadGroupBox = Nothing
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.gvSourceGroup)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 308)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1271, 264)
        Me.Panel2.TabIndex = 2
        '
        'gvSourceGroup
        '
        Me.gvSourceGroup.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvSourceGroup.EnableFastScrolling = True
        Me.gvSourceGroup.Location = New System.Drawing.Point(0, 0)
        '
        '
        '
        Me.gvSourceGroup.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn3.FieldName = "_CSOURCE_GROUP_ID"
        R_GridViewTextBoxColumn3.HeaderText = "_CSOURCE_GROUP_ID"
        R_GridViewTextBoxColumn3.Name = "_CSOURCE_GROUP_ID"
        R_GridViewTextBoxColumn3.R_EnableADD = True
        R_GridViewTextBoxColumn3.R_ResourceId = "_CSOURCE_GROUP_ID"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 133
        R_GridViewTextBoxColumn4.FieldName = "_CDESCRIPTION"
        R_GridViewTextBoxColumn4.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxColumn4.Name = "_CDESCRIPTION"
        R_GridViewTextBoxColumn4.R_EnableADD = True
        R_GridViewTextBoxColumn4.R_EnableEDIT = True
        R_GridViewTextBoxColumn4.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 103
        R_GridViewTextBoxColumn5.FieldName = "_CRELATIVE_PATH"
        R_GridViewTextBoxColumn5.HeaderText = "_CRELATIVE_PATH"
        R_GridViewTextBoxColumn5.Name = "_CRELATIVE_PATH"
        R_GridViewTextBoxColumn5.R_EnableADD = True
        R_GridViewTextBoxColumn5.R_EnableEDIT = True
        R_GridViewTextBoxColumn5.R_ResourceId = "_CRELATIVE_PATH"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 113
        R_GridViewCheckBoxColumn2.FieldName = "_LQC_CHECKOUT"
        R_GridViewCheckBoxColumn2.HeaderText = "_LQC_CHECKOUT"
        R_GridViewCheckBoxColumn2.Name = "_LQC_CHECKOUT"
        R_GridViewCheckBoxColumn2.R_EnableADD = True
        R_GridViewCheckBoxColumn2.R_EnableEDIT = True
        R_GridViewCheckBoxColumn2.R_ResourceId = "_LQC_CHECKOUT"
        R_GridViewCheckBoxColumn2.Width = 109
        R_GridViewCheckBoxColumn3.FieldName = "_LBUILD_CHECK_IN"
        R_GridViewCheckBoxColumn3.HeaderText = "_LBUILD_CHECK_IN"
        R_GridViewCheckBoxColumn3.Name = "_LBUILD_CHECK_IN"
        R_GridViewCheckBoxColumn3.R_EnableADD = True
        R_GridViewCheckBoxColumn3.R_EnableEDIT = True
        R_GridViewCheckBoxColumn3.R_ResourceId = "_LBUILD_CHECK_IN"
        R_GridViewCheckBoxColumn3.Width = 118
        R_GridViewTextBoxColumn6.FieldName = "_CBUILD_PATH"
        R_GridViewTextBoxColumn6.HeaderText = "_CBUILD_PATH"
        R_GridViewTextBoxColumn6.Name = "_CBUILD_PATH"
        R_GridViewTextBoxColumn6.R_EnableADD = True
        R_GridViewTextBoxColumn6.R_EnableEDIT = True
        R_GridViewTextBoxColumn6.R_ResourceId = "_CBUILD_PATH"
        R_GridViewTextBoxColumn6.R_UDT = Nothing
        R_GridViewTextBoxColumn6.Width = 97
        R_GridViewTextBoxColumn7.FieldName = "_CBUILD_EXTENSION"
        R_GridViewTextBoxColumn7.HeaderText = "_CBUILD_EXTENSION"
        R_GridViewTextBoxColumn7.Name = "_CBUILD_EXTENSION"
        R_GridViewTextBoxColumn7.R_EnableADD = True
        R_GridViewTextBoxColumn7.R_EnableEDIT = True
        R_GridViewTextBoxColumn7.R_ResourceId = "_CBUILD_EXTENSION"
        R_GridViewTextBoxColumn7.R_UDT = Nothing
        R_GridViewTextBoxColumn7.Width = 128
        R_GridViewCheckBoxColumn4.FieldName = "_LGENERATE"
        R_GridViewCheckBoxColumn4.HeaderText = "_LGENERATE"
        R_GridViewCheckBoxColumn4.Name = "_LGENERATE"
        R_GridViewCheckBoxColumn4.R_EnableADD = True
        R_GridViewCheckBoxColumn4.R_EnableEDIT = True
        R_GridViewCheckBoxColumn4.R_ResourceId = "_LGENERATE"
        R_GridViewCheckBoxColumn4.Width = 86
        R_GridViewCheckBoxColumn5.FieldName = "_LSINGLE_FILE"
        R_GridViewCheckBoxColumn5.HeaderText = "_LSINGLE_FILE"
        R_GridViewCheckBoxColumn5.Name = "_LSINGLE_FILE"
        R_GridViewCheckBoxColumn5.R_EnableADD = True
        R_GridViewCheckBoxColumn5.R_EnableEDIT = True
        R_GridViewCheckBoxColumn5.R_ResourceId = "_LSINGLE_FILE"
        R_GridViewCheckBoxColumn5.Width = 93
        R_GridViewTextBoxColumn8.FieldName = "_CFILE_EXTENSION"
        R_GridViewTextBoxColumn8.HeaderText = "_CFILE_EXTENSION"
        R_GridViewTextBoxColumn8.Name = "_CFILE_EXTENSION"
        R_GridViewTextBoxColumn8.R_EnableADD = True
        R_GridViewTextBoxColumn8.R_EnableEDIT = True
        R_GridViewTextBoxColumn8.R_ResourceId = "_CFILE_EXTENSION"
        R_GridViewTextBoxColumn8.R_UDT = Nothing
        R_GridViewTextBoxColumn8.Width = 117
        Me.gvSourceGroup.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn3, R_GridViewTextBoxColumn4, R_GridViewTextBoxColumn5, R_GridViewCheckBoxColumn2, R_GridViewCheckBoxColumn3, R_GridViewTextBoxColumn6, R_GridViewTextBoxColumn7, R_GridViewCheckBoxColumn4, R_GridViewCheckBoxColumn5, R_GridViewTextBoxColumn8})
        Me.gvSourceGroup.MasterTemplate.DataSource = Me.bsGvSourceGroup
        Me.gvSourceGroup.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvSourceGroup.MasterTemplate.EnableFiltering = True
        Me.gvSourceGroup.MasterTemplate.EnableGrouping = False
        Me.gvSourceGroup.MasterTemplate.ShowFilteringRow = False
        Me.gvSourceGroup.MasterTemplate.ShowGroupedColumns = True
        Me.gvSourceGroup.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvSourceGroup.Name = "gvSourceGroup"
        Me.gvSourceGroup.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvSourceGroup.R_ConductorGridSource = Me.conGridSrcGrp
        Me.gvSourceGroup.R_ConductorSource = Nothing
        Me.gvSourceGroup.R_DataAdded = False
        Me.gvSourceGroup.R_NewRowText = Nothing
        Me.gvSourceGroup.ShowHeaderCellButtons = True
        Me.gvSourceGroup.Size = New System.Drawing.Size(1271, 264)
        Me.gvSourceGroup.TabIndex = 2
        Me.gvSourceGroup.Text = "R_RadGridView1"
        '
        'bsGvSourceGroup
        '
        Me.bsGvSourceGroup.DataSource = GetType(CSM00100Front.CSM00100SourceGroupServiceRef.CSM00100SourceGroupDTO)
        '
        'conGridSrcGrp
        '
        Me.conGridSrcGrp.R_ConductorParent = Me.conGridAttr
        Me.conGridSrcGrp.R_RadGroupBox = Nothing
        '
        'CSM00100Attributes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CSM00100Attributes"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "Attributes"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.txtAttributeGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblAttributeGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvAttributes.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvAttributes, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvAttribute, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridAttr, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        CType(Me.gvSourceGroup.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvSourceGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvSourceGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridSrcGrp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblAttributeGroup As R_FrontEnd.R_RadLabel
    Friend WithEvents txtAttributeGroup As R_FrontEnd.R_RadTextBox
    Friend WithEvents gvAttributes As R_FrontEnd.R_RadGridView
    Friend WithEvents conGridAttr As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsGvAttribute As System.Windows.Forms.BindingSource
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents conGridSrcGrp As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsGvSourceGroup As System.Windows.Forms.BindingSource
    Friend WithEvents gvSourceGroup As R_FrontEnd.R_RadGridView

End Class
