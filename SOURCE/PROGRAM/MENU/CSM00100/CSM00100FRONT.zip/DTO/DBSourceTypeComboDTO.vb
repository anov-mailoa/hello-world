﻿Public Class DBSourceTypeComboDTO
    Public Property CDB_SOURCE_TYPE As String
    Public Property CDB_SOURCE_DESC As String
End Class
