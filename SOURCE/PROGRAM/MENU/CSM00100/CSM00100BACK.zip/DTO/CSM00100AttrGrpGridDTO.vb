﻿Public Class CSM00100AttrGrpGridDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CATTRIBUTE_GROUP As String
    Public Property LACTIVE As Boolean
    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)

End Class
