﻿Public Class CSM00100SourceGroupGridDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CATTRIBUTE_GROUP As String
    Public Property CATTRIBUTE_ID As String
    Public Property CSOURCE_GROUP_ID As String
    Public Property CDESCRIPTION As String
    Public Property CRELATIVE_PATH As String
    Public Property LQC_CHECKOUT As Boolean
    Public Property LBUILD_CHECK_IN As Boolean
    Public Property CBUILD_PATH As String
    Public Property CBUILD_EXTENSION As String
    Public Property LGENERATE As Boolean
    Public Property LSINGLE_FILE As Boolean
    Public Property CFILE_EXTENSION As String
    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)

End Class
