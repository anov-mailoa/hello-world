﻿Imports R_BackEnd
Imports R_Common
Imports RLicenseBack
Imports ServerHelper.General
Imports System.Data.Common

Public Class CSM00100Cls
    Inherits R_BusinessObject(Of CSM00100AttrGrpDTO)

    Public Function GetAttributeGroupList(poKey As CSM00100AttrGrpKeyDTO) As List(Of CSM00100AttrGrpGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00100AttrGrpGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CSM_ATTRIBUTE_GROUPS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE)
            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00100AttrGrpGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult

    End Function

    Public Function GetFromAppCombo(pcCompany_ID As String, pcUser_ID As String, Optional pcCommercial As String = "Y") As List(Of RLicenseAppComboDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RLicenseAppComboDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "EXEC RSP_Get_From_App_Combo '{0}', '{1}', '{2}' "
            lcQuery = String.Format(lcQuery, pcCompany_ID, pcUser_ID, pcCommercial)

            loResult = loDb.SqlExecObjectQuery(Of RLicenseAppComboDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Sub GenerateAttributeGroup(poNewEntity As CSM00100AttrGrpDTO, pcFrom_Apps_Code As String)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String

        Try
            loConn = loDb.GetConnection()

            ' Generate Attribute Group
            ' DESIGN
            lcQuery = "INSERT INTO CSM_ATTRIBUTE_GROUPS ("
            lcQuery += "CCOMPANY_ID, "
            lcQuery += "CAPPS_CODE, "
            lcQuery += "CATTRIBUTE_GROUP, "
            lcQuery += "LACTIVE, "
            lcQuery += "CUPDATE_BY, "
            lcQuery += "DUPDATE_DATE, "
            lcQuery += "CCREATE_BY, "
            lcQuery += "DCREATE_DATE) "
            lcQuery += "VALUES ('{0}', '{1}', '{2}', {3}, '{4}', {5}, '{6}', {7}) "
            lcQuery = String.Format(lcQuery,
            poNewEntity.CCOMPANY_ID,
            poNewEntity.CAPPS_CODE,
            "DESIGN",
            IIf(poNewEntity.LACTIVE, "1", "0"),
            poNewEntity.CUPDATE_BY,
            getDate(Now),
            poNewEntity.CCREATE_BY,
            getDate(Now))
            loDb.SqlExecNonQuery(lcQuery)

            ' PROGRAM
            lcQuery = "INSERT INTO CSM_ATTRIBUTE_GROUPS ("
            lcQuery += "CCOMPANY_ID, "
            lcQuery += "CAPPS_CODE, "
            lcQuery += "CATTRIBUTE_GROUP, "
            lcQuery += "LACTIVE, "
            lcQuery += "CUPDATE_BY, "
            lcQuery += "DUPDATE_DATE, "
            lcQuery += "CCREATE_BY, "
            lcQuery += "DCREATE_DATE) "
            lcQuery += "VALUES ('{0}', '{1}', '{2}', {3}, '{4}', {5}, '{6}', {7}) "
            lcQuery = String.Format(lcQuery,
            poNewEntity.CCOMPANY_ID,
            poNewEntity.CAPPS_CODE,
            "PROGRAM",
            IIf(poNewEntity.LACTIVE, "1", "0"),
            poNewEntity.CUPDATE_BY,
            getDate(Now),
            poNewEntity.CCREATE_BY,
            getDate(Now))
            loDb.SqlExecNonQuery(lcQuery)

            ' Copy attribute from other apps
            If Not pcFrom_Apps_Code.Trim.Equals("") Then
                lcQuery = "INSERT INTO CSM_ATTRIBUTES "
                lcQuery += "SELECT CCOMPANY_ID, "
                lcQuery += "'{1}', "
                lcQuery += "CATTRIBUTE_GROUP, "
                lcQuery += "CATTRIBUTE_ID, "
                lcQuery += "CATTRIBUTE_NAME, "
                lcQuery += "LMENU, "
                lcQuery += "'{3}', "
                lcQuery += "GETDATE(), "
                lcQuery += "'{4}', "
                lcQuery += "GETDATE() "
                lcQuery += "FROM CSM_ATTRIBUTES "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{2}' "
                lcQuery = String.Format(lcQuery,
                poNewEntity.CCOMPANY_ID,
                poNewEntity.CAPPS_CODE,
                pcFrom_Apps_Code.Trim,
                poNewEntity.CUPDATE_BY,
                poNewEntity.CCREATE_BY)
                loDb.SqlExecNonQuery(lcQuery)
            End If


        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try
        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Sub R_Deleting(poEntity As CSM00100AttrGrpDTO)

    End Sub

    Protected Overrides Function R_Display(poEntity As CSM00100AttrGrpDTO) As CSM00100AttrGrpDTO
        Dim lcQuery As String
        Dim loResult As CSM00100AttrGrpDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CSM_ATTRIBUTE_GROUPS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP)

                loResult = loDb.SqlExecObjectQuery(Of CSM00100AttrGrpDTO)(lcQuery).FirstOrDefault

            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As CSM00100AttrGrpDTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String

        Try
            loConn = loDb.GetConnection()

            If poCRUDMode = eCRUDMode.EditMode Then
                lcQuery = "UPDATE CSM_ATTRIBUTE_GROUPS "
                lcQuery += "SET "
                lcQuery += "LACTIVE = '{3}', "
                lcQuery += "CUPDATE_BY = '{4}', "
                lcQuery += "DUPDATE_DATE = {5} "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                lcQuery = String.Format(lcQuery,
                poNewEntity.CCOMPANY_ID,
                poNewEntity.CAPPS_CODE,
                poNewEntity.CATTRIBUTE_GROUP,
                poNewEntity.LACTIVE,
                poNewEntity.CUPDATE_BY,
                getDate(poNewEntity.DUPDATE_DATE))

                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End If

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

End Class
