﻿Imports CSM00400FrontResources
Imports R_Common
Imports CSM00400Front.CSM00300ServiceRef
Imports R_FrontEnd
Imports ClientHelper
Imports CSM00400Front.CSM00300StreamingServiceRef
Imports System.ServiceModel.Channels
Imports CSM00400Front.CSM00400ServiceRef
Imports CSM00400Front.CSM00400StreamingServiceRef
Imports System.ServiceModel

Public Class CSM00400

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSM00300Service/CSM00300Service.svc"
    Dim C_ServiceNameStream As String = "CSM00300Service/CSM00300StreamingService.svc"
    Dim C_ServiceNameDetail As String = "CSM00400Service/CSM00400Service.svc"
    Dim C_ServiceNameStreamDetail As String = "CSM00400Service/CSM00400StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim lcFile As String
    Dim llInitialized As Boolean = False
    Dim loProgramGridKey As New CSM00300KeyDTO
#End Region

#Region " FORM Methods "

    Private Sub CSM00400_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Dim loSvc As CSM00300ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00300Service, CSM00300ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loAppCombo As New List(Of RLicenseAppComboDTO)

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            ' Application
            loAppCombo = loSvc.GetAppCombo(_CCOMPID, _CUSERID)
            If loAppCombo.Count <= 0 Then
                cboApplication.Items.Clear()
                gvProgram.Enabled = False
            End If
            bsApps.DataSource = loAppCombo

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub CSM00400_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " SUB and FUNCTION "

    Private Sub RefreshGrids()
        Dim loTableKey As New CSM00300KeyDTO

        With loTableKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = cboApplication.SelectedValue.Trim
            .CATTRIBUTE_GROUP = "PROGRAM"
        End With

        With gvProgram
            .R_RefreshGrid(loTableKey)
            .Columns(0).Sort(Telerik.WinControls.UI.RadSortOrder.Ascending, False)
        End With
    End Sub

#End Region

#Region " COMBO Actions "

    Private Sub cboApplication_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboApplication.SelectedValueChanged
        Dim loEx As New R_Exception

        Try
            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " PROGRAM GRIDVIEW Events "

    Private Sub gvProgram_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvProgram.R_Display
        Dim loEx As New R_Exception
        Dim loTableKey As New CSM00300DTO
        Dim loSvc As CSM00400ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00400Service, CSM00400ServiceClient)(e_ServiceClientType.RegularService, C_ServiceNameDetail)
        Dim loSourceGroupCombo As New List(Of RCustDBSourceGroupComboDTO)

        Try
            loTableKey = CType(bsGvProgram.Current, CSM00300DTO)
            ' Source Group Field
            loSourceGroupCombo = loSvc.GetSourceGroupCombo(_CCOMPID, _
                                                         loTableKey._CAPPS_CODE, _
                                                         loTableKey._CATTRIBUTE_GROUP, _
                                                         loTableKey._CATTRIBUTE_ID)
            bsSourceGroup.DataSource = loSourceGroupCombo
            With loProgramGridKey
                .CCOMPANY_ID = loTableKey._CCOMPANY_ID
                .CAPPS_CODE = loTableKey._CAPPS_CODE
                .CATTRIBUTE_GROUP = loTableKey._CATTRIBUTE_GROUP
                .CATTRIBUTE_ID = loTableKey._CATTRIBUTE_ID
                .CPROGRAM_ID = loTableKey._CPROGRAM_ID
            End With
            gvSource.R_RefreshGrid(loTableKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loSvc.Close()
        loEx.ThrowExceptionIfErrors()

    End Sub

    Private Sub gvProgram_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvProgram.R_ServiceGetListRecord
        Dim loServiceStream As CSM00300StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00300StreamingService, CSM00300StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00300GridDTO)
        Dim loListEntity As New List(Of CSM00300DTO)

        Try
            With CType(poEntity, CSM00300KeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cAttributeGroup", .CATTRIBUTE_GROUP)
                R_Utility.R_SetStreamingContext("cAttributeId", .CATTRIBUTE_ID)
            End With

            loRtn = loServiceStream.GetProgramList()
            loStreaming = R_StreamUtility(Of CSM00300GridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00300GridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New CSM00300DTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                                  ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                                  ._CATTRIBUTE_GROUP = loDto.CATTRIBUTE_GROUP,
                                                           ._CATTRIBUTE_ID = loDto.CATTRIBUTE_ID,
                                                           ._CPROGRAM_ID = loDto.CPROGRAM_ID,
                                                           ._CPROGRAM_NAME = loDto.CPROGRAM_NAME,
                                                            ._CDESCRIPTION = loDto.CDESCRIPTION,
                                                           ._LSPEC = loDto.LSPEC,
                                                                  ._CCREATE_BY = loDto.CCREATE_BY,
                                                                  ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                                  ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                                  ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        If loServiceStream IsNot Nothing Then
            loServiceStream.Close()
        End If
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvProgram_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvProgram.R_ServiceGetRecord
        Dim loService As CSM00300ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00300Service, CSM00300ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New CSM00300DTO With {._CCOMPANY_ID = _CCOMPID,
                                                                             ._CAPPS_CODE = cboApplication.SelectedValue.Trim,
                                                                             ._CATTRIBUTE_GROUP = "PROGRAM",
                                                                             ._CATTRIBUTE_ID = CType(bsGvProgram.Current, CSM00300DTO)._CATTRIBUTE_ID,
                                                                             ._CPROGRAM_ID = CType(bsGvProgram.Current, CSM00300DTO)._CPROGRAM_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loService IsNot Nothing Then
            loService.Close()
        End If

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " SOURCE GRIDVIEW Events "

    Private Sub gvSource_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvSource.R_Saving
        With CType(poEntity, CSM00400DTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = cboApplication.SelectedValue.Trim
            ._CATTRIBUTE_GROUP = loProgramGridKey.CATTRIBUTE_GROUP
            ._CATTRIBUTE_ID = loProgramGridKey.CATTRIBUTE_ID
            ._CPROGRAM_ID = loProgramGridKey.CPROGRAM_ID
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With
    End Sub

    Private Sub gvSource_R_ServiceDelete(poEntity As Object) Handles gvSource.R_ServiceDelete
        Dim loService As CSM00400ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00400Service, CSM00400ServiceClient)(e_ServiceClientType.RegularService, C_ServiceNameDetail)
        Dim loEx As New R_Exception
        Dim lcErr As String

        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As FaultException
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loService IsNot Nothing Then
            loService.Close()
        End If

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSource_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvSource.R_ServiceGetListRecord
        Dim loServiceStream As CSM00400StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00400StreamingService, CSM00400StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStreamDetail)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00400GridDTO)
        Dim loListEntity As New List(Of CSM00400DTO)

        Try
            With CType(poEntity, CSM00300DTO)
                R_Utility.R_SetStreamingContext("cCompanyId", ._CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", ._CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cAttributeGroup", ._CATTRIBUTE_GROUP)
                R_Utility.R_SetStreamingContext("cAttributeId", ._CATTRIBUTE_ID)
                R_Utility.R_SetStreamingContext("cProgramId", ._CPROGRAM_ID)
            End With

            loRtn = loServiceStream.GetSourceList()
            loStreaming = R_StreamUtility(Of CSM00400GridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00400GridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New CSM00400DTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                                  ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                                  ._CATTRIBUTE_GROUP = loDto.CATTRIBUTE_GROUP,
                                                           ._CATTRIBUTE_ID = loDto.CATTRIBUTE_ID,
                                                           ._CPROGRAM_ID = loDto.CPROGRAM_ID,
                                                           ._CSOURCE_ID = loDto.CSOURCE_ID,
                                                           ._CDESCRIPTION = loDto.CDESCRIPTION,
                                                           ._CSOURCE_GROUP_ID = loDto.CSOURCE_GROUP_ID,
                                                           ._CSOURCE_GROUP_DESCR = loDto.CSOURCE_GROUP_DESCR,
                                                           ._LQC_CHECKOUT = loDto.LQC_CHECKOUT,
                                                                  ._CCREATE_BY = loDto.CCREATE_BY,
                                                                  ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                                  ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                                  ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        If loServiceStream IsNot Nothing Then
            loServiceStream.Close()
        End If

        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSource_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvSource.R_ServiceGetRecord
        Dim loService As CSM00400ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00400Service, CSM00400ServiceClient)(e_ServiceClientType.RegularService, C_ServiceNameDetail)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New CSM00400DTO With {._CCOMPANY_ID = _CCOMPID,
                                                                             ._CAPPS_CODE = cboApplication.SelectedValue.Trim,
                                                                             ._CATTRIBUTE_GROUP = "PROGRAM",
                                                                             ._CATTRIBUTE_ID = CType(bsGvSource.Current, CSM00400DTO)._CATTRIBUTE_ID,
                                                                             ._CPROGRAM_ID = CType(bsGvSource.Current, CSM00400DTO)._CPROGRAM_ID,
                                                                             ._CSOURCE_ID = CType(bsGvSource.Current, CSM00400DTO)._CSOURCE_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loService IsNot Nothing Then
            loService.Close()
        End If

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSource_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvSource.R_ServiceSave
        Dim loService As CSM00400ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00400Service, CSM00400ServiceClient)(e_ServiceClientType.RegularService, C_ServiceNameDetail)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loService IsNot Nothing Then
            loService.Close()
        End If

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSource_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvSource.R_Validation
        Dim loEx As New R_Exception()

        Try
            pcError = ""
            With poGridCellCollection
                If String.IsNullOrWhiteSpace(.Item("_CSOURCE_ID").Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00400_01")
                    loEx.Add("CSM00400_01", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00400_01"))
                    plCancel = True
                End If

                If String.IsNullOrWhiteSpace(.Item("_CSOURCE_GROUP_ID").Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00400_02")
                    loEx.Add("CSM00400_02", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00400_02"))
                    plCancel = True
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " O T H E R S "

    Private Sub btnGenerateSource_Click(sender As System.Object, e As System.EventArgs) Handles btnGenerateSource.Click
        Dim loException As New R_Exception
        Dim loService As CSM00400ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00400Service, CSM00400ServiceClient)(e_ServiceClientType.RegularService, C_ServiceNameDetail)
        Dim loKey As New List(Of CSM00400KeyDTO)
        Dim loKeyRow As CSM00400KeyDTO
        Dim loGridRow As Telerik.WinControls.UI.GridViewCellInfoCollection

        Try
            For Each loRow As Telerik.WinControls.UI.GridViewRowInfo In gvProgram.SelectedRows
                If loRow.IsSelected Then
                    loGridRow = loRow.Cells
                    loKeyRow = New CSM00400KeyDTO
                    With loKeyRow
                        .CCOMPANY_ID = _CCOMPID
                        .CAPPS_CODE = cboApplication.SelectedValue
                        .CATTRIBUTE_GROUP = "PROGRAM"
                        .CATTRIBUTE_ID = loGridRow.Item("_CATTRIBUTE_ID").Value
                        .CPROGRAM_ID = loGridRow.Item("_CPROGRAM_ID").Value
                        .CUSER_ID = _CUSERID
                    End With
                    loKey.Add(loKeyRow)
                End If
            Next
            loService.GenerateSource(loKey)
            RefreshGrids()
        Catch ex As Exception
            loException.Add(ex)
        End Try
        If loService IsNot Nothing Then
            loService.Close()
        End If

        If loException.Haserror Then
            Me.R_DisplayException(loException)
        End If
    End Sub

#End Region

End Class
