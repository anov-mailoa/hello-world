﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSM00400
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn1 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn6 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewComboBoxColumn1 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Dim R_GridViewTextBoxColumn7 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn2 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Me.bsSourceGroup = New System.Windows.Forms.BindingSource(Me.components)
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.gvProgram = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvProgram = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridProgram = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnGenerateSource = New R_FrontEnd.R_RadButton(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.cboApplication = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridSource = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.gvSource = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsVersion = New System.Windows.Forms.BindingSource(Me.components)
        CType(Me.bsSourceGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.gvProgram, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvProgram.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvProgram, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridProgram, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.btnGenerateSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvSource.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'bsSourceGroup
        '
        Me.bsSourceGroup.DataSource = GetType(CSM00400Front.CSM00400ServiceRef.RCustDBSourceGroupComboDTO)
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.gvProgram, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.gvSource, 0, 2)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 48.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'gvProgram
        '
        Me.gvProgram.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvProgram.EnableFastScrolling = True
        Me.gvProgram.Location = New System.Drawing.Point(3, 51)
        '
        '
        '
        Me.gvProgram.MasterTemplate.AllowAddNewRow = False
        Me.gvProgram.MasterTemplate.AllowDeleteRow = False
        Me.gvProgram.MasterTemplate.AllowEditRow = False
        Me.gvProgram.MasterTemplate.AutoGenerateColumns = False
        Me.gvProgram.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn1.FieldName = "_CPROGRAM_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CPROGRAM_ID"
        R_GridViewTextBoxColumn1.Name = "_CPROGRAM_ID"
        R_GridViewTextBoxColumn1.R_EnableADD = True
        R_GridViewTextBoxColumn1.R_ResourceId = "_CPROGRAM_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 160
        R_GridViewTextBoxColumn2.FieldName = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn2.HeaderText = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn2.Name = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 162
        R_GridViewTextBoxColumn3.FieldName = "_CPROGRAM_NAME"
        R_GridViewTextBoxColumn3.HeaderText = "_CPROGRAM_NAME"
        R_GridViewTextBoxColumn3.Name = "_CPROGRAM_NAME"
        R_GridViewTextBoxColumn3.R_EnableADD = True
        R_GridViewTextBoxColumn3.R_EnableEDIT = True
        R_GridViewTextBoxColumn3.R_ResourceId = "_CPROGRAM_NAME"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 193
        R_GridViewTextBoxColumn4.FieldName = "_CDESCRIPTION"
        R_GridViewTextBoxColumn4.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxColumn4.Name = "_CDESCRIPTION"
        R_GridViewTextBoxColumn4.R_EnableADD = True
        R_GridViewTextBoxColumn4.R_EnableEDIT = True
        R_GridViewTextBoxColumn4.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 160
        R_GridViewCheckBoxColumn1.FieldName = "_LSPEC"
        R_GridViewCheckBoxColumn1.HeaderText = "_LSPEC"
        R_GridViewCheckBoxColumn1.Name = "_LSPEC"
        R_GridViewCheckBoxColumn1.R_EnableADD = True
        R_GridViewCheckBoxColumn1.R_EnableEDIT = True
        R_GridViewCheckBoxColumn1.R_ResourceId = "_LSPEC"
        R_GridViewCheckBoxColumn1.Width = 580
        Me.gvProgram.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewTextBoxColumn4, R_GridViewCheckBoxColumn1})
        Me.gvProgram.MasterTemplate.DataSource = Me.bsGvProgram
        Me.gvProgram.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvProgram.MasterTemplate.EnableFiltering = True
        Me.gvProgram.MasterTemplate.EnableGrouping = False
        Me.gvProgram.MasterTemplate.MultiSelect = True
        Me.gvProgram.MasterTemplate.ShowGroupedColumns = True
        Me.gvProgram.Name = "gvProgram"
        Me.gvProgram.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvProgram.R_ConductorGridSource = Me.conGridProgram
        Me.gvProgram.R_ConductorSource = Nothing
        Me.gvProgram.R_DataAdded = False
        Me.gvProgram.R_FilteringMode = R_FrontEnd.R_eGridFilter.Basic
        Me.gvProgram.R_NewRowText = Nothing
        Me.gvProgram.ReadOnly = True
        Me.gvProgram.Size = New System.Drawing.Size(1271, 257)
        Me.gvProgram.TabIndex = 4
        Me.gvProgram.Text = "R_RadGridView1"
        '
        'bsGvProgram
        '
        Me.bsGvProgram.DataSource = GetType(CSM00400Front.CSM00300ServiceRef.CSM00300DTO)
        '
        'conGridProgram
        '
        Me.conGridProgram.R_ConductorParent = Nothing
        Me.conGridProgram.R_IsHeader = True
        Me.conGridProgram.R_RadGroupBox = Nothing
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnGenerateSource)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Controls.Add(Me.cboApplication)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 42)
        Me.Panel1.TabIndex = 0
        '
        'btnGenerateSource
        '
        Me.btnGenerateSource.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnGenerateSource.Location = New System.Drawing.Point(1073, 9)
        Me.btnGenerateSource.Name = "btnGenerateSource"
        Me.btnGenerateSource.R_ConductorGridSource = Nothing
        Me.btnGenerateSource.R_ConductorSource = Nothing
        Me.btnGenerateSource.R_DescriptionId = Nothing
        Me.btnGenerateSource.R_ResourceId = "btnGenerateSource"
        Me.btnGenerateSource.Size = New System.Drawing.Size(195, 24)
        Me.btnGenerateSource.TabIndex = 19
        Me.btnGenerateSource.Text = "R_RadButton1"
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 17
        Me.lblApplication.Text = "Application..."
        '
        'cboApplication
        '
        Me.cboApplication.DataSource = Me.bsApps
        Me.cboApplication.DisplayMember = "CAPPS_NAME"
        Me.cboApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboApplication.Location = New System.Drawing.Point(115, 9)
        Me.cboApplication.Name = "cboApplication"
        Me.cboApplication.R_ConductorGridSource = Me.conGridSource
        Me.cboApplication.R_ConductorSource = Nothing
        Me.cboApplication.R_EnableOTHER = True
        Me.cboApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboApplication.Size = New System.Drawing.Size(400, 20)
        Me.cboApplication.TabIndex = 18
        Me.cboApplication.Text = "R_RadDropDownList1"
        Me.cboApplication.ValueMember = "CAPPS_CODE"
        '
        'bsApps
        '
        Me.bsApps.DataSource = GetType(CSM00400Front.CSM00300ServiceRef.RLicenseAppComboDTO)
        '
        'conGridSource
        '
        Me.conGridSource.R_ConductorParent = Me.conGridProgram
        Me.conGridSource.R_RadGroupBox = Nothing
        '
        'gvSource
        '
        Me.gvSource.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvSource.EnableFastScrolling = True
        Me.gvSource.Location = New System.Drawing.Point(3, 314)
        '
        '
        '
        Me.gvSource.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn5.FieldName = "_CSOURCE_ID"
        R_GridViewTextBoxColumn5.HeaderText = "_CSOURCE_ID"
        R_GridViewTextBoxColumn5.Name = "_CSOURCE_ID"
        R_GridViewTextBoxColumn5.R_EnableADD = True
        R_GridViewTextBoxColumn5.R_ResourceId = "_CSOURCE_ID"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 75
        R_GridViewTextBoxColumn6.FieldName = "_CDESCRIPTION"
        R_GridViewTextBoxColumn6.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxColumn6.Name = "_CDESCRIPTION"
        R_GridViewTextBoxColumn6.R_EnableADD = True
        R_GridViewTextBoxColumn6.R_EnableEDIT = True
        R_GridViewTextBoxColumn6.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxColumn6.R_UDT = Nothing
        R_GridViewTextBoxColumn6.Width = 88
        R_GridViewComboBoxColumn1.DataSource = Me.bsSourceGroup
        R_GridViewComboBoxColumn1.DisplayMember = "CSOURCE_GROUP_ID"
        R_GridViewComboBoxColumn1.FieldName = "_CSOURCE_GROUP_ID"
        R_GridViewComboBoxColumn1.HeaderText = "_CSOURCE_GROUP_ID"
        R_GridViewComboBoxColumn1.Name = "_CSOURCE_GROUP_ID"
        R_GridViewComboBoxColumn1.R_EnableADD = True
        R_GridViewComboBoxColumn1.R_EnableEDIT = True
        R_GridViewComboBoxColumn1.R_ResourceId = "_CSOURCE_GROUP_ID"
        R_GridViewComboBoxColumn1.ValueMember = "CSOURCE_GROUP_ID"
        R_GridViewComboBoxColumn1.Width = 118
        R_GridViewTextBoxColumn7.FieldName = "_CSOURCE_GROUP_DESCR"
        R_GridViewTextBoxColumn7.HeaderText = "_CSOURCE_GROUP_DESCR"
        R_GridViewTextBoxColumn7.Name = "_CSOURCE_GROUP_DESCR"
        R_GridViewTextBoxColumn7.R_ResourceId = "_CSOURCE_GROUP_DESCR"
        R_GridViewTextBoxColumn7.R_UDT = Nothing
        R_GridViewTextBoxColumn7.Width = 141
        R_GridViewCheckBoxColumn2.FieldName = "_LQC_CHECKOUT"
        R_GridViewCheckBoxColumn2.HeaderText = "_LQC_CHECKOUT"
        R_GridViewCheckBoxColumn2.Name = "_LQC_CHECKOUT"
        R_GridViewCheckBoxColumn2.R_ResourceId = "_LQC_CHECKOUT"
        R_GridViewCheckBoxColumn2.Width = 305
        Me.gvSource.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn5, R_GridViewTextBoxColumn6, R_GridViewComboBoxColumn1, R_GridViewTextBoxColumn7, R_GridViewCheckBoxColumn2})
        Me.gvSource.MasterTemplate.DataSource = Me.bsGvSource
        Me.gvSource.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvSource.MasterTemplate.EnableFiltering = True
        Me.gvSource.MasterTemplate.EnableGrouping = False
        Me.gvSource.MasterTemplate.ShowFilteringRow = False
        Me.gvSource.MasterTemplate.ShowGroupedColumns = True
        Me.gvSource.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvSource.Name = "gvSource"
        Me.gvSource.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvSource.R_ConductorGridSource = Me.conGridSource
        Me.gvSource.R_ConductorSource = Nothing
        Me.gvSource.R_DataAdded = False
        Me.gvSource.R_NewRowText = Nothing
        Me.gvSource.ShowHeaderCellButtons = True
        Me.gvSource.Size = New System.Drawing.Size(1271, 258)
        Me.gvSource.TabIndex = 5
        Me.gvSource.Text = "R_RadGridView1"
        '
        'bsGvSource
        '
        Me.bsGvSource.DataSource = GetType(CSM00400Front.CSM00400ServiceRef.CSM00400DTO)
        '
        'bsVersion
        '
        Me.bsVersion.DataSource = GetType(CSM00400Front.CSM00300ServiceRef.RCustDBVersionComboDTO)
        '
        'CSM00400
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CSM00400"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.bsSourceGroup, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        CType(Me.gvProgram.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvProgram, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvProgram, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridProgram, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.btnGenerateSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvSource.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource
    Friend WithEvents bsVersion As System.Windows.Forms.BindingSource
    Friend WithEvents conGridProgram As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsGvProgram As System.Windows.Forms.BindingSource
    Friend WithEvents gvProgram As R_FrontEnd.R_RadGridView
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents cboApplication As R_FrontEnd.R_RadDropDownList
    Friend WithEvents conGridSource As R_FrontEnd.R_ConductorGrid
    Friend WithEvents gvSource As R_FrontEnd.R_RadGridView
    Friend WithEvents bsGvSource As System.Windows.Forms.BindingSource
    Friend WithEvents bsSourceGroup As System.Windows.Forms.BindingSource
    Friend WithEvents btnGenerateSource As R_FrontEnd.R_RadButton

End Class
