﻿Imports R_BackEnd
Imports R_Common
Imports System.Data.Common
Imports System.Transactions
Imports ServerHelper.General

Public Class CSM00400Cls
    Inherits R_BusinessObject(Of CSM00400DTO)

    Public Function GetSourceList(poKey As CSM00400KeyDTO) As List(Of CSM00400GridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00400GridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "SELECT A.*, B.CDESCRIPTION AS CSOURCE_GROUP_DESCR, B.LQC_CHECKOUT "
                lcQuery += "FROM CSM_SOURCES A (NOLOCK) "
                lcQuery += "JOIN CSM_SOURCE_GROUPS B (NOLOCK) "
                lcQuery += "ON B.CCOMPANY_ID = A.CCOMPANY_ID "
                lcQuery += "AND B.CAPPS_CODE = A.CAPPS_CODE "
                lcQuery += "AND B.CATTRIBUTE_GROUP = A.CATTRIBUTE_GROUP "
                lcQuery += "AND B.CATTRIBUTE_ID = A.CATTRIBUTE_ID "
                lcQuery += "AND B.CSOURCE_GROUP_ID = A.CSOURCE_GROUP_ID "
                lcQuery += "WHERE A.CCOMPANY_ID = '{0}' "
                lcQuery += "AND A.CAPPS_CODE = '{1}' "
                lcQuery += "AND A.CATTRIBUTE_GROUP = '{2}' "
                lcQuery += "AND A.CATTRIBUTE_ID = '{3}' "
                lcQuery += "AND A.CPROGRAM_ID = '{4}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CPROGRAM_ID)
            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00400GridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Deleting(poEntity As CSM00400DTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcRtn As String

        Try
            loConn = loDb.GetConnection()

            With poEntity

                'validation
                loCmd = loDb.GetCommand()
                lcQuery = "EXEC RSP_Delete_Source_Validation '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', @CRET_MSG OUTPUT "
                With poEntity
                    lcQuery = String.Format(lcQuery, _
                                            .CCOMPANY_ID, _
                                            .CAPPS_CODE, _
                                            .CATTRIBUTE_GROUP, _
                                            .CATTRIBUTE_ID,
                                            .CPROGRAM_ID,
                                            .CSOURCE_ID)
                End With
                loCmd.CommandText = lcQuery
                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@CRET_MSG"
                    .DbType = DbType.String
                    .Size = 50
                    .Direction = ParameterDirection.Output
                End With
                loCmd.Parameters.Add(loPar)
                loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)

                If loCmd.Parameters("@CRET_MSG") Is Nothing Then
                    lcRtn = "UNKNOWN_ERROR"
                Else
                    lcRtn = loCmd.Parameters("@CRET_MSG").Value
                End If

                If Not lcRtn.Equals("OK") Then
                    Throw New Exception(lcRtn)
                End If

                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "CSM_SOURCES "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                lcQuery += "AND CPROGRAM_ID = '{4}' "
                lcQuery += "AND CSOURCE_ID = '{5}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CPROGRAM_ID, .CSOURCE_ID)

                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As CSM00400DTO) As CSM00400DTO
        Dim lcQuery As String
        Dim loResult As CSM00400DTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity
                lcQuery = "SELECT A.*, B.CDESCRIPTION AS CSOURCE_GROUP_DESCR, B.LQC_CHECKOUT "
                lcQuery += "FROM CSM_SOURCES A (NOLOCK) "
                lcQuery += "JOIN CSM_SOURCE_GROUPS B (NOLOCK) "
                lcQuery += "ON B.CCOMPANY_ID = A.CCOMPANY_ID "
                lcQuery += "AND B.CAPPS_CODE = A.CAPPS_CODE "
                lcQuery += "AND B.CATTRIBUTE_GROUP = A.CATTRIBUTE_GROUP "
                lcQuery += "AND B.CATTRIBUTE_ID = A.CATTRIBUTE_ID "
                lcQuery += "AND B.CSOURCE_GROUP_ID = A.CSOURCE_GROUP_ID "
                lcQuery += "WHERE A.CCOMPANY_ID = '{0}' "
                lcQuery += "AND A.CAPPS_CODE = '{1}' "
                lcQuery += "AND A.CATTRIBUTE_GROUP = '{2}' "
                lcQuery += "AND A.CATTRIBUTE_ID = '{3}' "
                lcQuery += "AND A.CPROGRAM_ID = '{4}' "
                lcQuery += "AND A.CSOURCE_ID = '{5}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CPROGRAM_ID, .CSOURCE_ID)

                loResult = loDb.SqlExecObjectQuery(Of CSM00400DTO)(lcQuery).FirstOrDefault

            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As CSM00400DTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String

        Try
            loConn = loDb.GetConnection()

            With poNewEntity
                If poCRUDMode = eCRUDMode.AddMode Then

                    .CUPDATE_BY = .CUPDATE_BY
                    .CCREATE_BY = .CUPDATE_BY
                    .DUPDATE_DATE = Now
                    .DCREATE_DATE = Now

                    lcQuery = "INSERT INTO CSM_SOURCES ("
                    lcQuery += "CCOMPANY_ID, "
                    lcQuery += "CAPPS_CODE, "
                    lcQuery += "CATTRIBUTE_GROUP, "
                    lcQuery += "CATTRIBUTE_ID, "
                    lcQuery += "CPROGRAM_ID, "
                    lcQuery += "CSOURCE_ID, "
                    lcQuery += "CDESCRIPTION, "
                    lcQuery += "CSOURCE_GROUP_ID, "
                    lcQuery += "CUPDATE_BY, "
                    lcQuery += "DUPDATE_DATE, "
                    lcQuery += "CCREATE_BY, "
                    lcQuery += "DCREATE_DATE) "
                    lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', GETDATE(), '{8}', GETDATE()) "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CATTRIBUTE_GROUP,
                    .CATTRIBUTE_ID,
                    .CPROGRAM_ID,
                    .CSOURCE_ID,
                    .CDESCRIPTION,
                    .CSOURCE_GROUP_ID,
                    .CUPDATE_BY)

                ElseIf poCRUDMode = eCRUDMode.EditMode Then

                    lcQuery = "UPDATE CSM_SOURCES "
                    lcQuery += "SET "
                    lcQuery += "CDESCRIPTION = '{6}', "
                    lcQuery += "CSOURCE_GROUP_ID = '{7}', "
                    lcQuery += "CUPDATE_BY = '{8}', "
                    lcQuery += "DUPDATE_DATE = GETDATE() "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                    lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                    lcQuery += "AND CPROGRAM_ID = '{4}' "
                    lcQuery += "AND CSOURCE_ID = '{5}' "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CATTRIBUTE_GROUP,
                    .CATTRIBUTE_ID,
                    .CPROGRAM_ID,
                    .CSOURCE_ID,
                    .CDESCRIPTION,
                    .CSOURCE_GROUP_ID,
                    .CUPDATE_BY)

                End If
            End With
            loDb.SqlExecNonQuery(lcQuery, loConn, True)
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Sub GenerateSource(poKey As List(Of CSM00400KeyDTO))
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loCmd As DbCommand
        Dim loPar As DbParameter

        Try
            Using TransScope As New TransactionScope(TransactionScopeOption.Required)


                For Each loKey As CSM00400KeyDTO In poKey

                    loCmd = loDb.GetCommand()
                    lcQuery = "EXEC RSP_Generate_Source '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', @CERR_NO OUTPUT, @CERR_MSG OUTPUT "
                    With loKey
                        lcQuery = String.Format(lcQuery, _
                                                .CCOMPANY_ID, _
                                                .CAPPS_CODE, _
                                                .CATTRIBUTE_GROUP, _
                                                .CATTRIBUTE_ID, _
                                                .CPROGRAM_ID, _
                                                .CUSER_ID)
                    End With
                    loCmd.CommandText = lcQuery
                    loPar = loDb.GetParameter()
                    With loPar
                        .ParameterName = "@CERR_NO"
                        .DbType = DbType.String
                        .Size = 50
                        .Direction = ParameterDirection.Output
                    End With
                    loCmd.Parameters.Add(loPar)
                    loPar = loDb.GetParameter()
                    With loPar
                        .ParameterName = "@CERR_MSG"
                        .DbType = DbType.String
                        .Size = 100
                        .Direction = ParameterDirection.Output
                    End With
                    loCmd.Parameters.Add(loPar)
                    loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)

                    If loCmd.Parameters("@CERR_MSG") Is Nothing Then
                        loEx.Add("999", "UNKNOWN_ERROR")
                        Exit Try
                    Else
                        If Not loCmd.Parameters("@CERR_MSG").Value.Equals("OK") Then
                            loEx.Add(loCmd.Parameters("@CERR_NO").Value, loCmd.Parameters("@CERR_MSG").Value)
                            Exit Try
                        End If
                    End If
                Next

                TransScope.Complete()
            End Using

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If

        End Try
        loEx.ThrowExceptionIfErrors()
    End Sub

End Class
