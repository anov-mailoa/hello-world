﻿Public Class CSM00400SourceGroupDTO
    Public Property CSOURCE_GROUP_ID As String
    Public Property LSELECT As Boolean
End Class
