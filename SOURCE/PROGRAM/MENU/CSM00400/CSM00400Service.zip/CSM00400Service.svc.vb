﻿Imports R_Common
Imports CSM00400Back
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00400Service" in code, svc and config file together.
Public Class CSM00400Service
    Implements ICSM00400Service

    Public Sub Svc_R_Delete(poEntity As CSM00400Back.CSM00400DTO) Implements R_BackEnd.R_IServicebase(Of CSM00400Back.CSM00400DTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New CSM00400Cls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As CSM00400Back.CSM00400DTO) As CSM00400Back.CSM00400DTO Implements R_BackEnd.R_IServicebase(Of CSM00400Back.CSM00400DTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New CSM00400Cls
        Dim loRtn As CSM00400DTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As CSM00400Back.CSM00400DTO, poCRUDMode As R_Common.eCRUDMode) As CSM00400Back.CSM00400DTO Implements R_BackEnd.R_IServicebase(Of CSM00400Back.CSM00400DTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New CSM00400Cls
        Dim loRtn As CSM00400DTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Dummy1() As System.Collections.Generic.List(Of CSM00400Back.CSM00400KeyDTO) Implements ICSM00400Service.Dummy1

    End Function

    Public Function GetSourceGroupCombo(companyId As String, appsCode As String, attributeGroup As String, attributeId As String) As System.Collections.Generic.List(Of RLicenseBack.RCustDBSourceGroupComboDTO) Implements ICSM00400Service.GetSourceGroupCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBSourceGroupComboDTO)

        Try
            loRtn = loCls.GetSourceGroupCombo(companyId, appsCode, attributeGroup, attributeId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub GenerateSource(poKey As List(Of CSM00400Back.CSM00400KeyDTO)) Implements ICSM00400Service.GenerateSource
        Dim loEx As New R_Exception
        Dim loCls As New CSM00400Cls

        Try
            loCls.GenerateSource(poKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

    End Sub
End Class
