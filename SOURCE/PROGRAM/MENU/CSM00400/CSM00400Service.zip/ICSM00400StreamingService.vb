﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports CSM00400Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00400StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00400StreamingService

    <OperationContract(Action:="getSourceList", ReplyAction:="getSourceList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetSourceList() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of CSM00400GridDTO))

End Interface
