﻿Imports R_BackEnd
Imports R_Common
Imports System.Data.Common
Imports ServerHelper.General

Public Class LAT00500Cls
    Inherits R_BusinessObject(Of LAT00500DTO)

    Public Function GetContract(poTableKey As LAT00500KeyDTO) As List(Of LAT00500GridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of LAT00500GridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poTableKey

                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "LAT_CONTRACT (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                If .CAPPS_CODE IsNot Nothing Then
                    If Not .CAPPS_CODE.Trim.Equals("") Then
                        lcQuery += "AND CAPPS_CODE = '{1}' "
                    End If
                End If
                If .CCUSTOMER_CODE IsNot Nothing Then
                    If Not .CCUSTOMER_CODE.Trim.Equals("") Then
                        lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                    End If
                End If
                If .CCONTRACT_NO IsNot Nothing Then
                    If Not .CCONTRACT_NO.Trim.Equals("") Then
                        lcQuery += "AND CCONTRACT_NO = '{3}' "
                    End If
                End If
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CCUSTOMER_CODE, .CCONTRACT_NO)
            End With

            loResult = loDb.SqlExecObjectQuery(Of LAT00500GridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Deleting(poEntity As LAT00500DTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loResult As LAT00500DTO

        Try
            loConn = loDb.GetConnection()

            With poEntity
                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "LAT_CONTRACT "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                lcQuery += "AND CCONTRACT_NO = '{3}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CCUSTOMER_CODE, .CCONTRACT_NO)

                loDb.SqlExecNonQuery(lcQuery, loConn, True)

            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As LAT00500DTO) As LAT00500DTO
        Dim lcQuery As String
        Dim loResult As LAT00500DTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "LAT_CONTRACT (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                lcQuery += "AND CCONTRACT_NO = '{3}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CCUSTOMER_CODE, .CCONTRACT_NO)

                loResult = loDb.SqlExecObjectQuery(Of LAT00500DTO)(lcQuery).FirstOrDefault

            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As LAT00500DTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As LAT00500DTO

        Try
            loConn = loDb.GetConnection()

            With poNewEntity

                If poCRUDMode = eCRUDMode.AddMode Then
                    lcQuery = "SELECT * "
                    lcQuery += "FROM "
                    lcQuery += "LAT_CONTRACT (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                    lcQuery += "AND CCONTRACT_NO = '{3}' "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CCUSTOMER_CODE, .CCONTRACT_NO)

                    loResult = loDb.SqlExecObjectQuery(Of LAT00500DTO)(lcQuery, loConn, True).FirstOrDefault
                    If loResult IsNot Nothing Then
                        Throw New Exception("Contract No. " + .CCONTRACT_NO.Trim + " is already exist")
                    End If

                    ' Set Fields
                    .CCREATE_BY = .CUPDATE_BY
                    .DUPDATE_DATE = Now
                    .DCREATE_DATE = Now

                    lcQuery = "INSERT INTO LAT_CONTRACT ("
                    lcQuery += "CCOMPANY_ID, "
                    lcQuery += "CAPPS_CODE, "
                    lcQuery += "CCUSTOMER_CODE, "
                    lcQuery += "CCONTRACT_NO, "
                    lcQuery += "DCONTRACT_DATE, "
                    lcQuery += "CDESCRIPTION, "
                    lcQuery += "CUPDATE_BY, "
                    lcQuery += "DUPDATE_DATE, "
                    lcQuery += "CCREATE_BY, "
                    lcQuery += "DCREATE_DATE) "
                    lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', {4}, '{5}', '{6}', {7}, '{8}', {9}) "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CCUSTOMER_CODE,
                    .CCONTRACT_NO,
                    getDate(.DCONTRACT_DATE),
                    .CDESCRIPTION,
                    .CUPDATE_BY,
                    getDate(.DUPDATE_DATE),
                    .CCREATE_BY,
                    getDate(.DCREATE_DATE))

                    loDb.SqlExecNonQuery(lcQuery)

                ElseIf poCRUDMode = eCRUDMode.EditMode Then

                    lcQuery = "UPDATE LAT_CONTRACT "
                    lcQuery += "SET "
                    lcQuery += "DCONTRACT_DATE = {4}, "
                    lcQuery += "CDESCRIPTION = '{5}', "
                    lcQuery += "CUPDATE_BY = '{6}', "
                    lcQuery += "DUPDATE_DATE = {7} "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                    lcQuery += "AND CCONTRACT_NO = '{3}' "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CCUSTOMER_CODE,
                    .CCONTRACT_NO,
                    getDate(.DCONTRACT_DATE),
                    .CDESCRIPTION,
                    .CUPDATE_BY,
                    getDate(poNewEntity.DUPDATE_DATE))

                    loDb.SqlExecNonQuery(lcQuery, loConn, True)
                End If

            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
End Class
