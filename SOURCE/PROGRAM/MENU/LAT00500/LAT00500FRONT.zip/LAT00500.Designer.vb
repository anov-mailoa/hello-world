﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LAT00500
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxMultilineColumn1 As R_FrontEnd.R_GridViewTextBoxMultilineColumn = New R_FrontEnd.R_GridViewTextBoxMultilineColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cboCustomer = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsCust = New System.Windows.Forms.BindingSource(Me.components)
        Me.cboApplication = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblCustomer = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvContract = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsContract = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridContract = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.cboCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsCust, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvContract, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvContract.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsContract, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridContract, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.gvContract, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.cboCustomer)
        Me.Panel1.Controls.Add(Me.cboApplication)
        Me.Panel1.Controls.Add(Me.lblCustomer)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 74)
        Me.Panel1.TabIndex = 0
        '
        'cboCustomer
        '
        Me.cboCustomer.DataSource = Me.bsCust
        Me.cboCustomer.DisplayMember = "CCUSTOMER_NAME"
        Me.cboCustomer.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList
        Me.cboCustomer.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboCustomer.Location = New System.Drawing.Point(115, 35)
        Me.cboCustomer.Name = "cboCustomer"
        Me.cboCustomer.R_ConductorGridSource = Nothing
        Me.cboCustomer.R_ConductorSource = Nothing
        Me.cboCustomer.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboCustomer.Size = New System.Drawing.Size(400, 20)
        Me.cboCustomer.TabIndex = 11
        Me.cboCustomer.Text = "R_RadDropDownList1"
        Me.cboCustomer.ValueMember = "CCUSTOMER_CODE"
        '
        'bsCust
        '
        Me.bsCust.DataSource = GetType(LAT00500Front.LAT00500ServiceRef.RLicenseCustComboDTO)
        '
        'cboApplication
        '
        Me.cboApplication.DataSource = Me.bsApps
        Me.cboApplication.DisplayMember = "CAPPS_NAME"
        Me.cboApplication.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList
        Me.cboApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboApplication.Location = New System.Drawing.Point(115, 9)
        Me.cboApplication.Name = "cboApplication"
        Me.cboApplication.R_ConductorGridSource = Nothing
        Me.cboApplication.R_ConductorSource = Nothing
        Me.cboApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboApplication.Size = New System.Drawing.Size(400, 20)
        Me.cboApplication.TabIndex = 10
        Me.cboApplication.Text = "R_RadDropDownList1"
        Me.cboApplication.ValueMember = "CAPPS_CODE"
        '
        'bsApps
        '
        Me.bsApps.DataSource = GetType(LAT00500Front.LAT00500ServiceRef.RLicenseAppComboDTO)
        '
        'lblCustomer
        '
        Me.lblCustomer.AutoSize = False
        Me.lblCustomer.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustomer.Location = New System.Drawing.Point(9, 33)
        Me.lblCustomer.Name = "lblCustomer"
        Me.lblCustomer.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustomer.R_ResourceId = "lblCustomer"
        Me.lblCustomer.Size = New System.Drawing.Size(100, 18)
        Me.lblCustomer.TabIndex = 9
        Me.lblCustomer.Text = "Customer..."
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 8
        Me.lblApplication.Text = "Application..."
        '
        'gvContract
        '
        Me.gvContract.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvContract.EnableFastScrolling = True
        Me.gvContract.Location = New System.Drawing.Point(3, 83)
        '
        '
        '
        Me.gvContract.MasterTemplate.AutoGenerateColumns = False
        Me.gvContract.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn1.FieldName = "_CCONTRACT_NO"
        R_GridViewTextBoxColumn1.HeaderText = "_CCONTRACT_NO"
        R_GridViewTextBoxColumn1.Name = "_CCONTRACT_NO"
        R_GridViewTextBoxColumn1.R_EnableADD = True
        R_GridViewTextBoxColumn1.R_ResourceId = "_CCONTRACT_NO"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 1148
        R_GridViewDateTimeColumn1.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn1.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn1.FieldName = "_DCONTRACT_DATE"
        R_GridViewDateTimeColumn1.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn1.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn1.HeaderText = "_DCONTRACT_DATE"
        R_GridViewDateTimeColumn1.Name = "_DCONTRACT_DATE"
        R_GridViewDateTimeColumn1.R_EnableADD = True
        R_GridViewDateTimeColumn1.R_EnableEDIT = True
        R_GridViewDateTimeColumn1.R_ResourceId = "_DCONTRACT_DATE"
        R_GridViewDateTimeColumn1.Width = 52
        R_GridViewTextBoxMultilineColumn1.FieldName = "_CDESCRIPTION"
        R_GridViewTextBoxMultilineColumn1.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxMultilineColumn1.Name = "_CDESCRIPTION"
        R_GridViewTextBoxMultilineColumn1.R_EnableADD = True
        R_GridViewTextBoxMultilineColumn1.R_EnableEDIT = True
        R_GridViewTextBoxMultilineColumn1.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxMultilineColumn1.R_UDT = Nothing
        R_GridViewTextBoxMultilineColumn1.ReadOnly = True
        R_GridViewTextBoxMultilineColumn1.Width = 53
        R_GridViewTextBoxMultilineColumn1.WrapText = True
        Me.gvContract.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewDateTimeColumn1, R_GridViewTextBoxMultilineColumn1})
        Me.gvContract.MasterTemplate.DataSource = Me.bsContract
        Me.gvContract.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvContract.MasterTemplate.EnableFiltering = True
        Me.gvContract.MasterTemplate.EnableGrouping = False
        Me.gvContract.MasterTemplate.ShowFilteringRow = False
        Me.gvContract.MasterTemplate.ShowGroupedColumns = True
        Me.gvContract.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvContract.Name = "gvContract"
        Me.gvContract.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvContract.R_ConductorGridSource = Me.conGridContract
        Me.gvContract.R_ConductorSource = Nothing
        Me.gvContract.R_DataAdded = False
        Me.gvContract.R_NewRowText = Nothing
        Me.gvContract.ShowHeaderCellButtons = True
        Me.gvContract.Size = New System.Drawing.Size(1271, 489)
        Me.gvContract.TabIndex = 1
        Me.gvContract.Text = "R_RadGridView1"
        '
        'bsContract
        '
        Me.bsContract.DataSource = GetType(LAT00500Front.LAT00500ServiceRef.LAT00500DTO)
        '
        'conGridContract
        '
        Me.conGridContract.R_ConductorParent = Nothing
        Me.conGridContract.R_IsHeader = True
        Me.conGridContract.R_RadGroupBox = Nothing
        '
        'LAT00500
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "LAT00500"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.cboCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsCust, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvContract.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvContract, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsContract, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridContract, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents cboCustomer As R_FrontEnd.R_RadDropDownList
    Friend WithEvents cboApplication As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblCustomer As R_FrontEnd.R_RadLabel
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents gvContract As R_FrontEnd.R_RadGridView
    Friend WithEvents bsContract As System.Windows.Forms.BindingSource
    Friend WithEvents bsCust As System.Windows.Forms.BindingSource
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource
    Friend WithEvents conGridContract As R_FrontEnd.R_ConductorGrid

End Class
