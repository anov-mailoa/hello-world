﻿Public Class LAT00400KeyDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CCUSTOMER_CODE As String
    Public Property CCONFIG_ID As String
    Public Property CFIELD_NAME As String
End Class
