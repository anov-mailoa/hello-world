﻿Imports R_BackEnd
Imports R_Common
Imports System.Data.Common
Imports ServerHelper.General

Public Class LAT00400Cls
    Inherits R_BusinessObject(Of LAT00400CuCoDTO)

    Public Function GetCustomerConfig(poTableKey As LAT00400KeyDTO) As List(Of LAT00400CuCoGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of LAT00400CuCoGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poTableKey

                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "LAT_CUSTOMER_CONFIG (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                If .CAPPS_CODE IsNot Nothing Then
                    If Not .CAPPS_CODE.Trim.Equals("") Then
                        lcQuery += "AND CAPPS_CODE = '{1}' "
                    End If
                End If
                If .CCUSTOMER_CODE IsNot Nothing Then
                    If Not .CCUSTOMER_CODE.Trim.Equals("") Then
                        lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                    End If
                End If
                If .CCONFIG_ID IsNot Nothing Then
                    If Not .CCONFIG_ID.Trim.Equals("") Then
                        lcQuery += "AND CCONFIG_ID = '{3}' "
                    End If
                End If
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CCUSTOMER_CODE, .CCONFIG_ID)
            End With

            loResult = loDb.SqlExecObjectQuery(Of LAT00400CuCoGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Deleting(poEntity As LAT00400CuCoDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loResult As LAT00400CuCoDTO

        Try
            loConn = loDb.GetConnection()

            With poEntity
                ' validasi
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "LAT_CUSTOMER_CONFIG_DETAIL (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                lcQuery += "AND CCONFIG_ID = '{3}' "

                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CCUSTOMER_CODE, .CCONFIG_ID)

                loResult = loDb.SqlExecObjectQuery(Of LAT00400CuCoDTO)(lcQuery, loConn, False).FirstOrDefault
                If loResult IsNot Nothing Then
                    Throw New Exception("Customer Configuration Update No. " + .CCONFIG_ID.Trim + " has already had detail information.")
                End If

                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "LAT_CUSTOMER_CONFIG "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                lcQuery += "AND CCONFIG_ID = '{3}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CCUSTOMER_CODE, .CCONFIG_ID)

                loDb.SqlExecNonQuery(lcQuery, loConn, True)

            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

    Protected Overrides Function R_Display(poEntity As LAT00400CuCoDTO) As LAT00400CuCoDTO
        Dim lcQuery As String
        Dim loResult As LAT00400CuCoDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "LAT_CUSTOMER_CONFIG (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                lcQuery += "AND CCONFIG_ID = '{3}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CCUSTOMER_CODE, .CCONFIG_ID)

                loResult = loDb.SqlExecObjectQuery(Of LAT00400CuCoDTO)(lcQuery).FirstOrDefault

            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As LAT00400CuCoDTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As LAT00400CuCoDTO

        Try
            loConn = loDb.GetConnection()

            With poNewEntity

                If poCRUDMode = eCRUDMode.AddMode Then
                    lcQuery = "SELECT * "
                    lcQuery += "FROM "
                    lcQuery += "LAT_CUSTOMER_CONFIG (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                    lcQuery += "AND CCONFIG_ID = '{3}' "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CCUSTOMER_CODE, .CCONFIG_ID)

                    loResult = loDb.SqlExecObjectQuery(Of LAT00400CuCoDTO)(lcQuery, loConn, True).FirstOrDefault
                    If loResult IsNot Nothing Then
                        Throw New Exception("Customer Configuration Update No. " + .CCONFIG_ID.Trim + " is already exist")
                    End If

                    ' Set CCONFIG_ID
                    .CCONFIG_ID = Now.ToString("yyyyMMdd-HHmmss")
                    .CCREATE_BY = .CUPDATE_BY
                    .DUPDATE_DATE = Now
                    .DCREATE_DATE = Now

                    lcQuery = "INSERT INTO LAT_CUSTOMER_CONFIG ("
                    lcQuery += "CCOMPANY_ID, "
                    lcQuery += "CAPPS_CODE, "
                    lcQuery += "CCUSTOMER_CODE, "
                    lcQuery += "CCONFIG_ID, "
                    lcQuery += "CAPPS_NAME, "
                    lcQuery += "DCONFIG_DATE, "
                    lcQuery += "CCONFIG_BY, "
                    lcQuery += "CNOTE, "
                    lcQuery += "CUPDATE_BY, "
                    lcQuery += "DUPDATE_DATE, "
                    lcQuery += "CCREATE_BY, "
                    lcQuery += "DCREATE_DATE) "
                    lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', {5}, '{6}', '{7}', '{8}', {9}, '{10}', {11}) "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CCUSTOMER_CODE,
                    .CCONFIG_ID,
                    .CAPPS_NAME,
                    getDate(.DCONFIG_DATE),
                    .CCONFIG_BY,
                    .CNOTE,
                    .CUPDATE_BY,
                    getDate(.DUPDATE_DATE),
                    .CCREATE_BY,
                    getDate(.DCREATE_DATE))

                    loDb.SqlExecNonQuery(lcQuery)

                ElseIf poCRUDMode = eCRUDMode.EditMode Then

                    lcQuery = "UPDATE LAT_CUSTOMER_CONFIG "
                    lcQuery += "SET "
                    lcQuery += "DCONFIG_DATE = {4}, "
                    lcQuery += "CCONFIG_BY = '{5}', "
                    lcQuery += "CNOTE = '{6}', "
                    lcQuery += "CUPDATE_BY = '{7}', "
                    lcQuery += "DUPDATE_DATE = {8} "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                    lcQuery += "AND CCONFIG_ID = '{3}' "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CCUSTOMER_CODE,
                    .CCONFIG_ID,
                    getDate(.DCONFIG_DATE),
                    .CCONFIG_BY,
                    .CNOTE,
                    .CUPDATE_BY,
                    getDate(poNewEntity.DUPDATE_DATE))

                    loDb.SqlExecNonQuery(lcQuery, loConn, True)
                End If

            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
End Class
