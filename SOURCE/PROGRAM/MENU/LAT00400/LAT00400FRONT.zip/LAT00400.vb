﻿Imports LAT00400FrontResources
Imports R_Common
Imports LAT00400Front.LAT00400ServiceRef
Imports LAT00400Front.LAT00400StreamingServiceRef
Imports LAT00400Front.LAT00400DetailServiceRef
Imports System.ServiceModel.Channels
Imports ClientHelper
Imports R_FrontEnd

Public Class LAT00400

#Region " VARIABLE "
    Dim C_ServiceName As String = "LAT00400Service/LAT00400Service.svc"
    Dim C_ServiceNameStream As String = "LAT00400Service/LAT00400StreamingService.svc"
    Dim C_ServiceNameDetail As String = "LAT00400Service/LAT00400DetailService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim llInitialized As Boolean = False
#End Region

#Region " Form Methods "

    Private Sub LAT00200_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loSvc As LAT00400ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00400Service, LAT00400ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loAppCombo As New List(Of RLicenseAppComboDTO)

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            ' Application
            loAppCombo = loSvc.GetAppCombo(_CCOMPID, _CUSERID)
            bsApps.DataSource = loAppCombo

            llInitialized = True
            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub LAT00400_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " Combos "

    Private Sub cboApplication_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboApplication.SelectedValueChanged
        Dim loEx As New R_Exception
        Dim loSvc As LAT00400ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00400Service, LAT00400ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loCustCombo As New List(Of RLicenseCustComboDTO)

        Try
            ' Customer
            loCustCombo = loSvc.GetCustByAppsCombo(_CCOMPID, CType(sender, R_RadDropDownList).SelectedValue)
            bsCust.DataSource = loCustCombo
            loSvc.Close()
            ' Apps Field
            RefreshAppsFieldCombo()
            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub cboCustomer_TextChanged(sender As Object, e As System.EventArgs) Handles cboCustomer.TextChanged
        If llInitialized Then
            RefreshGrids()
        End If
    End Sub

#End Region

#Region " Header GridView Methods "

    Private Sub gvCuCo_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvCuCo.R_Display
        Dim loEx As New R_Exception
        Dim loTableKey As New LAT00400KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = cboApplication.SelectedValue.Trim
                .CCUSTOMER_CODE = cboCustomer.SelectedValue.Trim
                .CCONFIG_ID = CType(poEntity, LAT00400CuCoDTO)._CCONFIG_ID
            End With
            gvCuCoDtl.R_RefreshGrid(loTableKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
    Private Sub gvCuCo_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvCuCo.R_Saving
        With CType(poEntity, LAT00400CuCoDTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = cboApplication.SelectedValue.Trim
            ._CAPPS_NAME = cboApplication.SelectedText.Trim
            ._CCUSTOMER_CODE = cboCustomer.SelectedValue.Trim
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With
    End Sub
    Private Sub gvCuCo_R_ServiceDelete(poEntity As Object) Handles gvCuCo.R_ServiceDelete
        Dim loService As LAT00400ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00400Service, LAT00400ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
    Private Sub gvCuCo_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvCuCo.R_ServiceGetListRecord
        Dim loServiceStream As LAT00400StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00400StreamingService, LAT00400StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of LAT00400CuCoGridDTO)
        Dim loListEntity As New List(Of LAT00400CuCoDTO)

        Try
            With poEntity
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cCustomerCode", .CCUSTOMER_CODE)
            End With

            loRtn = loServiceStream.GetCustomerConfig()
            loStreaming = R_StreamUtility(Of LAT00400CuCoGridDTO).ReadFromMessage(loRtn)

            For Each loDto As LAT00400CuCoGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New LAT00400CuCoDTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                               ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                               ._CCUSTOMER_CODE = loDto.CCUSTOMER_CODE,
                                                               ._CCONFIG_ID = loDto.CCONFIG_ID,
                                                               ._DCONFIG_DATE = loDto.DCONFIG_DATE,
                                                               ._CCONFIG_BY = loDto.CCONFIG_BY,
                                                               ._CNOTE = loDto.CNOTE,
                                                               ._CCREATE_BY = loDto.CCREATE_BY,
                                                               ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                               ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                               ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub
    Private Sub gvCuCo_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvCuCo.R_ServiceGetRecord
        Dim loService As LAT00400ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00400Service, LAT00400ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New LAT00400CuCoDTO With {._CCOMPANY_ID = _CCOMPID,
                                                                                 ._CAPPS_CODE = cboApplication.SelectedValue.Trim,
                                                                                 ._CCUSTOMER_CODE = cboCustomer.SelectedValue.Trim,
                                                                                 ._CCONFIG_ID = CType(bsCuCo.Current, LAT00400CuCoDTO)._CCONFIG_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
    Private Sub gvCuCo_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvCuCo.R_ServiceSave
        Dim loService As LAT00400ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00400Service, LAT00400ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
    Private Sub gvCuCo_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvCuCo.R_Validation
        Dim loEx As New R_Exception()

        Try
            pcError = ""
            With poGridCellCollection
                If String.IsNullOrWhiteSpace(.Item(1).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS001")
                    loEx.Add("PS001", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS001"))
                    plCancel = True
                End If

                If String.IsNullOrWhiteSpace(.Item(2).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS002")
                    loEx.Add("PS002", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS002"))
                    plCancel = True
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " Header Conductor Methods "

    Private Sub conGridCuCo_R_SetHasData(plEnable As Boolean) Handles conGridCuCo.R_SetHasData
        gvCuCoDtl.Enabled = plEnable
    End Sub

#End Region

#Region " Detail Gridview Methods "

    Private Sub gvCuCoDtl_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvCuCoDtl.R_Saving
        With CType(poEntity, LAT00400CuCoDtlDTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = cboApplication.SelectedValue.Trim
            ._CCUSTOMER_CODE = cboCustomer.SelectedValue.Trim
            ._CCONFIG_ID = CType(bsCuCo.Current, LAT00400CuCoDTO)._CCONFIG_ID
            ._CSEQUENCE = CType(bsAppsFieldCombo.Current, LAM00600GridDTO).CSEQUENCE
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With
    End Sub
    Private Sub gvCuCoDtl_R_ServiceDelete(poEntity As Object) Handles gvCuCoDtl.R_ServiceDelete
        Dim loService As LAT00400DetailServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00400DetailService, LAT00400DetailServiceClient)(e_ServiceClientType.RegularService, C_ServiceNameDetail)
        Dim loEx As New R_Exception

        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
    Private Sub gvCuCoDtl_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvCuCoDtl.R_ServiceGetListRecord
        Dim loServiceStream As LAT00400StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00400StreamingService, LAT00400StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of LAT00400CuCoDtlGridDTO)
        Dim loListEntity As New List(Of LAT00400CuCoDtlDTO)

        Try
            With poEntity
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cCustomerCode", .CCUSTOMER_CODE)
                R_Utility.R_SetStreamingContext("cConfigId", .CCONFIG_ID)
            End With

            loRtn = loServiceStream.GetCustomerConfigDetail()
            loStreaming = R_StreamUtility(Of LAT00400CuCoDtlGridDTO).ReadFromMessage(loRtn)

            For Each loDto As LAT00400CuCoDtlGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New LAT00400CuCoDtlDTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                                  ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                                  ._CCUSTOMER_CODE = loDto.CCUSTOMER_CODE,
                                                                  ._CCONFIG_ID = loDto.CCONFIG_ID,
                                                                  ._CFIELD_NAME = loDto.CFIELD_NAME,
                                                                  ._CFIELD_VALUE = loDto.CFIELD_VALUE,
                                                                  ._CSEQUENCE = loDto.CSEQUENCE,
                                                                  ._CCREATE_BY = loDto.CCREATE_BY,
                                                                  ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                                  ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                                  ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub
    Private Sub gvCuCoDtl_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvCuCoDtl.R_ServiceGetRecord
        Dim loService As LAT00400DetailServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00400DetailService, LAT00400DetailServiceClient)(e_ServiceClientType.RegularService, C_ServiceNameDetail)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New LAT00400CuCoDtlDTO With {._CCOMPANY_ID = _CCOMPID,
                                                                                    ._CAPPS_CODE = cboApplication.SelectedValue.Trim,
                                                                                    ._CCUSTOMER_CODE = cboCustomer.SelectedValue.Trim,
                                                                                    ._CCONFIG_ID = CType(bsCuCo.Current, LAT00400CuCoDTO)._CCONFIG_ID,
                                                                                    ._CFIELD_NAME = CType(bsCuCoDtl.Current, LAT00400CuCoDtlDTO)._CFIELD_NAME})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
    Private Sub gvCuCoDtl_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvCuCoDtl.R_ServiceSave
        Dim loService As LAT00400DetailServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00400DetailService, LAT00400DetailServiceClient)(e_ServiceClientType.RegularService, C_ServiceNameDetail)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " Functions "

    Private Sub RefreshGrids()
        Dim loTableKey As New LAT00400KeyDTO

        ' Get CuCo header
        With loTableKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = cboApplication.SelectedValue.Trim
            .CCUSTOMER_CODE = cboCustomer.SelectedValue.Trim
        End With

        gvCuCo.R_RefreshGrid(loTableKey)
    End Sub

    Private Sub RefreshAppsFieldCombo()
        Dim loService As LAT00400DetailServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00400DetailService, LAT00400DetailServiceClient)(e_ServiceClientType.RegularService, C_ServiceNameDetail)
        Dim loAppsFieldKey As New LAM00600KeyDTO

        ' Initiate detail field name combo
        With loAppsFieldKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = cboApplication.SelectedValue.Trim
            .LFIELD_GROUP = False
        End With
        bsAppsFieldCombo.DataSource = loService.GetAppsFieldCombo(loAppsFieldKey)
        loService.Close()
    End Sub
#End Region

End Class
