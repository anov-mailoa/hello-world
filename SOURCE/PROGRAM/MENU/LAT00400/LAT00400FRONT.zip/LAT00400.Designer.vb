﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LAT00400
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxMultilineColumn1 As R_FrontEnd.R_GridViewTextBoxMultilineColumn = New R_FrontEnd.R_GridViewTextBoxMultilineColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewComboBoxColumn1 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.bsAppsFieldCombo = New System.Windows.Forms.BindingSource(Me.components)
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.gvCuCo = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsCuCo = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridCuCo = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cboCustomer = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsCust = New System.Windows.Forms.BindingSource(Me.components)
        Me.cboApplication = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblCustomer = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvCuCoDtl = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsCuCoDtl = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridCuCoDtl = New R_FrontEnd.R_ConductorGrid(Me.components)
        CType(Me.bsAppsFieldCombo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.gvCuCo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvCuCo.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsCuCo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridCuCo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.cboCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsCust, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvCuCoDtl, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvCuCoDtl.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsCuCoDtl, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridCuCoDtl, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'bsAppsFieldCombo
        '
        Me.bsAppsFieldCombo.DataSource = GetType(LAT00400Front.LAT00400DetailServiceRef.LAM00600GridDTO)
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.gvCuCo, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.gvCuCoDtl, 0, 2)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 70.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'gvCuCo
        '
        Me.gvCuCo.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvCuCo.EnableFastScrolling = True
        Me.gvCuCo.Location = New System.Drawing.Point(3, 83)
        '
        '
        '
        Me.gvCuCo.MasterTemplate.AutoGenerateColumns = False
        Me.gvCuCo.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn1.FieldName = "_CCONFIG_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CCONFIG_ID"
        R_GridViewTextBoxColumn1.Name = "_CCONFIG_ID"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CCONFIG_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 314
        R_GridViewTextBoxColumn2.FieldName = "_CCONFIG_BY"
        R_GridViewTextBoxColumn2.HeaderText = "_CCONFIG_BY"
        R_GridViewTextBoxColumn2.Name = "_CCONFIG_BY"
        R_GridViewTextBoxColumn2.R_EnableADD = True
        R_GridViewTextBoxColumn2.R_EnableEDIT = True
        R_GridViewTextBoxColumn2.R_ResourceId = "_CCONFIG_BY"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 314
        R_GridViewDateTimeColumn1.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn1.FieldName = "_DCONFIG_DATE"
        R_GridViewDateTimeColumn1.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn1.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn1.HeaderText = "_DCONFIG_DATE"
        R_GridViewDateTimeColumn1.Name = "_DCONFIG_DATE"
        R_GridViewDateTimeColumn1.R_EnableADD = True
        R_GridViewDateTimeColumn1.R_EnableEDIT = True
        R_GridViewDateTimeColumn1.R_ResourceId = "_DCONFIG_DATE"
        R_GridViewDateTimeColumn1.Width = 314
        R_GridViewTextBoxMultilineColumn1.FieldName = "_CNOTE"
        R_GridViewTextBoxMultilineColumn1.HeaderText = "_CNOTE"
        R_GridViewTextBoxMultilineColumn1.Name = "_CNOTE"
        R_GridViewTextBoxMultilineColumn1.R_EnableADD = True
        R_GridViewTextBoxMultilineColumn1.R_EnableEDIT = True
        R_GridViewTextBoxMultilineColumn1.R_ResourceId = "_CNOTE"
        R_GridViewTextBoxMultilineColumn1.R_UDT = Nothing
        R_GridViewTextBoxMultilineColumn1.ReadOnly = True
        R_GridViewTextBoxMultilineColumn1.Width = 312
        R_GridViewTextBoxMultilineColumn1.WrapText = True
        Me.gvCuCo.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewDateTimeColumn1, R_GridViewTextBoxMultilineColumn1})
        Me.gvCuCo.MasterTemplate.DataSource = Me.bsCuCo
        Me.gvCuCo.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvCuCo.MasterTemplate.EnableFiltering = True
        Me.gvCuCo.MasterTemplate.EnableGrouping = False
        Me.gvCuCo.MasterTemplate.ShowFilteringRow = False
        Me.gvCuCo.MasterTemplate.ShowGroupedColumns = True
        Me.gvCuCo.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvCuCo.Name = "gvCuCo"
        Me.gvCuCo.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvCuCo.R_ConductorGridSource = Me.conGridCuCo
        Me.gvCuCo.R_ConductorSource = Nothing
        Me.gvCuCo.R_DataAdded = False
        Me.gvCuCo.R_NewRowText = Nothing
        Me.gvCuCo.ShowHeaderCellButtons = True
        Me.gvCuCo.Size = New System.Drawing.Size(1271, 142)
        Me.gvCuCo.TabIndex = 7
        Me.gvCuCo.Text = "R_RadGridView1"
        '
        'bsCuCo
        '
        Me.bsCuCo.DataSource = GetType(LAT00400Front.LAT00400ServiceRef.LAT00400CuCoDTO)
        '
        'conGridCuCo
        '
        Me.conGridCuCo.R_ConductorParent = Nothing
        Me.conGridCuCo.R_IsHeader = True
        Me.conGridCuCo.R_RadGroupBox = Nothing
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.cboCustomer)
        Me.Panel1.Controls.Add(Me.cboApplication)
        Me.Panel1.Controls.Add(Me.lblCustomer)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 74)
        Me.Panel1.TabIndex = 0
        '
        'cboCustomer
        '
        Me.cboCustomer.DataSource = Me.bsCust
        Me.cboCustomer.DisplayMember = "CCUSTOMER_NAME"
        Me.cboCustomer.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboCustomer.Location = New System.Drawing.Point(115, 35)
        Me.cboCustomer.Name = "cboCustomer"
        Me.cboCustomer.R_ConductorGridSource = Nothing
        Me.cboCustomer.R_ConductorSource = Nothing
        Me.cboCustomer.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboCustomer.Size = New System.Drawing.Size(400, 20)
        Me.cboCustomer.TabIndex = 7
        Me.cboCustomer.Text = "R_RadDropDownList1"
        Me.cboCustomer.ValueMember = "CCUSTOMER_CODE"
        '
        'bsCust
        '
        Me.bsCust.DataSource = GetType(LAT00400Front.LAT00400ServiceRef.RLicenseCustComboDTO)
        '
        'cboApplication
        '
        Me.cboApplication.DataSource = Me.bsApps
        Me.cboApplication.DisplayMember = "CAPPS_NAME"
        Me.cboApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboApplication.Location = New System.Drawing.Point(115, 9)
        Me.cboApplication.Name = "cboApplication"
        Me.cboApplication.R_ConductorGridSource = Nothing
        Me.cboApplication.R_ConductorSource = Nothing
        Me.cboApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboApplication.Size = New System.Drawing.Size(400, 20)
        Me.cboApplication.TabIndex = 6
        Me.cboApplication.Text = "R_RadDropDownList1"
        Me.cboApplication.ValueMember = "CAPPS_CODE"
        '
        'bsApps
        '
        Me.bsApps.DataSource = GetType(LAT00400Front.LAT00400ServiceRef.RLicenseAppComboDTO)
        '
        'lblCustomer
        '
        Me.lblCustomer.AutoSize = False
        Me.lblCustomer.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustomer.Location = New System.Drawing.Point(9, 33)
        Me.lblCustomer.Name = "lblCustomer"
        Me.lblCustomer.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustomer.R_ResourceId = "lblCustomer"
        Me.lblCustomer.Size = New System.Drawing.Size(100, 18)
        Me.lblCustomer.TabIndex = 5
        Me.lblCustomer.Text = "Customer..."
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 4
        Me.lblApplication.Text = "Application..."
        '
        'gvCuCoDtl
        '
        Me.gvCuCoDtl.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvCuCoDtl.EnableFastScrolling = True
        Me.gvCuCoDtl.Location = New System.Drawing.Point(3, 231)
        '
        '
        '
        Me.gvCuCoDtl.MasterTemplate.AutoGenerateColumns = False
        Me.gvCuCoDtl.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn3.FieldName = "_CSEQUENCE"
        R_GridViewTextBoxColumn3.HeaderText = "_CSEQUENCE"
        R_GridViewTextBoxColumn3.Name = "_CSEQUENCE"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CSEQUENCE"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 54
        R_GridViewComboBoxColumn1.DataSource = Me.bsAppsFieldCombo
        R_GridViewComboBoxColumn1.DisplayMember = "CFIELD_NAME"
        R_GridViewComboBoxColumn1.FieldName = "_CFIELD_NAME"
        R_GridViewComboBoxColumn1.HeaderText = "_CFIELD_NAME"
        R_GridViewComboBoxColumn1.Name = "_CFIELD_NAME"
        R_GridViewComboBoxColumn1.R_EnableADD = True
        R_GridViewComboBoxColumn1.R_ResourceId = "_CFIELD_NAME"
        R_GridViewComboBoxColumn1.ValueMember = "CFIELD_NAME"
        R_GridViewComboBoxColumn1.Width = 1148
        R_GridViewTextBoxColumn4.FieldName = "_CFIELD_VALUE"
        R_GridViewTextBoxColumn4.HeaderText = "_CFIELD_VALUE"
        R_GridViewTextBoxColumn4.Name = "_CFIELD_VALUE"
        R_GridViewTextBoxColumn4.R_EnableADD = True
        R_GridViewTextBoxColumn4.R_EnableEDIT = True
        R_GridViewTextBoxColumn4.R_ResourceId = "_CFIELD_VALUE"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 51
        Me.gvCuCoDtl.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn3, R_GridViewComboBoxColumn1, R_GridViewTextBoxColumn4})
        Me.gvCuCoDtl.MasterTemplate.DataSource = Me.bsCuCoDtl
        Me.gvCuCoDtl.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvCuCoDtl.MasterTemplate.EnableFiltering = True
        Me.gvCuCoDtl.MasterTemplate.EnableGrouping = False
        Me.gvCuCoDtl.MasterTemplate.ShowFilteringRow = False
        Me.gvCuCoDtl.MasterTemplate.ShowGroupedColumns = True
        Me.gvCuCoDtl.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvCuCoDtl.Name = "gvCuCoDtl"
        Me.gvCuCoDtl.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvCuCoDtl.R_ConductorGridSource = Me.conGridCuCoDtl
        Me.gvCuCoDtl.R_ConductorSource = Nothing
        Me.gvCuCoDtl.R_DataAdded = False
        Me.gvCuCoDtl.R_NewRowText = Nothing
        Me.gvCuCoDtl.ShowHeaderCellButtons = True
        Me.gvCuCoDtl.Size = New System.Drawing.Size(1271, 341)
        Me.gvCuCoDtl.TabIndex = 8
        Me.gvCuCoDtl.Text = "R_RadGridView1"
        '
        'bsCuCoDtl
        '
        Me.bsCuCoDtl.DataSource = GetType(LAT00400Front.LAT00400DetailServiceRef.LAT00400CuCoDtlDTO)
        '
        'conGridCuCoDtl
        '
        Me.conGridCuCoDtl.R_ConductorParent = Me.conGridCuCo
        Me.conGridCuCoDtl.R_RadGroupBox = Nothing
        '
        'LAT00400
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "LAT00400"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.bsAppsFieldCombo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        CType(Me.gvCuCo.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvCuCo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsCuCo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridCuCo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.cboCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsCust, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvCuCoDtl.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvCuCoDtl, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsCuCoDtl, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridCuCoDtl, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents cboCustomer As R_FrontEnd.R_RadDropDownList
    Friend WithEvents cboApplication As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblCustomer As R_FrontEnd.R_RadLabel
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource
    Friend WithEvents bsCust As System.Windows.Forms.BindingSource
    Friend WithEvents bsCuCo As System.Windows.Forms.BindingSource
    Friend WithEvents gvCuCo As R_FrontEnd.R_RadGridView
    Friend WithEvents conGridCuCo As R_FrontEnd.R_ConductorGrid
    Friend WithEvents gvCuCoDtl As R_FrontEnd.R_RadGridView
    Friend WithEvents conGridCuCoDtl As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsCuCoDtl As System.Windows.Forms.BindingSource
    Friend WithEvents bsAppsFieldCombo As System.Windows.Forms.BindingSource

End Class
