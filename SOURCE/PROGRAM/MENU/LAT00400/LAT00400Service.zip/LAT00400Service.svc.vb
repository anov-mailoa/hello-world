﻿Imports R_Common
Imports LAT00400Back
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the class name "LAT00400Service" in code, svc and config file together.
Public Class LAT00400Service
    Implements ILAT00400Service

    Public Sub Svc_R_Delete(poEntity As LAT00400Back.LAT00400CuCoDTO) Implements R_BackEnd.R_IServicebase(Of LAT00400Back.LAT00400CuCoDTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New LAT00400Cls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As LAT00400Back.LAT00400CuCoDTO) As LAT00400Back.LAT00400CuCoDTO Implements R_BackEnd.R_IServicebase(Of LAT00400Back.LAT00400CuCoDTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New LAT00400Cls
        Dim loRtn As LAT00400CuCoDTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As LAT00400Back.LAT00400CuCoDTO, poCRUDMode As R_Common.eCRUDMode) As LAT00400Back.LAT00400CuCoDTO Implements R_BackEnd.R_IServicebase(Of LAT00400Back.LAT00400CuCoDTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New LAT00400Cls
        Dim loRtn As LAT00400CuCoDTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetCustByAppsCombo(companyId As String, appsCode As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseCustComboDTO) Implements ILAT00400Service.GetCustByAppsCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseCustComboDTO)

        Try
            loRtn = loCls.GetCustByAppsCombo(companyId, appsCode)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn

    End Function

    Public Function GetAppCombo(companyId As String, userId As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseAppComboDTO) Implements ILAT00400Service.GetAppCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseAppComboDTO)

        Try
            loRtn = loCls.GetAppCombo(companyId, userId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn

    End Function

    Public Function Dummy1() As System.Collections.Generic.List(Of LAT00400Back.LAT00400KeyDTO) Implements ILAT00400Service.Dummy1

    End Function
End Class
