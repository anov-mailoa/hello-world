﻿Imports R_Common
Imports CSM00520Back
Imports CST00200Back
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00520IssueService" in code, svc and config file together.
Public Class CSM00520IssueService
    Implements ICSM00520IssueService

    Public Sub Svc_R_Delete(poEntity As CSM00520Back.CSM00520IssueDTO) Implements R_BackEnd.R_IServicebase(Of CSM00520Back.CSM00520IssueDTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New CSM00520IssueCls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As CSM00520Back.CSM00520IssueDTO) As CSM00520Back.CSM00520IssueDTO Implements R_BackEnd.R_IServicebase(Of CSM00520Back.CSM00520IssueDTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New CSM00520IssueCls
        Dim loRtn As CSM00520IssueDTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As CSM00520Back.CSM00520IssueDTO, poCRUDMode As R_Common.eCRUDMode) As CSM00520Back.CSM00520IssueDTO Implements R_BackEnd.R_IServicebase(Of CSM00520Back.CSM00520IssueDTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New CSM00520IssueCls
        Dim loRtn As CSM00520IssueDTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetIssueClassCombo(key As CST00200Back.CST00200KeyDTO) As System.Collections.Generic.List(Of CST00200Back.CST00200IssueClassComboDTO) Implements ICSM00520IssueService.GetIssueClassCombo
        Dim loException As New R_Exception
        Dim loCls As New CST00200Cls
        Dim loRtn As List(Of CST00200IssueClassComboDTO)

        Try
            loRtn = loCls.GetIssueClassCombo(key)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetIssueTypeCombo() As System.Collections.Generic.List(Of CST00200Back.CST00200IssueTypeComboDTO) Implements ICSM00520IssueService.GetIssueTypeCombo
        Dim loException As New R_Exception
        Dim loCls As New CST00200Cls
        Dim loRtn As List(Of CST00200IssueTypeComboDTO)

        Try
            loRtn = loCls.GetIssueTypeCombo()
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of CSM00520Back.CSM00520IssueKeyDTO)) Implements ICSM00520IssueService.Dummy

    End Sub

    Public Function GetAttributeCombo(companyId As String, appsCode As String, attributeGroup As String) As System.Collections.Generic.List(Of RLicenseBack.RCustDBAttributeComboDTO) Implements ICSM00520IssueService.GetAttributeCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBAttributeComboDTO)

        Try
            loRtn = loCls.GetAttributeCombo(companyId, appsCode, attributeGroup)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetAttributeGroupCombo(companyId As String, appsCode As String) As System.Collections.Generic.List(Of RLicenseBack.RCustDBAttributeGroupComboDTO) Implements ICSM00520IssueService.GetAttributeGroupCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBAttributeGroupComboDTO)

        Try
            loRtn = loCls.GetAttributeGroupCombo(companyId, appsCode)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
