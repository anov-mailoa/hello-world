﻿Imports R_Common
Imports CSM00520Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00520IssueStreamingService" in code, svc and config file together.
Public Class CSM00520IssueStreamingService
    Implements ICSM00520IssueStreamingService

    Public Function GetIssueList() As System.ServiceModel.Channels.Message Implements ICSM00520IssueStreamingService.GetIssueList
        Dim loException As New R_Exception
        Dim loCls As New CSM00520IssueCls
        Dim loRtnTemp As List(Of CSM00520IssueGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00520IssueKeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .CPROJECT_ID = R_Utility.R_GetStreamingContext("cProjectId")
                .CSESSION_ID = R_Utility.R_GetStreamingContext("cSessionId")
            End With

            loRtnTemp = loCls.GetIssueList(loTableKey)

            loRtn = R_StreamUtility(Of CSM00520IssueGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getIssueList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetItemList() As System.ServiceModel.Channels.Message Implements ICSM00520IssueStreamingService.GetItemList
        Dim loException As New R_Exception
        Dim loCls As New CSM00520IssueCls
        Dim loRtnTemp As List(Of CSM00520ItemListDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00520IssueKeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CATTRIBUTE_ID = R_Utility.R_GetStreamingContext("cAttributeId")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
            End With

            loRtnTemp = loCls.GetItemList(loTableKey)

            loRtn = R_StreamUtility(Of CSM00520ItemListDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getItemList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of CSM00520Back.CSM00520IssueGridDTO), poPar2 As System.Collections.Generic.List(Of CSM00520Back.CSM00520ItemListDTO)) Implements ICSM00520IssueStreamingService.Dummy

    End Sub
End Class
