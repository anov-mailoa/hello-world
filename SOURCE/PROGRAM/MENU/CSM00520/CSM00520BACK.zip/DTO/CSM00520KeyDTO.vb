﻿Public Class CSM00520KeyDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CVERSION As String
    Public Property CPROJECT_ID As String
    Public Property CSESSION_ID As String

    Public Property CUSER_ID As String
    Public Property CNOTE As String

    Public Property CINIT_SCHEDULE_TYPE As String

End Class
