﻿Imports R_BackEnd
Imports R_Common
Imports System.Data.Common
Imports ServerHelper.General

Public Class CSM00520IssueCls
    Inherits R_BusinessObject(Of CSM00520IssueDTO)

    Public Function GetIssueList(poKey As CSM00520IssueKeyDTO) As List(Of CSM00520IssueGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00520IssueGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CST_ISSUES (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery += "AND CPROJECT_ID = '{3}' "
                lcQuery += "AND CSESSION_ID = '{4}' "
                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CVERSION, _
                                        .CPROJECT_ID, _
                                        .CSESSION_ID)
            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00520IssueGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Deleting(poEntity As CSM00520IssueDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim lcException As String
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcRtn As String = "UNKNOWN_ERROR"

        Try
            loConn = loDb.GetConnection()

            With poEntity

                ' delete validation
                lcException = CRUDValidation("DELETE", poEntity)
                If Not String.IsNullOrEmpty(lcException) Then
                    Throw New Exception(lcException)
                End If

                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "CST_ISSUES "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery += "AND CPROJECT_ID = '{3}' "
                lcQuery += "AND CSESSION_ID = '{4}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{5}' "
                lcQuery += "AND CATTRIBUTE_ID = '{6}' "
                lcQuery += "AND CITEM_ID = '{7}' "
                lcQuery += "AND CISSUE_ID = '{8}' "
                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CVERSION, _
                                        .CPROJECT_ID, _
                                        .CSESSION_ID, _
                                        .CATTRIBUTE_GROUP, _
                                        .CATTRIBUTE_ID, _
                                        .CITEM_ID, _
                                        .CISSUE_ID)
                loDb.SqlExecNonQuery(lcQuery, loConn, False)

                ' delete attachment table
                lcQuery = "DELETE FROM "
                lcQuery += "CST_ISSUES_ATTACH "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery += "AND CPROJECT_ID = '{3}' "
                lcQuery += "AND CSESSION_ID = '{4}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{5}' "
                lcQuery += "AND CATTRIBUTE_ID = '{6}' "
                lcQuery += "AND CITEM_ID = '{7}' "
                lcQuery += "AND CISSUE_ID = '{8}' "
                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CVERSION, _
                                        .CPROJECT_ID, _
                                        .CSESSION_ID, _
                                        .CATTRIBUTE_GROUP, _
                                        .CATTRIBUTE_ID, _
                                        .CITEM_ID, _
                                        .CISSUE_ID)
                loDb.SqlExecNonQuery(lcQuery, loConn, False)

                ' delete project program if there is no more issues for the same program
                loCmd = loDb.GetCommand()
                lcQuery = "EXEC RSP_CSM00520_After_Issue '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', @CRET_MSG OUTPUT "
                lcQuery = String.Format(lcQuery, _
                                            .CCOMPANY_ID, _
                                            .CAPPS_CODE, _
                                            .CVERSION, _
                                            .CPROJECT_ID, _
                                            .CSESSION_ID, _
                                            .CATTRIBUTE_GROUP, _
                                            .CATTRIBUTE_ID, _
                                            .CITEM_ID, _
                                            .CISSUE_ID, _
                                            .CUSER_ID)

                loCmd.CommandText = lcQuery
                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@CRET_MSG"
                    .DbType = DbType.String
                    .Size = 50
                    .Direction = ParameterDirection.Output
                End With
                loCmd.Parameters.Add(loPar)
                loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd, True)

                If loCmd.Parameters("@CRET_MSG") Is Nothing Then
                    lcRtn = "UNKNOWN_ERROR"
                Else
                    lcRtn = loCmd.Parameters("@CRET_MSG").Value
                End If
                If Not lcRtn.Equals("OK") Then
                    loEx.Add(lcRtn, lcRtn)
                    Exit Try
                End If

            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As CSM00520IssueDTO) As CSM00520IssueDTO
        Dim lcQuery As String
        Dim loResult As CSM00520IssueDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CST_ISSUES (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery += "AND CPROJECT_ID = '{3}' "
                lcQuery += "AND CSESSION_ID = '{4}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{5}' "
                lcQuery += "AND CATTRIBUTE_ID = '{6}' "
                lcQuery += "AND CITEM_ID = '{7}' "
                lcQuery += "AND CISSUE_ID = '{8}' "
                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CVERSION, _
                                        .CPROJECT_ID, _
                                        .CSESSION_ID, _
                                        .CATTRIBUTE_GROUP, _
                                        .CATTRIBUTE_ID, _
                                        .CITEM_ID, _
                                        .CISSUE_ID)
                loResult = loDb.SqlExecObjectQuery(Of CSM00520IssueDTO)(lcQuery).FirstOrDefault
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As CSM00520IssueDTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim lcException As String
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcRtn As String = "UNKNOWN_ERROR"

        Try
            loConn = loDb.GetConnection()

            With poNewEntity
                If poCRUDMode = eCRUDMode.AddMode Then

                    lcQuery = "INSERT INTO CST_ISSUES ("
                    lcQuery += "CCOMPANY_ID, "
                    lcQuery += "CAPPS_CODE, "
                    lcQuery += "CVERSION, "
                    lcQuery += "CPROJECT_ID, "
                    lcQuery += "CSESSION_ID, "
                    lcQuery += "CATTRIBUTE_GROUP, "
                    lcQuery += "CATTRIBUTE_ID, "
                    lcQuery += "CITEM_ID, "
                    lcQuery += "CISSUE_ID, "
                    lcQuery += "CUSER_ID, "
                    lcQuery += "CISSUE_DATE, "
                    lcQuery += "CISSUE_TYPE, "
                    lcQuery += "CISSUE_CLASS, "
                    lcQuery += "CDESCRIPTION, "
                    lcQuery += "CSCHEDULE_ID, "
                    lcQuery += "CPREV_SCHEDULE_ID, "
                    lcQuery += "LOK, "
                    lcQuery += "CUPDATE_BY, "
                    lcQuery += "DUPDATE_DATE, "
                    lcQuery += "CCREATE_BY, "
                    lcQuery += "DCREATE_DATE) "
                    lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', CONVERT(char(8), GETDATE(), 112), '{10}', '{11}', '{12}', '{13}', '{14}', {15}, '{16}' , GETDATE(), '{17}', GETDATE()) "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CVERSION,
                    .CPROJECT_ID,
                    .CSESSION_ID,
                    .CATTRIBUTE_GROUP,
                    .CATTRIBUTE_ID,
                    .CITEM_ID,
                    .CISSUE_ID,
                    .CUSER_ID,
                    .CISSUE_TYPE,
                    .CISSUE_CLASS,
                    .CDESCRIPTION,
                    .CSCHEDULE_ID,
                    .CPREV_SCHEDULE_ID,
                    getBit(.LOK),
                    .CUPDATE_BY,
                    .CCREATE_BY)
                    loDb.SqlExecNonQuery(lcQuery, loConn, False)

                    loCmd = loDb.GetCommand()
                    lcQuery = "EXEC RSP_CSM00520_After_Issue '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', @CRET_MSG OUTPUT "
                    lcQuery = String.Format(lcQuery, _
                                                .CCOMPANY_ID, _
                                                .CAPPS_CODE, _
                                                .CVERSION, _
                                                .CPROJECT_ID, _
                                                .CSESSION_ID, _
                                                .CATTRIBUTE_GROUP, _
                                                .CATTRIBUTE_ID, _
                                                .CITEM_ID, _
                                                .CISSUE_ID, _
                                                .CUSER_ID)

                    loCmd.CommandText = lcQuery
                    loPar = loDb.GetParameter()
                    With loPar
                        .ParameterName = "@CRET_MSG"
                        .DbType = DbType.String
                        .Size = 50
                        .Direction = ParameterDirection.Output
                    End With
                    loCmd.Parameters.Add(loPar)
                    loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd, True)

                    If loCmd.Parameters("@CRET_MSG") Is Nothing Then
                        lcRtn = "UNKNOWN_ERROR"
                    Else
                        lcRtn = loCmd.Parameters("@CRET_MSG").Value
                    End If
                    If Not lcRtn.Equals("OK") Then
                        loEx.Add(lcRtn, lcRtn)
                        Exit Try
                    End If

                ElseIf poCRUDMode = eCRUDMode.EditMode Then

                    ' update validation
                    lcException = CRUDValidation("UPDATE", poNewEntity)
                    If Not String.IsNullOrEmpty(lcException) Then
                        Throw New Exception(lcException)
                    End If

                    lcQuery = "UPDATE CST_ISSUES "
                    lcQuery += "SET "
                    lcQuery += "CISSUE_TYPE = '{9}', "
                    lcQuery += "CDESCRIPTION = '{10}', "
                    lcQuery += "CISSUE_CLASS = '{11}', "
                    lcQuery += "LOK = {12}, "
                    lcQuery += "CUPDATE_BY = '{13}', "
                    lcQuery += "DUPDATE_DATE = GETDATE() "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CVERSION = '{2}' "
                    lcQuery += "AND CPROJECT_ID = '{3}' "
                    lcQuery += "AND CSESSION_ID = '{4}' "
                    lcQuery += "AND CATTRIBUTE_GROUP = '{5}' "
                    lcQuery += "AND CATTRIBUTE_ID = '{6}' "
                    lcQuery += "AND CITEM_ID = '{7}' "
                    lcQuery += "AND CISSUE_ID = '{8}' "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CVERSION,
                    .CPROJECT_ID,
                    .CSESSION_ID,
                    .CATTRIBUTE_GROUP,
                    .CATTRIBUTE_ID,
                    .CITEM_ID,
                    .CISSUE_ID,
                    .CISSUE_TYPE,
                    .CDESCRIPTION,
                    .CISSUE_CLASS,
                    getBit(.LOK),
                    .CUPDATE_BY)
                    loDb.SqlExecNonQuery(lcQuery, loConn, True)

                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Function CRUDValidation(pcCRUDAction As String, poEntity As CSM00520IssueDTO) As String
        Dim lcException As String
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loConn As DbConnection

        Try
            loConn = loDb.GetConnection()
            lcException = ""

            If Not String.IsNullOrWhiteSpace(poEntity.CSCHEDULE_ID) Then
                If String.Equals(pcCRUDAction, "DELETE") Then
                    ' jika sudah scheduled, tidak boleh delete lagi
                    lcException = "SCHEDULED"
                End If

                If String.Equals(pcCRUDAction, "UPDATE") Then

                    ' cek current status, jika sudah QCCI, tidak boleh update lagi
                    Dim lcStatus As String

                    lcStatus = ""
                    lcQuery = "SELECT CSTATUS "
                    lcQuery += "FROM "
                    lcQuery += "CST_PROJECT_PROGRAMS (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CVERSION = '{2}' "
                    lcQuery += "AND CPROJECT_ID = '{3}' "
                    lcQuery += "AND CSESSION_ID = '{4}' "
                    lcQuery += "AND CSCHEDULE_ID = '{5}' "
                    lcQuery += "AND CATTRIBUTE_GROUP = '{6}' "
                    lcQuery += "AND CATTRIBUTE_ID = '{7}' "
                    lcQuery += "AND CITEM_ID = '{8}' "
                    With poEntity
                        lcQuery = String.Format(lcQuery, _
                        .CCOMPANY_ID, _
                        .CAPPS_CODE, _
                        .CVERSION, _
                        .CPROJECT_ID, _
                        .CSESSION_ID, _
                        .CSCHEDULE_ID, _
                        .CATTRIBUTE_GROUP, _
                        .CATTRIBUTE_ID, _
                        .CITEM_ID)
                    End With
                    lcStatus = loDb.SqlExecObjectQuery(Of String)(lcQuery).FirstOrDefault
                    If Not (lcStatus.Trim.Equals("PLAN") Or lcStatus.Trim.Equals("QCCO")) Then
                        lcException = "STATUS_NO_EDIT"
                    End If
                End If
            Else
                If String.Equals(pcCRUDAction, "DELETE") Then
                    ' cek current schedule ID, pastikan 
                    Dim lcStatus As String

                    lcStatus = ""
                    lcQuery = "SELECT CSCHEDULE_ID "
                    lcQuery += "FROM "
                    lcQuery += "CST_ISSUES (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CVERSION = '{2}' "
                    lcQuery += "AND CPROJECT_ID = '{3}' "
                    lcQuery += "AND CSESSION_ID = '{4}' "
                    lcQuery += "AND CATTRIBUTE_GROUP = '{5}' "
                    lcQuery += "AND CATTRIBUTE_ID = '{6}' "
                    lcQuery += "AND CITEM_ID = '{7}' "
                    lcQuery += "AND CISSUE_ID = '{8}' "
                    With poEntity
                        lcQuery = String.Format(lcQuery, _
                        .CCOMPANY_ID, _
                        .CAPPS_CODE, _
                        .CVERSION, _
                        .CPROJECT_ID, _
                        .CSESSION_ID, _
                        .CATTRIBUTE_GROUP, _
                        .CATTRIBUTE_ID, _
                        .CITEM_ID, _
                        .CISSUE_ID)
                    End With
                    lcStatus = loDb.SqlExecObjectQuery(Of String)(lcQuery).FirstOrDefault
                    If Not String.IsNullOrWhiteSpace(lcStatus) Then
                        lcException = "SCHEDULED"
                    End If
                End If
            End If

        Catch ex As Exception
            lcException = ex.Message
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        Return lcException
    End Function

    Public Function GetItemList(poKey As CSM00520IssueKeyDTO) As List(Of CSM00520ItemListDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00520ItemListDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "EXEC RSP_Get_Item_List '{0}', '{1}', '{2}', '{3}', '{4}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CVERSION)
            End With

            loResult = loDb.SqlExecObjectQuery(Of CSM00520ItemListDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult

    End Function

End Class
