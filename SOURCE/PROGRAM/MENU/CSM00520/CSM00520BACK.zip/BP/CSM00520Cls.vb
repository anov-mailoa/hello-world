﻿Imports R_BackEnd
Imports R_Common
Imports System.Data.Common
Imports CSM00500Back

Public Class CSM00520Cls
    Inherits R_BusinessObject(Of CSM00520DTO)

    Public Function GetComplaintSessionList(poKey As CSM00520KeyDTO) As List(Of CSM00520GridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00520GridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "SELECT A.* "
                lcQuery += "FROM "
                lcQuery += "CSM_PROJECT_SESSIONS A (NOLOCK) "
                lcQuery += "WHERE A.CCOMPANY_ID = '{0}' "
                lcQuery += "AND A.CAPPS_CODE = '{1}' "
                lcQuery += "AND A.CVERSION = '{2}' "
                lcQuery += "AND A.CPROJECT_ID = '{3}' "
                lcQuery += "AND A.CINIT_SCHEDULE_TYPE = '3' "
                lcQuery += "ORDER BY A.CSESSION_ID DESC "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID)

            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00520GridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Deleting(poEntity As CSM00520DTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loResult As List(Of CSM00500SessionValidationDTO)

        Try
            loConn = loDb.GetConnection()

            With poEntity

                ' Validation (new, on-progress and no unfinished sequence, etc)
                lcQuery = "EXEC RSP_Session_Validation '{0}', '{1}', '{2}', '{3}', '{4}', '', '', '', '', 'DELETE' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID, .CSESSION_ID)

                loResult = loDb.SqlExecObjectQuery(Of CSM00500SessionValidationDTO)(lcQuery, loConn, False)
                If loResult.Count > 0 Then
                    For Each result As CSM00500SessionValidationDTO In loResult
                        loEx.Add(result.CMESSAGE_CODE, result.CDESCRIPTION)
                    Next
                    Exit Try
                End If

                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "CSM_PROJECT_SESSIONS "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery += "AND CPROJECT_ID = '{3}' "
                lcQuery += "AND CSESSION_ID = '{4}' "
                lcQuery = String.Format(lcQuery, _
                            .CCOMPANY_ID, _
                            .CAPPS_CODE, _
                            .CVERSION, _
                            .CPROJECT_ID, _
                            .CSESSION_ID)
                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As CSM00520DTO) As CSM00520DTO
        Dim lcQuery As String
        Dim loResult As CSM00520DTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CSM_PROJECT_SESSIONS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery += "AND CPROJECT_ID = '{3}' "
                lcQuery += "AND CSESSION_ID = '{4}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID, .CSESSION_ID)

                loResult = loDb.SqlExecObjectQuery(Of CSM00520DTO)(lcQuery).FirstOrDefault

            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As CSM00520DTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As CSM00500SessionGridDTO
        Dim lcSession_ID As String
        Dim lcSession_No As String

        Try
            loConn = loDb.GetConnection()

            With poNewEntity
                If poCRUDMode = eCRUDMode.AddMode Then
                    lcSession_ID = ""
                    ' Get last session
                    lcQuery = "SELECT TOP 1 * "
                    lcQuery += "FROM "
                    lcQuery += "CSM_PROJECT_SESSIONS (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CVERSION = '{2}' "
                    lcQuery += "AND CPROJECT_ID = '{3}' "
                    lcQuery += "ORDER BY CSESSION_ID DESC "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID)

                    loResult = loDb.SqlExecObjectQuery(Of CSM00500SessionGridDTO)(lcQuery, loConn, False).FirstOrDefault
                    If loResult IsNot Nothing Then
                        lcSession_ID = loResult.CSESSION_ID
                        lcSession_No = Right(lcSession_ID, 12)
                        lcSession_ID = Today.ToString("yyyyMMdd") & Right("000000000000" & CInt(lcSession_No + 1).ToString.Trim, 12)
                    Else
                        lcSession_ID = Today.ToString("yyyyMMdd") & "000000000001"
                    End If
                    .CSESSION_ID = lcSession_ID

                    ' Save session data
                    lcQuery = "INSERT INTO CSM_PROJECT_SESSIONS ("
                    lcQuery += "CCOMPANY_ID, "
                    lcQuery += "CAPPS_CODE, "
                    lcQuery += "CVERSION, "
                    lcQuery += "CPROJECT_ID, "
                    lcQuery += "CSESSION_ID, "
                    lcQuery += "CINIT_SCHEDULE_TYPE, "
                    lcQuery += "DSESSION_DATE, "
                    lcQuery += "CSTATUS, "
                    lcQuery += "CNOTE, "
                    lcQuery += "CCARE_NO, "
                    lcQuery += "CUPDATE_BY, "
                    lcQuery += "DUPDATE_DATE, "
                    lcQuery += "CCREATE_BY, "
                    lcQuery += "DCREATE_DATE) "
                    lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', GETDATE(), 'NEW', '{6}', '{7}', '{8}', GETDATE(), '{8}', GETDATE()) "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CVERSION,
                    .CPROJECT_ID,
                    lcSession_ID,
                    .CINIT_SCHEDULE_TYPE,
                    .CNOTE,
                    .CCARE_NO,
                    .CUPDATE_BY)
                Else
                    lcQuery = "UPDATE CSM_PROJECT_SESSIONS "
                    lcQuery += "SET "
                    lcQuery += "CNOTE = '{5}', "
                    lcQuery += "CUPDATE_BY = '{6}', "
                    lcQuery += "DUPDATE_DATE = GETDATE() "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CVERSION = '{2}' "
                    lcQuery += "AND CPROJECT_ID = '{3}' "
                    lcQuery += "AND CSESSION_ID = '{4}' "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CVERSION,
                    .CPROJECT_ID,
                    .CSESSION_ID,
                    .CNOTE,
                    .CUPDATE_BY)

                End If
            End With
            loDb.SqlExecNonQuery(lcQuery, loConn, True)
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
End Class
