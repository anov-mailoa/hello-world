﻿Imports CSM00520FrontResources
Imports R_Common
Imports CSM00520Front.CSM00520IssueServiceRef
Imports CSM00520Front.CSM00520IssueStreamingServiceRef
Imports ClientHelper
Imports R_FrontEnd
Imports System.ServiceModel.Channels
Imports RCustDBFrontHelper
Imports CST00200Front

Public Class CSM00520Issues

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSM00520Service/CSM00520IssueService.svc"
    Dim C_ServiceNameStream As String = "CSM00520Service/CSM00520IssueStreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _CVERSION As String
    Dim _CPROJECTID As String
    Dim _CSESSIONID As String
    Dim _CSCHEDULEID As String
    Dim _CUSER_NAME As String
    Dim _CFUNCTIONID As String
    Dim _LINIT As Boolean
    Dim _CATTRIBUTEGROUP As String
    Dim _CATTRIBUTEID As String
    Dim _CITEMID As String
    Dim _CACTION As String
    Dim _CISSUE_ID As String
    Dim _OISSUE_CLIPBOARD As CSM00520IssueGridDTO

#End Region

#Region " SUBs and FUNCTIONs "

    Private Sub RefreshGrids()
        Dim loGridKey As New CSM00520IssueKeyDTO

        If _LINIT Then
            If Not (String.IsNullOrEmpty(_CAPPSCODE) Or String.IsNullOrEmpty(_CVERSION) Or String.IsNullOrEmpty(_CPROJECTID)) Then
                With loGridKey
                    .CCOMPANY_ID = _CCOMPID
                    .CAPPS_CODE = _CAPPSCODE
                    .CVERSION = _CVERSION
                    .CPROJECT_ID = _CPROJECTID
                    .CSESSION_ID = _CSESSIONID
                End With
                With gvIssue
                    .R_RefreshGrid(loGridKey)
                End With
            End If
        End If
    End Sub

    Private Sub ComboManager(pcCode As String, pcValue As String)
        Dim loSvc As CSM00520IssueServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00520IssueService, CSM00520IssueServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)

        ' Refresh Combo
        '_LDONE_COMBO_SETTING = False
        Select Case pcCode
            Case "_CISSUE_CLASS"
                Dim loIssueClassCombo As New List(Of CST00200IssueClassComboDTO)
                loIssueClassCombo = loSvc.GetIssueClassCombo(New CST00200KeyDTO With {.CCOMPANY_ID = _CCOMPID,
                                                                                    .CAPPS_CODE = _CAPPSCODE})
                bsIssueClass.DataSource = loIssueClassCombo
                Dim loIssueTypeCombo As New List(Of CST00200IssueTypeComboDTO)
                loIssueTypeCombo = loSvc.GetIssueTypeCombo()
                bsIssueType.DataSource = loIssueTypeCombo
        End Select
        loSvc.Close()

    End Sub

#End Region

#Region " FORM Events "

    Private Sub CSM00520Issues_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Try
            _LINIT = False
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            With CType(poParameter, CSM00520IssueParamDTO)
                _CAPPSCODE = .CAPPS_CODE
                _CVERSION = .CVERSION
                _CPROJECTID = .CPROJECT_ID
                _CSESSIONID = .CSESSION_ID
                txtApplication.Text = .CAPPS_NAME
                txtVersion.Text = IIf(.LCUSTOM, .CCUSTOMER_NAME, .CCODE_NAME)
                txtProject.Text = .CPROJECT_NAME
                txtSession.Text = .CSESSION_ID
                txtCARENo.Text = .CCARE_NO
                lblVersion.Visible = Not .LCUSTOM
                lblCustomer.Visible = .LCUSTOM
                lblCustom.Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), IIf(.LCUSTOM, "rdbCustom", "rdbStandard"))
            End With
            _CFUNCTIONID = "QC"
            _LINIT = True
            _OISSUE_CLIPBOARD = New CSM00520IssueGridDTO
            ComboManager("_CISSUE_CLASS", Nothing)
            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub CSM00520Issues_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " ISSUE Gridview "

    Private Sub gvIssue_CellValueChanged(sender As Object, e As Telerik.WinControls.UI.GridViewCellEventArgs) Handles gvIssue.CellValueChanged
        If e.Column.Name.Equals("_CISSUE_CLASS") Then
            e.Row.Cells("_CISSUE_TYPE").Value = CType(bsIssueClass.Current, CST00200IssueClassComboDTO).CISSUE_TYPE.ToString
        End If
    End Sub

    Private Sub gvIssue_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvIssue.DataBindingComplete
        With gvIssue
            '.BestFitColumns()
            .Columns("_CDESCRIPTION").Width = 360
        End With
    End Sub

    Private Sub gvIssue_R_Before_Open_LookUpForm(sender As Object, e As Telerik.WinControls.UI.EditorRequiredEventArgs, ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles gvIssue.R_Before_Open_LookUpForm
        If gvIssue.CurrentColumn.Name.Trim.Equals("_CDESCRIPTION") Then
            poTargetForm = New CST00200Description
            poParameter = New CST00200ServiceRef.CST00200DTO With {._CDESCRIPTION = gvIssue.CurrentRow.Cells("_CDESCRIPTION").Value}
        ElseIf gvIssue.CurrentColumn.Name.Trim.Equals("_CITEM_ID") Then
            poTargetForm = New CSM00520ItemList
            poParameter = New CSM00520IssueKeyDTO With {.CCOMPANY_ID = _CCOMPID, _
                                                        .CAPPS_CODE = _CAPPSCODE, _
                                                        .CATTRIBUTE_GROUP = _CATTRIBUTEGROUP, _
                                                        .CATTRIBUTE_ID = _CATTRIBUTEID, _
                                                        .CVERSION = _CVERSION}
        End If
    End Sub

    Private Sub gvIssue_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvIssue.R_Display
        _CISSUE_ID = CType(bsGvIssue.Current, CSM00520IssueDTO)._CISSUE_ID
    End Sub

    Private Sub gvIssue_R_Return_LookUp(sender As Object, e As Telerik.WinControls.UI.EditorRequiredEventArgs, poReturnObject As Object) Handles gvIssue.R_Return_LookUp
        If gvIssue.CurrentColumn.Name.Trim.Equals("_CDESCRIPTION") Then
            e.Editor.Value = poReturnObject._CDESCRIPTION
        ElseIf gvIssue.CurrentColumn.Name.Trim.Equals("_CITEM_ID") Then
            gvIssue.CurrentRow.Cells("_CITEM_ID").Value = poReturnObject.CITEM_ID
            gvIssue.CurrentRow.Cells("_CATTRIBUTE_GROUP").Value = poReturnObject.CATTRIBUTE_GROUP
            _CATTRIBUTEGROUP = poReturnObject.CATTRIBUTE_GROUP
            gvIssue.CurrentRow.Cells("_CATTRIBUTE_ID").Value = poReturnObject.CATTRIBUTE_ID
            _CATTRIBUTEID = poReturnObject.CATTRIBUTE_ID
        End If
    End Sub

    Private Sub gvIssue_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvIssue.R_Saving
        With CType(poEntity, CSM00520IssueDTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = _CAPPSCODE
            ._CVERSION = _CVERSION
            ._CPROJECT_ID = _CPROJECTID
            ._CSESSION_ID = _CSESSIONID
            ._CATTRIBUTE_GROUP = _CATTRIBUTEGROUP
            ._CATTRIBUTE_ID = _CATTRIBUTEID
            ._CUSER_ID = _CUSERID
            ._CPREV_SCHEDULE_ID = _CSCHEDULEID
            ._CCREATE_BY = _CUSERID
            ._CUPDATE_BY = _CUSERID
        End With
    End Sub

    Private Sub gvIssue_R_ServiceDelete(poEntity As Object) Handles gvIssue.R_ServiceDelete
        Dim loService As CSM00520IssueServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00520IssueService, CSM00520IssueServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String

        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvIssue_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvIssue.R_ServiceGetListRecord
        Dim loServiceStream As CSM00520IssueStreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00520IssueStreamingService, CSM00520IssueStreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00520IssueGridDTO)
        Dim loListEntity As New List(Of CSM00520IssueDTO)

        Try
            With CType(poEntity, CSM00520IssueKeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
                R_Utility.R_SetStreamingContext("cProjectId", .CPROJECT_ID)
                R_Utility.R_SetStreamingContext("cSessionId", .CSESSION_ID)
            End With

            loRtn = loServiceStream.GetIssueList()
            loStreaming = R_StreamUtility(Of CSM00520IssueGridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00520IssueGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New CSM00520IssueDTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                           ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                           ._CVERSION = loDto.CVERSION,
                                                           ._CPROJECT_ID = loDto.CPROJECT_ID,
                                                           ._CSESSION_ID = loDto.CSESSION_ID,
                                                           ._CATTRIBUTE_GROUP = loDto.CATTRIBUTE_GROUP,
                                                           ._CATTRIBUTE_ID = loDto.CATTRIBUTE_ID,
                                                           ._CITEM_ID = loDto.CITEM_ID,
                                                           ._CISSUE_ID = loDto.CISSUE_ID,
                                                           ._CUSER_ID = loDto.CUSER_ID,
                                                           ._DISSUE_DATE = General.StrToDate(loDto.CISSUE_DATE),
                                                           ._CISSUE_CLASS = loDto.CISSUE_CLASS,
                                                           ._CISSUE_TYPE = loDto.CISSUE_TYPE,
                                                           ._CDESCRIPTION = loDto.CDESCRIPTION,
                                                           ._CSCHEDULE_ID = loDto.CSCHEDULE_ID,
                                                           ._CPREV_SCHEDULE_ID = loDto.CPREV_SCHEDULE_ID,
                                                           ._LOK = loDto.LOK})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvIssue_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvIssue.R_ServiceGetRecord
        Dim loService As CSM00520IssueServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00520IssueService, CSM00520IssueServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New CSM00520IssueDTO With {._CCOMPANY_ID = _CCOMPID,
                                                                             ._CAPPS_CODE = _CAPPSCODE,
                                                                             ._CVERSION = _CVERSION,
                                                                             ._CPROJECT_ID = _CPROJECTID,
                                                                             ._CSESSION_ID = _CSESSIONID,
                                                                             ._CATTRIBUTE_GROUP = _CATTRIBUTEGROUP,
                                                                             ._CATTRIBUTE_ID = _CATTRIBUTEID,
                                                                             ._CITEM_ID = _CITEMID,
                                                                             ._CISSUE_ID = CType(bsGvIssue.Current, CSM00520IssueDTO)._CISSUE_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvIssue_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvIssue.R_ServiceSave
        Dim loService As CSM00520IssueServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00520IssueService, CSM00520IssueServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
            poEntityResult._DISSUE_DATE = General.StrToDate(poEntityResult._CISSUE_DATE)
        Catch ex As Exception
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvIssue_R_SetEditGridColumn(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, poGridColumnCollection As Telerik.WinControls.UI.GridViewColumnCollection) Handles gvIssue.R_SetEditGridColumn
        Dim llEnableIssueType As Boolean

        llEnableIssueType = (CType(poEntity, CSM00520IssueDTO)._CSCHEDULE_ID = "")
        CType(poGridColumnCollection("_CISSUE_CLASS"), R_GridViewComboBoxColumn).ReadOnly = Not llEnableIssueType
        CType(poGridColumnCollection("_CISSUE_TYPE"), R_GridViewComboBoxColumn).ReadOnly = Not llEnableIssueType

    End Sub

    Private Sub gvIssue_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvIssue.R_Validation
        Dim loEx As New R_Exception()

        Try
            With poGridCellCollection
                If String.IsNullOrWhiteSpace(.Item("_CISSUE_ID").Value) Then
                    loEx.Add("CSM00520_02", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00520_02"))
                    plCancel = True
                End If
                If String.IsNullOrWhiteSpace(.Item("_CISSUE_TYPE").Value) Then
                    loEx.Add("CSM00520_03", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00520_03"))
                    plCancel = True
                End If
                If String.IsNullOrWhiteSpace(.Item("_CDESCRIPTION").Value) Then
                    loEx.Add("CSM00520_04", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00520_04"))
                    plCancel = True
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " ISSUE CLASS button "

    Private Sub btnIssueClass_R_After_Open_Form(poPopUpResult As System.Windows.Forms.DialogResult, poPopUpEntityResult As Object) Handles btnIssueClass.R_After_Open_Form
        ComboManager("_CISSUE_CLASS", Nothing)
    End Sub

    Private Sub btnIssueClass_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnIssueClass.R_Before_Open_Form
        poTargetForm = New CST00200IssueClass
        With CType(poTargetForm, CST00200IssueClass)
            .Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "btnIssueClass")
            .CAPPS_NAME = txtApplication.Text
        End With

        poParameter = New CST00200KeyDTO With {.CCOMPANY_ID = _CCOMPID, .CAPPS_CODE = _CAPPSCODE}
    End Sub

#End Region

#Region " ATTACHMENT button "

    Private Sub btnAttachment_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnAttachment.R_Before_Open_Form
        poTargetForm = New CST00200Attach
        With CType(poTargetForm, CST00200Attach)
            .Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "btnAttachment")
        End With

        poParameter = New CST00200KeyDTO
        With poParameter
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = _CAPPSCODE
            .CVERSION = _CVERSION
            .CPROJECT_ID = _CPROJECTID
            .CSESSION_ID = _CSESSIONID
            .CFUNCTION_ID = _CFUNCTIONID
            .CATTRIBUTE_GROUP = _CATTRIBUTEGROUP
            .CATTRIBUTE_ID = _CATTRIBUTEID
            .CITEM_ID = _CITEMID
            .CISSUE_ID = _CISSUE_ID
        End With
    End Sub

#End Region

#Region " COPY & PASTE ISSUE button "

    Private Sub btnCopy_Click(sender As System.Object, e As System.EventArgs) Handles btnCopy.Click
        If gvIssue.CurrentRow IsNot Nothing Then
            With gvIssue.CurrentRow
                _OISSUE_CLIPBOARD.CISSUE_ID = .Cells("_CISSUE_ID").Value
                _OISSUE_CLIPBOARD.CISSUE_CLASS = .Cells("_CISSUE_CLASS").Value
                _OISSUE_CLIPBOARD.CDESCRIPTION = .Cells("_CDESCRIPTION").Value
            End With
        End If
    End Sub

    Private Sub btnPaste_Click(sender As System.Object, e As System.EventArgs) Handles btnPaste.Click
        If gvIssue.IsInEditMode Then
            With gvIssue.CurrentRow
                .Cells("_CISSUE_ID").Value = _OISSUE_CLIPBOARD.CISSUE_ID
                .Cells("_CISSUE_CLASS").Value = _OISSUE_CLIPBOARD.CISSUE_CLASS
                .Cells("_CDESCRIPTION").Value = _OISSUE_CLIPBOARD.CDESCRIPTION
            End With
            gvIssue.EndEdit()
        End If
    End Sub

#End Region

#Region " REFRESH button "

    Private Sub btnRefresh_Click(sender As Object, e As System.EventArgs) Handles btnRefresh.Click
        RefreshGrids()
    End Sub

#End Region

End Class
