﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSM00520
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn5 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn6 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn7 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn6 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn7 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn8 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn8 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtCustomerName = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lupCustomer = New R_FrontEnd.R_LookUp(Me.components)
        Me.txtCustomerCode = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblCustomer = New R_FrontEnd.R_RadLabel(Me.components)
        Me.rdbCustom = New R_FrontEnd.R_RadRadioButton(Me.components)
        Me.rdbStandard = New R_FrontEnd.R_RadRadioButton(Me.components)
        Me.lblProject = New R_FrontEnd.R_RadLabel(Me.components)
        Me.cboProject = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsProject = New System.Windows.Forms.BindingSource(Me.components)
        Me.cboVersion = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsVersion = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridSession = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblVersion = New R_FrontEnd.R_RadLabel(Me.components)
        Me.cboApplication = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.gvSession = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvSession = New System.Windows.Forms.BindingSource(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnCloseSession = New R_FrontEnd.R_RadButton(Me.components)
        Me.btnStartSession = New R_FrontEnd.R_RadButton(Me.components)
        Me.preIssue = New R_FrontEnd.R_PredefinedDock(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.txtCustomerName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lupCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCustomerCode, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.rdbCustom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.rdbStandard, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvSession.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvSession, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.btnCloseSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnStartSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.gvSession, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 0, 2)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 120.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.txtCustomerName)
        Me.Panel1.Controls.Add(Me.lupCustomer)
        Me.Panel1.Controls.Add(Me.txtCustomerCode)
        Me.Panel1.Controls.Add(Me.lblCustomer)
        Me.Panel1.Controls.Add(Me.rdbCustom)
        Me.Panel1.Controls.Add(Me.rdbStandard)
        Me.Panel1.Controls.Add(Me.lblProject)
        Me.Panel1.Controls.Add(Me.cboProject)
        Me.Panel1.Controls.Add(Me.cboVersion)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Controls.Add(Me.lblVersion)
        Me.Panel1.Controls.Add(Me.cboApplication)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 114)
        Me.Panel1.TabIndex = 0
        '
        'txtCustomerName
        '
        Me.txtCustomerName.Enabled = False
        Me.txtCustomerName.Location = New System.Drawing.Point(257, 59)
        Me.txtCustomerName.Name = "txtCustomerName"
        Me.txtCustomerName.R_ConductorGridSource = Nothing
        Me.txtCustomerName.R_ConductorSource = Nothing
        Me.txtCustomerName.R_UDT = Nothing
        Me.txtCustomerName.Size = New System.Drawing.Size(258, 20)
        Me.txtCustomerName.TabIndex = 45
        '
        'lupCustomer
        '
        Me.lupCustomer.Location = New System.Drawing.Point(221, 59)
        Me.lupCustomer.Name = "lupCustomer"
        Me.lupCustomer.R_ConductorGridSource = Nothing
        Me.lupCustomer.R_ConductorSource = Nothing
        Me.lupCustomer.R_DescriptionId = Nothing
        Me.lupCustomer.R_Field_Description = ""
        Me.lupCustomer.R_Field_Value = ""
        Me.lupCustomer.R_ResourceId = Nothing
        Me.lupCustomer.R_TextBox_Description = Nothing
        Me.lupCustomer.R_TextBox_Value = Me.txtCustomerCode
        Me.lupCustomer.R_Title = Nothing
        Me.lupCustomer.Size = New System.Drawing.Size(30, 20)
        Me.lupCustomer.TabIndex = 28
        Me.lupCustomer.Text = "..."
        '
        'txtCustomerCode
        '
        Me.txtCustomerCode.Location = New System.Drawing.Point(115, 59)
        Me.txtCustomerCode.Name = "txtCustomerCode"
        Me.txtCustomerCode.R_ConductorGridSource = Nothing
        Me.txtCustomerCode.R_ConductorSource = Nothing
        Me.txtCustomerCode.R_UDT = Nothing
        Me.txtCustomerCode.Size = New System.Drawing.Size(100, 20)
        Me.txtCustomerCode.TabIndex = 44
        '
        'lblCustomer
        '
        Me.lblCustomer.AutoSize = False
        Me.lblCustomer.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustomer.Location = New System.Drawing.Point(9, 59)
        Me.lblCustomer.Name = "lblCustomer"
        Me.lblCustomer.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustomer.R_ResourceId = "lblCustomer"
        Me.lblCustomer.Size = New System.Drawing.Size(100, 18)
        Me.lblCustomer.TabIndex = 43
        Me.lblCustomer.Text = "Application..."
        '
        'rdbCustom
        '
        Me.rdbCustom.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.rdbCustom.Location = New System.Drawing.Point(247, 35)
        Me.rdbCustom.Name = "rdbCustom"
        Me.rdbCustom.R_ConductorGridSource = Nothing
        Me.rdbCustom.R_ConductorSource = Nothing
        Me.rdbCustom.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.rdbCustom.R_ResourceId = "rdbCustom"
        Me.rdbCustom.Size = New System.Drawing.Size(122, 18)
        Me.rdbCustom.TabIndex = 42
        Me.rdbCustom.TabStop = False
        Me.rdbCustom.Text = "R_RadRadioButton2"
        '
        'rdbStandard
        '
        Me.rdbStandard.CheckState = System.Windows.Forms.CheckState.Checked
        Me.rdbStandard.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.rdbStandard.Location = New System.Drawing.Point(116, 35)
        Me.rdbStandard.Name = "rdbStandard"
        Me.rdbStandard.R_ConductorGridSource = Nothing
        Me.rdbStandard.R_ConductorSource = Nothing
        Me.rdbStandard.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.rdbStandard.R_ResourceId = "rdbStandard"
        Me.rdbStandard.Size = New System.Drawing.Size(122, 18)
        Me.rdbStandard.TabIndex = 41
        Me.rdbStandard.Text = "R_RadRadioButton1"
        Me.rdbStandard.ToggleState = Telerik.WinControls.Enumerations.ToggleState.[On]
        '
        'lblProject
        '
        Me.lblProject.AutoSize = False
        Me.lblProject.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblProject.Location = New System.Drawing.Point(9, 85)
        Me.lblProject.Name = "lblProject"
        Me.lblProject.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblProject.R_ResourceId = "lblProject"
        Me.lblProject.Size = New System.Drawing.Size(100, 18)
        Me.lblProject.TabIndex = 39
        Me.lblProject.Text = "Application..."
        '
        'cboProject
        '
        Me.cboProject.DataSource = Me.bsProject
        Me.cboProject.DisplayMember = "CPROJECT_NAME"
        Me.cboProject.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboProject.Location = New System.Drawing.Point(115, 85)
        Me.cboProject.Name = "cboProject"
        Me.cboProject.R_ConductorGridSource = Me.conGridSession
        Me.cboProject.R_ConductorSource = Nothing
        Me.cboProject.R_EnableOTHER = True
        Me.cboProject.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboProject.Size = New System.Drawing.Size(400, 20)
        Me.cboProject.TabIndex = 40
        Me.cboProject.Text = "R_RadDropDownList1"
        Me.cboProject.ValueMember = "CPROJECT_ID"
        '
        'cboVersion
        '
        Me.cboVersion.DataSource = Me.bsVersion
        Me.cboVersion.DisplayMember = "CCODE_NAME"
        Me.cboVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboVersion.Location = New System.Drawing.Point(115, 59)
        Me.cboVersion.Name = "cboVersion"
        Me.cboVersion.R_ConductorGridSource = Me.conGridSession
        Me.cboVersion.R_ConductorSource = Nothing
        Me.cboVersion.R_EnableOTHER = True
        Me.cboVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboVersion.Size = New System.Drawing.Size(147, 20)
        Me.cboVersion.TabIndex = 24
        Me.cboVersion.Text = "R_RadDropDownList1"
        Me.cboVersion.ValueMember = "CVERSION"
        '
        'bsVersion
        '
        Me.bsVersion.DataSource = GetType(CSM00520Front.CSM00520ServiceRef.RCustDBVersionComboDTO)
        '
        'conGridSession
        '
        Me.conGridSession.R_ConductorParent = Nothing
        Me.conGridSession.R_IsHeader = True
        Me.conGridSession.R_RadGroupBox = Nothing
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 21
        Me.lblApplication.Text = "Application..."
        '
        'lblVersion
        '
        Me.lblVersion.AutoSize = False
        Me.lblVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblVersion.Location = New System.Drawing.Point(9, 59)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblVersion.R_ResourceId = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(100, 18)
        Me.lblVersion.TabIndex = 23
        Me.lblVersion.Text = "Application..."
        '
        'cboApplication
        '
        Me.cboApplication.DataSource = Me.bsApps
        Me.cboApplication.DisplayMember = "CAPPS_NAME"
        Me.cboApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboApplication.Location = New System.Drawing.Point(115, 9)
        Me.cboApplication.Name = "cboApplication"
        Me.cboApplication.R_ConductorGridSource = Me.conGridSession
        Me.cboApplication.R_ConductorSource = Nothing
        Me.cboApplication.R_EnableOTHER = True
        Me.cboApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboApplication.Size = New System.Drawing.Size(400, 20)
        Me.cboApplication.TabIndex = 22
        Me.cboApplication.Text = "R_RadDropDownList1"
        Me.cboApplication.ValueMember = "CAPPS_CODE"
        '
        'bsApps
        '
        Me.bsApps.DataSource = GetType(CSM00520Front.CSM00520ServiceRef.RLicenseAppComboDTO)
        '
        'gvSession
        '
        Me.gvSession.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvSession.EnableFastScrolling = True
        Me.gvSession.Location = New System.Drawing.Point(3, 123)
        '
        '
        '
        Me.gvSession.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn5.FieldName = "_CSESSION_ID"
        R_GridViewTextBoxColumn5.HeaderText = "_CSESSION_ID"
        R_GridViewTextBoxColumn5.MaxLength = 20
        R_GridViewTextBoxColumn5.Name = "_CSESSION_ID"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CSESSION_ID"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 93
        R_GridViewDateTimeColumn5.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn5.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn5.FieldName = "_DSESSION_DATE"
        R_GridViewDateTimeColumn5.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn5.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn5.HeaderText = "_DSESSION_DATE"
        R_GridViewDateTimeColumn5.Name = "_DSESSION_DATE"
        R_GridViewDateTimeColumn5.R_ResourceId = "_DSESSION_DATE"
        R_GridViewDateTimeColumn5.Width = 110
        R_GridViewDateTimeColumn6.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn6.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn6.FieldName = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn6.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn6.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn6.HeaderText = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn6.Name = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn6.R_ResourceId = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn6.Width = 131
        R_GridViewDateTimeColumn7.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn7.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn7.FieldName = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn7.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn7.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn7.HeaderText = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn7.Name = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn7.R_ResourceId = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn7.Width = 121
        R_GridViewTextBoxColumn6.FieldName = "_CSTATUS"
        R_GridViewTextBoxColumn6.HeaderText = "_CSTATUS"
        R_GridViewTextBoxColumn6.Name = "_CSTATUS"
        R_GridViewTextBoxColumn6.R_ResourceId = "_CSTATUS"
        R_GridViewTextBoxColumn6.R_UDT = Nothing
        R_GridViewTextBoxColumn6.Width = 73
        R_GridViewTextBoxColumn7.FieldName = "_CCARE_NO"
        R_GridViewTextBoxColumn7.HeaderText = "_CCARE_NO"
        R_GridViewTextBoxColumn7.Name = "_CCARE_NO"
        R_GridViewTextBoxColumn7.R_EnableADD = True
        R_GridViewTextBoxColumn7.R_ResourceId = "_CCARE_NO"
        R_GridViewTextBoxColumn7.R_UDT = Nothing
        R_GridViewTextBoxColumn7.Width = 82
        R_GridViewTextBoxColumn8.FieldName = "_CNOTE"
        R_GridViewTextBoxColumn8.HeaderText = "_CNOTE"
        R_GridViewTextBoxColumn8.Name = "_CNOTE"
        R_GridViewTextBoxColumn8.R_EnableADD = True
        R_GridViewTextBoxColumn8.R_EnableEDIT = True
        R_GridViewTextBoxColumn8.R_ResourceId = "_CNOTE"
        R_GridViewTextBoxColumn8.R_UDT = Nothing
        R_GridViewTextBoxColumn8.Width = 63
        R_GridViewDateTimeColumn8.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn8.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn8.FieldName = "_DCLOSE_DATE"
        R_GridViewDateTimeColumn8.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn8.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn8.HeaderText = "_DCLOSE_DATE"
        R_GridViewDateTimeColumn8.Name = "_DCLOSE_DATE"
        R_GridViewDateTimeColumn8.R_ResourceId = "_DCLOSE_DATE"
        R_GridViewDateTimeColumn8.Width = 99
        Me.gvSession.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn5, R_GridViewDateTimeColumn5, R_GridViewDateTimeColumn6, R_GridViewDateTimeColumn7, R_GridViewTextBoxColumn6, R_GridViewTextBoxColumn7, R_GridViewTextBoxColumn8, R_GridViewDateTimeColumn8})
        Me.gvSession.MasterTemplate.DataSource = Me.bsGvSession
        Me.gvSession.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvSession.MasterTemplate.EnableFiltering = True
        Me.gvSession.MasterTemplate.EnableGrouping = False
        Me.gvSession.MasterTemplate.ShowFilteringRow = False
        Me.gvSession.MasterTemplate.ShowGroupedColumns = True
        Me.gvSession.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvSession.Name = "gvSession"
        Me.gvSession.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvSession.R_ConductorGridSource = Me.conGridSession
        Me.gvSession.R_ConductorSource = Nothing
        Me.gvSession.R_DataAdded = False
        Me.gvSession.R_NewRowText = Nothing
        Me.gvSession.ShowHeaderCellButtons = True
        Me.gvSession.Size = New System.Drawing.Size(1271, 417)
        Me.gvSession.TabIndex = 2
        Me.gvSession.Text = "R_RadGridView1"
        '
        'bsGvSession
        '
        Me.bsGvSession.DataSource = GetType(CSM00520Front.CSM00520ServiceRef.CSM00520DTO)
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.btnCloseSession)
        Me.Panel2.Controls.Add(Me.btnStartSession)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 546)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1271, 26)
        Me.Panel2.TabIndex = 3
        '
        'btnCloseSession
        '
        Me.btnCloseSession.Location = New System.Drawing.Point(116, 1)
        Me.btnCloseSession.Name = "btnCloseSession"
        Me.btnCloseSession.R_ConductorGridSource = Me.conGridSession
        Me.btnCloseSession.R_ConductorSource = Nothing
        Me.btnCloseSession.R_DescriptionId = Nothing
        Me.btnCloseSession.R_EnableHASDATA = True
        Me.btnCloseSession.R_EnableOTHER = True
        Me.btnCloseSession.R_ResourceId = "btnCloseSession"
        Me.btnCloseSession.Size = New System.Drawing.Size(110, 24)
        Me.btnCloseSession.TabIndex = 5
        Me.btnCloseSession.Text = "R_RadButton1"
        '
        'btnStartSession
        '
        Me.btnStartSession.Location = New System.Drawing.Point(0, 1)
        Me.btnStartSession.Name = "btnStartSession"
        Me.btnStartSession.R_ConductorGridSource = Me.conGridSession
        Me.btnStartSession.R_ConductorSource = Nothing
        Me.btnStartSession.R_DescriptionId = Nothing
        Me.btnStartSession.R_EnableHASDATA = True
        Me.btnStartSession.R_EnableOTHER = True
        Me.btnStartSession.R_ResourceId = "btnStartSession"
        Me.btnStartSession.Size = New System.Drawing.Size(110, 24)
        Me.btnStartSession.TabIndex = 4
        Me.btnStartSession.Text = "R_RadButton1"
        '
        'preIssue
        '
        Me.preIssue.R_ConductorGridSource = Me.conGridSession
        Me.preIssue.R_ConductorSource = Nothing
        Me.preIssue.R_CopyAccess = False
        Me.preIssue.R_DockIndex = 0
        Me.preIssue.R_EnableHASDATA = True
        Me.preIssue.R_HeaderTitle = ""
        '
        'CSM00520
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CSM00520"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.txtCustomerName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lupCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCustomerCode, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.rdbCustom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.rdbStandard, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvSession.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvSession, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        CType(Me.btnCloseSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnStartSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource
    Friend WithEvents bsVersion As System.Windows.Forms.BindingSource
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents cboVersion As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents lblVersion As R_FrontEnd.R_RadLabel
    Friend WithEvents cboApplication As R_FrontEnd.R_RadDropDownList
    Friend WithEvents gvSession As R_FrontEnd.R_RadGridView
    Friend WithEvents bsGvSession As System.Windows.Forms.BindingSource
    Friend WithEvents conGridSession As R_FrontEnd.R_ConductorGrid
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents bsProject As System.Windows.Forms.BindingSource
    Friend WithEvents lblProject As R_FrontEnd.R_RadLabel
    Friend WithEvents cboProject As R_FrontEnd.R_RadDropDownList
    Friend WithEvents btnStartSession As R_FrontEnd.R_RadButton
    Friend WithEvents btnCloseSession As R_FrontEnd.R_RadButton
    Friend WithEvents preIssue As R_FrontEnd.R_PredefinedDock
    Friend WithEvents rdbCustom As R_FrontEnd.R_RadRadioButton
    Friend WithEvents rdbStandard As R_FrontEnd.R_RadRadioButton
    Friend WithEvents lblCustomer As R_FrontEnd.R_RadLabel
    Friend WithEvents txtCustomerCode As R_FrontEnd.R_RadTextBox
    Friend WithEvents lupCustomer As R_FrontEnd.R_LookUp
    Friend WithEvents txtCustomerName As R_FrontEnd.R_RadTextBox

End Class
