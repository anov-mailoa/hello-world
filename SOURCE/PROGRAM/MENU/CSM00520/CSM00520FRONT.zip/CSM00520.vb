﻿Imports CSM00520FrontResources
Imports R_Common
Imports CSM00520Front.CSM00520ServiceRef
Imports ClientHelper
Imports R_FrontEnd
Imports System.ServiceModel.Channels
Imports CSM00520Front.CSM00520StreamingServiceRef
Imports System.ServiceModel
Imports RCustDBFrontHelper.General
Imports RCustDBFrontHelper

Public Class CSM00520

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSM00520Service/CSM00520Service.svc"
    Dim C_ServiceNameStream As String = "CSM00520Service/CSM00520StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _CVERSION As String
    Dim _CPROJECTID As String
    Dim _CCUSTOMER_CODE As String = ""
    Dim _LCUSTOM As Boolean
    Dim lcFile As String
    Dim llInitialized As Boolean = False
#End Region

#Region " SUB and FUNCTION "

    Private Sub RefreshGrids()
        Dim loTableKey As New CSM00520KeyDTO
        Dim lcVersion As String
        Dim lcApplication As String
        Dim lcProject As String
        Dim llProjectOK As Boolean

        lcApplication = ""
        lcVersion = ""
        lcProject = ""
        llProjectOK = False

        If cboVersion.SelectedValue IsNot Nothing Then
            lcVersion = cboVersion.SelectedValue.Trim
        End If
        If cboApplication.SelectedValue IsNot Nothing Then
            lcApplication = cboApplication.SelectedValue.Trim
        End If
        If cboProject.SelectedValue IsNot Nothing Then
            lcProject = cboProject.SelectedValue.Trim
            llProjectOK = True
        End If
        _CAPPSCODE = lcApplication
        _CPROJECTID = lcProject
        _CVERSION = IIf(_LCUSTOM, _CCUSTOMER_CODE, lcVersion)

        With loTableKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = lcApplication
            .CVERSION = _CVERSION
            .CPROJECT_ID = lcProject
        End With

        With gvSession
            If llInitialized Then
                .R_RefreshGrid(loTableKey)
                .Columns(0).Sort(Telerik.WinControls.UI.RadSortOrder.Ascending, False)
            End If
        End With
        gvSession.Enabled = llProjectOK
    End Sub

    Private Sub RefreshProjectCombo()
        Dim loSvc As CSM00520ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00520Service, CSM00520ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loProjectCombo As New List(Of RCustDBProjectComboDTO)
        Dim lcVersion As String
        ' Project
        _LCUSTOM = rdbCustom.IsChecked
        lcVersion = ""
        If cboVersion.SelectedValue IsNot Nothing Then
            lcVersion = cboVersion.SelectedValue.Trim
        End If
        _CVERSION = IIf(_LCUSTOM, _CCUSTOMER_CODE, lcVersion)
        loProjectCombo = loSvc.GetProjectCombo(New RCustDBProjectKeyDTO With {.CCOMPANY_ID = _CCOMPID, _
                                                                              .CAPPS_CODE = cboApplication.SelectedValue, _
                                                                              .CVERSION = _CVERSION, _
                                                                              .CSTATUS = "*", _
                                                                              .CUSER_ID = _CUSERID})
        If loProjectCombo.Count > 0 Then
            bsProject.DataSource = loProjectCombo
        Else
            cboProject.Items.Clear()
        End If
        loSvc.Close()
    End Sub

#End Region

#Region " FORM Events "

    Private Sub CSM00520_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Dim loSvc As CSM00520ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00520Service, CSM00520ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loAppCombo As New List(Of RLicenseAppComboDTO)

        Try
            llInitialized = False

            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            cboApplication.Items.Clear()
            cboVersion.Items.Clear()
            cboProject.Items.Clear()

            ' Application
            loAppCombo = loSvc.GetAppCombo(_CCOMPID, _CUSERID)
            If loAppCombo.Count <= 0 Then
                cboApplication.Items.Clear()
            End If
            bsApps.DataSource = loAppCombo
            llInitialized = True

            RefreshGrids()

            ' Predefined dock
            Me.R_Components = Me.components
            preIssue.R_HeaderTitle = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00520IssueTitle")

        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loSvc.Close()
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub CSM00511_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " COMBO Actions "

    Private Sub cboApplication_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboApplication.SelectedValueChanged
        Dim loEx As New R_Exception
        Dim loSvc As CSM00520ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00520Service, CSM00520ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loVersionCombo As New List(Of RCustDBVersionComboDTO)

        Try
            ' Version
            loVersionCombo = loSvc.GetVersionCombo(_CCOMPID, CType(sender, R_RadDropDownList).SelectedValue)
            If loVersionCombo.Count > 0 Then
                bsVersion.DataSource = loVersionCombo
                cboVersion.SelectedIndex = loVersionCombo.Count - 1
            Else
                cboVersion.Items.Clear()
            End If
            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loSvc.Close()
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub cboVersion_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboVersion.SelectedValueChanged
        Dim loEx As New R_Exception

        Try
            RefreshProjectCombo()
            If llInitialized Then
                RefreshGrids()
            End If
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub cboProject_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboProject.SelectedValueChanged
        Dim loEx As New R_Exception

        Try
            If llInitialized Then
                RefreshGrids()
            End If
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " GRIDVIEW Events "

    Private Sub gvSession_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvSession.DataBindingComplete
        gvSession.BestFitColumns()
    End Sub

    Private Sub gvSession_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvSession.R_Saving
        With CType(poEntity, CSM00520DTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = cboApplication.SelectedValue.Trim
            ._CVERSION = _CVERSION
            ._CPROJECT_ID = cboProject.SelectedValue.Trim
            ._CINIT_SCHEDULE_TYPE = "3"
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With
    End Sub

    Private Sub gvSession_R_ServiceDelete(poEntity As Object) Handles gvSession.R_ServiceDelete
        Dim loService As CSM00520ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00520Service, CSM00520ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String
        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As FaultException
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loService.Close()
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSession_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvSession.R_ServiceGetListRecord
        Dim loServiceStream As CSM00520StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00520StreamingService, CSM00520StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00520GridDTO)
        Dim loListEntity As New List(Of CSM00520DTO)

        Try
            With CType(poEntity, CSM00520KeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
                R_Utility.R_SetStreamingContext("cProjectId", .CPROJECT_ID)
            End With

            loRtn = loServiceStream.GetComplaintSessionList()
            loStreaming = R_StreamUtility(Of CSM00520GridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00520GridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New CSM00520DTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                                  ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                           ._CVERSION = loDto.CVERSION,
                                                           ._CPROJECT_ID = loDto.CPROJECT_ID,
                                                           ._CSESSION_ID = loDto.CSESSION_ID,
                                                                  ._DSESSION_DATE = loDto.DSESSION_DATE,
                                                                  ._CSTATUS = loDto.CSTATUS,
                                                           ._CCARE_NO = loDto.CCARE_NO,
                                                                  ._CNOTE = loDto.CNOTE,
                                                                  ._DPLAN_START_DATE = StrToDate(loDto.CPLAN_START_DATE),
                                                                  ._DPLAN_END_DATE = StrToDate(loDto.CPLAN_END_DATE),
                                                                  ._DACTUAL_START_DATE = StrToDate(loDto.CACTUAL_START_DATE),
                                                                  ._DACTUAL_END_DATE = StrToDate(loDto.CACTUAL_END_DATE),
                                                                  ._DCLOSE_DATE = loDto.DCLOSE_DATE,
                                                                  ._CINIT_SCHEDULE_TYPE = loDto.CINIT_SCHEDULE_TYPE,
                                                                    ._CCREATE_BY = loDto.CCREATE_BY,
                                                                    ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                                    ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                                    ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loServiceStream.Close()
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSession_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvSession.R_ServiceGetRecord
        Dim loService As CSM00520ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00520Service, CSM00520ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New CSM00520DTO With {._CCOMPANY_ID = _CCOMPID,
                                                                             ._CAPPS_CODE = cboApplication.SelectedValue.Trim,
                                                                             ._CVERSION = cboVersion.SelectedValue.Trim,
                                                                             ._CPROJECT_ID = cboProject.SelectedValue.Trim,
                                                                             ._CSESSION_ID = CType(bsGvSession.Current, CSM00520DTO)._CSESSION_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loService.Close()
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSession_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvSession.R_ServiceSave
        Dim loService As CSM00520ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00520Service, CSM00520ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loService.Close()

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSession_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvSession.R_Validation
        Dim loEx As New R_Exception()

        Try
            With poGridCellCollection
                If String.IsNullOrWhiteSpace(.Item("_CCARE_NO").Value) Then
                    loEx.Add("CSM00520_01", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00520_01"))
                    plCancel = True
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " BUTTON Actions "

    Private Sub btnStartSession_Click(sender As System.Object, e As System.EventArgs) Handles btnStartSession.Click
        Dim loService As CSM00520ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00520Service, CSM00520ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim loPar As New CSM00500SessionKeyDTO

        Try
            With loPar
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = _CAPPSCODE
                .CVERSION = _CVERSION
                .CPROJECT_ID = _CPROJECTID
                .CSESSION_ID = CType(bsGvSession.Current, CSM00520DTO)._CSESSION_ID
                .CUSER_ID = _CUSERID
                .CNOTE = CType(bsGvSession.Current, CSM00520DTO)._CNOTE
            End With
            loService.StartSession(loPar)
            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loService.Close()
        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If

    End Sub

    Private Sub btnCloseSession_Click(sender As Object, e As System.EventArgs) Handles btnCloseSession.Click
        Dim loService As CSM00520ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00520Service, CSM00520ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim loPar As New CSM00500SessionKeyDTO

        Try
            With loPar
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = _CAPPSCODE
                .CVERSION = _CVERSION
                .CPROJECT_ID = _CPROJECTID
                .CSESSION_ID = CType(bsGvSession.Current, CSM00520DTO)._CSESSION_ID
                .CNOTE = CType(bsGvSession.Current, CSM00520DTO)._CNOTE
                .CUSER_ID = _CUSERID
            End With
            loService.CloseSession(loPar)
            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loService.Close()
        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If
    End Sub
#End Region

#Region " PREDEFINED DOCK Events "

    Private Sub preIssue_R_InstantiateDock(ByRef poTargetForm As R_FrontEnd.R_FormBase) Handles preIssue.R_InstantiateDock
        poTargetForm = New CSM00520Issues
    End Sub

    Private Sub preIssue_R_PassParameter(ByRef poParameter As Object) Handles preIssue.R_PassParameter
        Dim loPICKey As New CSM00520IssueParamDTO
        Dim lcVersion As String
        Dim lcApplication As String
        Dim lcApplicationName As String
        Dim lcProjectId As String
        Dim lcProjectName As String
        Dim lcSessionID As String
        Dim lcCARENo As String

        lcApplication = ""
        lcApplicationName = ""
        lcVersion = ""
        lcProjectId = ""
        lcProjectName = ""
        If cboVersion.SelectedValue IsNot Nothing Then
            lcVersion = cboVersion.SelectedValue.Trim
        End If
        If cboApplication.SelectedValue IsNot Nothing Then
            lcApplication = cboApplication.SelectedValue.Trim
            lcApplicationName = cboApplication.Text.Trim
        End If
        If cboProject.SelectedValue IsNot Nothing Then
            lcProjectId = cboProject.SelectedValue.Trim
            lcProjectName = cboProject.Text.Trim
        End If
        If CType(bsGvSession.Current, CSM00520DTO)._CPROJECT_ID IsNot Nothing Then
            With CType(bsGvSession.Current, CSM00520DTO)
                lcSessionID = ._CSESSION_ID
                lcCARENo = ._CCARE_NO
            End With
        End If

        With loPICKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = lcApplication
            .CVERSION = _CVERSION
            .CPROJECT_ID = lcProjectId
            .CSESSION_ID = lcSessionID
            .CCARE_NO = lcCARENo
            .CAPPS_NAME = lcApplicationName
            .CPROJECT_NAME = lcProjectName
            .LCUSTOM = _LCUSTOM
            .CCUSTOMER_NAME = txtCustomerName.Text
            .CCODE_NAME = cboVersion.Text
        End With
        poParameter = loPICKey
    End Sub

#End Region

#Region " LOOKUP Events "

    Private Sub R_LookUp1_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles lupCustomer.R_Before_Open_Form
        poTargetForm = New CustList
        poParameter = New FileStreamingServiceRef.RCustDBFileKeyDTO With {.CCOMPANY_ID = _CCOMPID}
    End Sub

    Private Sub R_LookUp1_R_Return_LookUp(poReturnObject As Object) Handles lupCustomer.R_Return_LookUp
        txtCustomerCode.Text = poReturnObject.CCUSTOMER_CODE
        txtCustomerName.Text = poReturnObject.CCUSTOMER_NAME
    End Sub

    Private Sub txtCustomerCode_TextChanged(sender As Object, e As System.EventArgs) Handles txtCustomerCode.TextChanged
        Dim loSvc As CSM00520ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00520Service, CSM00520ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loProjectCombo As New List(Of RCustDBProjectComboDTO)

        _CCUSTOMER_CODE = txtCustomerCode.Text
        RefreshProjectCombo()
        If llInitialized Then
            RefreshGrids()
        End If
    End Sub

#End Region

#Region " RADIO BUTTON Actions "

    Private Sub rdbStandard_CheckStateChanged(sender As Object, e As System.EventArgs) Handles rdbStandard.CheckStateChanged
        If CType(sender, R_RadRadioButton).IsChecked Then
            RefreshProjectCombo()
            RefreshGrids()
        End If
    End Sub

    Private Sub rdbCustom_CheckStateChanged(sender As Object, e As System.EventArgs) Handles rdbCustom.CheckStateChanged
        If CType(sender, R_RadRadioButton).IsChecked Then
            RefreshProjectCombo()
            RefreshGrids()
        End If
    End Sub

    Private Sub conGridProject_R_SetAdd(plEnable As Boolean) Handles conGridSession.R_SetAdd
        lblVersion.Visible = Not _LCUSTOM
        cboVersion.Enabled = Not plEnable And Not _LCUSTOM
        cboVersion.Visible = Not _LCUSTOM
        lblCustomer.Visible = _LCUSTOM
        txtCustomerCode.Enabled = Not plEnable And _LCUSTOM
        lupCustomer.Enabled = Not plEnable And _LCUSTOM
        txtCustomerCode.Visible = _LCUSTOM
        lupCustomer.Visible = _LCUSTOM
        txtCustomerName.Visible = _LCUSTOM
    End Sub

    Private Sub conGridProject_R_SetEdit(plEnable As Boolean) Handles conGridSession.R_SetEdit
        lblVersion.Visible = Not _LCUSTOM
        cboVersion.Enabled = Not plEnable And Not _LCUSTOM
        cboVersion.Visible = Not _LCUSTOM
        lblCustomer.Visible = _LCUSTOM
        txtCustomerCode.Enabled = Not plEnable And _LCUSTOM
        lupCustomer.Enabled = Not plEnable And _LCUSTOM
        txtCustomerCode.Visible = _LCUSTOM
        lupCustomer.Visible = _LCUSTOM
        txtCustomerName.Visible = _LCUSTOM
    End Sub

#End Region

End Class
