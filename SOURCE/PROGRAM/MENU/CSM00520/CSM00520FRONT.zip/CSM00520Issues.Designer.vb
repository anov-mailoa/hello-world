﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSM00520Issues
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn6 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn7 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn2 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn8 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn9 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewLookUpColumn3 As R_FrontEnd.R_GridViewLookUpColumn = New R_FrontEnd.R_GridViewLookUpColumn()
        Dim R_GridViewComboBoxColumn3 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Dim R_GridViewComboBoxColumn4 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Dim R_GridViewLookUpColumn4 As R_FrontEnd.R_GridViewLookUpColumn = New R_FrontEnd.R_GridViewLookUpColumn()
        Dim R_GridViewTextBoxColumn10 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.bsIssueClass = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsIssueType = New System.Windows.Forms.BindingSource(Me.components)
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnRefresh = New R_FrontEnd.R_RadButton(Me.components)
        Me.lblCARENo = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtCARENo = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblSession = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtSession = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtProject = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtVersion = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtApplication = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.btnIssueClass = New R_FrontEnd.R_PopUp(Me.components)
        Me.conGridIssue = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.lblProject = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblVersion = New R_FrontEnd.R_RadLabel(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnCopy = New R_FrontEnd.R_RadButton(Me.components)
        Me.btnPaste = New R_FrontEnd.R_RadButton(Me.components)
        Me.btnAttachment = New R_FrontEnd.R_PopUp(Me.components)
        Me.lblIssueList = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvIssue = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvIssue = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblCustomer = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblCustom = New R_FrontEnd.R_RadLabel(Me.components)
        CType(Me.bsIssueClass, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsIssueType, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.btnRefresh, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCARENo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCARENo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnIssueClass, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.btnCopy, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnPaste, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnAttachment, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblIssueList, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvIssue.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCustom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'bsIssueClass
        '
        Me.bsIssueClass.DataSource = GetType(CSM00520Front.CSM00520IssueServiceRef.CST00200IssueClassComboDTO)
        '
        'bsIssueType
        '
        Me.bsIssueType.DataSource = GetType(CSM00520Front.CSM00520IssueServiceRef.CST00200IssueTypeComboDTO)
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 96.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lblCustom)
        Me.Panel1.Controls.Add(Me.lblCustomer)
        Me.Panel1.Controls.Add(Me.btnRefresh)
        Me.Panel1.Controls.Add(Me.lblCARENo)
        Me.Panel1.Controls.Add(Me.txtCARENo)
        Me.Panel1.Controls.Add(Me.lblSession)
        Me.Panel1.Controls.Add(Me.txtSession)
        Me.Panel1.Controls.Add(Me.txtProject)
        Me.Panel1.Controls.Add(Me.txtVersion)
        Me.Panel1.Controls.Add(Me.txtApplication)
        Me.Panel1.Controls.Add(Me.btnIssueClass)
        Me.Panel1.Controls.Add(Me.lblProject)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Controls.Add(Me.lblVersion)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 90)
        Me.Panel1.TabIndex = 1
        '
        'btnRefresh
        '
        Me.btnRefresh.Location = New System.Drawing.Point(9, 60)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.R_ConductorGridSource = Nothing
        Me.btnRefresh.R_ConductorSource = Nothing
        Me.btnRefresh.R_DescriptionId = Nothing
        Me.btnRefresh.R_ResourceId = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(110, 24)
        Me.btnRefresh.TabIndex = 61
        Me.btnRefresh.Text = "R_RadButton1"
        '
        'lblCARENo
        '
        Me.lblCARENo.AutoSize = False
        Me.lblCARENo.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCARENo.Location = New System.Drawing.Point(833, 35)
        Me.lblCARENo.Name = "lblCARENo"
        Me.lblCARENo.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCARENo.R_ResourceId = "lblCARENo"
        Me.lblCARENo.Size = New System.Drawing.Size(100, 18)
        Me.lblCARENo.TabIndex = 55
        Me.lblCARENo.Text = "Application..."
        '
        'txtCARENo
        '
        Me.txtCARENo.Location = New System.Drawing.Point(939, 34)
        Me.txtCARENo.Name = "txtCARENo"
        Me.txtCARENo.R_ConductorGridSource = Nothing
        Me.txtCARENo.R_ConductorSource = Nothing
        Me.txtCARENo.R_UDT = Nothing
        Me.txtCARENo.ReadOnly = True
        Me.txtCARENo.Size = New System.Drawing.Size(200, 20)
        Me.txtCARENo.TabIndex = 54
        Me.txtCARENo.TabStop = False
        '
        'lblSession
        '
        Me.lblSession.AutoSize = False
        Me.lblSession.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblSession.Location = New System.Drawing.Point(521, 35)
        Me.lblSession.Name = "lblSession"
        Me.lblSession.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblSession.R_ResourceId = "lblSession"
        Me.lblSession.Size = New System.Drawing.Size(100, 18)
        Me.lblSession.TabIndex = 52
        Me.lblSession.Text = "Application..."
        '
        'txtSession
        '
        Me.txtSession.Location = New System.Drawing.Point(627, 34)
        Me.txtSession.Name = "txtSession"
        Me.txtSession.R_ConductorGridSource = Nothing
        Me.txtSession.R_ConductorSource = Nothing
        Me.txtSession.R_UDT = Nothing
        Me.txtSession.ReadOnly = True
        Me.txtSession.Size = New System.Drawing.Size(200, 20)
        Me.txtSession.TabIndex = 51
        Me.txtSession.TabStop = False
        '
        'txtProject
        '
        Me.txtProject.Location = New System.Drawing.Point(115, 34)
        Me.txtProject.Name = "txtProject"
        Me.txtProject.R_ConductorGridSource = Nothing
        Me.txtProject.R_ConductorSource = Nothing
        Me.txtProject.R_UDT = Nothing
        Me.txtProject.ReadOnly = True
        Me.txtProject.Size = New System.Drawing.Size(294, 20)
        Me.txtProject.TabIndex = 50
        Me.txtProject.TabStop = False
        '
        'txtVersion
        '
        Me.txtVersion.Location = New System.Drawing.Point(627, 8)
        Me.txtVersion.Name = "txtVersion"
        Me.txtVersion.R_ConductorGridSource = Nothing
        Me.txtVersion.R_ConductorSource = Nothing
        Me.txtVersion.R_UDT = Nothing
        Me.txtVersion.ReadOnly = True
        Me.txtVersion.Size = New System.Drawing.Size(200, 20)
        Me.txtVersion.TabIndex = 49
        Me.txtVersion.TabStop = False
        '
        'txtApplication
        '
        Me.txtApplication.Location = New System.Drawing.Point(115, 8)
        Me.txtApplication.Name = "txtApplication"
        Me.txtApplication.R_ConductorGridSource = Nothing
        Me.txtApplication.R_ConductorSource = Nothing
        Me.txtApplication.R_UDT = Nothing
        Me.txtApplication.ReadOnly = True
        Me.txtApplication.Size = New System.Drawing.Size(400, 20)
        Me.txtApplication.TabIndex = 48
        Me.txtApplication.TabStop = False
        '
        'btnIssueClass
        '
        Me.btnIssueClass.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnIssueClass.Location = New System.Drawing.Point(125, 60)
        Me.btnIssueClass.Name = "btnIssueClass"
        Me.btnIssueClass.R_ConductorGridSource = Me.conGridIssue
        Me.btnIssueClass.R_ConductorSource = Nothing
        Me.btnIssueClass.R_DescriptionId = Nothing
        Me.btnIssueClass.R_EnableOTHER = True
        Me.btnIssueClass.R_ResourceId = "btnIssueClass"
        Me.btnIssueClass.R_Title = Nothing
        Me.btnIssueClass.Size = New System.Drawing.Size(110, 24)
        Me.btnIssueClass.TabIndex = 36
        Me.btnIssueClass.Text = "R_PopUp1"
        '
        'conGridIssue
        '
        Me.conGridIssue.R_ConductorParent = Nothing
        Me.conGridIssue.R_IsHeader = True
        Me.conGridIssue.R_RadGroupBox = Nothing
        '
        'lblProject
        '
        Me.lblProject.AutoSize = False
        Me.lblProject.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblProject.Location = New System.Drawing.Point(9, 35)
        Me.lblProject.Name = "lblProject"
        Me.lblProject.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblProject.R_ResourceId = "lblProject"
        Me.lblProject.Size = New System.Drawing.Size(100, 18)
        Me.lblProject.TabIndex = 33
        Me.lblProject.Text = "Application..."
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 30
        Me.lblApplication.Text = "Application..."
        '
        'lblVersion
        '
        Me.lblVersion.AutoSize = False
        Me.lblVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblVersion.Location = New System.Drawing.Point(521, 9)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblVersion.R_ResourceId = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(100, 18)
        Me.lblVersion.TabIndex = 32
        Me.lblVersion.Text = "Application..."
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.btnCopy)
        Me.Panel2.Controls.Add(Me.btnPaste)
        Me.Panel2.Controls.Add(Me.btnAttachment)
        Me.Panel2.Controls.Add(Me.lblIssueList)
        Me.Panel2.Controls.Add(Me.gvIssue)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 99)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1271, 473)
        Me.Panel2.TabIndex = 5
        '
        'btnCopy
        '
        Me.btnCopy.Location = New System.Drawing.Point(920, 3)
        Me.btnCopy.Name = "btnCopy"
        Me.btnCopy.R_ConductorGridSource = Me.conGridIssue
        Me.btnCopy.R_ConductorSource = Nothing
        Me.btnCopy.R_DescriptionId = Nothing
        Me.btnCopy.R_EnableHASDATA = True
        Me.btnCopy.R_ResourceId = "btnCopy"
        Me.btnCopy.Size = New System.Drawing.Size(110, 24)
        Me.btnCopy.TabIndex = 4
        Me.btnCopy.Text = "R_RadButton1"
        '
        'btnPaste
        '
        Me.btnPaste.Location = New System.Drawing.Point(1036, 3)
        Me.btnPaste.Name = "btnPaste"
        Me.btnPaste.R_ConductorGridSource = Nothing
        Me.btnPaste.R_ConductorSource = Nothing
        Me.btnPaste.R_DescriptionId = Nothing
        Me.btnPaste.R_ResourceId = "btnPaste"
        Me.btnPaste.Size = New System.Drawing.Size(110, 24)
        Me.btnPaste.TabIndex = 3
        Me.btnPaste.Text = "R_RadButton1"
        '
        'btnAttachment
        '
        Me.btnAttachment.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnAttachment.Location = New System.Drawing.Point(1152, 3)
        Me.btnAttachment.Name = "btnAttachment"
        Me.btnAttachment.R_ConductorGridSource = Me.conGridIssue
        Me.btnAttachment.R_ConductorSource = Nothing
        Me.btnAttachment.R_DescriptionId = Nothing
        Me.btnAttachment.R_EnableHASDATA = True
        Me.btnAttachment.R_ResourceId = "btnAttachment"
        Me.btnAttachment.R_Title = Nothing
        Me.btnAttachment.Size = New System.Drawing.Size(110, 24)
        Me.btnAttachment.TabIndex = 2
        Me.btnAttachment.Text = "R_PopUp1"
        '
        'lblIssueList
        '
        Me.lblIssueList.AutoSize = False
        Me.lblIssueList.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblIssueList.Location = New System.Drawing.Point(9, 6)
        Me.lblIssueList.Name = "lblIssueList"
        Me.lblIssueList.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblIssueList.R_ResourceId = "lblIssueList"
        Me.lblIssueList.Size = New System.Drawing.Size(100, 18)
        Me.lblIssueList.TabIndex = 1
        Me.lblIssueList.Text = "R_RadLabel1"
        '
        'gvIssue
        '
        Me.gvIssue.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gvIssue.AutoSizeRows = True
        Me.gvIssue.EnableFastScrolling = True
        Me.gvIssue.Location = New System.Drawing.Point(0, 30)
        '
        '
        '
        Me.gvIssue.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn6.FieldName = "_CISSUE_ID"
        R_GridViewTextBoxColumn6.HeaderText = "_CISSUE_ID"
        R_GridViewTextBoxColumn6.MaxLength = 15
        R_GridViewTextBoxColumn6.Name = "_CISSUE_ID"
        R_GridViewTextBoxColumn6.R_EnableADD = True
        R_GridViewTextBoxColumn6.R_ResourceId = "_CISSUE_ID"
        R_GridViewTextBoxColumn6.R_UDT = Nothing
        R_GridViewTextBoxColumn6.Width = 78
        R_GridViewTextBoxColumn7.FieldName = "_CUSER_ID"
        R_GridViewTextBoxColumn7.HeaderText = "_CUSER_ID"
        R_GridViewTextBoxColumn7.Name = "_CUSER_ID"
        R_GridViewTextBoxColumn7.R_ResourceId = "_CUSER_ID"
        R_GridViewTextBoxColumn7.R_UDT = Nothing
        R_GridViewTextBoxColumn7.Width = 76
        R_GridViewDateTimeColumn2.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn2.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn2.FieldName = "_DISSUE_DATE"
        R_GridViewDateTimeColumn2.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn2.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn2.HeaderText = "_DISSUE_DATE"
        R_GridViewDateTimeColumn2.Name = "_DISSUE_DATE"
        R_GridViewDateTimeColumn2.R_ResourceId = "_DISSUE_DATE"
        R_GridViewDateTimeColumn2.Width = 95
        R_GridViewTextBoxColumn8.FieldName = "_CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn8.HeaderText = "_CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn8.Name = "_CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn8.R_ResourceId = "_CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn8.R_UDT = Nothing
        R_GridViewTextBoxColumn8.Width = 131
        R_GridViewTextBoxColumn9.FieldName = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn9.HeaderText = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn9.Name = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn9.R_ResourceId = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn9.R_UDT = Nothing
        R_GridViewTextBoxColumn9.Width = 104
        R_GridViewLookUpColumn3.FieldName = "_CITEM_ID"
        R_GridViewLookUpColumn3.HeaderText = "_CITEM_ID"
        R_GridViewLookUpColumn3.Name = "_CITEM_ID"
        R_GridViewLookUpColumn3.R_EnableADD = True
        R_GridViewLookUpColumn3.R_ResourceId = "_CITEM_ID"
        R_GridViewLookUpColumn3.R_Title = Nothing
        R_GridViewLookUpColumn3.Width = 74
        R_GridViewComboBoxColumn3.DataSource = Me.bsIssueClass
        R_GridViewComboBoxColumn3.DisplayMember = "CDESCRIPTION"
        R_GridViewComboBoxColumn3.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDown
        R_GridViewComboBoxColumn3.FieldName = "_CISSUE_CLASS"
        R_GridViewComboBoxColumn3.HeaderText = "_CISSUE_CLASS"
        R_GridViewComboBoxColumn3.Name = "_CISSUE_CLASS"
        R_GridViewComboBoxColumn3.R_EnableADD = True
        R_GridViewComboBoxColumn3.R_EnableEDIT = True
        R_GridViewComboBoxColumn3.R_ResourceId = "_CISSUE_CLASS"
        R_GridViewComboBoxColumn3.ValueMember = "CISSUE_CLASS"
        R_GridViewComboBoxColumn3.Width = 99
        R_GridViewComboBoxColumn4.DataSource = Me.bsIssueType
        R_GridViewComboBoxColumn4.DisplayMember = "CDESCRIPTION"
        R_GridViewComboBoxColumn4.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDown
        R_GridViewComboBoxColumn4.FieldName = "_CISSUE_TYPE"
        R_GridViewComboBoxColumn4.HeaderText = "_CISSUE_TYPE"
        R_GridViewComboBoxColumn4.Name = "_CISSUE_TYPE"
        R_GridViewComboBoxColumn4.R_EnableADD = True
        R_GridViewComboBoxColumn4.R_EnableEDIT = True
        R_GridViewComboBoxColumn4.R_ResourceId = "_CISSUE_TYPE"
        R_GridViewComboBoxColumn4.ValueMember = "CISSUE_TYPE"
        R_GridViewComboBoxColumn4.Width = 91
        R_GridViewLookUpColumn4.FieldName = "_CDESCRIPTION"
        R_GridViewLookUpColumn4.HeaderText = "_CDESCRIPTION"
        R_GridViewLookUpColumn4.Name = "_CDESCRIPTION"
        R_GridViewLookUpColumn4.R_EnableADD = True
        R_GridViewLookUpColumn4.R_EnableEDIT = True
        R_GridViewLookUpColumn4.R_ResourceId = "_CDESCRIPTION"
        R_GridViewLookUpColumn4.R_Title = "Description"
        R_GridViewLookUpColumn4.TextAlignment = System.Drawing.ContentAlignment.TopLeft
        R_GridViewLookUpColumn4.Width = 103
        R_GridViewLookUpColumn4.WrapText = True
        R_GridViewTextBoxColumn10.FieldName = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn10.HeaderText = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn10.Name = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn10.R_ResourceId = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn10.R_UDT = Nothing
        Me.gvIssue.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn6, R_GridViewTextBoxColumn7, R_GridViewDateTimeColumn2, R_GridViewTextBoxColumn8, R_GridViewTextBoxColumn9, R_GridViewLookUpColumn3, R_GridViewComboBoxColumn3, R_GridViewComboBoxColumn4, R_GridViewLookUpColumn4, R_GridViewTextBoxColumn10})
        Me.gvIssue.MasterTemplate.DataSource = Me.bsGvIssue
        Me.gvIssue.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvIssue.MasterTemplate.EnableFiltering = True
        Me.gvIssue.MasterTemplate.EnableGrouping = False
        Me.gvIssue.MasterTemplate.ShowFilteringRow = False
        Me.gvIssue.MasterTemplate.ShowGroupedColumns = True
        Me.gvIssue.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvIssue.Name = "gvIssue"
        Me.gvIssue.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvIssue.R_ConductorGridSource = Me.conGridIssue
        Me.gvIssue.R_ConductorSource = Nothing
        Me.gvIssue.R_DataAdded = False
        Me.gvIssue.R_NewRowText = Nothing
        Me.gvIssue.ShowHeaderCellButtons = True
        Me.gvIssue.Size = New System.Drawing.Size(1271, 443)
        Me.gvIssue.TabIndex = 0
        Me.gvIssue.Text = "R_RadGridView1"
        '
        'bsGvIssue
        '
        Me.bsGvIssue.DataSource = GetType(CSM00520Front.CSM00520IssueServiceRef.CSM00520IssueDTO)
        '
        'lblCustomer
        '
        Me.lblCustomer.AutoSize = False
        Me.lblCustomer.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustomer.Location = New System.Drawing.Point(521, 9)
        Me.lblCustomer.Name = "lblCustomer"
        Me.lblCustomer.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustomer.R_ResourceId = "lblCustomer"
        Me.lblCustomer.Size = New System.Drawing.Size(100, 18)
        Me.lblCustomer.TabIndex = 62
        Me.lblCustomer.Text = "Application..."
        '
        'lblCustom
        '
        Me.lblCustom.AutoSize = False
        Me.lblCustom.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustom.Location = New System.Drawing.Point(415, 35)
        Me.lblCustom.Name = "lblCustom"
        Me.lblCustom.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustom.R_ResourceId = ""
        Me.lblCustom.Size = New System.Drawing.Size(100, 18)
        Me.lblCustom.TabIndex = 63
        Me.lblCustom.Text = "Application..."
        '
        'CSM00520Issues
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CSM00520Issues"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.bsIssueClass, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsIssueType, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.btnRefresh, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCARENo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCARENo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnIssueClass, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridIssue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        CType(Me.btnCopy, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnPaste, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnAttachment, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblIssueList, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvIssue.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvIssue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvIssue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCustom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblProject As R_FrontEnd.R_RadLabel
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents lblVersion As R_FrontEnd.R_RadLabel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents gvIssue As R_FrontEnd.R_RadGridView
    Friend WithEvents conGridIssue As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsGvIssue As System.Windows.Forms.BindingSource
    Friend WithEvents bsIssueClass As System.Windows.Forms.BindingSource
    Friend WithEvents btnIssueClass As R_FrontEnd.R_PopUp
    Friend WithEvents lblIssueList As R_FrontEnd.R_RadLabel
    Friend WithEvents btnAttachment As R_FrontEnd.R_PopUp
    Friend WithEvents txtSession As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtProject As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtVersion As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtApplication As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblSession As R_FrontEnd.R_RadLabel
    Friend WithEvents btnPaste As R_FrontEnd.R_RadButton
    Friend WithEvents btnCopy As R_FrontEnd.R_RadButton
    Friend WithEvents lblCARENo As R_FrontEnd.R_RadLabel
    Friend WithEvents txtCARENo As R_FrontEnd.R_RadTextBox
    Friend WithEvents btnRefresh As R_FrontEnd.R_RadButton
    Friend WithEvents bsIssueType As System.Windows.Forms.BindingSource
    Friend WithEvents lblCustomer As R_FrontEnd.R_RadLabel
    Friend WithEvents lblCustom As R_FrontEnd.R_RadLabel

End Class
