﻿Public Class CSM00600DetailGridDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CATTRIBUTE_GROUP As String
    Public Property CATTRIBUTE_ID As String
    Public Property CPROGRAM_ID As String
    Public Property CCR_ID As String
    Public Property CSEQUENCE As String
    Public Property CISSUE_ID As String
    Public Property CDESCRIPTION As String
    Public Property LCANCEL As Boolean
    Public Property CSCHEDULE_ID As String
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)
    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)

    Public Property CISSUE_DESCRIPTION As String

End Class
