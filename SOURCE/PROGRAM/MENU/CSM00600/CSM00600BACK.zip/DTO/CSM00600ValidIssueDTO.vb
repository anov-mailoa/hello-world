﻿Public Class CSM00600ValidIssueDTO
    Public Property CSCHEDULE_ID As String
    Public Property LOK As Boolean
End Class
