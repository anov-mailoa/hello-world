﻿Public Class CSM00600KeyDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CATTRIBUTE_GROUP As String
    Public Property CATTRIBUTE_ID As String
    Public Property CPROGRAM_ID As String
    Public Property CCR_ID As String
    Public Property CSEQUENCE As String

    ' Process
    Public Property CUSER_ID As String

End Class
