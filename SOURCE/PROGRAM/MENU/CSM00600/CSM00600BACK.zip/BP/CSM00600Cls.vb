﻿Imports R_BackEnd
Imports R_Common
Imports System.Data.Common
Imports System.Transactions

Public Class CSM00600Cls
    Inherits R_BusinessObject(Of CSM00600DTO)

    Public Function GetCRList(poKey As CSM00600KeyDTO) As List(Of CSM00600GridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00600GridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CSM_PROGRAM_CHANGES (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                lcQuery += "AND CPROGRAM_ID = '{4}' "
                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CATTRIBUTE_GROUP, _
                                        .CATTRIBUTE_ID, _
                                        .CPROGRAM_ID)

            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00600GridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Deleting(poEntity As CSM00600DTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcRtn As String

        Try
            loConn = loDb.GetConnection()

            With poEntity

                'validation
                loCmd = loDb.GetCommand()
                lcQuery = "EXEC RSP_Delete_CR_Validation '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '', 'HEADER', @CRET_MSG OUTPUT "
                With poEntity
                    lcQuery = String.Format(lcQuery, _
                                            .CCOMPANY_ID, _
                                            .CAPPS_CODE, _
                                            .CATTRIBUTE_GROUP, _
                                            .CATTRIBUTE_ID, _
                                            .CPROGRAM_ID, _
                                            .CCR_ID)
                End With
                loCmd.CommandText = lcQuery
                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@CRET_MSG"
                    .DbType = DbType.String
                    .Size = 50
                    .Direction = ParameterDirection.Output
                End With
                loCmd.Parameters.Add(loPar)
                loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)

                If loCmd.Parameters("@CRET_MSG") Is Nothing Then
                    lcRtn = "UNKNOWN_ERROR"
                Else
                    lcRtn = loCmd.Parameters("@CRET_MSG").Value
                End If

                If Not lcRtn.Equals("OK") Then
                    Throw New Exception(lcRtn)
                End If

                'delete project user table
                lcQuery = "DELETE FROM "
                lcQuery += "CSM_CHANGES_DETAIL "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                lcQuery += "AND CPROGRAM_ID = '{4}' "
                lcQuery += "AND CCR_ID = '{5}' "
                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CATTRIBUTE_GROUP, _
                                        .CATTRIBUTE_ID, _
                                        .CPROGRAM_ID, _
                                        .CCR_ID)
                loDb.SqlExecNonQuery(lcQuery, loConn, False)

                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "CSM_PROGRAM_CHANGES "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                lcQuery += "AND CPROGRAM_ID = '{4}' "
                lcQuery += "AND CCR_ID = '{5}' "
                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CATTRIBUTE_GROUP, _
                                        .CATTRIBUTE_ID, _
                                        .CPROGRAM_ID, _
                                        .CCR_ID)
                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As CSM00600DTO) As CSM00600DTO
        Dim lcQuery As String
        Dim loResult As CSM00600DTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CSM_PROGRAM_CHANGES "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                lcQuery += "AND CPROGRAM_ID = '{4}' "
                lcQuery += "AND CCR_ID = '{5}' "
                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CATTRIBUTE_GROUP, _
                                        .CATTRIBUTE_ID, _
                                        .CPROGRAM_ID, _
                                        .CCR_ID)
                loResult = loDb.SqlExecObjectQuery(Of CSM00600DTO)(lcQuery).FirstOrDefault

            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As CSM00600DTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loProject As New CSM00600DTO
        Dim loKey As New CSM00600KeyDTO

        Try
            loConn = loDb.GetConnection()

            With poNewEntity

                ' get current project/session
                lcQuery = "SELECT A.* "
                lcQuery += "FROM CSM_PROJECT_SESSIONS A (NOLOCK) "
                lcQuery += "JOIN CSM_PROJECT_PROGRAMS B (NOLOCK) "
                lcQuery += "ON B.CCOMPANY_ID = A.CCOMPANY_ID "
                lcQuery += "AND B.CAPPS_CODE = A.CAPPS_CODE "
                lcQuery += "AND B.CVERSION = A.CVERSION "
                lcQuery += "AND B.CPROJECT_ID = A.CPROJECT_ID "
                lcQuery += "AND B.CSESSION_ID = A.CSESSION_ID "
                lcQuery += "WHERE A.CCOMPANY_ID = '{0}' "
                lcQuery += "AND A.CAPPS_CODE = '{1}' "
                lcQuery += "AND A.CVERSION = '{2}' "
                lcQuery += "AND A.CSTATUS <> 'CLOSED' "
                lcQuery += "AND B.CATTRIBUTE_GROUP = '{3}' "
                lcQuery += "AND B.CATTRIBUTE_ID = '{4}' "
                lcQuery += "AND B.CITEM_ID = '{5}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CPROGRAM_ID)

                loProject = loDb.SqlExecObjectQuery(Of CSM00600DTO)(lcQuery).FirstOrDefault
                If loProject IsNot Nothing Then
                    .CPROJECT_ID = loProject.CPROJECT_ID
                    .CSESSION_ID = loProject.CSESSION_ID
                Else
                    Throw New Exception("NO_PROJECT")
                End If

                If poCRUDMode = eCRUDMode.AddMode Then

                    .CSTATUS = "NEW"
                    .CUPDATE_BY = .CUPDATE_BY
                    .CCREATE_BY = .CUPDATE_BY

                    ' get current version
                    'lcQuery = "SELECT CVERSION "
                    'lcQuery += "FROM RVT_APP_VERSION (NOLOCK) "
                    'lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    'lcQuery += "AND CAPPS_CODE = '{1}' "
                    'lcQuery += "AND CSTATUS = 'OPEN' "
                    'lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE)

                    '.CVERSION = loDb.SqlExecObjectQuery(Of String)(lcQuery).FirstOrDefault
                    'If String.IsNullOrEmpty(.CVERSION) Then
                    '    Throw New Exception("NO_VERSION")
                    'End If

                    ' get CCR_ID
                    lcQuery = "EXEC RSP_Get_CR_Id '{0}', '{1}', '{2}', '{3}', '{4}', '', 'HEADER' "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CPROGRAM_ID)

                    loKey = loDb.SqlExecObjectQuery(Of CSM00600KeyDTO)(lcQuery).FirstOrDefault
                    If loKey IsNot Nothing Then
                        .CCR_ID = loKey.CCR_ID
                    Else
                        Throw New Exception("NO_CR_ID")
                    End If

                    lcQuery = "INSERT INTO CSM_PROGRAM_CHANGES ("
                    lcQuery += "CCOMPANY_ID, "
                    lcQuery += "CAPPS_CODE, "
                    lcQuery += "CATTRIBUTE_GROUP, "
                    lcQuery += "CATTRIBUTE_ID, "
                    lcQuery += "CPROGRAM_ID, "
                    lcQuery += "CCR_ID, "
                    lcQuery += "CVERSION, "
                    lcQuery += "CPROJECT_ID, "
                    lcQuery += "CSESSION_ID, "
                    lcQuery += "CSTATUS, "
                    lcQuery += "CDESCRIPTION, "
                    lcQuery += "CUPDATE_BY, "
                    lcQuery += "DUPDATE_DATE, "
                    lcQuery += "CCREATE_BY, "
                    lcQuery += "DCREATE_DATE) "
                    lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', GETDATE(), '{12}', GETDATE()) "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CATTRIBUTE_GROUP,
                    .CATTRIBUTE_ID,
                    .CPROGRAM_ID,
                    .CCR_ID,
                    .CVERSION,
                    .CPROJECT_ID,
                    .CSESSION_ID,
                    .CSTATUS,
                    .CDESCRIPTION,
                    .CUPDATE_BY,
                    .CCREATE_BY)

                ElseIf poCRUDMode = eCRUDMode.EditMode Then
                    lcQuery = "UPDATE CSM_PROGRAM_CHANGES "
                    lcQuery += "SET "
                    lcQuery += "CVERSION = '{6}', "
                    lcQuery += "CPROJECT_ID = '{7}', "
                    lcQuery += "CSESSION_ID = '{8}', "
                    lcQuery += "CDESCRIPTION = '{9}', "
                    lcQuery += "CUPDATE_BY = '{10}', "
                    lcQuery += "DUPDATE_DATE = GETDATE() "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                    lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                    lcQuery += "AND CPROGRAM_ID = '{4}' "
                    lcQuery += "AND CCR_ID = '{5}' "
                    lcQuery = String.Format(lcQuery, _
                                            .CCOMPANY_ID, _
                                            .CAPPS_CODE, _
                                            .CATTRIBUTE_GROUP, _
                                            .CATTRIBUTE_ID, _
                                            .CPROGRAM_ID, _
                                            .CCR_ID, _
                                            .CVERSION, _
                                            .CPROJECT_ID, _
                                            .CSESSION_ID, _
                                            .CDESCRIPTION, _
                                            .CUPDATE_BY)
                End If
            End With
            loDb.SqlExecNonQuery(lcQuery, loConn, True)
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Sub ScheduleCR(poPar As CSM00600KeyDTO)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db
        Dim lcQuery As String
        Dim loConn As DbConnection
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcRtn As String = "OK"

        Try
            Using TransScope As New TransactionScope(TransactionScopeOption.Required)
                ' update schedule
                loCmd = loDb.GetCommand()
                lcQuery = "EXEC RSP_CR_Schedule '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', @CRET_MSG OUTPUT "
                With poPar
                    lcQuery = String.Format(lcQuery, _
                                            .CCOMPANY_ID, _
                                            .CAPPS_CODE, _
                                            .CATTRIBUTE_GROUP, _
                                            .CATTRIBUTE_ID, _
                                            .CPROGRAM_ID, _
                                            .CCR_ID, _
                                            .CUSER_ID)
                End With
                loCmd.CommandText = lcQuery
                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@CRET_MSG"
                    .DbType = DbType.String
                    .Size = 50
                    .Direction = ParameterDirection.Output
                End With
                loCmd.Parameters.Add(loPar)
                loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)

                If loCmd.Parameters("@CRET_MSG") Is Nothing Then
                    lcRtn = "UNKNOWN_ERROR"
                Else
                    lcRtn = loCmd.Parameters("@CRET_MSG").Value
                End If
                If Not lcRtn.Equals("OK") Then
                    loEx.Add(lcRtn, lcRtn)
                    Exit Try
                End If
                TransScope.Complete()
            End Using

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

End Class
