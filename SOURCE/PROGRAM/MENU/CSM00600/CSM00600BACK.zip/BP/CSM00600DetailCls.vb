﻿Imports R_BackEnd
Imports R_Common
Imports System.Data.Common
Imports ServerHelper.General

Public Class CSM00600DetailCls
    Inherits R_BusinessObject(Of CSM00600DetailDTO)

    Public Function GetCRDetailList(poKey As CSM00600KeyDTO) As List(Of CSM00600DetailGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00600DetailGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CSM_CHANGES_DETAIL (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                lcQuery += "AND CPROGRAM_ID = '{4}' "
                lcQuery += "AND CCR_ID = '{5}' "

                lcQuery = "SELECT A.*, "
                lcQuery += "ISNULL(C.CDESCRIPTION, '---') AS CISSUE_DESCRIPTION "
                lcQuery += "FROM CSM_CHANGES_DETAIL A (NOLOCK) "
                lcQuery += "JOIN CSM_PROGRAM_CHANGES B (NOLOCK) "
                lcQuery += "ON B.CCOMPANY_ID = A.CCOMPANY_ID "
                lcQuery += "AND B.CAPPS_CODE = A.CAPPS_CODE "
                lcQuery += "AND B.CATTRIBUTE_GROUP = A.CATTRIBUTE_GROUP "
                lcQuery += "AND B.CATTRIBUTE_ID = A.CATTRIBUTE_ID "
                lcQuery += "AND B.CPROGRAM_ID = A.CPROGRAM_ID "
                lcQuery += "AND B.CCR_ID = A.CCR_ID "
                lcQuery += "LEFT JOIN CST_ISSUES C (NOLOCK) "
                lcQuery += "ON C.CCOMPANY_ID = A.CCOMPANY_ID "
                lcQuery += "AND C.CAPPS_CODE = A.CAPPS_CODE "
                lcQuery += "AND C.CVERSION = B.CVERSION "
                lcQuery += "AND C.CPROJECT_ID = B.CPROJECT_ID "
                lcQuery += "AND C.CSESSION_ID = B.CSESSION_ID "
                lcQuery += "AND C.CATTRIBUTE_GROUP = A.CATTRIBUTE_GROUP "
                lcQuery += "AND C.CATTRIBUTE_ID = A.CATTRIBUTE_ID "
                lcQuery += "AND C.CITEM_ID = A.CPROGRAM_ID "
                lcQuery += "AND C.CISSUE_ID = A.CISSUE_ID "
                lcQuery += "WHERE A.CCOMPANY_ID = '{0}' "
                lcQuery += "AND A.CAPPS_CODE = '{1}' "
                lcQuery += "AND A.CATTRIBUTE_GROUP = '{2}' "
                lcQuery += "AND A.CATTRIBUTE_ID = '{3}' "
                lcQuery += "AND A.CPROGRAM_ID = '{4}' "
                lcQuery += "AND A.CCR_ID = '{5}' "

                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CATTRIBUTE_GROUP, _
                                        .CATTRIBUTE_ID, _
                                        .CPROGRAM_ID, _
                                        .CCR_ID)

            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00600DetailGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Deleting(poEntity As CSM00600DetailDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcRtn As String

        Try
            loConn = loDb.GetConnection()

            With poEntity

                'validation
                loCmd = loDb.GetCommand()
                lcQuery = "EXEC RSP_Delete_CR_Validation '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', 'DETAIL', @CRET_MSG OUTPUT "
                With poEntity
                    lcQuery = String.Format(lcQuery, _
                                            .CCOMPANY_ID, _
                                            .CAPPS_CODE, _
                                            .CATTRIBUTE_GROUP, _
                                            .CATTRIBUTE_ID, _
                                            .CPROGRAM_ID, _
                                            .CCR_ID, _
                                            .CSEQUENCE)
                End With
                loCmd.CommandText = lcQuery
                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@CRET_MSG"
                    .DbType = DbType.String
                    .Size = 50
                    .Direction = ParameterDirection.Output
                End With
                loCmd.Parameters.Add(loPar)
                loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)

                If loCmd.Parameters("@CRET_MSG") Is Nothing Then
                    lcRtn = "UNKNOWN_ERROR"
                Else
                    lcRtn = loCmd.Parameters("@CRET_MSG").Value
                End If

                If Not lcRtn.Equals("OK") Then
                    Throw New Exception(lcRtn)
                End If

                'delete project user table
                lcQuery = "DELETE FROM "
                lcQuery += "CSM_CHANGES_DETAIL "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                lcQuery += "AND CPROGRAM_ID = '{4}' "
                lcQuery += "AND CCR_ID = '{5}' "
                lcQuery += "AND CSEQUENCE = '{6}' "
                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CATTRIBUTE_GROUP, _
                                        .CATTRIBUTE_ID, _
                                        .CPROGRAM_ID, _
                                        .CCR_ID, _
                                        .CSEQUENCE)
                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As CSM00600DetailDTO) As CSM00600DetailDTO
        Dim lcQuery As String
        Dim loResult As CSM00600DetailDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CSM_CHANGES_DETAIL "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                lcQuery += "AND CPROGRAM_ID = '{4}' "
                lcQuery += "AND CCR_ID = '{5}' "
                lcQuery += "AND CSEQUENCE = '{6}' "
                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CATTRIBUTE_GROUP, _
                                        .CATTRIBUTE_ID, _
                                        .CPROGRAM_ID, _
                                        .CCR_ID, _
                                        .CSEQUENCE)
                loResult = loDb.SqlExecObjectQuery(Of CSM00600DetailDTO)(lcQuery).FirstOrDefault

            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As CSM00600DetailDTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loKey As New CSM00600KeyDTO
        Dim lcScheduleID As String
        Dim loValidIssue As CSM00600ValidIssueDTO

        Try
            loConn = loDb.GetConnection()

            With poNewEntity
                If poCRUDMode = eCRUDMode.AddMode Then

                    .CUPDATE_BY = .CUPDATE_BY
                    .CCREATE_BY = .CUPDATE_BY

                    ' get CCR_ID
                    lcQuery = "EXEC RSP_Get_CR_Id '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', 'DETAIL' "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CPROGRAM_ID, .CCR_ID)

                    loKey = loDb.SqlExecObjectQuery(Of CSM00600KeyDTO)(lcQuery).FirstOrDefault
                    If loKey IsNot Nothing Then
                        .CSEQUENCE = loKey.CSEQUENCE
                    Else
                        Throw New Exception("NO_SEQUENCE")
                    End If

                    ' get issue schedule
                    lcScheduleID = ""
                    If Not String.IsNullOrEmpty(.CISSUE_ID) Then
                        lcQuery = "SELECT CSCHEDULE_ID "
                        lcQuery += "FROM "
                        lcQuery += "CST_ISSUES (NOLOCK) "
                        lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                        lcQuery += "AND CAPPS_CODE = '{1}' "
                        lcQuery += "AND CVERSION = '{2}' "
                        lcQuery += "AND CPROJECT_ID = '{3}' "
                        lcQuery += "AND CSESSION_ID = '{4}' "
                        lcQuery += "AND CATTRIBUTE_GROUP = '{5}' "
                        lcQuery += "AND CATTRIBUTE_ID = '{6}' "
                        lcQuery += "AND CITEM_ID = '{7}' "
                        lcQuery += "AND CISSUE_ID = '{8}' "
                        lcQuery = String.Format(lcQuery, _
                                                .CCOMPANY_ID, _
                                                .CAPPS_CODE, _
                                                .CVERSION, _
                                                .CPROJECT_ID, _
                                                .CSESSION_ID, _
                                                .CATTRIBUTE_GROUP, _
                                                .CATTRIBUTE_ID, _
                                                .CPROGRAM_ID, _
                                                .CISSUE_ID)
                        loValidIssue = loDb.SqlExecObjectQuery(Of CSM00600ValidIssueDTO)(lcQuery).FirstOrDefault
                        If loValidIssue IsNot Nothing Then
                            If loValidIssue.LOK Then
                                Throw New Exception("OK_ISSUE")
                            Else
                                lcScheduleID = loValidIssue.CSCHEDULE_ID
                            End If
                        Else
                            Throw New Exception("NO_ISSUE")
                        End If
                    End If

                    lcQuery = "INSERT INTO CSM_CHANGES_DETAIL ("
                    lcQuery += "CCOMPANY_ID, "
                    lcQuery += "CAPPS_CODE, "
                    lcQuery += "CATTRIBUTE_GROUP, "
                    lcQuery += "CATTRIBUTE_ID, "
                    lcQuery += "CPROGRAM_ID, "
                    lcQuery += "CCR_ID, "
                    lcQuery += "CSEQUENCE, "
                    lcQuery += "CISSUE_ID, "
                    lcQuery += "CDESCRIPTION, "
                    lcQuery += "CSCHEDULE_ID, "
                    lcQuery += "CUPDATE_BY, "
                    lcQuery += "DUPDATE_DATE, "
                    lcQuery += "CCREATE_BY, "
                    lcQuery += "DCREATE_DATE) "
                    lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', GETDATE(), '{11}', GETDATE()) "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CATTRIBUTE_GROUP,
                    .CATTRIBUTE_ID,
                    .CPROGRAM_ID,
                    .CCR_ID,
                    .CSEQUENCE,
                    .CISSUE_ID,
                    .CDESCRIPTION,
                    lcScheduleID,
                    .CUPDATE_BY,
                    .CCREATE_BY)

                ElseIf poCRUDMode = eCRUDMode.EditMode Then
                    lcQuery = "UPDATE CSM_CHANGES_DETAIL "
                    lcQuery += "SET "
                    lcQuery += "CISSUE_ID = '{7}', "
                    lcQuery += "CDESCRIPTION = '{8}', "
                    lcQuery += "LCANCEL = {9}, "
                    lcQuery += "CUPDATE_BY = '{10}', "
                    lcQuery += "DUPDATE_DATE = GETDATE() "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                    lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                    lcQuery += "AND CPROGRAM_ID = '{4}' "
                    lcQuery += "AND CCR_ID = '{5}' "
                    lcQuery += "AND CSEQUENCE = '{6}' "
                    lcQuery = String.Format(lcQuery, _
                                            .CCOMPANY_ID, _
                                            .CAPPS_CODE, _
                                            .CATTRIBUTE_GROUP, _
                                            .CATTRIBUTE_ID, _
                                            .CPROGRAM_ID, _
                                            .CCR_ID, _
                                            .CSEQUENCE, _
                                            .CISSUE_ID, _
                                            .CDESCRIPTION, _
                                            getBit(.LCANCEL), _
                                            .CUPDATE_BY)
                End If
            End With
            loDb.SqlExecNonQuery(lcQuery, loConn, True)
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

End Class
