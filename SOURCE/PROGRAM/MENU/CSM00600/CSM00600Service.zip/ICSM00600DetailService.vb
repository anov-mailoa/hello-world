﻿Imports System.ServiceModel
Imports R_BackEnd
Imports CSM00600Back
Imports R_Common
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00600DetailService" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00600DetailService
    Inherits R_IServicebase(Of CSM00600DetailDTO)

    '<OperationContract(Action:="getIssueCombo", ReplyAction:="getIssueCombo")> _
    '<FaultContract(GetType(R_ServiceExceptions))> _
    'Function GetIssueCombo(key As RCustDBIssueKeyDTO) As List(Of RCustDBIssueComboDTO)

End Interface
