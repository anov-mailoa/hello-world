﻿Imports R_Common
Imports CSM00600Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00600DetailStreamingService" in code, svc and config file together.
Public Class CSM00600DetailStreamingService
    Implements ICSM00600DetailStreamingService

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of CSM00600Back.CSM00600DetailGridDTO)) Implements ICSM00600DetailStreamingService.Dummy

    End Sub

    Public Function GetCRDetailList() As System.ServiceModel.Channels.Message Implements ICSM00600DetailStreamingService.GetCRDetailList
        Dim loException As New R_Exception
        Dim loCls As New CSM00600DetailCls
        Dim loRtnTemp As List(Of CSM00600DetailGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00600KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CATTRIBUTE_ID = R_Utility.R_GetStreamingContext("cAttributeId")
                .CPROGRAM_ID = R_Utility.R_GetStreamingContext("cProgramId")
                .CCR_ID = R_Utility.R_GetStreamingContext("cCRId")
            End With

            loRtnTemp = loCls.GetCRDetailList(loTableKey)

            loRtn = R_StreamUtility(Of CSM00600DetailGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getCRDetailList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

End Class
