﻿Imports R_Common
Imports CSM00600Back
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00600Service" in code, svc and config file together.
Public Class CSM00600Service
    Implements ICSM00600Service

    Public Sub Svc_R_Delete(poEntity As CSM00600Back.CSM00600DTO) Implements R_BackEnd.R_IServicebase(Of CSM00600Back.CSM00600DTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New CSM00600Cls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As CSM00600Back.CSM00600DTO) As CSM00600Back.CSM00600DTO Implements R_BackEnd.R_IServicebase(Of CSM00600Back.CSM00600DTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New CSM00600Cls
        Dim loRtn As CSM00600DTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As CSM00600Back.CSM00600DTO, poCRUDMode As R_Common.eCRUDMode) As CSM00600Back.CSM00600DTO Implements R_BackEnd.R_IServicebase(Of CSM00600Back.CSM00600DTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New CSM00600Cls
        Dim loRtn As CSM00600DTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetAppCombo(companyId As String, userId As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseAppComboDTO) Implements ICSM00600Service.GetAppCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseAppComboDTO)

        Try
            loRtn = loCls.GetAppCombo(companyId, userId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetVersionCombo(companyId As String, appsCode As String) As System.Collections.Generic.List(Of RLicenseBack.RCustDBVersionComboDTO) Implements ICSM00600Service.GetVersionCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBVersionComboDTO)

        Try
            loRtn = loCls.GetVersionCombo(companyId, appsCode)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Dummy() As System.Collections.Generic.List(Of CSM00600Back.CSM00600KeyDTO) Implements ICSM00600Service.Dummy

    End Function

    Public Function GetAttributeCombo(companyId As String, appsCode As String, attributeGroup As String) As System.Collections.Generic.List(Of RLicenseBack.RCustDBAttributeComboDTO) Implements ICSM00600Service.GetAttributeCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBAttributeComboDTO)

        Try
            loRtn = loCls.GetAttributeCombo(companyId, appsCode, attributeGroup)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetAttributeGroupCombo(companyId As String, appsCode As String) As System.Collections.Generic.List(Of RLicenseBack.RCustDBAttributeGroupComboDTO) Implements ICSM00600Service.GetAttributeGroupCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBAttributeGroupComboDTO)

        Try
            loRtn = loCls.GetAttributeGroupCombo(companyId, appsCode)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetItemCombo(key As RLicenseBack.RCustDBItemKeyDTO) As System.Collections.Generic.List(Of RLicenseBack.RCustDBItemComboDTO) Implements ICSM00600Service.GetItemCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBItemComboDTO)

        Try
            loRtn = loCls.GetItemCombo(key)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub ScheduleCR(poPar As CSM00600Back.CSM00600KeyDTO) Implements ICSM00600Service.ScheduleCR
        Dim loException As New R_Exception
        Dim loCls As New CSM00600Cls

        Try
            loCls.ScheduleCR(poPar)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

End Class
