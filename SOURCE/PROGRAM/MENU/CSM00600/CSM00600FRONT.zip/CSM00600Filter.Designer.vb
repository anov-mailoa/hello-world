﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSM00600Filter
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.R_ReturnPopUp1 = New R_FrontEnd.R_ReturnPopUp()
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.cboApplication = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsItem = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblItem = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblAttribute = New R_FrontEnd.R_RadLabel(Me.components)
        Me.cboAttribute = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsAttribute = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblAttributeGroup = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtAttributeGroup = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lupItem = New R_FrontEnd.R_LookUp(Me.components)
        Me.txtItemName = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtItemID = New R_FrontEnd.R_RadTextBox(Me.components)
        CType(Me.R_ReturnPopUp1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblAttribute, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboAttribute, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsAttribute, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblAttributeGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtAttributeGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lupItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtItemName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtItemID, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'R_ReturnPopUp1
        '
        Me.R_ReturnPopUp1.Location = New System.Drawing.Point(356, 121)
        Me.R_ReturnPopUp1.Name = "R_ReturnPopUp1"
        Me.R_ReturnPopUp1.Size = New System.Drawing.Size(162, 31)
        Me.R_ReturnPopUp1.TabIndex = 0
        '
        'bsApps
        '
        Me.bsApps.DataSource = GetType(CSM00600Front.CSM00600ServiceRef.RLicenseAppComboDTO)
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(12, 12)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 33
        Me.lblApplication.Text = "Application..."
        '
        'cboApplication
        '
        Me.cboApplication.DataSource = Me.bsApps
        Me.cboApplication.DisplayMember = "CAPPS_NAME"
        Me.cboApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboApplication.Location = New System.Drawing.Point(118, 12)
        Me.cboApplication.Name = "cboApplication"
        Me.cboApplication.R_ConductorGridSource = Nothing
        Me.cboApplication.R_ConductorSource = Nothing
        Me.cboApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboApplication.Size = New System.Drawing.Size(400, 20)
        Me.cboApplication.TabIndex = 34
        Me.cboApplication.Text = "R_RadDropDownList1"
        Me.cboApplication.ValueMember = "CAPPS_CODE"
        '
        'bsItem
        '
        Me.bsItem.DataSource = GetType(CSM00600Front.CSM00600ServiceRef.RCustDBItemComboDTO)
        '
        'lblItem
        '
        Me.lblItem.AutoSize = False
        Me.lblItem.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblItem.Location = New System.Drawing.Point(12, 91)
        Me.lblItem.Name = "lblItem"
        Me.lblItem.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblItem.R_ResourceId = "lblItem"
        Me.lblItem.Size = New System.Drawing.Size(100, 18)
        Me.lblItem.TabIndex = 51
        Me.lblItem.Text = "Application..."
        '
        'lblAttribute
        '
        Me.lblAttribute.AutoSize = False
        Me.lblAttribute.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblAttribute.Location = New System.Drawing.Point(12, 64)
        Me.lblAttribute.Name = "lblAttribute"
        Me.lblAttribute.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblAttribute.R_ResourceId = "lblAttribute"
        Me.lblAttribute.Size = New System.Drawing.Size(100, 18)
        Me.lblAttribute.TabIndex = 50
        Me.lblAttribute.Text = "Application..."
        '
        'cboAttribute
        '
        Me.cboAttribute.DataSource = Me.bsAttribute
        Me.cboAttribute.DisplayMember = "CATTRIBUTE_NAME"
        Me.cboAttribute.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboAttribute.Location = New System.Drawing.Point(118, 64)
        Me.cboAttribute.Name = "cboAttribute"
        Me.cboAttribute.R_ConductorGridSource = Nothing
        Me.cboAttribute.R_ConductorSource = Nothing
        Me.cboAttribute.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboAttribute.Size = New System.Drawing.Size(206, 20)
        Me.cboAttribute.TabIndex = 49
        Me.cboAttribute.Text = "R_RadDropDownList1"
        Me.cboAttribute.ValueMember = "CATTRIBUTE_ID"
        '
        'bsAttribute
        '
        Me.bsAttribute.DataSource = GetType(CSM00600Front.CSM00600ServiceRef.RCustDBAttributeComboDTO)
        '
        'lblAttributeGroup
        '
        Me.lblAttributeGroup.AutoSize = False
        Me.lblAttributeGroup.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblAttributeGroup.Location = New System.Drawing.Point(12, 39)
        Me.lblAttributeGroup.Name = "lblAttributeGroup"
        Me.lblAttributeGroup.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblAttributeGroup.R_ResourceId = "lblAttributeGroup"
        Me.lblAttributeGroup.Size = New System.Drawing.Size(100, 18)
        Me.lblAttributeGroup.TabIndex = 48
        Me.lblAttributeGroup.Text = "Application..."
        '
        'txtAttributeGroup
        '
        Me.txtAttributeGroup.Location = New System.Drawing.Point(118, 38)
        Me.txtAttributeGroup.Name = "txtAttributeGroup"
        Me.txtAttributeGroup.R_ConductorGridSource = Nothing
        Me.txtAttributeGroup.R_ConductorSource = Nothing
        Me.txtAttributeGroup.R_UDT = Nothing
        Me.txtAttributeGroup.ReadOnly = True
        Me.txtAttributeGroup.Size = New System.Drawing.Size(206, 20)
        Me.txtAttributeGroup.TabIndex = 53
        Me.txtAttributeGroup.TabStop = False
        '
        'lupItem
        '
        Me.lupItem.Location = New System.Drawing.Point(224, 90)
        Me.lupItem.Name = "lupItem"
        Me.lupItem.R_ConductorGridSource = Nothing
        Me.lupItem.R_ConductorSource = Nothing
        Me.lupItem.R_DescriptionId = Nothing
        Me.lupItem.R_Field_Description = ""
        Me.lupItem.R_Field_Value = ""
        Me.lupItem.R_ResourceId = Nothing
        Me.lupItem.R_TextBox_Description = Me.txtItemName
        Me.lupItem.R_TextBox_Value = Me.txtItemID
        Me.lupItem.R_Title = Nothing
        Me.lupItem.Size = New System.Drawing.Size(30, 20)
        Me.lupItem.TabIndex = 73
        Me.lupItem.Text = "..."
        '
        'txtItemName
        '
        Me.txtItemName.Enabled = False
        Me.txtItemName.Location = New System.Drawing.Point(260, 90)
        Me.txtItemName.Name = "txtItemName"
        Me.txtItemName.R_ConductorGridSource = Nothing
        Me.txtItemName.R_ConductorSource = Nothing
        Me.txtItemName.R_UDT = Nothing
        Me.txtItemName.Size = New System.Drawing.Size(258, 20)
        Me.txtItemName.TabIndex = 71
        '
        'txtItemID
        '
        Me.txtItemID.Location = New System.Drawing.Point(118, 90)
        Me.txtItemID.Name = "txtItemID"
        Me.txtItemID.R_ConductorGridSource = Nothing
        Me.txtItemID.R_ConductorSource = Nothing
        Me.txtItemID.R_UDT = Nothing
        Me.txtItemID.Size = New System.Drawing.Size(100, 20)
        Me.txtItemID.TabIndex = 72
        '
        'CSM00600Filter
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(531, 163)
        Me.ControlBox = False
        Me.Controls.Add(Me.lupItem)
        Me.Controls.Add(Me.txtItemID)
        Me.Controls.Add(Me.txtItemName)
        Me.Controls.Add(Me.txtAttributeGroup)
        Me.Controls.Add(Me.lblItem)
        Me.Controls.Add(Me.lblAttribute)
        Me.Controls.Add(Me.cboAttribute)
        Me.Controls.Add(Me.lblAttributeGroup)
        Me.Controls.Add(Me.lblApplication)
        Me.Controls.Add(Me.cboApplication)
        Me.Controls.Add(Me.R_ReturnPopUp1)
        Me.Name = "CSM00600Filter"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "Filter"
        CType(Me.R_ReturnPopUp1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblAttribute, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboAttribute, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsAttribute, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblAttributeGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtAttributeGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lupItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtItemName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtItemID, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents R_ReturnPopUp1 As R_FrontEnd.R_ReturnPopUp
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents cboApplication As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblItem As R_FrontEnd.R_RadLabel
    Friend WithEvents lblAttribute As R_FrontEnd.R_RadLabel
    Friend WithEvents cboAttribute As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblAttributeGroup As R_FrontEnd.R_RadLabel
    Friend WithEvents bsAttribute As System.Windows.Forms.BindingSource
    Friend WithEvents bsItem As System.Windows.Forms.BindingSource
    Friend WithEvents txtAttributeGroup As R_FrontEnd.R_RadTextBox
    Friend WithEvents lupItem As R_FrontEnd.R_LookUp
    Friend WithEvents txtItemName As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtItemID As R_FrontEnd.R_RadTextBox

End Class
