﻿Imports CSM00600FrontResources
Imports R_Common
Imports CSM00600Front.CSM00600DetailServiceRef
Imports R_FrontEnd
Imports ClientHelper
Imports CSM00600Front.CSM00600DetailStreamingServiceRef
Imports System.ServiceModel.Channels
Imports System.ServiceModel
Imports CSM00600Front.CSM00600ServiceRef

Public Class CSM00600Detail

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSM00600Service/CSM00600DetailService.svc"
    Dim C_ServiceNameStream As String = "CSM00600Service/CSM00600DetailStreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _CATTRIBUTEGROUP As String
    Dim _CATTRIBUTEID As String
    Dim _CPROGRAMID As String
    Dim _CCRID As String
    Dim _CVERSION As String
    Dim _CPROJECTID As String
    Dim _CSESSIONID As String
    Dim _CUSER_NAME As String
    Dim _CSTATUS As String
    Dim _LOK As Boolean
#End Region

#Region " FORM Events "

    Private Sub CSM00600Detail_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loSvc As CSM00600DetailServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00600DetailService, CSM00600DetailServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            With CType(poParameter, CSM00600DetailParamDTO)
                _CAPPSCODE = .OGRID_KEY.CAPPS_CODE
                _CATTRIBUTEGROUP = .OGRID_KEY.CATTRIBUTE_GROUP
                _CATTRIBUTEID = .OGRID_KEY.CATTRIBUTE_ID
                _CPROGRAMID = .OGRID_KEY.CPROGRAM_ID
                _CCRID = .OGRID_KEY.CCR_ID
                _CVERSION = .CVERSION
                _CPROJECTID = .CPROJECT_ID
                _CSESSIONID = .CSESSION_ID
                _CSTATUS = .CSTATUS
                txtApplication.Text = .CAPPS_NAME
                txtAttributeGroup.Text = .OGRID_KEY.CATTRIBUTE_GROUP
                txtAttribute.Text = .CATTRIBUTE_NAME
                txtItem.Text = .CITEM_NAME
                txtCRId.Text = .OGRID_KEY.CCR_ID
            End With

            ' Issue combo
            'Dim loIssueKey As New RCustDBIssueKeyDTO
            'Dim loIssueCombo As New List(Of RCustDBIssueComboDTO)
            'With loIssueKey
            '    .CCOMPANY_ID = _CCOMPID
            '    .CAPPS_CODE = _CAPPSCODE
            '    .CVERSION = CType(poParameter, CSM00600DetailParamDTO).CVERSION
            '    .CPROJECT_ID = CType(poParameter, CSM00600DetailParamDTO).CPROJECT_ID
            '    .CSESSION_ID = CType(poParameter, CSM00600DetailParamDTO).CSESSION_ID
            '    .CATTRIBUTE_GROUP = CType(poParameter, CSM00600DetailParamDTO).OGRID_KEY.CATTRIBUTE_GROUP
            '    .CATTRIBUTE_ID = CType(poParameter, CSM00600DetailParamDTO).OGRID_KEY.CATTRIBUTE_ID
            '    .CITEM_ID = CType(poParameter, CSM00600DetailParamDTO).OGRID_KEY.CPROGRAM_ID
            '    .CISSUE_TYPE = "DESIGN"
            '    .LOUTSTANDING_ONLY = False
            'End With
            'loIssueCombo = loSvc.GetIssueCombo(loIssueKey)
            'bsIssue.DataSource = loIssueCombo

            gvCRDetail.R_RefreshGrid(CType(poParameter, CSM00600DetailParamDTO).OGRID_KEY)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub CSM00600Detail_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " GRIDVIEW Events "

    Private Sub gvCRDetail_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvCRDetail.DataBindingComplete
        gvCRDetail.BestFitColumns()
    End Sub

    Private Sub gvCRDetail_R_Before_Open_LookUpForm(sender As Object, e As Telerik.WinControls.UI.EditorRequiredEventArgs, ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles gvCRDetail.R_Before_Open_LookUpForm
        poTargetForm = New CSM00600IssueList
        poParameter = New CSM00600IssueParamDTO With {.CCOMPANY_ID = _CCOMPID, _
                                                      .CAPPS_CODE = _CAPPSCODE, _
                                                      .CVERSION = _CVERSION, _
                                                      .CPROJECT_ID = _CPROJECTID, _
                                                      .CSESSION_ID = _CSESSIONID, _
                                                      .CATTRIBUTE_GROUP = _CATTRIBUTEGROUP, _
                                                      .CATTRIBUTE_ID = _CATTRIBUTEID, _
                                                      .CITEM_ID = _CPROGRAMID, _
                                                      .CISSUE_TYPE = "DESIGN"}
    End Sub

    Private Sub gvCRDetail_R_CheckGridAdd(poEntityCollection As Object, ByRef plAllowGridAdd As Boolean) Handles gvCRDetail.R_CheckGridAdd
        plAllowGridAdd = (_CSTATUS = "NEW")
    End Sub

    Private Sub gvCRDetail_R_CheckGridDelete(poEntityCollection As Object, ByRef plAllowGridDelete As Boolean) Handles gvCRDetail.R_CheckGridDelete
        plAllowGridDelete = (_CSTATUS = "NEW")
    End Sub

    Private Sub gvCRDetail_R_Return_LookUp(sender As Object, e As Telerik.WinControls.UI.EditorRequiredEventArgs, poReturnObject As Object) Handles gvCRDetail.R_Return_LookUp
        gvCRDetail.CurrentRow.Cells("_CISSUE_ID").Value = poReturnObject.CISSUE_ID
        gvCRDetail.CurrentRow.Cells("_CISSUE_DESCRIPTION").Value = poReturnObject.CDESCRIPTION
    End Sub

    Private Sub gvCRDetail_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvCRDetail.R_Saving
        With CType(poEntity, CSM00600DetailDTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = _CAPPSCODE
            ._CATTRIBUTE_GROUP = _CATTRIBUTEGROUP
            ._CATTRIBUTE_ID = _CATTRIBUTEID
            ._CPROGRAM_ID = _CPROGRAMID
            ._CCR_ID = _CCRID
            ._CVERSION = _CVERSION
            ._CPROJECT_ID = _CPROJECTID
            ._CSESSION_ID = _CSESSIONID
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With

    End Sub

    Private Sub gvCRDetail_R_ServiceDelete(poEntity As Object) Handles gvCRDetail.R_ServiceDelete
        Dim loService As CSM00600DetailServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00600DetailService, CSM00600DetailServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String
        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As FaultException
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvCRDetail_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvCRDetail.R_ServiceGetListRecord
        Dim loServiceStream As CSM00600DetailStreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00600DetailStreamingService, CSM00600DetailStreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00600DetailGridDTO)
        Dim loListEntity As New List(Of CSM00600DetailDTO)

        Try
            With CType(poEntity, CSM00600KeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cAttributeGroup", .CATTRIBUTE_GROUP)
                R_Utility.R_SetStreamingContext("cAttributeId", .CATTRIBUTE_ID)
                R_Utility.R_SetStreamingContext("cProgramId", .CPROGRAM_ID)
                R_Utility.R_SetStreamingContext("cCRId", .CCR_ID)
            End With

            loRtn = loServiceStream.GetCRDetailList()
            loStreaming = R_StreamUtility(Of CSM00600DetailGridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00600DetailGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New CSM00600DetailDTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                                 ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                                 ._CATTRIBUTE_GROUP = loDto.CATTRIBUTE_GROUP,
                                                                 ._CATTRIBUTE_ID = loDto.CATTRIBUTE_ID,
                                                                 ._CPROGRAM_ID = loDto.CPROGRAM_ID,
                                                                 ._CCR_ID = loDto.CCR_ID,
                                                                 ._CSEQUENCE = loDto.CSEQUENCE,
                                                                 ._CISSUE_ID = loDto.CISSUE_ID,
                                                                 ._CISSUE_DESCRIPTION = loDto.CISSUE_DESCRIPTION,
                                                                 ._CDESCRIPTION = loDto.CDESCRIPTION,
                                                                 ._LCANCEL = loDto.LCANCEL,
                                                                 ._CSCHEDULE_ID = loDto.CSCHEDULE_ID,
                                                                  ._CCREATE_BY = loDto.CCREATE_BY,
                                                                  ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                                  ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                                  ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvCRDetail_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvCRDetail.R_ServiceGetRecord
        Dim loService As CSM00600DetailServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00600DetailService, CSM00600DetailServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New CSM00600DetailDTO With {._CCOMPANY_ID = _CCOMPID,
                                                                             ._CAPPS_CODE = _CAPPSCODE,
                                                                             ._CATTRIBUTE_GROUP = _CATTRIBUTEGROUP,
                                                                             ._CATTRIBUTE_ID = _CATTRIBUTEID,
                                                                             ._CPROGRAM_ID = _CPROGRAMID,
                                                                                   ._CCR_ID = _CCRID,
                                                                             ._CSEQUENCE = CType(bsGvCRDetail.Current, CSM00600DetailDTO)._CSEQUENCE})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvCRDetail_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvCRDetail.R_ServiceSave
        Dim loService As CSM00600DetailServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00600DetailService, CSM00600DetailServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As FaultException
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvCRDetail_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvCRDetail.R_Validation
        Dim loEx As New R_Exception()

        Try
            With poGridCellCollection
                If String.IsNullOrWhiteSpace(.Item("_CDESCRIPTION").Value) Then
                    loEx.Add("CSM00600_02", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00600_02"))
                    plCancel = True
                End If

                If _LOK Then
                    loEx.Add("CSM00600_01", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00600_01"))
                    plCancel = True
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub
#End Region

#Region " SCHEDULE button "
    Private Sub btnSchedule_Click(sender As Object, e As System.EventArgs) Handles btnSchedule.Click
        Dim loException As New R_Exception
        Dim loService As CSM00600ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00600Service, CSM00600ServiceClient)(e_ServiceClientType.RegularService, "CSM00600Service/CSM00600Service.svc")
        Dim loTableKey As New CSM00600KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = _CAPPSCODE
                .CATTRIBUTE_GROUP = _CATTRIBUTEGROUP
                .CATTRIBUTE_ID = _CATTRIBUTEID
                .CPROGRAM_ID = _CPROGRAMID
                .CCR_ID = _CCRID
                .CUSER_ID = _CUSERID
            End With
            loService.ScheduleCR(loTableKey)
            gvCRDetail.R_RefreshGrid(loTableKey)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        If loException.Haserror Then
            Me.R_DisplayException(loException)
        End If
    End Sub
#End Region

End Class
