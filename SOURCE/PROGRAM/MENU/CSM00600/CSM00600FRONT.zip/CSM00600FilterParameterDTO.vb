﻿Imports CSM00600Front.CSM00600ServiceRef

<Serializable()> _
Public Class CSM00600FilterParameterDTO
    Public Property OFILTER_KEY As CSM00600KeyDTO
    Public Property OAPPS_LIST As List(Of RLicenseAppComboDTO)
    Public Property OATTRIBUTE_GROUP_LIST As List(Of RCustDBAttributeGroupComboDTO)
    Public Property OATTRIBUTE_LIST As List(Of RCustDBAttributeComboDTO)
    Public Property OITEM_LIST As List(Of RCustDBItemComboDTO)
    Public Property CAPPS_NAME As String
    Public Property CATTRIBUTE_NAME As String
    Public Property CITEM_NAME As String
    Public Property LSPEC As Boolean

    Sub New()
        ' initialization
        OFILTER_KEY = New CSM00600KeyDTO
        With OFILTER_KEY
            .CCOMPANY_ID = ""
            .CAPPS_CODE = ""
            .CATTRIBUTE_GROUP = "PROGRAM"
            .CATTRIBUTE_ID = ""
            .CPROGRAM_ID = ""
        End With
        CAPPS_NAME = ""
        CATTRIBUTE_NAME = ""
        CITEM_NAME = ""
        LSPEC = False
    End Sub
End Class
