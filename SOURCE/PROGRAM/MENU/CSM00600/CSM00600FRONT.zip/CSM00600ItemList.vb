﻿Imports CSM00600FrontResources
Imports R_Common
Imports CSM00600Front.CSM00600StreamingServiceRef
Imports R_FrontEnd
Imports System.ServiceModel.Channels
Imports CSM00600Front.CSM00600ServiceRef

Public Class CSM00600ItemList

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSM00600Service/CSM00600Service.svc"
    Dim C_ServiceNameStream As String = "CSM00600Service/CSM00600StreamingService.svc"
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _CVERSION As String
    Dim _INIT As Boolean = False
#End Region

#Region " FORM Events "

    Private Sub CSM00600Item_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loKey As New RCustDBItemKeyDTO

        Try
            gvManager.R_RefreshGrid(poParameter)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub
#End Region

#Region " GRIDVIEW Events "

    Private Sub gvManager_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvManager.DataBindingComplete
        With gvManager
            .BestFitColumns()
        End With
    End Sub

    Private Sub gvManager_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvManager.R_ServiceGetListRecord
        Dim loServiceStream As CSM00600StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00600StreamingService, CSM00600StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00600Front.CSM00600StreamingServiceRef.RCustDBItemComboDTO)
        Dim loListEntity As New List(Of CSM00600Front.CSM00600StreamingServiceRef.RCustDBItemComboDTO)

        Try
            With CType(poEntity, RCustDBItemKeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cAttributeGroup", .CATTRIBUTE_GROUP)
                R_Utility.R_SetStreamingContext("cAttributeId", .CATTRIBUTE_ID)

                loRtn = loServiceStream.GetItemList()
                loStreaming = R_StreamUtility(Of CSM00600Front.CSM00600StreamingServiceRef.RCustDBItemComboDTO).ReadFromMessage(loRtn)

                For Each loDto As CSM00600Front.CSM00600StreamingServiceRef.RCustDBItemComboDTO In loStreaming
                    If loDto IsNot Nothing Then
                        loListEntity.Add(loDto)
                    Else
                        Exit For
                    End If
                Next
                poListEntityResult = loListEntity

            End With
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loServiceStream.Close()
        loException.ThrowExceptionIfErrors()
    End Sub
#End Region

End Class
