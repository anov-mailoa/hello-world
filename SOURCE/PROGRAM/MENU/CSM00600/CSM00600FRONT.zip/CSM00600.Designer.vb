﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSM00600
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewComboBoxColumn1 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.bsVersion = New System.Windows.Forms.BindingSource(Me.components)
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.gvCR = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvCR = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridCR = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtItem = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtAttribute = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtAttributeGroup = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtApplication = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.btnFilter = New R_FrontEnd.R_PopUp(Me.components)
        Me.lblItem = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblAttribute = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblAttributeGroup = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.preDetail = New R_FrontEnd.R_PredefinedDock(Me.components)
        Me.bsItem = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsAttribute = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsAttributeGroup = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        CType(Me.bsVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.gvCR, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvCR.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvCR, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridCR, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.txtItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtAttribute, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtAttributeGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnFilter, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblAttribute, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblAttributeGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsAttribute, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsAttributeGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'bsVersion
        '
        Me.bsVersion.DataSource = GetType(CSM00600Front.CSM00600ServiceRef.RCustDBVersionComboDTO)
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.gvCR, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 132.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'gvCR
        '
        Me.gvCR.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvCR.EnableFastScrolling = True
        Me.gvCR.Location = New System.Drawing.Point(3, 135)
        '
        '
        '
        Me.gvCR.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn1.FieldName = "_CCR_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CCR_ID"
        R_GridViewTextBoxColumn1.Name = "_CCR_ID"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CCR_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 63
        R_GridViewComboBoxColumn1.DataSource = Me.bsVersion
        R_GridViewComboBoxColumn1.DisplayMember = "CCODE_NAME"
        R_GridViewComboBoxColumn1.FieldName = "_CVERSION"
        R_GridViewComboBoxColumn1.HeaderText = "_CVERSION"
        R_GridViewComboBoxColumn1.Name = "_CVERSION"
        R_GridViewComboBoxColumn1.R_EnableADD = True
        R_GridViewComboBoxColumn1.R_EnableEDIT = True
        R_GridViewComboBoxColumn1.R_ResourceId = "_CVERSION"
        R_GridViewComboBoxColumn1.ValueMember = "CVERSION"
        R_GridViewComboBoxColumn1.Width = 79
        R_GridViewTextBoxColumn2.FieldName = "_CPROJECT_ID"
        R_GridViewTextBoxColumn2.HeaderText = "_CPROJECT_ID"
        R_GridViewTextBoxColumn2.Name = "_CPROJECT_ID"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CPROJECT_ID"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 94
        R_GridViewTextBoxColumn3.FieldName = "_CSESSION_ID"
        R_GridViewTextBoxColumn3.HeaderText = "_CSESSION_ID"
        R_GridViewTextBoxColumn3.Name = "_CSESSION_ID"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CSESSION_ID"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 93
        R_GridViewTextBoxColumn4.FieldName = "_CSTATUS"
        R_GridViewTextBoxColumn4.HeaderText = "_CSTATUS"
        R_GridViewTextBoxColumn4.Name = "_CSTATUS"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CSTATUS"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 73
        R_GridViewTextBoxColumn5.FieldName = "_CDESCRIPTION"
        R_GridViewTextBoxColumn5.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxColumn5.Name = "_CDESCRIPTION"
        R_GridViewTextBoxColumn5.R_EnableADD = True
        R_GridViewTextBoxColumn5.R_EnableEDIT = True
        R_GridViewTextBoxColumn5.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 103
        Me.gvCR.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewComboBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewTextBoxColumn4, R_GridViewTextBoxColumn5})
        Me.gvCR.MasterTemplate.DataSource = Me.bsGvCR
        Me.gvCR.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvCR.MasterTemplate.EnableFiltering = True
        Me.gvCR.MasterTemplate.EnableGrouping = False
        Me.gvCR.MasterTemplate.ShowFilteringRow = False
        Me.gvCR.MasterTemplate.ShowGroupedColumns = True
        Me.gvCR.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvCR.Name = "gvCR"
        Me.gvCR.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvCR.R_ConductorGridSource = Me.conGridCR
        Me.gvCR.R_ConductorSource = Nothing
        Me.gvCR.R_DataAdded = False
        Me.gvCR.R_NewRowText = Nothing
        Me.gvCR.ShowHeaderCellButtons = True
        Me.gvCR.Size = New System.Drawing.Size(1271, 437)
        Me.gvCR.TabIndex = 3
        Me.gvCR.Text = "R_RadGridView1"
        '
        'bsGvCR
        '
        Me.bsGvCR.DataSource = GetType(CSM00600Front.CSM00600ServiceRef.CSM00600DTO)
        '
        'conGridCR
        '
        Me.conGridCR.R_ConductorParent = Nothing
        Me.conGridCR.R_IsHeader = True
        Me.conGridCR.R_RadGroupBox = Nothing
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.txtItem)
        Me.Panel1.Controls.Add(Me.txtAttribute)
        Me.Panel1.Controls.Add(Me.txtAttributeGroup)
        Me.Panel1.Controls.Add(Me.txtApplication)
        Me.Panel1.Controls.Add(Me.btnFilter)
        Me.Panel1.Controls.Add(Me.lblItem)
        Me.Panel1.Controls.Add(Me.lblAttribute)
        Me.Panel1.Controls.Add(Me.lblAttributeGroup)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 126)
        Me.Panel1.TabIndex = 0
        '
        'txtItem
        '
        Me.txtItem.Location = New System.Drawing.Point(115, 86)
        Me.txtItem.Name = "txtItem"
        Me.txtItem.R_ConductorGridSource = Nothing
        Me.txtItem.R_ConductorSource = Nothing
        Me.txtItem.R_UDT = Nothing
        Me.txtItem.ReadOnly = True
        Me.txtItem.Size = New System.Drawing.Size(200, 20)
        Me.txtItem.TabIndex = 52
        Me.txtItem.TabStop = False
        '
        'txtAttribute
        '
        Me.txtAttribute.Location = New System.Drawing.Point(115, 60)
        Me.txtAttribute.Name = "txtAttribute"
        Me.txtAttribute.R_ConductorGridSource = Nothing
        Me.txtAttribute.R_ConductorSource = Nothing
        Me.txtAttribute.R_UDT = Nothing
        Me.txtAttribute.ReadOnly = True
        Me.txtAttribute.Size = New System.Drawing.Size(400, 20)
        Me.txtAttribute.TabIndex = 51
        Me.txtAttribute.TabStop = False
        '
        'txtAttributeGroup
        '
        Me.txtAttributeGroup.Location = New System.Drawing.Point(115, 34)
        Me.txtAttributeGroup.Name = "txtAttributeGroup"
        Me.txtAttributeGroup.R_ConductorGridSource = Nothing
        Me.txtAttributeGroup.R_ConductorSource = Nothing
        Me.txtAttributeGroup.R_UDT = Nothing
        Me.txtAttributeGroup.ReadOnly = True
        Me.txtAttributeGroup.Size = New System.Drawing.Size(200, 20)
        Me.txtAttributeGroup.TabIndex = 50
        Me.txtAttributeGroup.TabStop = False
        '
        'txtApplication
        '
        Me.txtApplication.Location = New System.Drawing.Point(115, 8)
        Me.txtApplication.Name = "txtApplication"
        Me.txtApplication.R_ConductorGridSource = Nothing
        Me.txtApplication.R_ConductorSource = Nothing
        Me.txtApplication.R_UDT = Nothing
        Me.txtApplication.ReadOnly = True
        Me.txtApplication.Size = New System.Drawing.Size(400, 20)
        Me.txtApplication.TabIndex = 49
        Me.txtApplication.TabStop = False
        '
        'btnFilter
        '
        Me.btnFilter.Location = New System.Drawing.Point(521, 6)
        Me.btnFilter.Name = "btnFilter"
        Me.btnFilter.R_ConductorGridSource = Nothing
        Me.btnFilter.R_ConductorSource = Nothing
        Me.btnFilter.R_DescriptionId = Nothing
        Me.btnFilter.R_ResourceId = "btnFilter"
        Me.btnFilter.R_Title = "Change Request Filter"
        Me.btnFilter.Size = New System.Drawing.Size(110, 24)
        Me.btnFilter.TabIndex = 48
        Me.btnFilter.Text = "R_PopUp1"
        '
        'lblItem
        '
        Me.lblItem.AutoSize = False
        Me.lblItem.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblItem.Location = New System.Drawing.Point(9, 87)
        Me.lblItem.Name = "lblItem"
        Me.lblItem.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblItem.R_ResourceId = "lblItem"
        Me.lblItem.Size = New System.Drawing.Size(100, 18)
        Me.lblItem.TabIndex = 45
        Me.lblItem.Text = "Application..."
        '
        'lblAttribute
        '
        Me.lblAttribute.AutoSize = False
        Me.lblAttribute.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblAttribute.Location = New System.Drawing.Point(9, 61)
        Me.lblAttribute.Name = "lblAttribute"
        Me.lblAttribute.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblAttribute.R_ResourceId = "lblAttribute"
        Me.lblAttribute.Size = New System.Drawing.Size(100, 18)
        Me.lblAttribute.TabIndex = 44
        Me.lblAttribute.Text = "Application..."
        '
        'lblAttributeGroup
        '
        Me.lblAttributeGroup.AutoSize = False
        Me.lblAttributeGroup.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblAttributeGroup.Location = New System.Drawing.Point(9, 35)
        Me.lblAttributeGroup.Name = "lblAttributeGroup"
        Me.lblAttributeGroup.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblAttributeGroup.R_ResourceId = "lblAttributeGroup"
        Me.lblAttributeGroup.Size = New System.Drawing.Size(100, 18)
        Me.lblAttributeGroup.TabIndex = 42
        Me.lblAttributeGroup.Text = "Application..."
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 23
        Me.lblApplication.Text = "Application..."
        '
        'preDetail
        '
        Me.preDetail.R_ConductorGridSource = Me.conGridCR
        Me.preDetail.R_ConductorSource = Nothing
        Me.preDetail.R_CopyAccess = True
        Me.preDetail.R_DockIndex = 0
        Me.preDetail.R_EnableHASDATA = True
        Me.preDetail.R_HeaderTitle = "CR Detail"
        '
        'bsItem
        '
        Me.bsItem.DataSource = GetType(CSM00600Front.CSM00600ServiceRef.RCustDBItemComboDTO)
        '
        'bsAttribute
        '
        Me.bsAttribute.DataSource = GetType(CSM00600Front.CSM00600ServiceRef.RCustDBAttributeComboDTO)
        '
        'bsAttributeGroup
        '
        Me.bsAttributeGroup.DataSource = GetType(CSM00600Front.CSM00600ServiceRef.RCustDBAttributeGroupComboDTO)
        '
        'bsApps
        '
        Me.bsApps.DataSource = GetType(CSM00600Front.CSM00600ServiceRef.RLicenseAppComboDTO)
        '
        'CSM00600
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CSM00600"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.bsVersion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        CType(Me.gvCR.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvCR, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvCR, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridCR, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.txtItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtAttribute, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtAttributeGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnFilter, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblAttribute, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblAttributeGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsAttribute, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsAttributeGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource
    Friend WithEvents bsAttributeGroup As System.Windows.Forms.BindingSource
    Friend WithEvents bsAttribute As System.Windows.Forms.BindingSource
    Friend WithEvents bsVersion As System.Windows.Forms.BindingSource
    Friend WithEvents bsItem As System.Windows.Forms.BindingSource
    Friend WithEvents bsGvCR As System.Windows.Forms.BindingSource
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents lblAttributeGroup As R_FrontEnd.R_RadLabel
    Friend WithEvents lblAttribute As R_FrontEnd.R_RadLabel
    Friend WithEvents lblItem As R_FrontEnd.R_RadLabel
    Friend WithEvents gvCR As R_FrontEnd.R_RadGridView
    Friend WithEvents preDetail As R_FrontEnd.R_PredefinedDock
    Friend WithEvents conGridCR As R_FrontEnd.R_ConductorGrid
    Friend WithEvents txtItem As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtAttribute As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtAttributeGroup As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtApplication As R_FrontEnd.R_RadTextBox
    Friend WithEvents btnFilter As R_FrontEnd.R_PopUp

End Class
