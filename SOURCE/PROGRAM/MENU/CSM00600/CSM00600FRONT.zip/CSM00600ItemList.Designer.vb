﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSM00600ItemList
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.gvManager = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsManager = New System.Windows.Forms.BindingSource(Me.components)
        Me.R_ReturnLookUpAndFind1 = New R_FrontEnd.R_ReturnLookUpAndFind()
        Me.bsAttributeGroup = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsAttribute = New System.Windows.Forms.BindingSource(Me.components)
        CType(Me.gvManager, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvManager.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsManager, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsAttributeGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsAttribute, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'gvManager
        '
        Me.gvManager.EnableFastScrolling = True
        Me.gvManager.Location = New System.Drawing.Point(12, 12)
        '
        '
        '
        Me.gvManager.MasterTemplate.AutoGenerateColumns = False
        Me.gvManager.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn1.FieldName = "CITEM_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CITEM_ID"
        R_GridViewTextBoxColumn1.Name = "_CITEM_ID"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CITEM_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 87
        R_GridViewTextBoxColumn2.FieldName = "CITEM_NAME"
        R_GridViewTextBoxColumn2.HeaderText = "_CITEM_NAME"
        R_GridViewTextBoxColumn2.Name = "_CITEM_NAME"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CITEM_NAME"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 457
        Me.gvManager.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2})
        Me.gvManager.MasterTemplate.DataSource = Me.bsManager
        Me.gvManager.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvManager.MasterTemplate.EnableFiltering = True
        Me.gvManager.MasterTemplate.EnableGrouping = False
        Me.gvManager.MasterTemplate.ShowFilteringRow = False
        Me.gvManager.MasterTemplate.ShowGroupedColumns = True
        Me.gvManager.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvManager.Name = "gvManager"
        Me.gvManager.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvManager.R_ConductorGridSource = Nothing
        Me.gvManager.R_ConductorSource = Nothing
        Me.gvManager.R_DataAdded = False
        Me.gvManager.R_NewRowText = Nothing
        Me.gvManager.ShowHeaderCellButtons = True
        Me.gvManager.Size = New System.Drawing.Size(563, 233)
        Me.gvManager.TabIndex = 1
        Me.gvManager.Text = "R_RadGridView1"
        '
        'bsManager
        '
        Me.bsManager.DataSource = GetType(CSM00600Front.CSM00600StreamingServiceRef.RCustDBItemComboDTO)
        '
        'R_ReturnLookUpAndFind1
        '
        Me.R_ReturnLookUpAndFind1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.R_ReturnLookUpAndFind1.Location = New System.Drawing.Point(404, 251)
        Me.R_ReturnLookUpAndFind1.Name = "R_ReturnLookUpAndFind1"
        Me.R_ReturnLookUpAndFind1.R_BindingSource = Me.bsManager
        Me.R_ReturnLookUpAndFind1.Size = New System.Drawing.Size(162, 31)
        Me.R_ReturnLookUpAndFind1.TabIndex = 2
        '
        'CSM00600ItemList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(587, 294)
        Me.Controls.Add(Me.R_ReturnLookUpAndFind1)
        Me.Controls.Add(Me.gvManager)
        Me.Name = "CSM00600ItemList"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "Item List"
        CType(Me.gvManager.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvManager, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsManager, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsAttributeGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsAttribute, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents bsManager As System.Windows.Forms.BindingSource
    Friend WithEvents gvManager As R_FrontEnd.R_RadGridView
    Friend WithEvents R_ReturnLookUpAndFind1 As R_FrontEnd.R_ReturnLookUpAndFind
    Friend WithEvents bsAttributeGroup As System.Windows.Forms.BindingSource
    Friend WithEvents bsAttribute As System.Windows.Forms.BindingSource

End Class
