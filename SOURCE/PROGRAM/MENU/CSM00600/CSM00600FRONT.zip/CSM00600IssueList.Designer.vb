﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSM00600IssueList
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.bsIssue = New System.Windows.Forms.BindingSource(Me.components)
        Me.gvIssue = New R_FrontEnd.R_RadGridView(Me.components)
        Me.R_ReturnLookUpAndFind1 = New R_FrontEnd.R_ReturnLookUpAndFind()
        CType(Me.bsIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvIssue.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'gvIssue
        '
        Me.gvIssue.EnableFastScrolling = True
        Me.gvIssue.Location = New System.Drawing.Point(12, 12)
        '
        '
        '
        Me.gvIssue.MasterTemplate.AutoGenerateColumns = False
        Me.gvIssue.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn1.FieldName = "CISSUE_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CISSUE_ID"
        R_GridViewTextBoxColumn1.Name = "_CISSUE_ID"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CISSUE_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 76
        R_GridViewTextBoxColumn2.FieldName = "CDESCRIPTION"
        R_GridViewTextBoxColumn2.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxColumn2.Name = "_CDESCRIPTION"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 325
        Me.gvIssue.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2})
        Me.gvIssue.MasterTemplate.DataSource = Me.bsIssue
        Me.gvIssue.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvIssue.MasterTemplate.EnableFiltering = True
        Me.gvIssue.MasterTemplate.EnableGrouping = False
        Me.gvIssue.MasterTemplate.ShowFilteringRow = False
        Me.gvIssue.MasterTemplate.ShowGroupedColumns = True
        Me.gvIssue.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvIssue.Name = "gvIssue"
        Me.gvIssue.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvIssue.R_ConductorGridSource = Nothing
        Me.gvIssue.R_ConductorSource = Nothing
        Me.gvIssue.R_DataAdded = False
        Me.gvIssue.R_NewRowText = Nothing
        Me.gvIssue.ShowHeaderCellButtons = True
        Me.gvIssue.Size = New System.Drawing.Size(420, 170)
        Me.gvIssue.TabIndex = 1
        Me.gvIssue.Text = "R_RadGridView1"
        '
        'R_ReturnLookUpAndFind1
        '
        Me.R_ReturnLookUpAndFind1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.R_ReturnLookUpAndFind1.Location = New System.Drawing.Point(270, 188)
        Me.R_ReturnLookUpAndFind1.Name = "R_ReturnLookUpAndFind1"
        Me.R_ReturnLookUpAndFind1.R_BindingSource = Me.bsIssue
        Me.R_ReturnLookUpAndFind1.Size = New System.Drawing.Size(162, 31)
        Me.R_ReturnLookUpAndFind1.TabIndex = 2
        '
        'CSM00600IssueList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(453, 231)
        Me.Controls.Add(Me.R_ReturnLookUpAndFind1)
        Me.Controls.Add(Me.gvIssue)
        Me.Name = "CSM00600IssueList"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "Issue List"
        CType(Me.bsIssue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvIssue.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvIssue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents bsIssue As System.Windows.Forms.BindingSource
    Friend WithEvents gvIssue As R_FrontEnd.R_RadGridView
    Friend WithEvents R_ReturnLookUpAndFind1 As R_FrontEnd.R_ReturnLookUpAndFind

End Class
