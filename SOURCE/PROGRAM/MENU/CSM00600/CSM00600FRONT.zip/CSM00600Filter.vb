﻿Imports CSM00600Front.CSM00600ServiceRef
Imports R_FrontEnd
Imports ClientHelper
Imports R_Common
Imports CSM00600Front.CSM00600StreamingServiceRef

Public Class CSM00600Filter

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSM00600Service/CSM00600Service.svc"
    Dim C_ServiceNameStream As String = "CSM00600Service/CSM00600StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim loFilterParam As New CSM00600FilterParameterDTO
    Dim llRefreshCombo As Boolean
#End Region

#Region " SUBs and FUNCTIONs "

    Private Sub ComboManager(pcCode As String, pcValue As String, pcDisplay As String)
        Dim loSvc As CSM00600ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00600Service, CSM00600ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loFilterKey As New CSM00600KeyDTO
        Dim lcValue As String = ""
        Dim lcDisplay As String = ""

        ' Refresh Combo
        With loFilterKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = cboApplication.SelectedValue
        End With

        If pcValue IsNot Nothing Then
            lcValue = pcValue.Trim
        End If
        If pcDisplay IsNot Nothing Then
            lcDisplay = pcDisplay
        End If

        With loFilterParam
            Select Case pcCode
                Case "_INIT"
                    ' initialize combo
                    cboAttribute.Items.Clear()
                    'cboItem.Items.Clear()
                    If .OAPPS_LIST Is Nothing Then
                        Dim loAppCombo As New List(Of RLicenseAppComboDTO)
                        loAppCombo = loSvc.GetAppCombo(_CCOMPID, _CUSERID)
                        If loAppCombo.Count <= 0 Then
                            cboApplication.Items.Clear()
                        End If
                        llRefreshCombo = True
                        bsApps.DataSource = loAppCombo
                        .OAPPS_LIST = loAppCombo
                    Else
                        llRefreshCombo = False
                        bsApps.DataSource = .OAPPS_LIST
                        cboApplication.SelectedValue = .OFILTER_KEY.CAPPS_CODE
                        bsAttribute.DataSource = .OATTRIBUTE_LIST
                        cboAttribute.SelectedValue = .OFILTER_KEY.CATTRIBUTE_ID
                        bsItem.DataSource = .OITEM_LIST
                        txtItemID.Text = .OFILTER_KEY.CPROGRAM_ID
                        txtItemName.Text = .CITEM_NAME
                        llRefreshCombo = True
                    End If
                Case "_CAPPS_CODE"
                    If .OATTRIBUTE_LIST Is Nothing Or Not lcValue.Equals(.OFILTER_KEY.CAPPS_CODE) Then
                        Dim loAttributeCombo As New List(Of RCustDBAttributeComboDTO)
                        .OFILTER_KEY.CAPPS_CODE = lcValue
                        .CAPPS_NAME = lcDisplay
                        loAttributeCombo = loSvc.GetAttributeCombo(_CCOMPID, lcValue, .OFILTER_KEY.CATTRIBUTE_GROUP)
                        If loAttributeCombo.Count <= 0 Then
                            cboAttribute.Items.Clear()
                        End If
                        bsAttribute.DataSource = loAttributeCombo
                        .OATTRIBUTE_LIST = loAttributeCombo
                    End If
                Case "_CATTRIBUTE_ID"
                    If .OITEM_LIST Is Nothing Or Not lcValue.Equals(.OFILTER_KEY.CATTRIBUTE_ID) Then
                        .OFILTER_KEY.CATTRIBUTE_ID = lcValue
                        .CATTRIBUTE_NAME = lcDisplay
                    End If

            End Select
        End With
        loSvc.Close()
    End Sub

#End Region

#Region " COMBO Actions "

    Private Sub cboApplication_Trigger(sender As Object, e As System.EventArgs) Handles cboApplication.SelectedIndexChanged
        If llRefreshCombo Then
            ComboManager("_CAPPS_CODE", sender.SelectedValue, sender.SelectedText)
        End If
    End Sub

    Private Sub cboAttribute_Trigger(sender As Object, e As System.EventArgs) Handles cboAttribute.SelectedIndexChanged
        If llRefreshCombo Then
            ComboManager("_CATTRIBUTE_ID", sender.SelectedValue, sender.SelectedText)
        End If
    End Sub

#End Region

#Region " FORM Methods "

    Private Sub R_ReturnPopUp1_R_SetPopUpResult(ByRef poEntityResult As Object) Handles R_ReturnPopUp1.R_SetPopUpResult
        poEntityResult = loFilterParam
    End Sub

    Private Sub CSM00510Filter_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim loEx As New R_Exception

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            loFilterParam = poParameter
            txtAttributeGroup.Text = loFilterParam.OFILTER_KEY.CATTRIBUTE_GROUP
            ComboManager("_INIT", Nothing, Nothing)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " LOOKUP Events "
    Private Sub lupItem_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles lupItem.R_Before_Open_Form
        poTargetForm = New CSM00600ItemList
        poParameter = New RCustDBItemKeyDTO With {.CCOMPANY_ID = _CCOMPID, _
                                                    .CAPPS_CODE = cboApplication.SelectedValue, _
                                                    .CATTRIBUTE_GROUP = txtAttributeGroup.Text.Trim, _
                                                    .CATTRIBUTE_ID = cboAttribute.SelectedValue}
    End Sub

    Private Sub lupItem_R_Return_LookUp(poReturnObject As Object) Handles lupItem.R_Return_LookUp
        With CType(poReturnObject, CSM00600Front.CSM00600StreamingServiceRef.RCustDBItemComboDTO)
            txtItemID.Text = .CITEM_ID
            txtItemName.Text = .CITEM_NAME
        End With
        With loFilterParam
            .OFILTER_KEY.CPROGRAM_ID = txtItemID.Text.Trim
            .CITEM_NAME = txtItemName.Text.Trim
        End With
    End Sub
#End Region

End Class
