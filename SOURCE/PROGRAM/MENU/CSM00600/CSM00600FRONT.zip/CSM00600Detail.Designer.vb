﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSM00600Detail
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewLookUpColumn1 As R_FrontEnd.R_GridViewLookUpColumn = New R_FrontEnd.R_GridViewLookUpColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn1 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.gvCRDetail = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvCRDetail = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridCRDetail = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnSchedule = New R_FrontEnd.R_RadButton(Me.components)
        Me.txtCRId = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtItem = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtAttribute = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtAttributeGroup = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtApplication = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblCRId = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblItem = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblAttribute = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblAttributeGroup = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.gvCRDetail, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvCRDetail.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvCRDetail, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridCRDetail, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.btnSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCRId, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtAttribute, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtAttributeGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCRId, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblAttribute, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblAttributeGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.gvCRDetail, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 150.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'gvCRDetail
        '
        Me.gvCRDetail.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvCRDetail.EnableFastScrolling = True
        Me.gvCRDetail.Location = New System.Drawing.Point(3, 153)
        '
        '
        '
        Me.gvCRDetail.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn1.FieldName = "_CSEQUENCE"
        R_GridViewTextBoxColumn1.HeaderText = "_CSEQUENCE"
        R_GridViewTextBoxColumn1.Name = "_CSEQUENCE"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CSEQUENCE"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 89
        R_GridViewLookUpColumn1.FieldName = "_CISSUE_ID"
        R_GridViewLookUpColumn1.HeaderText = "_CISSUE_ID"
        R_GridViewLookUpColumn1.Name = "_CISSUE_ID"
        R_GridViewLookUpColumn1.R_EnableADD = True
        R_GridViewLookUpColumn1.R_EnableEDIT = True
        R_GridViewLookUpColumn1.R_ResourceId = "_CISSUE_ID"
        R_GridViewLookUpColumn1.R_Title = Nothing
        R_GridViewLookUpColumn1.Width = 78
        R_GridViewTextBoxColumn2.FieldName = "_CISSUE_DESCRIPTION"
        R_GridViewTextBoxColumn2.HeaderText = "_CISSUE_DESCRIPTION"
        R_GridViewTextBoxColumn2.Multiline = True
        R_GridViewTextBoxColumn2.Name = "_CISSUE_DESCRIPTION"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CISSUE_DESCRIPTION"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.ReadOnly = True
        R_GridViewTextBoxColumn2.Width = 136
        R_GridViewTextBoxColumn2.WrapText = True
        R_GridViewTextBoxColumn3.FieldName = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn3.HeaderText = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn3.Name = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 103
        R_GridViewTextBoxColumn4.FieldName = "_CDESCRIPTION"
        R_GridViewTextBoxColumn4.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxColumn4.MaxLength = 8000
        R_GridViewTextBoxColumn4.Multiline = True
        R_GridViewTextBoxColumn4.Name = "_CDESCRIPTION"
        R_GridViewTextBoxColumn4.R_EnableADD = True
        R_GridViewTextBoxColumn4.R_EnableEDIT = True
        R_GridViewTextBoxColumn4.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 103
        R_GridViewTextBoxColumn4.WrapText = True
        R_GridViewCheckBoxColumn1.FieldName = "_LCANCEL"
        R_GridViewCheckBoxColumn1.HeaderText = "_LCANCEL"
        R_GridViewCheckBoxColumn1.Name = "_LCANCEL"
        R_GridViewCheckBoxColumn1.R_EnableEDIT = True
        R_GridViewCheckBoxColumn1.R_ResourceId = "_LCANCEL"
        R_GridViewCheckBoxColumn1.Width = 88
        Me.gvCRDetail.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewLookUpColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewTextBoxColumn4, R_GridViewCheckBoxColumn1})
        Me.gvCRDetail.MasterTemplate.DataSource = Me.bsGvCRDetail
        Me.gvCRDetail.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvCRDetail.MasterTemplate.EnableFiltering = True
        Me.gvCRDetail.MasterTemplate.EnableGrouping = False
        Me.gvCRDetail.MasterTemplate.ShowFilteringRow = False
        Me.gvCRDetail.MasterTemplate.ShowGroupedColumns = True
        Me.gvCRDetail.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvCRDetail.Name = "gvCRDetail"
        Me.gvCRDetail.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvCRDetail.R_ConductorGridSource = Me.conGridCRDetail
        Me.gvCRDetail.R_ConductorSource = Nothing
        Me.gvCRDetail.R_DataAdded = False
        Me.gvCRDetail.R_NewRowText = Nothing
        Me.gvCRDetail.ShowHeaderCellButtons = True
        Me.gvCRDetail.Size = New System.Drawing.Size(1271, 419)
        Me.gvCRDetail.TabIndex = 4
        Me.gvCRDetail.Text = "R_RadGridView1"
        '
        'bsGvCRDetail
        '
        Me.bsGvCRDetail.DataSource = GetType(CSM00600Front.CSM00600DetailServiceRef.CSM00600DetailDTO)
        '
        'conGridCRDetail
        '
        Me.conGridCRDetail.R_ConductorParent = Nothing
        Me.conGridCRDetail.R_IsHeader = True
        Me.conGridCRDetail.R_RadGroupBox = Nothing
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnSchedule)
        Me.Panel1.Controls.Add(Me.txtCRId)
        Me.Panel1.Controls.Add(Me.txtItem)
        Me.Panel1.Controls.Add(Me.txtAttribute)
        Me.Panel1.Controls.Add(Me.txtAttributeGroup)
        Me.Panel1.Controls.Add(Me.txtApplication)
        Me.Panel1.Controls.Add(Me.lblCRId)
        Me.Panel1.Controls.Add(Me.lblItem)
        Me.Panel1.Controls.Add(Me.lblAttribute)
        Me.Panel1.Controls.Add(Me.lblAttributeGroup)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 144)
        Me.Panel1.TabIndex = 0
        '
        'btnSchedule
        '
        Me.btnSchedule.Location = New System.Drawing.Point(371, 6)
        Me.btnSchedule.Name = "btnSchedule"
        Me.btnSchedule.R_ConductorGridSource = Nothing
        Me.btnSchedule.R_ConductorSource = Nothing
        Me.btnSchedule.R_DescriptionId = Nothing
        Me.btnSchedule.R_ResourceId = "btnSchedule"
        Me.btnSchedule.Size = New System.Drawing.Size(110, 24)
        Me.btnSchedule.TabIndex = 56
        Me.btnSchedule.Text = "R_RadButton1"
        '
        'txtCRId
        '
        Me.txtCRId.Location = New System.Drawing.Point(115, 112)
        Me.txtCRId.Name = "txtCRId"
        Me.txtCRId.R_ConductorGridSource = Nothing
        Me.txtCRId.R_ConductorSource = Nothing
        Me.txtCRId.R_UDT = Nothing
        Me.txtCRId.ReadOnly = True
        Me.txtCRId.Size = New System.Drawing.Size(250, 20)
        Me.txtCRId.TabIndex = 55
        Me.txtCRId.TabStop = False
        '
        'txtItem
        '
        Me.txtItem.Location = New System.Drawing.Point(115, 86)
        Me.txtItem.Name = "txtItem"
        Me.txtItem.R_ConductorGridSource = Nothing
        Me.txtItem.R_ConductorSource = Nothing
        Me.txtItem.R_UDT = Nothing
        Me.txtItem.ReadOnly = True
        Me.txtItem.Size = New System.Drawing.Size(250, 20)
        Me.txtItem.TabIndex = 54
        Me.txtItem.TabStop = False
        '
        'txtAttribute
        '
        Me.txtAttribute.Location = New System.Drawing.Point(115, 60)
        Me.txtAttribute.Name = "txtAttribute"
        Me.txtAttribute.R_ConductorGridSource = Nothing
        Me.txtAttribute.R_ConductorSource = Nothing
        Me.txtAttribute.R_UDT = Nothing
        Me.txtAttribute.ReadOnly = True
        Me.txtAttribute.Size = New System.Drawing.Size(250, 20)
        Me.txtAttribute.TabIndex = 53
        Me.txtAttribute.TabStop = False
        '
        'txtAttributeGroup
        '
        Me.txtAttributeGroup.Location = New System.Drawing.Point(115, 34)
        Me.txtAttributeGroup.Name = "txtAttributeGroup"
        Me.txtAttributeGroup.R_ConductorGridSource = Nothing
        Me.txtAttributeGroup.R_ConductorSource = Nothing
        Me.txtAttributeGroup.R_UDT = Nothing
        Me.txtAttributeGroup.ReadOnly = True
        Me.txtAttributeGroup.Size = New System.Drawing.Size(250, 20)
        Me.txtAttributeGroup.TabIndex = 52
        Me.txtAttributeGroup.TabStop = False
        '
        'txtApplication
        '
        Me.txtApplication.Location = New System.Drawing.Point(115, 8)
        Me.txtApplication.Name = "txtApplication"
        Me.txtApplication.R_ConductorGridSource = Nothing
        Me.txtApplication.R_ConductorSource = Nothing
        Me.txtApplication.R_UDT = Nothing
        Me.txtApplication.ReadOnly = True
        Me.txtApplication.Size = New System.Drawing.Size(250, 20)
        Me.txtApplication.TabIndex = 51
        Me.txtApplication.TabStop = False
        '
        'lblCRId
        '
        Me.lblCRId.AutoSize = False
        Me.lblCRId.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCRId.Location = New System.Drawing.Point(9, 113)
        Me.lblCRId.Name = "lblCRId"
        Me.lblCRId.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCRId.R_ResourceId = "lblCRId"
        Me.lblCRId.Size = New System.Drawing.Size(100, 18)
        Me.lblCRId.TabIndex = 50
        Me.lblCRId.Text = "Application..."
        '
        'lblItem
        '
        Me.lblItem.AutoSize = False
        Me.lblItem.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblItem.Location = New System.Drawing.Point(9, 87)
        Me.lblItem.Name = "lblItem"
        Me.lblItem.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblItem.R_ResourceId = "lblItem"
        Me.lblItem.Size = New System.Drawing.Size(100, 18)
        Me.lblItem.TabIndex = 49
        Me.lblItem.Text = "Application..."
        '
        'lblAttribute
        '
        Me.lblAttribute.AutoSize = False
        Me.lblAttribute.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblAttribute.Location = New System.Drawing.Point(9, 61)
        Me.lblAttribute.Name = "lblAttribute"
        Me.lblAttribute.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblAttribute.R_ResourceId = "lblAttribute"
        Me.lblAttribute.Size = New System.Drawing.Size(100, 18)
        Me.lblAttribute.TabIndex = 48
        Me.lblAttribute.Text = "Application..."
        '
        'lblAttributeGroup
        '
        Me.lblAttributeGroup.AutoSize = False
        Me.lblAttributeGroup.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblAttributeGroup.Location = New System.Drawing.Point(9, 35)
        Me.lblAttributeGroup.Name = "lblAttributeGroup"
        Me.lblAttributeGroup.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblAttributeGroup.R_ResourceId = "lblAttributeGroup"
        Me.lblAttributeGroup.Size = New System.Drawing.Size(100, 18)
        Me.lblAttributeGroup.TabIndex = 47
        Me.lblAttributeGroup.Text = "Application..."
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 46
        Me.lblApplication.Text = "Application..."
        '
        'CSM00600Detail
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CSM00600Detail"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.TableLayoutPanel1.ResumeLayout(False)
        CType(Me.gvCRDetail.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvCRDetail, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvCRDetail, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridCRDetail, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.btnSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCRId, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtAttribute, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtAttributeGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCRId, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblAttribute, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblAttributeGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblCRId As R_FrontEnd.R_RadLabel
    Friend WithEvents lblItem As R_FrontEnd.R_RadLabel
    Friend WithEvents lblAttribute As R_FrontEnd.R_RadLabel
    Friend WithEvents lblAttributeGroup As R_FrontEnd.R_RadLabel
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents txtCRId As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtItem As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtAttribute As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtAttributeGroup As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtApplication As R_FrontEnd.R_RadTextBox
    Friend WithEvents gvCRDetail As R_FrontEnd.R_RadGridView
    Friend WithEvents bsGvCRDetail As System.Windows.Forms.BindingSource
    Friend WithEvents conGridCRDetail As R_FrontEnd.R_ConductorGrid
    Friend WithEvents btnSchedule As R_FrontEnd.R_RadButton

End Class
