﻿Imports CSM00600Front.CSM00600ServiceRef

Public Class CSM00600DetailParamDTO
    Public Property OGRID_KEY As CSM00600KeyDTO
    Public Property CAPPS_NAME As String
    Public Property CATTRIBUTE_NAME As String
    Public Property CITEM_NAME As String

    Public Property CVERSION As String
    Public Property CPROJECT_ID As String
    Public Property CSESSION_ID As String
    Public Property CSTATUS As String
End Class
