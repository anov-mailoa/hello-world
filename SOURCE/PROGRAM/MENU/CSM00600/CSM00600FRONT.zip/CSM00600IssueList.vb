﻿Imports CSM00600FrontResources
Imports R_Common
Imports CSM00600Front.CSM00600StreamingServiceRef
Imports R_FrontEnd
Imports System.ServiceModel.Channels

Public Class CSM00600IssueList

#Region " VARIABLE "
    Dim C_ServiceNameStream As String = "CSM00600Service/CSM00600StreamingService.svc"
#End Region

    Private Sub CSM00600IssueList_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Try
            gvIssue.R_RefreshGrid(poParameter)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

    Private Sub gvIssue_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvIssue.R_ServiceGetListRecord
        Dim loServiceStream As CSM00600StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00600StreamingService, CSM00600StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00600Front.CSM00600StreamingServiceRef.RCustDBIssueComboDTO)
        Dim loListEntity As New List(Of CSM00600Front.CSM00600StreamingServiceRef.RCustDBIssueComboDTO)

        Try
            With CType(poEntity, CSM00600IssueParamDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
                R_Utility.R_SetStreamingContext("cProjectId", .CPROJECT_ID)
                R_Utility.R_SetStreamingContext("cSessionId", .CSESSION_ID)
                R_Utility.R_SetStreamingContext("cAttributeGroup", .CATTRIBUTE_GROUP)
                R_Utility.R_SetStreamingContext("cAttributeId", .CATTRIBUTE_ID)
                R_Utility.R_SetStreamingContext("cItemId", .CITEM_ID)
                R_Utility.R_SetStreamingContext("cIssueType", .CISSUE_TYPE)

                loRtn = loServiceStream.GetIssueCombo()
                loStreaming = R_StreamUtility(Of RCustDBIssueComboDTO).ReadFromMessage(loRtn)

                For Each loDto As RCustDBIssueComboDTO In loStreaming
                    If loDto IsNot Nothing Then
                        loListEntity.Add(loDto)
                    Else
                        Exit For
                    End If
                Next
                poListEntityResult = loListEntity

            End With
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loServiceStream.Close()
        loException.ThrowExceptionIfErrors()
    End Sub

End Class
