﻿Imports CSM00600FrontResources
Imports R_Common
Imports CSM00600Front.CSM00600ServiceRef
Imports R_FrontEnd
Imports ClientHelper
Imports CSM00600Front.CSM00600StreamingServiceRef
Imports System.ServiceModel.Channels
Imports System.ServiceModel

Public Class CSM00600

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSM00600Service/CSM00600Service.svc"
    Dim C_ServiceNameStream As String = "CSM00600Service/CSM00600StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _CATTRIBUTEGROUP As String
    Dim _CATTRIBUTEID As String
    Dim _CITEMID As String
    Dim _LINIT As Boolean
    Dim _LREADY_TO_REFRESH As Boolean = False
    Dim loFilterParam As New CSM00600FilterParameterDTO

#End Region

#Region " SUBs and FUNCTIONs "

    Private Sub RefreshGrids(poTableKey As CSM00600KeyDTO)
        With gvCR
            .R_RefreshGrid(poTableKey)
            .Columns(0).Sort(Telerik.WinControls.UI.RadSortOrder.Ascending, False)
        End With
    End Sub

#End Region

#Region " FILTER "

    Private Sub btnFilter_R_After_Open_Form(poPopUpResult As System.Windows.Forms.DialogResult, poPopUpEntityResult As Object) Handles btnFilter.R_After_Open_Form

        If poPopUpResult = Windows.Forms.DialogResult.OK Then
            Dim loSvc As CSM00600ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00600Service, CSM00600ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
            loFilterParam = poPopUpEntityResult
            With loFilterParam
                txtApplication.Text = .CAPPS_NAME
                txtAttributeGroup.Text = .OFILTER_KEY.CATTRIBUTE_GROUP
                txtAttribute.Text = .CATTRIBUTE_NAME
                txtItem.Text = .CITEM_NAME
                ' version combo
                Dim loVersionCombo As New List(Of RCustDBVersionComboDTO)
                loVersionCombo = loSvc.GetVersionCombo(_CCOMPID, .OFILTER_KEY.CAPPS_CODE)
                bsVersion.DataSource = loVersionCombo
                RefreshGrids(.OFILTER_KEY)
            End With
        End If
    End Sub

    Private Sub btnFilter_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnFilter.R_Before_Open_Form
        poTargetForm = New CSM00600Filter
        poParameter = loFilterParam
    End Sub

#End Region

#Region " FORM Events "

    Private Sub CSM00600_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Dim loAppCombo As New List(Of RLicenseAppComboDTO)

        Try
            _LINIT = False
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            _LINIT = True

            ' Predefined dock
            Me.R_Components = Me.components
            preDetail.R_HeaderTitle = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00600DetailTitle")
            loFilterParam.OFILTER_KEY.CCOMPANY_ID = _CCOMPID
            btnFilter.PerformClick()

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub CSM00600_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " GRIDVIEW Events "

    Private Sub gvCR_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvCR.DataBindingComplete
        gvCR.BestFitColumns()
    End Sub

    Private Sub gvCR_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvCR.R_Saving
        With CType(poEntity, CSM00600DTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = loFilterParam.OFILTER_KEY.CAPPS_CODE
            ._CATTRIBUTE_GROUP = loFilterParam.OFILTER_KEY.CATTRIBUTE_GROUP
            ._CATTRIBUTE_ID = loFilterParam.OFILTER_KEY.CATTRIBUTE_ID
            ._CPROGRAM_ID = loFilterParam.OFILTER_KEY.CPROGRAM_ID
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With

    End Sub

    Private Sub gvCR_R_ServiceDelete(poEntity As Object) Handles gvCR.R_ServiceDelete
        Dim loService As CSM00600ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00600Service, CSM00600ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String
        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As FaultException
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvCR_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvCR.R_ServiceGetListRecord
        Dim loServiceStream As CSM00600StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00600StreamingService, CSM00600StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00600GridDTO)
        Dim loListEntity As New List(Of CSM00600DTO)

        Try
            With CType(poEntity, CSM00600KeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cAttributeGroup", .CATTRIBUTE_GROUP)
                R_Utility.R_SetStreamingContext("cAttributeId", .CATTRIBUTE_ID)
                R_Utility.R_SetStreamingContext("cProgramId", .CPROGRAM_ID)
            End With

            loRtn = loServiceStream.GetCRList()
            loStreaming = R_StreamUtility(Of CSM00600GridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00600GridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New CSM00600DTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                           ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                           ._CATTRIBUTE_GROUP = loDto.CATTRIBUTE_GROUP,
                                                           ._CATTRIBUTE_ID = loDto.CATTRIBUTE_ID,
                                                           ._CPROGRAM_ID = loDto.CPROGRAM_ID,
                                                           ._CCR_ID = loDto.CCR_ID,
                                                           ._CVERSION = loDto.CVERSION,
                                                           ._CPROJECT_ID = loDto.CPROJECT_ID,
                                                           ._CSESSION_ID = loDto.CSESSION_ID,
                                                           ._CSTATUS = loDto.CSTATUS,
                                                           ._CDESCRIPTION = loDto.CDESCRIPTION,
                                                                  ._CCREATE_BY = loDto.CCREATE_BY,
                                                                  ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                                  ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                                  ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvCR_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvCR.R_ServiceGetRecord
        Dim loService As CSM00600ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00600Service, CSM00600ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New CSM00600DTO With {._CCOMPANY_ID = _CCOMPID,
                                                                             ._CAPPS_CODE = loFilterParam.OFILTER_KEY.CAPPS_CODE,
                                                                             ._CATTRIBUTE_GROUP = loFilterParam.OFILTER_KEY.CATTRIBUTE_GROUP,
                                                                             ._CATTRIBUTE_ID = loFilterParam.OFILTER_KEY.CATTRIBUTE_ID,
                                                                             ._CPROGRAM_ID = loFilterParam.OFILTER_KEY.CPROGRAM_ID,
                                                                             ._CCR_ID = CType(bsGvCR.Current, CSM00600DTO)._CCR_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvCR_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvCR.R_ServiceSave
        Dim loService As CSM00600ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00600Service, CSM00600ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As FaultException
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " PREDEFINED DOCK Events "

    Private Sub preDetail_R_InstantiateDock(ByRef poTargetForm As R_FrontEnd.R_FormBase) Handles preDetail.R_InstantiateDock
        poTargetForm = New CSM00600Detail
    End Sub

    Private Sub preDetail_R_PassParameter(ByRef poParameter As Object) Handles preDetail.R_PassParameter
        Dim loPICKey As New CSM00600KeyDTO
        Dim lcCRId As String
        Dim lcVersion As String
        Dim lcProjectId As String
        Dim lcSessionId As String
        Dim lcStatus As String

        lcCRId = ""
        lcVersion = ""
        lcProjectId = ""
        lcSessionId = ""
        lcStatus = ""
        If CType(bsGvCR.Current, CSM00600DTO)._CCR_ID IsNot Nothing Then
            With CType(bsGvCR.Current, CSM00600DTO)
                lcCRId = ._CCR_ID
                lcVersion = ._CVERSION
                lcProjectId = ._CPROJECT_ID
                lcSessionId = ._CSESSION_ID
                lcStatus = ._CSTATUS
            End With
        End If

        With loPICKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = loFilterParam.OFILTER_KEY.CAPPS_CODE
            .CATTRIBUTE_GROUP = loFilterParam.OFILTER_KEY.CATTRIBUTE_GROUP
            .CATTRIBUTE_ID = loFilterParam.OFILTER_KEY.CATTRIBUTE_ID
            .CPROGRAM_ID = loFilterParam.OFILTER_KEY.CPROGRAM_ID
            .CCR_ID = lcCRId
        End With
        poParameter = New CSM00600DetailParamDTO With {.CAPPS_NAME = txtApplication.Text,
                                                       .CATTRIBUTE_NAME = txtAttribute.Text,
                                                       .CITEM_NAME = txtItem.Text,
                                                       .CVERSION = lcVersion,
                                                       .CPROJECT_ID = lcProjectId,
                                                       .CSESSION_ID = lcSessionId,
                                                       .CSTATUS = lcStatus,
                                                        .OGRID_KEY = loPICKey}

    End Sub

#End Region

End Class
