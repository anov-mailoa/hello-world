﻿Imports CSI00200FrontResources
Imports R_Common
Imports CSI00200Front.CSI00200ServiceRef
Imports CSI00200Front.CSI00200StreamingServiceRef
Imports ClientHelper
Imports R_FrontEnd
Imports System.ServiceModel.Channels
Imports RCustDBFrontHelper

Public Class CSI00200

#Region " VARIABLE "

    Dim C_ServiceName As String = "CSI00200Service/CSI00200Service.svc"
    Dim C_ServiceNameStream As String = "CSI00200Service/CSI00200StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _CVERSION As String
    Dim _CPROJECTID As String
    Dim _CSESSIONID As String
    Dim _COPTION As String
    Dim _LOUTSTANDING As Boolean
    Dim loFilterParam As New CSI00200FilterParameterDTO

#End Region

#Region " SUBs and FUNCTIONs "

    Private Sub RefreshGrids(poKey As CSI00200ParamDTO)
        With gvIssueStatus
            .R_RefreshGrid(poKey)
        End With
    End Sub

#End Region

#Region " FORM Events "

    Private Sub CSI00100_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loComboKey As New RCustDBProjectKeyDTO

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            With loComboKey
                .CCOMPANY_ID = _CCOMPID
                .CUSER_ID = _CUSERID
            End With
            loFilterParam.OFILTER_KEY.CCOMPANY_ID = _CCOMPID
            btnFilter.PerformClick()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " FILTER "

    Private Sub btnFilter_R_After_Open_Form(poPopUpResult As System.Windows.Forms.DialogResult, poPopUpEntityResult As Object) Handles btnFilter.R_After_Open_Form
        Dim loGridKey As New CSI00200ParamDTO

        If poPopUpResult = Windows.Forms.DialogResult.OK Then
            loFilterParam = poPopUpEntityResult
            With loFilterParam
                _CAPPSCODE = .OFILTER_KEY.CAPPS_CODE
                _CVERSION = .OFILTER_KEY.CVERSION
                _CPROJECTID = .OFILTER_KEY.CPROJECT_ID
                _CSESSIONID = .OFILTER_KEY.CSESSION_ID
                _COPTION = .OFILTER_KEY.COPTION
                _LOUTSTANDING = .OFILTER_KEY.LOUTSTANDING
                txtApplication.Text = .CAPPS_NAME
                txtVersion.Text = .CCODE_NAME
                txtProject.Text = .CPROJECT_NAME
                txtSession.Text = .OFILTER_KEY.CSESSION_ID
            End With
            If Not (String.IsNullOrEmpty(_CAPPSCODE) Or String.IsNullOrEmpty(_CVERSION) Or String.IsNullOrEmpty(_CPROJECTID)) Then
                With loGridKey
                    .CCOMPANY_ID = _CCOMPID
                    .CAPPS_CODE = _CAPPSCODE
                    .CVERSION = _CVERSION
                    .CPROJECT_ID = _CPROJECTID
                    .CSESSION_ID = _CSESSIONID
                    .LOUTSTANDING = _LOUTSTANDING
                    .CUSER_ID = _CUSERID
                    .COPTION = _COPTION
                End With
                RefreshGrids(loGridKey)
            End If
        End If

    End Sub

    Private Sub btnFilter_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnFilter.R_Before_Open_Form
        poTargetForm = New CSI00200Filter
        poParameter = loFilterParam
    End Sub

#End Region

#Region " ISSUE STATUS Gridview "

    Private Sub gvIssueStatus_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvIssueStatus.DataBindingComplete
        gvIssueStatus.BestFitColumns()
    End Sub

    Private Sub gvIssueStatus_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvIssueStatus.R_Display
        Dim loEx As New R_Exception
        Dim loTableKey As New CSI00200ParamDTO
        Dim loProjectStatus As New CSI00200IssueStatusDTO

        Try
            loProjectStatus = CType(bsGvIssueStatus.Current, CSI00200IssueStatusDTO)
            With loTableKey
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = _CAPPSCODE
                .CVERSION = _CVERSION
                .CPROJECT_ID = _CPROJECTID
                .CSESSION_ID = _CSESSIONID
            End With
            With loProjectStatus
                loTableKey.CATTRIBUTE_GROUP = "PROGRAM"
                loTableKey.CATTRIBUTE_ID = .CATTRIBUTE_ID
                loTableKey.CITEM_ID = .CITEM_ID
                loTableKey.CISSUE_ID = .CISSUE_ID
            End With
            gvAssignment.R_RefreshGrid(loTableKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvIssueStatus_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvIssueStatus.R_ServiceGetListRecord
        Dim loServiceStream As CSI00200StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSI00200StreamingService, CSI00200StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSI00200IssueStatusDTO)
        Dim loListEntity As New List(Of CSI00200IssueStatusDTO)

        Try
            With CType(poEntity, CSI00200ParamDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
                R_Utility.R_SetStreamingContext("cProjectId", .CPROJECT_ID)
                R_Utility.R_SetStreamingContext("cSessionId", .CSESSION_ID)
                R_Utility.R_SetStreamingContext("lOutstanding", .LOUTSTANDING)
                R_Utility.R_SetStreamingContext("cOption", .COPTION)
                R_Utility.R_SetStreamingContext("cUserId", .CUSER_ID)
            End With

            loRtn = loServiceStream.GetIssueStatus()
            loStreaming = R_StreamUtility(Of CSI00200IssueStatusDTO).ReadFromMessage(loRtn)

            For Each loDto As CSI00200IssueStatusDTO In loStreaming
                If loDto IsNot Nothing Then
                    With loDto
                        .DISSUE_DATE = General.StrToDate(.CISSUE_DATE)
                    End With
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " ASSIGNMENT Gridview "

    Private Sub gvAssignment_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvAssignment.DataBindingComplete
        gvAssignment.BestFitColumns()
    End Sub

    Private Sub gvAssignment_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvAssignment.R_ServiceGetListRecord
        Dim loServiceStream As CSI00200StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSI00200StreamingService, CSI00200StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSI00200AssignmentDTO)
        Dim loListEntity As New List(Of CSI00200AssignmentDTO)

        Try
            With CType(poEntity, CSI00200ParamDTO)
                .COPTION = "1"
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
                R_Utility.R_SetStreamingContext("cProjectId", .CPROJECT_ID)
                R_Utility.R_SetStreamingContext("cSessionId", .CSESSION_ID)
                R_Utility.R_SetStreamingContext("cAttributeGroup", .CATTRIBUTE_GROUP)
                R_Utility.R_SetStreamingContext("cAttributeId", .CATTRIBUTE_ID)
                R_Utility.R_SetStreamingContext("cItemId", .CITEM_ID)
                R_Utility.R_SetStreamingContext("cIssueId", .CISSUE_ID)
            End With

            loRtn = loServiceStream.GetAssignment()
            loStreaming = R_StreamUtility(Of CSI00200AssignmentDTO).ReadFromMessage(loRtn)

            For Each loDto As CSI00200AssignmentDTO In loStreaming
                If loDto IsNot Nothing Then
                    With loDto
                        .DPLAN_START_DATE = General.StrToDate(.CPLAN_START_DATE)
                        .DPLAN_END_DATE = General.StrToDate(.CPLAN_END_DATE)
                        .DREVISED_START_DATE = General.StrToDate(.CREVISED_START_DATE)
                        .DREVISED_END_DATE = General.StrToDate(.CREVISED_END_DATE)
                        .DACTUAL_START_DATE = General.StrToDate(.CACTUAL_START_DATE)
                        .DACTUAL_END_DATE = General.StrToDate(.CACTUAL_END_DATE)
                    End With
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()

    End Sub

#End Region

End Class
