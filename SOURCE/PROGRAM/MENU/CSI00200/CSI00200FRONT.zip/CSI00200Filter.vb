﻿Imports CSI00200Front.CSI00200ServiceRef
Imports R_FrontEnd
Imports ClientHelper
Imports R_Common

Public Class CSI00200Filter

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSI00200Service/CSI00200Service.svc"
    Dim C_ServiceNameStream As String = "CSI00200Service/CSI00200StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim loFilterParam As New CSI00200FilterParameterDTO
    Dim llRefreshCombo As Boolean
#End Region

#Region " SUBs and FUNCTIONs "

    Private Sub ComboManager(pcCode As String, pcValue As String, pcDisplay As String)
        Dim loSvc As CSI00200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSI00200Service, CSI00200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loProjectKey As New RCustDBProjectKeyDTO
        Dim lcValue As String = ""
        Dim lcDisplay As String = ""

        ' Refresh Combo
        With loProjectKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = cboApplication.SelectedValue
            .CVERSION = cboVersion.SelectedValue
            .CPROJECT_ID = cboProject.SelectedValue
            .CSESSION_ID = ""
            .CSTATUS = "*"
            .CUSER_ID = _CUSERID
        End With

        If pcValue IsNot Nothing Then
            lcValue = pcValue.Trim
        Else
            If Not pcCode.Equals("_INIT") Then
                Exit Sub
            End If
        End If
        If pcDisplay IsNot Nothing Then
            lcDisplay = pcDisplay
        End If

        With loFilterParam
            Select Case pcCode
                Case "_INIT"
                    ' initialize combo
                    cboVersion.Items.Clear()
                    cboProject.Items.Clear()
                    cboSession.Items.Clear()
                    If .OAPPS_LIST Is Nothing Then
                        Dim loAppCombo As New List(Of RLicenseAppComboDTO)
                        loAppCombo = loSvc.GetAppCombo(_CCOMPID, _CUSERID)
                        If loAppCombo.Count <= 0 Then
                            cboApplication.Items.Clear()
                        End If
                        llRefreshCombo = True
                        bsApps.DataSource = loAppCombo
                        .OAPPS_LIST = loAppCombo
                    Else
                        llRefreshCombo = False
                        bsApps.DataSource = .OAPPS_LIST
                        cboApplication.SelectedValue = .OFILTER_KEY.CAPPS_CODE
                        bsVersion.DataSource = .OVERSION_LIST
                        cboVersion.SelectedValue = .OFILTER_KEY.CVERSION
                        bsProject.DataSource = .OPROJECT_LIST
                        cboProject.SelectedValue = .OFILTER_KEY.CPROJECT_ID
                        bsSession.DataSource = .OSESSION_LIST
                        cboSession.SelectedValue = .OFILTER_KEY.CSESSION_ID
                        llRefreshCombo = True
                    End If
                Case "_CAPPS_CODE"
                    If .OVERSION_LIST Is Nothing Or Not lcValue.Equals(.OFILTER_KEY.CAPPS_CODE) Then
                        Dim loVersionCombo As New List(Of RCustDBVersionComboDTO)
                        .OFILTER_KEY.CAPPS_CODE = lcValue
                        .CAPPS_NAME = lcDisplay
                        loVersionCombo = loSvc.GetVersionCombo(_CCOMPID, lcValue)
                        If loVersionCombo.Count <= 0 Then
                            cboVersion.Items.Clear()
                        End If
                        bsVersion.DataSource = loVersionCombo
                        .OVERSION_LIST = loVersionCombo
                    End If
                Case "_CVERSION"
                    If .OPROJECT_LIST Is Nothing Or Not lcValue.Equals(.OFILTER_KEY.CVERSION) Then
                        Dim loProjectCombo As New List(Of RCustDBProjectComboDTO)
                        .OFILTER_KEY.CVERSION = lcValue
                        .CCODE_NAME = lcDisplay
                        loProjectCombo = loSvc.GetProjectCombo(loProjectKey)
                        If loProjectCombo.Count <= 0 Then
                            cboProject.Items.Clear()
                        End If
                        bsProject.DataSource = loProjectCombo
                        .OPROJECT_LIST = loProjectCombo
                    End If
                Case "_CPROJECT_ID"
                    If .OSESSION_LIST Is Nothing Or Not lcValue.Equals(.OFILTER_KEY.CPROJECT_ID) Then
                        Dim loSessionCombo As New List(Of RCustDBSessionComboDTO)
                        .OFILTER_KEY.CPROJECT_ID = lcValue
                        .CPROJECT_NAME = lcDisplay
                        loProjectKey.CSTATUS = "*"
                        loSessionCombo = loSvc.GetSessionCombo(loProjectKey)
                        If loSessionCombo.Count <= 0 Then
                            cboSession.Items.Clear()
                        End If
                        bsSession.DataSource = loSessionCombo
                        .OSESSION_LIST = loSessionCombo
                    End If
                Case "_CSESSION_ID"
                    If Not lcValue.Equals(.OFILTER_KEY.CSESSION_ID) Then
                        .OFILTER_KEY.CSESSION_ID = lcValue
                    End If

                    If bsSession.DataSource IsNot Nothing Then
                        If bsSession.Current IsNot Nothing Then
                            .CSESSION_STATUS = CType(bsSession.Current, RCustDBSessionComboDTO).CSTATUS
                        End If
                    End If
            End Select
        End With
        loSvc.Close()
    End Sub

#End Region

#Region " COMBO Actions "

    Private Sub cboApplication_Trigger(sender As Object, e As System.EventArgs) Handles cboApplication.SelectedIndexChanged
        If llRefreshCombo Then
            ComboManager("_CAPPS_CODE", sender.SelectedValue, sender.SelectedText)
        End If
    End Sub

    Private Sub cboVersion_Trigger(sender As Object, e As System.EventArgs) Handles cboVersion.SelectedIndexChanged
        If llRefreshCombo Then
            ComboManager("_CVERSION", sender.SelectedValue, sender.SelectedText)
        End If
    End Sub

    Private Sub cboProject_Trigger(sender As Object, e As System.EventArgs) Handles cboProject.SelectedIndexChanged
        If llRefreshCombo Then
            ComboManager("_CPROJECT_ID", sender.SelectedValue, sender.SelectedText)
        End If
    End Sub

    Private Sub cboSession_SelectedIndexChanged(sender As Object, e As Telerik.WinControls.UI.Data.PositionChangedEventArgs) Handles cboSession.SelectedIndexChanged
        If llRefreshCombo Then
            ComboManager("_CSESSION_ID", sender.SelectedValue, sender.SelectedText)
        End If
    End Sub

    Private Sub chkOption_CheckStateChanged(sender As Object, e As System.EventArgs) Handles chkOption.CheckStateChanged
        loFilterParam.OFILTER_KEY.COPTION = IIf(CType(sender, R_RadCheckBox).Checked, "2", "1")
    End Sub

    Private Sub chkOutstanding_CheckStateChanged(sender As Object, e As System.EventArgs) Handles chkOutstanding.CheckStateChanged
        loFilterParam.OFILTER_KEY.LOUTSTANDING = CType(sender, R_RadCheckBox).Checked
    End Sub

#End Region

#Region " FORM Methods "

    Private Sub R_ReturnPopUp1_R_SetPopUpResult(ByRef poEntityResult As Object) Handles R_ReturnPopUp1.R_SetPopUpResult
        poEntityResult = loFilterParam
    End Sub

    Private Sub CSI00100Filter_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim loEx As New R_Exception

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            loFilterParam = poParameter
            ComboManager("_INIT", Nothing, Nothing)
            chkOption.Checked = (loFilterParam.OFILTER_KEY.COPTION = "2")
            chkOutstanding.Checked = loFilterParam.OFILTER_KEY.LOUTSTANDING
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

End Class
