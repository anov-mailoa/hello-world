﻿Imports CSI00200Front.CSI00200ServiceRef

<Serializable()> _
Public Class CSI00200FilterParameterDTO
    Public Property OFILTER_KEY As CSI00200ParamDTO
    Public Property OAPPS_LIST As List(Of RLicenseAppComboDTO)
    Public Property OVERSION_LIST As List(Of RCustDBVersionComboDTO)
    Public Property OPROJECT_LIST As List(Of RCustDBProjectComboDTO)
    Public Property OSESSION_LIST As List(Of RCustDBSessionComboDTO)
    Public Property CAPPS_NAME As String
    Public Property CCODE_NAME As String
    Public Property CPROJECT_NAME As String
    Public Property CSESSION_STATUS As String

    Sub New()
        ' initialization
        OFILTER_KEY = New CSI00200ParamDTO
        With OFILTER_KEY
            .CCOMPANY_ID = ""
            .CAPPS_CODE = ""
            .CVERSION = ""
            .CPROJECT_ID = ""
            .CSESSION_ID = ""
            .LOUTSTANDING = False
            .COPTION = "1"
            .CUSER_ID = ""
        End With
        CAPPS_NAME = ""
        CPROJECT_NAME = ""
        CSESSION_STATUS = ""
    End Sub
End Class
