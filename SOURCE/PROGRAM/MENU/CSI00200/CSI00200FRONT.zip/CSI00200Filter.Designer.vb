﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSI00200Filter
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.R_ReturnPopUp1 = New R_FrontEnd.R_ReturnPopUp()
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsVersion = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsProject = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblProject = New R_FrontEnd.R_RadLabel(Me.components)
        Me.cboProject = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.cboVersion = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblVersion = New R_FrontEnd.R_RadLabel(Me.components)
        Me.cboApplication = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.chkOption = New R_FrontEnd.R_RadCheckBox(Me.components)
        Me.lblSession = New R_FrontEnd.R_RadLabel(Me.components)
        Me.cboSession = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsSession = New System.Windows.Forms.BindingSource(Me.components)
        Me.chkOutstanding = New R_FrontEnd.R_RadCheckBox(Me.components)
        CType(Me.R_ReturnPopUp1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkOption, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkOutstanding, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'R_ReturnPopUp1
        '
        Me.R_ReturnPopUp1.Location = New System.Drawing.Point(356, 126)
        Me.R_ReturnPopUp1.Name = "R_ReturnPopUp1"
        Me.R_ReturnPopUp1.Size = New System.Drawing.Size(162, 31)
        Me.R_ReturnPopUp1.TabIndex = 0
        '
        'bsApps
        '
        Me.bsApps.DataSource = GetType(CSI00200Front.CSI00200ServiceRef.RLicenseAppComboDTO)
        '
        'bsVersion
        '
        Me.bsVersion.DataSource = GetType(CSI00200Front.CSI00200ServiceRef.RCustDBVersionComboDTO)
        '
        'bsProject
        '
        Me.bsProject.DataSource = GetType(CSI00200Front.CSI00200ServiceRef.RCustDBProjectComboDTO)
        '
        'lblProject
        '
        Me.lblProject.AutoSize = False
        Me.lblProject.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblProject.Location = New System.Drawing.Point(12, 64)
        Me.lblProject.Name = "lblProject"
        Me.lblProject.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblProject.R_ResourceId = "lblProject"
        Me.lblProject.Size = New System.Drawing.Size(100, 18)
        Me.lblProject.TabIndex = 37
        Me.lblProject.Text = "Application..."
        '
        'cboProject
        '
        Me.cboProject.DataSource = Me.bsProject
        Me.cboProject.DisplayMember = "CPROJECT_NAME"
        Me.cboProject.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboProject.Location = New System.Drawing.Point(118, 64)
        Me.cboProject.Name = "cboProject"
        Me.cboProject.R_ConductorGridSource = Nothing
        Me.cboProject.R_ConductorSource = Nothing
        Me.cboProject.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboProject.Size = New System.Drawing.Size(400, 20)
        Me.cboProject.TabIndex = 38
        Me.cboProject.Text = "R_RadDropDownList1"
        Me.cboProject.ValueMember = "CPROJECT_ID"
        '
        'cboVersion
        '
        Me.cboVersion.DataSource = Me.bsVersion
        Me.cboVersion.DisplayMember = "CCODE_NAME"
        Me.cboVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboVersion.Location = New System.Drawing.Point(118, 38)
        Me.cboVersion.Name = "cboVersion"
        Me.cboVersion.R_ConductorGridSource = Nothing
        Me.cboVersion.R_ConductorSource = Nothing
        Me.cboVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboVersion.Size = New System.Drawing.Size(202, 20)
        Me.cboVersion.TabIndex = 36
        Me.cboVersion.Text = "R_RadDropDownList1"
        Me.cboVersion.ValueMember = "CVERSION"
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(12, 12)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 33
        Me.lblApplication.Text = "Application..."
        '
        'lblVersion
        '
        Me.lblVersion.AutoSize = False
        Me.lblVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblVersion.Location = New System.Drawing.Point(12, 38)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblVersion.R_ResourceId = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(100, 18)
        Me.lblVersion.TabIndex = 35
        Me.lblVersion.Text = "Application..."
        '
        'cboApplication
        '
        Me.cboApplication.DataSource = Me.bsApps
        Me.cboApplication.DisplayMember = "CAPPS_NAME"
        Me.cboApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboApplication.Location = New System.Drawing.Point(118, 12)
        Me.cboApplication.Name = "cboApplication"
        Me.cboApplication.R_ConductorGridSource = Nothing
        Me.cboApplication.R_ConductorSource = Nothing
        Me.cboApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboApplication.Size = New System.Drawing.Size(400, 20)
        Me.cboApplication.TabIndex = 34
        Me.cboApplication.Text = "R_RadDropDownList1"
        Me.cboApplication.ValueMember = "CAPPS_CODE"
        '
        'chkOption
        '
        Me.chkOption.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.chkOption.Location = New System.Drawing.Point(118, 116)
        Me.chkOption.Name = "chkOption"
        Me.chkOption.R_ConductorGridSource = Nothing
        Me.chkOption.R_ConductorSource = Nothing
        Me.chkOption.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.chkOption.R_ResourceId = "chkOption"
        Me.chkOption.Size = New System.Drawing.Size(107, 18)
        Me.chkOption.TabIndex = 39
        Me.chkOption.Text = "R_RadCheckBox1"
        '
        'lblSession
        '
        Me.lblSession.AutoSize = False
        Me.lblSession.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblSession.Location = New System.Drawing.Point(12, 90)
        Me.lblSession.Name = "lblSession"
        Me.lblSession.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblSession.R_ResourceId = "lblSession"
        Me.lblSession.Size = New System.Drawing.Size(100, 18)
        Me.lblSession.TabIndex = 42
        Me.lblSession.Text = "Application..."
        '
        'cboSession
        '
        Me.cboSession.DataSource = Me.bsSession
        Me.cboSession.DisplayMember = "CSESSION_AND_STATUS"
        Me.cboSession.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboSession.Location = New System.Drawing.Point(118, 90)
        Me.cboSession.Name = "cboSession"
        Me.cboSession.R_ConductorGridSource = Nothing
        Me.cboSession.R_ConductorSource = Nothing
        Me.cboSession.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboSession.Size = New System.Drawing.Size(400, 20)
        Me.cboSession.TabIndex = 41
        Me.cboSession.Text = "R_RadDropDownList1"
        Me.cboSession.ValueMember = "CSESSION_ID"
        '
        'chkOutstanding
        '
        Me.chkOutstanding.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.chkOutstanding.Location = New System.Drawing.Point(118, 140)
        Me.chkOutstanding.Name = "chkOutstanding"
        Me.chkOutstanding.R_ConductorGridSource = Nothing
        Me.chkOutstanding.R_ConductorSource = Nothing
        Me.chkOutstanding.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.chkOutstanding.R_ResourceId = "chkOutstanding"
        Me.chkOutstanding.Size = New System.Drawing.Size(107, 18)
        Me.chkOutstanding.TabIndex = 43
        Me.chkOutstanding.Text = "R_RadCheckBox1"
        '
        'CSI00200Filter
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(531, 179)
        Me.ControlBox = False
        Me.Controls.Add(Me.chkOutstanding)
        Me.Controls.Add(Me.lblSession)
        Me.Controls.Add(Me.cboSession)
        Me.Controls.Add(Me.chkOption)
        Me.Controls.Add(Me.lblProject)
        Me.Controls.Add(Me.cboProject)
        Me.Controls.Add(Me.cboVersion)
        Me.Controls.Add(Me.lblApplication)
        Me.Controls.Add(Me.lblVersion)
        Me.Controls.Add(Me.cboApplication)
        Me.Controls.Add(Me.R_ReturnPopUp1)
        Me.Name = "CSI00200Filter"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "Filter"
        CType(Me.R_ReturnPopUp1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkOption, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkOutstanding, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents R_ReturnPopUp1 As R_FrontEnd.R_ReturnPopUp
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource
    Friend WithEvents bsVersion As System.Windows.Forms.BindingSource
    Friend WithEvents bsProject As System.Windows.Forms.BindingSource
    Friend WithEvents lblProject As R_FrontEnd.R_RadLabel
    Friend WithEvents cboProject As R_FrontEnd.R_RadDropDownList
    Friend WithEvents cboVersion As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents lblVersion As R_FrontEnd.R_RadLabel
    Friend WithEvents cboApplication As R_FrontEnd.R_RadDropDownList
    Friend WithEvents chkOption As R_FrontEnd.R_RadCheckBox
    Friend WithEvents lblSession As R_FrontEnd.R_RadLabel
    Friend WithEvents cboSession As R_FrontEnd.R_RadDropDownList
    Friend WithEvents bsSession As System.Windows.Forms.BindingSource
    Friend WithEvents chkOutstanding As R_FrontEnd.R_RadCheckBox

End Class
