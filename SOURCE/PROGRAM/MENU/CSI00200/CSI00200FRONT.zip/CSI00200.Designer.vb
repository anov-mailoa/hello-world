﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSI00200
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn6 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn7 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn8 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn9 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn10 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn1 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewTextBoxColumn11 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn12 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn13 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn14 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn15 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDecimalColumn1 As R_FrontEnd.R_GridViewDecimalColumn = New R_FrontEnd.R_GridViewDecimalColumn()
        Dim R_GridViewDateTimeColumn2 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn3 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDecimalColumn2 As R_FrontEnd.R_GridViewDecimalColumn = New R_FrontEnd.R_GridViewDecimalColumn()
        Dim R_GridViewDateTimeColumn4 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn5 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDecimalColumn3 As R_FrontEnd.R_GridViewDecimalColumn = New R_FrontEnd.R_GridViewDecimalColumn()
        Dim R_GridViewDateTimeColumn6 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn7 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn16 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.gvIssueStatus = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvIssueStatus = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridIssueStatus = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblSession = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtSession = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.btnFilter = New R_FrontEnd.R_PopUp(Me.components)
        Me.txtProject = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtVersion = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtApplication = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblProject = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblVersion = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvAssignment = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvAssignment = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridAssignment = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.gvIssueStatus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvIssueStatus.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvIssueStatus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridIssueStatus, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.lblSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnFilter, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvAssignment, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvAssignment.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvAssignment, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridAssignment, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.gvIssueStatus, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.gvAssignment, 0, 2)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 120.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 70.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'gvIssueStatus
        '
        Me.gvIssueStatus.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvIssueStatus.EnableFastScrolling = True
        Me.gvIssueStatus.Location = New System.Drawing.Point(3, 123)
        '
        '
        '
        Me.gvIssueStatus.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn1.FieldName = "CATTRIBUTE_NAME"
        R_GridViewTextBoxColumn1.HeaderText = "_CATTRIBUTE_NAME"
        R_GridViewTextBoxColumn1.Name = "_CATTRIBUTE_NAME"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CATTRIBUTE_NAME"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 125
        R_GridViewTextBoxColumn2.FieldName = "CITEM_ID"
        R_GridViewTextBoxColumn2.HeaderText = "_CITEM_ID"
        R_GridViewTextBoxColumn2.Name = "_CITEM_ID"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CITEM_ID"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 74
        R_GridViewTextBoxColumn3.FieldName = "CITEM_NAME"
        R_GridViewTextBoxColumn3.HeaderText = "_CITEM_NAME"
        R_GridViewTextBoxColumn3.Name = "_CITEM_NAME"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CITEM_NAME"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 95
        R_GridViewDateTimeColumn1.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn1.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn1.FieldName = "DISSUE_DATE"
        R_GridViewDateTimeColumn1.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn1.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn1.HeaderText = "_DISSUE_DATE"
        R_GridViewDateTimeColumn1.Name = "_DISSUE_DATE"
        R_GridViewDateTimeColumn1.R_ResourceId = "_DISSUE_DATE"
        R_GridViewDateTimeColumn1.Width = 95
        R_GridViewTextBoxColumn4.FieldName = "CISSUE_ID"
        R_GridViewTextBoxColumn4.HeaderText = "_CISSUE_ID"
        R_GridViewTextBoxColumn4.Name = "_CISSUE_ID"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CISSUE_ID"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 78
        R_GridViewTextBoxColumn5.FieldName = "CUSER_ID"
        R_GridViewTextBoxColumn5.HeaderText = "_CUSER_ID"
        R_GridViewTextBoxColumn5.Name = "_CUSER_ID"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CUSER_ID"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 76
        R_GridViewTextBoxColumn6.FieldName = "CISSUE_TYPE"
        R_GridViewTextBoxColumn6.HeaderText = "_CISSUE_TYPE"
        R_GridViewTextBoxColumn6.Name = "_CISSUE_TYPE"
        R_GridViewTextBoxColumn6.R_ResourceId = "_CISSUE_TYPE"
        R_GridViewTextBoxColumn6.R_UDT = Nothing
        R_GridViewTextBoxColumn6.Width = 91
        R_GridViewTextBoxColumn7.FieldName = "CISSUE_CLASS_DESCRIPTION"
        R_GridViewTextBoxColumn7.HeaderText = "_CISSUE_CLASS_DESCRIPTION"
        R_GridViewTextBoxColumn7.Name = "_CISSUE_CLASS_DESCRIPTION"
        R_GridViewTextBoxColumn7.R_ResourceId = "_CISSUE_CLASS_DESCRIPTION"
        R_GridViewTextBoxColumn7.R_UDT = Nothing
        R_GridViewTextBoxColumn7.Width = 172
        R_GridViewTextBoxColumn8.FieldName = "CDESCRIPTION"
        R_GridViewTextBoxColumn8.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxColumn8.Name = "_CDESCRIPTION"
        R_GridViewTextBoxColumn8.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxColumn8.R_UDT = Nothing
        R_GridViewTextBoxColumn8.Width = 103
        R_GridViewTextBoxColumn8.WrapText = True
        R_GridViewTextBoxColumn9.FieldName = "CSCHEDULE_ID"
        R_GridViewTextBoxColumn9.HeaderText = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn9.Name = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn9.R_ResourceId = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn9.R_UDT = Nothing
        R_GridViewTextBoxColumn9.Width = 103
        R_GridViewTextBoxColumn10.FieldName = "CPREV_SCHEDULE_ID"
        R_GridViewTextBoxColumn10.HeaderText = "_CPREV_SCHEDULE_ID"
        R_GridViewTextBoxColumn10.Name = "_CPREV_SCHEDULE_ID"
        R_GridViewTextBoxColumn10.R_ResourceId = "_CPREV_SCHEDULE_ID"
        R_GridViewTextBoxColumn10.R_UDT = Nothing
        R_GridViewTextBoxColumn10.Width = 134
        R_GridViewCheckBoxColumn1.FieldName = "LOK"
        R_GridViewCheckBoxColumn1.HeaderText = "_LOK"
        R_GridViewCheckBoxColumn1.Name = "_LOK"
        R_GridViewCheckBoxColumn1.R_ResourceId = "_LOK"
        R_GridViewCheckBoxColumn1.Width = 62
        R_GridViewTextBoxColumn11.FieldName = "CSCHEDULE_STATUS"
        R_GridViewTextBoxColumn11.HeaderText = "_CSCHEDULE_STATUS"
        R_GridViewTextBoxColumn11.Name = "_CSCHEDULE_STATUS"
        R_GridViewTextBoxColumn11.R_ResourceId = "_CSCHEDULE_STATUS"
        R_GridViewTextBoxColumn11.R_UDT = Nothing
        R_GridViewTextBoxColumn11.Width = 131
        Me.gvIssueStatus.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewDateTimeColumn1, R_GridViewTextBoxColumn4, R_GridViewTextBoxColumn5, R_GridViewTextBoxColumn6, R_GridViewTextBoxColumn7, R_GridViewTextBoxColumn8, R_GridViewTextBoxColumn9, R_GridViewTextBoxColumn10, R_GridViewCheckBoxColumn1, R_GridViewTextBoxColumn11})
        Me.gvIssueStatus.MasterTemplate.DataSource = Me.bsGvIssueStatus
        Me.gvIssueStatus.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvIssueStatus.MasterTemplate.EnableFiltering = True
        Me.gvIssueStatus.MasterTemplate.EnableGrouping = False
        Me.gvIssueStatus.MasterTemplate.ShowFilteringRow = False
        Me.gvIssueStatus.MasterTemplate.ShowGroupedColumns = True
        Me.gvIssueStatus.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvIssueStatus.Name = "gvIssueStatus"
        Me.gvIssueStatus.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvIssueStatus.R_ConductorGridSource = Me.conGridIssueStatus
        Me.gvIssueStatus.R_ConductorSource = Nothing
        Me.gvIssueStatus.R_DataAdded = False
        Me.gvIssueStatus.R_NewRowText = Nothing
        Me.gvIssueStatus.ReadOnly = True
        Me.gvIssueStatus.ShowHeaderCellButtons = True
        Me.gvIssueStatus.Size = New System.Drawing.Size(1271, 312)
        Me.gvIssueStatus.TabIndex = 0
        Me.gvIssueStatus.Text = "R_RadGridView1"
        '
        'bsGvIssueStatus
        '
        Me.bsGvIssueStatus.DataSource = GetType(CSI00200Front.CSI00200StreamingServiceRef.CSI00200IssueStatusDTO)
        '
        'conGridIssueStatus
        '
        Me.conGridIssueStatus.R_ConductorParent = Nothing
        Me.conGridIssueStatus.R_IsHeader = True
        Me.conGridIssueStatus.R_RadGroupBox = Nothing
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lblSession)
        Me.Panel1.Controls.Add(Me.txtSession)
        Me.Panel1.Controls.Add(Me.btnFilter)
        Me.Panel1.Controls.Add(Me.txtProject)
        Me.Panel1.Controls.Add(Me.txtVersion)
        Me.Panel1.Controls.Add(Me.txtApplication)
        Me.Panel1.Controls.Add(Me.lblProject)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Controls.Add(Me.lblVersion)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 114)
        Me.Panel1.TabIndex = 1
        '
        'lblSession
        '
        Me.lblSession.AutoSize = False
        Me.lblSession.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblSession.Location = New System.Drawing.Point(9, 87)
        Me.lblSession.Name = "lblSession"
        Me.lblSession.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblSession.R_ResourceId = "lblSession"
        Me.lblSession.Size = New System.Drawing.Size(100, 18)
        Me.lblSession.TabIndex = 59
        Me.lblSession.Text = "Application..."
        '
        'txtSession
        '
        Me.txtSession.Location = New System.Drawing.Point(115, 86)
        Me.txtSession.Name = "txtSession"
        Me.txtSession.R_ConductorGridSource = Nothing
        Me.txtSession.R_ConductorSource = Nothing
        Me.txtSession.R_UDT = Nothing
        Me.txtSession.ReadOnly = True
        Me.txtSession.Size = New System.Drawing.Size(200, 20)
        Me.txtSession.TabIndex = 58
        Me.txtSession.TabStop = False
        '
        'btnFilter
        '
        Me.btnFilter.Location = New System.Drawing.Point(539, 6)
        Me.btnFilter.Name = "btnFilter"
        Me.btnFilter.R_ConductorGridSource = Me.conGridIssueStatus
        Me.btnFilter.R_ConductorSource = Nothing
        Me.btnFilter.R_DescriptionId = Nothing
        Me.btnFilter.R_ResourceId = "btnFilter"
        Me.btnFilter.R_Title = "Issue Filter"
        Me.btnFilter.Size = New System.Drawing.Size(110, 24)
        Me.btnFilter.TabIndex = 57
        Me.btnFilter.Text = "R_PopUp1"
        '
        'txtProject
        '
        Me.txtProject.Location = New System.Drawing.Point(115, 60)
        Me.txtProject.Name = "txtProject"
        Me.txtProject.R_ConductorGridSource = Nothing
        Me.txtProject.R_ConductorSource = Nothing
        Me.txtProject.R_UDT = Nothing
        Me.txtProject.ReadOnly = True
        Me.txtProject.Size = New System.Drawing.Size(400, 20)
        Me.txtProject.TabIndex = 56
        Me.txtProject.TabStop = False
        '
        'txtVersion
        '
        Me.txtVersion.Location = New System.Drawing.Point(115, 34)
        Me.txtVersion.Name = "txtVersion"
        Me.txtVersion.R_ConductorGridSource = Nothing
        Me.txtVersion.R_ConductorSource = Nothing
        Me.txtVersion.R_UDT = Nothing
        Me.txtVersion.ReadOnly = True
        Me.txtVersion.Size = New System.Drawing.Size(200, 20)
        Me.txtVersion.TabIndex = 55
        Me.txtVersion.TabStop = False
        '
        'txtApplication
        '
        Me.txtApplication.Location = New System.Drawing.Point(115, 8)
        Me.txtApplication.Name = "txtApplication"
        Me.txtApplication.R_ConductorGridSource = Nothing
        Me.txtApplication.R_ConductorSource = Nothing
        Me.txtApplication.R_UDT = Nothing
        Me.txtApplication.ReadOnly = True
        Me.txtApplication.Size = New System.Drawing.Size(400, 20)
        Me.txtApplication.TabIndex = 54
        Me.txtApplication.TabStop = False
        '
        'lblProject
        '
        Me.lblProject.AutoSize = False
        Me.lblProject.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblProject.Location = New System.Drawing.Point(9, 61)
        Me.lblProject.Name = "lblProject"
        Me.lblProject.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblProject.R_ResourceId = "lblProject"
        Me.lblProject.Size = New System.Drawing.Size(100, 18)
        Me.lblProject.TabIndex = 53
        Me.lblProject.Text = "Application..."
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 51
        Me.lblApplication.Text = "Application..."
        '
        'lblVersion
        '
        Me.lblVersion.AutoSize = False
        Me.lblVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblVersion.Location = New System.Drawing.Point(9, 35)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblVersion.R_ResourceId = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(100, 18)
        Me.lblVersion.TabIndex = 52
        Me.lblVersion.Text = "Application..."
        '
        'gvAssignment
        '
        Me.gvAssignment.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvAssignment.EnableFastScrolling = True
        Me.gvAssignment.Location = New System.Drawing.Point(3, 441)
        '
        '
        '
        Me.gvAssignment.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn12.FieldName = "CFUNCTION_ID"
        R_GridViewTextBoxColumn12.HeaderText = "_CFUNCTION_ID"
        R_GridViewTextBoxColumn12.Name = "_CFUNCTION_ID"
        R_GridViewTextBoxColumn12.R_ResourceId = "_CFUNCTION_ID"
        R_GridViewTextBoxColumn12.R_UDT = Nothing
        R_GridViewTextBoxColumn12.Width = 104
        R_GridViewTextBoxColumn13.FieldName = "CUSER_ID"
        R_GridViewTextBoxColumn13.HeaderText = "_CUSER_ID"
        R_GridViewTextBoxColumn13.Name = "_CUSER_ID"
        R_GridViewTextBoxColumn13.R_ResourceId = "_CUSER_ID"
        R_GridViewTextBoxColumn13.R_UDT = Nothing
        R_GridViewTextBoxColumn13.Width = 76
        R_GridViewTextBoxColumn14.FieldName = "CREASSIGNMENT_ID"
        R_GridViewTextBoxColumn14.HeaderText = "_CREASSIGNMENT_ID"
        R_GridViewTextBoxColumn14.Name = "_CREASSIGNMENT_ID"
        R_GridViewTextBoxColumn14.R_ResourceId = "_CREASSIGNMENT_ID"
        R_GridViewTextBoxColumn14.R_UDT = Nothing
        R_GridViewTextBoxColumn14.Width = 131
        R_GridViewTextBoxColumn15.FieldName = "CLOCATION_NAME"
        R_GridViewTextBoxColumn15.HeaderText = "_CLOCATION_NAME"
        R_GridViewTextBoxColumn15.Name = "_CLOCATION_NAME"
        R_GridViewTextBoxColumn15.R_ResourceId = "_CLOCATION_NAME"
        R_GridViewTextBoxColumn15.R_UDT = Nothing
        R_GridViewTextBoxColumn15.Width = 124
        R_GridViewDecimalColumn1.FieldName = "NMANDAYS"
        R_GridViewDecimalColumn1.FormatString = "{0:N}"
        R_GridViewDecimalColumn1.HeaderText = "_NMANDAYS"
        R_GridViewDecimalColumn1.Name = "_NMANDAYS"
        R_GridViewDecimalColumn1.R_ResourceId = "_NMANDAYS"
        R_GridViewDecimalColumn1.ThousandsSeparator = True
        R_GridViewDecimalColumn1.Width = 89
        R_GridViewDateTimeColumn2.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn2.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn2.FieldName = "DPLAN_START_DATE"
        R_GridViewDateTimeColumn2.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn2.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn2.HeaderText = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn2.Name = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn2.R_ResourceId = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn2.Width = 131
        R_GridViewDateTimeColumn3.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn3.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn3.FieldName = "DPLAN_END_DATE"
        R_GridViewDateTimeColumn3.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn3.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn3.HeaderText = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn3.Name = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn3.R_ResourceId = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn3.Width = 121
        R_GridViewDecimalColumn2.FieldName = "NREVISED_MANDAYS"
        R_GridViewDecimalColumn2.FormatString = "{0:N}"
        R_GridViewDecimalColumn2.HeaderText = "_NREVISED_MANDAYS"
        R_GridViewDecimalColumn2.Name = "_NREVISED_MANDAYS"
        R_GridViewDecimalColumn2.R_ResourceId = "_NREVISED_MANDAYS"
        R_GridViewDecimalColumn2.ThousandsSeparator = True
        R_GridViewDecimalColumn2.Width = 136
        R_GridViewDateTimeColumn4.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn4.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn4.FieldName = "DREVISED_START_DATE"
        R_GridViewDateTimeColumn4.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn4.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn4.HeaderText = "_DREVISED_START_DATE"
        R_GridViewDateTimeColumn4.Name = "_DREVISED_START_DATE"
        R_GridViewDateTimeColumn4.R_ResourceId = "_DREVISED_START_DATE"
        R_GridViewDateTimeColumn4.Width = 145
        R_GridViewDateTimeColumn5.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn5.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn5.FieldName = "DREVISED_END_DATE"
        R_GridViewDateTimeColumn5.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn5.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn5.HeaderText = "_DREVISED_END_DATE"
        R_GridViewDateTimeColumn5.Name = "_DREVISED_END_DATE"
        R_GridViewDateTimeColumn5.R_ResourceId = "_DREVISED_END_DATE"
        R_GridViewDateTimeColumn5.Width = 136
        R_GridViewDecimalColumn3.FieldName = "NACTUAL_MANDAYS"
        R_GridViewDecimalColumn3.FormatString = "{0:N}"
        R_GridViewDecimalColumn3.HeaderText = "_NACTUAL_MANDAYS"
        R_GridViewDecimalColumn3.Name = "_NACTUAL_MANDAYS"
        R_GridViewDecimalColumn3.R_ResourceId = "_NACTUAL_MANDAYS"
        R_GridViewDecimalColumn3.ThousandsSeparator = True
        R_GridViewDecimalColumn3.Width = 134
        R_GridViewDateTimeColumn6.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn6.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn6.FieldName = "DACTUAL_START_DATE"
        R_GridViewDateTimeColumn6.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn6.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn6.HeaderText = "_DACTUAL_START_DATE"
        R_GridViewDateTimeColumn6.Name = "_DACTUAL_START_DATE"
        R_GridViewDateTimeColumn6.R_ResourceId = "_DACTUAL_START_DATE"
        R_GridViewDateTimeColumn6.Width = 144
        R_GridViewDateTimeColumn7.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn7.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn7.FieldName = "DACTUAL_END_DATE"
        R_GridViewDateTimeColumn7.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn7.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn7.HeaderText = "_DACTUAL_END_DATE"
        R_GridViewDateTimeColumn7.Name = "_DACTUAL_END_DATE"
        R_GridViewDateTimeColumn7.R_ResourceId = "_DACTUAL_END_DATE"
        R_GridViewDateTimeColumn7.Width = 134
        R_GridViewTextBoxColumn16.FieldName = "CASSIGNMENT_STATUS"
        R_GridViewTextBoxColumn16.HeaderText = "_CASSIGNMENT_STATUS"
        R_GridViewTextBoxColumn16.Name = "_CASSIGNMENT_STATUS"
        R_GridViewTextBoxColumn16.R_ResourceId = "_CASSIGNMENT_STATUS"
        R_GridViewTextBoxColumn16.R_UDT = Nothing
        R_GridViewTextBoxColumn16.Width = 147
        Me.gvAssignment.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn12, R_GridViewTextBoxColumn13, R_GridViewTextBoxColumn14, R_GridViewTextBoxColumn15, R_GridViewDecimalColumn1, R_GridViewDateTimeColumn2, R_GridViewDateTimeColumn3, R_GridViewDecimalColumn2, R_GridViewDateTimeColumn4, R_GridViewDateTimeColumn5, R_GridViewDecimalColumn3, R_GridViewDateTimeColumn6, R_GridViewDateTimeColumn7, R_GridViewTextBoxColumn16})
        Me.gvAssignment.MasterTemplate.DataSource = Me.bsGvAssignment
        Me.gvAssignment.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvAssignment.MasterTemplate.EnableFiltering = True
        Me.gvAssignment.MasterTemplate.EnableGrouping = False
        Me.gvAssignment.MasterTemplate.ShowFilteringRow = False
        Me.gvAssignment.MasterTemplate.ShowGroupedColumns = True
        Me.gvAssignment.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvAssignment.Name = "gvAssignment"
        Me.gvAssignment.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvAssignment.R_ConductorGridSource = Me.conGridAssignment
        Me.gvAssignment.R_ConductorSource = Nothing
        Me.gvAssignment.R_DataAdded = False
        Me.gvAssignment.R_NewRowText = Nothing
        Me.gvAssignment.ReadOnly = True
        Me.gvAssignment.ShowHeaderCellButtons = True
        Me.gvAssignment.Size = New System.Drawing.Size(1271, 131)
        Me.gvAssignment.TabIndex = 2
        Me.gvAssignment.Text = "R_RadGridView1"
        '
        'bsGvAssignment
        '
        Me.bsGvAssignment.DataSource = GetType(CSI00200Front.CSI00200StreamingServiceRef.CSI00200AssignmentDTO)
        '
        'conGridAssignment
        '
        Me.conGridAssignment.R_ConductorParent = Me.conGridIssueStatus
        Me.conGridAssignment.R_RadGroupBox = Nothing
        '
        'CSI00200
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CSI00200"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.TableLayoutPanel1.ResumeLayout(False)
        CType(Me.gvIssueStatus.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvIssueStatus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvIssueStatus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridIssueStatus, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.lblSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnFilter, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvAssignment.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvAssignment, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvAssignment, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridAssignment, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(false)

End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents bsGvIssueStatus As System.Windows.Forms.BindingSource
    Friend WithEvents bsGvAssignment As System.Windows.Forms.BindingSource
    Friend WithEvents conGridIssueStatus As R_FrontEnd.R_ConductorGrid
    Friend WithEvents gvIssueStatus As R_FrontEnd.R_RadGridView
    Friend WithEvents conGridAssignment As R_FrontEnd.R_ConductorGrid
    Friend WithEvents R_RadGridView2 As R_FrontEnd.R_RadGridView
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents txtProject As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtVersion As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtApplication As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblProject As R_FrontEnd.R_RadLabel
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents lblVersion As R_FrontEnd.R_RadLabel
    Friend WithEvents btnFilter As R_FrontEnd.R_PopUp
    Friend WithEvents gvAssignment As R_FrontEnd.R_RadGridView
    Friend WithEvents lblSession As R_FrontEnd.R_RadLabel
    Friend WithEvents txtSession As R_FrontEnd.R_RadTextBox

End Class
