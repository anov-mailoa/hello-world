﻿Imports R_Common
Imports R_BackEnd
Imports ServerHelper.General

Public Class CSI00200Cls

    Public Function GetIssueStatus(poKey As CSI00200ParamDTO) As List(Of CSI00200IssueStatusDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSI00200IssueStatusDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "EXEC RSP_Issue_Status '{0}', '{1}', '{2}', '{3}', '{4}', {5}, '{6}', '{7}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID, .CSESSION_ID, getBit(.LOUTSTANDING), .COPTION, .CUSER_ID)
            End With
            loResult = loDb.SqlExecObjectQuery(Of CSI00200IssueStatusDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetAssignment(poKey As CSI00200ParamDTO) As List(Of CSI00200AssignmentDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSI00200AssignmentDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "EXEC RSP_Issue_Status_Assignment '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID, .CSESSION_ID, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CITEM_ID, .CISSUE_ID)
            End With
            loResult = loDb.SqlExecObjectQuery(Of CSI00200AssignmentDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function


End Class
