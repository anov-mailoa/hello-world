﻿Public Class CSI00200AssignmentDTO
    Public Property CATTRIBUTE_ID As String
    Public Property CITEM_ID As String
    Public Property CISSUE_ID As String
    Public Property CFUNCTION_ID As String
    Public Property CUSER_ID As String
    Public Property CREASSIGNMENT_ID As String
    Public Property CLOCATION_ID As String
    Public Property CLOCATION_NAME As String
    Public Property NMANDAYS As Decimal
    Public Property CPLAN_START_DATE As String
    Public Property CPLAN_END_DATE As String
    Public Property NREVISED_MANDAYS As Decimal
    Public Property CREVISED_START_DATE As String
    Public Property CREVISED_END_DATE As String
    Public Property NACTUAL_MANDAYS As Decimal
    Public Property CACTUAL_START_DATE As String
    Public Property CACTUAL_END_DATE As String
    Public Property CASSIGNMENT_STATUS As String

    Public Property DPLAN_START_DATE As Nullable(Of DateTime)
    Public Property DPLAN_END_DATE As Nullable(Of DateTime)
    Public Property DREVISED_START_DATE As Nullable(Of DateTime)
    Public Property DREVISED_END_DATE As Nullable(Of DateTime)
    Public Property DACTUAL_START_DATE As Nullable(Of DateTime)
    Public Property DACTUAL_END_DATE As Nullable(Of DateTime)

End Class
