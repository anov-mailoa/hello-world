﻿Public Class CSI00200IssueStatusDTO
    Public Property CATTRIBUTE_ID As String
    Public Property CATTRIBUTE_NAME As String
    Public Property CITEM_ID As String
    Public Property CITEM_NAME As String
    Public Property CISSUE_DATE As String
    Public Property CISSUE_ID As String
    Public Property CUSER_ID As String
    Public Property CISSUE_TYPE As String
    Public Property CISSUE_CLASS As String
    Public Property CISSUE_CLASS_DESCRIPTION As String
    Public Property CDESCRIPTION As String
    Public Property CSCHEDULE_ID As String
    Public Property CPREV_SCHEDULE_ID As String
    Public Property LOK As Boolean
    Public Property CSCHEDULE_STATUS As String

    Public Property DISSUE_DATE As Nullable(Of DateTime)

End Class
