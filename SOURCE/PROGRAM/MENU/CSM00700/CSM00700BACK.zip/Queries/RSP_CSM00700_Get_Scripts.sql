/****** Object:  StoredProcedure [dbo].[RSP_CSM00700_Get_Scripts]    Script Date: 9/22/2014 3:54:01 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSP_CSM00700_Get_Scripts]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSP_CSM00700_Get_Scripts]
GO

/****** Object:  StoredProcedure [dbo].[RSP_CSM00700_Get_Scripts]    Script Date: 9/22/2014 3:54:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Anov Mailoa
-- Create date: 9 October 2019
-- Description:	RSP_CSM00700_Get_Scripts - To create changes relative to previous database version
-- =============================================
CREATE PROCEDURE [dbo].[RSP_CSM00700_Get_Scripts] 
	@CCOMPANY_ID VARCHAR(8) = 'RND',
	@CAPPS_CODE VARCHAR(20) = 'MyApp',
	@CDATABASE_ID VARCHAR(20) = 'Sandbox'
WITH RECOMPILE, ENCRYPTION
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @CSTATUS VARCHAR(10)
	SELECT @CSTATUS = 'ERROR'

	IF NOT EXISTS (SELECT *
	FROM sys.databases
	WHERE name = @CDATABASE_ID)
	BEGIN
		SELECT @CSTATUS = 'ERROR'
	END
	ELSE BEGIN
		SELECT @CSTATUS = 'OK'
	END

	IF @CSTATUS = 'OK' BEGIN

		SELECT B.CVERSION, A.CDB_CHANGE_ID, A.CSCRIPT_ID, A.CFILE_NAME, A.OBINARY_FILE_DATA
		FROM CST_DB_CHANGES_SCRIPTS A (NOLOCK)
		JOIN CST_DB_CHANGES B (NOLOCK)
		ON B.CCOMPANY_ID = A.CCOMPANY_ID
		AND B.CAPPS_CODE = A.CAPPS_CODE
		AND B.CDATABASE_ID = A.CDATABASE_ID
		AND B.CDB_CHANGE_ID = A.CDB_CHANGE_ID
		AND B.CSTATUS = 'NEW'
		WHERE A.CCOMPANY_ID = @CCOMPANY_ID
		AND A.CAPPS_CODE = @CAPPS_CODE
		AND A.CDATABASE_ID = @CDATABASE_ID
			
		SELECT @CSTATUS = 'OK'

	END

	RETURN
END
GO
