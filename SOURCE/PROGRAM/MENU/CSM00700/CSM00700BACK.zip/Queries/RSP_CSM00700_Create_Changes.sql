/****** Object:  StoredProcedure [dbo].[RSP_CSM00700_Create_Changes]    Script Date: 9/22/2014 3:54:01 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSP_CSM00700_Create_Changes]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSP_CSM00700_Create_Changes]
GO

/****** Object:  StoredProcedure [dbo].[RSP_CSM00700_Create_Changes]    Script Date: 9/22/2014 3:54:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Anov Mailoa
-- Create date: 9 October 2019
-- Description:	RSP_CSM00700_Create_Changes - To create changes relative to previous database version
-- =============================================
CREATE PROCEDURE [dbo].[RSP_CSM00700_Create_Changes] 
	@CCOMPANY_ID VARCHAR(8) = 'RND',
	@CAPPS_CODE VARCHAR(20) = 'MyApp',
	@CDATABASE_ID VARCHAR(20) = 'Sandbox',
	@CUSER_ID VARCHAR(8) = '280014',
	@CSTATUS VARCHAR(10) OUTPUT,
	@CMESSAGE NVARCHAR(MAX) OUTPUT
WITH RECOMPILE, ENCRYPTION
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @CDB_CHANGE_ID VARCHAR(20),
		@ICHANGES_COUNT INTEGER

	SELECT @CSTATUS = 'ERROR',
		@CMESSAGE = 'Nothing has been processed.'

	IF NOT EXISTS (SELECT *
	FROM sys.databases
	WHERE name = @CDATABASE_ID)
	BEGIN
		SELECT @CSTATUS = 'ERROR',
			@CMESSAGE = 'Database does not exist.'
	END
	ELSE BEGIN
		SELECT @CSTATUS = 'OK'
	END

	IF @CSTATUS = 'OK' BEGIN

		-- Cari change ID terakhir
		SELECT @ICHANGES_COUNT = COUNT(CDB_CHANGE_ID)
		FROM CST_DB_CHANGES (NOLOCK)
		WHERE CCOMPANY_ID = @CCOMPANY_ID
		AND CAPPS_CODE = @CAPPS_CODE
		AND CDATABASE_ID = @CDATABASE_ID

		SELECT @CDB_CHANGE_ID = 'DBCS' + RIGHT('000000' + LTRIM(CONVERT(VARCHAR(6), @ICHANGES_COUNT)), 6)

		INSERT INTO CST_DB_CHANGES
		VALUES (@CCOMPANY_ID, @CAPPS_CODE, @CDATABASE_ID, @CDB_CHANGE_ID, 
		dbo.RFN_Get_Current_Version(@CCOMPANY_ID,@CAPPS_CODE), GETDATE(), 'NEW', '<Please fill Description>',
		@CUSER_ID, GETDATE(), @CUSER_ID, GETDATE())
		
		SELECT @CSTATUS = 'OK',
			@CMESSAGE = 'Changes have been recorded.'

	END

	RETURN
END
GO
