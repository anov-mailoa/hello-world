/****** Object:  StoredProcedure [dbo].[RSP_CSM00700_Save_Script]    Script Date: 9/22/2014 3:54:01 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSP_CSM00700_Save_Script]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSP_CSM00700_Save_Script]
GO

/****** Object:  StoredProcedure [dbo].[RSP_CSM00700_Save_Script]    Script Date: 9/22/2014 3:54:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Anov Mailoa
-- Create date: 18 October 2019
-- Description:	RSP_CSM00700_Save_Script - To save changes script
-- =============================================
CREATE PROCEDURE [dbo].[RSP_CSM00700_Save_Script] 
	@CCOMPANY_ID VARCHAR(8), -- 0
	@CAPPS_CODE VARCHAR(20), -- 1
	@CDATABASE_ID VARCHAR(20) = 'Sandbox', -- 2
	@CDB_CHANGE_ID VARCHAR(20) = '', -- 3
	@CFILE_NAME VARCHAR(50) = '', -- 4
	@CNOTE NVARCHAR(255) = N'', -- 5
	@CUSER_ID VARCHAR(8), -- 6
	@OFILE_DATA VARBINARY(MAX) -- 7
WITH RECOMPILE, ENCRYPTION
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @DTODAY AS DATETIME,
		@CSCRIPT_ID AS VARCHAR(10),
		@ICHANGES_COUNT INTEGER

	SELECT @DTODAY = GETDATE()

	-- Cari change ID terakhir
	SELECT @ICHANGES_COUNT = COUNT(CSCRIPT_ID)
	FROM CST_DB_CHANGES_SCRIPTS (NOLOCK)
	WHERE CCOMPANY_ID = @CCOMPANY_ID
	AND CAPPS_CODE = @CAPPS_CODE
	AND CDATABASE_ID = @CDATABASE_ID
	AND CDB_CHANGE_ID = @CDB_CHANGE_ID

	SELECT @CSCRIPT_ID = RIGHT('0000000000' + LTRIM(CONVERT(VARCHAR(10), @ICHANGES_COUNT+1)), 10)

	INSERT INTO CST_DB_CHANGES_SCRIPTS (
	CCOMPANY_ID,
	CAPPS_CODE,
	CDATABASE_ID,
	CDB_CHANGE_ID,
	CSCRIPT_ID,
	CFILE_NAME,
	OBINARY_FILE_DATA,
	CNOTE,
	LUPLOAD,
	CUPDATE_BY,
	DUPDATE_DATE,
	CCREATE_BY,
	DCREATE_DATE)
	VALUES (@CCOMPANY_ID, @CAPPS_CODE, @CDATABASE_ID, @CDB_CHANGE_ID, @CSCRIPT_ID, 
		@CFILE_NAME, @OFILE_DATA, @CNOTE, 1, @CUSER_ID, GETDATE(), @CUSER_ID, GETDATE())

END
GO
