/****** Object:  StoredProcedure [dbo].[RSP_CSM00700_Delete_Validation]    Script Date: 9/22/2014 3:54:01 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSP_CSM00700_Delete_Validation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSP_CSM00700_Delete_Validation]
GO

/****** Object:  StoredProcedure [dbo].[RSP_CSM00700_Delete_Validation]    Script Date: 9/22/2014 3:54:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Anov Mailoa
-- Create date: 16 Oktober 2019
-- Description:	RSP_CSM00700_Delete_Validation - To validate project removal
-- =============================================
CREATE PROCEDURE [dbo].[RSP_CSM00700_Delete_Validation] 
	@CCOMPANY_ID VARCHAR(8) = 'RND',
	@CAPPS_CODE VARCHAR(20) = 'MyApp',
	@CDATABASE_ID VARCHAR(20) = 'Sandbox',
	@CDB_CHANGE_ID VARCHAR(20) = '',
	@CSCRIPT_ID VARCHAR(100) = '',
	@CVALIDATION_MODE CHAR(1) = '1',
	@CRET_MSG VARCHAR(50) OUTPUT
WITH RECOMPILE, ENCRYPTION
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @CVALID_CODE AS VARCHAR(100)

	-- @@CVALIDATION_MODE values:
	-- 1 = Delete changes
	-- 2 = Delete scripts
	-- 3 = Upload scripts

	IF @CVALIDATION_MODE = '1' BEGIN

		-- check if there are any scripts
		SELECT TOP 1 @CVALID_CODE = CSCRIPT_ID
		FROM CST_DB_CHANGES_SCRIPTS (NOLOCK)
		WHERE CCOMPANY_ID = @CCOMPANY_ID
		AND CAPPS_CODE = @CAPPS_CODE
		AND CDATABASE_ID = @CDATABASE_ID
		AND CDB_CHANGE_ID = @CDB_CHANGE_ID
		IF @CVALID_CODE IS NOT NULL BEGIN
			-- Scripts found
			SELECT @CRET_MSG = 'SCRIPTS_EXISTS'
			RETURN
		END
	END

	IF @CVALIDATION_MODE = '2' OR @CVALIDATION_MODE = '3' BEGIN

		-- check version status
		SELECT @CVALID_CODE = B.CSTATUS 
		FROM CST_DB_CHANGES A (NOLOCK)
		JOIN RVT_APP_VERSION B (NOLOCK) 
		ON B.CCOMPANY_ID = A.CCOMPANY_ID
		AND B.CAPPS_CODE = A.CAPPS_CODE	
		AND B.CVERSION = A.CVERSION
		WHERE A.CCOMPANY_ID = @CCOMPANY_ID 
		AND A.CAPPS_CODE = @CAPPS_CODE 
		AND A.CDATABASE_ID = @CDATABASE_ID
		AND A.CDB_CHANGE_ID = @CDB_CHANGE_ID

		IF @CVALID_CODE IS NULL BEGIN
			-- Version error
			SELECT @CRET_MSG = 'VERSION_ERROR'
			RETURN
		END
		ELSE BEGIN
			-- Status error
			IF @CVALID_CODE = 'RELEASED' BEGIN
				SELECT @CRET_MSG = 'VERSION_RELEASED'
				RETURN
			END
		END

	END

	IF @CVALIDATION_MODE = '2' BEGIN

		-- only uploaded script can be deleted
		SELECT @CVALID_CODE = CASE WHEN A.LUPLOAD = 1 THEN 'VALID' ELSE 'INVALID' END
		FROM CST_DB_CHANGES_SCRIPTS A (NOLOCK)
		WHERE A.CCOMPANY_ID = @CCOMPANY_ID 
		AND A.CAPPS_CODE = @CAPPS_CODE 
		AND A.CDATABASE_ID = @CDATABASE_ID
		AND A.CDB_CHANGE_ID = @CDB_CHANGE_ID
		AND A.CSCRIPT_ID = @CSCRIPT_ID

		IF @CVALID_CODE IS NULL BEGIN
			-- Version error
			SELECT @CRET_MSG = 'SCRIPT_NOT_FOUND'
			RETURN
		END
		ELSE BEGIN
			-- Status error
			IF @CVALID_CODE = 'INVALID' BEGIN
				SELECT @CRET_MSG = 'SCRIPT_DELETE_INVALID'
				RETURN
			END
		END

	END

	SELECT @CRET_MSG = 'OK'
	RETURN
END
GO
