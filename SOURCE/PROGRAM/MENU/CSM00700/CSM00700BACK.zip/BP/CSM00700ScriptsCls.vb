﻿Imports System.Data.Common
Imports CSM00700Back
Imports R_BackEnd
Imports R_Common

Public Class CSM00700ScriptsCls
    Inherits R_BusinessObject(Of CSM00700ScriptsDTO)

    Public Function UploadScriptValidation(poKey As CSM00700KeyDTO) As String
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcRtn As String = "OK"

        Try

            With poKey

                loCmd = loDb.GetCommand()
                lcQuery = "EXEC RSP_CSM00700_Validation '{0}', '{1}', '{2}', '{3}', '', '3', @CRET_MSG OUTPUT "
                lcQuery = String.Format(lcQuery,
                                    .CCOMPANY_ID,
                                    .CAPPS_CODE,
                                    .CDATABASE_ID,
                                    .CDB_CHANGE_ID)
                loCmd.CommandText = lcQuery
                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@CRET_MSG"
                    .DbType = DbType.String
                    .Size = 50
                    .Direction = ParameterDirection.Output
                End With
                loCmd.Parameters.Add(loPar)
                loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)

                If loCmd.Parameters("@CRET_MSG") Is Nothing Then
                    lcRtn = "UNKNOWN_ERROR"
                Else
                    lcRtn = loCmd.Parameters("@CRET_MSG").Value
                End If

                If Not lcRtn.Equals("OK") Then
                    Throw New Exception(lcRtn)
                End If

            End With

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return lcRtn
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As CSM00700ScriptsDTO, poCRUDMode As eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String

        Try
            loConn = loDb.GetConnection()

            With poNewEntity

                If poCRUDMode = eCRUDMode.EditMode Then
                    lcQuery = "UPDATE CST_DB_CHANGES_SCRIPTS "
                    lcQuery += "SET "
                    lcQuery += "CNOTE = '{5}', "
                    lcQuery += "CUPDATE_BY = '{6}', "
                    lcQuery += "DUPDATE_DATE = GETDATE() "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CDATABASE_ID = '{2}' "
                    lcQuery += "AND CDB_CHANGE_ID = '{3}' "
                    lcQuery += "AND CSCRIPT_ID = '{4}' "
                    lcQuery = String.Format(lcQuery,
                                            .CCOMPANY_ID,
                                            .CAPPS_CODE,
                                            .CDATABASE_ID,
                                            .CDB_CHANGE_ID,
                                            .CSCRIPT_ID,
                                            .CNOTE,
                                            .CUPDATE_BY)
                End If
            End With
            loDb.SqlExecNonQuery(lcQuery, loConn, True)
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Sub R_Deleting(poEntity As CSM00700ScriptsDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcRtn As String

        Try
            loConn = loDb.GetConnection()

            With poEntity

                'validation: check version status
                loCmd = loDb.GetCommand()
                lcQuery = "EXEC RSP_CSM00700_Validation '{0}', '{1}', '{2}', '{3}', '{4}', '2', @CRET_MSG OUTPUT "
                lcQuery = String.Format(lcQuery,
                                        .CCOMPANY_ID,
                                        .CAPPS_CODE,
                                        .CDATABASE_ID,
                                        .CDB_CHANGE_ID,
                                        .CSCRIPT_ID)
                loCmd.CommandText = lcQuery
                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@CRET_MSG"
                    .DbType = DbType.String
                    .Size = 50
                    .Direction = ParameterDirection.Output
                End With
                loCmd.Parameters.Add(loPar)
                loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)

                If loCmd.Parameters("@CRET_MSG") Is Nothing Then
                    lcRtn = "UNKNOWN_ERROR"
                Else
                    lcRtn = loCmd.Parameters("@CRET_MSG").Value
                End If

                If Not lcRtn.Equals("OK") Then
                    Throw New Exception(lcRtn)
                End If

                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "CST_DB_CHANGES_SCRIPTS "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CDATABASE_ID = '{2}' "
                lcQuery += "AND CDB_CHANGE_ID = '{3}' "
                lcQuery += "AND CSCRIPT_ID = '{4}' "
                lcQuery = String.Format(lcQuery,
                                        .CCOMPANY_ID,
                                        .CAPPS_CODE,
                                        .CDATABASE_ID,
                                        .CDB_CHANGE_ID,
                                        .CSCRIPT_ID)
                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As CSM00700ScriptsDTO) As CSM00700ScriptsDTO
        Dim lcQuery As String
        Dim loResult As CSM00700ScriptsDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CST_DB_CHANGES_SCRIPTS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CDATABASE_ID = '{2}' "
                lcQuery += "AND CDB_CHANGE_ID = '{3}' "
                lcQuery += "AND CSCRIPT_ID = '{4}' "
                lcQuery = String.Format(lcQuery,
                                        .CCOMPANY_ID,
                                        .CAPPS_CODE,
                                        .CDATABASE_ID,
                                        .CDB_CHANGE_ID,
                                        .CSCRIPT_ID)
                loResult = loDb.SqlExecObjectQuery(Of CSM00700ScriptsDTO)(lcQuery).FirstOrDefault

            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function ShiftScript(poKey As CSM00700KeyDTO) As String
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcRtn As String = "OK"

        Try

            With poKey

                loCmd = loDb.GetCommand()
                lcQuery = "EXEC RSP_CSM00700_Shift_Script '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', @CRET_MSG OUTPUT "
                lcQuery = String.Format(lcQuery,
                                    .CCOMPANY_ID,
                                    .CAPPS_CODE,
                                    .CDATABASE_ID,
                                    .CDB_CHANGE_ID,
                                    .CSCRIPT_ID,
                                    .CUPDOWN,
                                    .CUSER_ID)
                loCmd.CommandText = lcQuery
                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@CRET_MSG"
                    .DbType = DbType.String
                    .Size = 50
                    .Direction = ParameterDirection.Output
                End With
                loCmd.Parameters.Add(loPar)
                loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)

                If loCmd.Parameters("@CRET_MSG") Is Nothing Then
                    lcRtn = "UNKNOWN_ERROR"
                Else
                    lcRtn = loCmd.Parameters("@CRET_MSG").Value
                End If

                If Not lcRtn.Equals("OK") Then
                    Throw New Exception(lcRtn)
                End If

            End With

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return lcRtn
    End Function

End Class
