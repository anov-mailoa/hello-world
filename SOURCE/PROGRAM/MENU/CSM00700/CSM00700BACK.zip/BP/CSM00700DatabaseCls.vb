﻿Imports System.Data.Common
Imports R_BackEnd
Imports R_Common

Public Class CSM00700DatabaseCls
    Inherits R_BusinessObject(Of CSM00700DatabaseDTO)

    Protected Overrides Sub R_Saving(poNewEntity As CSM00700DatabaseDTO, poCRUDMode As Global.R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loProject As New CSM00700DatabaseDTO
        Dim loKey As New CSM00700KeyDTO

        Try
            loConn = loDb.GetConnection()

            With poNewEntity

                If poCRUDMode = eCRUDMode.EditMode Then


                    lcQuery = "UPDATE CSM_DATABASES "
                    lcQuery += "SET "
                    lcQuery += "CDATABASE_NAME = '{3}', "
                    lcQuery += "CDESCRIPTION = '{4}', "
                    lcQuery += "CUPDATE_BY = '{5}', "
                    lcQuery += "DUPDATE_DATE = GETDATE() "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CDATABASE_ID = '{2}' "
                    lcQuery = String.Format(lcQuery,
                                            .CCOMPANY_ID,
                                            .CAPPS_CODE,
                                            .CDATABASE_ID,
                                            .CDATABASE_NAME,
                                            .CDESCRIPTION,
                                            .CUPDATE_BY)
                End If
            End With
            loDb.SqlExecNonQuery(lcQuery, loConn, True)
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Sub R_Deleting(poEntity As CSM00700DatabaseDTO)
        Throw New NotImplementedException()
    End Sub

    Public Function GetDatabaseList(poKey As CSM00700KeyDTO) As List(Of CSM00700DatabaseGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00700DatabaseGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "SELECT * "
                lcQuery += "FROM CSM_DATABASES (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery = String.Format(lcQuery,
                                        .CCOMPANY_ID,
                                        .CAPPS_CODE)

            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00700DatabaseGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetTableList(poKey As CSM00700KeyDTO) As List(Of CSM00700DbTablesGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00700DbTablesGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "SELECT * "
                lcQuery += "FROM CSM_DB_TABLES (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CDATABASE_ID = '{2}' "
                lcQuery = String.Format(lcQuery,
                                        .CCOMPANY_ID,
                                        .CAPPS_CODE,
                                        .CDATABASE_ID)

            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00700DbTablesGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetColumnList(poKey As CSM00700KeyDTO) As List(Of CSM00700DbColumnsGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00700DbColumnsGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "SELECT "
                lcQuery += "CCOMPANY_ID, CAPPS_CODE, CDATABASE_ID, CTABLE_NAME, CCOLUMN_NAME, "
                lcQuery += "RTRIM(CDATA_TYPE) + "
                lcQuery += "CASE WHEN CDATA_TYPE LIKE '%char' OR CDATA_TYPE LIKE '%binary' THEN '(' + "
                lcQuery += "CASE WHEN NLENGTH >=0 THEN RTRIM(CONVERT(varchar(10), NLENGTH)) "
                lcQuery += "ELSE 'max' END  + ')' "
                lcQuery += "WHEN CDATA_TYPE IN ('decimal','numeric') THEN '(' + RTRIM(CONVERT(varchar(10), NPRECISION)) + "
                lcQuery += "',' + RTRIM(CONVERT(varchar(10), NSCALE)) + ')' "
                lcQuery += "ELSE '' END AS CDATA_TYPE, "
                lcQuery += "CDESCRIPTION, LNULL, CDEFAULT_VALUE, CSTATUS, "
                lcQuery += "CUPDATE_BY, DUPDATE_DATE, CCREATE_BY, DCREATE_DATE "
                lcQuery += "FROM CSM_DB_COLUMNS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CDATABASE_ID = '{2}' "
                lcQuery += "AND CTABLE_NAME = '{3}' "
                lcQuery = String.Format(lcQuery,
                                        .CCOMPANY_ID,
                                        .CAPPS_CODE,
                                        .CDATABASE_ID,
                                        .CTABLE_NAME)

            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00700DbColumnsGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Function R_Display(poEntity As CSM00700DatabaseDTO) As CSM00700DatabaseDTO
        Dim lcQuery As String
        Dim loResult As CSM00700DatabaseDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity
                lcQuery = "SELECT * "
                lcQuery += "FROM CSM_DATABASES (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CDATABASE_ID = '{2}' "
                lcQuery = String.Format(lcQuery,
                                        .CCOMPANY_ID,
                                        .CAPPS_CODE,
                                        .CDATABASE_ID)
                loResult = loDb.SqlExecObjectQuery(Of CSM00700DatabaseDTO)(lcQuery).FirstOrDefault

            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function AddDatabase(poKey As CSM00700DatabaseDTO) As String
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcRtn As String = "OK"

        Try

            loCmd = loDb.GetCommand()
            lcQuery = "EXEC RSP_CSM00700_Add_Empty '{0}', '{1}', '{2}', '{3}', '{4}', 0, '{5}', @CSTATUS OUTPUT, @CMESSAGE OUTPUT "
            With poKey
                lcQuery = String.Format(lcQuery,
                                        .CCOMPANY_ID,
                                        .CAPPS_CODE,
                                        .CDATABASE_ID,
                                        .CDATABASE_NAME,
                                        .CDESCRIPTION,
                                        .CUPDATE_BY)
            End With
            loCmd.CommandText = lcQuery
            loPar = loDb.GetParameter()
            With loPar
                .ParameterName = "@CSTATUS"
                .DbType = DbType.String
                .Size = 50
                .Direction = ParameterDirection.Output
            End With
            loCmd.Parameters.Add(loPar)
            loPar = Nothing
            loPar = loDb.GetParameter()
            With loPar
                .ParameterName = "@CMESSAGE"
                .DbType = DbType.String
                .Size = 50
                .Direction = ParameterDirection.Output
            End With
            loCmd.Parameters.Add(loPar)
            loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)

            If loCmd.Parameters("@CSTATUS") Is Nothing Then
                lcRtn = "UNKNOWN_ERROR"
                Exit Try
            Else
                lcRtn = loCmd.Parameters("@CSTATUS").Value
                If lcRtn = "ERROR" Then
                    loEx.Add(lcRtn, loCmd.Parameters("@CMESSAGE").Value)
                End If
                Exit Try
            End If

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return lcRtn

    End Function

End Class
