﻿Imports System.Data.Common
Imports CSM00700Back
Imports R_BackEnd
Imports R_Common

Public Class CSM00700ChangesCls
    Inherits R_BusinessObject(Of CSM00700ChangesDTO)

    Public Function CreateChanges(poKey As CSM00700ChangesDTO) As String
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcRtn As String = "OK"

        Try

            loCmd = loDb.GetCommand()
            lcQuery = "EXEC RSP_CSM00700_Create_Changes '{0}', '{1}', '{2}', '{3}', @CSTATUS OUTPUT, @CMESSAGE OUTPUT "
            With poKey
                lcQuery = String.Format(lcQuery,
                                        .CCOMPANY_ID,
                                        .CAPPS_CODE,
                                        .CDATABASE_ID,
                                        .CUPDATE_BY)
            End With
            loCmd.CommandText = lcQuery
            loPar = loDb.GetParameter()
            With loPar
                .ParameterName = "@CSTATUS"
                .DbType = DbType.String
                .Size = 50
                .Direction = ParameterDirection.Output
            End With
            loCmd.Parameters.Add(loPar)
            loPar = Nothing
            loPar = loDb.GetParameter()
            With loPar
                .ParameterName = "@CMESSAGE"
                .DbType = DbType.String
                .Size = 50
                .Direction = ParameterDirection.Output
            End With
            loCmd.Parameters.Add(loPar)
            loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)

            If loCmd.Parameters("@CSTATUS") Is Nothing Then
                lcRtn = "UNKNOWN_ERROR"
                Exit Try
            Else
                lcRtn = loCmd.Parameters("@CSTATUS").Value
                If lcRtn = "ERROR" Then
                    loEx.Add(lcRtn, loCmd.Parameters("@CMESSAGE").Value)
                End If
                Exit Try
            End If

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return lcRtn
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As CSM00700ChangesDTO, poCRUDMode As eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String

        Try
            loConn = loDb.GetConnection()

            With poNewEntity

                If poCRUDMode = eCRUDMode.EditMode Then
                    lcQuery = "UPDATE CST_DB_CHANGES "
                    lcQuery += "SET "
                    lcQuery += "CDESCRIPTION = '{4}', "
                    lcQuery += "CUPDATE_BY = '{5}', "
                    lcQuery += "DUPDATE_DATE = GETDATE() "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CDATABASE_ID = '{2}' "
                    lcQuery += "AND CDB_CHANGE_ID = '{3}' "
                    lcQuery = String.Format(lcQuery,
                                            .CCOMPANY_ID,
                                            .CAPPS_CODE,
                                            .CDATABASE_ID,
                                            .CDB_CHANGE_ID,
                                            .CDESCRIPTION,
                                            .CUPDATE_BY)
                End If
            End With
            loDb.SqlExecNonQuery(lcQuery, loConn, True)
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Sub R_Deleting(poEntity As CSM00700ChangesDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcRtn As String

        Try
            loConn = loDb.GetConnection()

            With poEntity

                'validation
                loCmd = loDb.GetCommand()
                lcQuery = "EXEC RSP_CSM00700_Validation '{0}', '{1}', '{2}', '{3}', '', '1', @CRET_MSG OUTPUT "
                lcQuery = String.Format(lcQuery,
                                        .CCOMPANY_ID,
                                        .CAPPS_CODE,
                                        .CDATABASE_ID,
                                        .CDB_CHANGE_ID)
                loCmd.CommandText = lcQuery
                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@CRET_MSG"
                    .DbType = DbType.String
                    .Size = 50
                    .Direction = ParameterDirection.Output
                End With
                loCmd.Parameters.Add(loPar)
                loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)

                If loCmd.Parameters("@CRET_MSG") Is Nothing Then
                    lcRtn = "UNKNOWN_ERROR"
                Else
                    lcRtn = loCmd.Parameters("@CRET_MSG").Value
                End If

                If Not lcRtn.Equals("OK") Then
                    Throw New Exception(lcRtn)
                End If

                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "CST_DB_CHANGES "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CDATABASE_ID = '{2}' "
                lcQuery += "AND CDB_CHANGE_ID = '{3}' "
                lcQuery = String.Format(lcQuery,
                                        .CCOMPANY_ID,
                                        .CAPPS_CODE,
                                        .CDATABASE_ID,
                                        .CDB_CHANGE_ID)
                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As CSM00700ChangesDTO) As CSM00700ChangesDTO
        Dim lcQuery As String
        Dim loResult As CSM00700ChangesDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CST_DB_CHANGES (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CDATABASE_ID = '{2}' "
                lcQuery += "AND CDB_CHANGE_ID = '{3}' "
                lcQuery = String.Format(lcQuery,
                                        .CCOMPANY_ID,
                                        .CAPPS_CODE,
                                        .CDATABASE_ID,
                                        .CDB_CHANGE_ID)
                loResult = loDb.SqlExecObjectQuery(Of CSM00700ChangesDTO)(lcQuery).FirstOrDefault

            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function


End Class
