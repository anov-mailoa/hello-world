﻿Imports R_BackEnd
Imports R_Common
Imports System.Data.Common
Imports System.Transactions
Imports RCustDBFileCommon
Imports System.IO
Imports R_Version
Imports Ionic.Zip

Public Class CSM00700DbChangesCls
    Implements R_IBatchProcess

#Region " VARIABLES "
    Private Shared C_ZipPath As String = "D:\RealCode\Temp\Zips"
    Private Shared C_RootPath As String = "D:\RealCodeRelease"
#End Region


    Public Sub R_BatchProcess(poBatchProcessPar As R_BatchProcessPar) Implements R_IBatchProcess.R_BatchProcess
        Dim loException As New R_Exception()
        Dim loDb As New R_Db()
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcQuery As String
        Dim loObject As List(Of RCustDBFileEntityDTO)

        Try
            loObject = R_Utility.Deserialize(poBatchProcessPar.BigObject)

            ' transaction block
            ' script upload
            Using TransScope As New TransactionScope(TransactionScopeOption.Required)

                ' save file
                For Each loFile As RCustDBFileEntityDTO In loObject

                    loCmd = loDb.GetCommand()
                    With loFile

                        lcQuery = "EXEC RSP_CSM00700_Save_Script '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', @OFILE_DATA "
                        lcQuery = String.Format(lcQuery,
                            .CCOMPANY_ID,
                            .CAPPS_CODE,
                            .CPROJECT_ID, ' CDATABASE_ID
                            .CSESSION_ID, ' CDB_CHANGE_ID
                            .CFILE_NAME,
                            .CNOTE,
                            .CFUNCTION_ID) ' CUSER_ID
                        loCmd.CommandText = lcQuery
                        loPar = loDb.GetParameter()
                        With loPar
                            .ParameterName = "@OFILE_DATA"
                            .DbType = DbType.Binary
                            .Value = IIf(loFile.OFILE_BYTE Is Nothing, DBNull.Value, loFile.OFILE_BYTE)
                        End With
                        loCmd.Parameters.Add(loPar)
                        loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)
                    End With
                Next

                TransScope.Complete()
            End Using

        Catch ex As Exception
            loException.Add(ex)
        End Try

    End Sub

    Public Function GetChangesList(poKey As CSM00700KeyDTO) As List(Of CSM00700ChangesGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00700ChangesGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "SELECT * "
                lcQuery += "FROM CST_DB_CHANGES (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CDATABASE_ID = '{2}' "
                lcQuery = String.Format(lcQuery,
                                        .CCOMPANY_ID,
                                        .CAPPS_CODE,
                                        .CDATABASE_ID)

            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00700ChangesGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetScriptList(poKey As CSM00700KeyDTO) As List(Of CSM00700ScriptsGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00700ScriptsGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "SELECT * "
                lcQuery += "FROM CST_DB_CHANGES_SCRIPTS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CDATABASE_ID = '{2}' "
                lcQuery += "AND CDB_CHANGE_ID = '{3}' "
                lcQuery = String.Format(lcQuery,
                                        .CCOMPANY_ID,
                                        .CAPPS_CODE,
                                        .CDATABASE_ID,
                                        .CDB_CHANGE_ID)

            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00700ScriptsGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function ReleaseCandidate(poKey As CSM00700KeyDTO) As String
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcRtn As String = "OK"

        Try
            DumpFiles(poKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return lcRtn
    End Function

    Public Function DumpFiles(poKey As CSM00700KeyDTO) As String
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim lcRtn As String = "OK"
        Dim loTempByte As List(Of CSM00700RCFilesDTO)
        Dim lcZipFilePath As String
        Dim lcRCFilePath As String
        Dim lcChangesFilePath As String = ""
        Dim lcScriptFilePath As String
        Dim lcVersion As String
        Dim lcRevision As String = "0000"
        Dim lcNextRevision As String = "0000"
        Dim lcMSBuildPath As String = ""
        Dim lcRDeployPath As String = "D:\RealCodeTools"
        Dim lcLogFilePath As String = ""
        Dim lcPackageFilePath As String = ""
        Dim lcComment As String = ""
        Dim loFilenames As New List(Of String)
        Dim loZip As New R_Zip
        Dim lcFileKey As String
        Dim lcPassword As String
        Dim lcPreviousVersion As String = ""
        Dim lcPropertiesFilename As String
        Dim loPropertiesFileWriter As StreamWriter

        Try
            With poKey


                ' Get files
                lcQuery = "EXEC RSP_CSM00700_Get_Scripts '{0}', '{1}', '{2}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID,
                                            .CAPPS_CODE,
                                            .CDATABASE_ID)
                loTempByte = loDb.SqlExecObjectQuery(Of CSM00700RCFilesDTO)(lcQuery)

                ' Save files
                lcRCFilePath = C_RootPath.Trim & "\" & .CCOMPANY_ID.Trim & "\" & .CAPPS_CODE.Trim & "\STD\DB-RC"
                lcPackageFilePath = C_RootPath.Trim & "\" & .CCOMPANY_ID.Trim & "\" & .CAPPS_CODE.Trim & "\STD\Packages"
                Dim loFile As CSM00700RCFilesDTO
                For i = 0 To loTempByte.Count - 1
                    loFile = loTempByte(i)
                    With loFile
                        lcVersion = .CVERSION.Trim
                        lcChangesFilePath = lcRCFilePath.Trim & "\" & .CVERSION.Trim
                        ' iterasi pertama delete dulu
                        If i = 0 Then
                            If Directory.Exists(lcChangesFilePath) Then
                                Directory.Delete(lcChangesFilePath, True)
                            End If
                        End If
                        ' Create changes folder if not exists
                        If Not Directory.Exists(lcChangesFilePath) Then
                            Directory.CreateDirectory(lcChangesFilePath)
                        End If
                        ' save script file
                        lcScriptFilePath = lcChangesFilePath & "\" & .CDB_CHANGE_ID.Trim & "-" & .CSCRIPT_ID.Trim & ".sql"
                        R_Utility.ConvertByteToFile(lcScriptFilePath, .OBINARY_FILE_DATA)
                    End With
                Next

                ' Get previous version number
                lcQuery = "SELECT TOP 1 CVERSION "
                lcQuery += "FROM RVT_APP_VERSION (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION < '{2}' "
                lcQuery += "ORDER BY CVERSION DESC "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID,
                                            .CAPPS_CODE,
                                            lcVersion)
                lcPreviousVersion = loDb.SqlExecObjectQuery(Of String)(lcQuery).FirstOrDefault.Trim
                lcPropertiesFilename = lcRCFilePath.Trim & "\" & lcVersion.Trim & "\Properties.ini"
                loPropertiesFileWriter = My.Computer.FileSystem.OpenTextFileWriter(lcPropertiesFilename, False)
                With loPropertiesFileWriter
                    .WriteLine("PreviousVersion=" & lcPreviousVersion.Trim)
                    .Close()
                End With

                lcZipFilePath = Path.Combine(lcPackageFilePath, .CAPPS_CODE.Trim + "_" + Replace(lcVersion.Trim, ".", "_") + "_D.zip")
                lcComment = .CAPPS_CODE.Trim + " Version " + lcVersion.Trim + " - DB Script"
                lcFileKey = "R3@lt@P@$$w0rd"
                lcPassword = R_Utility.EncryptPbkdf2(.CAPPS_CODE.Trim + lcVersion.Trim, lcFileKey)

                'loZip.R_SignToolPath = ConfigurationManager.AppSettings.GetValues("SignToolPath")(0)
                loZip.ZipWithPassword(lcChangesFilePath, lcZipFilePath, lcPassword, lcComment)

            End With

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return lcRtn
    End Function

End Class
