﻿Imports System.Data.Common
Imports R_BackEnd
Imports R_Common

Public Class CSM00700DbProgramsCls
    Inherits R_BusinessObject(Of CSM00700DbProgramsDTO)

    Public Function GetDbProgramsList(poKey As CSM00700KeyDTO) As List(Of CSM00700DbProgramsGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00700DbProgramsGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CSM_DB_PROGRAMS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CDATABASE_ID = '{2}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CDATABASE_ID)
            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00700DbProgramsGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetDbProgramSourceList(poKey As CSM00700KeyDTO) As List(Of CSM00700DbProgramSourcesGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00700DbProgramSourcesGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "SELECT CSOURCE_ID, CDESCRIPTION "
                lcQuery += "FROM CSM_SOURCES (NOLOCK) " '
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                lcQuery += "AND CSOURCE_GROUP_ID = '{4}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CSOURCE_GROUP_ID)
            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00700DbProgramSourcesGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetSourceGroupList(poKey As CSM00700KeyDTO) As List(Of CSM00700SourceGroupListDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00700SourceGroupListDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "SELECT CATTRIBUTE_GROUP, CATTRIBUTE_ID, CSOURCE_GROUP_ID, CDESCRIPTION "
                lcQuery += "FROM CSM_SOURCE_GROUPS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID)
            End With

            loResult = loDb.SqlExecObjectQuery(Of CSM00700SourceGroupListDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult

    End Function

    Protected Overrides Sub R_Saving(poNewEntity As CSM00700DbProgramsDTO, poCRUDMode As eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As CSM00700DbProgramsDTO

        Try
            loConn = loDb.GetConnection()

            With poNewEntity
                If poCRUDMode = eCRUDMode.AddMode Then

                    ' check duplicate entry
                    lcQuery = "SELECT * "
                    lcQuery += "FROM "
                    lcQuery += "CSM_DB_PROGRAMS (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CDATABASE_ID = '{2}' "
                    lcQuery += "AND CATTRIBUTE_GROUP = '{3}' "
                    lcQuery += "AND CATTRIBUTE_ID = '{4}' "
                    lcQuery += "AND CSOURCE_GROUP_ID = '{5}' "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CDATABASE_ID, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CSOURCE_GROUP_ID)

                    loResult = loDb.SqlExecObjectQuery(Of CSM00700DbProgramsDTO)(lcQuery, loConn, False).FirstOrDefault
                    If loResult IsNot Nothing Then
                        Throw New Exception("Duplicate row.")
                    End If

                    .CUPDATE_BY = .CUPDATE_BY
                    .CCREATE_BY = .CUPDATE_BY
                    .DUPDATE_DATE = Now
                    .DCREATE_DATE = Now

                    lcQuery = "INSERT INTO CSM_DB_PROGRAMS ("
                    lcQuery += "CCOMPANY_ID, "
                    lcQuery += "CAPPS_CODE, "
                    lcQuery += "CDATABASE_ID, "
                    lcQuery += "CATTRIBUTE_GROUP, "
                    lcQuery += "CATTRIBUTE_ID, "
                    lcQuery += "CSOURCE_GROUP_ID, "
                    lcQuery += "CUPDATE_BY, "
                    lcQuery += "DUPDATE_DATE, "
                    lcQuery += "CCREATE_BY, "
                    lcQuery += "DCREATE_DATE) "
                    lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', GETDATE(), '{7}', GETDATE()) "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CDATABASE_ID,
                    .CATTRIBUTE_GROUP,
                    .CATTRIBUTE_ID,
                    .CSOURCE_GROUP_ID,
                    .CUPDATE_BY,
                    .CCREATE_BY)
                End If
            End With
            loDb.SqlExecNonQuery(lcQuery, loConn, True)
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Sub R_Deleting(poEntity As CSM00700DbProgramsDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection

        Try
            loConn = loDb.GetConnection()

            With poEntity

                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "CSM_DB_PROGRAMS "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CDATABASE_ID = '{2}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{3}' "
                lcQuery += "AND CATTRIBUTE_ID = '{4}' "
                lcQuery += "AND CSOURCE_GROUP_ID = '{5}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CDATABASE_ID, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CSOURCE_GROUP_ID)

                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As CSM00700DbProgramsDTO) As CSM00700DbProgramsDTO
        Dim lcQuery As String
        Dim loResult As CSM00700DbProgramsDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CSM_DB_PROGRAMS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CDATABASE_ID = '{2}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{3}' "
                lcQuery += "AND CATTRIBUTE_ID = '{4}' "
                lcQuery += "AND CSOURCE_GROUP_ID = '{5}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CDATABASE_ID, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CSOURCE_GROUP_ID)

                loResult = loDb.SqlExecObjectQuery(Of CSM00700DbProgramsDTO)(lcQuery).FirstOrDefault

            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function
End Class
