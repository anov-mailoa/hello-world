﻿<Serializable()>
Public Class CSM00700ScriptFileDTO
    ' Main key
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CDATABASE_ID As String
    Public Property CVERSION As String
    Public Property CDB_CHANGE_ID As String
    Public Property CSCRIPT_ID As String
    Public Property CFILE_NAME As String
    Public Property CNOTE As String
    Public Property OFILE_BYTE As Byte()

    Public Property CUSER_ID As String

End Class
