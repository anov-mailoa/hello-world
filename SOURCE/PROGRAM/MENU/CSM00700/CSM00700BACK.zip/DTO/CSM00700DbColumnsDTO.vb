﻿Imports R_BackEnd

Public Class CSM00700DbColumnsDTO
    Inherits R_DTOBase

    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CDATABASE_ID As String
    Public Property CTABLE_NAME As String
    Public Property CCOLUMN_NAME As String
    Public Property CDATA_TYPE As String
    Public Property LNULL As Boolean
    Public Property CDEFAULT_VALUE As String
    Public Property CDESCRIPTION As String
    Public Property CSTATUS As String
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)
    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)

End Class
