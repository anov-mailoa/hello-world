﻿Public Class CSM00700RCFilesDTO
    Public Property CVERSION As String
    Public Property CDB_CHANGE_ID As String
    Public Property CSCRIPT_ID As String
    Public Property CFILE_NAME As String
    Public Property OBINARY_FILE_DATA As Byte()
End Class
