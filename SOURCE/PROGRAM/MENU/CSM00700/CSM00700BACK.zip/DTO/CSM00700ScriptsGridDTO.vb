﻿Public Class CSM00700ScriptsGridDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CDATABASE_ID As String
    Public Property CDB_CHANGE_ID As String
    Public Property CSCRIPT_ID As String
    Public Property CFILE_NAME As String
    Public Property CNOTE As String
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)
    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)
End Class
