﻿Public Class CSM00700DbProgramSourcesGridDTO
    Public Property CSOURCE_ID As String
    Public Property CDESCRIPTION As String
End Class
