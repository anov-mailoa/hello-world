﻿Imports CSM00700Front.CSM00700ServiceRef
Imports R_FrontEnd
Imports ClientHelper
Imports R_Common
Imports CSM00700Front.CSM00700StreamingServiceRef

Public Class CSM00700AddEmpty

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSM00700Service/CSM00700Service.svc"
    Dim C_ServiceNameStream As String = "CSM00700Service/CSM00700StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim loScriptUploadParam As New CSM00700AddEmptyParamDTO
    Dim llRefreshCombo As Boolean
#End Region

#Region " SUBs and FUNCTIONs "



#End Region

#Region " FORM Methods "

    Private Sub R_ReturnPopUp1_R_SetPopUpResult(ByRef poEntityResult As Object) Handles R_ReturnPopUp1.R_SetPopUpResult
        With loScriptUploadParam
            .OFILTER_KEY.CDATABASE_ID = txtDatabaseID.Text
            .CDATABASE_NAME = txtDatabaseName.Text
            .CDESCRIPTION = txtDescription.Text
        End With
        poEntityResult = loScriptUploadParam
    End Sub

    Private Sub CSM00510Filter_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim loEx As New R_Exception

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            loScriptUploadParam = poParameter
            txtApplication.Text = loScriptUploadParam.CAPPS_NAME
            txtDatabaseID.Text = ""
            txtDatabaseName.Text = ""
            txtDescription.Text = ""
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

End Class
