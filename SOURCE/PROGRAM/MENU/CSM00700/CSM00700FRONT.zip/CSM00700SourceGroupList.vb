﻿Imports CSM00700FrontResources
Imports R_Common
Imports CSM00700Front.CSM00700ProgramsStreamingServiceRef
Imports R_FrontEnd
Imports System.ServiceModel.Channels
Imports CSM00700Front.CSM00700ProgramsServiceRef

Public Class CSM00700SourceGroupList

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSM00700Service/CSM00700ProgramsService.svc"
    Dim C_ServiceNameStream As String = "CSM00700Service/CSM00700ProgramsStreamingService.svc"
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _INIT As Boolean = False
#End Region

#Region " FORM Events "

    Private Sub CSM00500Manager_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loSvc As CSM00700ProgramsServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700ProgramsService, CSM00700ProgramsServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loAttributeGroupCombo As New List(Of RCustDBAttributeGroupComboDTO)

        Try
            With CType(poParameter, CSM00700KeyDTO)
                _CCOMPID = .CCOMPANY_ID
                _CAPPSCODE = .CAPPS_CODE
                _INIT = True
                ' Combos
                loAttributeGroupCombo = loSvc.GetAttributeGroupCombo(.CCOMPANY_ID, .CAPPS_CODE)
                bsAttributeGroup.DataSource = loAttributeGroupCombo
                loSvc.Close()
                If .CATTRIBUTE_GROUP IsNot Nothing Then
                    cboAttributeGroup.SelectedValue = .CATTRIBUTE_GROUP
                End If
                If .CATTRIBUTE_ID IsNot Nothing Then
                    cboAttribute.SelectedValue = .CATTRIBUTE_ID
                End If
            End With

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub
#End Region

#Region " GRIDVIEW Events "

    Private Sub gvManager_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvManager.R_ServiceGetListRecord
        Dim loServiceStream As CSM00700ProgramsStreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700ProgramsStreamingService, CSM00700ProgramsStreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00700SourceGroupListDTO)
        Dim loListEntity As New List(Of CSM00700SourceGroupListDTO)

        Try
            With CType(poEntity, CSM00700KeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cAttributeGroup", .CATTRIBUTE_GROUP)
                R_Utility.R_SetStreamingContext("cAttributeId", .CATTRIBUTE_ID)

                loRtn = loServiceStream.GetSourceGroupList()
                loStreaming = R_StreamUtility(Of CSM00700SourceGroupListDTO).ReadFromMessage(loRtn)

                For Each loDto As CSM00700SourceGroupListDTO In loStreaming
                    If loDto IsNot Nothing Then
                        loDto.CATTRIBUTE_GROUP = cboAttributeGroup.SelectedValue
                        loDto.CATTRIBUTE_ID = cboAttribute.SelectedValue
                        loListEntity.Add(loDto)
                    Else
                        Exit For
                    End If
                Next
                poListEntityResult = loListEntity

            End With
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loServiceStream.Close()
        loException.ThrowExceptionIfErrors()
    End Sub
#End Region

#Region " COMBO Actions "
    Private Sub cboAttributeGroup_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboAttributeGroup.SelectedValueChanged
        Dim loEx As New R_Exception
        Dim loSvc As CSM00700ProgramsServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700ProgramsService, CSM00700ProgramsServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loAttributeCombo As New List(Of RCustDBAttributeComboDTO)

        Try
            If _INIT Then
                loAttributeCombo = loSvc.GetAttributeCombo(_CCOMPID, _CAPPSCODE, CType(sender, R_RadDropDownList).SelectedValue)
                bsAttribute.DataSource = loAttributeCombo
                loSvc.Close()
            End If
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loSvc.Close()
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub cboAttribute_TextChanged(sender As Object, e As System.EventArgs) Handles cboAttribute.SelectedValueChanged
        Dim loKey As New CSM00700KeyDTO

        If _INIT Then
            With loKey
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = _CAPPSCODE
                .CATTRIBUTE_GROUP = cboAttributeGroup.SelectedValue
                .CATTRIBUTE_ID = sender.SelectedValue
            End With
            gvManager.R_RefreshGrid(loKey)
        End If
    End Sub

#End Region

End Class
