﻿Imports R_FrontEnd
Imports CSM00700Front.CSM00700ServiceRef
Imports CSM00700Front.CSM00700StreamingServiceRef
Imports CSM00700Front.CSM00700ProgramsServiceRef
Imports CSM00700Front.CSM00700ProgramsStreamingServiceRef
Imports R_Common
Imports System.ServiceModel.Channels
Imports ClientHelper
Imports CSM00700FrontResources
Imports System.IO
Imports Telerik.WinControls.UI

Public Class CSM00700Detail

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSM00700Service/CSM00700Service.svc"
    Dim C_ServiceNameStream As String = "CSM00700Service/CSM00700StreamingService.svc"
    Dim C_ProgramServiceName As String = "CSM00700Service/CSM00700ProgramsService.svc"
    Dim C_ProgramServiceNameStream As String = "CSM00700Service/CSM00700ProgramsStreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPS_CODE As String
    Dim _CDATABASE_ID As String
    Dim _CATTRIBUTEID As String
    Dim llInitialized As Boolean = False
    Dim _CSERVER_UID As String = ""
    Dim _LACTIVE As Boolean
    Dim _NINTERVAL As Integer = 1
    Dim _NGRACE_DAYS As Integer = 0
    Dim _NWARNING_DAYS As Integer = 0
    Dim _CLAST_EXPIRY_DATE As String
    Dim _CACTIVATION_TYPE As String
    Dim loDetailParam As New CSM00700DetailParamDTO

#End Region

#Region " F O R M "

    Private Sub CSM00700Detail_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loSvc As CSM00700ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700Service, CSM00700ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            ' PageView
            pvpTables.Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "lblTableTitle")
            pvpPrograms.Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "lblProgramTitle")

            With CType(poParameter, CSM00700DetailParamDTO)
                _CAPPS_CODE = .OGRID_KEY.CAPPS_CODE
                _CDATABASE_ID = .OGRID_KEY.CDATABASE_ID
                txtApplication.Text = .CAPPS_NAME
                txtDatabaseName.Text = .CDATABASE_NAME
            End With

            llInitialized = True
            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " TABLE GRIDVIEW Events "

    Private Sub gvTables_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvTables.DataBindingComplete
        gvTables.BestFitColumns()
    End Sub

    Private Sub gvTables_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvTables.R_Display
        Dim loEx As New R_Exception
        Dim loTableKey As New CSM00700Front.CSM00700ServiceRef.CSM00700KeyDTO

        Try
            With CType(poEntity, CSM00700DbTablesGridDTO)
                loTableKey.CCOMPANY_ID = .CCOMPANY_ID
                loTableKey.CAPPS_CODE = .CAPPS_CODE
                loTableKey.CDATABASE_ID = .CDATABASE_ID
                loTableKey.CTABLE_NAME = .CTABLE_NAME
            End With
            gvColumns.R_RefreshGrid(loTableKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvTables_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvTables.R_ServiceGetListRecord
        Dim loServiceStream As CSM00700StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700StreamingService, CSM00700StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00700DbTablesGridDTO)
        Dim loListEntity As New List(Of CSM00700DbTablesGridDTO)

        Try
            With poEntity
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cDatabaseID", .CDATABASE_ID)
            End With

            loRtn = loServiceStream.GetTableList()
            loStreaming = R_StreamUtility(Of CSM00700DbTablesGridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00700DbTablesGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " COLUMN GRIDVIEW Events "
    Private Sub gvColumns_DataBindingComplete(sender As Object, e As GridViewBindingCompleteEventArgs) Handles gvColumns.DataBindingComplete
        gvColumns.BestFitColumns()
    End Sub

    Private Sub gvColumns_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvColumns.R_ServiceGetListRecord
        Dim loServiceStream As CSM00700StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700StreamingService, CSM00700StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00700DbColumnsGridDTO)
        Dim loListEntity As New List(Of CSM00700DbColumnsGridDTO)

        Try
            With poEntity
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cDatabaseID", .CDATABASE_ID)
                R_Utility.R_SetStreamingContext("cTableName", .CTABLE_NAME)
            End With

            loRtn = loServiceStream.GetColumnList()
            loStreaming = R_StreamUtility(Of CSM00700DbColumnsGridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00700DbColumnsGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " SUBs and FUNCTIONs "

    Private Sub RefreshGrids()
        Dim loTableKey As New CSM00700Front.CSM00700ServiceRef.CSM00700KeyDTO
        Dim loSvc As CSM00700ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700Service, CSM00700ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)

        With loTableKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = _CAPPS_CODE
            .CDATABASE_ID = _CDATABASE_ID
        End With

        gvTables.R_RefreshGrid(loTableKey)
        gvPrograms.R_RefreshGrid(loTableKey)
    End Sub

#End Region

#Region " BUTTONs "

    Private Sub btnManageObjects_R_Before_Open_Form(ByRef poTargetForm As R_FormBase, ByRef poParameter As Object) Handles btnChanges.R_Before_Open_Form
        Dim loPICKey As New CSM00700Front.CSM00700ServiceRef.CSM00700KeyDTO

        poTargetForm = New CSM00700Changes

        With loPICKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = _CAPPS_CODE
            .CDATABASE_ID = _CDATABASE_ID
        End With
        With loDetailParam
            .OGRID_KEY = loPICKey
            .CAPPS_NAME = txtApplication.Text
            .CDATABASE_NAME = txtDatabaseName.Text
        End With

        poParameter = loDetailParam
    End Sub

    Private Sub CSM00700Detail_R_LockUnlock(peLockUnlock As R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " PROGRAM GRIDVIEW Events "

    Private Sub gvPrograms_DataBindingComplete(sender As Object, e As GridViewBindingCompleteEventArgs) Handles gvPrograms.DataBindingComplete
        gvPrograms.BestFitColumns()
    End Sub

    Private Sub gvPrograms_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvPrograms.R_ServiceGetListRecord
        Dim loServiceStream As CSM00700ProgramsStreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700ProgramsStreamingService, CSM00700ProgramsStreamingServiceClient)(e_ServiceClientType.StreamingService, C_ProgramServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00700DbProgramsGridDTO)
        Dim loListEntity As New List(Of CSM00700DbProgramsDTO)

        Try
            With poEntity
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cDatabaseId", .CDATABASE_ID)
            End With

            loRtn = loServiceStream.GetDbProgramsList()
            loStreaming = R_StreamUtility(Of CSM00700DbProgramsGridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00700DbProgramsGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New CSM00700DbProgramsDTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                                      ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                                      ._CDATABASE_ID = loDto.CDATABASE_ID,
                                                                      ._CATTRIBUTE_GROUP = loDto.CATTRIBUTE_GROUP,
                                                                      ._CATTRIBUTE_ID = loDto.CATTRIBUTE_ID,
                                                                      ._CSOURCE_GROUP_ID = loDto.CSOURCE_GROUP_ID})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvPrograms_R_Before_Open_LookUpForm(sender As Object, e As EditorRequiredEventArgs, ByRef poTargetForm As R_FormBase, ByRef poParameter As Object) Handles gvPrograms.R_Before_Open_LookUpForm
        poTargetForm = New CSM00700SourceGroupList
        poParameter = New CSM00700Front.CSM00700ProgramsStreamingServiceRef.CSM00700KeyDTO With {.CCOMPANY_ID = _CCOMPID,
                                                        .CAPPS_CODE = _CAPPS_CODE,
                                                        .CATTRIBUTE_GROUP = "PROGRAM",
                                                        .CATTRIBUTE_ID = _CATTRIBUTEID}
    End Sub

    Private Sub gvPrograms_R_Return_LookUp(sender As Object, e As EditorRequiredEventArgs, poReturnObject As Object) Handles gvPrograms.R_Return_LookUp
        gvPrograms.CurrentRow.Cells("_CSOURCE_GROUP_ID").Value = poReturnObject.CSOURCE_GROUP_ID
        gvPrograms.CurrentRow.Cells("_CATTRIBUTE_ID").Value = poReturnObject.CATTRIBUTE_ID
        _CATTRIBUTEID = poReturnObject.CATTRIBUTE_ID
    End Sub

    Private Sub gvPrograms_R_Saving(ByRef poEntity As Object, poGridCellCollection As GridViewCellInfoCollection, peGridMode As R_eGridMode) Handles gvPrograms.R_Saving
        With CType(poEntity, CSM00700DbProgramsDTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = _CAPPS_CODE
            ._CDATABASE_ID = _CDATABASE_ID
            ._CATTRIBUTE_GROUP = "PROGRAM"
            ._CCREATE_BY = _CUSERID
            ._CUPDATE_BY = _CUSERID
        End With
    End Sub

    Private Sub gvPrograms_R_Display(poEntity As Object, poGridCellCollection As GridViewCellInfoCollection, peGridMode As R_eGridMode) Handles gvPrograms.R_Display
        Dim loEx As New R_Exception
        Dim loTableKey As New CSM00700Front.CSM00700ProgramsStreamingServiceRef.CSM00700KeyDTO

        Try
            With CType(poEntity, CSM00700DbProgramsDTO)
                loTableKey.CCOMPANY_ID = ._CCOMPANY_ID
                loTableKey.CAPPS_CODE = ._CAPPS_CODE
                loTableKey.CATTRIBUTE_GROUP = ._CATTRIBUTE_GROUP
                loTableKey.CATTRIBUTE_ID = ._CATTRIBUTE_ID
                loTableKey.CSOURCE_GROUP_ID = ._CSOURCE_GROUP_ID
            End With
            gvSources.R_RefreshGrid(loTableKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvPrograms_R_ServiceDelete(poEntity As Object) Handles gvPrograms.R_ServiceDelete
        Dim loService As CSM00700ProgramsServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700ProgramsService, CSM00700ProgramsServiceClient)(e_ServiceClientType.RegularService, C_ProgramServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String

        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvPrograms_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvPrograms.R_ServiceGetRecord
        Dim loService As CSM00700ProgramsServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700ProgramsService, CSM00700ProgramsServiceClient)(e_ServiceClientType.RegularService, C_ProgramServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New CSM00700DbProgramsDTO With {._CCOMPANY_ID = _CCOMPID,
                                                                                        ._CAPPS_CODE = _CAPPS_CODE,
                                                                                        ._CDATABASE_ID = _CDATABASE_ID,
                                                                      ._CATTRIBUTE_GROUP = "PROGRAM",
                                                                      ._CATTRIBUTE_ID = _CATTRIBUTEID,
                                                                      ._CSOURCE_GROUP_ID = CType(bsGvPrograms.Current, CSM00700DbProgramsDTO)._CSOURCE_GROUP_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvPrograms_R_ServiceSave(poEntity As Object, peGridMode As R_eGridMode, ByRef poEntityResult As Object) Handles gvPrograms.R_ServiceSave
        Dim loService As CSM00700ProgramsServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700ProgramsService, CSM00700ProgramsServiceClient)(e_ServiceClientType.RegularService, C_ProgramServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " PROGRAM SOURCE GRIDVIEW Events "

    Private Sub gvSources_DataBindingComplete(sender As Object, e As GridViewBindingCompleteEventArgs) Handles gvSources.DataBindingComplete
        gvSources.BestFitColumns()
    End Sub

    Private Sub gvSources_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvSources.R_ServiceGetListRecord
        Dim loServiceStream As CSM00700ProgramsStreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700ProgramsStreamingService, CSM00700ProgramsStreamingServiceClient)(e_ServiceClientType.StreamingService, C_ProgramServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00700DbProgramSourcesGridDTO)
        Dim loListEntity As New List(Of CSM00700DbProgramSourcesGridDTO)

        Try
            With poEntity
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cAttributeGroup", .CATTRIBUTE_GROUP)
                R_Utility.R_SetStreamingContext("cAttributeId", .CATTRIBUTE_ID)
                R_Utility.R_SetStreamingContext("cSourceGroupId", .CSOURCE_GROUP_ID)
            End With

            loRtn = loServiceStream.GetDbProgramSourceList()
            loStreaming = R_StreamUtility(Of CSM00700DbProgramSourcesGridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00700DbProgramSourcesGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

#End Region
End Class
