﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class CSM00700Changes
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn1 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewTextBoxColumn6 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn7 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn8 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn9 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn10 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn11 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn12 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn13 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.btnManageObjects = New R_FrontEnd.R_Detail(Me.components)
        Me.gvTables = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvTables = New System.Windows.Forms.BindingSource(Me.components)
        Me.gvColumns = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvColumns = New System.Windows.Forms.BindingSource(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtDatabaseName = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtApplication = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblDatabaseName = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnRelease = New R_FrontEnd.R_RadButton(Me.components)
        Me.btnCreateChanges = New R_FrontEnd.R_RadButton(Me.components)
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.gvScripts = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvScripts = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridScripts = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.conGridChanges = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.gvChanges = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvChanges = New System.Windows.Forms.BindingSource(Me.components)
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btnUpload = New R_FrontEnd.R_PopUp(Me.components)
        Me.txtDescription = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblNote = New R_FrontEnd.R_RadLabel(Me.components)
        Me.btnBrowse = New R_FrontEnd.R_RadButton(Me.components)
        Me.txtFilename = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblFile = New R_FrontEnd.R_RadLabel(Me.components)
        Me.fbdSaveToFile = New System.Windows.Forms.FolderBrowserDialog()
        Me.conGridTables = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.conGridColumns = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.ofdUpload = New System.Windows.Forms.OpenFileDialog()
        Me.btnShiftUp = New R_FrontEnd.R_RadButton(Me.components)
        Me.btnShiftDown = New R_FrontEnd.R_RadButton(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.btnManageObjects, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvTables, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvTables.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvTables, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvColumns, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvColumns.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvColumns, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.txtDatabaseName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblDatabaseName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.btnRelease, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnCreateChanges, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel2.SuspendLayout()
        CType(Me.gvScripts, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvScripts.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvScripts, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridScripts, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridChanges, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvChanges, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvChanges.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvChanges, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.btnUpload, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDescription, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblNote, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnBrowse, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtFilename, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblFile, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridTables, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridColumns, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnShiftUp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnShiftDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 1277.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.SplitContainer1, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TableLayoutPanel2, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 4
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 72.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(3, 344)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnManageObjects)
        Me.SplitContainer1.Panel1.Controls.Add(Me.gvTables)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.gvColumns)
        Me.SplitContainer1.Size = New System.Drawing.Size(1271, 228)
        Me.SplitContainer1.SplitterDistance = 435
        Me.SplitContainer1.TabIndex = 2
        '
        'btnManageObjects
        '
        Me.btnManageObjects.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnManageObjects.Location = New System.Drawing.Point(3, 414)
        Me.btnManageObjects.Name = "btnManageObjects"
        Me.btnManageObjects.R_ConductorGridSource = Nothing
        Me.btnManageObjects.R_ConductorSource = Nothing
        Me.btnManageObjects.R_DescriptionId = Nothing
        Me.btnManageObjects.R_ResourceId = "btnManageObjects"
        Me.btnManageObjects.R_Title = Nothing
        Me.btnManageObjects.Size = New System.Drawing.Size(110, 24)
        Me.btnManageObjects.TabIndex = 55
        Me.btnManageObjects.Text = "R_Detail1"
        '
        'gvTables
        '
        Me.gvTables.Dock = System.Windows.Forms.DockStyle.Top
        Me.gvTables.EnableFastScrolling = True
        Me.gvTables.Location = New System.Drawing.Point(0, 0)
        '
        '
        '
        Me.gvTables.MasterTemplate.AllowAddNewRow = False
        Me.gvTables.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn1.FieldName = "CTABLE_NAME"
        R_GridViewTextBoxColumn1.HeaderText = "_CTABLE_NAME"
        R_GridViewTextBoxColumn1.Name = "_CTABLE_NAME"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CTABLE_NAME"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 101
        R_GridViewTextBoxColumn2.FieldName = "CDESCRIPTION"
        R_GridViewTextBoxColumn2.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxColumn2.Name = "_CDESCRIPTION"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 103
        Me.gvTables.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2})
        Me.gvTables.MasterTemplate.DataSource = Me.bsGvTables
        Me.gvTables.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvTables.MasterTemplate.EnableFiltering = True
        Me.gvTables.MasterTemplate.EnableGrouping = False
        Me.gvTables.MasterTemplate.ShowFilteringRow = False
        Me.gvTables.MasterTemplate.ShowGroupedColumns = True
        Me.gvTables.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvTables.Name = "gvTables"
        Me.gvTables.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvTables.R_ConductorGridSource = Nothing
        Me.gvTables.R_ConductorSource = Nothing
        Me.gvTables.R_DataAdded = False
        Me.gvTables.R_NewRowText = Nothing
        Me.gvTables.ShowHeaderCellButtons = True
        Me.gvTables.Size = New System.Drawing.Size(435, 344)
        Me.gvTables.TabIndex = 2
        Me.gvTables.Text = "R_RadGridView1"
        '
        'bsGvTables
        '
        Me.bsGvTables.DataSource = GetType(CSM00700Front.CSM00700StreamingServiceRef.CSM00700DbTablesGridDTO)
        '
        'gvColumns
        '
        Me.gvColumns.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvColumns.EnableFastScrolling = True
        Me.gvColumns.Location = New System.Drawing.Point(0, 0)
        '
        '
        '
        Me.gvColumns.MasterTemplate.AllowAddNewRow = False
        Me.gvColumns.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn3.FieldName = "CCOLUMN_NAME"
        R_GridViewTextBoxColumn3.HeaderText = "_CCOLUMN_NAME"
        R_GridViewTextBoxColumn3.Name = "_CCOLUMN_NAME"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CCOLUMN_NAME"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 118
        R_GridViewTextBoxColumn4.FieldName = "CDATA_TYPE"
        R_GridViewTextBoxColumn4.HeaderText = "_CDATA_TYPE"
        R_GridViewTextBoxColumn4.Name = "_CDATA_TYPE"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CDATA_TYPE"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 91
        R_GridViewTextBoxColumn5.FieldName = "CDESCRIPTION"
        R_GridViewTextBoxColumn5.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxColumn5.Name = "_CDESCRIPTION"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 103
        R_GridViewCheckBoxColumn1.FieldName = "LNULL"
        R_GridViewCheckBoxColumn1.HeaderText = "_LNULL"
        R_GridViewCheckBoxColumn1.Name = "_LNULL"
        R_GridViewCheckBoxColumn1.R_ResourceId = "_LNULL"
        R_GridViewCheckBoxColumn1.Width = 59
        R_GridViewTextBoxColumn6.FieldName = "CDEFAULT_VALUE"
        R_GridViewTextBoxColumn6.HeaderText = "_CDEFAULT_VALUE"
        R_GridViewTextBoxColumn6.Name = "_CDEFAULT_VALUE"
        R_GridViewTextBoxColumn6.R_ResourceId = "_CDEFAULT_VALUE"
        R_GridViewTextBoxColumn6.R_UDT = Nothing
        R_GridViewTextBoxColumn6.Width = 117
        Me.gvColumns.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn3, R_GridViewTextBoxColumn4, R_GridViewTextBoxColumn5, R_GridViewCheckBoxColumn1, R_GridViewTextBoxColumn6})
        Me.gvColumns.MasterTemplate.DataSource = Me.bsGvColumns
        Me.gvColumns.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvColumns.MasterTemplate.EnableFiltering = True
        Me.gvColumns.MasterTemplate.ShowFilteringRow = False
        Me.gvColumns.MasterTemplate.ShowGroupedColumns = True
        Me.gvColumns.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvColumns.Name = "gvColumns"
        Me.gvColumns.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvColumns.R_ConductorGridSource = Nothing
        Me.gvColumns.R_ConductorSource = Nothing
        Me.gvColumns.R_DataAdded = False
        Me.gvColumns.R_EnableGrouping = True
        Me.gvColumns.R_NewRowText = Nothing
        Me.gvColumns.ShowGroupPanel = False
        Me.gvColumns.ShowHeaderCellButtons = True
        Me.gvColumns.Size = New System.Drawing.Size(832, 228)
        Me.gvColumns.TabIndex = 3
        Me.gvColumns.Text = "R_RadGridView1"
        '
        'bsGvColumns
        '
        Me.bsGvColumns.DataSource = GetType(CSM00700Front.CSM00700StreamingServiceRef.CSM00700DbColumnsGridDTO)
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.txtDatabaseName)
        Me.Panel1.Controls.Add(Me.txtApplication)
        Me.Panel1.Controls.Add(Me.lblDatabaseName)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 66)
        Me.Panel1.TabIndex = 1
        '
        'txtDatabaseName
        '
        Me.txtDatabaseName.Location = New System.Drawing.Point(115, 34)
        Me.txtDatabaseName.Name = "txtDatabaseName"
        Me.txtDatabaseName.R_ConductorGridSource = Nothing
        Me.txtDatabaseName.R_ConductorSource = Nothing
        Me.txtDatabaseName.R_UDT = Nothing
        Me.txtDatabaseName.ReadOnly = True
        Me.txtDatabaseName.Size = New System.Drawing.Size(206, 20)
        Me.txtDatabaseName.TabIndex = 52
        Me.txtDatabaseName.TabStop = False
        '
        'txtApplication
        '
        Me.txtApplication.Location = New System.Drawing.Point(115, 8)
        Me.txtApplication.Name = "txtApplication"
        Me.txtApplication.R_ConductorGridSource = Nothing
        Me.txtApplication.R_ConductorSource = Nothing
        Me.txtApplication.R_UDT = Nothing
        Me.txtApplication.ReadOnly = True
        Me.txtApplication.Size = New System.Drawing.Size(206, 20)
        Me.txtApplication.TabIndex = 51
        Me.txtApplication.TabStop = False
        '
        'lblDatabaseName
        '
        Me.lblDatabaseName.AutoSize = False
        Me.lblDatabaseName.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblDatabaseName.Location = New System.Drawing.Point(9, 35)
        Me.lblDatabaseName.Name = "lblDatabaseName"
        Me.lblDatabaseName.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblDatabaseName.R_ResourceId = "lblDatabaseName"
        Me.lblDatabaseName.Size = New System.Drawing.Size(100, 18)
        Me.lblDatabaseName.TabIndex = 54
        Me.lblDatabaseName.Text = "Application..."
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 53
        Me.lblApplication.Text = "Application..."
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.btnShiftDown)
        Me.Panel2.Controls.Add(Me.btnShiftUp)
        Me.Panel2.Controls.Add(Me.btnRelease)
        Me.Panel2.Controls.Add(Me.btnCreateChanges)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 308)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1271, 30)
        Me.Panel2.TabIndex = 4
        '
        'btnRelease
        '
        Me.btnRelease.Location = New System.Drawing.Point(119, 3)
        Me.btnRelease.Name = "btnRelease"
        Me.btnRelease.R_ConductorGridSource = Nothing
        Me.btnRelease.R_ConductorSource = Nothing
        Me.btnRelease.R_DescriptionId = Nothing
        Me.btnRelease.R_ResourceId = "btnRelease"
        Me.btnRelease.Size = New System.Drawing.Size(110, 24)
        Me.btnRelease.TabIndex = 1
        Me.btnRelease.Text = "R_RadButton2"
        '
        'btnCreateChanges
        '
        Me.btnCreateChanges.Location = New System.Drawing.Point(3, 3)
        Me.btnCreateChanges.Name = "btnCreateChanges"
        Me.btnCreateChanges.R_ConductorGridSource = Nothing
        Me.btnCreateChanges.R_ConductorSource = Nothing
        Me.btnCreateChanges.R_DescriptionId = Nothing
        Me.btnCreateChanges.R_ResourceId = "btnCreateChanges"
        Me.btnCreateChanges.Size = New System.Drawing.Size(110, 24)
        Me.btnCreateChanges.TabIndex = 56
        Me.btnCreateChanges.Text = "R_RadButton1"
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 3
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 601.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.gvScripts, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.gvChanges, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Panel3, 2, 0)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(3, 75)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(1271, 227)
        Me.TableLayoutPanel2.TabIndex = 5
        '
        'gvScripts
        '
        Me.gvScripts.EnableFastScrolling = True
        Me.gvScripts.Location = New System.Drawing.Point(405, 3)
        '
        '
        '
        Me.gvScripts.MasterTemplate.AllowAddNewRow = False
        Me.gvScripts.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn7.FieldName = "_CSCRIPT_ID"
        R_GridViewTextBoxColumn7.HeaderText = "_CSCRIPT_ID"
        R_GridViewTextBoxColumn7.Name = "_CSCRIPT_ID"
        R_GridViewTextBoxColumn7.R_ResourceId = "_CSCRIPT_ID"
        R_GridViewTextBoxColumn7.R_UDT = Nothing
        R_GridViewTextBoxColumn7.Width = 85
        R_GridViewTextBoxColumn8.FieldName = "_CFILE_NAME"
        R_GridViewTextBoxColumn8.HeaderText = "_CFILE_NAME"
        R_GridViewTextBoxColumn8.Name = "_CFILE_NAME"
        R_GridViewTextBoxColumn8.R_ResourceId = "_CFILE_NAME"
        R_GridViewTextBoxColumn8.R_UDT = Nothing
        R_GridViewTextBoxColumn9.FieldName = "_CNOTE"
        R_GridViewTextBoxColumn9.HeaderText = "_CNOTE"
        R_GridViewTextBoxColumn9.Name = "_CNOTE"
        R_GridViewTextBoxColumn9.R_EnableEDIT = True
        R_GridViewTextBoxColumn9.R_ResourceId = "_CNOTE"
        R_GridViewTextBoxColumn9.R_UDT = Nothing
        R_GridViewTextBoxColumn9.Width = 63
        Me.gvScripts.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn7, R_GridViewTextBoxColumn8, R_GridViewTextBoxColumn9})
        Me.gvScripts.MasterTemplate.DataSource = Me.bsGvScripts
        Me.gvScripts.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvScripts.MasterTemplate.EnableFiltering = True
        Me.gvScripts.MasterTemplate.ShowFilteringRow = False
        Me.gvScripts.MasterTemplate.ShowGroupedColumns = True
        Me.gvScripts.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvScripts.Name = "gvScripts"
        Me.gvScripts.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvScripts.R_ConductorGridSource = Me.conGridScripts
        Me.gvScripts.R_ConductorSource = Nothing
        Me.gvScripts.R_DataAdded = False
        Me.gvScripts.R_EnableGrouping = True
        Me.gvScripts.R_NewRowText = Nothing
        Me.gvScripts.ShowGroupPanel = False
        Me.gvScripts.ShowHeaderCellButtons = True
        Me.gvScripts.Size = New System.Drawing.Size(262, 221)
        Me.gvScripts.TabIndex = 4
        Me.gvScripts.Text = "R_RadGridView1"
        '
        'bsGvScripts
        '
        Me.bsGvScripts.DataSource = GetType(CSM00700Front.CSM00700ScriptsServiceRef.CSM00700ScriptsDTO)
        '
        'conGridScripts
        '
        Me.conGridScripts.R_ConductorParent = Me.conGridChanges
        Me.conGridScripts.R_RadGroupBox = Nothing
        '
        'conGridChanges
        '
        Me.conGridChanges.R_ConductorParent = Nothing
        Me.conGridChanges.R_IsHeader = True
        Me.conGridChanges.R_RadGroupBox = Nothing
        '
        'gvChanges
        '
        Me.gvChanges.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvChanges.EnableFastScrolling = True
        Me.gvChanges.Location = New System.Drawing.Point(3, 3)
        '
        '
        '
        Me.gvChanges.MasterTemplate.AllowAddNewRow = False
        Me.gvChanges.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn10.FieldName = "_CDB_CHANGE_ID"
        R_GridViewTextBoxColumn10.HeaderText = "_CDB_CHANGE_ID"
        R_GridViewTextBoxColumn10.Name = "_CDB_CHANGE_ID"
        R_GridViewTextBoxColumn10.R_ResourceId = "_CDB_CHANGE_ID"
        R_GridViewTextBoxColumn10.R_UDT = Nothing
        R_GridViewTextBoxColumn10.Width = 113
        R_GridViewTextBoxColumn11.FieldName = "_CVERSION"
        R_GridViewTextBoxColumn11.HeaderText = "_CVERSION"
        R_GridViewTextBoxColumn11.Name = "_CVERSION"
        R_GridViewTextBoxColumn11.R_ResourceId = "_CVERSION"
        R_GridViewTextBoxColumn11.R_UDT = Nothing
        R_GridViewTextBoxColumn11.Width = 79
        R_GridViewDateTimeColumn1.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn1.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn1.FieldName = "_DCHANGE_DATE"
        R_GridViewDateTimeColumn1.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn1.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn1.HeaderText = "_DCHANGE_DATE"
        R_GridViewDateTimeColumn1.Name = "_DCHANGE_DATE"
        R_GridViewDateTimeColumn1.R_ResourceId = "_DCHANGE_DATE"
        R_GridViewDateTimeColumn1.Width = 111
        R_GridViewTextBoxColumn12.FieldName = "_CSTATUS"
        R_GridViewTextBoxColumn12.HeaderText = "_CSTATUS"
        R_GridViewTextBoxColumn12.Name = "_CSTATUS"
        R_GridViewTextBoxColumn12.R_ResourceId = "_CSTATUS"
        R_GridViewTextBoxColumn12.R_UDT = Nothing
        R_GridViewTextBoxColumn12.Width = 73
        R_GridViewTextBoxColumn13.FieldName = "_CDESCRIPTION"
        R_GridViewTextBoxColumn13.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxColumn13.Name = "_CDESCRIPTION"
        R_GridViewTextBoxColumn13.R_EnableEDIT = True
        R_GridViewTextBoxColumn13.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxColumn13.R_UDT = Nothing
        R_GridViewTextBoxColumn13.Width = 103
        Me.gvChanges.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn10, R_GridViewTextBoxColumn11, R_GridViewDateTimeColumn1, R_GridViewTextBoxColumn12, R_GridViewTextBoxColumn13})
        Me.gvChanges.MasterTemplate.DataSource = Me.bsGvChanges
        Me.gvChanges.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvChanges.MasterTemplate.EnableFiltering = True
        Me.gvChanges.MasterTemplate.EnableGrouping = False
        Me.gvChanges.MasterTemplate.ShowFilteringRow = False
        Me.gvChanges.MasterTemplate.ShowGroupedColumns = True
        Me.gvChanges.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvChanges.Name = "gvChanges"
        Me.gvChanges.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvChanges.R_ConductorGridSource = Me.conGridChanges
        Me.gvChanges.R_ConductorSource = Nothing
        Me.gvChanges.R_DataAdded = False
        Me.gvChanges.R_NewRowText = Nothing
        Me.gvChanges.ShowHeaderCellButtons = True
        Me.gvChanges.Size = New System.Drawing.Size(396, 221)
        Me.gvChanges.TabIndex = 3
        Me.gvChanges.Text = "R_RadGridView1"
        '
        'bsGvChanges
        '
        Me.bsGvChanges.DataSource = GetType(CSM00700Front.CSM00700ChangesServiceRef.CSM00700ChangesDTO)
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.btnUpload)
        Me.Panel3.Controls.Add(Me.txtDescription)
        Me.Panel3.Controls.Add(Me.lblNote)
        Me.Panel3.Controls.Add(Me.btnBrowse)
        Me.Panel3.Controls.Add(Me.txtFilename)
        Me.Panel3.Controls.Add(Me.lblFile)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(673, 3)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(595, 221)
        Me.Panel3.TabIndex = 5
        '
        'btnUpload
        '
        Me.btnUpload.Location = New System.Drawing.Point(462, 26)
        Me.btnUpload.Name = "btnUpload"
        Me.btnUpload.R_ConductorGridSource = Nothing
        Me.btnUpload.R_ConductorSource = Nothing
        Me.btnUpload.R_DescriptionId = Nothing
        Me.btnUpload.R_ResourceId = "btnUpload"
        Me.btnUpload.R_Title = "Upload Script"
        Me.btnUpload.Size = New System.Drawing.Size(110, 24)
        Me.btnUpload.TabIndex = 53
        Me.btnUpload.Text = "R_PopUp1"
        '
        'txtDescription
        '
        Me.txtDescription.AcceptsReturn = True
        Me.txtDescription.AutoSize = False
        Me.txtDescription.Location = New System.Drawing.Point(109, 28)
        Me.txtDescription.Multiline = True
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.R_ConductorGridSource = Nothing
        Me.txtDescription.R_ConductorSource = Nothing
        Me.txtDescription.R_UDT = Nothing
        Me.txtDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtDescription.Size = New System.Drawing.Size(347, 91)
        Me.txtDescription.TabIndex = 12
        '
        'lblNote
        '
        Me.lblNote.AutoSize = False
        Me.lblNote.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblNote.Location = New System.Drawing.Point(3, 29)
        Me.lblNote.Name = "lblNote"
        Me.lblNote.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblNote.R_ResourceId = "_CDESCRIPTION"
        Me.lblNote.Size = New System.Drawing.Size(100, 18)
        Me.lblNote.TabIndex = 11
        Me.lblNote.Text = "R_RadLabel3"
        '
        'btnBrowse
        '
        Me.btnBrowse.Location = New System.Drawing.Point(462, 0)
        Me.btnBrowse.Name = "btnBrowse"
        Me.btnBrowse.R_ConductorGridSource = Nothing
        Me.btnBrowse.R_ConductorSource = Nothing
        Me.btnBrowse.R_DescriptionId = Nothing
        Me.btnBrowse.R_ResourceId = "btnBrowse"
        Me.btnBrowse.Size = New System.Drawing.Size(110, 24)
        Me.btnBrowse.TabIndex = 10
        Me.btnBrowse.Text = "R_RadButton1"
        '
        'txtFilename
        '
        Me.txtFilename.Location = New System.Drawing.Point(109, 2)
        Me.txtFilename.Name = "txtFilename"
        Me.txtFilename.R_ConductorGridSource = Nothing
        Me.txtFilename.R_ConductorSource = Nothing
        Me.txtFilename.R_UDT = Nothing
        Me.txtFilename.ReadOnly = True
        Me.txtFilename.Size = New System.Drawing.Size(347, 20)
        Me.txtFilename.TabIndex = 9
        Me.txtFilename.TabStop = False
        '
        'lblFile
        '
        Me.lblFile.AutoSize = False
        Me.lblFile.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblFile.Location = New System.Drawing.Point(3, 3)
        Me.lblFile.Name = "lblFile"
        Me.lblFile.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblFile.R_ResourceId = "lblFile"
        Me.lblFile.Size = New System.Drawing.Size(100, 18)
        Me.lblFile.TabIndex = 8
        Me.lblFile.Text = "R_RadLabel2"
        '
        'conGridTables
        '
        Me.conGridTables.R_ConductorParent = Nothing
        Me.conGridTables.R_IsHeader = True
        Me.conGridTables.R_RadGroupBox = Nothing
        '
        'conGridColumns
        '
        Me.conGridColumns.R_ConductorParent = Me.conGridTables
        Me.conGridColumns.R_RadGroupBox = Nothing
        '
        'ofdUpload
        '
        '
        'btnShiftUp
        '
        Me.btnShiftUp.Location = New System.Drawing.Point(405, 3)
        Me.btnShiftUp.Name = "btnShiftUp"
        Me.btnShiftUp.R_ConductorGridSource = Nothing
        Me.btnShiftUp.R_ConductorSource = Nothing
        Me.btnShiftUp.R_DescriptionId = Nothing
        Me.btnShiftUp.R_ResourceId = "btnShiftUp"
        Me.btnShiftUp.Size = New System.Drawing.Size(110, 24)
        Me.btnShiftUp.TabIndex = 57
        Me.btnShiftUp.Text = "R_RadButton1"
        '
        'btnShiftDown
        '
        Me.btnShiftDown.Location = New System.Drawing.Point(521, 3)
        Me.btnShiftDown.Name = "btnShiftDown"
        Me.btnShiftDown.R_ConductorGridSource = Nothing
        Me.btnShiftDown.R_ConductorSource = Nothing
        Me.btnShiftDown.R_DescriptionId = Nothing
        Me.btnShiftDown.R_ResourceId = "btnShiftDown"
        Me.btnShiftDown.Size = New System.Drawing.Size(110, 24)
        Me.btnShiftDown.TabIndex = 58
        Me.btnShiftDown.Text = "R_RadButton2"
        '
        'CSM00700Changes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CSM00700Changes"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "Changes"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.btnManageObjects, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvTables.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvTables, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvTables, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvColumns.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvColumns, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvColumns, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.txtDatabaseName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblDatabaseName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        CType(Me.btnRelease, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnCreateChanges, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel2.ResumeLayout(False)
        CType(Me.gvScripts.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvScripts, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvScripts, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridScripts, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridChanges, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvChanges.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvChanges, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvChanges, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.btnUpload, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDescription, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblNote, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnBrowse, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtFilename, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblFile, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridTables, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridColumns, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnShiftUp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnShiftDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents bsGvTables As System.Windows.Forms.BindingSource
    Friend WithEvents bsGvColumns As System.Windows.Forms.BindingSource
    Friend WithEvents fbdSaveToFile As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents txtDatabaseName As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtApplication As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblDatabaseName As R_FrontEnd.R_RadLabel
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents SplitContainer1 As Windows.Forms.SplitContainer
    Friend WithEvents gvTables As R_FrontEnd.R_RadGridView
    Friend WithEvents gvColumns As R_FrontEnd.R_RadGridView
    Friend WithEvents conGridTables As R_FrontEnd.R_ConductorGrid
    Friend WithEvents conGridColumns As R_FrontEnd.R_ConductorGrid
    Friend WithEvents btnManageObjects As R_FrontEnd.R_Detail
    Friend WithEvents gvChanges As R_FrontEnd.R_RadGridView
    Friend WithEvents gvScripts As R_FrontEnd.R_RadGridView
    Friend WithEvents btnRelease As R_FrontEnd.R_RadButton
    Friend WithEvents bsGvChanges As Windows.Forms.BindingSource
    Friend WithEvents bsGvScripts As Windows.Forms.BindingSource
    Friend WithEvents btnUpload As R_FrontEnd.R_PopUp
    Friend WithEvents Panel1 As Windows.Forms.Panel
    Friend WithEvents Panel2 As Windows.Forms.Panel
    Friend WithEvents TableLayoutPanel2 As Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel3 As Windows.Forms.Panel
    Friend WithEvents txtDescription As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblNote As R_FrontEnd.R_RadLabel
    Friend WithEvents btnBrowse As R_FrontEnd.R_RadButton
    Friend WithEvents txtFilename As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblFile As R_FrontEnd.R_RadLabel
    Friend WithEvents ofdUpload As Windows.Forms.OpenFileDialog
    Friend WithEvents conGridScripts As R_FrontEnd.R_ConductorGrid
    Friend WithEvents conGridChanges As R_FrontEnd.R_ConductorGrid
    Friend WithEvents btnCreateChanges As R_FrontEnd.R_RadButton
    Friend WithEvents btnShiftDown As R_FrontEnd.R_RadButton
    Friend WithEvents btnShiftUp As R_FrontEnd.R_RadButton
End Class
