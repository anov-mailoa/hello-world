﻿Imports CSM00700Front.CSM00700ServiceRef

Public Class CSM00700DetailParamDTO
    Public Property OGRID_KEY As CSM00700KeyDTO
    Public Property CAPPS_NAME As String
    Public Property CDATABASE_NAME As String

    Sub New()
        ' initialization
        OGRID_KEY = New CSM00700KeyDTO
        With OGRID_KEY
            .CCOMPANY_ID = ""
            .CAPPS_CODE = ""
            .CDATABASE_ID = ""
            .CUSER_ID = ""
        End With
        CAPPS_NAME = ""
        CDATABASE_NAME = ""
    End Sub

End Class
