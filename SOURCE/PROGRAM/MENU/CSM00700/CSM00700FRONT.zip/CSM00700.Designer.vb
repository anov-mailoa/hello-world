﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSM00700
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnAddEmpty = New R_FrontEnd.R_PopUp(Me.components)
        Me.cboApplication = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.gvDatabase = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvDatabase = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridDatabase = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.btnSave = New R_FrontEnd.R_RadButton(Me.components)
        Me.txtDescription = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtCurrentVersion = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtStatus = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtInitialVersion = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtDatabaseName = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblDescription = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblCurrentVersion = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblStatus = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblInitialVersion = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblDatabaseName = New R_FrontEnd.R_RadLabel(Me.components)
        Me.preObjects = New R_FrontEnd.R_PredefinedDock(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.btnAddEmpty, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.gvDatabase, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvDatabase.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvDatabase, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridDatabase, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnSave, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDescription, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCurrentVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtStatus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtInitialVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDatabaseName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblDescription, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCurrentVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblStatus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblInitialVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblDatabaseName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.SplitContainer1, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 72.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnAddEmpty)
        Me.Panel1.Controls.Add(Me.cboApplication)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 66)
        Me.Panel1.TabIndex = 0
        '
        'btnAddEmpty
        '
        Me.btnAddEmpty.Location = New System.Drawing.Point(9, 33)
        Me.btnAddEmpty.Name = "btnAddEmpty"
        Me.btnAddEmpty.R_ConductorGridSource = Nothing
        Me.btnAddEmpty.R_ConductorSource = Nothing
        Me.btnAddEmpty.R_DescriptionId = Nothing
        Me.btnAddEmpty.R_ResourceId = "btnAddEmpty"
        Me.btnAddEmpty.R_Title = "Change Request Filter"
        Me.btnAddEmpty.Size = New System.Drawing.Size(193, 24)
        Me.btnAddEmpty.TabIndex = 52
        Me.btnAddEmpty.Text = "R_PopUp1"
        '
        'cboApplication
        '
        Me.cboApplication.DataSource = Me.bsApps
        Me.cboApplication.DisplayMember = "CAPPS_NAME"
        Me.cboApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboApplication.Location = New System.Drawing.Point(115, 9)
        Me.cboApplication.Name = "cboApplication"
        Me.cboApplication.R_ConductorGridSource = Nothing
        Me.cboApplication.R_ConductorSource = Nothing
        Me.cboApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboApplication.Size = New System.Drawing.Size(400, 20)
        Me.cboApplication.TabIndex = 51
        Me.cboApplication.Text = "R_RadDropDownList1"
        Me.cboApplication.ValueMember = "CAPPS_CODE"
        '
        'bsApps
        '
        Me.bsApps.DataSource = GetType(CSM00700Front.CSM00700ServiceRef.RLicenseAppComboDTO)
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 25
        Me.lblApplication.Text = "Application..."
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(3, 75)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.gvDatabase)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.btnSave)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtDescription)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtCurrentVersion)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtStatus)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtInitialVersion)
        Me.SplitContainer1.Panel2.Controls.Add(Me.txtDatabaseName)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lblDescription)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lblCurrentVersion)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lblStatus)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lblInitialVersion)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lblDatabaseName)
        Me.SplitContainer1.Size = New System.Drawing.Size(1271, 497)
        Me.SplitContainer1.SplitterDistance = 436
        Me.SplitContainer1.TabIndex = 1
        '
        'gvDatabase
        '
        Me.gvDatabase.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvDatabase.EnableFastScrolling = True
        Me.gvDatabase.Location = New System.Drawing.Point(0, 0)
        '
        '
        '
        Me.gvDatabase.MasterTemplate.AllowAddNewRow = False
        Me.gvDatabase.MasterTemplate.AllowDeleteRow = False
        Me.gvDatabase.MasterTemplate.AllowEditRow = False
        Me.gvDatabase.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn3.FieldName = "_CDATABASE_ID"
        R_GridViewTextBoxColumn3.HeaderText = "_CDATABASE_ID"
        R_GridViewTextBoxColumn3.Name = "_CDATABASE_ID"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CDATABASE_ID"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 103
        R_GridViewTextBoxColumn4.FieldName = "_CDATABASE_NAME"
        R_GridViewTextBoxColumn4.HeaderText = "_CDATABASE_NAME"
        R_GridViewTextBoxColumn4.Name = "_CDATABASE_NAME"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CDATABASE_NAME"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 153
        Me.gvDatabase.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn3, R_GridViewTextBoxColumn4})
        Me.gvDatabase.MasterTemplate.DataSource = Me.bsGvDatabase
        Me.gvDatabase.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvDatabase.MasterTemplate.EnableFiltering = True
        Me.gvDatabase.MasterTemplate.EnableGrouping = False
        Me.gvDatabase.MasterTemplate.ShowFilteringRow = False
        Me.gvDatabase.MasterTemplate.ShowGroupedColumns = True
        Me.gvDatabase.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvDatabase.Name = "gvDatabase"
        Me.gvDatabase.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvDatabase.R_ConductorGridSource = Me.conGridDatabase
        Me.gvDatabase.R_ConductorSource = Nothing
        Me.gvDatabase.R_DataAdded = False
        Me.gvDatabase.R_NewRowText = Nothing
        Me.gvDatabase.ShowHeaderCellButtons = True
        Me.gvDatabase.Size = New System.Drawing.Size(436, 497)
        Me.gvDatabase.TabIndex = 2
        Me.gvDatabase.Text = "R_RadGridView1"
        '
        'bsGvDatabase
        '
        Me.bsGvDatabase.DataSource = GetType(CSM00700Front.CSM00700ServiceRef.CSM00700DatabaseDTO)
        '
        'conGridDatabase
        '
        Me.conGridDatabase.R_ConductorParent = Nothing
        Me.conGridDatabase.R_IsHeader = True
        Me.conGridDatabase.R_RadGroupBox = Nothing
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(120, 267)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.R_ConductorGridSource = Nothing
        Me.btnSave.R_ConductorSource = Nothing
        Me.btnSave.R_DescriptionId = Nothing
        Me.btnSave.R_ResourceId = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(110, 24)
        Me.btnSave.TabIndex = 55
        Me.btnSave.Text = "R_RadButton1"
        '
        'txtDescription
        '
        Me.txtDescription.AcceptsReturn = True
        Me.txtDescription.AutoSize = False
        Me.txtDescription.Location = New System.Drawing.Point(120, 111)
        Me.txtDescription.Multiline = True
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.R_ConductorGridSource = Nothing
        Me.txtDescription.R_ConductorSource = Nothing
        Me.txtDescription.R_UDT = Nothing
        Me.txtDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtDescription.Size = New System.Drawing.Size(386, 150)
        Me.txtDescription.TabIndex = 54
        '
        'txtCurrentVersion
        '
        Me.txtCurrentVersion.Location = New System.Drawing.Point(120, 87)
        Me.txtCurrentVersion.Name = "txtCurrentVersion"
        Me.txtCurrentVersion.R_ConductorGridSource = Nothing
        Me.txtCurrentVersion.R_ConductorSource = Nothing
        Me.txtCurrentVersion.R_UDT = Nothing
        Me.txtCurrentVersion.ReadOnly = True
        Me.txtCurrentVersion.Size = New System.Drawing.Size(123, 20)
        Me.txtCurrentVersion.TabIndex = 53
        Me.txtCurrentVersion.TabStop = False
        '
        'txtStatus
        '
        Me.txtStatus.Location = New System.Drawing.Point(120, 63)
        Me.txtStatus.Name = "txtStatus"
        Me.txtStatus.R_ConductorGridSource = Nothing
        Me.txtStatus.R_ConductorSource = Nothing
        Me.txtStatus.R_UDT = Nothing
        Me.txtStatus.ReadOnly = True
        Me.txtStatus.Size = New System.Drawing.Size(123, 20)
        Me.txtStatus.TabIndex = 52
        Me.txtStatus.TabStop = False
        '
        'txtInitialVersion
        '
        Me.txtInitialVersion.Location = New System.Drawing.Point(120, 39)
        Me.txtInitialVersion.Name = "txtInitialVersion"
        Me.txtInitialVersion.R_ConductorGridSource = Nothing
        Me.txtInitialVersion.R_ConductorSource = Nothing
        Me.txtInitialVersion.R_UDT = Nothing
        Me.txtInitialVersion.ReadOnly = True
        Me.txtInitialVersion.Size = New System.Drawing.Size(123, 20)
        Me.txtInitialVersion.TabIndex = 51
        Me.txtInitialVersion.TabStop = False
        '
        'txtDatabaseName
        '
        Me.txtDatabaseName.Location = New System.Drawing.Point(120, 15)
        Me.txtDatabaseName.Name = "txtDatabaseName"
        Me.txtDatabaseName.R_ConductorGridSource = Nothing
        Me.txtDatabaseName.R_ConductorSource = Nothing
        Me.txtDatabaseName.R_UDT = Nothing
        Me.txtDatabaseName.Size = New System.Drawing.Size(400, 20)
        Me.txtDatabaseName.TabIndex = 50
        '
        'lblDescription
        '
        Me.lblDescription.AutoSize = False
        Me.lblDescription.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblDescription.Location = New System.Drawing.Point(14, 112)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblDescription.R_ResourceId = "lblDescription"
        Me.lblDescription.Size = New System.Drawing.Size(100, 18)
        Me.lblDescription.TabIndex = 30
        Me.lblDescription.Text = "Application..."
        '
        'lblCurrentVersion
        '
        Me.lblCurrentVersion.AutoSize = False
        Me.lblCurrentVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCurrentVersion.Location = New System.Drawing.Point(14, 88)
        Me.lblCurrentVersion.Name = "lblCurrentVersion"
        Me.lblCurrentVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCurrentVersion.R_ResourceId = "lblCurrentVersion"
        Me.lblCurrentVersion.Size = New System.Drawing.Size(100, 18)
        Me.lblCurrentVersion.TabIndex = 29
        Me.lblCurrentVersion.Text = "Application..."
        '
        'lblStatus
        '
        Me.lblStatus.AutoSize = False
        Me.lblStatus.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblStatus.Location = New System.Drawing.Point(14, 64)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblStatus.R_ResourceId = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(100, 18)
        Me.lblStatus.TabIndex = 28
        Me.lblStatus.Text = "Application..."
        '
        'lblInitialVersion
        '
        Me.lblInitialVersion.AutoSize = False
        Me.lblInitialVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblInitialVersion.Location = New System.Drawing.Point(14, 40)
        Me.lblInitialVersion.Name = "lblInitialVersion"
        Me.lblInitialVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblInitialVersion.R_ResourceId = "lblInitialVersion"
        Me.lblInitialVersion.Size = New System.Drawing.Size(100, 18)
        Me.lblInitialVersion.TabIndex = 27
        Me.lblInitialVersion.Text = "Application..."
        '
        'lblDatabaseName
        '
        Me.lblDatabaseName.AutoSize = False
        Me.lblDatabaseName.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblDatabaseName.Location = New System.Drawing.Point(14, 16)
        Me.lblDatabaseName.Name = "lblDatabaseName"
        Me.lblDatabaseName.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblDatabaseName.R_ResourceId = "lblDatabaseName"
        Me.lblDatabaseName.Size = New System.Drawing.Size(100, 18)
        Me.lblDatabaseName.TabIndex = 26
        Me.lblDatabaseName.Text = "Application..."
        '
        'preObjects
        '
        Me.preObjects.R_ConductorGridSource = Me.conGridDatabase
        Me.preObjects.R_ConductorSource = Nothing
        Me.preObjects.R_CopyAccess = True
        Me.preObjects.R_DockIndex = 0
        Me.preObjects.R_EnableHASDATA = True
        Me.preObjects.R_HeaderTitle = ""
        '
        'CSM00700
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CSM00700"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.btnAddEmpty, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.Panel2.PerformLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.gvDatabase.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvDatabase, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvDatabase, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridDatabase, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnSave, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDescription, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCurrentVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtStatus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtInitialVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDatabaseName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblDescription, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCurrentVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblStatus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblInitialVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblDatabaseName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents conGridDatabase As R_FrontEnd.R_ConductorGrid
    Friend WithEvents gvDatabase As R_FrontEnd.R_RadGridView
    Friend WithEvents bsGvDatabase As System.Windows.Forms.BindingSource
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents cboApplication As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblDescription As R_FrontEnd.R_RadLabel
    Friend WithEvents lblCurrentVersion As R_FrontEnd.R_RadLabel
    Friend WithEvents lblStatus As R_FrontEnd.R_RadLabel
    Friend WithEvents lblInitialVersion As R_FrontEnd.R_RadLabel
    Friend WithEvents lblDatabaseName As R_FrontEnd.R_RadLabel
    Friend WithEvents txtCurrentVersion As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtStatus As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtInitialVersion As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtDatabaseName As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtDescription As R_FrontEnd.R_RadTextBox
    Friend WithEvents btnAddEmpty As R_FrontEnd.R_PopUp
    Friend WithEvents btnSave As R_FrontEnd.R_RadButton
    Friend WithEvents preObjects As R_FrontEnd.R_PredefinedDock
End Class
