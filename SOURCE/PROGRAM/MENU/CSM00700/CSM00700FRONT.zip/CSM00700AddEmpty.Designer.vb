﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSM00700AddEmpty
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.R_ReturnPopUp1 = New R_FrontEnd.R_ReturnPopUp()
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblDescription = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblDatabaseName = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblDatabaseID = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtDatabaseID = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtApplication = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtDescription = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtDatabaseName = New R_FrontEnd.R_RadTextBox(Me.components)
        CType(Me.R_ReturnPopUp1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblDescription, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblDatabaseName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblDatabaseID, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDatabaseID, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDescription, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDatabaseName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'R_ReturnPopUp1
        '
        Me.R_ReturnPopUp1.Location = New System.Drawing.Point(118, 246)
        Me.R_ReturnPopUp1.Name = "R_ReturnPopUp1"
        Me.R_ReturnPopUp1.Size = New System.Drawing.Size(162, 31)
        Me.R_ReturnPopUp1.TabIndex = 4
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(12, 12)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 33
        Me.lblApplication.Text = "Application..."
        '
        'lblDescription
        '
        Me.lblDescription.AutoSize = False
        Me.lblDescription.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblDescription.Location = New System.Drawing.Point(12, 91)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblDescription.R_ResourceId = "lblDescription"
        Me.lblDescription.Size = New System.Drawing.Size(100, 18)
        Me.lblDescription.TabIndex = 51
        Me.lblDescription.Text = "Application..."
        '
        'lblDatabaseName
        '
        Me.lblDatabaseName.AutoSize = False
        Me.lblDatabaseName.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblDatabaseName.Location = New System.Drawing.Point(12, 65)
        Me.lblDatabaseName.Name = "lblDatabaseName"
        Me.lblDatabaseName.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblDatabaseName.R_ResourceId = "lblDatabaseName"
        Me.lblDatabaseName.Size = New System.Drawing.Size(100, 18)
        Me.lblDatabaseName.TabIndex = 50
        Me.lblDatabaseName.Text = "Application..."
        '
        'lblDatabaseID
        '
        Me.lblDatabaseID.AutoSize = False
        Me.lblDatabaseID.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblDatabaseID.Location = New System.Drawing.Point(12, 39)
        Me.lblDatabaseID.Name = "lblDatabaseID"
        Me.lblDatabaseID.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblDatabaseID.R_ResourceId = "lblDatabaseID"
        Me.lblDatabaseID.Size = New System.Drawing.Size(100, 18)
        Me.lblDatabaseID.TabIndex = 48
        Me.lblDatabaseID.Text = "Application..."
        '
        'txtDatabaseID
        '
        Me.txtDatabaseID.Location = New System.Drawing.Point(118, 38)
        Me.txtDatabaseID.Name = "txtDatabaseID"
        Me.txtDatabaseID.R_ConductorGridSource = Nothing
        Me.txtDatabaseID.R_ConductorSource = Nothing
        Me.txtDatabaseID.R_UDT = Nothing
        Me.txtDatabaseID.Size = New System.Drawing.Size(206, 20)
        Me.txtDatabaseID.TabIndex = 1
        '
        'txtApplication
        '
        Me.txtApplication.Location = New System.Drawing.Point(118, 11)
        Me.txtApplication.Name = "txtApplication"
        Me.txtApplication.R_ConductorGridSource = Nothing
        Me.txtApplication.R_ConductorSource = Nothing
        Me.txtApplication.R_UDT = Nothing
        Me.txtApplication.ReadOnly = True
        Me.txtApplication.Size = New System.Drawing.Size(206, 20)
        Me.txtApplication.TabIndex = 0
        Me.txtApplication.TabStop = False
        '
        'txtDescription
        '
        Me.txtDescription.AcceptsReturn = True
        Me.txtDescription.AutoSize = False
        Me.txtDescription.Location = New System.Drawing.Point(118, 90)
        Me.txtDescription.Multiline = True
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.R_ConductorGridSource = Nothing
        Me.txtDescription.R_ConductorSource = Nothing
        Me.txtDescription.R_UDT = Nothing
        Me.txtDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtDescription.Size = New System.Drawing.Size(386, 150)
        Me.txtDescription.TabIndex = 3
        '
        'txtDatabaseName
        '
        Me.txtDatabaseName.Location = New System.Drawing.Point(118, 64)
        Me.txtDatabaseName.Name = "txtDatabaseName"
        Me.txtDatabaseName.R_ConductorGridSource = Nothing
        Me.txtDatabaseName.R_ConductorSource = Nothing
        Me.txtDatabaseName.R_UDT = Nothing
        Me.txtDatabaseName.Size = New System.Drawing.Size(206, 20)
        Me.txtDatabaseName.TabIndex = 2
        '
        'CSM00700AddEmpty
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(531, 279)
        Me.ControlBox = False
        Me.Controls.Add(Me.txtDatabaseName)
        Me.Controls.Add(Me.txtDescription)
        Me.Controls.Add(Me.txtApplication)
        Me.Controls.Add(Me.txtDatabaseID)
        Me.Controls.Add(Me.lblDescription)
        Me.Controls.Add(Me.lblDatabaseName)
        Me.Controls.Add(Me.lblDatabaseID)
        Me.Controls.Add(Me.lblApplication)
        Me.Controls.Add(Me.R_ReturnPopUp1)
        Me.Name = "CSM00700AddEmpty"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "Add Empty Database"
        CType(Me.R_ReturnPopUp1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblDescription, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblDatabaseName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblDatabaseID, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDatabaseID, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDescription, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDatabaseName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents R_ReturnPopUp1 As R_FrontEnd.R_ReturnPopUp
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents lblDescription As R_FrontEnd.R_RadLabel
    Friend WithEvents lblDatabaseName As R_FrontEnd.R_RadLabel
    Friend WithEvents lblDatabaseID As R_FrontEnd.R_RadLabel
    Friend WithEvents txtDatabaseID As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtApplication As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtDescription As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtDatabaseName As R_FrontEnd.R_RadTextBox
End Class
