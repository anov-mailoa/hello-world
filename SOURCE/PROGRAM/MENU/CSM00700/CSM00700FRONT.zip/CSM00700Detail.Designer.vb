﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSM00700Detail
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn1 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewTextBoxColumn6 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn7 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn8 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn9 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewLookUpColumn1 As R_FrontEnd.R_GridViewLookUpColumn = New R_FrontEnd.R_GridViewLookUpColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtDatabaseName = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtApplication = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblDatabaseName = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadPageView1 = New R_FrontEnd.R_RadPageView(Me.components)
        Me.pvpTables = New Telerik.WinControls.UI.RadPageViewPage()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.btnChanges = New R_FrontEnd.R_Detail(Me.components)
        Me.gvTables = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvTables = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridTables = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.gvColumns = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvColumns = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridColumns = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.pvpPrograms = New Telerik.WinControls.UI.RadPageViewPage()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.gvSources = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvSources = New System.Windows.Forms.BindingSource(Me.components)
        Me.gvPrograms = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvPrograms = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridPrograms = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.fbdSaveToFile = New System.Windows.Forms.FolderBrowserDialog()
        Me.conGridSources = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.txtDatabaseName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblDatabaseName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadPageView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.R_RadPageView1.SuspendLayout()
        Me.pvpTables.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.btnChanges, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvTables, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvTables.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvTables, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridTables, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvColumns, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvColumns.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvColumns, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridColumns, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pvpPrograms.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        CType(Me.gvSources, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvSources.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvSources, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvPrograms, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvPrograms.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvPrograms, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridPrograms, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridSources, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 1277.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.R_RadPageView1, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 72.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 200.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.txtDatabaseName)
        Me.Panel1.Controls.Add(Me.txtApplication)
        Me.Panel1.Controls.Add(Me.lblDatabaseName)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 66)
        Me.Panel1.TabIndex = 1
        '
        'txtDatabaseName
        '
        Me.txtDatabaseName.Location = New System.Drawing.Point(115, 34)
        Me.txtDatabaseName.Name = "txtDatabaseName"
        Me.txtDatabaseName.R_ConductorGridSource = Nothing
        Me.txtDatabaseName.R_ConductorSource = Nothing
        Me.txtDatabaseName.R_UDT = Nothing
        Me.txtDatabaseName.ReadOnly = True
        Me.txtDatabaseName.Size = New System.Drawing.Size(206, 20)
        Me.txtDatabaseName.TabIndex = 52
        Me.txtDatabaseName.TabStop = False
        '
        'txtApplication
        '
        Me.txtApplication.Location = New System.Drawing.Point(115, 8)
        Me.txtApplication.Name = "txtApplication"
        Me.txtApplication.R_ConductorGridSource = Nothing
        Me.txtApplication.R_ConductorSource = Nothing
        Me.txtApplication.R_UDT = Nothing
        Me.txtApplication.ReadOnly = True
        Me.txtApplication.Size = New System.Drawing.Size(206, 20)
        Me.txtApplication.TabIndex = 51
        Me.txtApplication.TabStop = False
        '
        'lblDatabaseName
        '
        Me.lblDatabaseName.AutoSize = False
        Me.lblDatabaseName.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblDatabaseName.Location = New System.Drawing.Point(9, 35)
        Me.lblDatabaseName.Name = "lblDatabaseName"
        Me.lblDatabaseName.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblDatabaseName.R_ResourceId = "lblDatabaseName"
        Me.lblDatabaseName.Size = New System.Drawing.Size(100, 18)
        Me.lblDatabaseName.TabIndex = 54
        Me.lblDatabaseName.Text = "Application..."
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 53
        Me.lblApplication.Text = "Application..."
        '
        'R_RadPageView1
        '
        Me.R_RadPageView1.Controls.Add(Me.pvpTables)
        Me.R_RadPageView1.Controls.Add(Me.pvpPrograms)
        Me.R_RadPageView1.DefaultPage = Me.pvpTables
        Me.R_RadPageView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.R_RadPageView1.Location = New System.Drawing.Point(3, 75)
        Me.R_RadPageView1.Name = "R_RadPageView1"
        Me.R_RadPageView1.R_ConductorGridSource = Nothing
        Me.R_RadPageView1.R_ConductorSource = Nothing
        Me.R_RadPageView1.SelectedPage = Me.pvpPrograms
        Me.R_RadPageView1.Size = New System.Drawing.Size(1271, 497)
        Me.R_RadPageView1.TabIndex = 2
        Me.R_RadPageView1.Text = "Tables"
        '
        'pvpTables
        '
        Me.pvpTables.Controls.Add(Me.SplitContainer1)
        Me.pvpTables.ItemSize = New System.Drawing.SizeF(115.0!, 28.0!)
        Me.pvpTables.Location = New System.Drawing.Point(10, 37)
        Me.pvpTables.Name = "pvpTables"
        Me.pvpTables.Size = New System.Drawing.Size(1250, 449)
        Me.pvpTables.Text = "RadPageViewPage1"
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.btnChanges)
        Me.SplitContainer1.Panel1.Controls.Add(Me.gvTables)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.gvColumns)
        Me.SplitContainer1.Size = New System.Drawing.Size(1250, 449)
        Me.SplitContainer1.SplitterDistance = 428
        Me.SplitContainer1.TabIndex = 2
        '
        'btnChanges
        '
        Me.btnChanges.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnChanges.Location = New System.Drawing.Point(3, 422)
        Me.btnChanges.Name = "btnChanges"
        Me.btnChanges.R_ConductorGridSource = Nothing
        Me.btnChanges.R_ConductorSource = Nothing
        Me.btnChanges.R_DescriptionId = Nothing
        Me.btnChanges.R_ResourceId = "btnChanges"
        Me.btnChanges.R_Title = Nothing
        Me.btnChanges.Size = New System.Drawing.Size(110, 24)
        Me.btnChanges.TabIndex = 55
        Me.btnChanges.Text = "R_Detail1"
        '
        'gvTables
        '
        Me.gvTables.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.gvTables.EnableFastScrolling = True
        Me.gvTables.Location = New System.Drawing.Point(0, 0)
        '
        '
        '
        Me.gvTables.MasterTemplate.AllowAddNewRow = False
        Me.gvTables.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn1.FieldName = "CTABLE_NAME"
        R_GridViewTextBoxColumn1.HeaderText = "_CTABLE_NAME"
        R_GridViewTextBoxColumn1.Name = "_CTABLE_NAME"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CTABLE_NAME"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 101
        R_GridViewTextBoxColumn2.FieldName = "CDESCRIPTION"
        R_GridViewTextBoxColumn2.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxColumn2.Name = "_CDESCRIPTION"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 103
        Me.gvTables.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2})
        Me.gvTables.MasterTemplate.DataSource = Me.bsGvTables
        Me.gvTables.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvTables.MasterTemplate.EnableFiltering = True
        Me.gvTables.MasterTemplate.EnableGrouping = False
        Me.gvTables.MasterTemplate.ShowFilteringRow = False
        Me.gvTables.MasterTemplate.ShowGroupedColumns = True
        Me.gvTables.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvTables.Name = "gvTables"
        Me.gvTables.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvTables.R_ConductorGridSource = Me.conGridTables
        Me.gvTables.R_ConductorSource = Nothing
        Me.gvTables.R_DataAdded = False
        Me.gvTables.R_NewRowText = Nothing
        Me.gvTables.ShowHeaderCellButtons = True
        Me.gvTables.Size = New System.Drawing.Size(428, 416)
        Me.gvTables.TabIndex = 2
        Me.gvTables.Text = "R_RadGridView1"
        '
        'bsGvTables
        '
        Me.bsGvTables.DataSource = GetType(CSM00700Front.CSM00700StreamingServiceRef.CSM00700DbTablesGridDTO)
        '
        'conGridTables
        '
        Me.conGridTables.R_ConductorParent = Nothing
        Me.conGridTables.R_RadGroupBox = Nothing
        '
        'gvColumns
        '
        Me.gvColumns.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvColumns.EnableFastScrolling = True
        Me.gvColumns.Location = New System.Drawing.Point(0, 0)
        '
        '
        '
        Me.gvColumns.MasterTemplate.AllowAddNewRow = False
        Me.gvColumns.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn3.FieldName = "CCOLUMN_NAME"
        R_GridViewTextBoxColumn3.HeaderText = "_CCOLUMN_NAME"
        R_GridViewTextBoxColumn3.Name = "_CCOLUMN_NAME"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CCOLUMN_NAME"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 118
        R_GridViewTextBoxColumn4.FieldName = "CDATA_TYPE"
        R_GridViewTextBoxColumn4.HeaderText = "_CDATA_TYPE"
        R_GridViewTextBoxColumn4.Name = "_CDATA_TYPE"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CDATA_TYPE"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 91
        R_GridViewTextBoxColumn5.FieldName = "CDESCRIPTION"
        R_GridViewTextBoxColumn5.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxColumn5.Name = "_CDESCRIPTION"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 103
        R_GridViewCheckBoxColumn1.FieldName = "LNULL"
        R_GridViewCheckBoxColumn1.HeaderText = "_LNULL"
        R_GridViewCheckBoxColumn1.Name = "_LNULL"
        R_GridViewCheckBoxColumn1.R_ResourceId = "_LNULL"
        R_GridViewCheckBoxColumn1.Width = 59
        R_GridViewTextBoxColumn6.FieldName = "CDEFAULT_VALUE"
        R_GridViewTextBoxColumn6.HeaderText = "_CDEFAULT_VALUE"
        R_GridViewTextBoxColumn6.Name = "_CDEFAULT_VALUE"
        R_GridViewTextBoxColumn6.R_ResourceId = "_CDEFAULT_VALUE"
        R_GridViewTextBoxColumn6.R_UDT = Nothing
        R_GridViewTextBoxColumn6.Width = 117
        Me.gvColumns.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn3, R_GridViewTextBoxColumn4, R_GridViewTextBoxColumn5, R_GridViewCheckBoxColumn1, R_GridViewTextBoxColumn6})
        Me.gvColumns.MasterTemplate.DataSource = Me.bsGvColumns
        Me.gvColumns.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvColumns.MasterTemplate.EnableFiltering = True
        Me.gvColumns.MasterTemplate.ShowFilteringRow = False
        Me.gvColumns.MasterTemplate.ShowGroupedColumns = True
        Me.gvColumns.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvColumns.Name = "gvColumns"
        Me.gvColumns.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvColumns.R_ConductorGridSource = Me.conGridColumns
        Me.gvColumns.R_ConductorSource = Nothing
        Me.gvColumns.R_DataAdded = False
        Me.gvColumns.R_EnableGrouping = True
        Me.gvColumns.R_NewRowText = Nothing
        Me.gvColumns.ShowGroupPanel = False
        Me.gvColumns.ShowHeaderCellButtons = True
        Me.gvColumns.Size = New System.Drawing.Size(818, 449)
        Me.gvColumns.TabIndex = 3
        Me.gvColumns.Text = "R_RadGridView1"
        '
        'bsGvColumns
        '
        Me.bsGvColumns.DataSource = GetType(CSM00700Front.CSM00700StreamingServiceRef.CSM00700DbColumnsGridDTO)
        '
        'conGridColumns
        '
        Me.conGridColumns.R_ConductorParent = Me.conGridTables
        Me.conGridColumns.R_RadGroupBox = Nothing
        '
        'pvpPrograms
        '
        Me.pvpPrograms.Controls.Add(Me.TableLayoutPanel2)
        Me.pvpPrograms.ItemSize = New System.Drawing.SizeF(115.0!, 28.0!)
        Me.pvpPrograms.Location = New System.Drawing.Point(10, 37)
        Me.pvpPrograms.Name = "pvpPrograms"
        Me.pvpPrograms.Size = New System.Drawing.Size(1250, 449)
        Me.pvpPrograms.Text = "RadPageViewPage2"
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 2
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 47.84!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 52.16!))
        Me.TableLayoutPanel2.Controls.Add(Me.gvSources, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.gvPrograms, 0, 0)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 449.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(1250, 449)
        Me.TableLayoutPanel2.TabIndex = 0
        '
        'gvSources
        '
        Me.gvSources.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvSources.EnableFastScrolling = True
        Me.gvSources.Location = New System.Drawing.Point(601, 3)
        '
        '
        '
        Me.gvSources.MasterTemplate.AllowAddNewRow = False
        Me.gvSources.MasterTemplate.AutoGenerateColumns = False
        Me.gvSources.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn7.FieldName = "CSOURCE_ID"
        R_GridViewTextBoxColumn7.HeaderText = "_CSOURCE_ID"
        R_GridViewTextBoxColumn7.Name = "_CSOURCE_ID"
        R_GridViewTextBoxColumn7.R_ResourceId = "_CSOURCE_ID"
        R_GridViewTextBoxColumn7.R_UDT = Nothing
        R_GridViewTextBoxColumn7.Width = 294
        R_GridViewTextBoxColumn8.FieldName = "CDESCRIPTION"
        R_GridViewTextBoxColumn8.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxColumn8.Name = "_CDESCRIPTION"
        R_GridViewTextBoxColumn8.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxColumn8.R_UDT = Nothing
        R_GridViewTextBoxColumn8.Width = 333
        Me.gvSources.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn7, R_GridViewTextBoxColumn8})
        Me.gvSources.MasterTemplate.DataSource = Me.bsGvSources
        Me.gvSources.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvSources.MasterTemplate.EnableFiltering = True
        Me.gvSources.MasterTemplate.ShowFilteringRow = False
        Me.gvSources.MasterTemplate.ShowGroupedColumns = True
        Me.gvSources.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvSources.Name = "gvSources"
        Me.gvSources.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvSources.R_ConductorGridSource = Nothing
        Me.gvSources.R_ConductorSource = Nothing
        Me.gvSources.R_DataAdded = False
        Me.gvSources.R_EnableGrouping = True
        Me.gvSources.R_NewRowText = Nothing
        Me.gvSources.ShowGroupPanel = False
        Me.gvSources.ShowHeaderCellButtons = True
        Me.gvSources.Size = New System.Drawing.Size(646, 443)
        Me.gvSources.TabIndex = 4
        Me.gvSources.Text = "R_RadGridView1"
        '
        'bsGvSources
        '
        Me.bsGvSources.DataSource = GetType(CSM00700Front.CSM00700ProgramsStreamingServiceRef.CSM00700DbProgramSourcesGridDTO)
        '
        'gvPrograms
        '
        Me.gvPrograms.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvPrograms.EnableFastScrolling = True
        Me.gvPrograms.Location = New System.Drawing.Point(3, 3)
        '
        '
        '
        Me.gvPrograms.MasterTemplate.AutoGenerateColumns = False
        Me.gvPrograms.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn9.FieldName = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn9.HeaderText = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn9.Name = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn9.R_ResourceId = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn9.R_UDT = Nothing
        R_GridViewTextBoxColumn9.Width = 285
        R_GridViewLookUpColumn1.FieldName = "_CSOURCE_GROUP_ID"
        R_GridViewLookUpColumn1.HeaderText = "_CSOURCE_GROUP_ID"
        R_GridViewLookUpColumn1.Name = "_CSOURCE_GROUP_ID"
        R_GridViewLookUpColumn1.R_EnableADD = True
        R_GridViewLookUpColumn1.R_ResourceId = "_CSOURCE_GROUP_ID"
        R_GridViewLookUpColumn1.R_Title = Nothing
        R_GridViewLookUpColumn1.Width = 288
        Me.gvPrograms.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn9, R_GridViewLookUpColumn1})
        Me.gvPrograms.MasterTemplate.DataSource = Me.bsGvPrograms
        Me.gvPrograms.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvPrograms.MasterTemplate.EnableFiltering = True
        Me.gvPrograms.MasterTemplate.EnableGrouping = False
        Me.gvPrograms.MasterTemplate.ShowFilteringRow = False
        Me.gvPrograms.MasterTemplate.ShowGroupedColumns = True
        Me.gvPrograms.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvPrograms.Name = "gvPrograms"
        Me.gvPrograms.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvPrograms.R_ConductorGridSource = Me.conGridPrograms
        Me.gvPrograms.R_ConductorSource = Nothing
        Me.gvPrograms.R_DataAdded = False
        Me.gvPrograms.R_NewRowText = Nothing
        Me.gvPrograms.ShowHeaderCellButtons = True
        Me.gvPrograms.Size = New System.Drawing.Size(592, 443)
        Me.gvPrograms.TabIndex = 2
        Me.gvPrograms.Text = "R_RadGridView1"
        '
        'bsGvPrograms
        '
        Me.bsGvPrograms.DataSource = GetType(CSM00700Front.CSM00700ProgramsStreamingServiceRef.CSM00700DbProgramsGridDTO)
        '
        'conGridPrograms
        '
        Me.conGridPrograms.R_ConductorParent = Nothing
        Me.conGridPrograms.R_IsHeader = True
        Me.conGridPrograms.R_RadGroupBox = Nothing
        '
        'conGridSources
        '
        Me.conGridSources.R_ConductorParent = Me.conGridPrograms
        Me.conGridSources.R_RadGroupBox = Nothing
        '
        'CSM00700Detail
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CSM00700Detail"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.txtDatabaseName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblDatabaseName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadPageView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.R_RadPageView1.ResumeLayout(False)
        Me.pvpTables.ResumeLayout(False)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.btnChanges, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvTables.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvTables, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvTables, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridTables, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvColumns.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvColumns, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvColumns, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridColumns, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pvpPrograms.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        CType(Me.gvSources.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvSources, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvSources, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvPrograms.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvPrograms, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvPrograms, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridPrograms, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridSources, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents bsGvTables As System.Windows.Forms.BindingSource
    Friend WithEvents bsGvColumns As System.Windows.Forms.BindingSource
    Friend WithEvents fbdSaveToFile As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents R_RadPageView1 As R_FrontEnd.R_RadPageView
    Friend WithEvents pvpTables As Telerik.WinControls.UI.RadPageViewPage
    Friend WithEvents pvpPrograms As Telerik.WinControls.UI.RadPageViewPage
    Friend WithEvents txtDatabaseName As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtApplication As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblDatabaseName As R_FrontEnd.R_RadLabel
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents SplitContainer1 As Windows.Forms.SplitContainer
    Friend WithEvents gvTables As R_FrontEnd.R_RadGridView
    Friend WithEvents gvColumns As R_FrontEnd.R_RadGridView
    Friend WithEvents conGridTables As R_FrontEnd.R_ConductorGrid
    Friend WithEvents conGridColumns As R_FrontEnd.R_ConductorGrid
    Friend WithEvents btnChanges As R_FrontEnd.R_Detail
    Friend WithEvents TableLayoutPanel2 As Windows.Forms.TableLayoutPanel
    Friend WithEvents gvSources As R_FrontEnd.R_RadGridView
    Friend WithEvents gvPrograms As R_FrontEnd.R_RadGridView
    Friend WithEvents conGridSources As R_FrontEnd.R_ConductorGrid
    Friend WithEvents conGridPrograms As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsGvPrograms As Windows.Forms.BindingSource
    Friend WithEvents bsGvSources As Windows.Forms.BindingSource
End Class
