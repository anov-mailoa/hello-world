﻿Imports R_FrontEnd
Imports CSM00700Front.CSM00700ServiceRef
Imports CSM00700Front.CSM00700StreamingServiceRef
Imports CSM00700Front.CSM00700ChangesServiceRef
Imports CSM00700Front.CSM00700ChangesStreamingServiceRef
Imports CSM00700Front.CSM00700ScriptsServiceRef
Imports R_Common
Imports System.ServiceModel.Channels
Imports ClientHelper
Imports CSM00700FrontResources
Imports System.IO
Imports Telerik.WinControls.UI
Imports System.ComponentModel
Imports RCustDBFileCommon

Public Class CSM00700Changes

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSM00700Service/CSM00700Service.svc"
    Dim C_ServiceNameStream As String = "CSM00700Service/CSM00700StreamingService.svc"
    Dim C_ChangesServiceName As String = "CSM00700Service/CSM00700ChangesService.svc"
    Dim C_ChangesServiceNameStream As String = "CSM00700Service/CSM00700ChangesStreamingService.svc"
    Dim C_ScriptsServiceName As String = "CSM00700Service/CSM00700ScriptsService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPS_CODE As String
    Dim _CDATABASE_ID As String
    Dim _CDB_CHANGE_ID As String
    Dim _CSCRIPT_ID As String
    Dim _CNOTE As String
    Dim _CVERSION As String
    Dim llInitialized As Boolean = False
    Dim _CSERVER_UID As String = ""
    Dim _LACTIVE As Boolean
    Dim _NINTERVAL As Integer = 1
    Dim _NGRACE_DAYS As Integer = 0
    Dim _NWARNING_DAYS As Integer = 0
    Dim _CLAST_EXPIRY_DATE As String
    Dim _CACTIVATION_TYPE As String
    Dim _CFILE As String
    Dim _CFILE_NAME As String
#End Region

#Region " F O R M "

    Private Sub CSM00700Changes_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loSvc As CSM00700ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700Service, CSM00700ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            With CType(poParameter, CSM00700DetailParamDTO)
                _CAPPS_CODE = .OGRID_KEY.CAPPS_CODE
                _CDATABASE_ID = .OGRID_KEY.CDATABASE_ID
                txtApplication.Text = .CAPPS_NAME
                txtDatabaseName.Text = .CDATABASE_NAME
            End With

            llInitialized = True
            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub CSM00700Changes_R_LockUnlock(peLockUnlock As R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region "CHANGES GRIDVIEW Events "

    Private Sub gvChanges_DataBindingComplete(sender As Object, e As GridViewBindingCompleteEventArgs) Handles gvChanges.DataBindingComplete
        gvChanges.BestFitColumns()
    End Sub

    Private Sub gvChanges_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvChanges.R_ServiceGetListRecord
        Dim loServiceStream As CSM00700ChangesStreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700ChangesStreamingService, CSM00700ChangesStreamingServiceClient)(e_ServiceClientType.StreamingService, C_ChangesServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00700ChangesGridDTO)
        Dim loListEntity As New List(Of CSM00700ChangesDTO)

        Try
            With poEntity
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cDatabaseID", .CDATABASE_ID)
            End With

            loRtn = loServiceStream.GetChangesList()
            loStreaming = R_StreamUtility(Of CSM00700ChangesGridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00700ChangesGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New CSM00700ChangesDTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                          ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                          ._CDATABASE_ID = loDto.CDATABASE_ID,
                                                          ._CDB_CHANGE_ID = loDto.CDB_CHANGE_ID,
                                                          ._CVERSION = loDto.CVERSION,
                                                          ._DCHANGE_DATE = loDto.DCHANGE_DATE,
                                                          ._CSTATUS = loDto.CSTATUS,
                                                          ._CDESCRIPTION = loDto.CDESCRIPTION})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvChanges_R_Display(poEntity As Object, poGridCellCollection As GridViewCellInfoCollection, peGridMode As R_eGridMode) Handles gvChanges.R_Display
        Dim loEx As New R_Exception
        Dim loTableKey As New CSM00700Front.CSM00700ServiceRef.CSM00700KeyDTO

        Try
            With CType(poEntity, CSM00700ChangesDTO)
                loTableKey.CCOMPANY_ID = ._CCOMPANY_ID
                loTableKey.CAPPS_CODE = ._CAPPS_CODE
                loTableKey.CDATABASE_ID = ._CDATABASE_ID
                loTableKey.CDB_CHANGE_ID = ._CDB_CHANGE_ID
                _CDB_CHANGE_ID = ._CDB_CHANGE_ID
            End With
            gvScripts.R_RefreshGrid(loTableKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvChanges_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvChanges.R_ServiceGetRecord
        Dim loService As CSM00700ChangesServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700ChangesService, CSM00700ChangesServiceClient)(e_ServiceClientType.RegularService, C_ChangesServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New CSM00700ChangesDTO With {._CCOMPANY_ID = _CCOMPID,
                                                                             ._CAPPS_CODE = _CAPPS_CODE,
                                                                             ._CDATABASE_ID = _CDATABASE_ID,
                                                                             ._CDB_CHANGE_ID = _CDB_CHANGE_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvChanges_R_ServiceDelete(poEntity As Object) Handles gvChanges.R_ServiceDelete
        Dim loService As CSM00700ChangesServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700ChangesService, CSM00700ChangesServiceClient)(e_ServiceClientType.RegularService, C_ChangesServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String

        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvChanges_R_ServiceSave(poEntity As Object, peGridMode As R_eGridMode, ByRef poEntityResult As Object) Handles gvChanges.R_ServiceSave
        Dim loService As CSM00700ChangesServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700ChangesService, CSM00700ChangesServiceClient)(e_ServiceClientType.RegularService, C_ChangesServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String
        Dim lcPredefinedErr As String

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            lcPredefinedErr = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr)
            If lcPredefinedErr IsNot Nothing Then
                loEx.ErrorList.Clear()
                loEx.Add(lcErr, lcPredefinedErr)
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvChanges_R_Saving(ByRef poEntity As Object, poGridCellCollection As GridViewCellInfoCollection, peGridMode As R_eGridMode) Handles gvChanges.R_Saving
        With CType(poEntity, CSM00700ChangesDTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = _CAPPS_CODE
            ._CCREATE_BY = _CUSERID
            ._CUPDATE_BY = _CUSERID
        End With
    End Sub

#End Region

#Region "SCRIPTS GRIDVIEW Events "

    Private Sub gvScripts_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvScripts.R_ServiceGetListRecord
        Dim loServiceStream As CSM00700ChangesStreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700ChangesStreamingService, CSM00700ChangesStreamingServiceClient)(e_ServiceClientType.StreamingService, C_ChangesServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00700ScriptsGridDTO)
        Dim loListEntity As New List(Of CSM00700ScriptsDTO)

        Try
            With poEntity
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cDatabaseID", .CDATABASE_ID)
                R_Utility.R_SetStreamingContext("cDBChangeID", .CDB_CHANGE_ID)
            End With

            loRtn = loServiceStream.GetScriptList()
            loStreaming = R_StreamUtility(Of CSM00700ScriptsGridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00700ScriptsGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New CSM00700ScriptsDTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                          ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                          ._CDATABASE_ID = loDto.CDATABASE_ID,
                                                          ._CDB_CHANGE_ID = loDto.CDB_CHANGE_ID,
                                                          ._CSCRIPT_ID = loDto.CSCRIPT_ID,
                                                          ._CFILE_NAME = loDto.CFILE_NAME,
                                                          ._CNOTE = loDto.CNOTE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvScripts_DataBindingComplete(sender As Object, e As GridViewBindingCompleteEventArgs) Handles gvScripts.DataBindingComplete
        gvChanges.BestFitColumns()
    End Sub

    Private Sub gvScripts_R_ServiceDelete(poEntity As Object) Handles gvScripts.R_ServiceDelete
        Dim loService As CSM00700ScriptsServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700ScriptsService, CSM00700ScriptsServiceClient)(e_ServiceClientType.RegularService, C_ScriptsServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String

        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvScripts_R_ServiceSave(poEntity As Object, peGridMode As R_eGridMode, ByRef poEntityResult As Object) Handles gvScripts.R_ServiceSave
        Dim loService As CSM00700ScriptsServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700ScriptsService, CSM00700ScriptsServiceClient)(e_ServiceClientType.RegularService, C_ScriptsServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String
        Dim lcPredefinedErr As String

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            lcPredefinedErr = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr)
            If lcPredefinedErr IsNot Nothing Then
                loEx.ErrorList.Clear()
                loEx.Add(lcErr, lcPredefinedErr)
            End If
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

    Private Sub gvScripts_R_Saving(ByRef poEntity As Object, poGridCellCollection As GridViewCellInfoCollection, peGridMode As R_eGridMode) Handles gvScripts.R_Saving
        With CType(poEntity, CSM00700ScriptsDTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = _CAPPS_CODE
            ._CCREATE_BY = _CUSERID
            ._CUPDATE_BY = _CUSERID
        End With
    End Sub

    Private Sub gvScripts_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvScripts.R_ServiceGetRecord
        Dim loService As CSM00700ScriptsServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700ScriptsService, CSM00700ScriptsServiceClient)(e_ServiceClientType.RegularService, C_ScriptsServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New CSM00700ScriptsDTO With {._CCOMPANY_ID = _CCOMPID,
                                                                             ._CAPPS_CODE = _CAPPS_CODE,
                                                                             ._CDATABASE_ID = _CDATABASE_ID,
                                                                             ._CDB_CHANGE_ID = _CDB_CHANGE_ID,
                                                                             ._CSCRIPT_ID = _CSCRIPT_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvScripts_R_Display(poEntity As Object, poGridCellCollection As GridViewCellInfoCollection, peGridMode As R_eGridMode) Handles gvScripts.R_Display
        With CType(poEntity, CSM00700ScriptsDTO)
            _CSCRIPT_ID = ._CSCRIPT_ID
        End With
    End Sub

#End Region

#Region " TABLE GRIDVIEW Events "

    Private Sub gvTables_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvTables.DataBindingComplete
        gvTables.BestFitColumns()
    End Sub

    Private Sub gvTables_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvTables.R_Display
        Dim loEx As New R_Exception
        Dim loTableKey As New CSM00700Front.CSM00700ServiceRef.CSM00700KeyDTO

        Try
            With CType(poEntity, CSM00700DbTablesGridDTO)
                loTableKey.CCOMPANY_ID = .CCOMPANY_ID
                loTableKey.CAPPS_CODE = .CAPPS_CODE
                loTableKey.CDATABASE_ID = .CDATABASE_ID
                loTableKey.CTABLE_NAME = .CTABLE_NAME
            End With
            gvColumns.R_RefreshGrid(loTableKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvTables_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvTables.R_ServiceGetListRecord
        Dim loServiceStream As CSM00700StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700StreamingService, CSM00700StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00700DbTablesGridDTO)
        Dim loListEntity As New List(Of CSM00700DbTablesGridDTO)

        Try
            With poEntity
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cDatabaseID", .CDATABASE_ID)
            End With

            loRtn = loServiceStream.GetTableList()
            loStreaming = R_StreamUtility(Of CSM00700DbTablesGridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00700DbTablesGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " COLUMN GRIDVIEW Events "
    Private Sub gvColumns_DataBindingComplete(sender As Object, e As GridViewBindingCompleteEventArgs) Handles gvColumns.DataBindingComplete
        gvColumns.BestFitColumns()
    End Sub

    Private Sub gvColumns_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvColumns.R_ServiceGetListRecord
        Dim loServiceStream As CSM00700StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700StreamingService, CSM00700StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00700DbColumnsGridDTO)
        Dim loListEntity As New List(Of CSM00700DbColumnsGridDTO)

        Try
            With poEntity
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cDatabaseID", .CDATABASE_ID)
                R_Utility.R_SetStreamingContext("cTableName", .CTABLE_NAME)
            End With

            loRtn = loServiceStream.GetColumnList()
            loStreaming = R_StreamUtility(Of CSM00700DbColumnsGridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00700DbColumnsGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " SUBs and FUNCTIONs "

    Private Sub ShiftScript(pcDir As String)
        Dim loEx As New R_Exception
        Dim loService As CSM00700ScriptsServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700ScriptsService, CSM00700ScriptsServiceClient)(e_ServiceClientType.RegularService, C_ScriptsServiceName)
        Dim loKey As CSM00700Front.CSM00700ScriptsServiceRef.CSM00700KeyDTO
        Dim lcRtn As String
        Dim lnRowIndex As Integer
        Dim lnDir As Integer
        Dim lnEdge As Integer

        Try
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor

            ' Process
            If bsGvScripts.Count > 0 Then
                loKey = New CSM00700Front.CSM00700ScriptsServiceRef.CSM00700KeyDTO
                With loKey
                    .CCOMPANY_ID = _CCOMPID
                    .CAPPS_CODE = _CAPPS_CODE
                    .CDATABASE_ID = _CDATABASE_ID
                    .CDB_CHANGE_ID = _CDB_CHANGE_ID
                    .CSCRIPT_ID = _CSCRIPT_ID
                    .CUPDOWN = pcDir
                    .CUSER_ID = _CUSERID
                End With
                lcRtn = loService.ShiftScript(loKey)
                If Not lcRtn.Equals("OK") Then
                    loEx.Add(lcRtn, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcRtn))
                    Exit Try
                End If
                Dim loTableKey As New CSM00700Front.CSM00700ServiceRef.CSM00700KeyDTO

                With loTableKey
                    .CCOMPANY_ID = _CCOMPID
                    .CAPPS_CODE = _CAPPS_CODE
                    .CDATABASE_ID = _CDATABASE_ID
                    .CDB_CHANGE_ID = _CDB_CHANGE_ID
                End With
                With gvScripts
                    If .CurrentRow IsNot Nothing Then
                        lnRowIndex = .CurrentRow.Index
                    End If
                    .R_RefreshGrid(loTableKey)
                    If .RowCount > 0 Then
                        lnDir = IIf(pcDir = "U", -1, 1)
                        lnEdge = IIf((lnRowIndex = 0 AndAlso pcDir = "U") Or (lnRowIndex = .RowCount - 1 AndAlso pcDir = "D"), 0, 1)
                        bsGvScripts.Position = lnRowIndex + (lnDir * lnEdge)
                    End If
                End With
            End If

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        End Try
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        If loEx.Haserror Then
            R_DisplayException(loEx)
        End If
    End Sub

    Private Sub RefreshGrids()
        Dim loTableKey As New CSM00700Front.CSM00700ServiceRef.CSM00700KeyDTO
        Dim loSvc As CSM00700ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700Service, CSM00700ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)

        With loTableKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = _CAPPS_CODE
            .CDATABASE_ID = _CDATABASE_ID
        End With

        gvChanges.R_RefreshGrid(loTableKey)
        gvTables.R_RefreshGrid(loTableKey)
    End Sub

    Public Sub ProcessSingleFile(pcFilePath As String)
        Dim loException As New R_Exception
        Dim loSourceByte As Byte()
        Dim loFileByte As RCustDBFileEntityDTO
        Dim loFileBytes As New List(Of RCustDBFileEntityDTO)
        Dim loSvc As R_ProcessAndUploadClient
        Dim loBatchPar As R_BatchParameter
        Dim lcKeyGuid As String
        Dim loTableKey As New CSM00700Front.CSM00700ServiceRef.CSM00700KeyDTO

        Try
            loSourceByte = R_Utility.GetByteFromFile(pcFilePath)
            'Kirim Data ke Big Object
            loFileByte = New RCustDBFileEntityDTO
            With loFileByte
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = _CAPPS_CODE
                .CPROJECT_ID = _CDATABASE_ID
                .CSESSION_ID = _CDB_CHANGE_ID
                .CITEM_ID = txtFilename.Text
                .CNOTE = txtDescription.Text
                .CFILE_NAME = txtFilename.Text
                .OFILE_BYTE = loSourceByte
                .CFUNCTION_ID = _CUSERID
            End With
            loFileBytes.Add(loFileByte)

            'Instantiate FrontHelper
            loSvc = New R_ProcessAndUploadClient(Nothing, Nothing, Nothing)
            AddHandler loSvc.ProcessError, AddressOf ProcessError

            'preapare Batch Parameter

            With loBatchPar
                .COMPANY_ID = _CCOMPID
                .USER_ID = _CUSERID
                .ClassName = "CSM00700Back.CSM00700DbChangesCls"
                .BigObject = loFileBytes
                .UserParameters = Nothing
            End With
            lcKeyGuid = loSvc.R_BatchProcess(loBatchPar, Nothing)

            With loTableKey
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = _CAPPS_CODE
                .CDATABASE_ID = _CDATABASE_ID
                .CDB_CHANGE_ID = _CDB_CHANGE_ID
            End With
            gvScripts.R_RefreshGrid(loTableKey)
            Catch ex As Exception
                loException.Add(ex)
        End Try

        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub ProcessError(pcKeyGuid As String, ex As R_Exception)
        Dim loException As New R_Exception

        If ex.Haserror Then
            loException.Add(ex)
        End If
        loException.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " BUTTONs "

    Private Sub btnUpload_Click(sender As Object, e As EventArgs) Handles btnUpload.Click
        Dim loException As New R_Exception
        Dim loService As CSM00700ScriptsServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700ScriptsService, CSM00700ScriptsServiceClient)(e_ServiceClientType.RegularService, C_ScriptsServiceName)
        Dim loValidationKey As New CSM00700ScriptsServiceRef.CSM00700KeyDTO
        Dim lcErr As String
        Dim loTableKey As New CSM00700Front.CSM00700ServiceRef.CSM00700KeyDTO

        Try
            ' Validate version first
            With loValidationKey
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = _CAPPS_CODE
                .CDATABASE_ID = _CDATABASE_ID
                .CDB_CHANGE_ID = _CDB_CHANGE_ID
            End With
            loService.UploadScriptValidation(loValidationKey)

            ' Check filename
            If _CFILE.Trim.Equals("") Then
                loException.Add("Err001", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "Err001").Trim)
                Exit Try
            ElseIf Len(_CFILE_NAME.Trim) > 50 Then
                loException.Add("Err002", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "Err002").Trim)
                Exit Try
            End If

            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
            ProcessSingleFile(_CFILE)
            Threading.Thread.Sleep(5000)
            With loTableKey
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = _CAPPS_CODE
                .CDATABASE_ID = _CDATABASE_ID
                .CDB_CHANGE_ID = _CDB_CHANGE_ID
            End With
            gvScripts.R_RefreshGrid(loTableKey)
        Catch ex As Exception
            With loException
                .Add(ex)
                lcErr = .ErrorList(0).ErrDescp
                If R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr) IsNot Nothing Then
                    .ErrorList.Clear()
                    .Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
                End If
            End With
        Finally
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            txtFilename.Text = ""
            _CFILE_NAME = ""
            _CFILE = ""
            txtDescription.Text = ""
        End Try
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        If loException.Haserror Then
            Me.R_DisplayException(loException)
        End If
    End Sub

    Private Sub ofdUpload_FileOk(sender As Object, e As CancelEventArgs) Handles ofdUpload.FileOk
        txtFilename.Text = ofdUpload.SafeFileName
        _CFILE_NAME = ofdUpload.SafeFileName
        _CFILE = ofdUpload.FileName
    End Sub

    Private Sub btnBrowse_Click(sender As Object, e As EventArgs) Handles btnBrowse.Click
        With ofdUpload
            .InitialDirectory = IO.Path.Combine(My.Application.Info.DirectoryPath, "Data")
            .ShowDialog()
        End With
    End Sub

    Private Sub btnCreateChanges_Click(sender As Object, e As EventArgs) Handles btnCreateChanges.Click
        Dim loRtn As String
        Dim loKey As New CSM00700ChangesDTO
        Dim loEx As New R_Exception
        Try

            Dim loSvc As CSM00700ChangesServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700ChangesService, CSM00700ChangesServiceClient)(e_ServiceClientType.RegularService, C_ChangesServiceName)
            loKey._CCOMPANY_ID = _CCOMPID
            loKey._CAPPS_CODE = _CAPPS_CODE
            loKey._CDATABASE_ID = _CDATABASE_ID
            loKey._CUPDATE_BY = _CUSERID
            loRtn = loSvc.CreateChanges(loKey)

            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If

    End Sub

    Private Sub btnRelease_Click(sender As Object, e As EventArgs) Handles btnRelease.Click
        Dim loEx As New R_Exception
        Dim loSvc As CSM00700ChangesServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00700ChangesService, CSM00700ChangesServiceClient)(e_ServiceClientType.RegularService, C_ChangesServiceName)
        Dim loKey As CSM00700Front.CSM00700ChangesServiceRef.CSM00700KeyDTO
        Dim lcRtn As String

        Try
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor

            ' Process
            If bsGvChanges.Count > 0 Then
                loKey = New CSM00700Front.CSM00700ChangesServiceRef.CSM00700KeyDTO
                With loKey
                    .CCOMPANY_ID = _CCOMPID
                    .CAPPS_CODE = _CAPPS_CODE
                    .CDATABASE_ID = _CDATABASE_ID
                    .CUSER_ID = _CUSERID
                End With
                lcRtn = loSvc.DumpFiles(loKey)
                If Not lcRtn.Equals("OK") Then
                    loEx.Add(lcRtn, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcRtn))
                    Exit Try
                End If
                RefreshGrids()
            End If

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        End Try
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        If loEx.Haserror Then
            R_DisplayException(loEx)
        End If
    End Sub

    Private Sub btnShiftUp_Click(sender As Object, e As EventArgs) Handles btnShiftUp.Click
        ShiftScript("U")
    End Sub

    Private Sub btnShiftDown_Click(sender As Object, e As EventArgs) Handles btnShiftDown.Click
        ShiftScript("D")
    End Sub

#End Region

End Class
