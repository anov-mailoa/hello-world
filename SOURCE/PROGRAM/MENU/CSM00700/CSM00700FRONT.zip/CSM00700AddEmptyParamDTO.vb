﻿Imports CSM00700Front.CSM00700ServiceRef

<Serializable()>
Public Class CSM00700AddEmptyParamDTO
    Public Property OFILTER_KEY As CSM00700KeyDTO
    Public Property CAPPS_NAME As String
    Public Property CDATABASE_NAME As String
    Public Property CDESCRIPTION As String

    Sub New()
        ' initialization
        OFILTER_KEY = New CSM00700KeyDTO
        With OFILTER_KEY
            .CCOMPANY_ID = ""
            .CAPPS_CODE = ""
            .CDATABASE_ID = ""
            .CUSER_ID = ""
        End With
        CAPPS_NAME = ""
        CDATABASE_NAME = ""
        CDESCRIPTION = ""
    End Sub
End Class
