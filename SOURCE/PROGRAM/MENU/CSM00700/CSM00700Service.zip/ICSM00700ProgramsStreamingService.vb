﻿Imports System.ServiceModel
Imports System.ServiceModel.Channels
Imports CSM00700Back
Imports R_Common

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00700ProgramsStreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00700ProgramsStreamingService

    <OperationContract(Action:="getDbProgramsList", ReplyAction:="getDbProgramsList")>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function GetDbProgramsList() As Message

    <OperationContract(Action:="getDbProgramSourceList", ReplyAction:="getDbProgramSourceList")>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function GetDbProgramSourceList() As Message

    <OperationContract(Action:="getSourceGroupList", ReplyAction:="getSourceGroupList")>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function GetSourceGroupList() As Message

    <OperationContract()>
    <FaultContract(GetType(R_ServiceExceptions))>
    Sub Dummy(ByVal poPar1 As List(Of CSM00700DbProgramsGridDTO),
              ByVal poPar2 As List(Of CSM00700DbProgramSourcesGridDTO),
              ByVal poPar3 As List(Of CSM00700SourceGroupListDTO),
              ByVal poPar4 As CSM00700KeyDTO)

End Interface
