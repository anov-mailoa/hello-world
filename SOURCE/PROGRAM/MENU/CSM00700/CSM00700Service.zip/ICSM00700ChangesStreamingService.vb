﻿Imports System.ServiceModel
Imports System.ServiceModel.Channels
Imports CSM00700Back
Imports R_Common

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00700ChangesStreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00700ChangesStreamingService

    <OperationContract(Action:="getChangesList", ReplyAction:="getChangesList")>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function GetChangesList() As Message

    <OperationContract(Action:="getScriptList", ReplyAction:="getScriptList")>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function GetScriptList() As Message

    <OperationContract()>
    <FaultContract(GetType(R_ServiceExceptions))>
    Sub Dummy(ByVal poPar1 As List(Of CSM00700ChangesGridDTO),
              ByVal poPar2 As List(Of CSM00700ScriptsGridDTO),
              ByVal poPar3 As CSM00700ScriptFileDTO)

End Interface
