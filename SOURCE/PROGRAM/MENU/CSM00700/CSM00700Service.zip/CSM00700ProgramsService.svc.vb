﻿' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00700ProgramsService" in code, svc and config file together.
' NOTE: In order to launch WCF Test Client for testing this service, please select CSM00700ProgramsService.svc or CSM00700ProgramsService.svc.vb at the Solution Explorer and start debugging.
Imports CSM00700Back
Imports R_BackEnd
Imports R_Common
Imports RLicenseBack
Imports RLicenseService

Public Class CSM00700ProgramsService
    Implements ICSM00700ProgramsService

    Public Sub Svc_R_Delete(poEntity As CSM00700DbProgramsDTO) Implements R_IServicebase(Of CSM00700DbProgramsDTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New CSM00700DbProgramsCls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As CSM00700DbProgramsDTO) As CSM00700DbProgramsDTO Implements R_IServicebase(Of CSM00700DbProgramsDTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New CSM00700DbProgramsCls
        Dim loRtn As CSM00700DbProgramsDTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As CSM00700DbProgramsDTO, poCRUDMode As eCRUDMode) As CSM00700DbProgramsDTO Implements R_IServicebase(Of CSM00700DbProgramsDTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New CSM00700DbProgramsCls
        Dim loRtn As CSM00700DbProgramsDTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetAttributeCombo(companyId As String, appsCode As String, attributeGroup As String) As List(Of RCustDBAttributeComboDTO) Implements ICSM00700ProgramsService.GetAttributeCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBAttributeComboDTO)

        Try
            loRtn = loCls.GetAttributeCombo(companyId, appsCode, attributeGroup)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetAttributeGroupCombo(companyId As String, appsCode As String) As List(Of RCustDBAttributeGroupComboDTO) Implements ICSM00700ProgramsService.GetAttributeGroupCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBAttributeGroupComboDTO)

        Try
            loRtn = loCls.GetAttributeGroupCombo(companyId, appsCode)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

End Class
