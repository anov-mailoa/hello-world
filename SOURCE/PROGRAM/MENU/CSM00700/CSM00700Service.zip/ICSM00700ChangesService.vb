﻿Imports System.ServiceModel
Imports CSM00700Back
Imports R_BackEnd
Imports R_Common

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00700ChangesService" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00700ChangesService
    Inherits R_IServicebase(Of CSM00700ChangesDTO)

    <OperationContract(Action:="createChanges", ReplyAction:="createChanges")>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function CreateChanges(ByVal poKey As CSM00700ChangesDTO) As String

    <OperationContract(Action:="dumpFiles", ReplyAction:="dumpFiles")>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function DumpFiles(ByVal poProcessParam As CSM00700KeyDTO) As String

End Interface
