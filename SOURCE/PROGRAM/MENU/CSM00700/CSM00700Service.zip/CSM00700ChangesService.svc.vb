﻿' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00700ChangesService" in code, svc and config file together.
' NOTE: In order to launch WCF Test Client for testing this service, please select CSM00700ChangesService.svc or CSM00700ChangesService.svc.vb at the Solution Explorer and start debugging.
Imports CSM00700Back
Imports R_BackEnd
Imports R_Common
Imports RLicenseService

Public Class CSM00700ChangesService
    Implements ICSM00700ChangesService

    Public Sub Svc_R_Delete(poEntity As CSM00700ChangesDTO) Implements R_IServicebase(Of CSM00700ChangesDTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New CSM00700ChangesCls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As CSM00700ChangesDTO) As CSM00700ChangesDTO Implements R_IServicebase(Of CSM00700ChangesDTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New CSM00700ChangesCls
        Dim loRtn As CSM00700ChangesDTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As CSM00700ChangesDTO, poCRUDMode As eCRUDMode) As CSM00700ChangesDTO Implements R_IServicebase(Of CSM00700ChangesDTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New CSM00700ChangesCls
        Dim loRtn As CSM00700ChangesDTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function CreateChanges(poKey As CSM00700ChangesDTO) As String Implements ICSM00700ChangesService.CreateChanges
        Dim loEx As New R_Exception
        Dim loCls As New CSM00700ChangesCls
        Dim lcRtn As String

        Try
            lcRtn = loCls.CreateChanges(poKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
        Return lcRtn
    End Function

    Public Function DumpFiles(poProcessParam As CSM00700KeyDTO) As String Implements ICSM00700ChangesService.DumpFiles
        Dim loEx As New R_Exception
        Dim loCls As New CSM00700DbChangesCls
        Dim lcRtn As String

        Try
            lcRtn = loCls.DumpFiles(poProcessParam)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
        Return lcRtn
    End Function
End Class
