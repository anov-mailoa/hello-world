﻿Imports System.ServiceModel
Imports CSM00700Back
Imports R_BackEnd
Imports R_Common

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00700ScriptsService" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00700ScriptsService
    Inherits R_IServicebase(Of CSM00700ScriptsDTO)

    <OperationContract(Action:="uploadValidScript", ReplyAction:="uploadValidScript")>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function UploadScriptValidation(ByVal poKey As CSM00700KeyDTO) As String

    <OperationContract(Action:="shiftScript", ReplyAction:="shiftScript")>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function ShiftScript(ByVal poKey As CSM00700KeyDTO) As String

End Interface
