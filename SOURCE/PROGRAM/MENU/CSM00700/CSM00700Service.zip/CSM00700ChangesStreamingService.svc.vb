﻿' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00700ChangesStreamingService" in code, svc and config file together.
' NOTE: In order to launch WCF Test Client for testing this service, please select CSM00700ChangesStreamingService.svc or CSM00700ChangesStreamingService.svc.vb at the Solution Explorer and start debugging.
Imports System.ServiceModel.Channels
Imports CSM00700Back
Imports R_Common
Imports RLicenseService

Public Class CSM00700ChangesStreamingService
    Implements ICSM00700ChangesStreamingService

    Public Sub Dummy(poPar1 As List(Of CSM00700ChangesGridDTO), poPar2 As List(Of CSM00700ScriptsGridDTO), poPar3 As CSM00700ScriptFileDTO) Implements ICSM00700ChangesStreamingService.Dummy
        Throw New NotImplementedException()
    End Sub

    Public Function GetChangesList() As Message Implements ICSM00700ChangesStreamingService.GetChangesList
        Dim loException As New R_Exception
        Dim loCls As New CSM00700DbChangesCls
        Dim loRtnTemp As List(Of CSM00700ChangesGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00700KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CDATABASE_ID = R_Utility.R_GetStreamingContext("cDatabaseID")
            End With

            loRtnTemp = loCls.GetChangesList(loTableKey)

            loRtn = R_StreamUtility(Of CSM00700ChangesGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getChangesList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetScriptList() As Message Implements ICSM00700ChangesStreamingService.GetScriptList
        Dim loException As New R_Exception
        Dim loCls As New CSM00700DbChangesCls
        Dim loRtnTemp As List(Of CSM00700ScriptsGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00700KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CDATABASE_ID = R_Utility.R_GetStreamingContext("cDatabaseID")
                .CDB_CHANGE_ID = R_Utility.R_GetStreamingContext("cDBChangeID")
            End With

            loRtnTemp = loCls.GetScriptList(loTableKey)

            loRtn = R_StreamUtility(Of CSM00700ScriptsGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getScriptList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
