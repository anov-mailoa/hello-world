﻿<Serializable()> _
Public Class BatchCompanyDTO
    Public Property CCOMPANY_ID As String
    Public Property CCOMPANY_NAME As String
    Public Property LTIME_LIMITATION As Boolean
    Public Property CSTART_DATE As String
    Public Property CEND_DATE As String
    Public Property IUSER_LEVEL As Integer
End Class
