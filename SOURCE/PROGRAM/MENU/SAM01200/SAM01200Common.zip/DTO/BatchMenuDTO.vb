﻿<Serializable()> _
Public Class BatchMenuDTO
    Public Property CMENU_ID As String
    Public Property CMENU_NAME As String
End Class
