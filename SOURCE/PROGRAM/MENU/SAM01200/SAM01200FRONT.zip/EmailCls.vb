﻿Imports R_Common
Imports R_FrontEnd

Public Structure EmailParam
    Public cSubject As String
    Public cBody As String
    Public cEmailFrom As String
End Structure

Public Structure EmailProp
    'Const cEmailFrom As String = "invoice.sg@accor.com"
    Const cEmailCC As String = ""
    Const cEmailBCC As String = ""
    Const cEmailSubjectNew As String = "Your Password Details"
    Const cEmailSubjectReset As String = "Reset Password"
    Const cEmailSubjectDeleted As String = "Your account has been deleted"
    Const cNewUserBody As String = "<P>Hello {0},</P>  <P>&nbsp;</P>  <P>You have just registered an account successfully. Here is your account information :</P>  <P>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <STRONG>Username : {1}</STRONG></P>  <P>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG> Password : {2}</STRONG></P>  <P>Please login and&nbsp;change your password on my profile page.</P>  <P>Thank you</P>"
    Const cResetUserBody As String = "<P>Hello {0},</P>  <P>&nbsp;</P>  <P>You have just reset an account successfully. Here is your account information :</P>  <P>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <STRONG>Username : {1}</STRONG></P>  <P>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG> Password : {2}</STRONG></P>  <P>Please login and&nbsp;change your password on my profile page.</P>  <P>Thank you</P>"
    Const cDeleteUserBody As String = "<P>Hello {0},</P>  <P>&nbsp;</P>  <P>Your account has been deleted on system. Please contact your company system administrator.</P>  <P>&nbsp;</P>  <P>Thank you</P>  <P>&nbsp;</P> "
    Const cNewUserCompBody As String = "<P>Hello {0},</P>  <P>&nbsp;</P>  <P>You have just registered an account successfully. Here is your account information :</P>  <P>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <STRONG>Company ID : {2}</STRONG></P>  <P><STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Username : {0}</STRONG></P>  <P><STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Password : {1}</STRONG></P>  <P>Please login and&nbsp;change your password on my profile page.</P>  <P>Thank you</P>"
    Const cDeleteUserCompBody As String = "<P>Hello {0},</P>  <P>&nbsp;</P>  <P>Your account has been deleted on {1}&nbsp;company. Please contact your company system administrator.</P>  <P>&nbsp;</P>  <P>Thank you</P>  <P>&nbsp;</P> "
    Const cResetCompBody As String = "<P>Hello {0},</P>  <P>&nbsp;</P>  <P>You have just reset an account successfully. Here is your account information :</P>  <P>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <STRONG>Company ID : {2}</STRONG></P>  <P><STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Username : {0}</STRONG></P>  <P><STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Password : {1}</STRONG></P>  <P>Please login and&nbsp;change your password on my profile page.</P>  <P>Thank you</P>"
End Structure

Public Class EmailCls
    Public Function sendEmail(poParam As Object, poEmailPar As EmailParam, pcCompId As String, pcUserId As String) As String
        Dim loEmailPar As R_EmailEngineFrontPar
        Dim loEmailMsg As New R_EmailEngineMessage
        Dim loSvc As New R_EmailEngineClient
        Dim oEmbed As New List(Of R_EmailEngineFrontFile)
        Dim lcEmailId As String

        With loEmailMsg
            .EMAIL_FROM = poEmailPar.cEmailFrom
            .EMAIL_TO = poParam._CEMAIL_ADDRESS
            .EMAIL_CC = EmailProp.cEmailCC
            .EMAIL_SUBJECT = poEmailPar.cSubject
            .EMAIL_BODY = poEmailPar.cBody
            .EMAIL_BCC = EmailProp.cEmailBCC
            .FLAG_HTML = True
        End With

        'oEmbed.Add(New R_EmailEngineFrontFile() With {.FilePath = My.Application.Info.DirectoryPath & "\Image\logo_Realta.jpg",
        '                                              .FileId = "img1.jpg",
        '                                              .FileName = "img1.jpg",
        '                                              .FileExtension = IO.Path.GetExtension(My.Application.Info.DirectoryPath & "\Image\logo_Realta.jpg")})

        loEmailPar = New R_EmailEngineFrontPar With {.COMPANY_ID = pcCompId,
                                                     .PROGRAM_ID = "SAM01200",
                                                     .USER_ID = pcUserId,
                                                     .Message = loEmailMsg,
                                                     .Embeddeds = oEmbed}

        lcEmailId = loSvc.R_SaveEmail(loEmailPar)

        Return lcEmailId
    End Function
End Class
