﻿Public Class CultureDTO
    Public Property CCODE As String
    Public Property CDESC As String
End Class
