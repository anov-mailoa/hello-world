﻿Imports R_FrontEnd
Imports R_Common
Imports SAM01200Front.UserCompanyServiceRef
Imports SAM01200Front.SAM01200ServiceRef
Imports SAM01200Front.SAM01200StreamingServiceRef
Imports SAM01200Front.UserMenuServiceRef
Imports System.ServiceModel.Channels
Imports System.Globalization
Imports ClientHelper
Imports SAM01200FrontResources
Imports System.Text.RegularExpressions
Imports Telerik.WinControls.UI

Public Class CompanyMenu
#Region " VARIABLE "
    Dim C_ServiceName As String = "SAM01200Service/SAM01200Service.svc"
    Dim C_ServiceNameStream As String = "SAM01200Service/SAM01200StreamingService/SAM01200StreamingService.svc"
    Dim C_ServiceNameCompany As String = "SAM01200Service/UserCompanyService/UserCompanyService.svc"
    Dim C_ServiceNameMenu As String = "SAM01200Service/UserMenuService/UserMenuService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _oParentData As New SAM01200UserDTO
#End Region

#Region " INIT "
    Private Sub CompanyMenu_R_Init_From_Master(poParameter As Object) Handles MyBase.R_Init_From_Master
        Dim loService As SAM01200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01200Service, SAM01200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception()

        Try
            If U_GlobalVar.SecurityParameter.cSecurityAndAccountPolicy = "byuser" Then
                btnResetPass.Enabled = False
            End If

            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            _oParentData = poParameter

            txtUserId.Text = _oParentData._CUSER_ID
            txtUserName.Text = _oParentData._CUSER_NAME

            gvUserCompany.R_RefreshGrid(CType(poParameter, SAM01200UserDTO)._CUSER_ID)
            bsCmbCompany.DataSource = loService.getCmbCompany()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
#End Region

#Region "GRIDVIEW USER COMPANY"
    Private Sub gvUserCompany_R_CheckDelete(poEntity As Object, ByRef plAllowDelete As Boolean) Handles gvUserCompany.R_CheckDelete
        If CType(poEntity, UserCompanyDTO)._CCOMPANY_ID = _CCOMPID And _oParentData._CUSER_ID.ToLower = "admin" Then
            plAllowDelete = False
        End If
    End Sub

    Private Sub gvUserCompany_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvUserCompany.R_ServiceGetListRecord
        Dim loServiceStream As SAM01200StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01200StreamingService, SAM01200StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loEx As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of UserCompanyDTOnon)
        Dim loListEntity As New List(Of UserCompanyDTO)

        Try
            R_Utility.R_SetStreamingContext("cUserId", poEntity)

            loRtn = loServiceStream.getUserCompanyList()
            loStreaming = R_StreamUtility(Of UserCompanyDTOnon).ReadFromMessage(loRtn)

            For Each loDto As UserCompanyDTOnon In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New UserCompanyDTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                              ._CCOMPANY_NAME = loDto.CCOMPANY_NAME,
                                                              ._LTIME_LIMITATION = loDto.LTIME_LIMITATION,
                                                              ._CSTART_DATE = loDto.CSTART_DATE,
                                                              ._CEND_DATE = loDto.CEND_DATE,
                                                              ._IUSER_LEVEL = loDto.IUSER_LEVEL,
                                                              ._CCREATE_BY = loDto.CCREATE_BY,
                                                              ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                              ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                              ._DUPDATE_DATE = loDto.DUPDATE_DATE,
                                                              ._DSTART_DATE = getDate(loDto.CSTART_DATE),
                                                              ._DEND_DATE = getDate(loDto.CEND_DATE),
                                                              ._LENABLE_BROADCAST = loDto.LENABLE_BROADCAST})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvUserCompany_R_AfterAdd(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection) Handles gvUserCompany.R_AfterAdd
        poGridCellCollection(4).Value = Date.Now
        poGridCellCollection(5).Value = Date.Now
        poGridCellCollection(9).Value = _CUSERID
        poGridCellCollection(10).Value = DateTime.Now
    End Sub

    Private Sub gvUserCompany_CellValueChanged(sender As Object, e As Telerik.WinControls.UI.GridViewCellEventArgs) Handles gvUserCompany.CellValueChanged
        Dim cSender As String = sender.ColumnInfo.Name

        If cSender = "_CCOMPANY_ID" Then
            sender.GridViewElement.CurrentRow.Cells("_CCOMPANY_NAME").Value = CType(bsCmbCompany.Current, cmbDTO)._CDESC
        End If
    End Sub

    Private Sub gvUserCompany_R_AfterDelete() Handles gvUserCompany.R_AfterDelete
        'cek jika grid kedua kosong, maka data di grid ketiga dikosongkan juga
        If CType(gvUserCompany.DataSource, Windows.Forms.BindingSource).Count = 0 Then
            CType(gvUserMenu.DataSource, Windows.Forms.BindingSource).DataSource = Nothing
            gvUserMenu.Enabled = False
        Else
            gvUserMenu.Enabled = True
        End If
    End Sub

    Private Sub gvUserCompany_R_AfterSave(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvUserCompany.R_AfterSave
        'cek jika grid kedua kosong, maka data di grid ketiga dikosongkan juga
        If CType(gvUserCompany.DataSource, Windows.Forms.BindingSource).Count = 0 Then
            CType(gvUserMenu.DataSource, Windows.Forms.BindingSource).DataSource = Nothing
            gvUserMenu.Enabled = False
        Else
            gvUserMenu.Enabled = True
        End If
    End Sub

    Private Sub gvUserCompany_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvUserCompany.R_Display
        Dim loService As SAM01200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01200Service, SAM01200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            bsCmbMenu.DataSource = loService.getCmbMenu(CType(poEntity, UserCompanyDTO)._CCOMPANY_ID)
            loService.Close()

            gvUserMenu.R_RefreshGrid(CType(poEntity, UserCompanyDTO)._CCOMPANY_ID)

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvUserCompany_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvUserCompany.R_Saving
        With CType(poEntity, UserCompanyDTO)
            ._CUSER_LOGIN = _CUSERID
            ._DDATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            ._CUSER_ID = _oParentData._CUSER_ID
            ._CSTART_DATE = CDate(._DSTART_DATE).ToString("yyyyMMdd")
            ._CEND_DATE = CDate(._DEND_DATE).ToString("yyyyMMdd")
        End With
    End Sub

    Private Sub gvUserCompany_R_ServiceDelete(poEntity As Object) Handles gvUserCompany.R_ServiceDelete
        Dim loService As UserCompanyServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IUserCompanyService, UserCompanyServiceClient)(e_ServiceClientType.RegularService, C_ServiceNameCompany)
        Dim loServiceSMTP As SAM01200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01200Service, SAM01200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcEmailId As String
        Dim oEmailCls As New EmailCls
        Dim lcSMTP As String

        Try
            lcSMTP = loServiceSMTP.getSMTP(_CCOMPID)

            Dim oEmailPar As EmailParam
            With oEmailPar
                .cSubject = EmailProp.cEmailSubjectDeleted
                .cBody = String.Format(EmailProp.cDeleteUserCompBody, _oParentData._CUSER_ID, poEntity._CCOMPANY_ID)
                .cEmailFrom = lcSMTP
            End With
            lcEmailId = oEmailCls.sendEmail(_oParentData, oEmailPar, _CCOMPID, _CUSERID)

            loService.Svc_R_Delete(New UserCompanyDTO With {._CCOMPANY_ID = CType(bsGvCompany.Current, UserCompanyDTO)._CCOMPANY_ID,
                                                            ._CUSER_ID = _oParentData._CUSER_ID,
                                                            ._CEMAIL_ID = lcEmailId})

            loService.Close()
            loServiceSMTP.Close()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvUserCompany_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvUserCompany.R_ServiceGetRecord
        Dim loService As UserCompanyServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IUserCompanyService, UserCompanyServiceClient)(e_ServiceClientType.RegularService, C_ServiceNameCompany)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New UserCompanyDTO With {._CCOMPANY_ID = CType(poEntity, UserCompanyDTO)._CCOMPANY_ID,
                                                                                ._CUSER_ID = _oParentData._CUSER_ID})

            With CType(poEntityResult, UserCompanyDTO)
                ._DSTART_DATE = getDate(._CSTART_DATE)
                ._DEND_DATE = getDate(._CEND_DATE)
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvUserCompany_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvUserCompany.R_ServiceSave
        Dim loService As UserCompanyServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IUserCompanyService, UserCompanyServiceClient)(e_ServiceClientType.RegularService, C_ServiceNameCompany)
        Dim loServiceSMTP As SAM01200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01200Service, SAM01200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcEmailId As String
        Dim cParamValues As String
        Dim oEmailCls As New EmailCls
        Dim lcSMTP As String

        Try
            lcSMTP = loServiceSMTP.getSMTP(_CCOMPID)

            If peGridMode = R_eGridMode.Add Then
                Dim oEmailPar As EmailParam
                With oEmailPar
                    .cSubject = EmailProp.cEmailSubjectNew
                    .cBody = String.Format(EmailProp.cNewUserCompBody, _oParentData._CUSER_ID, "{1}", poEntity._CCOMPANY_ID)
                    .cEmailFrom = lcSMTP
                End With

                cParamValues = U_GlobalVar.SecurityParameter.cSecurityAndAccountPolicy

                If cParamValues = "bycompany" Then
                    lcEmailId = oEmailCls.sendEmail(_oParentData, oEmailPar, _CCOMPID, _CUSERID)

                    If String.IsNullOrEmpty(lcEmailId) = False Then
                        CType(poEntity, UserCompanyDTO)._CEMAIL_ID = lcEmailId
                    End If
                End If
            End If

            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvUserCompany_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvUserCompany.R_Validation
        Dim loEx As New R_Exception()

        Try
            pcError = ""
            With poGridCellCollection
                If String.IsNullOrWhiteSpace(.Item(0).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS004")
                    loEx.Add("PS004", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS004"))
                    plCancel = True
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
#End Region

#Region "GRIDVIEW USER MENU"
    Private Sub gvUserMenu_R_CheckDelete(poEntity As Object, ByRef plAllowDelete As Boolean) Handles gvUserMenu.R_CheckDelete
        If CType(poEntity, UserMenuDTO)._CMENU_ID = "MA" And _CUSERID.ToLower = "admin" Then
            plAllowDelete = False
        End If
    End Sub

    Private Sub gvUserMenu_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvUserMenu.R_ServiceGetListRecord
        Dim loServiceStream As SAM01200StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01200StreamingService, SAM01200StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loEx As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of UserMenuDTOnon)
        Dim loListEntity As New List(Of UserMenuDTO)

        Try
            R_Utility.R_SetStreamingContext("cCompanyId", poEntity)
            R_Utility.R_SetStreamingContext("cUserId", _oParentData._CUSER_ID)

            loRtn = loServiceStream.getUserMenuList()
            loStreaming = R_StreamUtility(Of UserMenuDTOnon).ReadFromMessage(loRtn)

            For Each loDto As UserMenuDTOnon In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New UserMenuDTO With {._CMENU_ID = loDto.CMENU_ID,
                                                            ._CMENU_NAME = loDto.CMENU_NAME,
                                                            ._CCREATE_BY = loDto.CCREATE_BY,
                                                            ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                            ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                            ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvUserMenu_R_AfterAdd(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection) Handles gvUserMenu.R_AfterAdd
        poGridCellCollection(4).Value = _CUSERID
        poGridCellCollection(5).Value = DateTime.Now
    End Sub

    Private Sub gvUserMenu_CellValueChanged(sender As Object, e As Telerik.WinControls.UI.GridViewCellEventArgs) Handles gvUserMenu.CellValueChanged
        Dim cSender As String = sender.ColumnInfo.Name

        If cSender = "_CMENU_ID" Then
            sender.GridViewElement.CurrentRow.Cells("_CMENU_NAME").Value = CType(bsCmbMenu.Current, cmbDTO)._CDESC
        End If
    End Sub

    Private Sub gvUserMenu_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvUserMenu.R_Saving
        With CType(poEntity, UserMenuDTO)
            ._DDATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            ._CUSER_ID = _oParentData._CUSER_ID
            ._CCOMPANY_ID = CType(bsGvCompany.Current, UserCompanyDTO)._CCOMPANY_ID
        End With
    End Sub

    Private Sub gvUserMenu_R_ServiceDelete(poEntity As Object) Handles gvUserMenu.R_ServiceDelete
        Dim loService As UserMenuServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IUserMenuService, UserMenuServiceClient)(e_ServiceClientType.RegularService, C_ServiceNameMenu)
        Dim loEx As New R_Exception

        Try
            loService.Svc_R_Delete(New UserMenuDTO With {._CCOMPANY_ID = CType(bsGvCompany.Current, UserCompanyDTO)._CCOMPANY_ID,
                                                         ._CUSER_ID = _oParentData._CUSER_ID,
                                                         ._CMENU_ID = CType(poEntity, UserMenuDTO)._CMENU_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvUserMenu_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvUserMenu.R_ServiceGetRecord
        Dim loService As UserMenuServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IUserMenuService, UserMenuServiceClient)(e_ServiceClientType.RegularService, C_ServiceNameMenu)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New UserMenuDTO With {._CCOMPANY_ID = CType(bsGvCompany.Current, UserCompanyDTO)._CCOMPANY_ID,
                                                                             ._CUSER_ID = _oParentData._CUSER_ID,
                                                                             ._CMENU_ID = CType(poEntity, UserMenuDTO)._CMENU_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvUserMenu_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvUserMenu.R_ServiceSave
        Dim loService As UserMenuServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IUserMenuService, UserMenuServiceClient)(e_ServiceClientType.RegularService, C_ServiceNameMenu)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvUserMenu_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvUserMenu.R_Validation
        Dim loEx As New R_Exception()

        Try
            pcError = ""
            With poGridCellCollection
                If String.IsNullOrWhiteSpace(.Item(0).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS005")
                    loEx.Add("PS005", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS005"))
                    plCancel = True
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
#End Region

    Private Sub SAM0300_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles MyBase.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

    Private Function getDate(pcDate As String) As Nullable(Of Date)
        If String.IsNullOrEmpty(pcDate) Then
            Return Nothing
        Else
            Return DateTime.ParseExact(pcDate, "yyyyMMdd", CultureInfo.CurrentCulture)
        End If
    End Function

#Region "POPUP COPY COMPANY"
    Private Sub btnPopupCopyCompany_R_After_Open_Form(poPopUpResult As System.Windows.Forms.DialogResult, poPopUpEntityResult As Object)
        Dim loEx As New R_Exception
        Dim loBatchPar As R_BatchParameter
        Dim loSvc As R_ProcessAndUploadClient
        Dim loBigObject As List(Of SAM01200Common.BatchCopyCompanyDTO)
        Dim lcKeyGuid As String
        Dim loUserPar As R_KeyValue
        Dim loUserParameters As New List(Of R_KeyValue)

        Try
            If poPopUpResult = Windows.Forms.DialogResult.OK Then
                If poPopUpEntityResult.Count = 0 Then
                    loEx.Add("", "Please choose company!")
                    Exit Try
                End If

                With loUserPar
                    .Key = "LINCLUDE_MENU"
                    .Value = CType(poPopUpEntityResult, List(Of CompanyCopyDTO)).Select(Function(x) x.LINCLUDE_MENU).FirstOrDefault
                End With
                loUserParameters.Add(loUserPar)

                With loUserPar
                    .Key = "CUSER_ID_FROM"
                    .Value = CType(poPopUpEntityResult, List(Of CompanyCopyDTO)).Select(Function(x) x.CUSER_ID_FROM).FirstOrDefault.ToString
                End With
                loUserParameters.Add(loUserPar)

                With loUserPar
                    .Key = "CUSER_ID"
                    .Value = _oParentData._CUSER_ID
                End With
                loUserParameters.Add(loUserPar)

                With loUserPar
                    .Key = "DDATE"
                    .Value = DateTime.Now
                End With
                loUserParameters.Add(loUserPar)

                'Instantiate FrontHelper
                loSvc = New R_ProcessAndUploadClient(bwCompanyMenu, Nothing, Nothing)
                AddHandler loSvc.ProcessError, AddressOf ProcessError
                AddHandler loSvc.ProcessComplete, AddressOf ProcessComplete

                loBigObject = CType(poPopUpEntityResult, List(Of CompanyCopyDTO)) _
                .Select(Function(x) New SAM01200Common.BatchCopyCompanyDTO() _
                        With {.CCOMPANY_ID = x.CCOMPANY_ID,
                              .CCOMPANY_NAME = x.CCOMPANY_NAME,
                              .LTIME_LIMITATION = x.LTIME_LIMITATION,
                              .CCULTURE_ID = x.CCULTURE_ID,
                              .CCULTURE_FORMAT = x.CCULTURE_FORMAT,
                              .CSTART_DATE = x.CSTART_DATE,
                              .CEND_DATE = x.CEND_DATE,
                              .IUSER_LEVEL = x.IUSER_LEVEL}).ToList()

                If loBigObject.Count = 0 Then
                    Exit Try
                End If

                With loBatchPar
                    .COMPANY_ID = _CCOMPID
                    .USER_ID = _CUSERID
                    .ClassName = "SAM01200Back.CopyCompanyCls"
                    .BigObject = loBigObject
                    .UserParameters = loUserParameters
                End With
                lcKeyGuid = loSvc.R_BatchProcess(loBatchPar, poPopUpEntityResult.Count)
            End If
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If
    End Sub

    Private Sub btnPopupCopyCompany_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object)
        poTargetForm = New CopyCompanies

        poParameter = New SAM01200UserDTO With {._CUSER_ID = _oParentData._CUSER_ID,
                                               ._CUSER_NAME = _oParentData._CUSER_NAME}
    End Sub
#End Region

#Region "POPUP USER COMPANY"
    Private Sub btnPopupUserCompany_R_After_Open_Form(poPopUpResult As System.Windows.Forms.DialogResult, poPopUpEntityResult As Object)
        Dim loEx As New R_Exception
        Dim loBatchPar As R_BatchParameter
        Dim loSvc As R_ProcessAndUploadClient
        Dim loBigObject As List(Of SAM01200Common.BatchCompanyDTO)
        Dim lcKeyGuid As String
        Dim loUserPar As R_KeyValue
        Dim loUserParameters As New List(Of R_KeyValue)

        Try
            If poPopUpResult = Windows.Forms.DialogResult.OK Then
                If poPopUpEntityResult.Count = 0 Then
                    loEx.Add("", "Please choose company!")
                    Exit Try
                End If

                With loUserPar
                    .Key = "CUSER_ID"
                    .Value = _oParentData._CUSER_ID
                End With
                loUserParameters.Add(loUserPar)

                With loUserPar
                    .Key = "DDATE"
                    .Value = DateTime.Now
                End With
                loUserParameters.Add(loUserPar)

                'Instantiate FrontHelper
                loSvc = New R_ProcessAndUploadClient(bwCompanyMenu, Nothing, Nothing)
                AddHandler loSvc.ProcessError, AddressOf ProcessError
                AddHandler loSvc.ProcessComplete, AddressOf ProcessComplete

                loBigObject = CType(poPopUpEntityResult, List(Of UserCompanyDTO)) _
                .Select(Function(x) New SAM01200Common.BatchCompanyDTO() _
                        With {.CCOMPANY_ID = x._CCOMPANY_ID,
                              .CCOMPANY_NAME = x._CCOMPANY_NAME,
                              .CSTART_DATE = x._CSTART_DATE,
                              .CEND_DATE = x._CEND_DATE,
                              .IUSER_LEVEL = x._IUSER_LEVEL,
                              .LTIME_LIMITATION = x._LTIME_LIMITATION}).ToList()

                If loBigObject.Count = 0 Then
                    Exit Try
                End If

                With loBatchPar
                    .COMPANY_ID = _CCOMPID
                    .USER_ID = _CUSERID
                    .ClassName = "SAM01200Back.UserCompanyCls"
                    .BigObject = loBigObject
                    .UserParameters = loUserParameters
                End With
                lcKeyGuid = loSvc.R_BatchProcess(loBatchPar, poPopUpEntityResult.Count)
            End If
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If
    End Sub

    Private Sub btnPopupUserCompany_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object)
        poTargetForm = New MultipleCompanies

        poParameter = R_Utility.Clone(_oParentData)
    End Sub
#End Region

#Region "POPUP COPY MENU"
    Private Sub btnPopupCopyMenu_R_After_Open_Form(poPopUpResult As System.Windows.Forms.DialogResult, poPopUpEntityResult As Object) Handles btnPopupCopyMenu.R_After_Open_Form
        Dim loEx As New R_Exception
        Dim loBatchPar As R_BatchParameter
        Dim loSvc As R_ProcessAndUploadClient
        Dim loBigObject As List(Of SAM01200Common.BatchMenuDTO)
        Dim lcKeyGuid As String
        Dim loUserPar As R_KeyValue
        Dim loUserParameters As New List(Of R_KeyValue)

        Try
            If poPopUpResult = Windows.Forms.DialogResult.OK Then
                If poPopUpEntityResult.Count = 0 Then
                    loEx.Add("", "Please choose company!")
                    Exit Try
                End If

                With loUserPar
                    .Key = "CCOMPANY_ID_FROM"
                    .Value = CType(poPopUpEntityResult, List(Of UserMenuDTO)).Select(Function(x) x._CCOMPANY_ID_FROM).FirstOrDefault
                End With
                loUserParameters.Add(loUserPar)

                With loUserPar
                    .Key = "CCOMPANY_ID"
                    .Value = CType(bsGvCompany.Current, UserCompanyDTO)._CCOMPANY_ID
                End With
                loUserParameters.Add(loUserPar)

                With loUserPar
                    .Key = "CUSER_ID"
                    .Value = _oParentData._CUSER_ID
                End With
                loUserParameters.Add(loUserPar)

                With loUserPar
                    .Key = "DDATE"
                    .Value = DateTime.Now
                End With
                loUserParameters.Add(loUserPar)

                'Instantiate FrontHelper
                loSvc = New R_ProcessAndUploadClient(bwCompanyMenu, Nothing, Nothing)
                AddHandler loSvc.ProcessError, AddressOf ProcessError
                AddHandler loSvc.ProcessComplete, AddressOf ProcessComplete

                loBigObject = CType(poPopUpEntityResult, List(Of UserMenuDTO)) _
                .Select(Function(x) New SAM01200Common.BatchMenuDTO() _
                        With {.CMENU_ID = x._CMENU_ID,
                              .CMENU_NAME = x._CMENU_NAME}).ToList()

                If loBigObject.Count = 0 Then
                    Exit Try
                End If

                With loBatchPar
                    .COMPANY_ID = _CCOMPID
                    .USER_ID = _CUSERID
                    .ClassName = "SAM01200Back.CopyMenuCls"
                    .BigObject = loBigObject
                    .UserParameters = loUserParameters
                End With
                lcKeyGuid = loSvc.R_BatchProcess(loBatchPar, poPopUpEntityResult.Count)
            End If
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If
    End Sub

    Private Sub btnPopupCopyMenu_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnPopupCopyMenu.R_Before_Open_Form
        poTargetForm = New CopyMenu

        poParameter = New UserCompanyDTO With {._CCOMPANY_ID = CType(bsGvCompany.Current, UserCompanyDTO)._CCOMPANY_ID,
                                               ._CCOMPANY_NAME = CType(bsGvCompany.Current, UserCompanyDTO)._CCOMPANY_NAME,
                                               ._CUSER_ID = _oParentData._CUSER_ID,
                                               ._CUSER_NAME = _oParentData._CUSER_NAME}
    End Sub
#End Region

#Region "POPUP USER MENU"
    Private Sub btnPopupUserMenu_R_After_Open_Form(poPopUpResult As System.Windows.Forms.DialogResult, poPopUpEntityResult As Object) Handles btnPopupUserMenu.R_After_Open_Form
        Dim loEx As New R_Exception
        Dim loBatchPar As R_BatchParameter
        Dim loSvc As R_ProcessAndUploadClient
        Dim loBigObject As List(Of SAM01200Common.BatchMenuDTO)
        Dim lcKeyGuid As String
        Dim loUserPar As R_KeyValue
        Dim loUserParameters As New List(Of R_KeyValue)

        Try
            If poPopUpResult = Windows.Forms.DialogResult.OK Then
                If poPopUpEntityResult.Count = 0 Then
                    loEx.Add("", "Please choose company!")
                    Exit Try
                End If

                With loUserPar
                    .Key = "CUSER_ID"
                    .Value = _oParentData._CUSER_ID
                End With
                loUserParameters.Add(loUserPar)

                With loUserPar
                    .Key = "CCOMPANY_ID"
                    .Value = CType(bsGvCompany.Current, UserCompanyDTO)._CCOMPANY_ID
                End With
                loUserParameters.Add(loUserPar)

                With loUserPar
                    .Key = "DDATE"
                    .Value = DateTime.Now
                End With
                loUserParameters.Add(loUserPar)

                'Instantiate FrontHelper
                loSvc = New R_ProcessAndUploadClient(bwCompanyMenu, Nothing, Nothing)
                AddHandler loSvc.ProcessError, AddressOf ProcessError
                AddHandler loSvc.ProcessComplete, AddressOf ProcessComplete

                loBigObject = CType(poPopUpEntityResult, List(Of UserMenuDTO)) _
                .Select(Function(x) New SAM01200Common.BatchMenuDTO() _
                        With {.CMENU_ID = x._CMENU_ID,
                              .CMENU_NAME = x._CMENU_NAME}).ToList()

                If loBigObject.Count = 0 Then
                    Exit Try
                End If

                With loBatchPar
                    .COMPANY_ID = _CCOMPID
                    .USER_ID = _CUSERID
                    .ClassName = "SAM01200Back.UserMenuCls"
                    .BigObject = loBigObject
                    .UserParameters = loUserParameters
                End With
                lcKeyGuid = loSvc.R_BatchProcess(loBatchPar, poPopUpEntityResult.Count)
            End If
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If
    End Sub

    Private Sub btnPopupUserMenu_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnPopupUserMenu.R_Before_Open_Form
        poTargetForm = New MultipleMenu

        poParameter = New UserCompanyDTO With {._CCOMPANY_ID = CType(bsGvCompany.Current, UserCompanyDTO)._CCOMPANY_ID,
                                               ._CCOMPANY_NAME = CType(bsGvCompany.Current, UserCompanyDTO)._CCOMPANY_NAME,
                                               ._CUSER_ID = _oParentData._CUSER_ID,
                                               ._CUSER_NAME = _oParentData._CUSER_NAME}
    End Sub
#End Region

#Region "INTERNAL METHOD"
    Private Sub ProcessComplete(pcKeyGuid As String, poProcessResultMode As eProcessResultMode)
        Dim loEx As New R_Exception()

        Select Case poProcessResultMode
            Case eProcessResultMode.Success
                R_RadMessageBox.Show(R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_Complete"), Windows.Forms.MessageBoxButtons.OK)
                gvUserCompany.R_RefreshGrid(_oParentData._CUSER_ID)
            Case eProcessResultMode.Fail
                Dim loException As New R_Exception
                Dim loRtn As List(Of R_ErrorStatusReturn)
                Dim loHelp As New R_ProcessAndUploadClient(bwCompanyMenu, Nothing, Nothing)
                Dim loPar As R_UploadAndProcessKey

                Try
                    With loPar
                        .COMPANY_ID = _CCOMPID
                        .USER_ID = _CUSERID
                        .KEY_GUID = pcKeyGuid
                    End With
                    loRtn = loHelp.R_GetErrorProcess(loPar)

                    For Each loError As R_ErrorStatusReturn In loRtn
                        loEx.Add(loError.SeqNo.ToString, loError.ErrorMessage)
                    Next
                Catch ex As Exception
                    loException.Add(ex)
                End Try

                If loException.Haserror Then
                    loEx.ThrowExceptionIfErrors()
                End If
        End Select
    End Sub

    Private Sub ProcessError(pcKeyGuid As String, ex As R_Exception)
        Dim loException As New R_Exception
        If ex.Haserror Then
            For Each loError As R_Error In ex.ErrorList
                loException.Add(loError)
            Next
        End If

        If loException.Haserror Then
            Me.R_DisplayException(loException)
        End If
    End Sub
#End Region

    Private Sub btnResetPass_Click(sender As System.Object, e As System.EventArgs) Handles btnResetPass.Click
        Dim loService As SAM01200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01200Service, SAM01200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception()
        Dim loParam As New SAM01200UserDTO
        Dim lcEmailId As String
        Dim loEmailCls As New EmailCls
        Dim lcSMTP As String

        Try
            If _oParentData._CEMAIL_ADDRESS Is Nothing Then
                loEx.Add("PS007", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS007"))
                Exit Try
            Else
                If IsEmail(_oParentData._CEMAIL_ADDRESS) = False Then
                    loEx.Add("PS006", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS006"))
                    Exit Try
                End If
            End If

            Select Case R_RadMessageBox.Show(R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_ResetPassword"), _
                                             R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_ResetConfirmation"), _
                                             Windows.Forms.MessageBoxButtons.YesNo)
                Case Windows.Forms.DialogResult.Yes
                    With CType(bsGvCompany.Current, UserCompanyDTO)
                        loParam._CUSER_LOGIN = _CUSERID
                        loParam._CUSER_ID = _oParentData._CUSER_ID
                        loParam._CEMAIL_ADDRESS = _oParentData._CEMAIL_ADDRESS
                        loParam._DDATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                        loParam._CCOMPANY_ID = ._CCOMPANY_ID
                    End With

                    lcSMTP = loService.getSMTP(_CCOMPID)

                    Dim oEmailPar As EmailParam
                    With oEmailPar
                        .cSubject = EmailProp.cEmailSubjectReset
                        .cBody = String.Format(EmailProp.cResetCompBody, _oParentData._CUSER_ID, "{1}", CType(bsGvCompany.Current, UserCompanyDTO)._CCOMPANY_ID)
                        .cEmailFrom = lcSMTP
                    End With
                    lcEmailId = loEmailCls.sendEmail(loParam, oEmailPar, _CCOMPID, _CUSERID)

                    loParam._CEMAIL_ID = lcEmailId
                    loParam._CPWD = loService.resetPass(loParam)

                    R_RadMessageBox.Show(R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_SentToUserEmail"))
            End Select
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If
    End Sub

    Private Function IsEmail(ByVal email As String) As Boolean
        Dim pattern As String = "^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"
        Dim emailAddressMatch As Match = Regex.Match(email, pattern)
        If emailAddressMatch.Success Then
            Return True
        Else
            Return False
        End If
    End Function

    'Private Sub gvMenu_CellEditorInitialized(sender As Object, e As Telerik.WinControls.UI.GridViewCellEventArgs) Handles gvUserMenu.CellEditorInitialized
    '    Dim editor As RadDropDownListEditor = TryCast(gvUserMenu.ActiveEditor, RadDropDownListEditor)
    '    If editor IsNot Nothing Then
    '        RemoveHandler editor.ValueChanged, AddressOf editor_ValueChanged
    '        AddHandler editor.ValueChanged, AddressOf editor_ValueChanged
    '    End If
    'End Sub

    'Private Sub editor_ValueChanged(sender As Object, e As EventArgs)
    '    Dim editor As RadDropDownListEditor = TryCast(sender, RadDropDownListEditor)
    '    MsgBox(editor.Value)
    'End Sub

    Private Sub conGridCompany_R_SetHasData(plEnable As Boolean) Handles conGridCompany.R_SetHasData
        R_RadGroupBox2.Enabled = plEnable
    End Sub
End Class
