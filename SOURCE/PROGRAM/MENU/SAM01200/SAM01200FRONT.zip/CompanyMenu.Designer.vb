﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CompanyMenu
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewComboBoxColumn1 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn1 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewCheckBoxColumn2 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn2 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDecimalColumn1 As R_FrontEnd.R_GridViewDecimalColumn = New R_FrontEnd.R_GridViewDecimalColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn3 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn4 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewComboBoxColumn2 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn5 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn6 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn6 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Me.bsCmbCompany = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsCmbMenu = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridCompany = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.R_RadGroupBox1 = New R_FrontEnd.R_RadGroupBox(Me.components)
        Me.gvUserCompany = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvCompany = New System.Windows.Forms.BindingSource(Me.components)
        Me.gvUserMenu = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvUserMenu = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridUserMenu = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.R_RadGroupBox2 = New R_FrontEnd.R_RadGroupBox(Me.components)
        Me.txtUserId = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtUserName = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.R_RadLabel1 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel2 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.btnPopupCopyCompany = New R_FrontEnd.R_PopUp(Me.components)
        Me.btnPopupUserCompany = New R_FrontEnd.R_PopUp(Me.components)
        Me.btnPopupCopyMenu = New R_FrontEnd.R_PopUp(Me.components)
        Me.btnPopupUserMenu = New R_FrontEnd.R_PopUp(Me.components)
        Me.bwCompanyMenu = New System.ComponentModel.BackgroundWorker()
        Me.btnResetPass = New R_FrontEnd.R_RadButton(Me.components)
        CType(Me.bsCmbCompany, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsCmbMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridCompany, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadGroupBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.R_RadGroupBox1.SuspendLayout()
        CType(Me.gvUserCompany, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvUserCompany.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvCompany, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvUserMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvUserMenu.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvUserMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridUserMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadGroupBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.R_RadGroupBox2.SuspendLayout()
        CType(Me.txtUserId, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtUserName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnPopupCopyCompany, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnPopupUserCompany, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnPopupCopyMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnPopupUserMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnResetPass, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'bsCmbCompany
        '
        Me.bsCmbCompany.DataSource = GetType(SAM01200Front.SAM01200ServiceRef.cmbDTO)
        '
        'bsCmbMenu
        '
        Me.bsCmbMenu.DataSource = GetType(SAM01200Front.SAM01200ServiceRef.cmbDTO)
        '
        'conGridCompany
        '
        Me.conGridCompany.R_ConductorParent = Nothing
        Me.conGridCompany.R_IsHeader = True
        Me.conGridCompany.R_RadGroupBox = Me.R_RadGroupBox1
        '
        'R_RadGroupBox1
        '
        Me.R_RadGroupBox1.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping
        Me.R_RadGroupBox1.Controls.Add(Me.gvUserCompany)
        Me.R_RadGroupBox1.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadGroupBox1.HeaderText = "R_RadGroupBox1"
        Me.R_RadGroupBox1.Location = New System.Drawing.Point(8, 67)
        Me.R_RadGroupBox1.Name = "R_RadGroupBox1"
        Me.R_RadGroupBox1.R_ConductorGridSource = Me.conGridCompany
        Me.R_RadGroupBox1.R_ConductorSource = Nothing
        Me.R_RadGroupBox1.R_ResourceId = "_Company"
        Me.R_RadGroupBox1.Size = New System.Drawing.Size(910, 203)
        Me.R_RadGroupBox1.TabIndex = 4
        Me.R_RadGroupBox1.Text = "R_RadGroupBox1"
        '
        'gvUserCompany
        '
        Me.gvUserCompany.Location = New System.Drawing.Point(5, 21)
        '
        '
        '
        Me.gvUserCompany.MasterTemplate.AutoGenerateColumns = False
        R_GridViewComboBoxColumn1.DataSource = Me.bsCmbCompany
        R_GridViewComboBoxColumn1.DisplayMember = "_CID"
        R_GridViewComboBoxColumn1.FieldName = "_CCOMPANY_ID"
        R_GridViewComboBoxColumn1.HeaderText = "_CCOMPANY_ID"
        R_GridViewComboBoxColumn1.MinWidth = 50
        R_GridViewComboBoxColumn1.Name = "_CCOMPANY_ID"
        R_GridViewComboBoxColumn1.R_EnableADD = True
        R_GridViewComboBoxColumn1.R_ResourceId = "_CCOMPANY_ID"
        R_GridViewComboBoxColumn1.ValueMember = "_CID"
        R_GridViewTextBoxColumn1.FieldName = "_CCOMPANY_NAME"
        R_GridViewTextBoxColumn1.HeaderText = "_CCOMPANY_NAME"
        R_GridViewTextBoxColumn1.IsAutoGenerated = True
        R_GridViewTextBoxColumn1.MinWidth = 150
        R_GridViewTextBoxColumn1.Name = "_CCOMPANY_NAME"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CCOMPANY_NAME"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 150
        R_GridViewCheckBoxColumn1.FieldName = "_LTIME_LIMITATION"
        R_GridViewCheckBoxColumn1.HeaderText = "_LTIME_LIMITATION"
        R_GridViewCheckBoxColumn1.IsAutoGenerated = True
        R_GridViewCheckBoxColumn1.MinWidth = 50
        R_GridViewCheckBoxColumn1.Name = "_LTIME_LIMITATION"
        R_GridViewCheckBoxColumn1.R_EnableADD = True
        R_GridViewCheckBoxColumn1.R_EnableEDIT = True
        R_GridViewCheckBoxColumn1.R_ResourceId = "_LTIME_LIMITATION"
        R_GridViewCheckBoxColumn2.FieldName = "_LENABLE_BROADCAST"
        R_GridViewCheckBoxColumn2.HeaderText = "_LENABLE_BROADCAST"
        R_GridViewCheckBoxColumn2.Name = "_LENABLE_BROADCAST"
        R_GridViewCheckBoxColumn2.R_EnableADD = True
        R_GridViewCheckBoxColumn2.R_EnableEDIT = True
        R_GridViewCheckBoxColumn2.R_ResourceId = "_LENABLE_BROADCAST"
        R_GridViewDateTimeColumn1.CustomFormat = ""
        R_GridViewDateTimeColumn1.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn1.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.GeneralDate
        R_GridViewDateTimeColumn1.FieldName = "_DSTART_DATE"
        R_GridViewDateTimeColumn1.FormatInfo = New System.Globalization.CultureInfo("")
        R_GridViewDateTimeColumn1.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn1.HeaderText = "_DSTART_DATE"
        R_GridViewDateTimeColumn1.IsAutoGenerated = True
        R_GridViewDateTimeColumn1.Name = "_DSTART_DATE"
        R_GridViewDateTimeColumn1.R_EnableADD = True
        R_GridViewDateTimeColumn1.R_EnableEDIT = True
        R_GridViewDateTimeColumn1.R_ResourceId = "_CSTART_DATE"
        R_GridViewDateTimeColumn2.CustomFormat = ""
        R_GridViewDateTimeColumn2.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn2.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.GeneralDate
        R_GridViewDateTimeColumn2.FieldName = "_DEND_DATE"
        R_GridViewDateTimeColumn2.FormatInfo = New System.Globalization.CultureInfo("")
        R_GridViewDateTimeColumn2.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn2.HeaderText = "_DEND_DATE"
        R_GridViewDateTimeColumn2.IsAutoGenerated = True
        R_GridViewDateTimeColumn2.Name = "_DEND_DATE"
        R_GridViewDateTimeColumn2.R_EnableADD = True
        R_GridViewDateTimeColumn2.R_EnableEDIT = True
        R_GridViewDateTimeColumn2.R_ResourceId = "_CEND_DATE"
        R_GridViewDecimalColumn1.DataType = GetType(Integer)
        R_GridViewDecimalColumn1.FieldName = "_IUSER_LEVEL"
        R_GridViewDecimalColumn1.FormatString = "{0:N}"
        R_GridViewDecimalColumn1.HeaderText = "_IUSER_LEVEL"
        R_GridViewDecimalColumn1.IsAutoGenerated = True
        R_GridViewDecimalColumn1.MinWidth = 50
        R_GridViewDecimalColumn1.Name = "_IUSER_LEVEL"
        R_GridViewDecimalColumn1.R_EnableADD = True
        R_GridViewDecimalColumn1.R_EnableEDIT = True
        R_GridViewDecimalColumn1.R_ResourceId = "_IUSER_LEVEL"
        R_GridViewDecimalColumn1.ThousandsSeparator = True
        R_GridViewTextBoxColumn2.FieldName = "_CUPDATE_BY"
        R_GridViewTextBoxColumn2.HeaderText = "_CUPDATE_BY"
        R_GridViewTextBoxColumn2.IsAutoGenerated = True
        R_GridViewTextBoxColumn2.MinWidth = 100
        R_GridViewTextBoxColumn2.Name = "_CUPDATE_BY"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CUPDATE_BY"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 100
        R_GridViewDateTimeColumn3.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn3.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn3.FieldName = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn3.FormatInfo = New System.Globalization.CultureInfo("")
        R_GridViewDateTimeColumn3.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn3.HeaderText = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn3.IsAutoGenerated = True
        R_GridViewDateTimeColumn3.MinWidth = 150
        R_GridViewDateTimeColumn3.Name = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn3.R_ResourceId = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn3.Width = 150
        R_GridViewTextBoxColumn3.FieldName = "_CCREATE_BY"
        R_GridViewTextBoxColumn3.HeaderText = "_CCREATE_BY"
        R_GridViewTextBoxColumn3.IsAutoGenerated = True
        R_GridViewTextBoxColumn3.MinWidth = 100
        R_GridViewTextBoxColumn3.Name = "_CCREATE_BY"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CCREATE_BY"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 100
        R_GridViewDateTimeColumn4.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn4.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn4.FieldName = "_DCREATE_DATE"
        R_GridViewDateTimeColumn4.FormatInfo = New System.Globalization.CultureInfo("")
        R_GridViewDateTimeColumn4.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn4.HeaderText = "_DCREATE_DATE"
        R_GridViewDateTimeColumn4.IsAutoGenerated = True
        R_GridViewDateTimeColumn4.MinWidth = 150
        R_GridViewDateTimeColumn4.Name = "_DCREATE_DATE"
        R_GridViewDateTimeColumn4.R_ResourceId = "_DCREATE_DATE"
        R_GridViewDateTimeColumn4.Width = 150
        Me.gvUserCompany.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewComboBoxColumn1, R_GridViewTextBoxColumn1, R_GridViewCheckBoxColumn1, R_GridViewCheckBoxColumn2, R_GridViewDateTimeColumn1, R_GridViewDateTimeColumn2, R_GridViewDecimalColumn1, R_GridViewTextBoxColumn2, R_GridViewDateTimeColumn3, R_GridViewTextBoxColumn3, R_GridViewDateTimeColumn4})
        Me.gvUserCompany.MasterTemplate.DataSource = Me.bsGvCompany
        Me.gvUserCompany.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvUserCompany.MasterTemplate.EnableFiltering = True
        Me.gvUserCompany.MasterTemplate.EnableGrouping = False
        Me.gvUserCompany.MasterTemplate.NewRowText = ""
        Me.gvUserCompany.MasterTemplate.ShowFilteringRow = False
        Me.gvUserCompany.MasterTemplate.ShowGroupedColumns = True
        Me.gvUserCompany.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvUserCompany.Name = "gvUserCompany"
        Me.gvUserCompany.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvUserCompany.R_ConductorGridSource = Me.conGridCompany
        Me.gvUserCompany.R_ConductorSource = Nothing
        Me.gvUserCompany.R_DataAdded = False
        Me.gvUserCompany.R_NewRowText = ""
        Me.gvUserCompany.ShowHeaderCellButtons = True
        Me.gvUserCompany.Size = New System.Drawing.Size(900, 177)
        Me.gvUserCompany.TabIndex = 2
        Me.gvUserCompany.Text = "R_RadGridView2"
        '
        'bsGvCompany
        '
        Me.bsGvCompany.DataSource = GetType(SAM01200Front.UserCompanyServiceRef.UserCompanyDTO)
        '
        'gvUserMenu
        '
        Me.gvUserMenu.Location = New System.Drawing.Point(5, 21)
        '
        '
        '
        Me.gvUserMenu.MasterTemplate.AutoGenerateColumns = False
        R_GridViewComboBoxColumn2.DataSource = Me.bsCmbMenu
        R_GridViewComboBoxColumn2.DisplayMember = "_CID"
        R_GridViewComboBoxColumn2.FieldName = "_CMENU_ID"
        R_GridViewComboBoxColumn2.HeaderText = "_CMENU_ID"
        R_GridViewComboBoxColumn2.MinWidth = 100
        R_GridViewComboBoxColumn2.Name = "_CMENU_ID"
        R_GridViewComboBoxColumn2.R_EnableADD = True
        R_GridViewComboBoxColumn2.R_ResourceId = "_CMENU_ID"
        R_GridViewComboBoxColumn2.ValueMember = "_CID"
        R_GridViewComboBoxColumn2.Width = 100
        R_GridViewTextBoxColumn4.FieldName = "_CMENU_NAME"
        R_GridViewTextBoxColumn4.HeaderText = "_CMENU_NAME"
        R_GridViewTextBoxColumn4.IsAutoGenerated = True
        R_GridViewTextBoxColumn4.MinWidth = 150
        R_GridViewTextBoxColumn4.Name = "_CMENU_NAME"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CMENU_NAME"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 150
        R_GridViewTextBoxColumn5.FieldName = "_CUPDATE_BY"
        R_GridViewTextBoxColumn5.HeaderText = "_CUPDATE_BY"
        R_GridViewTextBoxColumn5.IsAutoGenerated = True
        R_GridViewTextBoxColumn5.MinWidth = 150
        R_GridViewTextBoxColumn5.Name = "_CUPDATE_BY"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CUPDATE_BY"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 150
        R_GridViewDateTimeColumn5.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn5.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn5.FieldName = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn5.FormatInfo = New System.Globalization.CultureInfo("en-US")
        R_GridViewDateTimeColumn5.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn5.HeaderText = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn5.IsAutoGenerated = True
        R_GridViewDateTimeColumn5.MinWidth = 200
        R_GridViewDateTimeColumn5.Name = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn5.R_ResourceId = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn5.Width = 200
        R_GridViewTextBoxColumn6.FieldName = "_CCREATE_BY"
        R_GridViewTextBoxColumn6.HeaderText = "_CCREATE_BY"
        R_GridViewTextBoxColumn6.IsAutoGenerated = True
        R_GridViewTextBoxColumn6.MinWidth = 150
        R_GridViewTextBoxColumn6.Name = "_CCREATE_BY"
        R_GridViewTextBoxColumn6.R_ResourceId = "_CCREATE_BY"
        R_GridViewTextBoxColumn6.R_UDT = Nothing
        R_GridViewTextBoxColumn6.Width = 150
        R_GridViewDateTimeColumn6.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn6.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn6.FieldName = "_DCREATE_DATE"
        R_GridViewDateTimeColumn6.FormatInfo = New System.Globalization.CultureInfo("en-US")
        R_GridViewDateTimeColumn6.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn6.HeaderText = "_DCREATE_DATE"
        R_GridViewDateTimeColumn6.IsAutoGenerated = True
        R_GridViewDateTimeColumn6.MinWidth = 200
        R_GridViewDateTimeColumn6.Name = "_DCREATE_DATE"
        R_GridViewDateTimeColumn6.R_ResourceId = "_DCREATE_DATE"
        R_GridViewDateTimeColumn6.Width = 200
        Me.gvUserMenu.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewComboBoxColumn2, R_GridViewTextBoxColumn4, R_GridViewTextBoxColumn5, R_GridViewDateTimeColumn5, R_GridViewTextBoxColumn6, R_GridViewDateTimeColumn6})
        Me.gvUserMenu.MasterTemplate.DataSource = Me.bsGvUserMenu
        Me.gvUserMenu.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvUserMenu.MasterTemplate.EnableFiltering = True
        Me.gvUserMenu.MasterTemplate.EnableGrouping = False
        Me.gvUserMenu.MasterTemplate.ShowFilteringRow = False
        Me.gvUserMenu.MasterTemplate.ShowGroupedColumns = True
        Me.gvUserMenu.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvUserMenu.Name = "gvUserMenu"
        Me.gvUserMenu.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvUserMenu.R_ConductorGridSource = Me.conGridUserMenu
        Me.gvUserMenu.R_ConductorSource = Nothing
        Me.gvUserMenu.R_DataAdded = False
        Me.gvUserMenu.R_NewRowText = Nothing
        Me.gvUserMenu.ShowHeaderCellButtons = True
        Me.gvUserMenu.Size = New System.Drawing.Size(900, 223)
        Me.gvUserMenu.TabIndex = 3
        Me.gvUserMenu.Text = "R_RadGridView3"
        '
        'bsGvUserMenu
        '
        Me.bsGvUserMenu.DataSource = GetType(SAM01200Front.UserMenuServiceRef.UserMenuDTO)
        '
        'conGridUserMenu
        '
        Me.conGridUserMenu.R_ConductorParent = Me.conGridCompany
        Me.conGridUserMenu.R_RadGroupBox = Nothing
        '
        'R_RadGroupBox2
        '
        Me.R_RadGroupBox2.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping
        Me.R_RadGroupBox2.Controls.Add(Me.gvUserMenu)
        Me.R_RadGroupBox2.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadGroupBox2.HeaderText = "R_RadGroupBox2"
        Me.R_RadGroupBox2.Location = New System.Drawing.Point(8, 311)
        Me.R_RadGroupBox2.Name = "R_RadGroupBox2"
        Me.R_RadGroupBox2.R_ConductorGridSource = Me.conGridUserMenu
        Me.R_RadGroupBox2.R_ConductorSource = Nothing
        Me.R_RadGroupBox2.R_ResourceId = "_Menu_Access"
        Me.R_RadGroupBox2.Size = New System.Drawing.Size(910, 249)
        Me.R_RadGroupBox2.TabIndex = 5
        Me.R_RadGroupBox2.Text = "R_RadGroupBox2"
        '
        'txtUserId
        '
        Me.txtUserId.Enabled = False
        Me.txtUserId.Location = New System.Drawing.Point(114, 11)
        Me.txtUserId.Name = "txtUserId"
        Me.txtUserId.R_ConductorGridSource = Nothing
        Me.txtUserId.R_ConductorSource = Nothing
        Me.txtUserId.R_UDT = Nothing
        Me.txtUserId.Size = New System.Drawing.Size(240, 20)
        Me.txtUserId.TabIndex = 6
        '
        'txtUserName
        '
        Me.txtUserName.Enabled = False
        Me.txtUserName.Location = New System.Drawing.Point(114, 35)
        Me.txtUserName.Name = "txtUserName"
        Me.txtUserName.R_ConductorGridSource = Nothing
        Me.txtUserName.R_ConductorSource = Nothing
        Me.txtUserName.R_UDT = Nothing
        Me.txtUserName.Size = New System.Drawing.Size(240, 20)
        Me.txtUserName.TabIndex = 7
        '
        'R_RadLabel1
        '
        Me.R_RadLabel1.AutoSize = False
        Me.R_RadLabel1.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel1.Location = New System.Drawing.Point(8, 12)
        Me.R_RadLabel1.Name = "R_RadLabel1"
        Me.R_RadLabel1.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel1.R_ResourceId = "_User_Id"
        Me.R_RadLabel1.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel1.TabIndex = 8
        Me.R_RadLabel1.Text = "R_RadLabel1"
        '
        'R_RadLabel2
        '
        Me.R_RadLabel2.AutoSize = False
        Me.R_RadLabel2.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel2.Location = New System.Drawing.Point(8, 36)
        Me.R_RadLabel2.Name = "R_RadLabel2"
        Me.R_RadLabel2.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel2.R_ResourceId = "_User_Name"
        Me.R_RadLabel2.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel2.TabIndex = 9
        Me.R_RadLabel2.Text = "R_RadLabel2"
        '
        'btnPopupCopyCompany
        '
        Me.btnPopupCopyCompany.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnPopupCopyCompany.Location = New System.Drawing.Point(571, 276)
        Me.btnPopupCopyCompany.Name = "btnPopupCopyCompany"
        Me.btnPopupCopyCompany.R_ConductorGridSource = Nothing
        Me.btnPopupCopyCompany.R_ConductorSource = Nothing
        Me.btnPopupCopyCompany.R_DescriptionId = Nothing
        Me.btnPopupCopyCompany.R_ResourceId = "_Copy"
        Me.btnPopupCopyCompany.R_Title = Nothing
        Me.btnPopupCopyCompany.Size = New System.Drawing.Size(110, 24)
        Me.btnPopupCopyCompany.TabIndex = 10
        Me.btnPopupCopyCompany.Text = "Copy"
        Me.btnPopupCopyCompany.Visible = False
        '
        'btnPopupUserCompany
        '
        Me.btnPopupUserCompany.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnPopupUserCompany.Location = New System.Drawing.Point(687, 276)
        Me.btnPopupUserCompany.Name = "btnPopupUserCompany"
        Me.btnPopupUserCompany.R_ConductorGridSource = Nothing
        Me.btnPopupUserCompany.R_ConductorSource = Nothing
        Me.btnPopupUserCompany.R_DescriptionId = Nothing
        Me.btnPopupUserCompany.R_ResourceId = "_Multiple"
        Me.btnPopupUserCompany.R_Title = Nothing
        Me.btnPopupUserCompany.Size = New System.Drawing.Size(110, 24)
        Me.btnPopupUserCompany.TabIndex = 11
        Me.btnPopupUserCompany.Text = "Multiple"
        Me.btnPopupUserCompany.Visible = False
        '
        'btnPopupCopyMenu
        '
        Me.btnPopupCopyMenu.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnPopupCopyMenu.Location = New System.Drawing.Point(692, 566)
        Me.btnPopupCopyMenu.Name = "btnPopupCopyMenu"
        Me.btnPopupCopyMenu.R_ConductorGridSource = Nothing
        Me.btnPopupCopyMenu.R_ConductorSource = Nothing
        Me.btnPopupCopyMenu.R_DescriptionId = Nothing
        Me.btnPopupCopyMenu.R_ResourceId = "_Copy"
        Me.btnPopupCopyMenu.R_Title = Nothing
        Me.btnPopupCopyMenu.Size = New System.Drawing.Size(110, 24)
        Me.btnPopupCopyMenu.TabIndex = 12
        Me.btnPopupCopyMenu.Text = "Copy"
        Me.btnPopupCopyMenu.Visible = False
        '
        'btnPopupUserMenu
        '
        Me.btnPopupUserMenu.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnPopupUserMenu.Location = New System.Drawing.Point(808, 566)
        Me.btnPopupUserMenu.Name = "btnPopupUserMenu"
        Me.btnPopupUserMenu.R_ConductorGridSource = Nothing
        Me.btnPopupUserMenu.R_ConductorSource = Nothing
        Me.btnPopupUserMenu.R_DescriptionId = Nothing
        Me.btnPopupUserMenu.R_ResourceId = "_Multiple"
        Me.btnPopupUserMenu.R_Title = Nothing
        Me.btnPopupUserMenu.Size = New System.Drawing.Size(110, 24)
        Me.btnPopupUserMenu.TabIndex = 13
        Me.btnPopupUserMenu.Text = "Multiple"
        Me.btnPopupUserMenu.Visible = False
        '
        'btnResetPass
        '
        Me.btnResetPass.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnResetPass.Location = New System.Drawing.Point(803, 276)
        Me.btnResetPass.Name = "btnResetPass"
        Me.btnResetPass.R_ConductorGridSource = Nothing
        Me.btnResetPass.R_ConductorSource = Nothing
        Me.btnResetPass.R_DescriptionId = Nothing
        Me.btnResetPass.R_ResourceId = "_Reset"
        Me.btnResetPass.Size = New System.Drawing.Size(110, 24)
        Me.btnResetPass.TabIndex = 14
        Me.btnResetPass.Text = "Reset Password"
        '
        'CompanyMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(935, 596)
        Me.Controls.Add(Me.btnResetPass)
        Me.Controls.Add(Me.btnPopupUserMenu)
        Me.Controls.Add(Me.btnPopupCopyMenu)
        Me.Controls.Add(Me.btnPopupUserCompany)
        Me.Controls.Add(Me.btnPopupCopyCompany)
        Me.Controls.Add(Me.R_RadLabel2)
        Me.Controls.Add(Me.R_RadLabel1)
        Me.Controls.Add(Me.txtUserName)
        Me.Controls.Add(Me.txtUserId)
        Me.Controls.Add(Me.R_RadGroupBox2)
        Me.Controls.Add(Me.R_RadGroupBox1)
        Me.Name = "CompanyMenu"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "Assign Company and Menu"
        CType(Me.bsCmbCompany, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsCmbMenu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridCompany, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadGroupBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.R_RadGroupBox1.ResumeLayout(False)
        CType(Me.gvUserCompany.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvUserCompany, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvCompany, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvUserMenu.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvUserMenu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvUserMenu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridUserMenu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadGroupBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.R_RadGroupBox2.ResumeLayout(False)
        CType(Me.txtUserId, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtUserName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnPopupCopyCompany, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnPopupUserCompany, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnPopupCopyMenu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnPopupUserMenu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnResetPass, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents conGridCompany As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsGvCompany As System.Windows.Forms.BindingSource
    Friend WithEvents gvUserCompany As R_FrontEnd.R_RadGridView
    Friend WithEvents bsCmbCompany As System.Windows.Forms.BindingSource
    Friend WithEvents gvUserMenu As R_FrontEnd.R_RadGridView
    Friend WithEvents R_RadGroupBox1 As R_FrontEnd.R_RadGroupBox
    Friend WithEvents R_RadGroupBox2 As R_FrontEnd.R_RadGroupBox
    Friend WithEvents txtUserId As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtUserName As R_FrontEnd.R_RadTextBox
    Friend WithEvents R_RadLabel1 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel2 As R_FrontEnd.R_RadLabel
    Friend WithEvents conGridUserMenu As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsCmbMenu As System.Windows.Forms.BindingSource
    Friend WithEvents bsGvUserMenu As System.Windows.Forms.BindingSource
    Friend WithEvents btnPopupCopyCompany As R_FrontEnd.R_PopUp
    Friend WithEvents btnPopupUserCompany As R_FrontEnd.R_PopUp
    Friend WithEvents btnPopupCopyMenu As R_FrontEnd.R_PopUp
    Friend WithEvents btnPopupUserMenu As R_FrontEnd.R_PopUp
    Friend WithEvents bwCompanyMenu As System.ComponentModel.BackgroundWorker
    Friend WithEvents btnResetPass As R_FrontEnd.R_RadButton

End Class
