﻿Imports R_FrontEnd
Imports SAM01200Front.SAM01200ServiceRef
Imports SAM01200Front.SAM01200StreamingServiceRef
Imports R_Common
Imports System.ServiceModel.Channels
Imports ClientHelper
Imports SAM01200FrontResources
Imports System.Globalization
Imports HelperStreamExtensionLibrary
Imports System.Text.RegularExpressions

Public Class SAM01200

#Region " VARIABLE "
    Dim C_ServiceName As String = "SAM01200Service/SAM01200Service.svc"
    Dim C_ServiceNameStream As String = "SAM01200Service/SAM01200StreamingService/SAM01200StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Private Const CHUNK_SIZE As Integer = 200 * 1024
#End Region

    Private Sub SAM01200_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim loService As SAM01200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01200Service, SAM01200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim oRes As New Resources_Dummy_Class

        Try
            If U_GlobalVar.SecurityParameter.cSecurityAndAccountPolicy = "bycompany" Then
                btnResetPass.Enabled = False
            Else
                btnAssignCompany.Enabled = False
            End If

            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            _loadCultures()

            gvUser.R_RefreshGrid(_CCOMPID)

            loService.Close()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub SAM01200_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        Dim loParLock As R_LockPar
        Dim loParUnlock As R_UnlockPar
        Dim loRtn As New R_LockingResult
        Dim loEntity As SAM01200UserDTO = poEntity

        If peLockUnlock = R_eLockUnlock.Lock Then
            With loParLock
                .Company_Id = U_GlobalVar.CompId.Trim
                .User_Id = U_GlobalVar.UserId.Trim
                .Program_Id = "SAM01200"
                .Table_Name = "SAM_USER"
                .Key_Value = loEntity._CUSER_ID
            End With
            loRtn = R_LockingClient.R_Lock(loParLock)
        ElseIf peLockUnlock = R_eLockUnlock.Unlock Then
            With loParUnlock
                .Program_Id = "SAM01200"
                .Company_Id = U_GlobalVar.CompId.Trim
                .User_Id = U_GlobalVar.UserId.Trim
                .Table_Name = "SAM_USER"
                .Key_Value = loEntity._CUSER_ID
            End With
            loRtn = R_LockingClient.R_Unlock(loParUnlock)
        End If
        plSuccessLockUnlock = loRtn.IsSuccess

        If loRtn.Exception IsNot Nothing Then
            loRtn.Exception.ThrowExceptionIfErrors()
        End If
    End Sub

#Region "GRIDVIEW USER"
    Private Sub gvUser_R_AfterAdd(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection) Handles gvUser.R_AfterAdd
        poGridCellCollection(7).Value = _CUSERID
        poGridCellCollection(8).Value = DateTime.Now
    End Sub

    Private Sub gvUser_R_CheckDelete(poEntity As Object, ByRef plAllowDelete As Boolean) Handles gvUser.R_CheckDelete
        If CType(poEntity, SAM01200UserDTO)._CUSER_ID.ToLower = "admin" Then
            plAllowDelete = False
        End If
    End Sub

    Private Sub gvUser_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvUser.R_Saving
        With CType(poEntity, SAM01200UserDTO)
            ._CUSER_LOGIN = _CUSERID
            ._DDATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With
    End Sub

    Private Sub gvUser_R_ServiceDelete(poEntity As Object) Handles gvUser.R_ServiceDelete
        Dim loService As SAM01200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01200Service, SAM01200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcEmailId As String
        Dim oEmailCls As New EmailCls
        Dim lcSMTP As String

        Try
            lcSMTP = loService.getSMTP(_CCOMPID)
            Dim oEmailPar As EmailParam
            With oEmailPar
                .cSubject = EmailProp.cEmailSubjectDeleted
                .cBody = String.Format(EmailProp.cDeleteUserBody, poEntity._CUSER_ID)
                .cEmailFrom = lcSMTP
            End With
            lcEmailId = oEmailCls.sendEmail(poEntity, oEmailPar, _CCOMPID, _CUSERID)

            With CType(poEntity, SAM01200UserDTO)
                ._CCOMPANY_ID = _CCOMPID
                ._CEMAIL_ID = lcEmailId
            End With

            loService.Svc_R_Delete(poEntity)

            R_RadMessageBox.Show(R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_SentToUserEmail"))
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvUser_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvUser.R_ServiceGetRecord
        Dim loService As SAM01200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01200Service, SAM01200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvUser_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvUser.R_ServiceSave
        Dim loService As SAM01200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01200Service, SAM01200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcEmailId As String
        Dim cParamValues As String
        Dim oEmailCls As New EmailCls
        Dim lcSMTP As String

        Try
            lcSMTP = loService.getSMTP(_CCOMPID)

            If peGridMode = R_eGridMode.Add Then
                Dim oEmailPar As EmailParam
                With oEmailPar
                    .cSubject = EmailProp.cEmailSubjectNew
                    .cBody = String.Format(EmailProp.cNewUserBody, poEntity._CUSER_ID, poEntity._CUSER_ID, "{2}")
                    .cEmailFrom = lcSMTP
                End With

                cParamValues = U_GlobalVar.SecurityParameter.cSecurityAndAccountPolicy

                If cParamValues = "byuser" Then
                    lcEmailId = oEmailCls.sendEmail(poEntity, oEmailPar, _CCOMPID, _CUSERID)

                    If String.IsNullOrEmpty(lcEmailId) = False Then
                        CType(poEntity, SAM01200UserDTO)._CEMAIL_ID = lcEmailId
                    End If
                End If
            End If

            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvUser_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvUser.R_ServiceGetListRecord
        Dim loServiceStream As SAM01200StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01200StreamingService, SAM01200StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loEx As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of SAM01200UserDTOnon)
        Dim loListEntity As New List(Of SAM01200UserDTO)

        Try
            loRtn = loServiceStream.getUserList()
            loStreaming = R_StreamUtility(Of SAM01200UserDTOnon).ReadFromMessage(loRtn)

            For Each loDto As SAM01200UserDTOnon In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New SAM01200UserDTO With {._CUSER_ID = loDto.CUSER_ID,
                                                               ._CUSER_NAME = loDto.CUSER_NAME,
                                                               ._CPOSITION = loDto.CPOSITION,
                                                               ._DLAST_UPDATE_PSWD = loDto.DLAST_UPDATE_PSWD,
                                                               ._CEMAIL_ADDRESS = loDto.CEMAIL_ADDRESS,
                                                               ._CCREATE_BY = loDto.CCREATE_BY,
                                                               ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                               ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                               ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvUser_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvUser.R_Validation
        Dim loEx As New R_Exception()

        Try
            pcError = ""
            With poGridCellCollection
                If String.IsNullOrWhiteSpace(.Item(0).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS001")
                    loEx.Add("PS001", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS001"))
                    plCancel = True
                End If

                If String.IsNullOrWhiteSpace(.Item(1).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS002")
                    loEx.Add("PS002", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS002"))
                    plCancel = True
                End If

                If String.IsNullOrWhiteSpace(.Item(4).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS003")
                    loEx.Add("PS003", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS003"))
                    plCancel = True
                Else
                    If IsEmail(.Item(4).Value.ToString) = False Then
                        pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS006")
                        loEx.Add("PS006", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS006"))
                        plCancel = True
                    End If
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
#End Region

#Region "BUTTON SECTION"
    Private Sub btnResetPass_Click(sender As System.Object, e As System.EventArgs) Handles btnResetPass.Click
        Dim loService As SAM01200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01200Service, SAM01200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception()
        Dim loParam As New SAM01200UserDTO
        Dim lcEmailId As String
        Dim loEmailCls As New EmailCls
        Dim lcSMTP As String

        Try
            If CType(bsGvUser.Current, SAM01200UserDTO)._CEMAIL_ADDRESS Is Nothing Then
                loEx.Add("PS007", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS007"))
                Exit Try
            Else
                If IsEmail(CType(bsGvUser.Current, SAM01200UserDTO)._CEMAIL_ADDRESS) = False Then
                    loEx.Add("PS006", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS006"))
                    Exit Try
                End If
            End If

            Select Case R_RadMessageBox.Show(R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_ResetPassword"), _
                                             R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_ResetConfirmation"), _
                                             Windows.Forms.MessageBoxButtons.YesNo)
                Case Windows.Forms.DialogResult.Yes
                    With CType(bsGvUser.Current, SAM01200UserDTO)
                        loParam._CUSER_LOGIN = _CUSERID
                        loParam._CUSER_ID = ._CUSER_ID
                        loParam._CEMAIL_ADDRESS = ._CEMAIL_ADDRESS
                        loParam._DDATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                    End With

                    lcSMTP = loService.getSMTP(_CCOMPID)

                    Dim oEmailPar As EmailParam
                    With oEmailPar
                        .cSubject = EmailProp.cEmailSubjectReset
                        .cBody = String.Format(EmailProp.cResetUserBody, loParam._CUSER_ID, loParam._CUSER_ID, "{2}")
                        .cEmailFrom = lcSMTP
                    End With
                    lcEmailId = loEmailCls.sendEmail(loParam, oEmailPar, _CCOMPID, _CUSERID)

                    loParam._CEMAIL_ID = lcEmailId
                    loParam._CPWD = loService.resetPass(loParam)

                    R_RadMessageBox.Show(R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_SentToUserEmail"))
            End Select
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If
    End Sub

    Private Sub btnAssignCompany_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnAssignCompany.R_Before_Open_Form
        poTargetForm = New CompanyMenu

        poParameter = bsGvUser.Current
    End Sub

#Region "POPUP UPLOAD"
    Private Sub btnUpload_R_After_Open_Form(poPopUpResult As System.Windows.Forms.DialogResult, poPopUpEntityResult As Object) Handles btnUpload.R_After_Open_Form
        Dim loService As SAM01200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01200Service, SAM01200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loUpload As New SliceDTO
        Dim loEx As New R_Exception()
        Dim loList As ArrayList
        Dim loDatas As Byte()

        Try
            If poPopUpResult = Windows.Forms.DialogResult.Cancel Then
                Exit Try
            End If

            If poPopUpEntityResult IsNot Nothing Then
                For Each oData As SliceDTO In poPopUpEntityResult
                    loUpload = oData

                    With loUpload
                        ._COMPANY_ID = U_GlobalVar.CompId
                        ._USER_ID = CType(bsGvUser.Current, SAM01200UserDTO)._CUSER_ID
                        ._KEY_GUID = Guid.NewGuid().ToString("N")
                    End With

                    'Slice Big Object
                    If loUpload._DATA IsNot Nothing Then
                        loList = New ArrayList()
                        loDatas = R_Utility.Serialize(loUpload._DATA)

                        For Each loItem In loDatas.Slices(CHUNK_SIZE).Select(Function(x, i) Tuple.Create(i, x))
                            loList.Add(loItem)
                        Next

                        For Each loItem As Tuple(Of Integer, Byte()) In loList
                            With loUpload
                                ._SEQ_NO = loItem.Item1
                                ._DATA = loItem.Item2
                            End With

                            loService.SliceFiles(U_GlobalVar.UserId, loUpload)
                        Next
                    End If

                    loService.SaveImage(U_GlobalVar.UserId, loUpload)
                Next
            End If


            loService.Close()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If
    End Sub

    Private Sub btnUpload_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnUpload.R_Before_Open_Form
        Dim loService As SAM01200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01200Service, SAM01200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loParam As New List(Of SliceDTO)
        Dim loEx As New R_Exception()

        Try
            poTargetForm = New UploadForm

            loParam = loService.GetImage(CType(bsGvUser.Current, SAM01200UserDTO)._CUSER_ID)
            loService.Close()
            poParameter = loParam
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
#End Region
#End Region

    Private Function getDate(pcDate As String) As Nullable(Of Date)
        If String.IsNullOrEmpty(pcDate) Then
            Return Nothing
        Else
            Return DateTime.ParseExact(pcDate, "yyyyMMdd", CultureInfo.CurrentCulture)
        End If
    End Function

    Private Function IsEmail(ByVal email As String) As Boolean
        Dim pattern As String = "^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"
        Dim emailAddressMatch As Match = Regex.Match(email, pattern)
        If emailAddressMatch.Success Then
            Return True
        Else
            Return False
        End If
    End Function

    Private Sub _loadCultures()
        Dim laNameValues As R_NameValue()
        Dim oRtn As New List(Of CultureDTO)

        laNameValues = R_Culture.R_GetAvailableCultures

        For Each avail As R_NameValue In laNameValues
            oRtn.Add(New CultureDTO With {.CCODE = IIf(avail.Value = 1, "en", "id"),
                                          .CDESC = avail.Name})
        Next

        cmbCultureUI.DataSource = oRtn
        cmbCultureFormat.DataSource = oRtn
    End Sub
End Class
