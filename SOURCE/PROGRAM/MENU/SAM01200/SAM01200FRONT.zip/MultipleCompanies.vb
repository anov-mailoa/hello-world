﻿Imports R_FrontEnd
Imports SAM01200Front.SAM01200ServiceRef
Imports SAM01200Front.SAM01200StreamingServiceRef
Imports SAM01200Front.UserCompanyServiceRef
Imports SAM01200Front.UserMenuServiceRef
Imports R_Common
Imports System.ServiceModel.Channels
Imports ClientHelper

Public Class MultipleCompanies

#Region " VARIABLE "
    Dim C_ServiceName As String = "SAM01200Service/SAM01200Service.svc"
    Dim C_ServiceNameStream As String = "SAM01200Service/SAM01200StreamingService/SAM01200StreamingService.svc"
    Dim C_ServiceNameCompany As String = "SAM01200Service/UserCompanyService/UserCompanyService.svc"
    Dim C_ServiceNameMenu As String = "SAM01200Service/UserMenuService/UserMenuService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
#End Region

    Private Sub MultipleCompanies_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        With CType(poParameter, SAM01200UserDTO)
            txtUserId.Text = ._CUSER_ID
            txtUserName.Text = ._CUSER_NAME

            gvCompany.R_RefreshGrid(New SAM01200UserDTO)
        End With
    End Sub

    Private Sub gvCompany_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvCompany.R_ServiceGetListRecord
        Dim loServiceStream As SAM01200StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01200StreamingService, SAM01200StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loEx As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of UserCompanyDTOnon)
        Dim loListEntity As New List(Of CompanyProcessDTO)

        Try
            loRtn = loServiceStream.getCompanyMultiple()
            loStreaming = R_StreamUtility(Of UserCompanyDTOnon).ReadFromMessage(loRtn)

            For Each loDto As UserCompanyDTOnon In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New CompanyProcessDTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                                  ._CCOMPANY_NAME = loDto.CCOMPANY_NAME,
                                                                  ._LTIME_LIMITATION = loDto.LTIME_LIMITATION,
                                                                  ._CSTART_DATE = loDto.CSTART_DATE,
                                                                  ._CEND_DATE = loDto.CEND_DATE,
                                                                  ._IUSER_LEVEL = loDto.IUSER_LEVEL})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvCompany_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvCompany.R_ServiceGetRecord
        poEntityResult = poEntity
    End Sub

    Private Sub rtnPopup_R_SetPopUpResult(ByRef poEntityResult As Object) Handles rtnPopup.R_SetPopUpResult
        poEntityResult = CType(bsGvCompany.List, List(Of CompanyProcessDTO)) _
            .Where(Function(x) x.LSELECTED = True) _
            .Select(Function(x) New UserCompanyDTO() _
                        With {._CCOMPANY_ID = x._CCOMPANY_ID,
                              ._CCOMPANY_NAME = x._CCOMPANY_NAME,
                                ._LTIME_LIMITATION = x._LTIME_LIMITATION,
                                ._CSTART_DATE = x._CSTART_DATE,
                                ._CEND_DATE = x._CEND_DATE,
                                ._IUSER_LEVEL = x._IUSER_LEVEL}).ToList()
    End Sub

    <Serializable()> _
    Public Class CompanyProcessDTO
        Inherits UserCompanyDTO
        Public Property LSELECTED As Boolean

        Public Sub New()
        End Sub
    End Class
End Class
