﻿Imports R_FrontEnd
Imports R_Common
Imports System.ServiceModel.Channels
Imports ClientHelper
Imports SAM01200Front.SAM01200ServiceRef
Imports System.Windows.Forms
Imports System.Drawing
Imports SAM01200FrontResources
Imports System.IO

Public Class UploadForm
#Region " VARIABLE "
    Dim loRtn As New List(Of SliceDTO)
    Dim _cOldImgPhoto As String
    Dim _cOldImgSign As String
#End Region

#Region " INIT "

    Private Sub UploadForm_R_FormClosing(ByRef e As Object) Handles Me.R_FormClosing

    End Sub

    Private Sub UploadForm_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim loEx As New R_Exception()
        Dim lcNoImgPath As String = My.Application.Info.DirectoryPath + "\Image\no-image.png" 'get image "not found"
        Dim oRes As New Resources_Dummy_Class

        Try
            'check parameter
            If poParameter IsNot Nothing Then
                Dim oParam As List(Of SliceDTO) = poParameter

                txtUserId.Text = oParam.FirstOrDefault._USER_ID
                txtUserName.Text = oParam.FirstOrDefault._USER_NAME

                'TYPE 1 = Photo, TYPE 2 = Signature
                'get image photo from db and convert to file
                Dim oPhoto As Byte() = oParam.Where(Function(x) x._TYPE = 1).Select(Function(x) x).FirstOrDefault._DATA
                Dim cPhotoFilename As String = U_GlobalVar.TemporaryPath + "\" + U_GlobalVar.UserId + "_" + Guid.NewGuid().ToString("N") + ".jpg"
                If oPhoto IsNot Nothing Then
                    oPhoto = R_Utility.Deserialize(oPhoto)
                    R_Utility.ConvertByteToFile(cPhotoFilename, oPhoto)
                End If

                'get image signature from db and convert to file
                Dim oSign As Byte() = oParam.Where(Function(x) x._TYPE = 2).Select(Function(x) x).FirstOrDefault._DATA
                Dim cSignFilename As String = U_GlobalVar.TemporaryPath + "\" + U_GlobalVar.UserId + "_" + Guid.NewGuid().ToString("N") + ".jpg"
                If oSign IsNot Nothing Then
                    oSign = R_Utility.Deserialize(oSign)
                    R_Utility.ConvertByteToFile(cSignFilename, oSign)
                End If

                'check if image exist then set it to background, if not check image "no image found" on telerik menu/image dir,
                'if not found get image from this project resources
                If My.Computer.FileSystem.FileExists(cPhotoFilename) Then
                    pbPhoto.BackgroundImage = SafeImageFromFile(cPhotoFilename)
                    _cOldImgPhoto = cPhotoFilename
                Else
                    If My.Computer.FileSystem.FileExists(lcNoImgPath) Then
                        pbPhoto.BackgroundImage = SafeImageFromFile(lcNoImgPath)
                        _cOldImgPhoto = lcNoImgPath
                    Else
                        pbPhoto.BackgroundImage = My.Resources.no_image
                        _cOldImgPhoto = Path.Combine(Application.UserAppDataPath, "no-image.png")
                    End If
                End If

                If My.Computer.FileSystem.FileExists(cSignFilename) Then
                    pbSign.BackgroundImage = SafeImageFromFile(cSignFilename)
                    _cOldImgSign = cSignFilename
                Else
                    If My.Computer.FileSystem.FileExists(lcNoImgPath) Then
                        pbSign.BackgroundImage = SafeImageFromFile(lcNoImgPath)
                        _cOldImgSign = lcNoImgPath
                    Else
                        pbSign.BackgroundImage = My.Resources.no_image
                        _cOldImgSign = Path.Combine(Application.UserAppDataPath, "no-image.png")
                    End If
                End If
            End If
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
#End Region

#Region "BUTTON REGION"
    Private Sub btnBrowsePhoto_Click(sender As System.Object, e As System.EventArgs) Handles btnBrowsePhoto.Click
        Dim openFileDialog1 As New OpenFileDialog()
        openFileDialog1.Filter = "Image Files (*.png, *.jpg, *.jpeg)|*.png;*.jpg;*.jpeg"
        openFileDialog1.Title = "Select a picture file"

        If openFileDialog1.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
            txtPhotoPath.Text = openFileDialog1.FileName
            loRtn.Add(New SliceDTO With {._DATA = R_Utility.GetByteFromFile(txtPhotoPath.Text),
                                         ._TYPE = 1})
            Dim oImg As Image = SafeImageFromFile(txtPhotoPath.Text)
            pbPhoto.BackgroundImage = oImg
        End If
    End Sub

    Private Sub btnBrowseSign_Click(sender As System.Object, e As System.EventArgs) Handles btnBrowseSign.Click
        Dim openFileDialog1 As New OpenFileDialog()
        openFileDialog1.Filter = "Image Files (*.png, *.jpg, *.jpeg)|*.png;*.jpg;*.jpeg"
        openFileDialog1.Title = "Select a picture file"

        If openFileDialog1.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
            txtSignPath.Text = openFileDialog1.FileName
            loRtn.Add(New SliceDTO With {._DATA = R_Utility.GetByteFromFile(txtSignPath.Text),
                                         ._TYPE = 2})
            Dim oImg As Image = SafeImageFromFile(txtSignPath.Text)
            pbSign.BackgroundImage = oImg
        End If
    End Sub

    Private Sub btnEditPhoto_Click(sender As System.Object, e As System.EventArgs) Handles btnEditPhoto.Click
        CType(sender, R_RadButton).Visible = False
        DisablePhoto(True)
    End Sub

    Private Sub btnEditSign_Click(sender As System.Object, e As System.EventArgs) Handles btnEditSign.Click
        CType(sender, R_RadButton).Visible = False
        DisableSign(True)
    End Sub

    Private Sub btnCancelPhoto_Click(sender As Object, e As System.EventArgs) Handles btnCancelPhoto.Click
        Dim oCheckImg As SliceDTO = loRtn.Where(Function(x) x._TYPE = 1).Select(Function(x) x).FirstOrDefault
        If oCheckImg IsNot Nothing Then
            loRtn.Remove(oCheckImg)
        End If

        If My.Computer.FileSystem.FileExists(_cOldImgPhoto) Then
            pbPhoto.BackgroundImage = SafeImageFromFile(_cOldImgPhoto)
        Else
            pbPhoto.BackgroundImage = My.Resources.no_image
        End If

        DisablePhoto(False)
    End Sub

    Private Sub btnCancelSign_Click(sender As Object, e As System.EventArgs) Handles btnCancelSign.Click
        Dim oCheckImg As SliceDTO = loRtn.Where(Function(x) x._TYPE = 2).Select(Function(x) x).FirstOrDefault
        If oCheckImg IsNot Nothing Then
            loRtn.Remove(oCheckImg)
        End If

        If My.Computer.FileSystem.FileExists(_cOldImgSign) Then
            pbSign.BackgroundImage = SafeImageFromFile(_cOldImgSign)
        Else
            pbSign.BackgroundImage = My.Resources.no_image
        End If

        DisableSign(False)
    End Sub
#End Region

#Region "INTERNAL METHOD"
    Private Sub DisablePhoto(plVisible As Boolean)
        txtPhotoPath.Visible = plVisible
        btnBrowsePhoto.Visible = plVisible
        btnCancelPhoto.Visible = plVisible
        txtPhotoPath.Text = ""
        btnEditPhoto.Visible = Not plVisible
    End Sub

    Private Sub DisableSign(plVisible As Boolean)
        txtSignPath.Visible = plVisible
        btnBrowseSign.Visible = plVisible
        btnCancelSign.Visible = plVisible
        txtSignPath.Text = ""
        btnEditSign.Visible = Not plVisible
    End Sub

    Public Shared Function SafeImageFromFile(path As String) As Image
        Using fs As New FileStream(path, FileMode.Open, FileAccess.Read)
            Dim img = Image.FromStream(fs)
            Return img
        End Using
    End Function
#End Region

    Private Sub rtnPopup_R_SetPopUpResult(ByRef poEntityResult As Object) Handles rtnPopup.R_SetPopUpResult
        If loRtn.Count > 0 Then
            poEntityResult = loRtn
        End If
    End Sub

End Class
