﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CopyCompanies
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn1 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn6 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDecimalColumn1 As R_FrontEnd.R_GridViewDecimalColumn = New R_FrontEnd.R_GridViewDecimalColumn()
        Me.txtUserNameFrom = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.bsCmbUser = New System.Windows.Forms.BindingSource(Me.components)
        Me.R_RadLabel2 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.rtnPopup = New R_FrontEnd.R_ReturnPopUp()
        Me.txtUserName = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtUserId = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.R_RadLabel1 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvCompany = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvCompany = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridCompany = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.R_RadLabel3 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.cbIncludeMenu = New R_FrontEnd.R_RadCheckBox(Me.components)
        Me.cmbUserFrom = New R_FrontEnd.R_RadDropDownList(Me.components)
        CType(Me.txtUserNameFrom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsCmbUser, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtUserName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtUserId, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvCompany, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvCompany.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvCompany, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridCompany, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cbIncludeMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbUserFrom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtUserNameFrom
        '
        Me.txtUserNameFrom.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsCmbUser, "_CDESC", True))
        Me.txtUserNameFrom.Enabled = False
        Me.txtUserNameFrom.Location = New System.Drawing.Point(292, 35)
        Me.txtUserNameFrom.Name = "txtUserNameFrom"
        Me.txtUserNameFrom.R_ConductorGridSource = Nothing
        Me.txtUserNameFrom.R_ConductorSource = Nothing
        Me.txtUserNameFrom.R_UDT = Nothing
        Me.txtUserNameFrom.Size = New System.Drawing.Size(333, 20)
        Me.txtUserNameFrom.TabIndex = 20
        '
        'bsCmbUser
        '
        Me.bsCmbUser.DataSource = GetType(SAM01200Front.SAM01200ServiceRef.cmbDTO)
        '
        'R_RadLabel2
        '
        Me.R_RadLabel2.AutoSize = False
        Me.R_RadLabel2.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel2.Location = New System.Drawing.Point(21, 36)
        Me.R_RadLabel2.Name = "R_RadLabel2"
        Me.R_RadLabel2.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel2.R_ResourceId = "_Company"
        Me.R_RadLabel2.Size = New System.Drawing.Size(61, 18)
        Me.R_RadLabel2.TabIndex = 18
        Me.R_RadLabel2.Text = "Company"
        '
        'rtnPopup
        '
        Me.rtnPopup.Location = New System.Drawing.Point(642, 289)
        Me.rtnPopup.Name = "rtnPopup"
        Me.rtnPopup.Size = New System.Drawing.Size(162, 31)
        Me.rtnPopup.TabIndex = 17
        '
        'txtUserName
        '
        Me.txtUserName.Enabled = False
        Me.txtUserName.Location = New System.Drawing.Point(292, 12)
        Me.txtUserName.Name = "txtUserName"
        Me.txtUserName.R_ConductorGridSource = Nothing
        Me.txtUserName.R_ConductorSource = Nothing
        Me.txtUserName.R_UDT = Nothing
        Me.txtUserName.Size = New System.Drawing.Size(333, 20)
        Me.txtUserName.TabIndex = 16
        '
        'txtUserId
        '
        Me.txtUserId.Enabled = False
        Me.txtUserId.Location = New System.Drawing.Point(129, 12)
        Me.txtUserId.Name = "txtUserId"
        Me.txtUserId.R_ConductorGridSource = Nothing
        Me.txtUserId.R_ConductorSource = Nothing
        Me.txtUserId.R_UDT = Nothing
        Me.txtUserId.Size = New System.Drawing.Size(157, 20)
        Me.txtUserId.TabIndex = 15
        '
        'R_RadLabel1
        '
        Me.R_RadLabel1.AutoSize = False
        Me.R_RadLabel1.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel1.Location = New System.Drawing.Point(21, 12)
        Me.R_RadLabel1.Name = "R_RadLabel1"
        Me.R_RadLabel1.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel1.R_ResourceId = "_User"
        Me.R_RadLabel1.Size = New System.Drawing.Size(61, 18)
        Me.R_RadLabel1.TabIndex = 14
        Me.R_RadLabel1.Text = "User"
        '
        'gvCompany
        '
        Me.gvCompany.Location = New System.Drawing.Point(12, 90)
        '
        '
        '
        Me.gvCompany.MasterTemplate.AllowAddNewRow = False
        Me.gvCompany.MasterTemplate.AllowDeleteRow = False
        Me.gvCompany.MasterTemplate.AllowEditRow = False
        Me.gvCompany.MasterTemplate.AutoGenerateColumns = False
        Me.gvCompany.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn1.FieldName = "CCOMPANY_ID"
        R_GridViewTextBoxColumn1.HeaderText = "CCOMPANY_ID"
        R_GridViewTextBoxColumn1.IsAutoGenerated = True
        R_GridViewTextBoxColumn1.Name = "CCOMPANY_ID"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CCOMPANY_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 97
        R_GridViewTextBoxColumn2.FieldName = "CCOMPANY_NAME"
        R_GridViewTextBoxColumn2.HeaderText = "CCOMPANY_NAME"
        R_GridViewTextBoxColumn2.IsAutoGenerated = True
        R_GridViewTextBoxColumn2.Name = "CCOMPANY_NAME"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CCOMPANY_NAME"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 97
        R_GridViewCheckBoxColumn1.FieldName = "LTIME_LIMITATION"
        R_GridViewCheckBoxColumn1.HeaderText = "LTIME_LIMITATION"
        R_GridViewCheckBoxColumn1.IsAutoGenerated = True
        R_GridViewCheckBoxColumn1.Name = "LTIME_LIMITATION"
        R_GridViewCheckBoxColumn1.R_ResourceId = "_LTIME_LIMITATION"
        R_GridViewCheckBoxColumn1.Width = 100
        R_GridViewTextBoxColumn3.FieldName = "CCULTURE_ID"
        R_GridViewTextBoxColumn3.HeaderText = "CCULTURE_ID"
        R_GridViewTextBoxColumn3.IsAutoGenerated = True
        R_GridViewTextBoxColumn3.Name = "CCULTURE_ID"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CCULTURE_ID"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 97
        R_GridViewTextBoxColumn4.FieldName = "CCULTURE_FORMAT"
        R_GridViewTextBoxColumn4.HeaderText = "CCULTURE_FORMAT"
        R_GridViewTextBoxColumn4.IsAutoGenerated = True
        R_GridViewTextBoxColumn4.Name = "CCULTURE_FORMAT"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CCULTURE_FORMAT"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 97
        R_GridViewTextBoxColumn5.FieldName = "CSTART_DATE"
        R_GridViewTextBoxColumn5.HeaderText = "CSTART_DATE"
        R_GridViewTextBoxColumn5.IsAutoGenerated = True
        R_GridViewTextBoxColumn5.Name = "CSTART_DATE"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CSTART_DATE"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 97
        R_GridViewTextBoxColumn6.FieldName = "CEND_DATE"
        R_GridViewTextBoxColumn6.HeaderText = "CEND_DATE"
        R_GridViewTextBoxColumn6.IsAutoGenerated = True
        R_GridViewTextBoxColumn6.Name = "CEND_DATE"
        R_GridViewTextBoxColumn6.R_ResourceId = "_CEND_DATE"
        R_GridViewTextBoxColumn6.R_UDT = Nothing
        R_GridViewTextBoxColumn6.Width = 97
        R_GridViewDecimalColumn1.DataType = GetType(Integer)
        R_GridViewDecimalColumn1.FieldName = "IUSER_LEVEL"
        R_GridViewDecimalColumn1.HeaderText = "IUSER_LEVEL"
        R_GridViewDecimalColumn1.IsAutoGenerated = True
        R_GridViewDecimalColumn1.Name = "IUSER_LEVEL"
        R_GridViewDecimalColumn1.R_ResourceId = "_IUSER_LEVEL"
        R_GridViewDecimalColumn1.ThousandsSeparator = True
        R_GridViewDecimalColumn1.Width = 97
        Me.gvCompany.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewCheckBoxColumn1, R_GridViewTextBoxColumn3, R_GridViewTextBoxColumn4, R_GridViewTextBoxColumn5, R_GridViewTextBoxColumn6, R_GridViewDecimalColumn1})
        Me.gvCompany.MasterTemplate.DataSource = Me.bsGvCompany
        Me.gvCompany.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvCompany.MasterTemplate.EnableFiltering = True
        Me.gvCompany.MasterTemplate.EnableGrouping = False
        Me.gvCompany.MasterTemplate.ShowGroupedColumns = True
        Me.gvCompany.Name = "gvCompany"
        Me.gvCompany.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvCompany.R_ConductorGridSource = Me.conGridCompany
        Me.gvCompany.R_ConductorSource = Nothing
        Me.gvCompany.Size = New System.Drawing.Size(792, 193)
        Me.gvCompany.TabIndex = 13
        Me.gvCompany.Text = "R_RadGridView1"
        '
        'bsGvCompany
        '
        Me.bsGvCompany.DataSource = GetType(SAM01200Front.SAM01200StreamingServiceRef.CompanyCopyDTO)
        '
        'conGridCompany
        '
        Me.conGridCompany.R_ConductorParent = Nothing
        Me.conGridCompany.R_IsHeader = True
        Me.conGridCompany.R_RadGroupBox = Nothing
        '
        'R_RadLabel3
        '
        Me.R_RadLabel3.AutoSize = False
        Me.R_RadLabel3.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel3.Location = New System.Drawing.Point(21, 60)
        Me.R_RadLabel3.Name = "R_RadLabel3"
        Me.R_RadLabel3.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel3.R_ResourceId = "_IncludeMenu"
        Me.R_RadLabel3.Size = New System.Drawing.Size(85, 18)
        Me.R_RadLabel3.TabIndex = 21
        Me.R_RadLabel3.Text = "Include Menu"
        '
        'cbIncludeMenu
        '
        Me.cbIncludeMenu.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cbIncludeMenu.Location = New System.Drawing.Point(129, 60)
        Me.cbIncludeMenu.Name = "cbIncludeMenu"
        Me.cbIncludeMenu.R_ConductorGridSource = Nothing
        Me.cbIncludeMenu.R_ConductorSource = Nothing
        Me.cbIncludeMenu.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cbIncludeMenu.R_ResourceId = Nothing
        Me.cbIncludeMenu.Size = New System.Drawing.Size(15, 15)
        Me.cbIncludeMenu.TabIndex = 22
        '
        'cmbUserFrom
        '
        Me.cmbUserFrom.DataSource = Me.bsCmbUser
        Me.cmbUserFrom.DisplayMember = "_CID"
        Me.cmbUserFrom.Location = New System.Drawing.Point(129, 36)
        Me.cmbUserFrom.Name = "cmbUserFrom"
        Me.cmbUserFrom.R_ConductorGridSource = Nothing
        Me.cmbUserFrom.R_ConductorSource = Nothing
        Me.cmbUserFrom.Size = New System.Drawing.Size(157, 20)
        Me.cmbUserFrom.TabIndex = 23
        Me.cmbUserFrom.ValueMember = "_CID"
        '
        'CopyCompanies
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(816, 327)
        Me.Controls.Add(Me.cmbUserFrom)
        Me.Controls.Add(Me.cbIncludeMenu)
        Me.Controls.Add(Me.R_RadLabel3)
        Me.Controls.Add(Me.txtUserNameFrom)
        Me.Controls.Add(Me.R_RadLabel2)
        Me.Controls.Add(Me.rtnPopup)
        Me.Controls.Add(Me.txtUserName)
        Me.Controls.Add(Me.txtUserId)
        Me.Controls.Add(Me.R_RadLabel1)
        Me.Controls.Add(Me.gvCompany)
        Me.Name = "CopyCompanies"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "Copy Companies Assignment"
        CType(Me.txtUserNameFrom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsCmbUser, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtUserName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtUserId, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvCompany.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvCompany, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvCompany, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridCompany, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cbIncludeMenu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbUserFrom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtUserNameFrom As R_FrontEnd.R_RadTextBox
    Friend WithEvents R_RadLabel2 As R_FrontEnd.R_RadLabel
    Friend WithEvents rtnPopup As R_FrontEnd.R_ReturnPopUp
    Friend WithEvents txtUserName As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtUserId As R_FrontEnd.R_RadTextBox
    Friend WithEvents R_RadLabel1 As R_FrontEnd.R_RadLabel
    Friend WithEvents gvCompany As R_FrontEnd.R_RadGridView
    Friend WithEvents R_RadLabel3 As R_FrontEnd.R_RadLabel
    Friend WithEvents cbIncludeMenu As R_FrontEnd.R_RadCheckBox
    Friend WithEvents cmbUserFrom As R_FrontEnd.R_RadDropDownList
    Friend WithEvents bsGvCompany As System.Windows.Forms.BindingSource
    Friend WithEvents conGridCompany As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsCmbUser As System.Windows.Forms.BindingSource

End Class
