﻿Imports R_FrontEnd
Imports SAM01200Front.SAM01200ServiceRef
Imports SAM01200Front.SAM01200StreamingServiceRef
Imports SAM01200Front.UserCompanyServiceRef
Imports SAM01200Front.UserMenuServiceRef
Imports R_Common
Imports System.ServiceModel.Channels
Imports ClientHelper

Public Class CopyMenu

#Region " VARIABLE "
    Dim C_ServiceName As String = "SAM01200Service/SAM01200Service.svc"
    Dim C_ServiceNameStream As String = "SAM01200Service/SAM01200StreamingService/SAM01200StreamingService.svc"
    Dim C_ServiceNameCompany As String = "SAM01200Service/UserCompanyService/UserCompanyService.svc"
    Dim C_ServiceNameMenu As String = "SAM01200Service/UserMenuService/UserMenuService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
#End Region

    Private Sub CopyMenu_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim loService As SAM01200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01200Service, SAM01200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception()

        Try
            With CType(poParameter, UserCompanyDTO)
                txtUserId.Text = ._CUSER_ID
                txtUserName.Text = ._CUSER_NAME
                txtCompId.Text = ._CCOMPANY_ID
                txtCompName.Text = ._CCOMPANY_NAME

                bsCmbCompany.DataSource = loService.getCmbMenuCopy(._CCOMPANY_ID, ._CUSER_ID)
                loService.Close()
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub cmbCompanyFrom_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cmbCompanyFrom.SelectedValueChanged
        If cmbCompanyFrom.SelectedIndex <> -1 Then
            gvMenu.R_RefreshGrid(New UserCompanyDTO With {._CCOMPANY_ID = CType(bsCmbCompany.Current, cmbDTO)._CID,
                                                          ._CUSER_ID = txtUserId.Text})
        End If
    End Sub

    Private Sub gvMenu_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvMenu.R_ServiceGetListRecord
        Dim loServiceStream As SAM01200StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01200StreamingService, SAM01200StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loEx As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of UserMenuDTOnon)
        Dim loListEntity As New List(Of UserMenuDTO)

        Try
            R_Utility.R_SetStreamingContext("cUserId", poEntity._CUSER_ID)
            R_Utility.R_SetStreamingContext("cCompanyId", poEntity._CCOMPANY_ID)

            loRtn = loServiceStream.getUserMenuList()
            loStreaming = R_StreamUtility(Of UserMenuDTOnon).ReadFromMessage(loRtn)

            For Each loDto As UserMenuDTOnon In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New UserMenuDTO With {._CMENU_ID = loDto.CMENU_ID,
                                                           ._CMENU_NAME = loDto.CMENU_NAME})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub rtnPopup_R_SetPopUpResult(ByRef poEntityResult As Object) Handles rtnPopup.R_SetPopUpResult
        poEntityResult = CType(bsGvMenu.List, List(Of UserMenuDTO)) _
            .Select(Function(x) New UserMenuDTO() _
                        With {._CMENU_ID = x._CMENU_ID,
                              ._CMENU_NAME = x._CMENU_NAME,
                              ._CCOMPANY_ID_FROM = cmbCompanyFrom.SelectedValue}).ToList()
    End Sub
End Class
