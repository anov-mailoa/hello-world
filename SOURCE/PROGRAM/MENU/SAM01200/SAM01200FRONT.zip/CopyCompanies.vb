﻿Imports R_FrontEnd
Imports SAM01200Front.SAM01200ServiceRef
Imports SAM01200Front.SAM01200StreamingServiceRef
Imports SAM01200Front.UserCompanyServiceRef
Imports SAM01200Front.UserMenuServiceRef
Imports R_Common
Imports System.ServiceModel.Channels
Imports ClientHelper

Public Class CopyCompanies

#Region " VARIABLE "
    Dim C_ServiceName As String = "SAM01200Service/SAM01200Service.svc"
    Dim C_ServiceNameStream As String = "SAM01200Service/SAM01200StreamingService/SAM01200StreamingService.svc"
    Dim C_ServiceNameCompany As String = "SAM01200Service/UserCompanyService/UserCompanyService.svc"
    Dim C_ServiceNameMenu As String = "SAM01200Service/UserMenuService/UserMenuService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
#End Region

    Private Sub CopyCompanies_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim loService As SAM01200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01200Service, SAM01200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception()

        Try
            With CType(poParameter, SAM01200UserDTO)
                txtUserId.Text = ._CUSER_ID
                txtUserName.Text = ._CUSER_NAME

                bsCmbUser.DataSource = loService.getCmbCompanyCopy(._CUSER_ID)
                loService.Close()
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub cmbUserFrom_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cmbUserFrom.SelectedValueChanged
        If cmbUserFrom.SelectedIndex <> -1 Then
            gvCompany.R_RefreshGrid(CType(bsCmbUser.Current, cmbDTO)._CID)
        End If
    End Sub

    Private Sub gvCompany_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvCompany.R_ServiceGetListRecord
        Dim loServiceStream As SAM01200StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ISAM01200StreamingService, SAM01200StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loEx As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CompanyCopyDTO)
        Dim loListEntity As New List(Of CompanyCopyDTO)

        Try
            R_Utility.R_SetStreamingContext("cUserId", poEntity)

            loRtn = loServiceStream.getCompanyCopyList()
            loStreaming = R_StreamUtility(Of CompanyCopyDTO).ReadFromMessage(loRtn)

            For Each loDto As CompanyCopyDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub rtnPopup_R_SetPopUpResult(ByRef poEntityResult As Object) Handles rtnPopup.R_SetPopUpResult
        poEntityResult = CType(bsGvCompany.List, List(Of CompanyCopyDTO)) _
            .Select(Function(x) New CompanyCopyDTO() _
                        With {.CCOMPANY_ID = x.CCOMPANY_ID,
                              .CCOMPANY_NAME = x.CCOMPANY_NAME,
                                .LTIME_LIMITATION = x.LTIME_LIMITATION,
                                .CCULTURE_ID = x.CCULTURE_ID,
                                .CCULTURE_FORMAT = x.CCULTURE_FORMAT,
                                .CSTART_DATE = x.CSTART_DATE,
                              .CEND_DATE = x.CEND_DATE,
                              .IUSER_LEVEL = x.IUSER_LEVEL,
                              .LINCLUDE_MENU = cbIncludeMenu.Checked,
                              .CUSER_ID_FROM = cmbUserFrom.SelectedValue}).ToList()
    End Sub
End Class
