﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CopyMenu
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.cmbCompanyFrom = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsCmbCompany = New System.Windows.Forms.BindingSource(Me.components)
        Me.R_RadLabel3 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtCompName = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.R_RadLabel2 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.rtnPopup = New R_FrontEnd.R_ReturnPopUp()
        Me.txtUserName = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtUserId = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.R_RadLabel1 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvMenu = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvMenu = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridMenu = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.txtCompId = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtCompanyName = New R_FrontEnd.R_RadTextBox(Me.components)
        CType(Me.cmbCompanyFrom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsCmbCompany, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCompName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtUserName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtUserId, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvMenu.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCompId, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCompanyName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmbCompanyFrom
        '
        Me.cmbCompanyFrom.DataSource = Me.bsCmbCompany
        Me.cmbCompanyFrom.DisplayMember = "_CID"
        Me.cmbCompanyFrom.Location = New System.Drawing.Point(129, 63)
        Me.cmbCompanyFrom.Name = "cmbCompanyFrom"
        Me.cmbCompanyFrom.R_ConductorGridSource = Nothing
        Me.cmbCompanyFrom.R_ConductorSource = Nothing
        Me.cmbCompanyFrom.Size = New System.Drawing.Size(157, 20)
        Me.cmbCompanyFrom.TabIndex = 33
        Me.cmbCompanyFrom.ValueMember = "_CID"
        '
        'bsCmbCompany
        '
        Me.bsCmbCompany.DataSource = GetType(SAM01200Front.SAM01200ServiceRef.cmbDTO)
        '
        'R_RadLabel3
        '
        Me.R_RadLabel3.AutoSize = False
        Me.R_RadLabel3.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel3.Location = New System.Drawing.Point(21, 63)
        Me.R_RadLabel3.Name = "R_RadLabel3"
        Me.R_RadLabel3.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel3.R_ResourceId = "_FromCompany"
        Me.R_RadLabel3.Size = New System.Drawing.Size(85, 18)
        Me.R_RadLabel3.TabIndex = 31
        Me.R_RadLabel3.Text = "From Company"
        '
        'txtCompName
        '
        Me.txtCompName.Enabled = False
        Me.txtCompName.Location = New System.Drawing.Point(292, 38)
        Me.txtCompName.Name = "txtCompName"
        Me.txtCompName.R_ConductorGridSource = Nothing
        Me.txtCompName.R_ConductorSource = Nothing
        Me.txtCompName.R_UDT = Nothing
        Me.txtCompName.Size = New System.Drawing.Size(333, 20)
        Me.txtCompName.TabIndex = 30
        '
        'R_RadLabel2
        '
        Me.R_RadLabel2.AutoSize = False
        Me.R_RadLabel2.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel2.Location = New System.Drawing.Point(21, 39)
        Me.R_RadLabel2.Name = "R_RadLabel2"
        Me.R_RadLabel2.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel2.R_ResourceId = "_Company"
        Me.R_RadLabel2.Size = New System.Drawing.Size(61, 18)
        Me.R_RadLabel2.TabIndex = 29
        Me.R_RadLabel2.Text = "Company"
        '
        'rtnPopup
        '
        Me.rtnPopup.Location = New System.Drawing.Point(642, 292)
        Me.rtnPopup.Name = "rtnPopup"
        Me.rtnPopup.Size = New System.Drawing.Size(162, 31)
        Me.rtnPopup.TabIndex = 28
        '
        'txtUserName
        '
        Me.txtUserName.Enabled = False
        Me.txtUserName.Location = New System.Drawing.Point(292, 15)
        Me.txtUserName.Name = "txtUserName"
        Me.txtUserName.R_ConductorGridSource = Nothing
        Me.txtUserName.R_ConductorSource = Nothing
        Me.txtUserName.R_UDT = Nothing
        Me.txtUserName.Size = New System.Drawing.Size(333, 20)
        Me.txtUserName.TabIndex = 27
        '
        'txtUserId
        '
        Me.txtUserId.Enabled = False
        Me.txtUserId.Location = New System.Drawing.Point(129, 15)
        Me.txtUserId.Name = "txtUserId"
        Me.txtUserId.R_ConductorGridSource = Nothing
        Me.txtUserId.R_ConductorSource = Nothing
        Me.txtUserId.R_UDT = Nothing
        Me.txtUserId.Size = New System.Drawing.Size(157, 20)
        Me.txtUserId.TabIndex = 26
        '
        'R_RadLabel1
        '
        Me.R_RadLabel1.AutoSize = False
        Me.R_RadLabel1.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel1.Location = New System.Drawing.Point(21, 15)
        Me.R_RadLabel1.Name = "R_RadLabel1"
        Me.R_RadLabel1.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel1.R_ResourceId = "_User"
        Me.R_RadLabel1.Size = New System.Drawing.Size(61, 18)
        Me.R_RadLabel1.TabIndex = 25
        Me.R_RadLabel1.Text = "User"
        '
        'gvMenu
        '
        Me.gvMenu.Location = New System.Drawing.Point(12, 93)
        '
        '
        '
        Me.gvMenu.MasterTemplate.AllowAddNewRow = False
        Me.gvMenu.MasterTemplate.AllowDeleteRow = False
        Me.gvMenu.MasterTemplate.AllowEditRow = False
        Me.gvMenu.MasterTemplate.AutoGenerateColumns = False
        Me.gvMenu.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn1.FieldName = "_CMENU_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CMENU_ID"
        R_GridViewTextBoxColumn1.IsAutoGenerated = True
        R_GridViewTextBoxColumn1.Name = "_CMENU_ID"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CMENU_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 386
        R_GridViewTextBoxColumn2.FieldName = "_CMENU_NAME"
        R_GridViewTextBoxColumn2.HeaderText = "_CMENU_NAME"
        R_GridViewTextBoxColumn2.IsAutoGenerated = True
        R_GridViewTextBoxColumn2.Name = "_CMENU_NAME"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CMENU_NAME"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 387
        Me.gvMenu.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2})
        Me.gvMenu.MasterTemplate.DataSource = Me.bsGvMenu
        Me.gvMenu.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvMenu.MasterTemplate.EnableFiltering = True
        Me.gvMenu.MasterTemplate.EnableGrouping = False
        Me.gvMenu.MasterTemplate.ShowGroupedColumns = True
        Me.gvMenu.Name = "gvMenu"
        Me.gvMenu.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvMenu.R_ConductorGridSource = Me.conGridMenu
        Me.gvMenu.R_ConductorSource = Nothing
        Me.gvMenu.Size = New System.Drawing.Size(792, 193)
        Me.gvMenu.TabIndex = 24
        Me.gvMenu.Text = "R_RadGridView1"
        '
        'bsGvMenu
        '
        Me.bsGvMenu.DataSource = GetType(SAM01200Front.UserMenuServiceRef.UserMenuDTO)
        '
        'conGridMenu
        '
        Me.conGridMenu.R_ConductorParent = Nothing
        Me.conGridMenu.R_IsHeader = True
        Me.conGridMenu.R_RadGroupBox = Nothing
        '
        'txtCompId
        '
        Me.txtCompId.Enabled = False
        Me.txtCompId.Location = New System.Drawing.Point(129, 38)
        Me.txtCompId.Name = "txtCompId"
        Me.txtCompId.R_ConductorGridSource = Nothing
        Me.txtCompId.R_ConductorSource = Nothing
        Me.txtCompId.R_UDT = Nothing
        Me.txtCompId.Size = New System.Drawing.Size(157, 20)
        Me.txtCompId.TabIndex = 34
        '
        'txtCompanyName
        '
        Me.txtCompanyName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.bsCmbCompany, "_CDESC", True))
        Me.txtCompanyName.Enabled = False
        Me.txtCompanyName.Location = New System.Drawing.Point(292, 62)
        Me.txtCompanyName.Name = "txtCompanyName"
        Me.txtCompanyName.R_ConductorGridSource = Nothing
        Me.txtCompanyName.R_ConductorSource = Nothing
        Me.txtCompanyName.R_UDT = Nothing
        Me.txtCompanyName.Size = New System.Drawing.Size(333, 20)
        Me.txtCompanyName.TabIndex = 35
        '
        'CopyMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(816, 327)
        Me.Controls.Add(Me.txtCompanyName)
        Me.Controls.Add(Me.txtCompId)
        Me.Controls.Add(Me.cmbCompanyFrom)
        Me.Controls.Add(Me.R_RadLabel3)
        Me.Controls.Add(Me.txtCompName)
        Me.Controls.Add(Me.R_RadLabel2)
        Me.Controls.Add(Me.rtnPopup)
        Me.Controls.Add(Me.txtUserName)
        Me.Controls.Add(Me.txtUserId)
        Me.Controls.Add(Me.R_RadLabel1)
        Me.Controls.Add(Me.gvMenu)
        Me.Name = "CopyMenu"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "Copy Menus Assignment"
        CType(Me.cmbCompanyFrom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsCmbCompany, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCompName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtUserName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtUserId, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvMenu.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvMenu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvMenu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridMenu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCompId, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCompanyName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmbCompanyFrom As R_FrontEnd.R_RadDropDownList
    Friend WithEvents R_RadLabel3 As R_FrontEnd.R_RadLabel
    Friend WithEvents txtCompName As R_FrontEnd.R_RadTextBox
    Friend WithEvents R_RadLabel2 As R_FrontEnd.R_RadLabel
    Friend WithEvents rtnPopup As R_FrontEnd.R_ReturnPopUp
    Friend WithEvents txtUserName As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtUserId As R_FrontEnd.R_RadTextBox
    Friend WithEvents R_RadLabel1 As R_FrontEnd.R_RadLabel
    Friend WithEvents gvMenu As R_FrontEnd.R_RadGridView
    Friend WithEvents txtCompId As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtCompanyName As R_FrontEnd.R_RadTextBox
    Friend WithEvents bsGvMenu As System.Windows.Forms.BindingSource
    Friend WithEvents conGridMenu As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsCmbCompany As System.Windows.Forms.BindingSource

End Class
