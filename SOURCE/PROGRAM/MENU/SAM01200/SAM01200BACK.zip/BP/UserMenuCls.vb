﻿Imports R_Common
Imports R_BackEnd
Imports System.Data.Common
Imports System.Transactions
Imports SAM01200Common

Public Class UserMenuCls
    Inherits R_BusinessObject(Of UserMenuDTO)

    Implements R_IBatchProcess

    Protected Overrides Sub R_Deleting(poEntity As UserMenuDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loRtnMenuProgram As New List(Of SAM01200MenuProgramDTO)

        Try
            loConn = loDb.GetConnection()

            Using TransScope As New TransactionScope(TransactionScopeOption.Required)
                lcQuery = "DELETE SAM_USER_PROGRAM "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' AND CUSER_ID = '{1}' AND CMENU_ID = '{2}' "
                lcQuery = String.Format(lcQuery, poEntity.CCOMPANY_ID.Trim, poEntity.CUSER_ID.Trim, poEntity.CMENU_ID.Trim)

                loDb.SqlExecNonQuery(lcQuery, loConn, False)

                lcQuery = "DELETE FROM SAM_USER_MENU "
                lcQuery += "WHERE CUSER_ID = '{0}' AND CCOMPANY_ID = '{1}' AND CMENU_ID = '{2}'"
                lcQuery = String.Format(lcQuery, poEntity.CUSER_ID, poEntity.CCOMPANY_ID, poEntity.CMENU_ID)

                loDb.SqlExecNonQuery(lcQuery, loConn, False)

                'select all program on sam_menu_program
                lcQuery = "SELECT A.CPROGRAM_ID "
                lcQuery += "FROM SAM_MENU_PROGRAM A (NOLOCK) "
                lcQuery += "WHERE A.CCOMPANY_ID = '{0}' AND A.CMENU_ID = '{1}'"
                lcQuery = String.Format(lcQuery, poEntity.CCOMPANY_ID, poEntity.CMENU_ID)
                loRtnMenuProgram = loDb.SqlExecObjectQuery(Of SAM01200MenuProgramDTO)(lcQuery, loConn, False)

                For Each prog As SAM01200MenuProgramDTO In loRtnMenuProgram
                    lcQuery = "DELETE FROM SAM_USER_PROGRAM "
                    lcQuery += "WHERE CUSER_ID = '{0}' AND CCOMPANY_ID = '{1}' AND CMENU_ID = 'FAV' AND CSUB_MENU_ID = '{2}'"
                    lcQuery = String.Format(lcQuery, poEntity.CUSER_ID, poEntity.CCOMPANY_ID, prog.CPROGRAM_ID)

                    loDb.SqlExecNonQuery(lcQuery, loConn, False)
                Next

                TransScope.Complete()
            End Using

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As UserMenuDTO) As UserMenuDTO
        Dim lcQuery As String
        Dim loResult As UserMenuDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT A.CMENU_ID, B.CMENU_NAME, "
            lcQuery += "A.CUPDATE_BY, A.DUPDATE_DATE, A.CCREATE_BY, A.DCREATE_DATE "
            lcQuery += "FROM SAM_USER_MENU A (NOLOCK) "
            lcQuery += "INNER JOIN SAM_MENU B (NOLOCK) "
            lcQuery += "ON B.CMENU_ID = A.CMENU_ID "
            lcQuery += "WHERE A.CUSER_ID = '{0}' AND A.CCOMPANY_ID = '{1}' AND A.CMENU_ID = '{2}'"
            lcQuery = String.Format(lcQuery, poEntity.CUSER_ID, poEntity.CCOMPANY_ID, poEntity.CMENU_ID)

            loResult = loDb.SqlExecObjectQuery(Of UserMenuDTO)(lcQuery).FirstOrDefault
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As UserMenuDTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As UserMenuDTO
        Dim loRtnFav As New UserMenuDTO

        Try
            loConn = loDb.GetConnection()

            Using TransScope As New TransactionScope(TransactionScopeOption.Required)
                If poCRUDMode = eCRUDMode.AddMode Then
                    lcQuery = "SELECT A.CMENU_ID, B.CMENU_NAME, "
                    lcQuery += "A.CUPDATE_BY, A.DUPDATE_DATE, A.CCREATE_BY, A.DCREATE_DATE "
                    lcQuery += "FROM SAM_USER_MENU A (NOLOCK) "
                    lcQuery += "INNER JOIN SAM_MENU B (NOLOCK) "
                    lcQuery += "ON B.CMENU_ID = A.CMENU_ID "
                    lcQuery += "WHERE A.CUSER_ID = '{0}' AND A.CCOMPANY_ID = '{1}' AND A.CMENU_ID = '{2}'"
                    lcQuery = String.Format(lcQuery, poNewEntity.CUSER_ID, poNewEntity.CCOMPANY_ID, poNewEntity.CMENU_ID)
                    loResult = loDb.SqlExecObjectQuery(Of UserMenuDTO)(lcQuery, loConn, False).FirstOrDefault

                    If loResult IsNot Nothing Then
                        Throw New Exception("Menu Id " + poNewEntity.CMENU_ID.Trim + " Already Exist")
                    End If

                    'save to SAM_USER_MENU
                    lcQuery = "INSERT INTO SAM_USER_MENU (CUSER_ID, CCOMPANY_ID, CMENU_ID, CCREATE_BY, DCREATE_DATE) "
                    lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', {4}) "
                    lcQuery = String.Format(lcQuery, poNewEntity.CUSER_ID, poNewEntity.CCOMPANY_ID, poNewEntity.CMENU_ID, poNewEntity.CUSER_ID, getDate(poNewEntity.DDATE))
                    loDb.SqlExecNonQuery(lcQuery, loConn, False)

                    'cek menu FAV in SAM_USER_PROGRAM
                    lcQuery = "SELECT A.CMENU_ID "
                    lcQuery += "FROM SAM_USER_PROGRAM A (NOLOCK) "
                    lcQuery += "WHERE A.CUSER_ID = '{0}' AND A.CCOMPANY_ID = '{1}' AND A.CMENU_ID = 'FAV'"
                    lcQuery = String.Format(lcQuery, poNewEntity.CUSER_ID, poNewEntity.CCOMPANY_ID)
                    loRtnFav = loDb.SqlExecObjectQuery(Of UserMenuDTO)(lcQuery, loConn, False).FirstOrDefault

                    If loRtnFav Is Nothing Then
                        'save default menu FAV to SAM_USER_PROGRAM
                        lcQuery = "INSERT INTO SAM_USER_PROGRAM (CCOMPANY_ID, CUSER_ID, CMENU_ID, CSUB_MENU_TYPE, CSUB_MENU_ID, "
                        lcQuery += "CSUB_MENU_NAME, IGROUP_INDEX, IROW_INDEX, ICOLUMN_INDEX, LFAVORITE, IFAVORITE_INDEX, CPARENT_SUB_MENU_ID, "
                        lcQuery += "ILEVEL, CCREATE_BY, DCREATE_DATE) "
                        lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}', '{13}', {14}) "
                        lcQuery = String.Format(lcQuery, poNewEntity.CCOMPANY_ID, poNewEntity.CUSER_ID, "FAV", _
                                                "G", "G001", "Favourites", 0, 0, 0, 0, 0, "ROOT", 1, poNewEntity.CUSER_ID, getDate(poNewEntity.DDATE))
                        loDb.SqlExecNonQuery(lcQuery, loConn, False)
                    End If

                    'get all menu and program
                    Dim loMenuProgramList As List(Of SAM01200MenuProgramDTO)

                    lcQuery = "SELECT A.CCOMPANY_ID, A.CMENU_ID, A.CPROGRAM_ID, B.CPROGRAM_NAME "
                    lcQuery += "FROM SAM_MENU_PROGRAM A, SAM_PROGRAM B "
                    lcQuery += "WHERE  A.CCOMPANY_ID = '{0}' AND A.CMENU_ID = '{1}' AND A.CPROGRAM_ID = B.CPROGRAM_ID"
                    lcQuery = String.Format(lcQuery, poNewEntity.CCOMPANY_ID.Trim, poNewEntity.CMENU_ID.Trim)
                    loMenuProgramList = loDb.SqlExecObjectQuery(Of SAM01200MenuProgramDTO)(lcQuery, loConn, False)

                    'filter all program by module
                    Dim loMenuProgList As New List(Of SAM01200MenuProgramDTO)
                    Dim loMenuGroupList As New List(Of GroupDTO)
                    Dim iGrpIndex As Integer = 0

                    'get all group
                    loMenuGroupList = getGroup()

                    For Each oGroup As GroupDTO In loMenuGroupList
                        If oGroup.CGROUP_ID = "MASTER" Then 'get all Master program
                            loMenuProgList = loMenuProgramList.Where(Function(x) x.CPROGRAM_ID.Substring(2, 1) = "M").Select(Function(x) x).ToList
                        ElseIf oGroup.CGROUP_ID = "TRANS" Then
                            loMenuProgList = loMenuProgramList.Where(Function(x) x.CPROGRAM_ID.Substring(2, 1) = "T").Select(Function(x) x).ToList
                        ElseIf oGroup.CGROUP_ID = "INQUI" Then
                            loMenuProgList = loMenuProgramList.Where(Function(x) x.CPROGRAM_ID.Substring(2, 1) = "I").Select(Function(x) x).ToList
                        ElseIf oGroup.CGROUP_ID = "BATCH" Then
                            loMenuProgList = loMenuProgramList.Where(Function(x) x.CPROGRAM_ID.Substring(2, 1) = "B").Select(Function(x) x).ToList
                        ElseIf oGroup.CGROUP_ID = "REPORT" Then
                            loMenuProgList = loMenuProgramList.Where(Function(x) x.CPROGRAM_ID.Substring(2, 1) = "R").Select(Function(x) x).ToList
                        End If

                        If loMenuProgList.Count > 0 Then
                            'save group
                            lcQuery = "INSERT INTO SAM_USER_PROGRAM (CCOMPANY_ID, CUSER_ID, CMENU_ID, CSUB_MENU_TYPE, CSUB_MENU_ID, "
                            lcQuery += "CSUB_MENU_NAME, IGROUP_INDEX, IROW_INDEX, ICOLUMN_INDEX, LFAVORITE, IFAVORITE_INDEX, CPARENT_SUB_MENU_ID, "
                            lcQuery += "ILEVEL, CCREATE_BY, DCREATE_DATE) "
                            lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}', '{13}', {14}) "
                            lcQuery = String.Format(lcQuery, poNewEntity.CCOMPANY_ID, poNewEntity.CUSER_ID, poNewEntity.CMENU_ID, _
                                                    "G", oGroup.CGROUP_ID, oGroup.CGROUP_NAME, iGrpIndex, 0, 0, 0, 0, poNewEntity.CMENU_ID, 1, poNewEntity.CUSER_ID, getDate(poNewEntity.DDATE))
                            loDb.SqlExecNonQuery(lcQuery, loConn, False)

                            Dim lnRowIndex As Integer = 0
                            Dim lnColumnIndex As Integer = 0
                            For Each loMenuProgram As SAM01200MenuProgramDTO In loMenuProgList
                                lcQuery = "INSERT INTO SAM_USER_PROGRAM "
                                lcQuery += "(CCOMPANY_ID, CUSER_ID, CMENU_ID, CSUB_MENU_TYPE, CSUB_MENU_ID, CSUB_MENU_NAME, IGROUP_INDEX, IROW_INDEX, "
                                lcQuery += "ICOLUMN_INDEX, LFAVORITE, IFAVORITE_INDEX, CPARENT_SUB_MENU_ID, ILEVEL, CCREATE_BY, DCREATE_DATE)"
                                lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}', "
                                lcQuery += "'{13}', {14})"
                                lcQuery = String.Format(lcQuery, poNewEntity.CCOMPANY_ID.Trim, poNewEntity.CUSER_ID.Trim, poNewEntity.CMENU_ID.Trim, _
                                                        "P", loMenuProgram.CPROGRAM_ID, loMenuProgram.CPROGRAM_NAME, iGrpIndex, lnRowIndex.ToString.Trim, lnColumnIndex.ToString.Trim, _
                                                        0, 0, oGroup.CGROUP_ID, 1, poNewEntity.CUSER_ID.Trim, getDate(poNewEntity.DDATE))

                                lnRowIndex = lnRowIndex + 1
                                If lnRowIndex = 4 Then
                                    lnRowIndex = 0
                                    lnColumnIndex = lnColumnIndex + 1
                                End If

                                loDb.SqlExecNonQuery(lcQuery, loConn, False)
                            Next
                            iGrpIndex += 1
                        End If
                    Next
                End If

                TransScope.Complete()
            End Using
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Sub R_BatchProcess(poBatchProcessPar As R_Common.R_BatchProcessPar) Implements R_Common.R_IBatchProcess.R_BatchProcess
        Dim loEx As New R_Exception()
        Dim loObject As List(Of BatchMenuDTO)
        Dim loDb As New R_Db
        Dim lcQuery As String
        Dim loResult As UserMenuDTO
        Dim loConn As DbConnection
        Dim CUSER_ID As String
        Dim CUSER_ID_LOGIN As String
        Dim DDATE As DateTime
        Dim countLoop As Integer = 0
        Dim CCOMP_ID As String
        Dim CCOMP_ID_LOGIN As String

        Try
            loObject = R_Utility.Deserialize(poBatchProcessPar.BigObject)
            DDATE = poBatchProcessPar.UserParameters.Where(Function(x) x.Key.Equals("DDATE")).FirstOrDefault.Value
            CUSER_ID = poBatchProcessPar.UserParameters.Where(Function(x) x.Key.Equals("CUSER_ID")).FirstOrDefault.Value
            CCOMP_ID = poBatchProcessPar.UserParameters.Where(Function(x) x.Key.Equals("CCOMPANY_ID")).FirstOrDefault.Value
            CCOMP_ID_LOGIN = poBatchProcessPar.Key.COMPANY_ID
            CUSER_ID_LOGIN = poBatchProcessPar.Key.USER_ID
            loConn = loDb.GetConnection()

            Using TransScope As New TransactionScope(TransactionScopeOption.Required)
                For Each save As BatchMenuDTO In loObject
                    loConn = loDb.GetConnection()

                    lcQuery = "exec RSP_WriteUploadProcessStatus '{0}', '{1}', '{2}', '{3}', '{4}'"
                    lcQuery = String.Format(lcQuery, CCOMP_ID, CUSER_ID, poBatchProcessPar.Key.KEY_GUID.Trim, countLoop, "Save " + save.CMENU_ID)
                    loDb.SqlExecNonQuery(lcQuery, loConn, False)

                    lcQuery = "SELECT A.CMENU_ID, B.CMENU_NAME, "
                    lcQuery += "A.CUPDATE_BY, A.DUPDATE_DATE, A.CCREATE_BY, A.DCREATE_DATE "
                    lcQuery += "FROM SAM_USER_MENU A (NOLOCK) "
                    lcQuery += "INNER JOIN SAM_MENU B (NOLOCK) "
                    lcQuery += "ON B.CMENU_ID = A.CMENU_ID "
                    lcQuery += "WHERE A.CUSER_ID = '{0}' AND A.CCOMPANY_ID = '{1}' AND A.CMENU_ID = '{2}'"
                    lcQuery = String.Format(lcQuery, CUSER_ID, CCOMP_ID, save.CMENU_ID)

                    loResult = loDb.SqlExecObjectQuery(Of UserMenuDTO)(lcQuery, loConn, False).FirstOrDefault

                    If loResult Is Nothing Then
                        lcQuery = "INSERT INTO SAM_USER_MENU (CUSER_ID, CCOMPANY_ID, CMENU_ID, CCREATE_BY, DCREATE_DATE) "
                        lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}') "
                        lcQuery = String.Format(lcQuery, CUSER_ID, CCOMP_ID, save.CMENU_ID, CUSER_ID_LOGIN, DDATE)

                        loDb.SqlExecNonQuery(lcQuery, loConn, False)
                    End If

                    countLoop += 1
                Next

                lcQuery = "exec RSP_WriteUploadProcessStatus '{0}', '{1}', '{2}', '{3}', '{4}', '{5}'"
                lcQuery = String.Format(lcQuery, CCOMP_ID, CUSER_ID, poBatchProcessPar.Key.KEY_GUID.Trim, countLoop, "Save Complete", 1)
                loDb.SqlExecNonQuery(lcQuery, loConn, False)

                TransScope.Complete()
            End Using

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Private Function getDate(pcDate As String) As String
        Return String.Format("CONVERT(DATETIME, '{0}')", pcDate)
    End Function

    Private Function getGroup() As List(Of GroupDTO)
        Dim loRtn As New List(Of GroupDTO)

        loRtn.Add(New GroupDTO With {.CGROUP_ID = "MASTER",
                                     .CGROUP_NAME = "Master"})

        loRtn.Add(New GroupDTO With {.CGROUP_ID = "TRANS",
                                     .CGROUP_NAME = "Transaction"})

        loRtn.Add(New GroupDTO With {.CGROUP_ID = "INQUI",
                                     .CGROUP_NAME = "Inquiry"})

        loRtn.Add(New GroupDTO With {.CGROUP_ID = "BATCH",
                                     .CGROUP_NAME = "Batch"})

        loRtn.Add(New GroupDTO With {.CGROUP_ID = "REPORT",
                                     .CGROUP_NAME = "Report"})

        Return loRtn
    End Function
End Class
