﻿Imports R_Common
Imports R_BackEnd
Imports System.Data.Common
Imports System.Transactions
Imports R_EmailEngine

Public Class SAM01200Cls
    Inherits R_BusinessObject(Of SAM01200UserDTO)

    Private lcRandomStr As String

    Protected Overrides Sub R_Deleting(poEntity As SAM01200UserDTO)
        Dim loEx As New R_Exception()

        Try
            deleteUSER(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As SAM01200UserDTO) As SAM01200UserDTO
        Dim lcQuery As String
        Dim loResult As SAM01200UserDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "SAM_USER (NOLOCK) "
            lcQuery += "WHERE CUSER_ID = '{0}'"
            lcQuery = String.Format(lcQuery, poEntity.CUSER_ID)

            loResult = loDb.SqlExecObjectQuery(Of SAM01200UserDTO)(lcQuery).FirstOrDefault

            If String.IsNullOrWhiteSpace(lcRandomStr) = False Then
                loResult.CPWD = lcRandomStr
            End If
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As SAM01200UserDTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        
        Try
            SaveSAM_USER(poNewEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        
        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Function getUserList() As List(Of SAM01200UserDTOnon)
        Dim lcQuery As String
        Dim loResult As List(Of SAM01200UserDTOnon)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "SAM_USER (NOLOCK)"
            lcQuery = String.Format(lcQuery)

            loResult = loDb.SqlExecObjectQuery(Of SAM01200UserDTOnon)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function getUserCompanyList(pcUserId As String) As List(Of UserCompanyDTOnon)
        Dim lcQuery As String
        Dim loResult As List(Of UserCompanyDTOnon)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT A.CCOMPANY_ID, B.CCOMPANY_NAME, A.LTIME_LIMITATION, A.CSTART_DATE, A.CEND_DATE, A.IUSER_LEVEL, "
            lcQuery += "A.CUPDATE_BY, A.DUPDATE_DATE, A.CCREATE_BY, A.DCREATE_DATE, A.LENABLE_BROADCAST "
            lcQuery += "FROM SAM_USER_COMPANY A (NOLOCK) "
            lcQuery += "INNER JOIN SAM_COMPANIES B (NOLOCK) "
            lcQuery += "ON B.CCOMPANY_ID = A.CCOMPANY_ID "
            lcQuery += "WHERE CUSER_ID = '{0}'"
            lcQuery = String.Format(lcQuery, pcUserId)

            loResult = loDb.SqlExecObjectQuery(Of UserCompanyDTOnon)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function getUserMenuList(pcUserId As String, pcCompId As String) As List(Of UserMenuDTOnon)
        Dim lcQuery As String
        Dim loResult As List(Of UserMenuDTOnon)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT A.CMENU_ID, B.CMENU_NAME, "
            lcQuery += "A.CUPDATE_BY, A.DUPDATE_DATE, A.CCREATE_BY, A.DCREATE_DATE "
            lcQuery += "FROM SAM_USER_MENU A (NOLOCK) "
            lcQuery += "INNER JOIN SAM_MENU B (NOLOCK) "
            lcQuery += "ON B.CMENU_ID = A.CMENU_ID AND B.CCOMPANY_ID = A.CCOMPANY_ID "
            lcQuery += "WHERE A.CUSER_ID = '{0}' AND A.CCOMPANY_ID = '{1}'"
            lcQuery = String.Format(lcQuery, pcUserId, pcCompId)

            loResult = loDb.SqlExecObjectQuery(Of UserMenuDTOnon)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function getCmbCompany() As List(Of cmbDTO)
        Dim lcQuery As String
        Dim loResult As List(Of cmbDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT CCOMPANY_ID AS CID, CCOMPANY_NAME AS CDESC "
            lcQuery += "FROM SAM_COMPANIES (NOLOCK)"
            lcQuery = String.Format(lcQuery)

            loResult = loDb.SqlExecObjectQuery(Of cmbDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function getCmbMenu(pcCompId As String) As List(Of cmbDTO)
        Dim lcQuery As String
        Dim loResult As List(Of cmbDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT CMENU_ID AS CID, CMENU_NAME AS CDESC "
            lcQuery += "FROM SAM_MENU (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' AND CMENU_ID <> 'FAV'"
            lcQuery = String.Format(lcQuery, pcCompId)

            loResult = loDb.SqlExecObjectQuery(Of cmbDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function getCompanyCopyList(pcUserId As String) As List(Of CompanyCopyDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CompanyCopyDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT B.CCOMPANY_ID, C.CCOMPANY_NAME, B.LTIME_LIMITATION, "
            lcQuery += "A.CCULTURE_ID, A.CCULTURE_FORMAT, B.CSTART_DATE, B.CEND_DATE, B.IUSER_LEVEL "
            lcQuery += "FROM SAM_USER A (NOLOCK) "
            lcQuery += "INNER JOIN SAM_USER_COMPANY B (NOLOCK) "
            lcQuery += "ON B.CUSER_ID = A.CUSER_ID "
            lcQuery += "INNER JOIN SAM_COMPANIES C (NOLOCK) "
            lcQuery += "ON C.CCOMPANY_ID = B.CCOMPANY_ID "
            lcQuery += "WHERE A.CUSER_ID = '{0}'"
            lcQuery = String.Format(lcQuery, pcUserId)

            loResult = loDb.SqlExecObjectQuery(Of CompanyCopyDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function getMenuCopyList(pcCompId As String) As List(Of UserMenuDTOnon)
        Dim lcQuery As String
        Dim loResult As List(Of UserMenuDTOnon)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT A.CMENU_ID, B.CMENU_NAME "
            lcQuery += "FROM SAM_USER_MENU A (NOLOCK) "
            lcQuery += "INNER JOIN SAM_MENU B (NOLOCK) "
            lcQuery += "ON B.CMENU_ID = A.CMENU_ID AND B.CCOMPANY_ID = A.CCOMPANY_ID "
            lcQuery += "WHERE A.CCOMPANY_ID = '{0}'"
            lcQuery = String.Format(lcQuery, pcCompId)

            loResult = loDb.SqlExecObjectQuery(Of UserMenuDTOnon)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function getCmbCompanyCopy(pcUserId As String) As List(Of cmbDTO)
        Dim lcQuery As String
        Dim loResult As List(Of cmbDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT CUSER_ID AS CID, CUSER_NAME AS CDESC "
            lcQuery += "FROM SAM_USER (NOLOCK) "
            lcQuery += "WHERE CUSER_ID != '{0}'"
            lcQuery = String.Format(lcQuery, pcUserId)

            loResult = loDb.SqlExecObjectQuery(Of cmbDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function getCmbMenuCopy(pcCompId As String, pcUserId As String) As List(Of cmbDTO)
        Dim lcQuery As String
        Dim loResult As List(Of cmbDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT A.CCOMPANY_ID AS CID, B.CCOMPANY_NAME AS CDESC "
            lcQuery += "FROM SAM_USER_COMPANY A (NOLOCK) "
            lcQuery += "INNER JOIN SAM_COMPANIES B (NOLOCK) "
            lcQuery += "ON B.CCOMPANY_ID = A.CCOMPANY_ID "
            lcQuery += "WHERE A.CCOMPANY_ID != '{0}' AND A.CUSER_ID != '{1}'"
            lcQuery = String.Format(lcQuery, pcCompId, pcUserId)

            loResult = loDb.SqlExecObjectQuery(Of cmbDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function resetPass(poParam As SAM01200UserDTO) As String
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As SAM01200UserDTO
        Dim lcPass As String
        Dim loPar As DbParameter
        Dim loCmd As DbCommand
        Dim loSender As R_Sender

        Try
            Dim cParameterValue As String
            cParameterValue = getParamValue()

            Using TransScope As New TransactionScope(TransactionScopeOption.Required)
                Dim cRandomPass As String = GenerateRandomString(8, False)

                loConn = loDb.GetConnection()

                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "SAM_USER (NOLOCK) "
                lcQuery += "WHERE CUSER_ID = '{0}'"
                lcQuery = String.Format(lcQuery, poParam.CUSER_ID)

                loResult = loDb.SqlExecObjectQuery(Of SAM01200UserDTO)(lcQuery, loConn, False).FirstOrDefault
                If loResult Is Nothing Then
                    Throw New Exception("User Id " + poParam.CUSER_ID.Trim + " Already Exist")
                Else
                    lcPass = R_Utility.HashPassword(cRandomPass, poParam.CUSER_ID.ToLower)

                    If cParameterValue = "byuser" Then
                        lcQuery = "UPDATE SAM_USER "
                        lcQuery += "SET "
                        lcQuery += "DLAST_UPDATE_PSWD = @Date, "
                        lcQuery += "CUSER_PASSWORD = '{0}', "
                        lcQuery += "CUPDATE_BY = '{1}', "
                        lcQuery += "DUPDATE_DATE = {3} "
                        lcQuery += "WHERE CUSER_ID = '{2}'"
                        lcQuery = String.Format(lcQuery, lcPass, poParam.CUSER_LOGIN, poParam.CUSER_ID, getDate(poParam.DDATE))

                        loCmd = loDb.GetCommand()
                        loCmd.CommandText = lcQuery
                        loPar = loDb.GetParameter()

                        With loPar
                            .ParameterName = "@Date"
                            .DbType = DbType.Date
                            .Value = DBNull.Value
                        End With
                        loCmd.Parameters.Add(loPar)

                        loDb.SqlExecNonQuery(loConn, loCmd, False)

                    Else
                        lcQuery = "UPDATE SAM_USER_COMPANY "
                        lcQuery += "SET "
                        lcQuery += "DLAST_UPDATE_PSWD = @Date, "
                        lcQuery += "CUSER_PASSWORD = '{0}', "
                        lcQuery += "CUPDATE_BY = '{1}', "
                        lcQuery += "DUPDATE_DATE = {3} "
                        lcQuery += "WHERE CUSER_ID = '{2}' AND CCOMPANY_ID = '{4}'"
                        lcQuery = String.Format(lcQuery, lcPass, poParam.CUSER_LOGIN, poParam.CUSER_ID, getDate(poParam.DDATE), poParam.CCOMPANY_ID)

                        loCmd = loDb.GetCommand()
                        loCmd.CommandText = lcQuery
                        loPar = loDb.GetParameter()

                        With loPar
                            .ParameterName = "@Date"
                            .DbType = DbType.Date
                            .Value = DBNull.Value
                        End With
                        loCmd.Parameters.Add(loPar)

                        loDb.SqlExecNonQuery(loConn, loCmd, False)
                    End If

                    If String.IsNullOrEmpty(poParam.CEMAIL_ID) = False Then
                        lcQuery = "SELECT A.CEMAIL_BODY "
                        lcQuery += "FROM GST_EMAIL_OUTBOX A (NOLOCK) "
                        lcQuery += "WHERE A.CEMAIL_ID = '{0}'"
                        lcQuery = String.Format(lcQuery, poParam.CEMAIL_ID)
                        loResult = loDb.SqlExecObjectQuery(Of SAM01200UserDTO)(lcQuery, loConn, False).FirstOrDefault

                        Dim cNewBody As String

                        If String.IsNullOrEmpty(loResult.CEMAIL_BODY) = False Then
                            cNewBody = String.Format(loResult.CEMAIL_BODY, Nothing, cRandomPass, Nothing)
                        End If

                        lcQuery = "UPDATE GST_EMAIL_OUTBOX "
                        lcQuery += "SET "
                        lcQuery += "LFLAG_ACTIVE = {0}, "
                        lcQuery += "CEMAIL_BODY = '{2}' "
                        lcQuery += "WHERE CEMAIL_ID = '{1}'"
                        lcQuery = String.Format(lcQuery, 1, poParam.CEMAIL_ID, cNewBody)
                        loDb.SqlExecNonQuery(lcQuery, loConn, False)

                        loSender = New R_Sender
                        loSender.R_SendById(poParam.CEMAIL_ID)
                    End If
                End If

                TransScope.Complete()
                Return cRandomPass
            End Using

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Function

#Region "Company Multiple"
    Public Function getCompanyMultiple() As List(Of UserCompanyDTOnon)
        Dim lcQuery As String
        Dim loResult As List(Of UserCompanyDTOnon)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT A.CCOMPANY_ID, A.CCOMPANY_NAME "
            lcQuery += "FROM SAM_COMPANIES A (NOLOCK) "
            lcQuery += "WHERE A.CCOMPANY_ID NOT IN (SELECT CCOMPANY_ID FROM SAM_USER_COMPANY (NOLOCK))"
            lcQuery = String.Format(lcQuery)

            loResult = loDb.SqlExecObjectQuery(Of UserCompanyDTOnon)(lcQuery)

            loResult = loResult.Select(Function(x) New UserCompanyDTOnon With {.CCOMPANY_ID = x.CCOMPANY_ID,
                                                                               .CCOMPANY_NAME = x.CCOMPANY_NAME,
                                                                               .LTIME_LIMITATION = False,
                                                                               .IUSER_LEVEL = 0}).ToList
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function
#End Region

#Region "Menu Multiple"
    Public Function getMenuMultiple(pcCompId As String) As List(Of UserMenuDTOnon)
        Dim lcQuery As String
        Dim loResult As List(Of UserMenuDTOnon)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT CMENU_ID, CMENU_NAME "
            lcQuery += "FROM SAM_MENU (NOLOCK) "
            lcQuery += "WHERE CMENU_ID NOT IN (SELECT B.CMENU_ID FROM SAM_USER_MENU B (NOLOCK)) AND CCOMPANY_ID = '{0}'"
            lcQuery = String.Format(lcQuery, pcCompId)

            loResult = loDb.SqlExecObjectQuery(Of UserMenuDTOnon)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function
#End Region

#Region "Company Copy"

#End Region

    Private Function getDate(pcDate As String) As String
        Return String.Format("CONVERT(DATETIME, '{0}')", pcDate)
    End Function

    Public Function GenerateRandomString(ByRef len As Integer, ByRef upper As Boolean) As String
        Dim rand As New Random()
        Dim allowableChars() As Char = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLOMNOPQRSTUVWXYZ0123456789".ToCharArray()
        Dim final As String = String.Empty
        For i As Integer = 0 To len - 1
            final += allowableChars(rand.Next(allowableChars.Length - 1))
        Next

        Return IIf(upper, final.ToUpper(), final)
    End Function

    Private Function getParamValue() As String
        Dim loRtnParameter As List(Of GST_PARAMETER_DTO)
        Dim loEx As New R_Exception()
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim cParameterValue As String

        Try
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "GST_PARAMETER (NOLOCK) "
            lcQuery = String.Format(lcQuery)
            loRtnParameter = loDb.SqlExecObjectQuery(Of GST_PARAMETER_DTO)(lcQuery)

            cParameterValue = loRtnParameter.Where(Function(x) x.cParameterId = "SecurityAndAccountPolicy").Select(Function(x) x.cParameterValue).FirstOrDefault
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

        Return cParameterValue
    End Function

    Public Sub SliceFiles(pcUpdateBy As String, poSlice As SliceDTO)
        Dim loException As New R_Exception
        Dim loDb As New R_Db()
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcCmd As String

        Try
            loCmd = loDb.GetCommand()
            lcCmd = "insert into GST_SPLIT_UPLOAD(CCOMPANY_ID,CUSER_ID,CKEY_GUID,ISEQ_NO,ODATA) VALUES('{0}','{1}','{2}',{3},@Data)"
            lcCmd = String.Format(lcCmd, poSlice.COMPANY_ID, pcUpdateBy, poSlice.KEY_GUID, poSlice.SEQ_NO.ToString())
            loCmd.CommandText = lcCmd
            loPar = loDb.GetParameter()
            With loPar
                .ParameterName = "@Data"
                .DbType = DbType.Binary
                .Value = IIf(poSlice.DATA Is Nothing, DBNull.Value, poSlice.DATA)
            End With
            loCmd.Parameters.Add(loPar)
            loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd, True)

        Catch ex As Exception
            loException.Add(ex)
        Finally
            If loCmd IsNot Nothing Then
                loCmd.Parameters.Clear()
                loCmd.Connection = Nothing
                loCmd.Dispose()
                loCmd = Nothing
            End If
            If loDb IsNot Nothing Then
                loDb = Nothing
            End If
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Public Sub SaveImage(pcUpdateBy As String, poSlice As SliceDTO)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loCmd As DbCommand
        Dim loPar As DbParameter

        Try
            loConn = loDb.GetConnection()

            lcQuery = "Select dbo.RFN_CombineByte('" + poSlice.COMPANY_ID.Trim + "','" + pcUpdateBy + "','" + poSlice.KEY_GUID.Trim + "') as DATA "
            Dim loHasil As Byte() = loDb.SqlExecObjectQuery(Of SliceDTO)(lcQuery).FirstOrDefault.DATA

            If poSlice.TYPE = 1 Then
                loCmd = loDb.GetCommand()
                lcQuery = "UPDATE SAM_USER "
                lcQuery += "SET "
                lcQuery += "OPHOTO = @Data, "
                lcQuery += "CUPDATE_BY = '{0}', "
                lcQuery += "DUPDATE_DATE = {1} "
                lcQuery += "WHERE CUSER_ID = '{2}'"
                lcQuery = String.Format(lcQuery, pcUpdateBy, getDate(DateTime.Now.ToString), poSlice.USER_ID)
                loCmd.CommandText = lcQuery

                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@Data"
                    .DbType = DbType.Binary
                    .Value = IIf(loHasil Is Nothing, DBNull.Value, loHasil)
                End With
                loCmd.Parameters.Add(loPar)
                loDb.SqlExecNonQuery(loConn, loCmd, True)
            Else
                loCmd = loDb.GetCommand()
                lcQuery = "UPDATE SAM_USER "
                lcQuery += "SET "
                lcQuery += "OSIGNATURE = @Data, "
                lcQuery += "CUPDATE_BY = '{0}', "
                lcQuery += "DUPDATE_DATE = {1} "
                lcQuery += "WHERE CUSER_ID = '{2}'"
                lcQuery = String.Format(lcQuery, pcUpdateBy, getDate(DateTime.Now.ToString), poSlice.USER_ID)
                loCmd.CommandText = lcQuery

                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@Data"
                    .DbType = DbType.Binary
                    .Value = IIf(loHasil Is Nothing, DBNull.Value, loHasil)
                End With
                loCmd.Parameters.Add(loPar)
                loDb.SqlExecNonQuery(loConn, loCmd, True)
            End If


        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Function GetImage(pcUserId As String) As List(Of SliceDTO)
        Dim lcQuery As String
        Dim loResult As New SliceDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loHasil As New List(Of SliceDTO)
        Dim loConn As DbConnection

        Try
            loConn = loDb.GetConnection()

            lcQuery = "SELECT OPHOTO AS DATA, CUSER_ID AS USER_ID, CUSER_NAME AS USER_NAME "
            lcQuery += "FROM "
            lcQuery += "SAM_USER (NOLOCK) "
            lcQuery += "WHERE CUSER_ID = '{0}'"
            lcQuery = String.Format(lcQuery, pcUserId)

            loResult = loDb.SqlExecObjectQuery(Of SliceDTO)(lcQuery, loConn, False).FirstOrDefault

            loHasil.Add(New SliceDTO With {.DATA = loResult.DATA,
                                           .TYPE = 1,
                                           .USER_ID = loResult.USER_ID,
                                           .USER_NAME = loResult.USER_NAME})

            lcQuery = "SELECT OSIGNATURE AS DATA, CUSER_ID AS USER_ID, CUSER_NAME AS USER_NAME "
            lcQuery += "FROM "
            lcQuery += "SAM_USER (NOLOCK) "
            lcQuery += "WHERE CUSER_ID = '{0}'"
            lcQuery = String.Format(lcQuery, pcUserId)

            loResult = loDb.SqlExecObjectQuery(Of SliceDTO)(lcQuery, loConn, False).FirstOrDefault

            loHasil.Add(New SliceDTO With {.DATA = loResult.DATA,
                                           .TYPE = 2,
                                           .USER_ID = loResult.USER_ID,
                                           .USER_NAME = loResult.USER_NAME})

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loHasil
    End Function

    Public Function getSMTP(pcCompId As String) As String
        Dim lcQuery As String
        Dim loResult As cmbDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim lcReturn As String
        Dim loConn As DbConnection

        Try
            loConn = loDb.GetConnection()

            lcQuery = "SELECT A.CGENERAL_EMAIL_ADDRESS AS CID "
            lcQuery += "FROM GSM_SMTP_CONFIG A (NOLOCK) "
            lcQuery += "INNER JOIN SAM_COMPANIES B (NOLOCK) "
            lcQuery += "ON B.CSMTP_ID = A.CSMTP_ID "
            lcQuery += "WHERE B.CCOMPANY_ID = '{0}'"
            lcQuery = String.Format(lcQuery, pcCompId)
            loResult = loDb.SqlExecObjectQuery(Of cmbDTO)(lcQuery, loConn, False).FirstOrDefault

            If loResult Is Nothing Then
                loEx.Add("", "SMTP Id not found. Please maintain SMTP paramater in SMTP Master program")
                Exit Try
            End If

            If loResult.CID Is Nothing Then
                loEx.Add("", "General email address not found. Please maintain in SMTP Master program")
                Exit Try
            End If

            lcReturn = loResult.CID

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
        Return lcReturn
    End Function

    Public Sub SaveSAM_USER(poNewEntity As SAM01200UserDTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As SAM01200UserDTO
        Dim lcPass As String
        Dim loSender As R_Sender
        Dim loEx As New R_Exception()

        Try
            loConn = loDb.GetConnection()

            If poCRUDMode = eCRUDMode.AddMode Then
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "SAM_USER (NOLOCK) "
                lcQuery += "WHERE CUSER_ID = '{0}'"
                lcQuery = String.Format(lcQuery, poNewEntity.CUSER_ID)

                loResult = loDb.SqlExecObjectQuery(Of SAM01200UserDTO)(lcQuery, loConn, False).FirstOrDefault
                If loResult IsNot Nothing Then
                    Throw New Exception("User Id " + poNewEntity.CUSER_ID.Trim + " Already Exist")
                End If

                lcRandomStr = ""
                lcRandomStr = GenerateRandomString(8, False)

                lcPass = R_Utility.HashPassword(lcRandomStr, poNewEntity.CUSER_ID.ToLower)

                lcQuery = "INSERT INTO SAM_USER (CUSER_ID, CUSER_NAME, CEMAIL_ADDRESS, CUSER_PASSWORD, CPOSITION, CCREATE_BY, DCREATE_DATE) "
                lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', "
                lcQuery += "'{5}', {6})"
                lcQuery = String.Format(lcQuery, poNewEntity.CUSER_ID, poNewEntity.CUSER_NAME, poNewEntity.CEMAIL_ADDRESS, lcPass, poNewEntity.CPOSITION, _
                                        poNewEntity.CUSER_LOGIN, getDate(poNewEntity.DDATE))

                loDb.SqlExecNonQuery(lcQuery, loConn, False)

                If String.IsNullOrEmpty(poNewEntity.CEMAIL_ID) = False Then
                    lcQuery = "SELECT A.CEMAIL_BODY "
                    lcQuery += "FROM GST_EMAIL_OUTBOX A (NOLOCK) "
                    lcQuery += "WHERE A.CEMAIL_ID = '{0}'"
                    lcQuery = String.Format(lcQuery, poNewEntity.CEMAIL_ID)
                    loResult = loDb.SqlExecObjectQuery(Of SAM01200UserDTO)(lcQuery, loConn, False).FirstOrDefault

                    Dim cNewBody As String

                    If String.IsNullOrEmpty(loResult.CEMAIL_BODY) = False Then
                        cNewBody = String.Format(loResult.CEMAIL_BODY, Nothing, Nothing, lcRandomStr)
                    End If

                    lcQuery = "UPDATE GST_EMAIL_OUTBOX "
                    lcQuery += "SET "
                    lcQuery += "LFLAG_ACTIVE = {0}, "
                    lcQuery += "CEMAIL_BODY = '{2}' "
                    lcQuery += "WHERE CEMAIL_ID = '{1}'"
                    lcQuery = String.Format(lcQuery, 1, poNewEntity.CEMAIL_ID, cNewBody)
                    loDb.SqlExecNonQuery(lcQuery, loConn, False)

                    loSender = New R_Sender
                    loSender.R_SendById(poNewEntity.CEMAIL_ID)
                End If
            ElseIf poCRUDMode = eCRUDMode.EditMode Then
                lcQuery = "UPDATE SAM_USER "
                lcQuery += "SET "
                lcQuery += "CUSER_NAME = '{0}', "
                lcQuery += "CEMAIL_ADDRESS = '{1}', "
                lcQuery += "CPOSITION = '{2}', "
                lcQuery += "CUPDATE_BY = '{3}', "
                lcQuery += "DUPDATE_DATE = {5} "
                lcQuery += "WHERE CUSER_ID = '{4}'"
                lcQuery = String.Format(lcQuery, poNewEntity.CUSER_NAME, poNewEntity.CEMAIL_ADDRESS, poNewEntity.CPOSITION, _
                                        poNewEntity.CUSER_LOGIN, poNewEntity.CUSER_ID, getDate(poNewEntity.DDATE))

                loDb.SqlExecNonQuery(lcQuery, loConn, False)
            End If
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Sub deleteUSER(poEntity As SAM01200UserDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loSender As R_Sender

        Try
            loConn = loDb.GetConnection()

            lcQuery = "DELETE FROM SAM_USER "
            lcQuery += "WHERE CUSER_ID = '{0}'"
            lcQuery = String.Format(lcQuery, poEntity.CUSER_ID)
            loDb.SqlExecNonQuery(lcQuery, loConn, False)

            lcQuery = "DELETE FROM SAM_USER_COMPANY "
            lcQuery += "WHERE CUSER_ID = '{0}'"
            lcQuery = String.Format(lcQuery, poEntity.CUSER_ID)
            loDb.SqlExecNonQuery(lcQuery, loConn, False)

            lcQuery = "DELETE FROM SAM_USER_PROGRAM "
            lcQuery += "WHERE CUSER_ID = '{0}' AND CCOMPANY_ID = '{1}'"
            lcQuery = String.Format(lcQuery, poEntity.CUSER_ID, poEntity.CCOMPANY_ID)
            loDb.SqlExecNonQuery(lcQuery, loConn, False)

            lcQuery = "DELETE FROM SAM_USER_MENU "
            lcQuery += "WHERE CUSER_ID = '{0}' AND CCOMPANY_ID = '{1}'"
            lcQuery = String.Format(lcQuery, poEntity.CUSER_ID, poEntity.CCOMPANY_ID)
            loDb.SqlExecNonQuery(lcQuery, loConn, False)

            If String.IsNullOrEmpty(poEntity.CEMAIL_ID) = False Then
                lcQuery = "UPDATE GST_EMAIL_OUTBOX "
                lcQuery += "SET "
                lcQuery += "LFLAG_ACTIVE = {0} "
                lcQuery += "WHERE CEMAIL_ID = '{1}'"
                lcQuery = String.Format(lcQuery, 1, poEntity.CEMAIL_ID)
                loDb.SqlExecNonQuery(lcQuery, loConn, False)

                loSender = New R_Sender
                loSender.R_SendById(poEntity.CEMAIL_ID)
            End If

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
End Class
