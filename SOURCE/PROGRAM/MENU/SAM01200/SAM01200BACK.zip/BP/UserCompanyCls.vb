﻿Imports R_Common
Imports R_BackEnd
Imports System.Data.Common
Imports System.Transactions
Imports SAM01200Common
Imports R_EmailEngine

Public Class UserCompanyCls
    Inherits R_BusinessObject(Of UserCompanyDTO)

    Implements R_IBatchProcess

    Private lcRandomStr As String

    Protected Overrides Sub R_Deleting(poEntity As UserCompanyDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loDelUserMenu As New List(Of UserMenuDTO)
        Dim loSender As R_Sender

        Try
            loConn = loDb.GetConnection()

            lcQuery = "DELETE FROM SAM_USER_COMPANY "
            lcQuery += "WHERE CUSER_ID = '{0}' AND CCOMPANY_ID = '{1}'"
            lcQuery = String.Format(lcQuery, poEntity.CUSER_ID, poEntity.CCOMPANY_ID)
            loDb.SqlExecNonQuery(lcQuery, loConn, False)

            lcQuery = "DELETE FROM SAM_USER_PROGRAM "
            lcQuery += "WHERE CUSER_ID = '{0}' AND CCOMPANY_ID = '{1}'"
            lcQuery = String.Format(lcQuery, poEntity.CUSER_ID, poEntity.CCOMPANY_ID)
            loDb.SqlExecNonQuery(lcQuery, loConn, False)

            lcQuery = "DELETE FROM SAM_USER_MENU "
            lcQuery += "WHERE CUSER_ID = '{0}' AND CCOMPANY_ID = '{1}'"
            lcQuery = String.Format(lcQuery, poEntity.CUSER_ID, poEntity.CCOMPANY_ID)
            loDb.SqlExecNonQuery(lcQuery, loConn, False)

            If String.IsNullOrEmpty(poEntity.CEMAIL_ID) = False Then
                lcQuery = "UPDATE GST_EMAIL_OUTBOX "
                lcQuery += "SET "
                lcQuery += "LFLAG_ACTIVE = {0} "
                lcQuery += "WHERE CEMAIL_ID = '{1}'"
                lcQuery = String.Format(lcQuery, 1, poEntity.CEMAIL_ID)
                loDb.SqlExecNonQuery(lcQuery, loConn, True)

                loSender = New R_Sender
                loSender.R_SendById(poEntity.CEMAIL_ID)
            End If

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As UserCompanyDTO) As UserCompanyDTO
        Dim loEx As New R_Exception()
        Dim loRtn As New UserCompanyDTO

        Try
            loRtn = displayUserCompany(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loRtn
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As UserCompanyDTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        
        Try
            saveSAM_USER_COMPANY(poNewEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        
        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Sub R_BatchProcess(poBatchProcessPar As R_Common.R_BatchProcessPar) Implements R_Common.R_IBatchProcess.R_BatchProcess
        Dim loEx As New R_Exception()
        Dim loObject As List(Of BatchCompanyDTO)
        Dim loDb As New R_Db
        Dim lcQuery As String
        Dim loResult As UserCompanyDTO
        Dim loConn As DbConnection
        Dim CUSER_ID As String
        Dim CUSER_ID_LOGIN As String
        Dim DDATE As DateTime
        Dim countLoop As Integer = 0
        Dim CCOMP_ID As String

        Try
            loObject = R_Utility.Deserialize(poBatchProcessPar.BigObject)
            DDATE = poBatchProcessPar.UserParameters.Where(Function(x) x.Key.Equals("DDATE")).FirstOrDefault.Value
            CUSER_ID = poBatchProcessPar.UserParameters.Where(Function(x) x.Key.Equals("CUSER_ID")).FirstOrDefault.Value
            CCOMP_ID = poBatchProcessPar.Key.COMPANY_ID
            CUSER_ID_LOGIN = poBatchProcessPar.Key.USER_ID
            loConn = loDb.GetConnection()

            Using TransScope As New TransactionScope(TransactionScopeOption.Required)
                For Each save As BatchCompanyDTO In loObject
                    loConn = loDb.GetConnection()

                    lcQuery = "exec RSP_WriteUploadProcessStatus '{0}', '{1}', '{2}', '{3}', '{4}'"
                    lcQuery = String.Format(lcQuery, CCOMP_ID, CUSER_ID, poBatchProcessPar.Key.KEY_GUID.Trim, countLoop, "Save " + save.CCOMPANY_ID)
                    loDb.SqlExecNonQuery(lcQuery, loConn, False)

                    lcQuery = "SELECT A.CCOMPANY_ID, B.CCOMPANY_NAME, A.LTIME_LIMITATION, A.CSTART_DATE, A.CEND_DATE, A.IUSER_LEVEL, "
                    lcQuery += "A.CUPDATE_BY, A.DUPDATE_DATE, A.CCREATE_BY, A.DCREATE_DATE "
                    lcQuery += "FROM SAM_USER_COMPANY A (NOLOCK) "
                    lcQuery += "INNER JOIN SAM_COMPANIES B (NOLOCK) "
                    lcQuery += "ON B.CCOMPANY_ID = A.CCOMPANY_ID "
                    lcQuery += "WHERE A.CUSER_ID = '{0}' AND A.CCOMPANY_ID = '{1}'"
                    lcQuery = String.Format(lcQuery, CUSER_ID, save.CCOMPANY_ID)

                    loResult = loDb.SqlExecObjectQuery(Of UserCompanyDTO)(lcQuery, loConn, False).FirstOrDefault

                    If loResult Is Nothing Then
                        lcQuery = "INSERT INTO SAM_USER_COMPANY (CUSER_ID, CCOMPANY_ID, LTIME_LIMITATION, CSTART_DATE, CEND_DATE, IUSER_LEVEL, CCREATE_BY, DCREATE_DATE) "
                        lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', "
                        lcQuery += "'{5}', '{6}', '{7}')"
                        lcQuery = String.Format(lcQuery, CUSER_ID, save.CCOMPANY_ID, save.LTIME_LIMITATION, save.CSTART_DATE, save.CEND_DATE, _
                                                save.IUSER_LEVEL, CUSER_ID_LOGIN, DDATE)

                        loDb.SqlExecNonQuery(lcQuery, loConn, False)
                    End If

                    countLoop += 1
                Next

                lcQuery = "exec RSP_WriteUploadProcessStatus '{0}', '{1}', '{2}', '{3}', '{4}', '{5}'"
                lcQuery = String.Format(lcQuery, CCOMP_ID, CUSER_ID, poBatchProcessPar.Key.KEY_GUID.Trim, countLoop, "Save Complete", 1)
                loDb.SqlExecNonQuery(lcQuery, loConn, False)

                TransScope.Complete()
            End Using

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Private Function getDate(pcDate As String) As String
        Return String.Format("CONVERT(DATETIME, '{0}')", pcDate)
    End Function

    Public Function GenerateRandomString(ByRef len As Integer, ByRef upper As Boolean) As String
        Dim rand As New Random()
        Dim allowableChars() As Char = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLOMNOPQRSTUVWXYZ0123456789".ToCharArray()
        Dim final As String = String.Empty
        For i As Integer = 0 To len - 1
            final += allowableChars(rand.Next(allowableChars.Length - 1))
        Next

        Return IIf(upper, final.ToUpper(), final)
    End Function

    Public Sub saveSAM_USER_COMPANY(poNewEntity As UserCompanyDTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As UserCompanyDTO
        Dim lcPass As String
        Dim loSender As R_Sender
        Dim loEx As New R_Exception()

        Try
            loConn = loDb.GetConnection()

            If poCRUDMode = eCRUDMode.AddMode Then
                lcQuery = "SELECT A.CCOMPANY_ID, B.CCOMPANY_NAME, A.LTIME_LIMITATION, A.CSTART_DATE, A.CEND_DATE, A.IUSER_LEVEL, "
                lcQuery += "A.CUPDATE_BY, A.DUPDATE_DATE, A.CCREATE_BY, A.DCREATE_DATE "
                lcQuery += "FROM SAM_USER_COMPANY A (NOLOCK) "
                lcQuery += "INNER JOIN SAM_COMPANIES B (NOLOCK) "
                lcQuery += "ON B.CCOMPANY_ID = A.CCOMPANY_ID "
                lcQuery += "WHERE A.CUSER_ID = '{0}' AND A.CCOMPANY_ID = '{1}'"
                lcQuery = String.Format(lcQuery, poNewEntity.CUSER_ID, poNewEntity.CCOMPANY_ID)

                loResult = loDb.SqlExecObjectQuery(Of UserCompanyDTO)(lcQuery, loConn, False).FirstOrDefault
                If loResult IsNot Nothing Then
                    Throw New Exception("Company Id " + poNewEntity.CCOMPANY_ID.Trim + " on this user is already exist")
                End If

                lcRandomStr = ""
                lcRandomStr = GenerateRandomString(8, False)

                lcPass = R_Utility.HashPassword(lcRandomStr, poNewEntity.CUSER_ID.ToLower)

                lcQuery = "INSERT INTO SAM_USER_COMPANY (CUSER_ID, CCOMPANY_ID, LTIME_LIMITATION, CSTART_DATE, CEND_DATE, IUSER_LEVEL, CUSER_PASSWORD, CCREATE_BY, DCREATE_DATE, LENABLE_BROADCAST) "
                lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', "
                lcQuery += "'{5}', '{6}', '{7}', {8}, '{9}')"
                lcQuery = String.Format(lcQuery, poNewEntity.CUSER_ID, poNewEntity.CCOMPANY_ID, poNewEntity.LTIME_LIMITATION, poNewEntity.CSTART_DATE, poNewEntity.CEND_DATE, _
                                        poNewEntity.IUSER_LEVEL, lcPass, poNewEntity.CUSER_LOGIN, getDate(poNewEntity.DDATE), poNewEntity.LENABLE_BROADCAST)

                loDb.SqlExecNonQuery(lcQuery, loConn, False)

                If String.IsNullOrEmpty(poNewEntity.CEMAIL_ID) = False Then
                    lcQuery = "SELECT A.CEMAIL_BODY "
                    lcQuery += "FROM GST_EMAIL_OUTBOX A (NOLOCK) "
                    lcQuery += "WHERE A.CEMAIL_ID = '{0}'"
                    lcQuery = String.Format(lcQuery, poNewEntity.CEMAIL_ID)
                    loResult = loDb.SqlExecObjectQuery(Of UserCompanyDTO)(lcQuery, loConn, False).FirstOrDefault

                    Dim cNewBody As String

                    If String.IsNullOrEmpty(loResult.CEMAIL_BODY) = False Then
                        cNewBody = String.Format(loResult.CEMAIL_BODY, Nothing, lcRandomStr)
                    End If

                    lcQuery = "UPDATE GST_EMAIL_OUTBOX "
                    lcQuery += "SET "
                    lcQuery += "LFLAG_ACTIVE = {0}, "
                    lcQuery += "CEMAIL_BODY = '{2}' "
                    lcQuery += "WHERE CEMAIL_ID = '{1}'"
                    lcQuery = String.Format(lcQuery, 1, poNewEntity.CEMAIL_ID, cNewBody)
                    loDb.SqlExecNonQuery(lcQuery, loConn)

                    loSender = New R_Sender
                    loSender.R_SendById(poNewEntity.CEMAIL_ID)
                End If
            ElseIf poCRUDMode = eCRUDMode.EditMode Then
                lcPass = R_Utility.HashPassword("123", poNewEntity.CUSER_ID)

                lcQuery = "UPDATE SAM_USER_COMPANY "
                lcQuery += "SET "
                lcQuery += "LTIME_LIMITATION = '{0}', "
                lcQuery += "LENABLE_BROADCAST = '{9}', "
                lcQuery += "CSTART_DATE = '{1}', "
                lcQuery += "CEND_DATE = '{2}', "
                lcQuery += "IUSER_LEVEL = '{3}', "
                'lcQuery += "CUSER_PASSWORD = '{8}', "
                lcQuery += "CUPDATE_BY = '{4}', "
                lcQuery += "DUPDATE_DATE = {5} "
                lcQuery += "WHERE CUSER_ID = '{6}' AND CCOMPANY_ID = '{7}'"
                lcQuery = String.Format(lcQuery, poNewEntity.LTIME_LIMITATION, poNewEntity.CSTART_DATE, poNewEntity.CEND_DATE, poNewEntity.IUSER_LEVEL, _
                                        poNewEntity.CUSER_LOGIN, getDate(poNewEntity.DDATE), poNewEntity.CUSER_ID, poNewEntity.CCOMPANY_ID, lcPass, poNewEntity.LENABLE_BROADCAST)

                loDb.SqlExecNonQuery(lcQuery, loConn, False)
            End If
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Function displayUserCompany(poParam As UserCompanyDTO) As UserCompanyDTO
        Dim lcQuery As String
        Dim loResult As UserCompanyDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT A.CCOMPANY_ID, B.CCOMPANY_NAME, A.LTIME_LIMITATION, A.CSTART_DATE, A.CEND_DATE, A.IUSER_LEVEL, "
            lcQuery += "A.CUPDATE_BY, A.DUPDATE_DATE, A.CCREATE_BY, A.DCREATE_DATE, A.LENABLE_BROADCAST "
            lcQuery += "FROM SAM_USER_COMPANY A (NOLOCK) "
            lcQuery += "INNER JOIN SAM_COMPANIES B (NOLOCK) "
            lcQuery += "ON B.CCOMPANY_ID = A.CCOMPANY_ID "
            lcQuery += "WHERE A.CUSER_ID = '{0}' AND A.CCOMPANY_ID = '{1}'"
            lcQuery = String.Format(lcQuery, poParam.CUSER_ID, poParam.CCOMPANY_ID)

            loResult = loDb.SqlExecObjectQuery(Of UserCompanyDTO)(lcQuery).FirstOrDefault

            If String.IsNullOrWhiteSpace(lcRandomStr) = False Then
                loResult.CPWD = lcRandomStr
            End If
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function
End Class
