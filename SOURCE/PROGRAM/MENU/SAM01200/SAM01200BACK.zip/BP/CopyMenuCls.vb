﻿Imports R_Common
Imports R_BackEnd
Imports System.Data.Common
Imports System.Transactions
Imports SAM01200Common

Public Class CopyMenuCls
    Implements R_IBatchProcess

    Public Sub R_BatchProcess(poBatchProcessPar As R_Common.R_BatchProcessPar) Implements R_Common.R_IBatchProcess.R_BatchProcess
        Dim loEx As New R_Exception()
        Dim loObject As List(Of BatchMenuDTO)
        Dim loDb As New R_Db
        Dim lcQuery As String
        Dim loResult As UserMenuDTO
        Dim loConn As DbConnection
        Dim CUSER_ID As String
        Dim CUSER_ID_LOGIN As String
        Dim DDATE As DateTime
        Dim countLoop As Integer = 0
        Dim CCOMP_ID As String
        Dim CCOMP_ID_FROM As String
        Dim CCOMP_ID_LOGIN As String

        Try
            loObject = R_Utility.Deserialize(poBatchProcessPar.BigObject)
            DDATE = poBatchProcessPar.UserParameters.Where(Function(x) x.Key.Equals("DDATE")).FirstOrDefault.Value
            CUSER_ID = poBatchProcessPar.UserParameters.Where(Function(x) x.Key.Equals("CUSER_ID")).FirstOrDefault.Value
            CCOMP_ID = poBatchProcessPar.UserParameters.Where(Function(x) x.Key.Equals("CCOMPANY_ID")).FirstOrDefault.Value
            CCOMP_ID_FROM = poBatchProcessPar.UserParameters.Where(Function(x) x.Key.Equals("CCOMPANY_ID_FROM")).FirstOrDefault.Value
            CCOMP_ID_LOGIN = poBatchProcessPar.Key.COMPANY_ID
            CUSER_ID_LOGIN = poBatchProcessPar.Key.USER_ID
            loConn = loDb.GetConnection()

            Using TransScope As New TransactionScope(TransactionScopeOption.Required)
                For Each save As BatchMenuDTO In loObject
                    loConn = loDb.GetConnection()

                    lcQuery = "exec RSP_WriteUploadProcessStatus '{0}', '{1}', '{2}', '{3}', '{4}'"
                    lcQuery = String.Format(lcQuery, CCOMP_ID, CUSER_ID, poBatchProcessPar.Key.KEY_GUID.Trim, countLoop, "Save " + save.CMENU_ID)
                    loDb.SqlExecNonQuery(lcQuery, loConn, False)

                    lcQuery = "SELECT A.CMENU_ID, B.CMENU_NAME, "
                    lcQuery += "A.CUPDATE_BY, A.DUPDATE_DATE, A.CCREATE_BY, A.DCREATE_DATE "
                    lcQuery += "FROM SAM_USER_MENU A (NOLOCK) "
                    lcQuery += "INNER JOIN SAM_MENU B (NOLOCK) "
                    lcQuery += "ON B.CMENU_ID = A.CMENU_ID AND B.CCOMPANY_ID = A.CCOMPANY_ID "
                    lcQuery += "WHERE A.CUSER_ID = '{0}' AND A.CCOMPANY_ID = '{1}' AND A.CMENU_ID = '{2}'"
                    lcQuery = String.Format(lcQuery, CUSER_ID, CCOMP_ID, save.CMENU_ID)

                    loResult = loDb.SqlExecObjectQuery(Of UserMenuDTO)(lcQuery, loConn, False).FirstOrDefault

                    If loResult Is Nothing Then
                        lcQuery = "INSERT INTO SAM_USER_MENU (CUSER_ID, CCOMPANY_ID, CMENU_ID, CCREATE_BY, DCREATE_DATE) "
                        lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}') "
                        lcQuery = String.Format(lcQuery, CUSER_ID, CCOMP_ID, save.CMENU_ID, CUSER_ID_LOGIN, DDATE)

                        loDb.SqlExecNonQuery(lcQuery, loConn, False)
                    End If

                    countLoop += 1
                Next

                lcQuery = "exec RSP_WriteUploadProcessStatus '{0}', '{1}', '{2}', '{3}', '{4}', '{5}'"
                lcQuery = String.Format(lcQuery, CCOMP_ID, CUSER_ID, poBatchProcessPar.Key.KEY_GUID.Trim, countLoop, "Save Complete", 1)
                loDb.SqlExecNonQuery(lcQuery, loConn, False)

                TransScope.Complete()
            End Using

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub
End Class
