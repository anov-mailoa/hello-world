﻿<Serializable()> _
Public Class SAM01200MenuProgramDTO
    Inherits R_BackEnd.R_DTOBase

    Public Property CCOMPANY_ID As String
    Public Property CMENU_ID As String
    Public Property CPROGRAM_ID As String
    Public Property CPROGRAM_NAME As String
End Class
