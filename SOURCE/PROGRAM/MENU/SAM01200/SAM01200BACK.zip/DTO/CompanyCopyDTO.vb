﻿Imports R_BackEnd

'<Serializable()> _
Public Class CompanyCopyDTO
    Inherits R_DTOBase

    Public Property CCOMPANY_ID As String
    Public Property CCOMPANY_NAME As String
    Public Property LTIME_LIMITATION As Boolean
    Public Property CCULTURE_ID As String
    Public Property CCULTURE_FORMAT As String
    Public Property CSTART_DATE As String
    Public Property CEND_DATE As String
    Public Property IUSER_LEVEL As Integer

    Public Property LINCLUDE_MENU As Boolean
    Public Property CUSER_ID_FROM As String
End Class
