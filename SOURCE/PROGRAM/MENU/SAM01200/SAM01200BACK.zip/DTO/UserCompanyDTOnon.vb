﻿Imports R_BackEnd

'<Serializable()> _
Public Class UserCompanyDTOnon
    Inherits R_DTOBase

    Public Property CCOMPANY_ID As String
    Public Property CCOMPANY_NAME As String
    Public Property LTIME_LIMITATION As Boolean
    Public Property CSTART_DATE As String
    Public Property CEND_DATE As String
    Public Property IUSER_LEVEL As Integer

    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)

    Public Property LENABLE_BROADCAST As Boolean
End Class
