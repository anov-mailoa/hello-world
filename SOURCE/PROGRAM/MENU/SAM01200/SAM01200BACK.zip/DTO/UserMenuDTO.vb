﻿Imports R_BackEnd

<Serializable()> _
Public Class UserMenuDTO
    Inherits R_DTOBase

    Public Property CUSER_ID As String
    Public Property CCOMPANY_ID As String
    Public Property CMENU_ID As String
    Public Property CMENU_NAME As String

    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)

    Public Property DDATE As String
    Public Property CCOMPANY_ID_FROM As String
End Class
