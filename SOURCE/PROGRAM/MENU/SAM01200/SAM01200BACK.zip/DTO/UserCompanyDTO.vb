﻿Imports R_BackEnd

<Serializable()> _
Public Class UserCompanyDTO
    Inherits R_DTOBase

    Public Property CUSER_ID As String
    Public Property CUSER_NAME As String
    Public Property CCOMPANY_ID As String
    Public Property CCOMPANY_NAME As String
    Public Property LTIME_LIMITATION As Boolean
    Public Property CSTART_DATE As String
    Public Property CEND_DATE As String
    Public Property IUSER_LEVEL As Integer

    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)

    Public Property CUSER_LOGIN As String
    Public Property DDATE As String
    Public Property DSTART_DATE As Nullable(Of Date)
    Public Property DEND_DATE As Nullable(Of Date)
    Public Property CPWD As String

    Public Property CEMAIL_ID As String
    Public Property CEMAIL_BODY As String

    Public Property LENABLE_BROADCAST As Boolean
End Class
