﻿Imports R_BackEnd

<Serializable()> _
Public Class cmbDTO
    Inherits R_DTOBase

    Public Property CID As String
    Public Property CDESC As String
End Class
