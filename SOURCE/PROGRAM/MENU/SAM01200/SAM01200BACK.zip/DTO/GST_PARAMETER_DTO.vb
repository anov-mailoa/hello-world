﻿Imports R_BackEnd

<Serializable()> _
Public Class GST_PARAMETER_DTO
    Inherits R_DTOBase

    Public Property cParameterId As String
    Public Property cParameterValue As String
End Class
