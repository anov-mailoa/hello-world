﻿Imports R_Common
Imports LAM00200Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "LAM00200ContactService" in code, svc and config file together.
Public Class LAM00200ContactService
    Implements ILAM00200ContactService

    Public Sub Svc_R_Delete(poEntity As LAM00200Back.LAM00200ContactDTO) Implements R_BackEnd.R_IServicebase(Of LAM00200Back.LAM00200ContactDTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New LAM00200ContactCls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As LAM00200Back.LAM00200ContactDTO) As LAM00200Back.LAM00200ContactDTO Implements R_BackEnd.R_IServicebase(Of LAM00200Back.LAM00200ContactDTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New LAM00200ContactCls
        Dim loRtn As LAM00200ContactDTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As LAM00200Back.LAM00200ContactDTO, poCRUDMode As R_Common.eCRUDMode) As LAM00200Back.LAM00200ContactDTO Implements R_BackEnd.R_IServicebase(Of LAM00200Back.LAM00200ContactDTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New LAM00200ContactCls
        Dim loRtn As LAM00200ContactDTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
