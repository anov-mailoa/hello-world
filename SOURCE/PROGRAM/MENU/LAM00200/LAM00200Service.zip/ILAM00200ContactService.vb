﻿Imports System.ServiceModel
Imports LAM00200Back
Imports R_BackEnd

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ILAM00200ContactService" in both code and config file together.
<ServiceContract()>
Public Interface ILAM00200ContactService
    Inherits R_IServicebase(Of LAM00200ContactDTO)

End Interface
