﻿Imports R_Common
Imports R_BackEnd
Imports System.Data.Common
Imports ServerHelper.General
Imports System.Transactions

Public Class LAM00200Cls
    Inherits R_BusinessObject(Of LAM00200DTO)

    Protected Overrides Sub R_Deleting(poEntity As LAM00200DTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loResult As LAM00200DTO

        Try
            loConn = loDb.GetConnection()

            ' validasi
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "LAM_APP_CUST (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery += "AND CCUSTOMER_CODE = '{1}' "
            lcQuery = String.Format(lcQuery, poEntity.CCOMPANY_ID, poEntity.CCUSTOMER_CODE)

            loResult = loDb.SqlExecObjectQuery(Of LAM00200DTO)(lcQuery, loConn, False).FirstOrDefault
            If loResult IsNot Nothing Then
                Throw New Exception("Customer Code " + poEntity.CCUSTOMER_CODE.Trim + " has already been used in transaction.")
            End If

            Using TransScope As New TransactionScope(TransactionScopeOption.Required)
                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "LAM_CUSTOMER "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' AND CCUSTOMER_CODE = '{1}' "
                lcQuery = String.Format(lcQuery, poEntity.CCOMPANY_ID, poEntity.CCUSTOMER_CODE)

                loDb.SqlExecNonQuery(lcQuery, loConn, True)

                TransScope.Complete()
            End Using

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As LAM00200DTO) As LAM00200DTO
        Dim lcQuery As String
        Dim loResult As LAM00200DTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "LAM_CUSTOMER (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery += "AND CCUSTOMER_CODE = '{1}' "
            lcQuery = String.Format(lcQuery, poEntity.CCOMPANY_ID, poEntity.CCUSTOMER_CODE)

            loResult = loDb.SqlExecObjectQuery(Of LAM00200DTO)(lcQuery).FirstOrDefault
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As LAM00200DTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As LAM00200DTO
        Dim loCmd As DbCommand
        Dim loPar As DbParameter

        Try
            loConn = loDb.GetConnection()

            If poCRUDMode = eCRUDMode.AddMode Then
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "LAM_CUSTOMER (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CCUSTOMER_CODE = '{1}' "
                lcQuery = String.Format(lcQuery, poNewEntity.CCOMPANY_ID, poNewEntity.CCUSTOMER_CODE)

                loResult = loDb.SqlExecObjectQuery(Of LAM00200DTO)(lcQuery, loConn, True).FirstOrDefault
                If loResult IsNot Nothing Then
                    Throw New Exception("Customer Code " + poNewEntity.CCUSTOMER_CODE.Trim + " is already exist")
                End If

                With poNewEntity
                    .CCREATE_BY = .CUPDATE_BY
                    .DUPDATE_DATE = Now
                    .DCREATE_DATE = Now
                End With

                lcQuery = "INSERT INTO LAM_CUSTOMER ("
                lcQuery += "CCOMPANY_ID, "
                lcQuery += "CCUSTOMER_CODE, "
                lcQuery += "CCUSTOMER_NAME, "
                lcQuery += "CADDRESS, "
                lcQuery += "CZIP_CODE, "
                lcQuery += "CCITY, "
                lcQuery += "CCOUNTRY, "
                lcQuery += "CEMAIL_ADDRESS, "
                lcQuery += "CPHONE_1, "
                lcQuery += "CPHONE_2, "
                lcQuery += "CFAX_NO, "
                lcQuery += "CLOB_CODE, "
                lcQuery += "CWEB_SITE, "
                lcQuery += "CCUSTOMER_GROUP, "
                lcQuery += "CUPDATE_BY, "
                lcQuery += "DUPDATE_DATE, "
                lcQuery += "CCREATE_BY, "
                lcQuery += "DCREATE_DATE) "
                lcQuery += "VALUES ('{0}', '{1}', @CustName, '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}', '{13}', '{14}', {15}, '{16}', {17}) "
                lcQuery = String.Format(lcQuery,
                poNewEntity.CCOMPANY_ID,
                poNewEntity.CCUSTOMER_CODE,
                poNewEntity.CCUSTOMER_NAME,
                poNewEntity.CADDRESS,
                poNewEntity.CZIP_CODE,
                poNewEntity.CCITY,
                poNewEntity.CCOUNTRY,
                poNewEntity.CEMAIL_ADDRESS,
                poNewEntity.CPHONE_1,
                poNewEntity.CPHONE_2,
                poNewEntity.CFAX_NO,
                poNewEntity.CLOB_CODE,
                poNewEntity.CWEB_SITE,
                poNewEntity.CCUSTOMER_GROUP,
                poNewEntity.CUPDATE_BY,
                getDate(poNewEntity.DUPDATE_DATE),
                poNewEntity.CCREATE_BY,
                getDate(poNewEntity.DCREATE_DATE))
                loCmd = loDb.GetCommand()
                loCmd.CommandText = lcQuery
                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@CustName"
                    .DbType = DbType.String
                    .Value = poNewEntity.CCUSTOMER_NAME
                End With
                loCmd.Parameters.Add(loPar)
                loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd, True)

            ElseIf poCRUDMode = eCRUDMode.EditMode Then

                lcQuery = "UPDATE LAM_CUSTOMER "
                lcQuery += "SET "
                lcQuery += "CADDRESS = '{3}', "
                lcQuery += "CZIP_CODE = '{4}', "
                lcQuery += "CCITY = '{5}', "
                lcQuery += "CCOUNTRY = '{6}', "
                lcQuery += "CEMAIL_ADDRESS = '{7}', "
                lcQuery += "CPHONE_1 = '{8}', "
                lcQuery += "CPHONE_2 = '{9}', "
                lcQuery += "CFAX_NO = '{10}', "
                lcQuery += "CLOB_CODE = '{11}', "
                lcQuery += "CWEB_SITE = '{12}', "
                lcQuery += "CCUSTOMER_GROUP = '{13}', "
                lcQuery += "CUPDATE_BY = '{14}', "
                lcQuery += "DUPDATE_DATE = {15} "
                lcQuery += "WHERE "
                lcQuery += "CCOMPANY_ID = '{0}' "
                lcQuery += "AND CCUSTOMER_CODE = '{1}' "
                lcQuery = String.Format(lcQuery,
                poNewEntity.CCOMPANY_ID,
                poNewEntity.CCUSTOMER_CODE,
                poNewEntity.CCUSTOMER_NAME,
                poNewEntity.CADDRESS,
                poNewEntity.CZIP_CODE,
                poNewEntity.CCITY,
                poNewEntity.CCOUNTRY,
                poNewEntity.CEMAIL_ADDRESS,
                poNewEntity.CPHONE_1,
                poNewEntity.CPHONE_2,
                poNewEntity.CFAX_NO,
                poNewEntity.CLOB_CODE,
                poNewEntity.CWEB_SITE,
                poNewEntity.CCUSTOMER_GROUP,
                poNewEntity.CUPDATE_BY,
                getDate(poNewEntity.DUPDATE_DATE))

                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End If

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Function getCustList(pcCompany_ID As String) As List(Of LAM00200GridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of LAM00200GridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT A.*, ISNULL(B.CCUSTOMER_GROUP_NAME, '---') AS CCUSTOMER_GROUP_NAME "
            lcQuery += "FROM "
            lcQuery += "LAM_CUSTOMER A (NOLOCK) "
            lcQuery += "LEFT OUTER JOIN LAM_CUSTOMER_GROUP B  "
            lcQuery += "ON B.CCUSTOMER_GROUP = A.CCUSTOMER_GROUP "
            lcQuery += "WHERE A.CCOMPANY_ID = '{0}' "
            lcQuery = String.Format(lcQuery, pcCompany_ID)

            loResult = loDb.SqlExecObjectQuery(Of LAM00200GridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function getCustGrpList() As List(Of LAM00200CustGrpDTO)
        Dim lcQuery As String
        Dim loResult As List(Of LAM00200CustGrpDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "LAM_CUSTOMER_GROUP (NOLOCK) "

            loResult = loDb.SqlExecObjectQuery(Of LAM00200CustGrpDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

End Class
