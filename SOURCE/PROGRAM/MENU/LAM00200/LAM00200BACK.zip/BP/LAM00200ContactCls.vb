﻿Imports R_Common
Imports R_BackEnd
Imports System.Data.Common
Imports ServerHelper.General

Public Class LAM00200ContactCls
    Inherits R_BusinessObject(Of LAM00200ContactDTO)

    Protected Overrides Sub R_Deleting(poEntity As LAM00200ContactDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loResult As LAM00200ContactDTO

        Try
            loConn = loDb.GetConnection()

            With poEntity

                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "LAM_CUSTOMER_CONTACT "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CCUSTOMER_CODE = '{1}' "
                lcQuery += "AND CCONTACT_ID = '{2}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CCUSTOMER_CODE, .CCONTACT_ID)

                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As LAM00200ContactDTO) As LAM00200ContactDTO
        Dim lcQuery As String
        Dim loResult As LAM00200ContactDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "LAM_CUSTOMER_CONTACT (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CCUSTOMER_CODE = '{1}' "
                lcQuery += "AND CCONTACT_ID = '{2}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CCUSTOMER_CODE, .CCONTACT_ID)
            End With

            loResult = loDb.SqlExecObjectQuery(Of LAM00200ContactDTO)(lcQuery).FirstOrDefault
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult

    End Function

    Protected Overrides Sub R_Saving(poNewEntity As LAM00200ContactDTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As String
        Dim lcContactID As String

        Try
            loConn = loDb.GetConnection()

            If poCRUDMode = eCRUDMode.AddMode Then
                With poNewEntity

                    lcQuery = "SELECT MAX(CCONTACT_ID) "
                    lcQuery += "FROM "
                    lcQuery += "LAM_CUSTOMER_CONTACT (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CCUSTOMER_CODE = '{1}' "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CCUSTOMER_CODE)

                    loResult = loDb.SqlExecObjectQuery(Of String)(lcQuery, loConn, True).FirstOrDefault
                    If loResult IsNot Nothing Then
                        lcContactID = Right("00000" + (CInt(loResult) + 1).ToString.Trim, 5)
                    Else
                        lcContactID = "00001"
                    End If

                    .CCONTACT_ID = lcContactID
                    .CCREATE_BY = .CUPDATE_BY
                    .DUPDATE_DATE = Now
                    .DCREATE_DATE = Now

                    lcQuery = "INSERT INTO LAM_CUSTOMER_CONTACT ("
                    lcQuery += "CCOMPANY_ID, "
                    lcQuery += "CCUSTOMER_CODE, "
                    lcQuery += "CCONTACT_ID, "
                    lcQuery += "CCONTACT_NAME, "
                    lcQuery += "CJOB_FUNCTION, "
                    lcQuery += "CEMAIL_1, "
                    lcQuery += "CEMAIL_2, "
                    lcQuery += "CPHONE_1, "
                    lcQuery += "CPHONE_2, "
                    lcQuery += "CUPDATE_BY, "
                    lcQuery += "DUPDATE_DATE, "
                    lcQuery += "CCREATE_BY, "
                    lcQuery += "DCREATE_DATE) "
                    lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', {10}, '{11}', {12}) "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CCUSTOMER_CODE,
                    .CCONTACT_ID,
                    .CCONTACT_NAME,
                    .CJOB_FUNCTION,
                    .CEMAIL_1,
                    .CEMAIL_2,
                    .CPHONE_1,
                    .CPHONE_2,
                    .CUPDATE_BY,
                    getDate(.DUPDATE_DATE),
                    poNewEntity.CCREATE_BY,
                    getDate(.DCREATE_DATE))
                End With

                loDb.SqlExecNonQuery(lcQuery)

            ElseIf poCRUDMode = eCRUDMode.EditMode Then


                lcQuery += "CCOMPANY_ID = '{0}', "
                lcQuery += "CCUSTOMER_CODE = '{1}', "
                lcQuery += "CCONTACT_ID = '{2}', "
                lcQuery += "CCONTACT_NAME = '{3}', "
                lcQuery += "CJOB_FUNCTION = '{4}', "
                lcQuery += "CEMAIL_1 = '{5}', "
                lcQuery += "CEMAIL_2 = '{6}', "
                lcQuery += "CPHONE_1 = '{7}', "
                lcQuery += "CPHONE_2 = '{8}', "
                lcQuery += "CUPDATE_BY = '{9}', "
                lcQuery += "DUPDATE_DATE = {10}, "
                lcQuery += "CCREATE_BY = '{11}', "
                lcQuery += "DCREATE_DATE = {12} "

                With poNewEntity
                    lcQuery = "UPDATE LAM_CUSTOMER_CONTACT "
                    lcQuery += "SET "
                    lcQuery += "CCONTACT_NAME = '{3}', "
                    lcQuery += "CJOB_FUNCTION = '{4}', "
                    lcQuery += "CEMAIL_1 = '{5}', "
                    lcQuery += "CEMAIL_2 = '{6}', "
                    lcQuery += "CPHONE_1 = '{7}', "
                    lcQuery += "CPHONE_2 = '{8}', "
                    lcQuery += "CUPDATE_BY = '{9}', "
                    lcQuery += "DUPDATE_DATE = {10} "
                    lcQuery += "WHERE "
                    lcQuery += "CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CCUSTOMER_CODE = '{1}' "
                    lcQuery += "AND CCONTACT_ID = '{2}' "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CCUSTOMER_CODE,
                    .CCONTACT_ID,
                    .CCONTACT_NAME,
                    .CJOB_FUNCTION,
                    .CEMAIL_1,
                    .CEMAIL_2,
                    .CPHONE_1,
                    .CPHONE_2,
                    .CUPDATE_BY,
                    getDate(.DUPDATE_DATE))
                End With

                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End If

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Function getCustContactList(pcCompany_ID As String, pcCustomer_Code As String) As List(Of LAM00200ContactGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of LAM00200ContactGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "LAM_CUSTOMER_CONTACT (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery += "AND CCUSTOMER_CODE = '{1}' "
            lcQuery = String.Format(lcQuery, pcCompany_ID, pcCustomer_Code)

            loResult = loDb.SqlExecObjectQuery(Of LAM00200ContactGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

End Class
