﻿Public Class LAM00200GridDTO
    Public Property CCOMPANY_ID As String
    Public Property CCUSTOMER_CODE As String
    Public Property CCUSTOMER_NAME As String
    Public Property CADDRESS As String
    Public Property CZIP_CODE As String
    Public Property CCITY As String
    Public Property CCOUNTRY As String
    Public Property CEMAIL_ADDRESS As String
    Public Property CPHONE_1 As String
    Public Property CPHONE_2 As String
    Public Property CFAX_NO As String
    Public Property CLOB_CODE As String
    Public Property CWEB_SITE As String
    Public Property CCUSTOMER_GROUP As String
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)
    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)

    Public Property CCUSTOMER_GROUP_NAME As String

End Class
