﻿Public Class LAM00200CustGrpDTO
    Public Property CCUSTOMER_GROUP As String
    Public Property CCUSTOMER_GROUP_NAME As String
End Class
