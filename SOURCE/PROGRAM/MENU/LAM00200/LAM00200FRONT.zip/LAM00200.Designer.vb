﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LAM00200
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn6 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn7 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn8 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn9 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn10 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewLookUpColumn1 As R_FrontEnd.R_GridViewLookUpColumn = New R_FrontEnd.R_GridViewLookUpColumn()
        Dim R_GridViewTextBoxColumn11 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn12 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn13 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn2 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Me.gvCust = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvCust = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridCust = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnContact = New R_FrontEnd.R_Detail(Me.components)
        CType(Me.gvCust, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvCust.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvCust, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridCust, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.btnContact, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'gvCust
        '
        Me.gvCust.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvCust.EnableFastScrolling = True
        Me.gvCust.Location = New System.Drawing.Point(3, 3)
        '
        '
        '
        Me.gvCust.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn1.FieldName = "_CCUSTOMER_CODE"
        R_GridViewTextBoxColumn1.HeaderText = "_CCUSTOMER_CODE"
        R_GridViewTextBoxColumn1.Name = "_CCUSTOMER_CODE"
        R_GridViewTextBoxColumn1.R_EnableADD = True
        R_GridViewTextBoxColumn1.R_ResourceId = "_CCUSTOMER_CODE"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 106
        R_GridViewTextBoxColumn2.FieldName = "_CCUSTOMER_NAME"
        R_GridViewTextBoxColumn2.HeaderText = "_CCUSTOMER_NAME"
        R_GridViewTextBoxColumn2.Name = "_CCUSTOMER_NAME"
        R_GridViewTextBoxColumn2.R_AllowSingleQuote = True
        R_GridViewTextBoxColumn2.R_EnableADD = True
        R_GridViewTextBoxColumn2.R_ResourceId = "_CCUSTOMER_NAME"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 108
        R_GridViewTextBoxColumn3.FieldName = "_CADDRESS"
        R_GridViewTextBoxColumn3.HeaderText = "_CADDRESS"
        R_GridViewTextBoxColumn3.Multiline = True
        R_GridViewTextBoxColumn3.Name = "_CADDRESS"
        R_GridViewTextBoxColumn3.R_EnableADD = True
        R_GridViewTextBoxColumn3.R_EnableEDIT = True
        R_GridViewTextBoxColumn3.R_ResourceId = "_CADDRESS"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 72
        R_GridViewTextBoxColumn4.FieldName = "_CCITY"
        R_GridViewTextBoxColumn4.HeaderText = "_CCITY"
        R_GridViewTextBoxColumn4.Name = "_CCITY"
        R_GridViewTextBoxColumn4.R_EnableADD = True
        R_GridViewTextBoxColumn4.R_EnableEDIT = True
        R_GridViewTextBoxColumn4.R_ResourceId = "_CCITY"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 72
        R_GridViewTextBoxColumn5.FieldName = "_CZIP_CODE"
        R_GridViewTextBoxColumn5.HeaderText = "_CZIP_CODE"
        R_GridViewTextBoxColumn5.Name = "_CZIP_CODE"
        R_GridViewTextBoxColumn5.R_EnableADD = True
        R_GridViewTextBoxColumn5.R_EnableEDIT = True
        R_GridViewTextBoxColumn5.R_ResourceId = "_CZIP_CODE"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 72
        R_GridViewTextBoxColumn6.FieldName = "_CCOUNTRY"
        R_GridViewTextBoxColumn6.HeaderText = "_CCOUNTRY"
        R_GridViewTextBoxColumn6.Name = "_CCOUNTRY"
        R_GridViewTextBoxColumn6.R_EnableADD = True
        R_GridViewTextBoxColumn6.R_EnableEDIT = True
        R_GridViewTextBoxColumn6.R_ResourceId = "_CCOUNTRY"
        R_GridViewTextBoxColumn6.R_UDT = Nothing
        R_GridViewTextBoxColumn6.Width = 72
        R_GridViewTextBoxColumn7.FieldName = "_CEMAIL_ADDRESS"
        R_GridViewTextBoxColumn7.HeaderText = "_CEMAIL_ADDRESS"
        R_GridViewTextBoxColumn7.Name = "_CEMAIL_ADDRESS"
        R_GridViewTextBoxColumn7.R_EnableADD = True
        R_GridViewTextBoxColumn7.R_EnableEDIT = True
        R_GridViewTextBoxColumn7.R_ResourceId = "_CEMAIL_ADDRESS"
        R_GridViewTextBoxColumn7.R_UDT = Nothing
        R_GridViewTextBoxColumn7.Width = 101
        R_GridViewTextBoxColumn8.FieldName = "_CPHONE_1"
        R_GridViewTextBoxColumn8.HeaderText = "_CPHONE_1"
        R_GridViewTextBoxColumn8.Name = "_CPHONE_1"
        R_GridViewTextBoxColumn8.R_EnableADD = True
        R_GridViewTextBoxColumn8.R_EnableEDIT = True
        R_GridViewTextBoxColumn8.R_ResourceId = "_CPHONE_1"
        R_GridViewTextBoxColumn8.R_UDT = Nothing
        R_GridViewTextBoxColumn8.Width = 72
        R_GridViewTextBoxColumn9.FieldName = "_CPHONE_2"
        R_GridViewTextBoxColumn9.HeaderText = "_CPHONE_2"
        R_GridViewTextBoxColumn9.Name = "_CPHONE_2"
        R_GridViewTextBoxColumn9.R_EnableADD = True
        R_GridViewTextBoxColumn9.R_EnableEDIT = True
        R_GridViewTextBoxColumn9.R_ResourceId = "_CPHONE_2"
        R_GridViewTextBoxColumn9.R_UDT = Nothing
        R_GridViewTextBoxColumn9.Width = 73
        R_GridViewTextBoxColumn10.FieldName = "_CFAX_NO"
        R_GridViewTextBoxColumn10.HeaderText = "_CFAX_NO"
        R_GridViewTextBoxColumn10.Name = "_CFAX_NO"
        R_GridViewTextBoxColumn10.R_EnableADD = True
        R_GridViewTextBoxColumn10.R_EnableEDIT = True
        R_GridViewTextBoxColumn10.R_ResourceId = "_CFAX_NO"
        R_GridViewTextBoxColumn10.R_UDT = Nothing
        R_GridViewTextBoxColumn10.Width = 73
        R_GridViewLookUpColumn1.FieldName = "_CCUSTOMER_GROUP"
        R_GridViewLookUpColumn1.HeaderText = "_CCUSTOMER_GROUP"
        R_GridViewLookUpColumn1.Name = "_CCUSTOMER_GROUP"
        R_GridViewLookUpColumn1.R_EnableADD = True
        R_GridViewLookUpColumn1.R_EnableEDIT = True
        R_GridViewLookUpColumn1.R_ResourceId = "_CCUSTOMER_GROUP"
        R_GridViewLookUpColumn1.R_Title = Nothing
        R_GridViewLookUpColumn1.Width = 47
        R_GridViewTextBoxColumn11.FieldName = "_CCUSTOMER_GROUP_NAME"
        R_GridViewTextBoxColumn11.HeaderText = "_CCUSTOMER_GROUP_NAME"
        R_GridViewTextBoxColumn11.Name = "_CCUSTOMER_GROUP_NAME"
        R_GridViewTextBoxColumn11.R_ResourceId = "_CCUSTOMER_GROUP_NAME"
        R_GridViewTextBoxColumn11.R_UDT = Nothing
        R_GridViewTextBoxColumn12.FieldName = "_CUPDATE_BY"
        R_GridViewTextBoxColumn12.HeaderText = "_CUPDATE_BY"
        R_GridViewTextBoxColumn12.Name = "_CUPDATE_BY"
        R_GridViewTextBoxColumn12.R_ResourceId = "_CUPDATE_BY"
        R_GridViewTextBoxColumn12.R_UDT = Nothing
        R_GridViewTextBoxColumn12.Width = 76
        R_GridViewDateTimeColumn1.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn1.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn1.FieldName = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn1.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn1.HeaderText = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.Name = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.R_ResourceId = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.Width = 90
        R_GridViewTextBoxColumn13.FieldName = "_CCREATE_BY"
        R_GridViewTextBoxColumn13.HeaderText = "_CCREATE_BY"
        R_GridViewTextBoxColumn13.Name = "_CCREATE_BY"
        R_GridViewTextBoxColumn13.R_ResourceId = "_CCREATE_BY"
        R_GridViewTextBoxColumn13.R_UDT = Nothing
        R_GridViewTextBoxColumn13.Width = 74
        R_GridViewDateTimeColumn2.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn2.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn2.FieldName = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn2.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn2.HeaderText = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.Name = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.R_ResourceId = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.Width = 28
        Me.gvCust.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewTextBoxColumn4, R_GridViewTextBoxColumn5, R_GridViewTextBoxColumn6, R_GridViewTextBoxColumn7, R_GridViewTextBoxColumn8, R_GridViewTextBoxColumn9, R_GridViewTextBoxColumn10, R_GridViewLookUpColumn1, R_GridViewTextBoxColumn11, R_GridViewTextBoxColumn12, R_GridViewDateTimeColumn1, R_GridViewTextBoxColumn13, R_GridViewDateTimeColumn2})
        Me.gvCust.MasterTemplate.DataSource = Me.bsGvCust
        Me.gvCust.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvCust.MasterTemplate.EnableFiltering = True
        Me.gvCust.MasterTemplate.EnableGrouping = False
        Me.gvCust.MasterTemplate.ShowFilteringRow = False
        Me.gvCust.MasterTemplate.ShowGroupedColumns = True
        Me.gvCust.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvCust.Name = "gvCust"
        Me.gvCust.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvCust.R_ConductorGridSource = Me.conGridCust
        Me.gvCust.R_ConductorSource = Nothing
        Me.gvCust.R_DataAdded = False
        Me.gvCust.R_NewRowText = Nothing
        Me.gvCust.ShowHeaderCellButtons = True
        Me.gvCust.Size = New System.Drawing.Size(1271, 529)
        Me.gvCust.TabIndex = 0
        Me.gvCust.Text = "R_RadGridView1"
        '
        'bsGvCust
        '
        Me.bsGvCust.DataSource = GetType(LAM00200Front.LAM00200ServiceRef.LAM00200DTO)
        '
        'conGridCust
        '
        Me.conGridCust.R_ConductorParent = Nothing
        Me.conGridCust.R_IsHeader = True
        Me.conGridCust.R_RadGroupBox = Nothing
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.gvCust, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 1
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnContact)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 538)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 34)
        Me.Panel1.TabIndex = 1
        '
        'btnContact
        '
        Me.btnContact.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnContact.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnContact.Location = New System.Drawing.Point(1152, 7)
        Me.btnContact.Name = "btnContact"
        Me.btnContact.R_ConductorGridSource = Me.conGridCust
        Me.btnContact.R_ConductorSource = Nothing
        Me.btnContact.R_DescriptionId = Nothing
        Me.btnContact.R_EnableHASDATA = True
        Me.btnContact.R_ResourceId = "btnContact"
        Me.btnContact.R_Title = Nothing
        Me.btnContact.Size = New System.Drawing.Size(110, 24)
        Me.btnContact.TabIndex = 0
        Me.btnContact.Text = "R_Detail1"
        '
        'LAM00200
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "LAM00200"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.gvCust.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvCust, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvCust, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridCust, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me.btnContact, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents gvCust As R_FrontEnd.R_RadGridView
    Friend WithEvents bsGvCust As System.Windows.Forms.BindingSource
    Friend WithEvents conGridCust As R_FrontEnd.R_ConductorGrid
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnContact As R_FrontEnd.R_Detail

End Class
