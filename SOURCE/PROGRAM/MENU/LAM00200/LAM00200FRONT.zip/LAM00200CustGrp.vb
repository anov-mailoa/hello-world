﻿Imports R_Common
Imports LAM00200Front.LAM00200StreamingServiceRef
Imports R_FrontEnd
Imports System.ServiceModel.Channels
Imports LAM00200FrontResources

Public Class LAM00200CustGrp

#Region " VARIABLE "
    Dim C_ServiceNameStream As String = "LAM00200Service/LAM00200StreamingService.svc"
#End Region

    Private Sub LAM00200CustGrp_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Try
            gvCustGrp.R_RefreshGrid(New Object)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

    Private Sub gvCustGrp_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvCustGrp.R_ServiceGetListRecord
        Dim loServiceStream As LAM00200StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00200StreamingService, LAM00200StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of LAM00200CustGrpDTO)
        Dim loListEntity As New List(Of LAM00200CustGrpDTO)

        Try
            loRtn = loServiceStream.GetCustGrpList()
            loStreaming = R_StreamUtility(Of LAM00200CustGrpDTO).ReadFromMessage(loRtn)

            For Each loDto As LAM00200CustGrpDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()

    End Sub


End Class
