﻿Imports R_FrontEnd
Imports LAM00200Front.LAM00200ServiceRef
Imports LAM00200Front.LAM00200StreamingServiceRef
Imports R_Common
Imports System.ServiceModel.Channels
Imports ClientHelper
Imports LAM00200FrontResources

Public Class LAM00200

#Region " VARIABLE "
    Dim C_ServiceName As String = "LAM00200Service/LAM00200Service.svc"
    Dim C_ServiceNameStream As String = "LAM00200Service/LAM00200StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
#End Region


    Private Sub LAM00200_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            gvCust.R_RefreshGrid(_CCOMPID)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvCust_R_Before_Open_LookUpForm(sender As Object, e As Telerik.WinControls.UI.EditorRequiredEventArgs, ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles gvCust.R_Before_Open_LookUpForm
        poTargetForm = New LAM00200CustGrp
    End Sub

    Private Sub gvCust_R_Return_LookUp(sender As Object, e As Telerik.WinControls.UI.EditorRequiredEventArgs, poReturnObject As Object) Handles gvCust.R_Return_LookUp
        With gvCust
            .CurrentRow.Cells("_CCUSTOMER_GROUP").Value = poReturnObject.CCUSTOMER_GROUP
            .CurrentRow.Cells("_CCUSTOMER_GROUP_NAME").Value = poReturnObject.CCUSTOMER_GROUP_NAME
        End With

    End Sub

    Private Sub gvCust_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvCust.R_Saving
        With CType(poEntity, LAM00200DTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With
    End Sub

    Private Sub gvCust_R_ServiceDelete(poEntity As Object) Handles gvCust.R_ServiceDelete
        Dim loService As LAM00200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00200Service, LAM00200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            With CType(poEntity, LAM00200DTO)
                ._CCOMPANY_ID = _CCOMPID
            End With

            loService.Svc_R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvCust_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvCust.R_ServiceGetListRecord
        Dim loServiceStream As LAM00200StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00200StreamingService, LAM00200StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of LAM00200GridDTO)
        Dim loListEntity As New List(Of LAM00200DTO)

        Try
            R_Utility.R_SetStreamingContext("cCompId", poEntity)

            loRtn = loServiceStream.GetCustList()
            loStreaming = R_StreamUtility(Of LAM00200GridDTO).ReadFromMessage(loRtn)

            For Each loDto As LAM00200GridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New LAM00200DTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                           ._CCUSTOMER_CODE = loDto.CCUSTOMER_CODE,
                                                           ._CCUSTOMER_NAME = loDto.CCUSTOMER_NAME,
                                                           ._CADDRESS = loDto.CADDRESS,
                                                           ._CZIP_CODE = loDto.CZIP_CODE,
                                                           ._CCITY = loDto.CCITY,
                                                           ._CCOUNTRY = loDto.CCOUNTRY,
                                                           ._CEMAIL_ADDRESS = loDto.CEMAIL_ADDRESS,
                                                           ._CPHONE_1 = loDto.CPHONE_1,
                                                           ._CPHONE_2 = loDto.CPHONE_2,
                                                           ._CFAX_NO = loDto.CFAX_NO,
                                                           ._CLOB_CODE = loDto.CLOB_CODE,
                                                           ._CWEB_SITE = loDto.CWEB_SITE,
                                                           ._CCUSTOMER_GROUP = loDto.CCUSTOMER_GROUP,
                                                           ._CCUSTOMER_GROUP_NAME = loDto.CCUSTOMER_GROUP_NAME,
                                                           ._CCREATE_BY = loDto.CCREATE_BY,
                                                           ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                           ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                           ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvCust_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvCust.R_ServiceGetRecord
        Dim loService As LAM00200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00200Service, LAM00200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New LAM00200DTO With {._CCOMPANY_ID = _CCOMPID,
                                                                            ._CCUSTOMER_CODE = CType(bsGvCust.Current, LAM00200DTO)._CCUSTOMER_CODE})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

    Private Sub gvCust_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvCust.R_ServiceSave
        Dim loService As LAM00200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00200Service, LAM00200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvCust_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvCust.R_Validation
        Dim loEx As New R_Exception()

        Try
            pcError = ""
            With poGridCellCollection
                If String.IsNullOrWhiteSpace(.Item(0).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS001")
                    loEx.Add("PS001", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS001"))
                    plCancel = True
                End If

                If String.IsNullOrWhiteSpace(.Item(1).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS002")
                    loEx.Add("PS002", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS002"))
                    plCancel = True
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub LAM00200_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

    Private Sub btnContact_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnContact.R_Before_Open_Form
        poTargetForm = New LAM00200Contact
        poParameter = CType(bsGvCust.Current, LAM00200DTO)
    End Sub
End Class
