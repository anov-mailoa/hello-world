﻿Imports R_FrontEnd
Imports LAM00200Front.LAM00200ServiceRef
Imports LAM00200Front.LAM00200ContactServiceRef
Imports LAM00200Front.LAM00200StreamingServiceRef
Imports R_Common
Imports System.ServiceModel.Channels
Imports ClientHelper
Imports LAM00200FrontResources

Public Class LAM00200Contact

#Region " VARIABLE "
    Dim C_ServiceName As String = "LAM00200Service/LAM00200ContactService.svc"
    Dim C_ServiceNameStream As String = "LAM00200Service/LAM00200StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CCUSTCODE As String
#End Region

    Private Sub LAM00200Contact_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            _CCUSTCODE = poParameter._CCUSTOMER_CODE
            gvCustContact.R_RefreshGrid(poParameter)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvCust_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvCustContact.R_Saving
        With CType(poEntity, LAM00200ContactDTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CCUSTOMER_CODE = _CCUSTCODE
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With
    End Sub

    Private Sub gvCust_R_ServiceDelete(poEntity As Object) Handles gvCustContact.R_ServiceDelete
        Dim loService As LAM00200ContactServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00200ContactService, LAM00200ContactServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvCust_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvCustContact.R_ServiceGetListRecord
        Dim loServiceStream As LAM00200StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00200StreamingService, LAM00200StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of LAM00200ContactGridDTO)
        Dim loListEntity As New List(Of LAM00200ContactDTO)

        Try
            With CType(poEntity, LAM00200DTO)
                R_Utility.R_SetStreamingContext("cCompId", ._CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cCustCode", ._CCUSTOMER_CODE)
            End With

            loRtn = loServiceStream.GetCustContactList()
            loStreaming = R_StreamUtility(Of LAM00200ContactGridDTO).ReadFromMessage(loRtn)

            For Each loDto As LAM00200ContactGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New LAM00200ContactDTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                                  ._CCUSTOMER_CODE = loDto.CCUSTOMER_CODE,
                                                                  ._CCONTACT_ID = loDto.CCONTACT_ID,
                                                                  ._CCONTACT_NAME = loDto.CCONTACT_NAME,
                                                                  ._CJOB_FUNCTION = loDto.CJOB_FUNCTION,
                                                                  ._CEMAIL_1 = loDto.CEMAIL_1,
                                                                  ._CEMAIL_2 = loDto.CEMAIL_2,
                                                                  ._CPHONE_1 = loDto.CPHONE_1,
                                                                  ._CPHONE_2 = loDto.CPHONE_2,
                                                                  ._CCREATE_BY = loDto.CCREATE_BY,
                                                                  ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                                  ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                                  ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvCust_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvCustContact.R_ServiceGetRecord
        Dim loService As LAM00200ContactServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00200ContactService, LAM00200ContactServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New LAM00200ContactDTO With {._CCOMPANY_ID = _CCOMPID,
                                                                                    ._CCUSTOMER_CODE = CType(poEntity, LAM00200ContactDTO)._CCUSTOMER_CODE,
                                                                                    ._CCONTACT_ID = CType(poEntity, LAM00200ContactDTO)._CCONTACT_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

    Private Sub gvCust_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvCustContact.R_ServiceSave
        Dim loService As LAM00200ContactServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAM00200ContactService, LAM00200ContactServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvCust_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvCustContact.R_Validation
        Dim loEx As New R_Exception()

        Try
            pcError = ""
            With poGridCellCollection
                If String.IsNullOrWhiteSpace(.Item(0).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS001")
                    loEx.Add("PS001", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS001"))
                    plCancel = True
                End If

                If String.IsNullOrWhiteSpace(.Item(1).Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS002")
                    loEx.Add("PS002", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "PS002"))
                    plCancel = True
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub LAM00200_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub
End Class
