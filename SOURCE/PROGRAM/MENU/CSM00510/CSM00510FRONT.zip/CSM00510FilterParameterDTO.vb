﻿Imports CSM00510Front.CSM00510ServiceRef

<Serializable()> _
Public Class CSM00510FilterParameterDTO
    Public Property OFILTER_KEY As CSM00500KeyDTO
    Public Property OAPPS_LIST As List(Of RLicenseAppComboDTO)
    Public Property OVERSION_LIST As List(Of RCustDBVersionComboDTO)
    Public Property OPROJECT_LIST As List(Of RCustDBProjectComboDTO)
    Public Property OSESSION_LIST As List(Of RCustDBSessionComboDTO)
    Public Property CAPPS_NAME As String
    Public Property CCODE_NAME As String
    Public Property CPROJECT_NAME As String
    Public Property CSESSION_STATUS As String
    Public Property LMANAGER As Boolean
    Public Property CSCHEDULE_TYPE As String
    Public Property LCUSTOM As Boolean
    Public Property CVERSION As String
    Public Property CCUSTOMER_CODE As String
    Public Property CCUSTOMER_NAME As String

    Sub New()
        ' initialization
        OFILTER_KEY = New CSM00500KeyDTO
        With OFILTER_KEY
            .CCOMPANY_ID = ""
            .CAPPS_CODE = ""
            .CVERSION = ""
            .CPROJECT_ID = ""
            .CSESSION_ID = ""
            .CSCHEDULE_ID = ""
            .CUSER_ID = ""
        End With
        CAPPS_NAME = ""
        CCODE_NAME = ""
        CPROJECT_NAME = ""
        CSESSION_STATUS = ""
        LMANAGER = False
        CSCHEDULE_TYPE = ""
        LCUSTOM = False
    End Sub
End Class
