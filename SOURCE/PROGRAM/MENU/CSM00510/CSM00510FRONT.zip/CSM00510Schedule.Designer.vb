﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSM00510Schedule
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn1 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim GanttViewTextViewColumn1 As Telerik.WinControls.UI.GanttViewTextViewColumn = New Telerik.WinControls.UI.GanttViewTextViewColumn()
        Dim GanttViewTextViewColumn2 As Telerik.WinControls.UI.GanttViewTextViewColumn = New Telerik.WinControls.UI.GanttViewTextViewColumn()
        Me.bsLocation = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsGvItemSchedule = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridItemSchedule = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.bsFunction = New System.Windows.Forms.BindingSource(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtSchedule = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblSchedule = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtSession = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.cboFunction = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.txtProject = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtVersion = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtApplication = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblFunction = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblSession = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblProject = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblVersion = New R_FrontEnd.R_RadLabel(Me.components)
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.gvIssue = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvIssue = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridIssue = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.lblIssueList = New R_FrontEnd.R_RadLabel(Me.components)
        Me.RadGanttView1 = New Telerik.WinControls.UI.RadGanttView()
        CType(Me.bsLocation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvItemSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridItemSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsFunction, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.txtSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboFunction, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblFunction, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.gvIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvIssue.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblIssueList, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RadGanttView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'bsLocation
        '
        Me.bsLocation.DataSource = GetType(CSM00500Front.CSM00500UsersServiceRef.RCustDBLocationComboDTO)
        '
        'bsGvItemSchedule
        '
        Me.bsGvItemSchedule.DataSource = GetType(CSM00510Front.CSM00510AssignmentServiceRef.CSM00500ItemDTO)
        Me.bsGvItemSchedule.Position = 6
        '
        'conGridItemSchedule
        '
        Me.conGridItemSchedule.R_ConductorParent = Nothing
        Me.conGridItemSchedule.R_IsHeader = True
        Me.conGridItemSchedule.R_RadGroupBox = Nothing
        '
        'bsFunction
        '
        Me.bsFunction.DataSource = GetType(CSM00510Front.CSM00510AssignmentServiceRef.RCustDBFunctionComboDTO)
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.txtSchedule)
        Me.Panel1.Controls.Add(Me.lblSchedule)
        Me.Panel1.Controls.Add(Me.txtSession)
        Me.Panel1.Controls.Add(Me.cboFunction)
        Me.Panel1.Controls.Add(Me.txtProject)
        Me.Panel1.Controls.Add(Me.txtVersion)
        Me.Panel1.Controls.Add(Me.txtApplication)
        Me.Panel1.Controls.Add(Me.lblFunction)
        Me.Panel1.Controls.Add(Me.lblSession)
        Me.Panel1.Controls.Add(Me.lblProject)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Controls.Add(Me.lblVersion)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 174)
        Me.Panel1.TabIndex = 0
        '
        'txtSchedule
        '
        Me.txtSchedule.Location = New System.Drawing.Point(115, 112)
        Me.txtSchedule.Name = "txtSchedule"
        Me.txtSchedule.R_ConductorGridSource = Nothing
        Me.txtSchedule.R_ConductorSource = Nothing
        Me.txtSchedule.R_UDT = Nothing
        Me.txtSchedule.ReadOnly = True
        Me.txtSchedule.Size = New System.Drawing.Size(206, 20)
        Me.txtSchedule.TabIndex = 45
        Me.txtSchedule.TabStop = False
        '
        'lblSchedule
        '
        Me.lblSchedule.AutoSize = False
        Me.lblSchedule.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblSchedule.Location = New System.Drawing.Point(9, 113)
        Me.lblSchedule.Name = "lblSchedule"
        Me.lblSchedule.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblSchedule.R_ResourceId = "lblSchedule"
        Me.lblSchedule.Size = New System.Drawing.Size(100, 18)
        Me.lblSchedule.TabIndex = 44
        Me.lblSchedule.Text = "Application..."
        '
        'txtSession
        '
        Me.txtSession.Location = New System.Drawing.Point(115, 86)
        Me.txtSession.Name = "txtSession"
        Me.txtSession.R_ConductorGridSource = Nothing
        Me.txtSession.R_ConductorSource = Nothing
        Me.txtSession.R_UDT = Nothing
        Me.txtSession.ReadOnly = True
        Me.txtSession.Size = New System.Drawing.Size(206, 20)
        Me.txtSession.TabIndex = 43
        Me.txtSession.TabStop = False
        '
        'cboFunction
        '
        Me.cboFunction.DataSource = Me.bsFunction
        Me.cboFunction.DisplayMember = "CFUNCTION_ID"
        Me.cboFunction.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboFunction.Location = New System.Drawing.Point(115, 138)
        Me.cboFunction.Name = "cboFunction"
        Me.cboFunction.R_ConductorGridSource = Nothing
        Me.cboFunction.R_ConductorSource = Nothing
        Me.cboFunction.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboFunction.Size = New System.Drawing.Size(206, 20)
        Me.cboFunction.TabIndex = 42
        Me.cboFunction.Text = "R_RadDropDownList1"
        Me.cboFunction.ValueMember = "CFUNCTION_ID"
        '
        'txtProject
        '
        Me.txtProject.Location = New System.Drawing.Point(115, 60)
        Me.txtProject.Name = "txtProject"
        Me.txtProject.R_ConductorGridSource = Nothing
        Me.txtProject.R_ConductorSource = Nothing
        Me.txtProject.R_UDT = Nothing
        Me.txtProject.ReadOnly = True
        Me.txtProject.Size = New System.Drawing.Size(206, 20)
        Me.txtProject.TabIndex = 41
        Me.txtProject.TabStop = False
        '
        'txtVersion
        '
        Me.txtVersion.Location = New System.Drawing.Point(115, 34)
        Me.txtVersion.Name = "txtVersion"
        Me.txtVersion.R_ConductorGridSource = Nothing
        Me.txtVersion.R_ConductorSource = Nothing
        Me.txtVersion.R_UDT = Nothing
        Me.txtVersion.ReadOnly = True
        Me.txtVersion.Size = New System.Drawing.Size(206, 20)
        Me.txtVersion.TabIndex = 40
        Me.txtVersion.TabStop = False
        '
        'txtApplication
        '
        Me.txtApplication.Location = New System.Drawing.Point(115, 8)
        Me.txtApplication.Name = "txtApplication"
        Me.txtApplication.R_ConductorGridSource = Nothing
        Me.txtApplication.R_ConductorSource = Nothing
        Me.txtApplication.R_UDT = Nothing
        Me.txtApplication.ReadOnly = True
        Me.txtApplication.Size = New System.Drawing.Size(206, 20)
        Me.txtApplication.TabIndex = 39
        Me.txtApplication.TabStop = False
        '
        'lblFunction
        '
        Me.lblFunction.AutoSize = False
        Me.lblFunction.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblFunction.Location = New System.Drawing.Point(9, 138)
        Me.lblFunction.Name = "lblFunction"
        Me.lblFunction.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblFunction.R_ResourceId = "lblFunction"
        Me.lblFunction.Size = New System.Drawing.Size(100, 18)
        Me.lblFunction.TabIndex = 38
        Me.lblFunction.Text = "Application..."
        '
        'lblSession
        '
        Me.lblSession.AutoSize = False
        Me.lblSession.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblSession.Location = New System.Drawing.Point(9, 87)
        Me.lblSession.Name = "lblSession"
        Me.lblSession.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblSession.R_ResourceId = "lblSession"
        Me.lblSession.Size = New System.Drawing.Size(100, 18)
        Me.lblSession.TabIndex = 37
        Me.lblSession.Text = "Application..."
        '
        'lblProject
        '
        Me.lblProject.AutoSize = False
        Me.lblProject.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblProject.Location = New System.Drawing.Point(9, 61)
        Me.lblProject.Name = "lblProject"
        Me.lblProject.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblProject.R_ResourceId = "lblProject"
        Me.lblProject.Size = New System.Drawing.Size(100, 18)
        Me.lblProject.TabIndex = 36
        Me.lblProject.Text = "Application..."
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 34
        Me.lblApplication.Text = "Application..."
        '
        'lblVersion
        '
        Me.lblVersion.AutoSize = False
        Me.lblVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblVersion.Location = New System.Drawing.Point(9, 35)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblVersion.R_ResourceId = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(100, 18)
        Me.lblVersion.TabIndex = 35
        Me.lblVersion.Text = "Application..."
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.gvIssue, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.lblIssueList, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.RadGanttView1, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 4
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 180.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'gvIssue
        '
        Me.gvIssue.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gvIssue.EnableFastScrolling = True
        Me.gvIssue.Location = New System.Drawing.Point(3, 390)
        '
        '
        '
        Me.gvIssue.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn1.FieldName = "CISSUE_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CISSUE_ID"
        R_GridViewTextBoxColumn1.Name = "_CISSUE_ID"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CISSUE_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 78
        R_GridViewTextBoxColumn2.FieldName = "CUSER_ID"
        R_GridViewTextBoxColumn2.HeaderText = "_CUSER_ID"
        R_GridViewTextBoxColumn2.Name = "_CUSER_ID"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CUSER_ID"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 76
        R_GridViewDateTimeColumn1.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn1.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn1.FieldName = "DISSUE_DATE"
        R_GridViewDateTimeColumn1.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn1.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn1.HeaderText = "_DISSUE_DATE"
        R_GridViewDateTimeColumn1.Name = "_DISSUE_DATE"
        R_GridViewDateTimeColumn1.R_ResourceId = "_DISSUE_DATE"
        R_GridViewDateTimeColumn1.Width = 95
        R_GridViewTextBoxColumn3.FieldName = "CISSUE_CLASS_DESCRIPTION"
        R_GridViewTextBoxColumn3.HeaderText = "_CISSUE_CLASS"
        R_GridViewTextBoxColumn3.Name = "_CISSUE_CLASS"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CISSUE_CLASS"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 99
        R_GridViewTextBoxColumn4.FieldName = "CISSUE_TYPE"
        R_GridViewTextBoxColumn4.HeaderText = "_CISSUE_TYPE"
        R_GridViewTextBoxColumn4.Name = "_CISSUE_TYPE"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CISSUE_TYPE"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 91
        R_GridViewTextBoxColumn5.FieldName = "CDESCRIPTION"
        R_GridViewTextBoxColumn5.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxColumn5.Multiline = True
        R_GridViewTextBoxColumn5.Name = "_CDESCRIPTION"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.ReadOnly = True
        R_GridViewTextBoxColumn5.Width = 103
        R_GridViewTextBoxColumn5.WrapText = True
        R_GridViewCheckBoxColumn1.FieldName = "LOK"
        R_GridViewCheckBoxColumn1.HeaderText = "_LOK"
        R_GridViewCheckBoxColumn1.Name = "_LOK"
        R_GridViewCheckBoxColumn1.R_ResourceId = "_LOK"
        R_GridViewCheckBoxColumn1.Width = 62
        Me.gvIssue.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewDateTimeColumn1, R_GridViewTextBoxColumn3, R_GridViewTextBoxColumn4, R_GridViewTextBoxColumn5, R_GridViewCheckBoxColumn1})
        Me.gvIssue.MasterTemplate.DataSource = Me.bsGvIssue
        Me.gvIssue.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvIssue.MasterTemplate.EnableFiltering = True
        Me.gvIssue.MasterTemplate.EnableGrouping = False
        Me.gvIssue.MasterTemplate.ShowFilteringRow = False
        Me.gvIssue.MasterTemplate.ShowGroupedColumns = True
        Me.gvIssue.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvIssue.Name = "gvIssue"
        Me.gvIssue.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvIssue.R_ConductorGridSource = Me.conGridIssue
        Me.gvIssue.R_ConductorSource = Nothing
        Me.gvIssue.R_DataAdded = False
        Me.gvIssue.R_NewRowText = Nothing
        Me.gvIssue.ReadOnly = True
        Me.gvIssue.ShowHeaderCellButtons = True
        Me.gvIssue.Size = New System.Drawing.Size(1271, 182)
        Me.gvIssue.TabIndex = 4
        Me.gvIssue.Text = "R_RadGridView1"
        '
        'conGridIssue
        '
        Me.conGridIssue.R_ConductorParent = Nothing
        Me.conGridIssue.R_RadGroupBox = Nothing
        '
        'lblIssueList
        '
        Me.lblIssueList.AutoSize = False
        Me.lblIssueList.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblIssueList.Location = New System.Drawing.Point(3, 370)
        Me.lblIssueList.Name = "lblIssueList"
        Me.lblIssueList.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblIssueList.R_ResourceId = "lblIssueList"
        Me.lblIssueList.Size = New System.Drawing.Size(100, 14)
        Me.lblIssueList.TabIndex = 5
        Me.lblIssueList.Text = "R_RadLabel1"
        '
        'RadGanttView1
        '
        GanttViewTextViewColumn1.DataType = Nothing
        GanttViewTextViewColumn1.FieldName = "_CITEM_ID"
        GanttViewTextViewColumn1.HeaderText = "Item"
        GanttViewTextViewColumn1.Name = "column1"
        GanttViewTextViewColumn2.DataType = Nothing
        GanttViewTextViewColumn2.FieldName = "_CUSER_ID"
        GanttViewTextViewColumn2.HeaderText = "User"
        GanttViewTextViewColumn2.Name = "column2"
        Me.RadGanttView1.Columns.AddRange(New Telerik.WinControls.UI.GanttViewTextViewColumn() {GanttViewTextViewColumn1, GanttViewTextViewColumn2})
        Me.RadGanttView1.DataSource = Me.bsGvItemSchedule
        Me.RadGanttView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.RadGanttView1.Location = New System.Drawing.Point(3, 183)
        Me.RadGanttView1.Name = "RadGanttView1"
        Me.RadGanttView1.Size = New System.Drawing.Size(1271, 181)
        Me.RadGanttView1.SplitterWidth = 7
        Me.RadGanttView1.TabIndex = 6
        Me.RadGanttView1.TaskDataMember = Nothing
        Me.RadGanttView1.Text = "RadGanttView1"
        '
        'CSM00510Schedule
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CSM00510Schedule"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.bsLocation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvItemSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridItemSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsFunction, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.txtSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboFunction, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblFunction, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        CType(Me.gvIssue.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvIssue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvIssue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridIssue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblIssueList, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RadGanttView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents conGridItemSchedule As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsGvItemSchedule As System.Windows.Forms.BindingSource
    Friend WithEvents bsFunction As System.Windows.Forms.BindingSource
    Friend WithEvents bsLocation As System.Windows.Forms.BindingSource
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents txtSchedule As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblSchedule As R_FrontEnd.R_RadLabel
    Friend WithEvents txtSession As R_FrontEnd.R_RadTextBox
    Friend WithEvents cboFunction As R_FrontEnd.R_RadDropDownList
    Friend WithEvents txtProject As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtVersion As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtApplication As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblFunction As R_FrontEnd.R_RadLabel
    Friend WithEvents lblSession As R_FrontEnd.R_RadLabel
    Friend WithEvents lblProject As R_FrontEnd.R_RadLabel
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents lblVersion As R_FrontEnd.R_RadLabel
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents conGridIssue As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsGvIssue As System.Windows.Forms.BindingSource
    Friend WithEvents gvIssue As R_FrontEnd.R_RadGridView
    Friend WithEvents lblIssueList As R_FrontEnd.R_RadLabel
    Friend WithEvents RadGanttView1 As Telerik.WinControls.UI.RadGanttView

End Class
