﻿Imports CSM00510Front.CSM00510AssignmentServiceRef
Imports R_FrontEnd
Imports CSM00510FrontResources
Imports R_Common
Imports ClientHelper
Imports CSM00500Front
Imports CSM00510Front.CSM00510AssignmentStreamingServiceRef
Imports System.ServiceModel.Channels
Imports RCustDBFrontHelper.General

Public Class CSM00510Schedule

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSM00510Service/CSM00510AssignmentService.svc"
    Dim C_ServiceNameStream As String = "CSM00510Service/CSM00510AssignmentStreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _CVERSION As String
    Dim _CPROJECTID As String
    Dim _CSESSIONID As String
    Dim _CSCHEDULEID As String
    Dim _CUSER_NAME As String
    Dim _CFUNCTIONID As String
    Dim _CSESSION_STATUS As String
    Dim _LDONE_COMBO_SETTING As Boolean = False
    Dim _LREADY_TO_REFRESH As Boolean = False
    Dim _LINIT As Boolean
    Dim _IGRID_MODE As Integer
    Dim _LMANAGER As Boolean
    Dim _CSCHEDULE_TYPE As String
#End Region

#Region " SUBs and FUNCTIONs "

    Private Sub RefreshGrids(poTableKey As CSM00500ItemKeyDTO)
        Dim llDevelopment As Boolean
        Dim llQC As Boolean
        Dim llRevised As Boolean
        Dim llNoDesign As Boolean
        Dim llNoDevelopment As Boolean

        llNoDesign = (_CSCHEDULE_TYPE = "3" Or _CSCHEDULE_TYPE = "6")
        llNoDevelopment = (_CSCHEDULE_TYPE = "3")
        llDevelopment = (cboFunction.Text = "DEVELOPMENT") And Not llNoDesign
        llQC = (cboFunction.Text = "QC") And Not llNoDevelopment
        llRevised = True
        'With gvItemSchedule
        '    .Columns("_NREVISED_MANDAYS").IsVisible = llRevised
        '    .Columns("_DREVISED_START_DATE").IsVisible = llRevised
        '    .Columns("_DREVISED_END_DATE").IsVisible = llRevised
        '    .Columns("_NDESIGN_MANDAYS").IsVisible = llDevelopment
        '    .Columns("_DDESIGN_PLAN_START").IsVisible = llDevelopment
        '    .Columns("_DDESIGN_PLAN_END").IsVisible = llDevelopment
        '    .Columns("_NREVISED_DESIGN_MANDAYS").IsVisible = llDevelopment And llRevised
        '    .Columns("_DDESIGN_REVISED_START").IsVisible = llDevelopment And llRevised
        '    .Columns("_DDESIGN_REVISED_END").IsVisible = llDevelopment And llRevised
        '    .Columns("_NDEVELOPMENT_MANDAYS").IsVisible = llQC
        '    .Columns("_DDEVELOPMENT_PLAN_START").IsVisible = llQC
        '    .Columns("_DDEVELOPMENT_PLAN_END").IsVisible = llQC
        '    .Columns("_NREVISED_DEVELOPMENT_MANDAYS").IsVisible = llQC And llRevised
        '    .Columns("_DDEVELOPMENT_REVISED_START").IsVisible = llQC And llRevised
        '    .Columns("_DDEVELOPMENT_REVISED_END").IsVisible = llQC And llRevised
        'End With

        'With gvItemSchedule
        '    .R_RefreshGrid(poTableKey)
        '    .Columns(0).Sort(Telerik.WinControls.UI.RadSortOrder.Ascending, False)
        'End With
    End Sub

    Private Sub ComboManager(pcCode As String, pcValue As String)
        Dim loSvc As CSM00510AssignmentServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00510AssignmentService, CSM00510AssignmentServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loProjectKey As New RCustDBProjectKeyDTO
        Dim loTableKey As New CSM00500ItemKeyDTO
        Dim lcValue As String

        ' Refresh Combo
        _LDONE_COMBO_SETTING = False
        With loProjectKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = _CAPPSCODE
            .CVERSION = _CVERSION
            .CPROJECT_ID = _CPROJECTID
            .CSESSION_ID = _CSESSIONID
            .CSTATUS = "*"
            .CUSER_ID = _CUSERID
            .LCHECK_PROJECT_MANAGER = True
        End With

        If pcValue Is Nothing Then
            lcValue = ""
        Else
            lcValue = pcValue
        End If

        Select Case pcCode
            Case "_INIT"
                Dim loFunctionCombo As New List(Of RCustDBFunctionComboDTO)
                Dim loFunctionFind As RCustDBFunctionComboDTO

                loFunctionCombo = loSvc.GetFunctionCombo(loProjectKey)
                If loFunctionCombo.Count <= 0 Then
                    cboFunction.Items.Clear()
                End If
                ' Sesuaikan combo dengan project type
                With loFunctionCombo
                    Select Case _CSCHEDULE_TYPE
                        Case 3
                            loFunctionFind = .Find(Function(x) x.CFUNCTION_ID = "DESIGN")
                            If loFunctionFind IsNot Nothing Then
                                .Remove(loFunctionFind)
                            End If
                            loFunctionFind = .Find(Function(x) x.CFUNCTION_ID = "DEVELOPMENT")
                            If loFunctionFind IsNot Nothing Then
                                .Remove(loFunctionFind)
                            End If
                        Case 6
                            loFunctionFind = .Find(Function(x) x.CFUNCTION_ID = "DESIGN")
                            If loFunctionFind IsNot Nothing Then
                                .Remove(loFunctionFind)
                            End If
                    End Select
                End With
                bsFunction.DataSource = loFunctionCombo
            Case "_CFUNCTION_ID"
                If Not lcValue.Equals(_CFUNCTIONID) Then
                    _CFUNCTIONID = lcValue
                End If

                If bsFunction.DataSource IsNot Nothing Then
                    If bsFunction.Current IsNot Nothing Then
                        _LMANAGER = CType(bsFunction.Current, RCustDBFunctionComboDTO).LMANAGER
                    End If
                End If

        End Select
        loSvc.Close()

        If Not (String.IsNullOrEmpty(_CAPPSCODE) _
                Or String.IsNullOrEmpty(_CVERSION) _
                Or String.IsNullOrEmpty(_CPROJECTID) _
                Or String.IsNullOrEmpty(_CSESSIONID) _
                Or String.IsNullOrEmpty(_CSCHEDULEID) _
                Or String.IsNullOrEmpty(_CFUNCTIONID)) Then
            With loTableKey
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = _CAPPSCODE
                .CVERSION = _CVERSION
                .CPROJECT_ID = _CPROJECTID
                .CSESSION_ID = _CSESSIONID
                .CSCHEDULE_ID = _CSCHEDULEID
                .CFUNCTION_ID = _CFUNCTIONID
            End With
            RefreshGrids(loTableKey)
        End If

    End Sub

#End Region

#Region " FORM Events "

    Private Sub CSM00510_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loSvc As CSM00510AssignmentServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00510AssignmentService, CSM00510AssignmentServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loComboKey As New CSM00510Front.CSM00510ServiceRef.RCustDBProjectKeyDTO
        Dim loLocationCombo As New List(Of RCustDBLocationComboDTO)

        Try
            _LINIT = False
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            With CType(poParameter, CSM00510FilterParameterDTO)
                _CAPPSCODE = .OFILTER_KEY.CAPPS_CODE
                _CVERSION = .OFILTER_KEY.CVERSION
                _CPROJECTID = .OFILTER_KEY.CPROJECT_ID
                _CSESSIONID = .OFILTER_KEY.CSESSION_ID
                _CSCHEDULEID = .OFILTER_KEY.CSCHEDULE_ID
                _CSCHEDULE_TYPE = .CSCHEDULE_TYPE
                txtApplication.Text = .CAPPS_NAME
                txtVersion.Text = .OFILTER_KEY.CVERSION
                txtProject.Text = .CPROJECT_NAME
                txtSession.Text = .OFILTER_KEY.CSESSION_ID
                txtSchedule.Text = .OFILTER_KEY.CSCHEDULE_ID
            End With
            With loComboKey
                .CCOMPANY_ID = _CCOMPID
                .CUSER_ID = _CUSERID
            End With
            ' initialize combo
            cboFunction.Items.Clear()
            ComboManager("_INIT", Nothing)
            loLocationCombo = loSvc.GetLocationCombo()
            bsLocation.DataSource = loLocationCombo

            ' show issue list only for design/program bugs schedule
            TableLayoutPanel1.RowStyles(2).Height = 0
            TableLayoutPanel1.RowStyles(3).Height = 0
            If _CSCHEDULE_TYPE = "5" Or _CSCHEDULE_TYPE = "6" Then
                TableLayoutPanel1.RowStyles(2).Height = 20
                TableLayoutPanel1.RowStyles(3).Height = 50
            End If

            _LINIT = True
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub CSM00510_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " GRIDVIEW Events "

    'Private Sub gvItemSchedule_R_Before_Open_LookUpForm(sender As Object, e As Telerik.WinControls.UI.EditorRequiredEventArgs, ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object)
    '    poTargetForm = New CSM00500UserList
    '    poParameter = New CSM00500UserListParameterDTO With {.CCOMPANY_ID = _CCOMPID, _
    '                                                         .CAPPS_CODE = _CAPPSCODE, _
    '                                                         .CVERSION = _CVERSION, _
    '                                                         .CPROJECT_ID = _CPROJECTID, _
    '                                                         .CFUNCTION_ID = _CFUNCTIONID, _
    '                                                         .CSESSION_ID = _CSESSIONID}
    'End Sub

    'Private Sub gvItemSchedule_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode)
    '    Dim loEx As New R_Exception
    '    Dim loTableKey As New RCustDBIssueKeyDTO

    '    Try
    '        With CType(poEntity, CSM00500ItemDTO)
    '            loTableKey.CCOMPANY_ID = ._CCOMPANY_ID
    '            loTableKey.CAPPS_CODE = ._CAPPS_CODE
    '            loTableKey.CVERSION = ._CVERSION
    '            loTableKey.CPROJECT_ID = ._CPROJECT_ID
    '            loTableKey.CSESSION_ID = ._CSESSION_ID
    '            loTableKey.CATTRIBUTE_GROUP = ._CATTRIBUTE_GROUP
    '            loTableKey.CATTRIBUTE_ID = ._CATTRIBUTE_ID
    '            loTableKey.CITEM_ID = ._CITEM_ID
    '            loTableKey.CSCHEDULE_ID = ._CSCHEDULE_ID
    '        End With
    '        gvIssue.R_RefreshGrid(loTableKey)
    '    Catch ex As Exception
    '        loEx.Add(ex)
    '    End Try

    '    loEx.ThrowExceptionIfErrors()


    'End Sub

    'Private Sub gvItemSchedule_R_Return_LookUp(sender As Object, e As Telerik.WinControls.UI.EditorRequiredEventArgs, poReturnObject As Object)
    '    If gvItemSchedule.CurrentColumn.Name.Trim.Equals("_CUSER_ID") Then
    '        With gvItemSchedule.CurrentRow
    '            .Cells("_CUSER_ID").Value = poReturnObject.CUSER_ID
    '            .Cells("_CREASSIGNMENT_ID").Value = poReturnObject.CUSER_ID
    '            .Cells("_CLOCATION_ID").Value = poReturnObject.CLOCATION_ID
    '        End With
    '    End If
    '    If gvItemSchedule.CurrentColumn.Name.Trim.Equals("_CREASSIGNMENT_ID") Then
    '        With gvItemSchedule.CurrentRow
    '            .Cells("_CREASSIGNMENT_ID").Value = poReturnObject.CUSER_ID
    '            .Cells("_CLOCATION_ID").Value = poReturnObject.CLOCATION_ID
    '        End With
    '    End If
    'End Sub

    'Private Sub gvItemSchedule_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode)
    '    With CType(poEntity, CSM00500ItemDTO)
    '        ._CCOMPANY_ID = _CCOMPID
    '        ._CUPDATE_BY = _CUSERID
    '        ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
    '    End With
    'End Sub

    'Private Sub gvItemSchedule_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object)
    '    Dim loServiceStream As CSM00510AssignmentStreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00510AssignmentStreamingService, CSM00510AssignmentStreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
    '    Dim loException As New R_Exception
    '    Dim loRtn As Message
    '    Dim loStreaming As IEnumerable(Of CSM00500ItemScheduleGridDTO)
    '    Dim loListEntity As New List(Of CSM00500ItemDTO)

    '    Try
    '        With CType(poEntity, CSM00500ItemKeyDTO)
    '            R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
    '            R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
    '            R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
    '            R_Utility.R_SetStreamingContext("cProjectId", .CPROJECT_ID)
    '            R_Utility.R_SetStreamingContext("cSessionId", .CSESSION_ID)
    '            R_Utility.R_SetStreamingContext("cScheduleId", .CSCHEDULE_ID)
    '            R_Utility.R_SetStreamingContext("cFunctionId", .CFUNCTION_ID)
    '        End With

    '        loRtn = loServiceStream.GetItemScheduleList()
    '        loStreaming = R_StreamUtility(Of CSM00500ItemScheduleGridDTO).ReadFromMessage(loRtn)

    '        For Each loDto As CSM00500ItemScheduleGridDTO In loStreaming
    '            If loDto IsNot Nothing Then
    '                loListEntity.Add(New CSM00500ItemDTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
    '                                                              ._CAPPS_CODE = loDto.CAPPS_CODE,
    '                                                            ._CVERSION = loDto.CVERSION,
    '                                                           ._CPROJECT_ID = loDto.CPROJECT_ID,
    '                                                           ._CSESSION_ID = loDto.CSESSION_ID,
    '                                                           ._CSCHEDULE_ID = loDto.CSCHEDULE_ID,
    '                                                           ._CFUNCTION_ID = loDto.CFUNCTION_ID,
    '                                                           ._CUSER_ID = loDto.CUSER_ID,
    '                                                           ._CLOCATION_ID = loDto.CLOCATION_ID,
    '                                                           ._CATTRIBUTE_GROUP = loDto.CATTRIBUTE_GROUP,
    '                                                           ._CATTRIBUTE_ID = loDto.CATTRIBUTE_ID,
    '                                                           ._CITEM_ID = loDto.CITEM_ID,
    '                                                           ._CITEM_NAME = loDto.CITEM_NAME,
    '                                                           ._NMANDAYS = loDto.NMANDAYS,
    '                                                           ._CPLAN_START_DATE = loDto.CPLAN_START_DATE,
    '                                                           ._CPLAN_END_DATE = loDto.CPLAN_END_DATE,
    '                                                           ._DPLAN_START_DATE = StrToDate(loDto.CPLAN_START_DATE),
    '                                                           ._DPLAN_END_DATE = StrToDate(loDto.CPLAN_END_DATE),
    '                                                           ._NREVISED_MANDAYS = loDto.NREVISED_MANDAYS,
    '                                                           ._CREVISED_START_DATE = loDto.CREVISED_START_DATE,
    '                                                           ._CREVISED_END_DATE = loDto.CREVISED_END_DATE,
    '                                                           ._DREVISED_START_DATE = StrToDate(loDto.CREVISED_START_DATE),
    '                                                           ._DREVISED_END_DATE = StrToDate(loDto.CREVISED_END_DATE),
    '                                                           ._NDESIGN_MANDAYS = loDto.NDESIGN_MANDAYS,
    '                                                           ._DDESIGN_PLAN_START = StrToDate(loDto.CDESIGN_PLAN_START),
    '                                                           ._DDESIGN_PLAN_END = StrToDate(loDto.CDESIGN_PLAN_END),
    '                                                           ._NREVISED_DESIGN_MANDAYS = loDto.NREVISED_DESIGN_MANDAYS,
    '                                                           ._DDESIGN_REVISED_START = StrToDate(loDto.CDESIGN_REVISED_START),
    '                                                           ._DDESIGN_REVISED_END = StrToDate(loDto.CDESIGN_REVISED_END),
    '                                                           ._NDEVELOPMENT_MANDAYS = loDto.NDEVELOPMENT_MANDAYS,
    '                                                           ._DDEVELOPMENT_PLAN_START = StrToDate(loDto.CDEVELOPMENT_PLAN_START),
    '                                                           ._DDEVELOPMENT_PLAN_END = StrToDate(loDto.CDEVELOPMENT_PLAN_END),
    '                                                           ._NREVISED_DEVELOPMENT_MANDAYS = loDto.NREVISED_DEVELOPMENT_MANDAYS,
    '                                                           ._DDEVELOPMENT_REVISED_START = StrToDate(loDto.CDEVELOPMENT_REVISED_START),
    '                                                           ._DDEVELOPMENT_REVISED_END = StrToDate(loDto.CDEVELOPMENT_REVISED_END),
    '                                                           ._CREASSIGNMENT_ID = loDto.CREASSIGNMENT_ID,
    '                                                           ._CSTATUS = loDto.CSTATUS,
    '                                                           ._LREVISION = Not (loDto.CREVISED_START_DATE.Trim.Equals("")),
    '                                                           ._LACTUAL_START = loDto.LACTUAL_START,
    '                                                           ._LACTUAL_END = loDto.LACTUAL_END,
    '                                                              ._CCREATE_BY = loDto.CCREATE_BY,
    '                                                              ._DCREATE_DATE = loDto.DCREATE_DATE,
    '                                                              ._CUPDATE_BY = loDto.CUPDATE_BY,
    '                                                              ._DUPDATE_DATE = loDto.DUPDATE_DATE})
    '            Else
    '                Exit For
    '            End If
    '        Next
    '        poListEntityResult = loListEntity
    '    Catch ex As Exception
    '        loException.Add(ex)
    '    End Try
    '    loException.ThrowExceptionIfErrors()
    'End Sub

    'Private Sub gvItemSchedule_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object)
    '    Dim loService As CSM00510AssignmentServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00510AssignmentService, CSM00510AssignmentServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
    '    Dim loEx As New R_Exception

    '    Try
    '        poEntityResult = loService.Svc_R_GetRecord(New CSM00500ItemDTO With {._CCOMPANY_ID = _CCOMPID,
    '                                                                                 ._CAPPS_CODE = _CAPPSCODE,
    '                                                                                 ._CVERSION = _CVERSION,
    '                                                                                 ._CPROJECT_ID = _CPROJECTID,
    '                                                                                 ._CSESSION_ID = _CSESSIONID,
    '                                                                             ._CSCHEDULE_ID = _CSCHEDULEID,
    '                                                                             ._CFUNCTION_ID = cboFunction.SelectedValue,
    '                                                                             ._CATTRIBUTE_GROUP = CType(bsGvItemSchedule.Current, CSM00500ItemDTO)._CATTRIBUTE_GROUP,
    '                                                                             ._CATTRIBUTE_ID = CType(bsGvItemSchedule.Current, CSM00500ItemDTO)._CATTRIBUTE_ID,
    '                                                                                 ._CITEM_ID = CType(bsGvItemSchedule.Current, CSM00500ItemDTO)._CITEM_ID})
    '    Catch ex As Exception
    '        loEx.Add(ex)
    '    End Try

    '    loEx.ThrowExceptionIfErrors()
    'End Sub

    'Private Sub gvItemSchedule_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object)
    '    Dim loService As CSM00510AssignmentServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00510AssignmentService, CSM00510AssignmentServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
    '    Dim loEx As New R_Exception
    '    Dim llEnableEditPlan As Boolean
    '    Dim llEnableReviseStart As Boolean
    '    Dim llEnableReviseEnd As Boolean

    '    Try
    '        With CType(poEntity, CSM00500ItemDTO)
    '            llEnableEditPlan = (._CSTATUS = "PLAN") And _LMANAGER
    '            llEnableReviseStart = Not (._CSTATUS = "PLAN") And Not ._LACTUAL_START And ._CUSER_ID = _CUSERID
    '            llEnableReviseEnd = Not (._CSTATUS = "PLAN") And Not ._LACTUAL_END And ._CUSER_ID = _CUSERID
    '            If llEnableEditPlan Then
    '                ._CREASSIGNMENT_ID = ._CUSER_ID
    '                If ._DPLAN_START_DATE IsNot Nothing Then
    '                    ._CPLAN_START_DATE = ._DPLAN_START_DATE.Value.ToString("yyyyMMdd")
    '                End If
    '            End If
    '            If llEnableReviseStart Then
    '                If ._DREVISED_START_DATE IsNot Nothing Then
    '                    ._CREVISED_START_DATE = ._DREVISED_START_DATE.Value.ToString("yyyyMMdd")
    '                End If
    '            End If
    '            If llEnableReviseEnd Then
    '                If ._DREVISED_END_DATE IsNot Nothing Then
    '                    ._CREVISED_END_DATE = ._DREVISED_END_DATE.Value.ToString("yyyyMMdd")
    '                End If
    '            End If
    '            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
    '        End With
    '        With CType(poEntityResult, CSM00500ItemDTO)
    '            ._DPLAN_START_DATE = StrToDate(._CPLAN_START_DATE)
    '            ._DPLAN_END_DATE = StrToDate(._CPLAN_END_DATE)
    '            ._DREVISED_START_DATE = StrToDate(._CREVISED_START_DATE)
    '            ._DREVISED_END_DATE = StrToDate(._CREVISED_END_DATE)
    '        End With
    '    Catch ex As Exception
    '        loEx.Add(ex)
    '    End Try

    '    loEx.ThrowExceptionIfErrors()
    'End Sub

    'Private Sub gvItemSchedule_R_SetEditGridColumn(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, poGridColumnCollection As Telerik.WinControls.UI.GridViewColumnCollection)
    '    Dim llEnableEditPlan As Boolean
    '    Dim llEnableReviseStart As Boolean
    '    Dim llEnableReviseEnd As Boolean
    '    Dim llEnableReassign As Boolean

    '    With CType(poEntity, CSM00500ItemDTO)
    '        llEnableEditPlan = (._CSTATUS = "PLAN") And _LMANAGER
    '        llEnableReassign = Not (._CSTATUS = "PLAN") And Not (._CSTATUS = "DONE") And _LMANAGER
    '        llEnableReviseStart = Not (._CSTATUS = "PLAN") And Not ._LACTUAL_START And ._CUSER_ID = _CUSERID
    '        llEnableReviseEnd = Not (._CSTATUS = "PLAN") And Not ._LACTUAL_END And ._CUSER_ID = _CUSERID
    '    End With

    '    CType(poGridColumnCollection("_CUSER_ID"), R_GridViewLookUpColumn).ReadOnly = Not llEnableEditPlan
    '    CType(poGridColumnCollection("_CREASSIGNMENT_ID"), R_GridViewLookUpColumn).ReadOnly = Not llEnableReassign
    '    CType(poGridColumnCollection("_CLOCATION_ID"), R_GridViewComboBoxColumn).ReadOnly = Not llEnableEditPlan
    '    CType(poGridColumnCollection("_NMANDAYS"), R_GridViewDecimalColumn).ReadOnly = Not llEnableEditPlan
    '    CType(poGridColumnCollection("_DPLAN_START_DATE"), R_GridViewDateTimeColumn).ReadOnly = Not llEnableEditPlan
    '    CType(poGridColumnCollection("_DREVISED_START_DATE"), R_GridViewDateTimeColumn).ReadOnly = Not llEnableReviseStart
    '    CType(poGridColumnCollection("_DREVISED_END_DATE"), R_GridViewDateTimeColumn).ReadOnly = Not llEnableReviseEnd
    'End Sub

    'Private Sub gvItemSchedule_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvItemSchedule.R_Validation
    '    Dim loEx As New R_Exception()

    '    Try
    '        With poGridCellCollection
    '            If String.IsNullOrEmpty(.Item("_DPLAN_START_DATE").Value) Then
    '                loEx.Add("CSM00510_01", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00510_01"))
    '                plCancel = True
    '            End If
    '            If String.IsNullOrEmpty(.Item("_CLOCATION_ID").Value) Then
    '                loEx.Add("CSM00510_02", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00510_02"))
    '                plCancel = True
    '            End If
    '            If String.IsNullOrEmpty(.Item("_CUSER_ID").Value) Then
    '                loEx.Add("CSM00510_03", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00510_02"))
    '                plCancel = True
    '            End If
    '        End With
    '    Catch ex As Exception
    '        loEx.Add(ex)
    '    End Try

    '    loEx.ThrowExceptionIfErrors()
    'End Sub

#End Region

#Region " MISC "

    Private Sub cboFunction_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboFunction.SelectedValueChanged
        ComboManager("_CFUNCTION_ID", sender.SelectedValue)
    End Sub

#End Region


#Region " ISSUE Gridview "

    Private Sub gvIssue_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvIssue.DataBindingComplete
        gvIssue.BestFitColumns()
    End Sub

    Private Sub gvIssue_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvIssue.R_ServiceGetListRecord
        Dim loServiceStream As CSM00510AssignmentStreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00510AssignmentStreamingService, CSM00510AssignmentStreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of RCustDBIssueListDTO)
        Dim loListEntity As New List(Of RCustDBIssueListDTO)

        Try
            With CType(poEntity, RCustDBIssueKeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
                R_Utility.R_SetStreamingContext("cProjectId", .CPROJECT_ID)
                R_Utility.R_SetStreamingContext("cSessionId", .CSESSION_ID)
                R_Utility.R_SetStreamingContext("cAttributeGroup", .CATTRIBUTE_GROUP)
                R_Utility.R_SetStreamingContext("cAttributeId", .CATTRIBUTE_ID)
                R_Utility.R_SetStreamingContext("cItemId", .CITEM_ID)
                R_Utility.R_SetStreamingContext("cScheduleId", .CSCHEDULE_ID)
                R_Utility.R_SetStreamingContext("cPrevScheduleId", "*")
            End With

            loRtn = loServiceStream.GetIssueList()
            loStreaming = R_StreamUtility(Of RCustDBIssueListDTO).ReadFromMessage(loRtn)

            For Each loDto As RCustDBIssueListDTO In loStreaming
                If loDto IsNot Nothing Then
                    loDto.DISSUE_DATE = StrToDate(loDto.CISSUE_DATE)
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

#End Region


End Class
