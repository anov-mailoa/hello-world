﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSM00510Assign
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewLookUpColumn1 As R_FrontEnd.R_GridViewLookUpColumn = New R_FrontEnd.R_GridViewLookUpColumn()
        Dim R_GridViewLookUpColumn2 As R_FrontEnd.R_GridViewLookUpColumn = New R_FrontEnd.R_GridViewLookUpColumn()
        Dim R_GridViewComboBoxColumn1 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Dim R_GridViewDecimalColumn1 As R_FrontEnd.R_GridViewDecimalColumn = New R_FrontEnd.R_GridViewDecimalColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn2 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDecimalColumn2 As R_FrontEnd.R_GridViewDecimalColumn = New R_FrontEnd.R_GridViewDecimalColumn()
        Dim R_GridViewDateTimeColumn3 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn4 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDecimalColumn3 As R_FrontEnd.R_GridViewDecimalColumn = New R_FrontEnd.R_GridViewDecimalColumn()
        Dim R_GridViewDateTimeColumn5 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn6 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn6 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDecimalColumn4 As R_FrontEnd.R_GridViewDecimalColumn = New R_FrontEnd.R_GridViewDecimalColumn()
        Dim R_GridViewDateTimeColumn7 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn8 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDecimalColumn5 As R_FrontEnd.R_GridViewDecimalColumn = New R_FrontEnd.R_GridViewDecimalColumn()
        Dim R_GridViewDateTimeColumn9 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn10 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDecimalColumn6 As R_FrontEnd.R_GridViewDecimalColumn = New R_FrontEnd.R_GridViewDecimalColumn()
        Dim R_GridViewDateTimeColumn11 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn12 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn7 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn8 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn9 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn10 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn13 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn11 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn12 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn13 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn1 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Me.bsLocation = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsGvItemSchedule = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridItemSchedule = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.bsFunction = New System.Windows.Forms.BindingSource(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblCustom = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblCustomer = New R_FrontEnd.R_RadLabel(Me.components)
        Me.btnStart = New R_FrontEnd.R_RadButton(Me.components)
        Me.btnEstimate = New R_FrontEnd.R_RadButton(Me.components)
        Me.txtSchedule = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblSchedule = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtSession = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.cboFunction = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.txtProject = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtVersion = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtApplication = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblFunction = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblSession = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblProject = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblVersion = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvItemSchedule = New R_FrontEnd.R_RadGridView(Me.components)
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.gvIssue = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvIssue = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridIssue = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.lblIssueList = New R_FrontEnd.R_RadLabel(Me.components)
        CType(Me.bsLocation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvItemSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridItemSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsFunction, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.lblCustom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnStart, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnEstimate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboFunction, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblFunction, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvItemSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvItemSchedule.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.gvIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvIssue.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblIssueList, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'bsLocation
        '
        Me.bsLocation.DataSource = GetType(CSM00500Front.CSM00500UsersServiceRef.RCustDBLocationComboDTO)
        '
        'bsGvItemSchedule
        '
        Me.bsGvItemSchedule.DataSource = GetType(CSM00510Front.CSM00510AssignmentServiceRef.CSM00500ItemDTO)
        '
        'conGridItemSchedule
        '
        Me.conGridItemSchedule.R_ConductorParent = Nothing
        Me.conGridItemSchedule.R_IsHeader = True
        Me.conGridItemSchedule.R_RadGroupBox = Nothing
        '
        'bsFunction
        '
        Me.bsFunction.DataSource = GetType(CSM00510Front.CSM00510AssignmentServiceRef.RCustDBFunctionComboDTO)
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lblCustom)
        Me.Panel1.Controls.Add(Me.lblCustomer)
        Me.Panel1.Controls.Add(Me.btnStart)
        Me.Panel1.Controls.Add(Me.btnEstimate)
        Me.Panel1.Controls.Add(Me.txtSchedule)
        Me.Panel1.Controls.Add(Me.lblSchedule)
        Me.Panel1.Controls.Add(Me.txtSession)
        Me.Panel1.Controls.Add(Me.cboFunction)
        Me.Panel1.Controls.Add(Me.txtProject)
        Me.Panel1.Controls.Add(Me.txtVersion)
        Me.Panel1.Controls.Add(Me.txtApplication)
        Me.Panel1.Controls.Add(Me.lblFunction)
        Me.Panel1.Controls.Add(Me.lblSession)
        Me.Panel1.Controls.Add(Me.lblProject)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Controls.Add(Me.lblVersion)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 174)
        Me.Panel1.TabIndex = 0
        '
        'lblCustom
        '
        Me.lblCustom.AutoSize = False
        Me.lblCustom.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustom.Location = New System.Drawing.Point(327, 61)
        Me.lblCustom.Name = "lblCustom"
        Me.lblCustom.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustom.R_ResourceId = ""
        Me.lblCustom.Size = New System.Drawing.Size(100, 18)
        Me.lblCustom.TabIndex = 51
        Me.lblCustom.Text = "Application..."
        '
        'lblCustomer
        '
        Me.lblCustomer.AutoSize = False
        Me.lblCustomer.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustomer.Location = New System.Drawing.Point(9, 35)
        Me.lblCustomer.Name = "lblCustomer"
        Me.lblCustomer.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustomer.R_ResourceId = "lblCustomer"
        Me.lblCustomer.Size = New System.Drawing.Size(100, 18)
        Me.lblCustomer.TabIndex = 50
        Me.lblCustomer.Text = "Application..."
        '
        'btnStart
        '
        Me.btnStart.Location = New System.Drawing.Point(443, 6)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.R_ConductorGridSource = Me.conGridItemSchedule
        Me.btnStart.R_ConductorSource = Nothing
        Me.btnStart.R_DescriptionId = Nothing
        Me.btnStart.R_EnableHASDATA = True
        Me.btnStart.R_ResourceId = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(110, 24)
        Me.btnStart.TabIndex = 46
        Me.btnStart.Text = "R_RadButton1"
        '
        'btnEstimate
        '
        Me.btnEstimate.Location = New System.Drawing.Point(327, 6)
        Me.btnEstimate.Name = "btnEstimate"
        Me.btnEstimate.R_ConductorGridSource = Me.conGridItemSchedule
        Me.btnEstimate.R_ConductorSource = Nothing
        Me.btnEstimate.R_DescriptionId = Nothing
        Me.btnEstimate.R_EnableHASDATA = True
        Me.btnEstimate.R_ResourceId = "btnEstimate"
        Me.btnEstimate.Size = New System.Drawing.Size(110, 24)
        Me.btnEstimate.TabIndex = 0
        Me.btnEstimate.Text = "R_RadButton1"
        '
        'txtSchedule
        '
        Me.txtSchedule.Location = New System.Drawing.Point(115, 112)
        Me.txtSchedule.Name = "txtSchedule"
        Me.txtSchedule.R_ConductorGridSource = Nothing
        Me.txtSchedule.R_ConductorSource = Nothing
        Me.txtSchedule.R_UDT = Nothing
        Me.txtSchedule.ReadOnly = True
        Me.txtSchedule.Size = New System.Drawing.Size(206, 20)
        Me.txtSchedule.TabIndex = 45
        Me.txtSchedule.TabStop = False
        '
        'lblSchedule
        '
        Me.lblSchedule.AutoSize = False
        Me.lblSchedule.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblSchedule.Location = New System.Drawing.Point(9, 113)
        Me.lblSchedule.Name = "lblSchedule"
        Me.lblSchedule.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblSchedule.R_ResourceId = "lblSchedule"
        Me.lblSchedule.Size = New System.Drawing.Size(100, 18)
        Me.lblSchedule.TabIndex = 44
        Me.lblSchedule.Text = "Application..."
        '
        'txtSession
        '
        Me.txtSession.Location = New System.Drawing.Point(115, 86)
        Me.txtSession.Name = "txtSession"
        Me.txtSession.R_ConductorGridSource = Nothing
        Me.txtSession.R_ConductorSource = Nothing
        Me.txtSession.R_UDT = Nothing
        Me.txtSession.ReadOnly = True
        Me.txtSession.Size = New System.Drawing.Size(206, 20)
        Me.txtSession.TabIndex = 43
        Me.txtSession.TabStop = False
        '
        'cboFunction
        '
        Me.cboFunction.DataSource = Me.bsFunction
        Me.cboFunction.DisplayMember = "CFUNCTION_ID"
        Me.cboFunction.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboFunction.Location = New System.Drawing.Point(115, 138)
        Me.cboFunction.Name = "cboFunction"
        Me.cboFunction.R_ConductorGridSource = Nothing
        Me.cboFunction.R_ConductorSource = Nothing
        Me.cboFunction.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboFunction.Size = New System.Drawing.Size(206, 20)
        Me.cboFunction.TabIndex = 42
        Me.cboFunction.Text = "R_RadDropDownList1"
        Me.cboFunction.ValueMember = "CFUNCTION_ID"
        '
        'txtProject
        '
        Me.txtProject.Location = New System.Drawing.Point(115, 60)
        Me.txtProject.Name = "txtProject"
        Me.txtProject.R_ConductorGridSource = Nothing
        Me.txtProject.R_ConductorSource = Nothing
        Me.txtProject.R_UDT = Nothing
        Me.txtProject.ReadOnly = True
        Me.txtProject.Size = New System.Drawing.Size(206, 20)
        Me.txtProject.TabIndex = 41
        Me.txtProject.TabStop = False
        '
        'txtVersion
        '
        Me.txtVersion.Location = New System.Drawing.Point(115, 34)
        Me.txtVersion.Name = "txtVersion"
        Me.txtVersion.R_ConductorGridSource = Nothing
        Me.txtVersion.R_ConductorSource = Nothing
        Me.txtVersion.R_UDT = Nothing
        Me.txtVersion.ReadOnly = True
        Me.txtVersion.Size = New System.Drawing.Size(206, 20)
        Me.txtVersion.TabIndex = 40
        Me.txtVersion.TabStop = False
        '
        'txtApplication
        '
        Me.txtApplication.Location = New System.Drawing.Point(115, 8)
        Me.txtApplication.Name = "txtApplication"
        Me.txtApplication.R_ConductorGridSource = Nothing
        Me.txtApplication.R_ConductorSource = Nothing
        Me.txtApplication.R_UDT = Nothing
        Me.txtApplication.ReadOnly = True
        Me.txtApplication.Size = New System.Drawing.Size(206, 20)
        Me.txtApplication.TabIndex = 39
        Me.txtApplication.TabStop = False
        '
        'lblFunction
        '
        Me.lblFunction.AutoSize = False
        Me.lblFunction.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblFunction.Location = New System.Drawing.Point(9, 138)
        Me.lblFunction.Name = "lblFunction"
        Me.lblFunction.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblFunction.R_ResourceId = "lblFunction"
        Me.lblFunction.Size = New System.Drawing.Size(100, 18)
        Me.lblFunction.TabIndex = 38
        Me.lblFunction.Text = "Application..."
        '
        'lblSession
        '
        Me.lblSession.AutoSize = False
        Me.lblSession.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblSession.Location = New System.Drawing.Point(9, 87)
        Me.lblSession.Name = "lblSession"
        Me.lblSession.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblSession.R_ResourceId = "lblSession"
        Me.lblSession.Size = New System.Drawing.Size(100, 18)
        Me.lblSession.TabIndex = 37
        Me.lblSession.Text = "Application..."
        '
        'lblProject
        '
        Me.lblProject.AutoSize = False
        Me.lblProject.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblProject.Location = New System.Drawing.Point(9, 61)
        Me.lblProject.Name = "lblProject"
        Me.lblProject.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblProject.R_ResourceId = "lblProject"
        Me.lblProject.Size = New System.Drawing.Size(100, 18)
        Me.lblProject.TabIndex = 36
        Me.lblProject.Text = "Application..."
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 34
        Me.lblApplication.Text = "Application..."
        '
        'lblVersion
        '
        Me.lblVersion.AutoSize = False
        Me.lblVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblVersion.Location = New System.Drawing.Point(9, 35)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblVersion.R_ResourceId = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(100, 18)
        Me.lblVersion.TabIndex = 35
        Me.lblVersion.Text = "Application..."
        '
        'gvItemSchedule
        '
        Me.gvItemSchedule.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvItemSchedule.EnableFastScrolling = True
        Me.gvItemSchedule.Location = New System.Drawing.Point(3, 183)
        '
        '
        '
        Me.gvItemSchedule.MasterTemplate.AllowAddNewRow = False
        Me.gvItemSchedule.MasterTemplate.AllowDeleteRow = False
        Me.gvItemSchedule.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn1.FieldName = "_CGANTT_SEQUENCE"
        R_GridViewTextBoxColumn1.HeaderText = "_CGANTT_SEQUENCE"
        R_GridViewTextBoxColumn1.MaxLength = 5
        R_GridViewTextBoxColumn1.Name = "_CGANTT_SEQUENCE"
        R_GridViewTextBoxColumn1.R_EnableEDIT = True
        R_GridViewTextBoxColumn1.R_ResourceId = "_CGANTT_SEQUENCE"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 129
        R_GridViewTextBoxColumn2.FieldName = "_CITEM_ID"
        R_GridViewTextBoxColumn2.HeaderText = "_CITEM_ID"
        R_GridViewTextBoxColumn2.IsPinned = True
        R_GridViewTextBoxColumn2.Name = "_CITEM_ID"
        R_GridViewTextBoxColumn2.PinPosition = Telerik.WinControls.UI.PinnedColumnPosition.Left
        R_GridViewTextBoxColumn2.R_ResourceId = "_CITEM_ID"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 74
        R_GridViewTextBoxColumn3.FieldName = "_CITEM_NAME"
        R_GridViewTextBoxColumn3.HeaderText = "_CITEM_NAME"
        R_GridViewTextBoxColumn3.IsPinned = True
        R_GridViewTextBoxColumn3.Name = "_CITEM_NAME"
        R_GridViewTextBoxColumn3.PinPosition = Telerik.WinControls.UI.PinnedColumnPosition.Left
        R_GridViewTextBoxColumn3.R_ResourceId = "_CITEM_NAME"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 95
        R_GridViewTextBoxColumn4.FieldName = "_CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn4.HeaderText = "_CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn4.Name = "_CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 131
        R_GridViewTextBoxColumn5.FieldName = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn5.HeaderText = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn5.Name = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 104
        R_GridViewLookUpColumn1.FieldName = "_CUSER_NAME"
        R_GridViewLookUpColumn1.HeaderText = "_CUSER_NAME"
        R_GridViewLookUpColumn1.Name = "_CUSER_NAME"
        R_GridViewLookUpColumn1.R_EnableEDIT = True
        R_GridViewLookUpColumn1.R_ResourceId = "_CUSER_ID"
        R_GridViewLookUpColumn1.R_Title = Nothing
        R_GridViewLookUpColumn1.Width = 97
        R_GridViewLookUpColumn2.FieldName = "_CREASSIGNMENT_NAME"
        R_GridViewLookUpColumn2.HeaderText = "_CREASSIGNMENT_NAME"
        R_GridViewLookUpColumn2.Name = "_CREASSIGNMENT_NAME"
        R_GridViewLookUpColumn2.R_EnableEDIT = True
        R_GridViewLookUpColumn2.R_ResourceId = "_CREASSIGNMENT_NAME"
        R_GridViewLookUpColumn2.R_Title = Nothing
        R_GridViewLookUpColumn2.Width = 152
        R_GridViewComboBoxColumn1.DataSource = Me.bsLocation
        R_GridViewComboBoxColumn1.DisplayMember = "CLOCATION_NAME"
        R_GridViewComboBoxColumn1.FieldName = "_CLOCATION_ID"
        R_GridViewComboBoxColumn1.HeaderText = "_CLOCATION_ID"
        R_GridViewComboBoxColumn1.Name = "_CLOCATION_ID"
        R_GridViewComboBoxColumn1.R_EnableEDIT = True
        R_GridViewComboBoxColumn1.R_ResourceId = "_CLOCATION_ID"
        R_GridViewComboBoxColumn1.ValueMember = "CLOCATION_ID"
        R_GridViewComboBoxColumn1.Width = 104
        R_GridViewDecimalColumn1.DecimalPlaces = 0
        R_GridViewDecimalColumn1.FieldName = "_NDESIGN_MANDAYS"
        R_GridViewDecimalColumn1.FormatString = "{0:N}"
        R_GridViewDecimalColumn1.HeaderText = "_NDESIGN_MANDAYS"
        R_GridViewDecimalColumn1.Name = "_NDESIGN_MANDAYS"
        R_GridViewDecimalColumn1.R_ResourceId = "_NDESIGN_MANDAYS"
        R_GridViewDecimalColumn1.ThousandsSeparator = True
        R_GridViewDecimalColumn1.Width = 132
        R_GridViewDateTimeColumn1.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn1.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn1.FieldName = "_DDESIGN_PLAN_START"
        R_GridViewDateTimeColumn1.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn1.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn1.HeaderText = "_DDESIGN_PLAN_START"
        R_GridViewDateTimeColumn1.Name = "_DDESIGN_PLAN_START"
        R_GridViewDateTimeColumn1.R_ResourceId = "_DDESIGN_PLAN_START"
        R_GridViewDateTimeColumn1.Width = 143
        R_GridViewDateTimeColumn2.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn2.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn2.FieldName = "_DDESIGN_PLAN_END"
        R_GridViewDateTimeColumn2.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn2.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn2.HeaderText = "_DDESIGN_PLAN_END"
        R_GridViewDateTimeColumn2.Name = "_DDESIGN_PLAN_END"
        R_GridViewDateTimeColumn2.R_ResourceId = "_DDESIGN_PLAN_END"
        R_GridViewDateTimeColumn2.Width = 133
        R_GridViewDecimalColumn2.DecimalPlaces = 0
        R_GridViewDecimalColumn2.FieldName = "_NDEVELOPMENT_MANDAYS"
        R_GridViewDecimalColumn2.FormatString = "{0:N}"
        R_GridViewDecimalColumn2.HeaderText = "_NDEVELOPMENT_MANDAYS"
        R_GridViewDecimalColumn2.Name = "_NDEVELOPMENT_MANDAYS"
        R_GridViewDecimalColumn2.R_ResourceId = "_NDEVELOPMENT_MANDAYS"
        R_GridViewDecimalColumn2.ThousandsSeparator = True
        R_GridViewDecimalColumn2.Width = 171
        R_GridViewDateTimeColumn3.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn3.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn3.FieldName = "_DDEVELOPMENT_PLAN_START"
        R_GridViewDateTimeColumn3.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn3.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn3.HeaderText = "_DDEVELOPMENT_PLAN_START"
        R_GridViewDateTimeColumn3.Name = "_DDEVELOPMENT_PLAN_START"
        R_GridViewDateTimeColumn3.R_ResourceId = "_DDEVELOPMENT_PLAN_START"
        R_GridViewDateTimeColumn3.Width = 181
        R_GridViewDateTimeColumn4.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn4.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn4.FieldName = "_DDEVELOPMENT_PLAN_END"
        R_GridViewDateTimeColumn4.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn4.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn4.HeaderText = "_DDEVELOPMENT_PLAN_END"
        R_GridViewDateTimeColumn4.Name = "_DDEVELOPMENT_PLAN_END"
        R_GridViewDateTimeColumn4.R_ResourceId = "_DDEVELOPMENT_PLAN_END"
        R_GridViewDateTimeColumn4.Width = 171
        R_GridViewDecimalColumn3.DecimalPlaces = 0
        R_GridViewDecimalColumn3.FieldName = "_NMANDAYS"
        R_GridViewDecimalColumn3.FormatString = "{0:N}"
        R_GridViewDecimalColumn3.HeaderText = "_NMANDAYS"
        R_GridViewDecimalColumn3.Maximum = New Decimal(New Integer() {4096, 0, 0, 0})
        R_GridViewDecimalColumn3.Minimum = New Decimal(New Integer() {0, 0, 0, 0})
        R_GridViewDecimalColumn3.Name = "_NMANDAYS"
        R_GridViewDecimalColumn3.R_EnableEDIT = True
        R_GridViewDecimalColumn3.R_ResourceId = "_NMANDAYS"
        R_GridViewDecimalColumn3.ThousandsSeparator = True
        R_GridViewDecimalColumn3.Width = 89
        R_GridViewDateTimeColumn5.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn5.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn5.FieldName = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn5.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn5.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn5.HeaderText = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn5.Name = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn5.R_EnableEDIT = True
        R_GridViewDateTimeColumn5.R_ResourceId = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn5.Width = 131
        R_GridViewDateTimeColumn6.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn6.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn6.FieldName = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn6.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn6.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn6.HeaderText = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn6.Name = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn6.R_ResourceId = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn6.Width = 121
        R_GridViewTextBoxColumn6.FieldName = "_CSTATUS"
        R_GridViewTextBoxColumn6.HeaderText = "_CSTATUS"
        R_GridViewTextBoxColumn6.Name = "_CSTATUS"
        R_GridViewTextBoxColumn6.R_ResourceId = "_CSTATUS"
        R_GridViewTextBoxColumn6.R_UDT = Nothing
        R_GridViewTextBoxColumn6.Width = 73
        R_GridViewDecimalColumn4.DecimalPlaces = 0
        R_GridViewDecimalColumn4.FieldName = "_NREVISED_DESIGN_MANDAYS"
        R_GridViewDecimalColumn4.FormatString = "{0:N}"
        R_GridViewDecimalColumn4.HeaderText = "_NREVISED_DESIGN_MANDAYS"
        R_GridViewDecimalColumn4.Name = "_NREVISED_DESIGN_MANDAYS"
        R_GridViewDecimalColumn4.R_ResourceId = "_NREVISED_DESIGN_MANDAYS"
        R_GridViewDecimalColumn4.ThousandsSeparator = True
        R_GridViewDecimalColumn4.Width = 179
        R_GridViewDateTimeColumn7.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn7.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn7.FieldName = "_DDESIGN_REVISED_START"
        R_GridViewDateTimeColumn7.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn7.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn7.HeaderText = "_DDESIGN_REVISED_START"
        R_GridViewDateTimeColumn7.Name = "_DDESIGN_REVISED_START"
        R_GridViewDateTimeColumn7.R_ResourceId = "_DDESIGN_REVISED_START"
        R_GridViewDateTimeColumn7.Width = 157
        R_GridViewDateTimeColumn8.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn8.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn8.FieldName = "_DDESIGN_REVISED_END"
        R_GridViewDateTimeColumn8.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn8.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn8.HeaderText = "_DDESIGN_REVISED_END"
        R_GridViewDateTimeColumn8.Name = "_DDESIGN_REVISED_END"
        R_GridViewDateTimeColumn8.R_ResourceId = "_DDESIGN_REVISED_END"
        R_GridViewDateTimeColumn8.Width = 148
        R_GridViewDecimalColumn5.DecimalPlaces = 0
        R_GridViewDecimalColumn5.FieldName = "_NREVISED_DEVELOPMENT_MANDAYS"
        R_GridViewDecimalColumn5.FormatString = "{0:N}"
        R_GridViewDecimalColumn5.HeaderText = "_NREVISED_DEVELOPMENT_MANDAYS"
        R_GridViewDecimalColumn5.Name = "_NREVISED_DEVELOPMENT_MANDAYS"
        R_GridViewDecimalColumn5.R_ResourceId = "_NREVISED_DEVELOPMENT_MANDAYS"
        R_GridViewDecimalColumn5.ThousandsSeparator = True
        R_GridViewDecimalColumn5.Width = 217
        R_GridViewDateTimeColumn9.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn9.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn9.FieldName = "_DDEVELOPMENT_REVISED_START"
        R_GridViewDateTimeColumn9.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn9.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn9.HeaderText = "_DDEVELOPMENT_REVISED_START"
        R_GridViewDateTimeColumn9.Name = "_DDEVELOPMENT_REVISED_START"
        R_GridViewDateTimeColumn9.R_ResourceId = "_DDEVELOPMENT_REVISED_START"
        R_GridViewDateTimeColumn9.Width = 195
        R_GridViewDateTimeColumn10.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn10.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn10.FieldName = "_DDEVELOPMENT_REVISED_END"
        R_GridViewDateTimeColumn10.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn10.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn10.HeaderText = "_DDEVELOPMENT_REVISED_END"
        R_GridViewDateTimeColumn10.Name = "_DDEVELOPMENT_REVISED_END"
        R_GridViewDateTimeColumn10.R_ResourceId = "_DDEVELOPMENT_REVISED_END"
        R_GridViewDateTimeColumn10.Width = 186
        R_GridViewDecimalColumn6.DecimalPlaces = 0
        R_GridViewDecimalColumn6.FieldName = "_NREVISED_MANDAYS"
        R_GridViewDecimalColumn6.FormatString = "{0:N}"
        R_GridViewDecimalColumn6.HeaderText = "_NREVISED_MANDAYS"
        R_GridViewDecimalColumn6.Maximum = New Decimal(New Integer() {4096, 0, 0, 0})
        R_GridViewDecimalColumn6.Minimum = New Decimal(New Integer() {0, 0, 0, 0})
        R_GridViewDecimalColumn6.Name = "_NREVISED_MANDAYS"
        R_GridViewDecimalColumn6.R_ResourceId = "_NREVISED_MANDAYS"
        R_GridViewDecimalColumn6.ThousandsSeparator = True
        R_GridViewDecimalColumn6.Width = 136
        R_GridViewDateTimeColumn11.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn11.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn11.FieldName = "_DREVISED_START_DATE"
        R_GridViewDateTimeColumn11.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn11.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn11.HeaderText = "_DREVISED_START_DATE"
        R_GridViewDateTimeColumn11.Name = "_DREVISED_START_DATE"
        R_GridViewDateTimeColumn11.R_EnableEDIT = True
        R_GridViewDateTimeColumn11.R_ResourceId = "_DREVISED_START_DATE"
        R_GridViewDateTimeColumn11.Width = 145
        R_GridViewDateTimeColumn12.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn12.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn12.FieldName = "_DREVISED_END_DATE"
        R_GridViewDateTimeColumn12.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn12.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn12.HeaderText = "_DREVISED_END_DATE"
        R_GridViewDateTimeColumn12.Name = "_DREVISED_END_DATE"
        R_GridViewDateTimeColumn12.R_ResourceId = "_DREVISED_END_DATE"
        R_GridViewDateTimeColumn12.Width = 136
        R_GridViewTextBoxColumn7.FieldName = "_CUSER_ID"
        R_GridViewTextBoxColumn7.HeaderText = "_CUSER_ID"
        R_GridViewTextBoxColumn7.IsVisible = False
        R_GridViewTextBoxColumn7.Name = "_CUSER_ID"
        R_GridViewTextBoxColumn7.R_ResourceId = Nothing
        R_GridViewTextBoxColumn7.R_UDT = Nothing
        R_GridViewTextBoxColumn8.FieldName = "_CREASSIGNMENT_ID"
        R_GridViewTextBoxColumn8.HeaderText = "_CREASSIGNMENT_ID"
        R_GridViewTextBoxColumn8.IsVisible = False
        R_GridViewTextBoxColumn8.Name = "_CREASSIGNMENT_ID"
        R_GridViewTextBoxColumn8.R_ResourceId = Nothing
        R_GridViewTextBoxColumn8.R_UDT = Nothing
        Me.gvItemSchedule.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewTextBoxColumn4, R_GridViewTextBoxColumn5, R_GridViewLookUpColumn1, R_GridViewLookUpColumn2, R_GridViewComboBoxColumn1, R_GridViewDecimalColumn1, R_GridViewDateTimeColumn1, R_GridViewDateTimeColumn2, R_GridViewDecimalColumn2, R_GridViewDateTimeColumn3, R_GridViewDateTimeColumn4, R_GridViewDecimalColumn3, R_GridViewDateTimeColumn5, R_GridViewDateTimeColumn6, R_GridViewTextBoxColumn6, R_GridViewDecimalColumn4, R_GridViewDateTimeColumn7, R_GridViewDateTimeColumn8, R_GridViewDecimalColumn5, R_GridViewDateTimeColumn9, R_GridViewDateTimeColumn10, R_GridViewDecimalColumn6, R_GridViewDateTimeColumn11, R_GridViewDateTimeColumn12, R_GridViewTextBoxColumn7, R_GridViewTextBoxColumn8})
        Me.gvItemSchedule.MasterTemplate.DataSource = Me.bsGvItemSchedule
        Me.gvItemSchedule.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvItemSchedule.MasterTemplate.EnableFiltering = True
        Me.gvItemSchedule.MasterTemplate.ShowFilteringRow = False
        Me.gvItemSchedule.MasterTemplate.ShowGroupedColumns = True
        Me.gvItemSchedule.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvItemSchedule.Name = "gvItemSchedule"
        Me.gvItemSchedule.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvItemSchedule.R_ConductorGridSource = Me.conGridItemSchedule
        Me.gvItemSchedule.R_ConductorSource = Nothing
        Me.gvItemSchedule.R_DataAdded = False
        Me.gvItemSchedule.R_EnableGrouping = True
        Me.gvItemSchedule.R_NewRowText = Nothing
        Me.gvItemSchedule.ShowGroupPanel = False
        Me.gvItemSchedule.ShowHeaderCellButtons = True
        Me.gvItemSchedule.Size = New System.Drawing.Size(1271, 181)
        Me.gvItemSchedule.TabIndex = 3
        Me.gvItemSchedule.Text = "R_RadGridView1"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.gvItemSchedule, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.gvIssue, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.lblIssueList, 0, 2)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 4
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 180.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'gvIssue
        '
        Me.gvIssue.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gvIssue.EnableFastScrolling = True
        Me.gvIssue.Location = New System.Drawing.Point(3, 390)
        '
        '
        '
        Me.gvIssue.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn9.FieldName = "CISSUE_ID"
        R_GridViewTextBoxColumn9.HeaderText = "_CISSUE_ID"
        R_GridViewTextBoxColumn9.Name = "_CISSUE_ID"
        R_GridViewTextBoxColumn9.R_ResourceId = "_CISSUE_ID"
        R_GridViewTextBoxColumn9.R_UDT = Nothing
        R_GridViewTextBoxColumn9.Width = 78
        R_GridViewTextBoxColumn10.FieldName = "CUSER_ID"
        R_GridViewTextBoxColumn10.HeaderText = "_CUSER_ID"
        R_GridViewTextBoxColumn10.Name = "_CUSER_ID"
        R_GridViewTextBoxColumn10.R_ResourceId = "_CUSER_ID"
        R_GridViewTextBoxColumn10.R_UDT = Nothing
        R_GridViewTextBoxColumn10.Width = 76
        R_GridViewDateTimeColumn13.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn13.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn13.FieldName = "DISSUE_DATE"
        R_GridViewDateTimeColumn13.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn13.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn13.HeaderText = "_DISSUE_DATE"
        R_GridViewDateTimeColumn13.Name = "_DISSUE_DATE"
        R_GridViewDateTimeColumn13.R_ResourceId = "_DISSUE_DATE"
        R_GridViewDateTimeColumn13.Width = 95
        R_GridViewTextBoxColumn11.FieldName = "CISSUE_CLASS_DESCRIPTION"
        R_GridViewTextBoxColumn11.HeaderText = "_CISSUE_CLASS"
        R_GridViewTextBoxColumn11.Name = "_CISSUE_CLASS"
        R_GridViewTextBoxColumn11.R_ResourceId = "_CISSUE_CLASS"
        R_GridViewTextBoxColumn11.R_UDT = Nothing
        R_GridViewTextBoxColumn11.Width = 99
        R_GridViewTextBoxColumn12.FieldName = "CISSUE_TYPE"
        R_GridViewTextBoxColumn12.HeaderText = "_CISSUE_TYPE"
        R_GridViewTextBoxColumn12.Name = "_CISSUE_TYPE"
        R_GridViewTextBoxColumn12.R_ResourceId = "_CISSUE_TYPE"
        R_GridViewTextBoxColumn12.R_UDT = Nothing
        R_GridViewTextBoxColumn12.Width = 91
        R_GridViewTextBoxColumn13.FieldName = "CDESCRIPTION"
        R_GridViewTextBoxColumn13.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxColumn13.Multiline = True
        R_GridViewTextBoxColumn13.Name = "_CDESCRIPTION"
        R_GridViewTextBoxColumn13.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxColumn13.R_UDT = Nothing
        R_GridViewTextBoxColumn13.ReadOnly = True
        R_GridViewTextBoxColumn13.Width = 103
        R_GridViewTextBoxColumn13.WrapText = True
        R_GridViewCheckBoxColumn1.FieldName = "LOK"
        R_GridViewCheckBoxColumn1.HeaderText = "_LOK"
        R_GridViewCheckBoxColumn1.Name = "_LOK"
        R_GridViewCheckBoxColumn1.R_ResourceId = "_LOK"
        R_GridViewCheckBoxColumn1.Width = 62
        Me.gvIssue.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn9, R_GridViewTextBoxColumn10, R_GridViewDateTimeColumn13, R_GridViewTextBoxColumn11, R_GridViewTextBoxColumn12, R_GridViewTextBoxColumn13, R_GridViewCheckBoxColumn1})
        Me.gvIssue.MasterTemplate.DataSource = Me.bsGvIssue
        Me.gvIssue.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvIssue.MasterTemplate.EnableFiltering = True
        Me.gvIssue.MasterTemplate.EnableGrouping = False
        Me.gvIssue.MasterTemplate.ShowFilteringRow = False
        Me.gvIssue.MasterTemplate.ShowGroupedColumns = True
        Me.gvIssue.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvIssue.Name = "gvIssue"
        Me.gvIssue.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvIssue.R_ConductorGridSource = Me.conGridIssue
        Me.gvIssue.R_ConductorSource = Nothing
        Me.gvIssue.R_DataAdded = False
        Me.gvIssue.R_NewRowText = Nothing
        Me.gvIssue.ReadOnly = True
        Me.gvIssue.ShowHeaderCellButtons = True
        Me.gvIssue.Size = New System.Drawing.Size(1271, 182)
        Me.gvIssue.TabIndex = 4
        Me.gvIssue.Text = "R_RadGridView1"
        '
        'conGridIssue
        '
        Me.conGridIssue.R_ConductorParent = Nothing
        Me.conGridIssue.R_RadGroupBox = Nothing
        '
        'lblIssueList
        '
        Me.lblIssueList.AutoSize = False
        Me.lblIssueList.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblIssueList.Location = New System.Drawing.Point(3, 370)
        Me.lblIssueList.Name = "lblIssueList"
        Me.lblIssueList.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblIssueList.R_ResourceId = "lblIssueList"
        Me.lblIssueList.Size = New System.Drawing.Size(100, 14)
        Me.lblIssueList.TabIndex = 5
        Me.lblIssueList.Text = "R_RadLabel1"
        '
        'CSM00510Assign
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CSM00510Assign"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.bsLocation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvItemSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridItemSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsFunction, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.lblCustom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnStart, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnEstimate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboFunction, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblFunction, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvItemSchedule.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvItemSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        CType(Me.gvIssue.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvIssue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvIssue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridIssue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblIssueList, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents conGridItemSchedule As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsGvItemSchedule As System.Windows.Forms.BindingSource
    Friend WithEvents bsFunction As System.Windows.Forms.BindingSource
    Friend WithEvents bsLocation As System.Windows.Forms.BindingSource
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents txtSchedule As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblSchedule As R_FrontEnd.R_RadLabel
    Friend WithEvents txtSession As R_FrontEnd.R_RadTextBox
    Friend WithEvents cboFunction As R_FrontEnd.R_RadDropDownList
    Friend WithEvents txtProject As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtVersion As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtApplication As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblFunction As R_FrontEnd.R_RadLabel
    Friend WithEvents lblSession As R_FrontEnd.R_RadLabel
    Friend WithEvents lblProject As R_FrontEnd.R_RadLabel
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents lblVersion As R_FrontEnd.R_RadLabel
    Friend WithEvents gvItemSchedule As R_FrontEnd.R_RadGridView
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents conGridIssue As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsGvIssue As System.Windows.Forms.BindingSource
    Friend WithEvents gvIssue As R_FrontEnd.R_RadGridView
    Friend WithEvents lblIssueList As R_FrontEnd.R_RadLabel
    Friend WithEvents btnStart As R_FrontEnd.R_RadButton
    Friend WithEvents btnEstimate As R_FrontEnd.R_RadButton
    Friend WithEvents lblCustomer As R_FrontEnd.R_RadLabel
    Friend WithEvents lblCustom As R_FrontEnd.R_RadLabel

End Class
