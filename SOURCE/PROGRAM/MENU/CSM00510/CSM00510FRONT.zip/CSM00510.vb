﻿Imports CSM00510FrontResources
Imports R_Common
Imports CSM00510Front.CSM00510ServiceRef
Imports R_FrontEnd
Imports ClientHelper
Imports CSM00510Front.CSM00510StreamingServiceRef
Imports System.ServiceModel.Channels
Imports System.ServiceModel
Imports Telerik.WinControls.Data
Imports System.ComponentModel

'Imports CSM00510Front.CSM00510AssignmentServiceRef

Public Class CSM00510

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSM00510Service/CSM00510Service.svc"
    Dim C_ServiceNameStream As String = "CSM00510Service/CSM00510StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _CVERSION As String
    Dim _CPROJECTID As String
    Dim _CSESSIONID As String
    Dim _CUSER_NAME As String
    Dim _CFUNCTIONID As String
    Dim _CSESSION_STATUS As String
    Dim _LDONE_COMBO_SETTING As Boolean = False
    Dim _LREADY_TO_REFRESH As Boolean = False
    Dim _LINIT As Boolean
    Dim _IGRID_MODE As Integer
    Dim _LMANAGER As Boolean
    Dim _CCUSTOMER_NAME As String
    Dim _LCUSTOM As Boolean
    Dim loFilterParam As New CSM00510FilterParameterDTO

#End Region

#Region " SUBs and FUNCTIONs "

    Private Sub RefreshGrids(poTableKey As CSM00500KeyDTO)
        With gvSchedule
            .R_RefreshGrid(poTableKey)
            .Columns(0).Sort(Telerik.WinControls.UI.RadSortOrder.Ascending, False)
        End With
    End Sub

#End Region

#Region " FORM Events "

    Private Sub CSM00510_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loComboKey As New CSM00510Front.CSM00510ServiceRef.RCustDBProjectKeyDTO

        Try
            _LINIT = False
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            _LINIT = True
            ' Predefined dock
            Me.R_Components = Me.components
            preAssign.R_HeaderTitle = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00510AssignTitle")
            loFilterParam.OFILTER_KEY.CCOMPANY_ID = _CCOMPID
            loFilterParam.OFILTER_KEY.CUSER_ID = _CUSERID

            ' Item grid
            Dim loItemGroupDescriptor As New GroupDescriptor()
            loItemGroupDescriptor.GroupNames.Add("_CATTRIBUTE_GROUP", ListSortDirection.Ascending)
            loItemGroupDescriptor.GroupNames.Add("_CATTRIBUTE_NAME", ListSortDirection.Descending)
            Me.gvItem.GroupDescriptors.Add(loItemGroupDescriptor)
            Me.gvItem.AutoExpandGroups = True

            btnFilter.PerformClick()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub CSM00510_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " GRIDVIEW Events "

    Private Sub gvSchedule_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvSchedule.DataBindingComplete
        gvSchedule.BestFitColumns()
    End Sub

    Private Sub gvSchedule_R_CheckDelete(poEntity As Object, ByRef plAllowDelete As Boolean) Handles gvSchedule.R_CheckDelete
        With CType(poEntity, CSM00500ScheduleDTO)
            plAllowDelete = (._CSCHEDULE_TYPE = "0" Or ._CSCHEDULE_TYPE = "1" Or ._CSCHEDULE_TYPE = "2" Or ._CSCHEDULE_TYPE = "3") And Not ._CSTATUS = "CLOSED"
        End With
    End Sub

    Private Sub gvSchedule_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvSchedule.R_Display
        Dim loEx As New R_Exception
        Dim loTableKey As New CSM00500KeyDTO

        Try
            With CType(poEntity, CSM00500ScheduleDTO)
                loTableKey.CCOMPANY_ID = ._CCOMPANY_ID
                loTableKey.CAPPS_CODE = ._CAPPS_CODE
                loTableKey.CVERSION = ._CVERSION
                loTableKey.CPROJECT_ID = ._CPROJECT_ID
                loTableKey.CSESSION_ID = ._CSESSION_ID
                loTableKey.CSCHEDULE_ID = ._CSCHEDULE_ID
            End With
            gvItem.R_RefreshGrid(loTableKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

    Private Sub gvSchedule_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvSchedule.R_Saving
        With CType(poEntity, CSM00500ScheduleDTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With
    End Sub

    Private Sub gvSchedule_R_ServiceDelete(poEntity As Object) Handles gvSchedule.R_ServiceDelete
        Dim loService As CSM00510ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00510Service, CSM00510ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String
        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As FaultException
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

    Private Sub gvSchedule_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvSchedule.R_ServiceGetListRecord
        Dim loServiceStream As CSM00510StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00510StreamingService, CSM00510StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00500ScheduleGridDTO)
        Dim loListEntity As New List(Of CSM00500ScheduleDTO)

        Try
            With CType(poEntity, CSM00500KeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
                R_Utility.R_SetStreamingContext("cProjectId", .CPROJECT_ID)
                R_Utility.R_SetStreamingContext("cSessionId", .CSESSION_ID)
            End With

            loRtn = loServiceStream.GetProjectScheduleList()
            loStreaming = R_StreamUtility(Of CSM00500ScheduleGridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00500ScheduleGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New CSM00500ScheduleDTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                                   ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                                   ._CVERSION = loDto.CVERSION,
                                                                   ._CPROJECT_ID = loDto.CPROJECT_ID,
                                                                   ._CSESSION_ID = loDto.CSESSION_ID,
                                                                   ._CSCHEDULE_ID = loDto.CSCHEDULE_ID,
                                                                   ._CSCHEDULE_TYPE = loDto.CSCHEDULE_TYPE,
                                                                   ._CSCHEDULE_TYPE_NAME = loDto.CSCHEDULE_TYPE_NAME,
                                                                   ._CSTATUS = loDto.CSTATUS,
                                                                   ._CNOTE = loDto.CNOTE,
                                                                   ._CCREATE_BY = loDto.CCREATE_BY,
                                                                   ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                                   ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                                   ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSchedule_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvSchedule.R_ServiceGetRecord
        Dim loService As CSM00510ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00510Service, CSM00510ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New CSM00500ScheduleDTO With {._CCOMPANY_ID = _CCOMPID,
                                                                                     ._CAPPS_CODE = loFilterParam.OFILTER_KEY.CAPPS_CODE,
                                                                                     ._CVERSION = loFilterParam.OFILTER_KEY.CVERSION,
                                                                                     ._CPROJECT_ID = loFilterParam.OFILTER_KEY.CPROJECT_ID,
                                                                                     ._CSESSION_ID = loFilterParam.OFILTER_KEY.CSESSION_ID,
                                                                                     ._CSCHEDULE_ID = CType(bsGvSchedule.Current, CSM00500ScheduleDTO)._CSCHEDULE_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSchedule_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvSchedule.R_ServiceSave
        Dim loService As CSM00510ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00510Service, CSM00510ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            With CType(poEntity, CSM00500ScheduleDTO)
                poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " PREDEFINED DOCK Events "

    Private Sub preAssign_R_InstantiateDock(ByRef poTargetForm As R_FrontEnd.R_FormBase) Handles preAssign.R_InstantiateDock
        poTargetForm = New CSM00510Assign
    End Sub

    Private Sub preAssign_R_PassParameter(ByRef poParameter As Object) Handles preAssign.R_PassParameter
        loFilterParam.OFILTER_KEY.CSCHEDULE_ID = CType(bsGvSchedule.Current, CSM00500ScheduleDTO)._CSCHEDULE_ID
        loFilterParam.CSCHEDULE_TYPE = CType(bsGvSchedule.Current, CSM00500ScheduleDTO)._CSCHEDULE_TYPE
        poParameter = loFilterParam
    End Sub

#End Region

#Region " FILTER "

    Private Sub btnFilter_R_After_Open_Form(poPopUpResult As System.Windows.Forms.DialogResult, poPopUpEntityResult As Object) Handles btnFilter.R_After_Open_Form

        If poPopUpResult = Windows.Forms.DialogResult.OK Then
            loFilterParam = poPopUpEntityResult
            With loFilterParam
                txtApplication.Text = .CAPPS_NAME
                txtVersion.Text = IIf(.LCUSTOM, .CCUSTOMER_NAME, .CCODE_NAME)
                txtProject.Text = .CPROJECT_NAME
                txtSession.Text = .OFILTER_KEY.CSESSION_ID
                lblVersion.Visible = Not .LCUSTOM
                lblCustomer.Visible = .LCUSTOM
                lblCustom.Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), IIf(.LCUSTOM, "rdbCustom", "rdbStandard"))
                RefreshGrids(.OFILTER_KEY)
            End With
        End If
    End Sub

    Private Sub btnFilter_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnFilter.R_Before_Open_Form
        poTargetForm = New CSM00510Filter
        poParameter = loFilterParam
    End Sub

#End Region

#Region " GRIDVIEW ITEM Events "
    Private Sub gvItem_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvItem.DataBindingComplete
        gvItem.BestFitColumns()
    End Sub

    Private Sub gvItem_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvItem.R_ServiceGetListRecord
        Dim loServiceStream As CSM00510StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00510StreamingService, CSM00510StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00500ItemPreviewGridDTO)
        Dim loListEntity As New List(Of CSM00500ItemPreviewGridDTO)

        Try
            With CType(poEntity, CSM00500KeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
                R_Utility.R_SetStreamingContext("cProjectId", .CPROJECT_ID)
                R_Utility.R_SetStreamingContext("cSessionId", .CSESSION_ID)
                R_Utility.R_SetStreamingContext("cScheduleId", .CSCHEDULE_ID)
            End With

            loRtn = loServiceStream.GetItemScheduleList()
            loStreaming = R_StreamUtility(Of CSM00500ItemPreviewGridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00500ItemPreviewGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub
#End Region

#Region " OTHER "

    Private Sub btnStart_Click(sender As Object, e As System.EventArgs) Handles btnStart.Click
        Dim loException As New R_Exception
        Dim loService As CSM00510ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00510Service, CSM00510ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)

        Try
            loFilterParam.OFILTER_KEY.CSCHEDULE_ID = CType(bsGvSchedule.Current, CSM00500ScheduleDTO)._CSCHEDULE_ID
            loService.StartSchedule(loFilterParam.OFILTER_KEY)
            RefreshGrids(loFilterParam.OFILTER_KEY)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        If loException.Haserror Then
            Me.R_DisplayException(loException)
        End If
    End Sub

    Private Sub btnClose_Click(sender As Object, e As System.EventArgs) Handles btnClose.Click
        Dim loException As New R_Exception
        Dim loService As CSM00510ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00510Service, CSM00510ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)

        Try
            loFilterParam.OFILTER_KEY.CSCHEDULE_ID = CType(bsGvSchedule.Current, CSM00500ScheduleDTO)._CSCHEDULE_ID
            loService.CloseSchedule(loFilterParam.OFILTER_KEY)
            RefreshGrids(loFilterParam.OFILTER_KEY)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        If loException.Haserror Then
            Me.R_DisplayException(loException)
        End If
    End Sub

#End Region


End Class
