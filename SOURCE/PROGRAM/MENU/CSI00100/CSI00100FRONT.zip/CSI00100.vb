﻿Imports CSI00100FrontResources
Imports R_Common
Imports CSI00100Front.CSI00100ServiceRef
Imports CSI00100Front.CSI00100StreamingServiceRef
Imports ClientHelper
Imports R_FrontEnd
Imports System.ServiceModel.Channels
Imports RCustDBFrontHelper
Imports Telerik.WinControls.Data
Imports System.ComponentModel

Public Class CSI00100

#Region " VARIABLE "

    Dim C_ServiceName As String = "CSI00100Service/CSI00100Service.svc"
    Dim C_ServiceNameStream As String = "CSI00100Service/CSI00100StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _CVERSION As String
    Dim _CPROJECTID As String
    Dim _COPTION As String
    Dim loFilterParam As New CSI00100FilterParameterDTO

#End Region

#Region " SUBs and FUNCTIONs "

    Private Sub RefreshGrids(poKey As CSI00100ParamDTO)
        With gvProjectStatus
            .R_RefreshGrid(poKey)
        End With
    End Sub

#End Region

#Region " FORM Events "

    Private Sub CSI00100_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loComboKey As New RCustDBProjectKeyDTO

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            With loComboKey
                .CCOMPANY_ID = _CCOMPID
                .CUSER_ID = _CUSERID
            End With
            loFilterParam.OFILTER_KEY.CCOMPANY_ID = _CCOMPID

            ' Project grid
            Dim loItemGroupDescriptor1 As New GroupDescriptor()
            loItemGroupDescriptor1.GroupNames.Add("_CSESSION_NOTE", ListSortDirection.Ascending)
            Dim loItemGroupDescriptor2 As New GroupDescriptor()
            loItemGroupDescriptor2.GroupNames.Add("_CSCHEDULE_DESCRIPTION", ListSortDirection.Ascending)
            loItemGroupDescriptor2.GroupNames.Add("_CSCHEDULE_TYPE_NAME", ListSortDirection.Ascending)
            loItemGroupDescriptor2.GroupNames.Add("_CSCHEDULE_STATUS", ListSortDirection.Ascending)
            Dim loItemGroupDescriptor3 As New GroupDescriptor()
            loItemGroupDescriptor3.GroupNames.Add("_CATTRIBUTE_GROUP", ListSortDirection.Ascending)
            Me.gvProjectStatus.GroupDescriptors.Add(loItemGroupDescriptor1)
            Me.gvProjectStatus.GroupDescriptors.Add(loItemGroupDescriptor2)
            Me.gvProjectStatus.GroupDescriptors.Add(loItemGroupDescriptor3)
            Me.gvProjectStatus.AutoExpandGroups = True

            btnFilter.PerformClick()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " FILTER "

    Private Sub btnFilter_R_After_Open_Form(poPopUpResult As System.Windows.Forms.DialogResult, poPopUpEntityResult As Object) Handles btnFilter.R_After_Open_Form
        Dim loGridKey As New CSI00100ParamDTO

        If poPopUpResult = Windows.Forms.DialogResult.OK Then
            loFilterParam = poPopUpEntityResult
            With loFilterParam
                _CAPPSCODE = .OFILTER_KEY.CAPPS_CODE
                _CVERSION = .OFILTER_KEY.CVERSION
                _CPROJECTID = .OFILTER_KEY.CPROJECT_ID
                _COPTION = .COPTION
                txtApplication.Text = .CAPPS_NAME
                txtVersion.Text = .CCODE_NAME
                txtProject.Text = .CPROJECT_NAME
            End With
            If Not (String.IsNullOrEmpty(_CAPPSCODE) Or String.IsNullOrEmpty(_CVERSION) Or String.IsNullOrEmpty(_CPROJECTID)) Then
                With loGridKey
                    .CCOMPANY_ID = _CCOMPID
                    .CAPPS_CODE = _CAPPSCODE
                    .CVERSION = _CVERSION
                    .CPROJECT_ID = _CPROJECTID
                    .CUSER_ID = _CUSERID
                    .COPTION = _COPTION
                End With
                RefreshGrids(loGridKey)
            End If
        End If

    End Sub

    Private Sub btnFilter_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnFilter.R_Before_Open_Form
        poTargetForm = New CSI00100Filter
        poParameter = loFilterParam
    End Sub

#End Region

#Region " PROJECT STATUS Gridview "

    Private Sub gvProjectStatus_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvProjectStatus.DataBindingComplete
        gvProjectStatus.BestFitColumns()
    End Sub

    Private Sub gvProjectStatus_GroupSummaryEvaluate(sender As Object, e As Telerik.WinControls.UI.GroupSummaryEvaluationEventArgs) Handles gvProjectStatus.GroupSummaryEvaluate

        Select Case e.SummaryItem.Name
            Case "_CSESSION_NOTE"
                e.FormatString = String.Format("Session: {0})", e.Group.Key(0))
            Case "_CSCHEDULE_DESCRIPTION"
                e.FormatString = String.Format("Schedule: {0} (Type: {1} / Status: {2})", e.Group.Key(0), e.Group.Key(1), e.Group.Key(2))
            Case Else
                e.FormatString = "{0}: {1}"
        End Select
    End Sub

    Private Sub gvProjectStatus_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvProjectStatus.R_Display
        Dim loEx As New R_Exception
        Dim loTableKey As New CSI00100ParamDTO
        Dim loProjectStatus As New CSI00100ProjectStatusDTO

        Try
            loProjectStatus = CType(bsGvProjectStatus.Current, CSI00100ProjectStatusDTO)
            With loTableKey
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = _CAPPSCODE
                .CVERSION = _CVERSION
                .CPROJECT_ID = _CPROJECTID
            End With
            With loProjectStatus
                loTableKey.CSESSION_ID = .CSESSION_ID
                loTableKey.CSCHEDULE_ID = .CSCHEDULE_ID
                loTableKey.CATTRIBUTE_GROUP = .CATTRIBUTE_GROUP
                loTableKey.CATTRIBUTE_ID = .CATTRIBUTE_ID
                loTableKey.CITEM_ID = .CITEM_ID
                loTableKey.CFUNCTION_ID = .CFUNCTION_ID
            End With
            gvActionLog.R_RefreshGrid(loTableKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvProjectStatus_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvProjectStatus.R_ServiceGetListRecord
        Dim loServiceStream As CSI00100StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSI00100StreamingService, CSI00100StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSI00100ProjectStatusDTO)
        Dim loListEntity As New List(Of CSI00100ProjectStatusDTO)

        Try
            With CType(poEntity, CSI00100ParamDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
                R_Utility.R_SetStreamingContext("cProjectId", .CPROJECT_ID)
                R_Utility.R_SetStreamingContext("cUserId", .CUSER_ID)
                R_Utility.R_SetStreamingContext("cOption", .COPTION)
            End With

            loRtn = loServiceStream.GetProjectStatus()
            loStreaming = R_StreamUtility(Of CSI00100ProjectStatusDTO).ReadFromMessage(loRtn)

            For Each loDto As CSI00100ProjectStatusDTO In loStreaming
                If loDto IsNot Nothing Then
                    With loDto
                        .DPLAN_START_DATE = General.StrToDate(.CPLAN_START_DATE)
                        .DPLAN_END_DATE = General.StrToDate(.CPLAN_END_DATE)
                        .DACTUAL_START_DATE = General.StrToDate(.CACTUAL_START_DATE)
                        .DACTUAL_END_DATE = General.StrToDate(.CACTUAL_END_DATE)
                    End With
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " ACTION LOG Gridview "

    Private Sub gvActionLog_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvActionLog.DataBindingComplete
        gvActionLog.BestFitColumns()
    End Sub

    Private Sub gvActionLog_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvActionLog.R_ServiceGetListRecord
        Dim loServiceStream As CSI00100StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSI00100StreamingService, CSI00100StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSI00100ActionLogDTO)
        Dim loListEntity As New List(Of CSI00100ActionLogDTO)

        Try
            With CType(poEntity, CSI00100ParamDTO)
                .COPTION = "1"
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
                R_Utility.R_SetStreamingContext("cProjectId", .CPROJECT_ID)
                R_Utility.R_SetStreamingContext("cSessionId", .CSESSION_ID)
                R_Utility.R_SetStreamingContext("cScheduleId", .CSCHEDULE_ID)
                R_Utility.R_SetStreamingContext("cAttributeGroup", .CATTRIBUTE_GROUP)
                R_Utility.R_SetStreamingContext("cAttributeId", .CATTRIBUTE_ID)
                R_Utility.R_SetStreamingContext("cItemId", .CITEM_ID)
                R_Utility.R_SetStreamingContext("cFunctionId", .CFUNCTION_ID)
            End With

            loRtn = loServiceStream.GetActionLog()
            loStreaming = R_StreamUtility(Of CSI00100ActionLogDTO).ReadFromMessage(loRtn)

            For Each loDto As CSI00100ActionLogDTO In loStreaming
                If loDto IsNot Nothing Then
                    With loDto
                        .DACTION_DATE = General.StrToDate(.CACTION_DATE)
                    End With
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()

    End Sub

#End Region

End Class
