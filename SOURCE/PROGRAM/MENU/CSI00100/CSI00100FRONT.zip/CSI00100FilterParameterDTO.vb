﻿Imports CSI00100Front.CSI00100ServiceRef

<Serializable()> _
Public Class CSI00100FilterParameterDTO
    Public Property OFILTER_KEY As CSI00100ParamDTO
    Public Property OAPPS_LIST As List(Of RLicenseAppComboDTO)
    Public Property OVERSION_LIST As List(Of RCustDBVersionComboDTO)
    Public Property OPROJECT_LIST As List(Of RCustDBProjectComboDTO)
    Public Property CAPPS_NAME As String
    Public Property CCODE_NAME As String
    Public Property CPROJECT_NAME As String
    Public Property CSESSION_STATUS As String
    Public Property COPTION As String

    Sub New()
        ' initialization
        OFILTER_KEY = New CSI00100ParamDTO
        With OFILTER_KEY
            .CCOMPANY_ID = ""
            .CAPPS_CODE = ""
            .CVERSION = ""
            .CPROJECT_ID = ""
            .CSESSION_ID = ""
            .CSCHEDULE_ID = ""
            .CUSER_ID = ""
        End With
        CAPPS_NAME = ""
        CPROJECT_NAME = ""
        CSESSION_STATUS = ""
        COPTION = "1"
    End Sub
End Class
