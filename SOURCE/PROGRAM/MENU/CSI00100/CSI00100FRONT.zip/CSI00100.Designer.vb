﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSI00100
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn6 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn7 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn8 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn9 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn10 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn11 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn12 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDecimalColumn1 As R_FrontEnd.R_GridViewDecimalColumn = New R_FrontEnd.R_GridViewDecimalColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn2 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDecimalColumn2 As R_FrontEnd.R_GridViewDecimalColumn = New R_FrontEnd.R_GridViewDecimalColumn()
        Dim R_GridViewDateTimeColumn3 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn4 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn13 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn14 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn15 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn16 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn17 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn18 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn19 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn20 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn21 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn22 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn5 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn23 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.gvProjectStatus = New R_FrontEnd.R_RadGridView(Me.components)
        Me.conGridProjectStatus = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnFilter = New R_FrontEnd.R_PopUp(Me.components)
        Me.txtProject = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtVersion = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtApplication = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblProject = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblVersion = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvActionLog = New R_FrontEnd.R_RadGridView(Me.components)
        Me.conGridActionLog = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.bsGvProjectStatus = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsGvActionLog = New System.Windows.Forms.BindingSource(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.gvProjectStatus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvProjectStatus.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridProjectStatus, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.btnFilter, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvActionLog, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvActionLog.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridActionLog, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvProjectStatus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvActionLog, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.gvProjectStatus, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.gvActionLog, 0, 2)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 96.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 70.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'gvProjectStatus
        '
        Me.gvProjectStatus.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvProjectStatus.EnableFastScrolling = True
        Me.gvProjectStatus.Location = New System.Drawing.Point(3, 99)
        '
        '
        '
        Me.gvProjectStatus.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn1.FieldName = "CSESSION_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CSESSION_ID"
        R_GridViewTextBoxColumn1.IsVisible = False
        R_GridViewTextBoxColumn1.Name = "_CSESSION_ID"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CSESSION_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 93
        R_GridViewTextBoxColumn2.FieldName = "CSCHEDULE_ID"
        R_GridViewTextBoxColumn2.HeaderText = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn2.IsVisible = False
        R_GridViewTextBoxColumn2.Name = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 103
        R_GridViewTextBoxColumn3.FieldName = "CSCHEDULE_TYPE_NAME"
        R_GridViewTextBoxColumn3.HeaderText = "_CSCHEDULE_TYPE_NAME"
        R_GridViewTextBoxColumn3.IsVisible = False
        R_GridViewTextBoxColumn3.Name = "_CSCHEDULE_TYPE_NAME"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CSCHEDULE_TYPE_NAME"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 153
        R_GridViewTextBoxColumn4.FieldName = "CSCHEDULE_STATUS"
        R_GridViewTextBoxColumn4.HeaderText = "_CSCHEDULE_STATUS"
        R_GridViewTextBoxColumn4.IsVisible = False
        R_GridViewTextBoxColumn4.Name = "_CSCHEDULE_STATUS"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CSCHEDULE_STATUS"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 131
        R_GridViewTextBoxColumn5.FieldName = "CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn5.HeaderText = "_CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn5.IsVisible = False
        R_GridViewTextBoxColumn5.Name = "_CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CATTRIBUTE_GROUP"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 131
        R_GridViewTextBoxColumn6.FieldName = "CATTRIBUTE_ID"
        R_GridViewTextBoxColumn6.HeaderText = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn6.Name = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn6.R_ResourceId = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn6.R_UDT = Nothing
        R_GridViewTextBoxColumn6.Width = 104
        R_GridViewTextBoxColumn7.FieldName = "CITEM_ID"
        R_GridViewTextBoxColumn7.HeaderText = "_CITEM_ID"
        R_GridViewTextBoxColumn7.Name = "_CITEM_ID"
        R_GridViewTextBoxColumn7.R_ResourceId = "_CITEM_ID"
        R_GridViewTextBoxColumn7.R_UDT = Nothing
        R_GridViewTextBoxColumn7.Width = 74
        R_GridViewTextBoxColumn8.FieldName = "CITEM_NAME"
        R_GridViewTextBoxColumn8.HeaderText = "_CITEM_NAME"
        R_GridViewTextBoxColumn8.Name = "_CITEM_NAME"
        R_GridViewTextBoxColumn8.R_ResourceId = "_CITEM_NAME"
        R_GridViewTextBoxColumn8.R_UDT = Nothing
        R_GridViewTextBoxColumn8.Width = 90
        R_GridViewTextBoxColumn9.FieldName = "CFUNCTION_ID"
        R_GridViewTextBoxColumn9.HeaderText = "_CFUNCTION_ID"
        R_GridViewTextBoxColumn9.Name = "_CFUNCTION_ID"
        R_GridViewTextBoxColumn9.R_ResourceId = "_CFUNCTION_ID"
        R_GridViewTextBoxColumn9.R_UDT = Nothing
        R_GridViewTextBoxColumn9.Width = 104
        R_GridViewTextBoxColumn10.FieldName = "CUSER_ID"
        R_GridViewTextBoxColumn10.HeaderText = "_CUSER_ID"
        R_GridViewTextBoxColumn10.Name = "_CUSER_ID"
        R_GridViewTextBoxColumn10.R_ResourceId = "_CUSER_ID"
        R_GridViewTextBoxColumn10.R_UDT = Nothing
        R_GridViewTextBoxColumn10.Width = 76
        R_GridViewTextBoxColumn11.FieldName = "CREASSIGNMENT_ID"
        R_GridViewTextBoxColumn11.HeaderText = "_CREASSIGNMENT_ID"
        R_GridViewTextBoxColumn11.Name = "_CREASSIGNMENT_ID"
        R_GridViewTextBoxColumn11.R_ResourceId = "_CREASSIGNMENT_ID"
        R_GridViewTextBoxColumn11.R_UDT = Nothing
        R_GridViewTextBoxColumn11.Width = 131
        R_GridViewTextBoxColumn12.AcceptsTab = True
        R_GridViewTextBoxColumn12.FieldName = "CLOCATION_ID"
        R_GridViewTextBoxColumn12.HeaderText = "_CLOCATION_ID"
        R_GridViewTextBoxColumn12.Name = "_CLOCATION_ID"
        R_GridViewTextBoxColumn12.R_ResourceId = "_CLOCATION_ID"
        R_GridViewTextBoxColumn12.R_UDT = Nothing
        R_GridViewTextBoxColumn12.Width = 104
        R_GridViewDecimalColumn1.FieldName = "NMANDAYS"
        R_GridViewDecimalColumn1.FormatString = "{0:N}"
        R_GridViewDecimalColumn1.HeaderText = "_NMANDAYS"
        R_GridViewDecimalColumn1.Name = "_NMANDAYS"
        R_GridViewDecimalColumn1.R_ResourceId = "_NMANDAYS"
        R_GridViewDecimalColumn1.ThousandsSeparator = True
        R_GridViewDecimalColumn1.Width = 89
        R_GridViewDateTimeColumn1.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn1.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn1.FieldName = "DPLAN_START_DATE"
        R_GridViewDateTimeColumn1.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn1.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn1.HeaderText = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn1.Name = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn1.R_ResourceId = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn1.Width = 131
        R_GridViewDateTimeColumn2.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn2.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn2.FieldName = "DPLAN_END_DATE"
        R_GridViewDateTimeColumn2.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn2.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn2.HeaderText = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn2.Name = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn2.R_ResourceId = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn2.Width = 121
        R_GridViewDecimalColumn2.FieldName = "NACTUAL_MANDAYS"
        R_GridViewDecimalColumn2.FormatString = "{0:N}"
        R_GridViewDecimalColumn2.HeaderText = "_NACTUAL_MANDAYS"
        R_GridViewDecimalColumn2.Name = "_NACTUAL_MANDAYS"
        R_GridViewDecimalColumn2.R_ResourceId = "_NACTUAL_MANDAYS"
        R_GridViewDecimalColumn2.ThousandsSeparator = True
        R_GridViewDecimalColumn2.Width = 134
        R_GridViewDateTimeColumn3.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn3.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn3.FieldName = "DACTUAL_START_DATE"
        R_GridViewDateTimeColumn3.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn3.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn3.HeaderText = "_DACTUAL_START_DATE"
        R_GridViewDateTimeColumn3.Name = "_DACTUAL_START_DATE"
        R_GridViewDateTimeColumn3.R_ResourceId = "_DACTUAL_START_DATE"
        R_GridViewDateTimeColumn3.Width = 144
        R_GridViewDateTimeColumn4.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn4.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn4.FieldName = "DACTUAL_END_DATE"
        R_GridViewDateTimeColumn4.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn4.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn4.HeaderText = "_DACTUAL_END_DATE"
        R_GridViewDateTimeColumn4.Name = "_DACTUAL_END_DATE"
        R_GridViewDateTimeColumn4.R_ResourceId = "_DACTUAL_END_DATE"
        R_GridViewDateTimeColumn4.Width = 134
        R_GridViewTextBoxColumn13.FieldName = "CITEM_STATUS"
        R_GridViewTextBoxColumn13.HeaderText = "_CITEM_STATUS"
        R_GridViewTextBoxColumn13.Name = "_CITEM_STATUS"
        R_GridViewTextBoxColumn13.R_ResourceId = "_CITEM_STATUS"
        R_GridViewTextBoxColumn13.R_UDT = Nothing
        R_GridViewTextBoxColumn13.Width = 102
        R_GridViewTextBoxColumn14.FieldName = "CITEM_SCHEDULE_STATUS"
        R_GridViewTextBoxColumn14.HeaderText = "_CITEM_SCHEDULE_STATUS"
        R_GridViewTextBoxColumn14.Name = "_CITEM_SCHEDULE_STATUS"
        R_GridViewTextBoxColumn14.R_ResourceId = "_CITEM_SCHEDULE_STATUS"
        R_GridViewTextBoxColumn14.R_UDT = Nothing
        R_GridViewTextBoxColumn14.Width = 161
        R_GridViewTextBoxColumn15.FieldName = "CLAST_ACTION"
        R_GridViewTextBoxColumn15.HeaderText = "_CLAST_ACTION"
        R_GridViewTextBoxColumn15.Name = "_CLAST_ACTION"
        R_GridViewTextBoxColumn15.R_ResourceId = "_CLAST_ACTION"
        R_GridViewTextBoxColumn15.R_UDT = Nothing
        R_GridViewTextBoxColumn15.Width = 103
        R_GridViewTextBoxColumn16.FieldName = "CLAST_ACTION_BY"
        R_GridViewTextBoxColumn16.HeaderText = "_CLAST_ACTION_BY"
        R_GridViewTextBoxColumn16.Name = "_CLAST_ACTION_BY"
        R_GridViewTextBoxColumn16.R_ResourceId = "_CLAST_ACTION_BY"
        R_GridViewTextBoxColumn16.R_UDT = Nothing
        R_GridViewTextBoxColumn16.Width = 121
        R_GridViewTextBoxColumn17.FieldName = "CCURRENT_SCHEDULE_ID"
        R_GridViewTextBoxColumn17.HeaderText = "_CCURRENT_SCHEDULE_ID"
        R_GridViewTextBoxColumn17.Name = "_CCURRENT_SCHEDULE_ID"
        R_GridViewTextBoxColumn17.R_ResourceId = "_CCURRENT_SCHEDULE_ID"
        R_GridViewTextBoxColumn17.R_UDT = Nothing
        R_GridViewTextBoxColumn17.Width = 156
        R_GridViewTextBoxColumn18.FieldName = "CASSIGNMENT_STATUS"
        R_GridViewTextBoxColumn18.HeaderText = "_CASSIGNMENT_STATUS"
        R_GridViewTextBoxColumn18.Name = "_CASSIGNMENT_STATUS"
        R_GridViewTextBoxColumn18.R_ResourceId = "_CASSIGNMENT_STATUS"
        R_GridViewTextBoxColumn18.R_UDT = Nothing
        R_GridViewTextBoxColumn18.Width = 147
        R_GridViewTextBoxColumn19.FieldName = "CSESSION_NOTE"
        R_GridViewTextBoxColumn19.HeaderText = "_CSESSION_NOTE"
        R_GridViewTextBoxColumn19.IsVisible = False
        R_GridViewTextBoxColumn19.Name = "_CSESSION_NOTE"
        R_GridViewTextBoxColumn19.R_ResourceId = Nothing
        R_GridViewTextBoxColumn19.R_UDT = Nothing
        R_GridViewTextBoxColumn20.FieldName = "CSCHEDULE_DESCRIPTION"
        R_GridViewTextBoxColumn20.HeaderText = "_CSCHEDULE_DESCRIPTION"
        R_GridViewTextBoxColumn20.IsVisible = False
        R_GridViewTextBoxColumn20.Name = "_CSCHEDULE_DESCRIPTION"
        R_GridViewTextBoxColumn20.R_ResourceId = Nothing
        R_GridViewTextBoxColumn20.R_UDT = Nothing
        Me.gvProjectStatus.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewTextBoxColumn4, R_GridViewTextBoxColumn5, R_GridViewTextBoxColumn6, R_GridViewTextBoxColumn7, R_GridViewTextBoxColumn8, R_GridViewTextBoxColumn9, R_GridViewTextBoxColumn10, R_GridViewTextBoxColumn11, R_GridViewTextBoxColumn12, R_GridViewDecimalColumn1, R_GridViewDateTimeColumn1, R_GridViewDateTimeColumn2, R_GridViewDecimalColumn2, R_GridViewDateTimeColumn3, R_GridViewDateTimeColumn4, R_GridViewTextBoxColumn13, R_GridViewTextBoxColumn14, R_GridViewTextBoxColumn15, R_GridViewTextBoxColumn16, R_GridViewTextBoxColumn17, R_GridViewTextBoxColumn18, R_GridViewTextBoxColumn19, R_GridViewTextBoxColumn20})
        Me.gvProjectStatus.MasterTemplate.DataSource = Me.bsGvProjectStatus
        Me.gvProjectStatus.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvProjectStatus.MasterTemplate.EnableFiltering = True
        Me.gvProjectStatus.MasterTemplate.ShowFilteringRow = False
        Me.gvProjectStatus.MasterTemplate.ShowGroupedColumns = True
        Me.gvProjectStatus.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvProjectStatus.Name = "gvProjectStatus"
        Me.gvProjectStatus.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvProjectStatus.R_ConductorGridSource = Me.conGridProjectStatus
        Me.gvProjectStatus.R_ConductorSource = Nothing
        Me.gvProjectStatus.R_DataAdded = False
        Me.gvProjectStatus.R_EnableGrouping = True
        Me.gvProjectStatus.R_NewRowText = Nothing
        Me.gvProjectStatus.ReadOnly = True
        Me.gvProjectStatus.ShowGroupPanel = False
        Me.gvProjectStatus.ShowHeaderCellButtons = True
        Me.gvProjectStatus.Size = New System.Drawing.Size(1271, 329)
        Me.gvProjectStatus.TabIndex = 0
        Me.gvProjectStatus.Text = "R_RadGridView1"
        '
        'conGridProjectStatus
        '
        Me.conGridProjectStatus.R_ConductorParent = Nothing
        Me.conGridProjectStatus.R_IsHeader = True
        Me.conGridProjectStatus.R_RadGroupBox = Nothing
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnFilter)
        Me.Panel1.Controls.Add(Me.txtProject)
        Me.Panel1.Controls.Add(Me.txtVersion)
        Me.Panel1.Controls.Add(Me.txtApplication)
        Me.Panel1.Controls.Add(Me.lblProject)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Controls.Add(Me.lblVersion)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 90)
        Me.Panel1.TabIndex = 1
        '
        'btnFilter
        '
        Me.btnFilter.Location = New System.Drawing.Point(539, 6)
        Me.btnFilter.Name = "btnFilter"
        Me.btnFilter.R_ConductorGridSource = Me.conGridProjectStatus
        Me.btnFilter.R_ConductorSource = Nothing
        Me.btnFilter.R_DescriptionId = Nothing
        Me.btnFilter.R_ResourceId = "btnFilter"
        Me.btnFilter.R_Title = "Project Filter"
        Me.btnFilter.Size = New System.Drawing.Size(110, 24)
        Me.btnFilter.TabIndex = 57
        Me.btnFilter.Text = "R_PopUp1"
        '
        'txtProject
        '
        Me.txtProject.Location = New System.Drawing.Point(115, 60)
        Me.txtProject.Name = "txtProject"
        Me.txtProject.R_ConductorGridSource = Nothing
        Me.txtProject.R_ConductorSource = Nothing
        Me.txtProject.R_UDT = Nothing
        Me.txtProject.ReadOnly = True
        Me.txtProject.Size = New System.Drawing.Size(400, 20)
        Me.txtProject.TabIndex = 56
        Me.txtProject.TabStop = False
        '
        'txtVersion
        '
        Me.txtVersion.Location = New System.Drawing.Point(115, 34)
        Me.txtVersion.Name = "txtVersion"
        Me.txtVersion.R_ConductorGridSource = Nothing
        Me.txtVersion.R_ConductorSource = Nothing
        Me.txtVersion.R_UDT = Nothing
        Me.txtVersion.ReadOnly = True
        Me.txtVersion.Size = New System.Drawing.Size(200, 20)
        Me.txtVersion.TabIndex = 55
        Me.txtVersion.TabStop = False
        '
        'txtApplication
        '
        Me.txtApplication.Location = New System.Drawing.Point(115, 8)
        Me.txtApplication.Name = "txtApplication"
        Me.txtApplication.R_ConductorGridSource = Nothing
        Me.txtApplication.R_ConductorSource = Nothing
        Me.txtApplication.R_UDT = Nothing
        Me.txtApplication.ReadOnly = True
        Me.txtApplication.Size = New System.Drawing.Size(400, 20)
        Me.txtApplication.TabIndex = 54
        Me.txtApplication.TabStop = False
        '
        'lblProject
        '
        Me.lblProject.AutoSize = False
        Me.lblProject.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblProject.Location = New System.Drawing.Point(9, 61)
        Me.lblProject.Name = "lblProject"
        Me.lblProject.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblProject.R_ResourceId = "lblProject"
        Me.lblProject.Size = New System.Drawing.Size(100, 18)
        Me.lblProject.TabIndex = 53
        Me.lblProject.Text = "Application..."
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 51
        Me.lblApplication.Text = "Application..."
        '
        'lblVersion
        '
        Me.lblVersion.AutoSize = False
        Me.lblVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblVersion.Location = New System.Drawing.Point(9, 35)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblVersion.R_ResourceId = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(100, 18)
        Me.lblVersion.TabIndex = 52
        Me.lblVersion.Text = "Application..."
        '
        'gvActionLog
        '
        Me.gvActionLog.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvActionLog.EnableFastScrolling = True
        Me.gvActionLog.Location = New System.Drawing.Point(3, 434)
        '
        '
        '
        Me.gvActionLog.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn21.FieldName = "CACTION"
        R_GridViewTextBoxColumn21.HeaderText = "_CACTION"
        R_GridViewTextBoxColumn21.Name = "_CACTION"
        R_GridViewTextBoxColumn21.R_ResourceId = "_CACTION"
        R_GridViewTextBoxColumn21.R_UDT = Nothing
        R_GridViewTextBoxColumn21.Width = 74
        R_GridViewTextBoxColumn22.FieldName = "CSEQUENCE"
        R_GridViewTextBoxColumn22.HeaderText = "_CSEQUENCE"
        R_GridViewTextBoxColumn22.Name = "_CSEQUENCE"
        R_GridViewTextBoxColumn22.R_ResourceId = "_CSEQUENCE"
        R_GridViewTextBoxColumn22.R_UDT = Nothing
        R_GridViewTextBoxColumn22.Width = 89
        R_GridViewDateTimeColumn5.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn5.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn5.FieldName = "DACTION_DATE"
        R_GridViewDateTimeColumn5.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn5.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn5.HeaderText = "_DACTION_DATE"
        R_GridViewDateTimeColumn5.Name = "_DACTION_DATE"
        R_GridViewDateTimeColumn5.R_ResourceId = "_DACTION_DATE"
        R_GridViewDateTimeColumn5.Width = 107
        R_GridViewTextBoxColumn23.FieldName = "CACTION_TIME"
        R_GridViewTextBoxColumn23.HeaderText = "_CACTION_TIME"
        R_GridViewTextBoxColumn23.Name = "_CACTION_TIME"
        R_GridViewTextBoxColumn23.R_ResourceId = "_CACTION_TIME"
        R_GridViewTextBoxColumn23.R_UDT = Nothing
        R_GridViewTextBoxColumn23.Width = 104
        Me.gvActionLog.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn21, R_GridViewTextBoxColumn22, R_GridViewDateTimeColumn5, R_GridViewTextBoxColumn23})
        Me.gvActionLog.MasterTemplate.DataSource = Me.bsGvActionLog
        Me.gvActionLog.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvActionLog.MasterTemplate.EnableFiltering = True
        Me.gvActionLog.MasterTemplate.EnableGrouping = False
        Me.gvActionLog.MasterTemplate.ShowFilteringRow = False
        Me.gvActionLog.MasterTemplate.ShowGroupedColumns = True
        Me.gvActionLog.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvActionLog.Name = "gvActionLog"
        Me.gvActionLog.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvActionLog.R_ConductorGridSource = Me.conGridActionLog
        Me.gvActionLog.R_ConductorSource = Nothing
        Me.gvActionLog.R_DataAdded = False
        Me.gvActionLog.R_NewRowText = Nothing
        Me.gvActionLog.ReadOnly = True
        Me.gvActionLog.ShowHeaderCellButtons = True
        Me.gvActionLog.Size = New System.Drawing.Size(1271, 138)
        Me.gvActionLog.TabIndex = 2
        Me.gvActionLog.Text = "R_RadGridView1"
        '
        'conGridActionLog
        '
        Me.conGridActionLog.R_ConductorParent = Me.conGridProjectStatus
        Me.conGridActionLog.R_RadGroupBox = Nothing
        '
        'bsGvProjectStatus
        '
        Me.bsGvProjectStatus.DataSource = GetType(CSI00100Front.CSI00100StreamingServiceRef.CSI00100ProjectStatusDTO)
        '
        'bsGvActionLog
        '
        Me.bsGvActionLog.DataSource = GetType(CSI00100Front.CSI00100StreamingServiceRef.CSI00100ActionLogDTO)
        '
        'CSI00100
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CSI00100"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.TableLayoutPanel1.ResumeLayout(False)
        CType(Me.gvProjectStatus.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvProjectStatus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridProjectStatus, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.btnFilter, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvActionLog.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvActionLog, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridActionLog, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvProjectStatus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvActionLog, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents bsGvProjectStatus As System.Windows.Forms.BindingSource
    Friend WithEvents bsGvActionLog As System.Windows.Forms.BindingSource
    Friend WithEvents conGridProjectStatus As R_FrontEnd.R_ConductorGrid
    Friend WithEvents gvProjectStatus As R_FrontEnd.R_RadGridView
    Friend WithEvents conGridActionLog As R_FrontEnd.R_ConductorGrid
    Friend WithEvents R_RadGridView2 As R_FrontEnd.R_RadGridView
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents txtProject As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtVersion As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtApplication As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblProject As R_FrontEnd.R_RadLabel
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents lblVersion As R_FrontEnd.R_RadLabel
    Friend WithEvents btnFilter As R_FrontEnd.R_PopUp
    Friend WithEvents gvActionLog As R_FrontEnd.R_RadGridView

End Class
