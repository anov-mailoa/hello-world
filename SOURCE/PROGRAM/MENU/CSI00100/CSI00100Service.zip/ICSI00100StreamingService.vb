﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports CSI00100Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSI00100StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ICSI00100StreamingService

    <OperationContract(Action:="getProjectStatus", ReplyAction:="getProjectStatus")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetProjectStatus() As Message

    <OperationContract(Action:="getActionLog", ReplyAction:="getActionLog")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetActionLog() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of CSI00100ProjectStatusDTO), ByVal poPar2 As List(Of CSI00100ActionLogDTO))


End Interface
