﻿Public Class CSI00100ActionLogDTO
    Public Property CACTION As String
    Public Property CSEQUENCE As String
    Public Property CACTION_DATE As String
    Public Property CACTION_TIME As String

    Public Property DACTION_DATE As Nullable(Of DateTime)

End Class
