﻿Imports R_Common
Imports R_BackEnd
Imports System.Data.Common
Imports System.Transactions

Public Class CST00210Cls

    Public Sub ScheduleIssue(poKey As CST00210KeyDTO, poIssueList As List(Of CST00210IssueDTO))
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db
        Dim lcQuery As String
        Dim loConn As DbConnection
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcRtn As String = "OK"

        Try
            Using TransScope As New TransactionScope(TransactionScopeOption.Required)
                ' mark selected issues
                For Each issue As CST00210IssueDTO In poIssueList
                    'update issue schedule with characters &&&
                    With issue
                        lcQuery = "UPDATE CST_ISSUES "
                        lcQuery += "SET "
                        lcQuery += "CSCHEDULE_ID = '&&&', "
                        lcQuery += "CUPDATE_BY = '{9}', "
                        lcQuery += "DUPDATE_DATE = GETDATE() "
                        lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                        lcQuery += "AND CAPPS_CODE = '{1}' "
                        lcQuery += "AND CVERSION = '{2}' "
                        lcQuery += "AND CPROJECT_ID = '{3}' "
                        lcQuery += "AND CSESSION_ID = '{4}' "
                        lcQuery += "AND CATTRIBUTE_GROUP = '{5}' "
                        lcQuery += "AND CATTRIBUTE_ID = '{6}' "
                        lcQuery += "AND CITEM_ID = '{7}' "
                        lcQuery += "AND CISSUE_ID = '{8}' "
                        lcQuery = String.Format(lcQuery,
                        .CCOMPANY_ID,
                        .CAPPS_CODE,
                        .CVERSION,
                        .CPROJECT_ID,
                        .CSESSION_ID,
                        .CATTRIBUTE_GROUP,
                        .CATTRIBUTE_ID,
                        .CITEM_ID,
                        .CISSUE_ID,
                        poKey.CUSER_ID)
                    End With
                    loDb.SqlExecNonQuery(lcQuery, loConn, False)
                Next

                ' update schedule
                loCmd = loDb.GetCommand()
                lcQuery = "EXEC RSP_Issue_Schedule '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', @CRET_MSG OUTPUT "
                With poKey
                    lcQuery = String.Format(lcQuery, _
                                            .CCOMPANY_ID, _
                                            .CAPPS_CODE, _
                                            .CVERSION, _
                                            .CPROJECT_ID, _
                                            .CSESSION_ID,
                                            .CDESIGN_USER_ID, _
                                            .CDEVELOPMENT_USER_ID, _
                                            .CQC_USER_ID, _
                                            .CNOTE, _
                                            .CUSER_ID)
                End With
                loCmd.CommandText = lcQuery
                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@CRET_MSG"
                    .DbType = DbType.String
                    .Size = 50
                    .Direction = ParameterDirection.Output
                End With
                loCmd.Parameters.Add(loPar)
                loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)

                If loCmd.Parameters("@CRET_MSG") Is Nothing Then
                    lcRtn = "UNKNOWN_ERROR"
                Else
                    lcRtn = loCmd.Parameters("@CRET_MSG").Value
                End If
                If Not lcRtn.Equals("OK") Then
                    loEx.Add(lcRtn, lcRtn)
                    Exit Try
                End If
                TransScope.Complete()
            End Using

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

End Class
