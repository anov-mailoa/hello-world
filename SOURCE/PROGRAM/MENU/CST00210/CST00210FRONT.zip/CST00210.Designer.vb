﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CST00210
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewCheckBoxSelectColumn3 As R_FrontEnd.R_GridViewCheckBoxSelectColumn = New R_FrontEnd.R_GridViewCheckBoxSelectColumn()
        Dim R_GridViewTextBoxColumn19 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn20 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn21 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn22 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn3 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn23 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn24 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn25 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn26 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn27 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn3 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnRefresh = New R_FrontEnd.R_RadButton(Me.components)
        Me.lblSession = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtSession = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtProject = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtVersion = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtApplication = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.btnFilter = New R_FrontEnd.R_PopUp(Me.components)
        Me.conGridIssue = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.lblProject = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblVersion = New R_FrontEnd.R_RadLabel(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.lblIssueList = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvIssue = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvIssue = New System.Windows.Forms.BindingSource(Me.components)
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.lblNote = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtNote = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtQCPIC = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.btnDevelopment = New R_FrontEnd.R_LookUp(Me.components)
        Me.txtDevelopmentPIC = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtDesignPIC = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblQC = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblDevelopment = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblDesign = New R_FrontEnd.R_RadLabel(Me.components)
        Me.btnQC = New R_FrontEnd.R_LookUp(Me.components)
        Me.btnDesign = New R_FrontEnd.R_LookUp(Me.components)
        Me.lblScheduleIssueParam = New R_FrontEnd.R_RadLabel(Me.components)
        Me.btnSchedule = New R_FrontEnd.R_RadButton(Me.components)
        Me.lblCustom = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblCustomer = New R_FrontEnd.R_RadLabel(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.btnRefresh, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnFilter, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.lblIssueList, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvIssue.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvIssue, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.lblNote, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtNote, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtQCPIC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnDevelopment, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDevelopmentPIC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDesignPIC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblQC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblDevelopment, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblDesign, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnQC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnDesign, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblScheduleIssueParam, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnSchedule, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCustom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel3, 0, 2)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 120.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 120.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lblCustomer)
        Me.Panel1.Controls.Add(Me.lblCustom)
        Me.Panel1.Controls.Add(Me.btnRefresh)
        Me.Panel1.Controls.Add(Me.lblSession)
        Me.Panel1.Controls.Add(Me.txtSession)
        Me.Panel1.Controls.Add(Me.txtProject)
        Me.Panel1.Controls.Add(Me.txtVersion)
        Me.Panel1.Controls.Add(Me.txtApplication)
        Me.Panel1.Controls.Add(Me.btnFilter)
        Me.Panel1.Controls.Add(Me.lblProject)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Controls.Add(Me.lblVersion)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 114)
        Me.Panel1.TabIndex = 1
        '
        'btnRefresh
        '
        Me.btnRefresh.Location = New System.Drawing.Point(646, 9)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.R_ConductorGridSource = Nothing
        Me.btnRefresh.R_ConductorSource = Nothing
        Me.btnRefresh.R_DescriptionId = Nothing
        Me.btnRefresh.R_ResourceId = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(110, 24)
        Me.btnRefresh.TabIndex = 61
        Me.btnRefresh.Text = "R_RadButton1"
        '
        'lblSession
        '
        Me.lblSession.AutoSize = False
        Me.lblSession.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblSession.Location = New System.Drawing.Point(9, 87)
        Me.lblSession.Name = "lblSession"
        Me.lblSession.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblSession.R_ResourceId = "lblSession"
        Me.lblSession.Size = New System.Drawing.Size(100, 18)
        Me.lblSession.TabIndex = 52
        Me.lblSession.Text = "Application..."
        '
        'txtSession
        '
        Me.txtSession.Location = New System.Drawing.Point(115, 86)
        Me.txtSession.Name = "txtSession"
        Me.txtSession.R_ConductorGridSource = Nothing
        Me.txtSession.R_ConductorSource = Nothing
        Me.txtSession.R_UDT = Nothing
        Me.txtSession.ReadOnly = True
        Me.txtSession.Size = New System.Drawing.Size(200, 20)
        Me.txtSession.TabIndex = 51
        Me.txtSession.TabStop = False
        '
        'txtProject
        '
        Me.txtProject.Location = New System.Drawing.Point(115, 60)
        Me.txtProject.Name = "txtProject"
        Me.txtProject.R_ConductorGridSource = Nothing
        Me.txtProject.R_ConductorSource = Nothing
        Me.txtProject.R_UDT = Nothing
        Me.txtProject.ReadOnly = True
        Me.txtProject.Size = New System.Drawing.Size(400, 20)
        Me.txtProject.TabIndex = 50
        Me.txtProject.TabStop = False
        '
        'txtVersion
        '
        Me.txtVersion.Location = New System.Drawing.Point(115, 34)
        Me.txtVersion.Name = "txtVersion"
        Me.txtVersion.R_ConductorGridSource = Nothing
        Me.txtVersion.R_ConductorSource = Nothing
        Me.txtVersion.R_UDT = Nothing
        Me.txtVersion.ReadOnly = True
        Me.txtVersion.Size = New System.Drawing.Size(200, 20)
        Me.txtVersion.TabIndex = 49
        Me.txtVersion.TabStop = False
        '
        'txtApplication
        '
        Me.txtApplication.Location = New System.Drawing.Point(115, 8)
        Me.txtApplication.Name = "txtApplication"
        Me.txtApplication.R_ConductorGridSource = Nothing
        Me.txtApplication.R_ConductorSource = Nothing
        Me.txtApplication.R_UDT = Nothing
        Me.txtApplication.ReadOnly = True
        Me.txtApplication.Size = New System.Drawing.Size(400, 20)
        Me.txtApplication.TabIndex = 48
        Me.txtApplication.TabStop = False
        '
        'btnFilter
        '
        Me.btnFilter.Location = New System.Drawing.Point(530, 9)
        Me.btnFilter.Name = "btnFilter"
        Me.btnFilter.R_ConductorGridSource = Me.conGridIssue
        Me.btnFilter.R_ConductorSource = Nothing
        Me.btnFilter.R_DescriptionId = Nothing
        Me.btnFilter.R_EnableOTHER = True
        Me.btnFilter.R_ResourceId = "btnFilter"
        Me.btnFilter.R_Title = "Issue Filter"
        Me.btnFilter.Size = New System.Drawing.Size(110, 24)
        Me.btnFilter.TabIndex = 37
        Me.btnFilter.Text = "R_PopUp1"
        '
        'conGridIssue
        '
        Me.conGridIssue.R_ConductorParent = Nothing
        Me.conGridIssue.R_IsHeader = True
        Me.conGridIssue.R_RadGroupBox = Nothing
        '
        'lblProject
        '
        Me.lblProject.AutoSize = False
        Me.lblProject.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblProject.Location = New System.Drawing.Point(9, 61)
        Me.lblProject.Name = "lblProject"
        Me.lblProject.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblProject.R_ResourceId = "lblProject"
        Me.lblProject.Size = New System.Drawing.Size(100, 18)
        Me.lblProject.TabIndex = 33
        Me.lblProject.Text = "Application..."
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 30
        Me.lblApplication.Text = "Application..."
        '
        'lblVersion
        '
        Me.lblVersion.AutoSize = False
        Me.lblVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblVersion.Location = New System.Drawing.Point(9, 35)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblVersion.R_ResourceId = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(100, 18)
        Me.lblVersion.TabIndex = 32
        Me.lblVersion.Text = "Application..."
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.lblIssueList)
        Me.Panel2.Controls.Add(Me.gvIssue)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 123)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1271, 329)
        Me.Panel2.TabIndex = 5
        '
        'lblIssueList
        '
        Me.lblIssueList.AutoSize = False
        Me.lblIssueList.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblIssueList.Location = New System.Drawing.Point(9, 6)
        Me.lblIssueList.Name = "lblIssueList"
        Me.lblIssueList.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblIssueList.R_ResourceId = "lblIssueList"
        Me.lblIssueList.Size = New System.Drawing.Size(100, 18)
        Me.lblIssueList.TabIndex = 1
        Me.lblIssueList.Text = "R_RadLabel1"
        '
        'gvIssue
        '
        Me.gvIssue.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gvIssue.EnableFastScrolling = True
        Me.gvIssue.Location = New System.Drawing.Point(0, 30)
        '
        '
        '
        Me.gvIssue.MasterTemplate.AllowAddNewRow = False
        Me.gvIssue.MasterTemplate.AllowDeleteRow = False
        Me.gvIssue.MasterTemplate.AutoGenerateColumns = False
        R_GridViewCheckBoxSelectColumn3.EditMode = Telerik.WinControls.UI.EditMode.OnValueChange
        R_GridViewCheckBoxSelectColumn3.EnableHeaderCheckBox = True
        R_GridViewCheckBoxSelectColumn3.FieldName = "LSELECT"
        R_GridViewCheckBoxSelectColumn3.HeaderText = ""
        R_GridViewCheckBoxSelectColumn3.Name = "_LSELECT"
        R_GridViewCheckBoxSelectColumn3.R_EnableEDIT = True
        R_GridViewCheckBoxSelectColumn3.R_ResourceId = "_LSELECT"
        R_GridViewTextBoxColumn19.FieldName = "CATTRIBUTE_ID"
        R_GridViewTextBoxColumn19.HeaderText = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn19.Name = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn19.R_ResourceId = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn19.R_UDT = Nothing
        R_GridViewTextBoxColumn20.FieldName = "CITEM_ID"
        R_GridViewTextBoxColumn20.HeaderText = "_CITEM_ID"
        R_GridViewTextBoxColumn20.Name = "_CITEM_ID"
        R_GridViewTextBoxColumn20.R_ResourceId = "_CITEM_ID"
        R_GridViewTextBoxColumn20.R_UDT = Nothing
        R_GridViewTextBoxColumn21.FieldName = "CISSUE_ID"
        R_GridViewTextBoxColumn21.HeaderText = "_CISSUE_ID"
        R_GridViewTextBoxColumn21.MaxLength = 15
        R_GridViewTextBoxColumn21.Name = "_CISSUE_ID"
        R_GridViewTextBoxColumn21.R_EnableADD = True
        R_GridViewTextBoxColumn21.R_ResourceId = "_CISSUE_ID"
        R_GridViewTextBoxColumn21.R_UDT = Nothing
        R_GridViewTextBoxColumn21.Width = 78
        R_GridViewTextBoxColumn22.FieldName = "CUSER_ID"
        R_GridViewTextBoxColumn22.HeaderText = "_CUSER_ID"
        R_GridViewTextBoxColumn22.Name = "_CUSER_ID"
        R_GridViewTextBoxColumn22.R_ResourceId = "_CUSER_ID"
        R_GridViewTextBoxColumn22.R_UDT = Nothing
        R_GridViewTextBoxColumn22.Width = 76
        R_GridViewDateTimeColumn3.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn3.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn3.FieldName = "DISSUE_DATE"
        R_GridViewDateTimeColumn3.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn3.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn3.HeaderText = "_DISSUE_DATE"
        R_GridViewDateTimeColumn3.Name = "_DISSUE_DATE"
        R_GridViewDateTimeColumn3.R_ResourceId = "_DISSUE_DATE"
        R_GridViewDateTimeColumn3.Width = 95
        R_GridViewTextBoxColumn23.FieldName = "CISSUE_CLASS_DESCRIPTION"
        R_GridViewTextBoxColumn23.HeaderText = "_CISSUE_CLASS"
        R_GridViewTextBoxColumn23.Name = "_CISSUE_CLASS"
        R_GridViewTextBoxColumn23.R_ResourceId = "_CISSUE_CLASS"
        R_GridViewTextBoxColumn23.R_UDT = Nothing
        R_GridViewTextBoxColumn24.FieldName = "CISSUE_TYPE"
        R_GridViewTextBoxColumn24.HeaderText = "_CISSUE_TYPE"
        R_GridViewTextBoxColumn24.Name = "_CISSUE_TYPE"
        R_GridViewTextBoxColumn24.R_ResourceId = "_CISSUE_TYPE"
        R_GridViewTextBoxColumn24.R_UDT = Nothing
        R_GridViewTextBoxColumn25.FieldName = "CDESCRIPTION"
        R_GridViewTextBoxColumn25.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxColumn25.MaxLength = 8000
        R_GridViewTextBoxColumn25.Multiline = True
        R_GridViewTextBoxColumn25.Name = "_CDESCRIPTION"
        R_GridViewTextBoxColumn25.R_EnableADD = True
        R_GridViewTextBoxColumn25.R_EnableEDIT = True
        R_GridViewTextBoxColumn25.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxColumn25.R_UDT = Nothing
        R_GridViewTextBoxColumn25.ReadOnly = True
        R_GridViewTextBoxColumn25.Width = 103
        R_GridViewTextBoxColumn25.WrapText = True
        R_GridViewTextBoxColumn26.FieldName = "CSCHEDULE_ID"
        R_GridViewTextBoxColumn26.HeaderText = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn26.Name = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn26.R_ResourceId = "_CSCHEDULE_ID"
        R_GridViewTextBoxColumn26.R_UDT = Nothing
        R_GridViewTextBoxColumn26.Width = 103
        R_GridViewTextBoxColumn27.FieldName = "CPREV_SCHEDULE_ID"
        R_GridViewTextBoxColumn27.HeaderText = "_CPREV_SCHEDULE_ID"
        R_GridViewTextBoxColumn27.Name = "_CPREV_SCHEDULE_ID"
        R_GridViewTextBoxColumn27.R_ResourceId = "_CPREV_SCHEDULE_ID"
        R_GridViewTextBoxColumn27.R_UDT = Nothing
        R_GridViewTextBoxColumn27.Width = 134
        R_GridViewCheckBoxColumn3.FieldName = "LOK"
        R_GridViewCheckBoxColumn3.HeaderText = "_LOK"
        R_GridViewCheckBoxColumn3.Name = "_LOK"
        R_GridViewCheckBoxColumn3.R_EnableEDIT = True
        R_GridViewCheckBoxColumn3.R_ResourceId = "_LOK"
        R_GridViewCheckBoxColumn3.Width = 62
        Me.gvIssue.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewCheckBoxSelectColumn3, R_GridViewTextBoxColumn19, R_GridViewTextBoxColumn20, R_GridViewTextBoxColumn21, R_GridViewTextBoxColumn22, R_GridViewDateTimeColumn3, R_GridViewTextBoxColumn23, R_GridViewTextBoxColumn24, R_GridViewTextBoxColumn25, R_GridViewTextBoxColumn26, R_GridViewTextBoxColumn27, R_GridViewCheckBoxColumn3})
        Me.gvIssue.MasterTemplate.DataSource = Me.bsGvIssue
        Me.gvIssue.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvIssue.MasterTemplate.EnableFiltering = True
        Me.gvIssue.MasterTemplate.EnableGrouping = False
        Me.gvIssue.MasterTemplate.ShowFilteringRow = False
        Me.gvIssue.MasterTemplate.ShowGroupedColumns = True
        Me.gvIssue.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvIssue.Name = "gvIssue"
        Me.gvIssue.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvIssue.R_ConductorGridSource = Me.conGridIssue
        Me.gvIssue.R_ConductorSource = Nothing
        Me.gvIssue.R_DataAdded = False
        Me.gvIssue.R_NewRowText = Nothing
        Me.gvIssue.ShowHeaderCellButtons = True
        Me.gvIssue.Size = New System.Drawing.Size(1271, 299)
        Me.gvIssue.TabIndex = 0
        Me.gvIssue.Text = "R_RadGridView1"
        '
        'bsGvIssue
        '
        Me.bsGvIssue.DataSource = GetType(CST00210Front.CST00210StreamingServiceRef.CST00210GridDTO)
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.lblNote)
        Me.Panel3.Controls.Add(Me.txtNote)
        Me.Panel3.Controls.Add(Me.txtQCPIC)
        Me.Panel3.Controls.Add(Me.btnDevelopment)
        Me.Panel3.Controls.Add(Me.txtDevelopmentPIC)
        Me.Panel3.Controls.Add(Me.txtDesignPIC)
        Me.Panel3.Controls.Add(Me.lblQC)
        Me.Panel3.Controls.Add(Me.lblDevelopment)
        Me.Panel3.Controls.Add(Me.lblDesign)
        Me.Panel3.Controls.Add(Me.btnQC)
        Me.Panel3.Controls.Add(Me.btnDesign)
        Me.Panel3.Controls.Add(Me.lblScheduleIssueParam)
        Me.Panel3.Controls.Add(Me.btnSchedule)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(3, 458)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1271, 114)
        Me.Panel3.TabIndex = 6
        '
        'lblNote
        '
        Me.lblNote.AutoSize = False
        Me.lblNote.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblNote.Location = New System.Drawing.Point(470, 26)
        Me.lblNote.Name = "lblNote"
        Me.lblNote.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblNote.R_ResourceId = "lblNote"
        Me.lblNote.Size = New System.Drawing.Size(85, 18)
        Me.lblNote.TabIndex = 65
        Me.lblNote.Text = "R_RadLabel1"
        '
        'txtNote
        '
        Me.txtNote.AcceptsReturn = True
        Me.txtNote.AutoSize = False
        Me.txtNote.Location = New System.Drawing.Point(561, 25)
        Me.txtNote.MaxLength = 200
        Me.txtNote.Multiline = True
        Me.txtNote.Name = "txtNote"
        Me.txtNote.R_ConductorGridSource = Nothing
        Me.txtNote.R_ConductorSource = Nothing
        Me.txtNote.R_UDT = Nothing
        Me.txtNote.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtNote.Size = New System.Drawing.Size(345, 43)
        Me.txtNote.TabIndex = 64
        '
        'txtQCPIC
        '
        Me.txtQCPIC.Location = New System.Drawing.Point(100, 73)
        Me.txtQCPIC.Name = "txtQCPIC"
        Me.txtQCPIC.R_ConductorGridSource = Nothing
        Me.txtQCPIC.R_ConductorSource = Nothing
        Me.txtQCPIC.R_UDT = Nothing
        Me.txtQCPIC.ReadOnly = True
        Me.txtQCPIC.Size = New System.Drawing.Size(328, 20)
        Me.txtQCPIC.TabIndex = 63
        Me.txtQCPIC.TabStop = False
        '
        'btnDevelopment
        '
        Me.btnDevelopment.Location = New System.Drawing.Point(434, 49)
        Me.btnDevelopment.Name = "btnDevelopment"
        Me.btnDevelopment.R_ConductorGridSource = Nothing
        Me.btnDevelopment.R_ConductorSource = Nothing
        Me.btnDevelopment.R_DescriptionId = Nothing
        Me.btnDevelopment.R_Field_Description = ""
        Me.btnDevelopment.R_Field_Value = ""
        Me.btnDevelopment.R_ResourceId = "btnLookup"
        Me.btnDevelopment.R_TextBox_Description = Nothing
        Me.btnDevelopment.R_TextBox_Value = Me.txtDevelopmentPIC
        Me.btnDevelopment.R_Title = Nothing
        Me.btnDevelopment.Size = New System.Drawing.Size(30, 20)
        Me.btnDevelopment.TabIndex = 56
        Me.btnDevelopment.Text = "..."
        '
        'txtDevelopmentPIC
        '
        Me.txtDevelopmentPIC.Location = New System.Drawing.Point(100, 49)
        Me.txtDevelopmentPIC.Name = "txtDevelopmentPIC"
        Me.txtDevelopmentPIC.R_ConductorGridSource = Nothing
        Me.txtDevelopmentPIC.R_ConductorSource = Nothing
        Me.txtDevelopmentPIC.R_UDT = Nothing
        Me.txtDevelopmentPIC.ReadOnly = True
        Me.txtDevelopmentPIC.Size = New System.Drawing.Size(328, 20)
        Me.txtDevelopmentPIC.TabIndex = 62
        Me.txtDevelopmentPIC.TabStop = False
        '
        'txtDesignPIC
        '
        Me.txtDesignPIC.Location = New System.Drawing.Point(100, 25)
        Me.txtDesignPIC.Name = "txtDesignPIC"
        Me.txtDesignPIC.R_ConductorGridSource = Nothing
        Me.txtDesignPIC.R_ConductorSource = Nothing
        Me.txtDesignPIC.R_UDT = Nothing
        Me.txtDesignPIC.ReadOnly = True
        Me.txtDesignPIC.Size = New System.Drawing.Size(328, 20)
        Me.txtDesignPIC.TabIndex = 61
        Me.txtDesignPIC.TabStop = False
        '
        'lblQC
        '
        Me.lblQC.AutoSize = False
        Me.lblQC.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblQC.Location = New System.Drawing.Point(9, 74)
        Me.lblQC.Name = "lblQC"
        Me.lblQC.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblQC.R_ResourceId = "lblQC"
        Me.lblQC.Size = New System.Drawing.Size(85, 18)
        Me.lblQC.TabIndex = 60
        Me.lblQC.Text = "R_RadLabel1"
        '
        'lblDevelopment
        '
        Me.lblDevelopment.AutoSize = False
        Me.lblDevelopment.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblDevelopment.Location = New System.Drawing.Point(9, 50)
        Me.lblDevelopment.Name = "lblDevelopment"
        Me.lblDevelopment.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblDevelopment.R_ResourceId = "lblDevelopment"
        Me.lblDevelopment.Size = New System.Drawing.Size(85, 18)
        Me.lblDevelopment.TabIndex = 59
        Me.lblDevelopment.Text = "R_RadLabel1"
        '
        'lblDesign
        '
        Me.lblDesign.AutoSize = False
        Me.lblDesign.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblDesign.Location = New System.Drawing.Point(9, 26)
        Me.lblDesign.Name = "lblDesign"
        Me.lblDesign.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblDesign.R_ResourceId = "lblDesign"
        Me.lblDesign.Size = New System.Drawing.Size(85, 18)
        Me.lblDesign.TabIndex = 58
        Me.lblDesign.Text = "R_RadLabel1"
        '
        'btnQC
        '
        Me.btnQC.Location = New System.Drawing.Point(434, 73)
        Me.btnQC.Name = "btnQC"
        Me.btnQC.R_ConductorGridSource = Nothing
        Me.btnQC.R_ConductorSource = Nothing
        Me.btnQC.R_DescriptionId = Nothing
        Me.btnQC.R_Field_Description = ""
        Me.btnQC.R_Field_Value = ""
        Me.btnQC.R_ResourceId = "btnLookup"
        Me.btnQC.R_TextBox_Description = Nothing
        Me.btnQC.R_TextBox_Value = Me.txtQCPIC
        Me.btnQC.R_Title = Nothing
        Me.btnQC.Size = New System.Drawing.Size(30, 20)
        Me.btnQC.TabIndex = 57
        Me.btnQC.Text = "..."
        '
        'btnDesign
        '
        Me.btnDesign.Location = New System.Drawing.Point(434, 25)
        Me.btnDesign.Name = "btnDesign"
        Me.btnDesign.R_ConductorGridSource = Nothing
        Me.btnDesign.R_ConductorSource = Nothing
        Me.btnDesign.R_DescriptionId = Nothing
        Me.btnDesign.R_Field_Description = ""
        Me.btnDesign.R_Field_Value = ""
        Me.btnDesign.R_ResourceId = "btnLookup"
        Me.btnDesign.R_TextBox_Description = Nothing
        Me.btnDesign.R_TextBox_Value = Me.txtDesignPIC
        Me.btnDesign.R_Title = Nothing
        Me.btnDesign.Size = New System.Drawing.Size(30, 20)
        Me.btnDesign.TabIndex = 55
        Me.btnDesign.Text = "..."
        '
        'lblScheduleIssueParam
        '
        Me.lblScheduleIssueParam.AutoSize = False
        Me.lblScheduleIssueParam.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblScheduleIssueParam.Location = New System.Drawing.Point(9, 3)
        Me.lblScheduleIssueParam.Name = "lblScheduleIssueParam"
        Me.lblScheduleIssueParam.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblScheduleIssueParam.R_ResourceId = "lblScheduleIssueParam"
        Me.lblScheduleIssueParam.Size = New System.Drawing.Size(207, 18)
        Me.lblScheduleIssueParam.TabIndex = 54
        Me.lblScheduleIssueParam.Text = "R_RadLabel1"
        '
        'btnSchedule
        '
        Me.btnSchedule.Location = New System.Drawing.Point(561, 71)
        Me.btnSchedule.Name = "btnSchedule"
        Me.btnSchedule.R_ConductorGridSource = Me.conGridIssue
        Me.btnSchedule.R_ConductorSource = Nothing
        Me.btnSchedule.R_DescriptionId = Nothing
        Me.btnSchedule.R_EnableOTHER = True
        Me.btnSchedule.R_ResourceId = "btnSchedule"
        Me.btnSchedule.Size = New System.Drawing.Size(110, 24)
        Me.btnSchedule.TabIndex = 53
        Me.btnSchedule.Text = "R_RadButton1"
        '
        'lblCustom
        '
        Me.lblCustom.AutoSize = False
        Me.lblCustom.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustom.Location = New System.Drawing.Point(521, 61)
        Me.lblCustom.Name = "lblCustom"
        Me.lblCustom.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustom.R_ResourceId = ""
        Me.lblCustom.Size = New System.Drawing.Size(100, 18)
        Me.lblCustom.TabIndex = 64
        Me.lblCustom.Text = "Application..."
        '
        'lblCustomer
        '
        Me.lblCustomer.AutoSize = False
        Me.lblCustomer.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustomer.Location = New System.Drawing.Point(9, 35)
        Me.lblCustomer.Name = "lblCustomer"
        Me.lblCustomer.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustomer.R_ResourceId = "lblCustomer"
        Me.lblCustomer.Size = New System.Drawing.Size(100, 18)
        Me.lblCustomer.TabIndex = 65
        Me.lblCustomer.Text = "Application..."
        '
        'CST00210
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CST00210"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.btnRefresh, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnFilter, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridIssue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        CType(Me.lblIssueList, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvIssue.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvIssue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvIssue, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.lblNote, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtNote, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtQCPIC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnDevelopment, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDevelopmentPIC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDesignPIC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblQC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblDevelopment, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblDesign, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnQC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnDesign, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblScheduleIssueParam, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnSchedule, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCustom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblProject As R_FrontEnd.R_RadLabel
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents lblVersion As R_FrontEnd.R_RadLabel
    Friend WithEvents gvInbox As R_FrontEnd.R_RadGridView
    Friend WithEvents conGridIssue As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsGvIssue As System.Windows.Forms.BindingSource
    Friend WithEvents btnFilter As R_FrontEnd.R_PopUp
    Friend WithEvents txtSession As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtProject As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtVersion As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtApplication As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblSession As R_FrontEnd.R_RadLabel
    Friend WithEvents btnSchedule As R_FrontEnd.R_RadButton
    Friend WithEvents btnRefresh As R_FrontEnd.R_RadButton
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents lblIssueList As R_FrontEnd.R_RadLabel
    Friend WithEvents gvIssue As R_FrontEnd.R_RadGridView
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents lblScheduleIssueParam As R_FrontEnd.R_RadLabel
    Friend WithEvents btnDesign As R_FrontEnd.R_LookUp
    Friend WithEvents btnDevelopment As R_FrontEnd.R_LookUp
    Friend WithEvents btnQC As R_FrontEnd.R_LookUp
    Friend WithEvents lblDesign As R_FrontEnd.R_RadLabel
    Friend WithEvents lblDevelopment As R_FrontEnd.R_RadLabel
    Friend WithEvents lblQC As R_FrontEnd.R_RadLabel
    Friend WithEvents txtDesignPIC As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtDevelopmentPIC As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtQCPIC As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblNote As R_FrontEnd.R_RadLabel
    Friend WithEvents txtNote As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblCustom As R_FrontEnd.R_RadLabel
    Friend WithEvents lblCustomer As R_FrontEnd.R_RadLabel

End Class
