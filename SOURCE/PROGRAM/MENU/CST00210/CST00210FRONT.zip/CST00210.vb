﻿Imports CST00210FrontResources
Imports R_Common
Imports CST00210Front.CST00210ServiceRef
Imports CST00210Front.CST00210StreamingServiceRef
Imports ClientHelper
Imports R_FrontEnd
Imports System.ServiceModel.Channels
Imports RCustDBFrontHelper
Imports CSM00500Front

Public Class CST00210

#Region " VARIABLE "
    Dim C_ServiceName As String = "CST00210Service/CST00210Service.svc"
    Dim C_ServiceNameStream As String = "CST00210Service/CST00210StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _CVERSION As String
    Dim _CPROJECTID As String
    Dim _CSESSIONID As String
    Dim _CSCHEDULEID As String
    Dim _CUSER_NAME As String
    Dim _CFUNCTIONID As String
    Dim _LINIT As Boolean
    Dim _CATTRIBUTEGROUP As String
    Dim _CATTRIBUTEID As String
    Dim _CITEMID As String
    Dim _CACTION As String
    Dim _CISSUE_ID As String
    Dim loFilterParam As New CST00210FilterParameterDTO

    Dim _CDESIGN_PIC As String
    Dim _CDEVELOPMENT_PIC As String
    Dim _CQC_PIC As String

#End Region

#Region " SUBs and FUNCTIONs "

    Private Sub RefreshGrids(poKey As CST00210KeyDTO)
        If _LINIT Then
            With gvIssue
                .R_RefreshGrid(poKey)
            End With
        End If
    End Sub

#End Region

#Region " FILTER "

    Private Sub btnFilter_R_After_Open_Form(poPopUpResult As System.Windows.Forms.DialogResult, poPopUpEntityResult As Object) Handles btnFilter.R_After_Open_Form
        Dim loGridKey As New CST00210KeyDTO

        If poPopUpResult = Windows.Forms.DialogResult.OK Then
            loFilterParam = poPopUpEntityResult
            With loFilterParam
                _CAPPSCODE = .OFILTER_KEY.CAPPS_CODE
                _CVERSION = .OFILTER_KEY.CVERSION
                _CPROJECTID = .OFILTER_KEY.CPROJECT_ID
                _CSESSIONID = .OFILTER_KEY.CSESSION_ID
                _CFUNCTIONID = "QC"
                txtApplication.Text = .CAPPS_NAME
                txtVersion.Text = IIf(.LCUSTOM, .CCUSTOMER_NAME, .CCODE_NAME)
                txtProject.Text = .CPROJECT_NAME
                txtSession.Text = .OFILTER_KEY.CSESSION_ID
                lblVersion.Visible = Not .LCUSTOM
                lblCustomer.Visible = .LCUSTOM
                lblCustom.Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), IIf(.LCUSTOM, "rdbCustom", "rdbStandard"))
            End With
            If Not (String.IsNullOrEmpty(_CAPPSCODE) Or String.IsNullOrEmpty(_CVERSION) Or String.IsNullOrEmpty(_CPROJECTID)) Then
                With loGridKey
                    .CCOMPANY_ID = _CCOMPID
                    .CAPPS_CODE = _CAPPSCODE
                    .CVERSION = _CVERSION
                    .CPROJECT_ID = _CPROJECTID
                    .CSESSION_ID = _CSESSIONID
                End With
                RefreshGrids(loGridKey)
            End If
        End If
    End Sub

    Private Sub btnFilter_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnFilter.R_Before_Open_Form
        poTargetForm = New CST00210Filter
        poParameter = loFilterParam
    End Sub

#End Region

#Region " FORM Events "

    Private Sub CST00200_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loComboKey As New RCustDBProjectKeyDTO

        Try
            _LINIT = False
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            _CATTRIBUTEGROUP = "PROGRAM"
            _CFUNCTIONID = "QC"
            _LINIT = True
            With loComboKey
                .CCOMPANY_ID = _CCOMPID
                .CUSER_ID = _CUSERID
            End With
            loFilterParam.OFILTER_KEY.CCOMPANY_ID = _CCOMPID
            btnFilter.PerformClick()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub CST00200_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " ISSUE Gridview "

    Private Sub gvIssue_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvIssue.DataBindingComplete
        gvIssue.BestFitColumns()
    End Sub

    Private Sub gvIssue_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvIssue.R_ServiceGetListRecord
        Dim loServiceStream As CST00210StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00210StreamingService, CST00210StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CST00210GridDTO)
        Dim loListEntity As New List(Of CST00210GridDTO)

        Try
            R_Utility.R_SetStreamingContext("cCompanyId", _CCOMPID)
            R_Utility.R_SetStreamingContext("cAppsCode", _CAPPSCODE)
            R_Utility.R_SetStreamingContext("cVersion", _CVERSION)
            R_Utility.R_SetStreamingContext("cProjectId", _CPROJECTID)
            R_Utility.R_SetStreamingContext("cSessionId", _CSESSIONID)
            R_Utility.R_SetStreamingContext("cAttributeGroup", _CATTRIBUTEGROUP)
            R_Utility.R_SetStreamingContext("cAttributeId", "*")
            R_Utility.R_SetStreamingContext("cItemId", "*")
            R_Utility.R_SetStreamingContext("cScheduleId", "*")
            R_Utility.R_SetStreamingContext("cPrevScheduleId", "*")

            loRtn = loServiceStream.GetIssueList()
            loStreaming = R_StreamUtility(Of CST00210GridDTO).ReadFromMessage(loRtn)

            For Each loDto As CST00210GridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loDto.DISSUE_DATE = General.StrToDate(loDto.CISSUE_DATE)
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " SCHEDULE button "
    Private Sub btnSchedule_Click(sender As Object, e As System.EventArgs) Handles btnSchedule.Click
        Dim loException As New R_Exception
        Dim loService As CST00210ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00210Service, CST00210ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loIssues As New List(Of CST00210IssueDTO)

        Me.Cursor = Windows.Forms.Cursors.WaitCursor
        btnSchedule.Enabled = False
        Try
            Dim loIssueList = From item In CType(bsGvIssue.List, List(Of CST00210GridDTO)) _
                             Where item.LSELECT = True And item.CSCHEDULE_ID.Trim = ""

            If loIssueList.ToList.Count = 0 Then
                loException.Add("CST00210_01", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CST00210_01"))
                Exit Try
            End If

            With loFilterParam.OFILTER_KEY
                .CDESIGN_USER_ID = _CDESIGN_PIC
                .CDEVELOPMENT_USER_ID = _CDEVELOPMENT_PIC
                .CQC_USER_ID = _CQC_PIC
                .CNOTE = txtNote.Text
                .CUSER_ID = _CUSERID
            End With

            loIssues = R_Utility.R_ConvertCollectionToCollection(Of CST00210GridDTO, CST00210IssueDTO)(loIssueList.ToList())
            'loIssues.AddRange(loIssueList.ToList())
            loService.ScheduleIssue(loFilterParam.OFILTER_KEY, loIssues)

            gvIssue.R_RefreshGrid(loFilterParam.OFILTER_KEY)
            txtNote.Text = ""
        Catch ex As Exception
            loException.Add(ex)
        Finally
            btnSchedule.Enabled = True
            Me.Cursor = Windows.Forms.Cursors.Default
        End Try

        If loException.Haserror Then
            Me.R_DisplayException(loException)
        End If
    End Sub
#End Region

#Region " REFRESH button "

    Private Sub btnRefresh_Click(sender As Object, e As System.EventArgs) Handles btnRefresh.Click
        Dim loGridKey As New CST00210KeyDTO

        If Not (String.IsNullOrEmpty(_CAPPSCODE) Or String.IsNullOrEmpty(_CVERSION) Or String.IsNullOrEmpty(_CPROJECTID)) Then
            With loGridKey
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = _CAPPSCODE
                .CVERSION = _CVERSION
                .CPROJECT_ID = _CPROJECTID
                .CSESSION_ID = _CSESSIONID
            End With
            RefreshGrids(loGridKey)
        End If
    End Sub

#End Region

#Region " SCHEDULE Parameter "

    Private Sub btnDesign_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnDesign.R_Before_Open_Form
        poTargetForm = New CSM00500UserList
        poParameter = New CSM00500UserListParameterDTO With {.CCOMPANY_ID = _CCOMPID, _
                                                             .CAPPS_CODE = _CAPPSCODE, _
                                                             .CVERSION = _CVERSION, _
                                                             .CPROJECT_ID = _CPROJECTID, _
                                                             .CSESSION_ID = _CSESSIONID, _
                                                             .CFUNCTION_ID = "DESIGN"}

    End Sub

    Private Sub btnDesign_R_Return_LookUp(poReturnObject As Object) Handles btnDesign.R_Return_LookUp
        With poReturnObject
            _CDESIGN_PIC = .CUSER_ID
            txtDesignPIC.Text = .CUSER_NAME.Trim & " (" & .CUSER_ID.Trim & ")"
        End With
    End Sub

    Private Sub btnDevelopment_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnDevelopment.R_Before_Open_Form
        poTargetForm = New CSM00500UserList
        poParameter = New CSM00500UserListParameterDTO With {.CCOMPANY_ID = _CCOMPID, _
                                                             .CAPPS_CODE = _CAPPSCODE, _
                                                             .CVERSION = _CVERSION, _
                                                             .CPROJECT_ID = _CPROJECTID, _
                                                             .CSESSION_ID = _CSESSIONID, _
                                                             .CFUNCTION_ID = "DEVELOPMENT"}
    End Sub

    Private Sub btnDevelopment_R_Return_LookUp(poReturnObject As Object) Handles btnDevelopment.R_Return_LookUp
        With poReturnObject
            _CDEVELOPMENT_PIC = .CUSER_ID
            txtDevelopmentPIC.Text = .CUSER_NAME.Trim & " (" & .CUSER_ID.Trim & ")"
        End With
    End Sub

    Private Sub btnQC_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnQC.R_Before_Open_Form
        poTargetForm = New CSM00500UserList
        poParameter = New CSM00500UserListParameterDTO With {.CCOMPANY_ID = _CCOMPID, _
                                                             .CAPPS_CODE = _CAPPSCODE, _
                                                             .CVERSION = _CVERSION, _
                                                             .CPROJECT_ID = _CPROJECTID, _
                                                             .CSESSION_ID = _CSESSIONID, _
                                                             .CFUNCTION_ID = "QC"}
    End Sub

    Private Sub btnQC_R_Return_LookUp(poReturnObject As Object) Handles btnQC.R_Return_LookUp
        With poReturnObject
            _CQC_PIC = .CUSER_ID
            txtQCPIC.Text = .CUSER_NAME.Trim & " (" & .CUSER_ID.Trim & ")"
        End With
    End Sub

#End Region

End Class
