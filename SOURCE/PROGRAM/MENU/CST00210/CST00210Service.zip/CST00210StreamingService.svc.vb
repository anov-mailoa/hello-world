﻿Imports R_Common
Imports RLicenseBack
Imports System.ServiceModel.Channels
Imports CST00210Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "CST00210StreamingService" in code, svc and config file together.
Public Class CST00210StreamingService
    Implements ICST00210StreamingService

    Public Function GetIssueList() As System.ServiceModel.Channels.Message Implements ICST00210StreamingService.GetIssueList
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtnTemp As List(Of RCustDBIssueListDTO)
        Dim loRtn As Message
        Dim loTableKey As New RCustDBIssueKeyDTO
        Dim loRtnTemp2 As List(Of CST00210GridDTO)

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .CPROJECT_ID = R_Utility.R_GetStreamingContext("cProjectId")
                .CSESSION_ID = R_Utility.R_GetStreamingContext("cSessionId")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CATTRIBUTE_ID = R_Utility.R_GetStreamingContext("cAttributeId")
                .CITEM_ID = R_Utility.R_GetStreamingContext("cItemId")
                .CSCHEDULE_ID = R_Utility.R_GetStreamingContext("cScheduleId")
                .CPREV_SCHEDULE_ID = R_Utility.R_GetStreamingContext("cPrevScheduleId")
                .LOUTSTANDING_ONLY = False
            End With

            loRtnTemp = loCls.GetIssueList(loTableKey)
            loRtnTemp2 = R_Utility.R_ConvertCollectionToCollection(Of RCustDBIssueListDTO, CST00210GridDTO)(loRtnTemp)
            loRtn = R_StreamUtility(Of CST00210GridDTO).WriteToMessage(loRtnTemp2.AsEnumerable, "getIssueList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub Dummy(poPar1 As CST00210Back.CST00210GridDTO) Implements ICST00210StreamingService.Dummy

    End Sub
End Class
