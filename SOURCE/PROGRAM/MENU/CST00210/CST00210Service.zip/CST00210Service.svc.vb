﻿Imports R_Common
Imports RLicenseBack
Imports CST00200Back
Imports CST00210Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "CST00210Service" in code, svc and config file together.
Public Class CST00210Service
    Implements ICST00210Service

    Public Function GetAppCombo(companyId As String, userId As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseAppComboDTO) Implements ICST00210Service.GetAppCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseAppComboDTO)

        Try
            loRtn = loCls.GetAppCombo(companyId, userId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetProjectCombo(pokey As RLicenseBack.RCustDBProjectKeyDTO) As System.Collections.Generic.List(Of RLicenseBack.RCustDBProjectComboDTO) Implements ICST00210Service.GetProjectCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBProjectComboDTO)

        Try
            loRtn = loCls.GetProjectCombo(pokey)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetSessionCombo(pokey As RLicenseBack.RCustDBProjectKeyDTO) As System.Collections.Generic.List(Of RLicenseBack.RCustDBSessionComboDTO) Implements ICST00210Service.GetSessionCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBSessionComboDTO)

        Try
            loRtn = loCls.GetSessionCombo(pokey)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetVersionCombo(companyId As String, appsCode As String) As System.Collections.Generic.List(Of RLicenseBack.RCustDBVersionComboDTO) Implements ICST00210Service.GetVersionCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBVersionComboDTO)

        Try
            loRtn = loCls.GetVersionCombo(companyId, appsCode)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetIssueTypeCombo() As System.Collections.Generic.List(Of CST00200Back.CST00200IssueTypeComboDTO) Implements ICST00210Service.GetIssueTypeCombo
        Dim loException As New R_Exception
        Dim loCls As New CST00200Cls
        Dim loRtn As List(Of CST00200IssueTypeComboDTO)

        Try
            loRtn = loCls.GetIssueTypeCombo()
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub ScheduleIssue(poKey As CST00210Back.CST00210KeyDTO, poIssueList As System.Collections.Generic.List(Of CST00210Back.CST00210IssueDTO)) Implements ICST00210Service.ScheduleIssue
        Dim loException As New R_Exception
        Dim loCls As New CST00210Cls

        Try
            loCls.ScheduleIssue(poKey, poIssueList)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub
End Class
