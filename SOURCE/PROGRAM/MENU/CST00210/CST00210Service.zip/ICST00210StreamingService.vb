﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports CST00210Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICST00210StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ICST00210StreamingService

    <OperationContract(Action:="getIssueList", ReplyAction:="getIssueList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetIssueList() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As CST00210GridDTO)

End Interface
