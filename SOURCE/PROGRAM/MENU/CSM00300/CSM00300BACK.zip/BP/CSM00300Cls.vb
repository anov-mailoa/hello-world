﻿Imports R_BackEnd
Imports R_Common
Imports System.Data.Common
Imports ServerHelper.General

Public Class CSM00300Cls
    Inherits R_BusinessObject(Of CSM00300DTO)

    Public Function GetProgramList(poKey As CSM00300KeyDTO) As List(Of CSM00300GridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00300GridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CSM_PROGRAMS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP)
            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00300GridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Deleting(poEntity As CSM00300DTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcRtn As String

        Try
            loConn = loDb.GetConnection()

            With poEntity

                'validation
                loCmd = loDb.GetCommand()
                lcQuery = "EXEC RSP_Delete_Design_Validation '{0}', '{1}', '{2}', '{3}', '{4}', @CRET_MSG OUTPUT "
                With poEntity
                    lcQuery = String.Format(lcQuery, _
                                            .CCOMPANY_ID, _
                                            .CAPPS_CODE, _
                                            .CATTRIBUTE_GROUP, _
                                            .CATTRIBUTE_ID,
                                            .CPROGRAM_ID)
                End With
                loCmd.CommandText = lcQuery
                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@CRET_MSG"
                    .DbType = DbType.String
                    .Size = 50
                    .Direction = ParameterDirection.Output
                End With
                loCmd.Parameters.Add(loPar)
                loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)

                If loCmd.Parameters("@CRET_MSG") Is Nothing Then
                    lcRtn = "UNKNOWN_ERROR"
                Else
                    lcRtn = loCmd.Parameters("@CRET_MSG").Value
                End If

                If Not lcRtn.Equals("OK") Then
                    Throw New Exception(lcRtn)
                End If

                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "CSM_PROGRAMS "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                lcQuery += "AND CPROGRAM_ID = '{4}' "

                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CPROGRAM_ID)

                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As CSM00300DTO) As CSM00300DTO
        Dim lcQuery As String
        Dim loResult As CSM00300DTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CSM_PROGRAMS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                lcQuery += "AND CPROGRAM_ID = '{4}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CPROGRAM_ID)

                loResult = loDb.SqlExecObjectQuery(Of CSM00300DTO)(lcQuery).FirstOrDefault

            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As CSM00300DTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim lcProgramID As String

        Try
            loConn = loDb.GetConnection()

            With poNewEntity
                If poCRUDMode = eCRUDMode.AddMode Then

                    .CUPDATE_BY = .CUPDATE_BY
                    .CCREATE_BY = .CUPDATE_BY

                    ' cari duplicate
                    lcQuery = "SELECT CPROGRAM_ID "
                    lcQuery += "FROM CSM_PROGRAMS (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                    lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                    lcQuery += "AND CPROGRAM_ID = '{4}' "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CPROGRAM_ID)

                    lcProgramID = loDb.SqlExecObjectQuery(Of String)(lcQuery, loConn, False).FirstOrDefault
                    If lcProgramID IsNot Nothing Then
                        Throw New Exception("DUPLICATE_PROGRAM")
                    End If

                    ' cari current open version
                    lcQuery = "SELECT CVERSION = dbo.RFN_Get_Current_Version('{0}', '{1}') "

                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE)

                    .CINITIAL_VERSION = loDb.SqlExecObjectQuery(Of String)(lcQuery, loConn, False).FirstOrDefault
                    'If .CINITIAL_VERSION Is Nothing Then
                    '    ' cari current released version
                    '    lcQuery = "SELECT TOP 1 CVERSION "
                    '    lcQuery += "FROM RVT_APP_VERSION (NOLOCK) "
                    '    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    '    lcQuery += "AND CAPPS_CODE = '{1}' "
                    '    lcQuery += "AND CSTATUS = 'RELEASED' "
                    '    lcQuery += "ORDER BY CVERSION DESC "
                    '    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE)

                    '    .CINITIAL_VERSION = loDb.SqlExecObjectQuery(Of String)(lcQuery).FirstOrDefault
                    If .CINITIAL_VERSION Is Nothing Then
                        Throw New Exception("NO_OPEN_VERSION")
                    End If
                    'End If
                    If .CINITIAL_VERSION.Trim.Equals("") Then
                        Throw New Exception("NO_OPEN_VERSION")
                    End If

                    lcQuery = "INSERT INTO CSM_PROGRAMS ("
                    lcQuery += "CCOMPANY_ID, "
                    lcQuery += "CAPPS_CODE, "
                    lcQuery += "CATTRIBUTE_GROUP, "
                    lcQuery += "CATTRIBUTE_ID, "
                    lcQuery += "CPROGRAM_ID, "
                    lcQuery += "CPROGRAM_NAME, "
                    lcQuery += "CDESCRIPTION, "
                    lcQuery += "LSPEC, "
                    lcQuery += "CINITIAL_VERSION, "
                    lcQuery += "CUPDATE_BY, "
                    lcQuery += "DUPDATE_DATE, "
                    lcQuery += "CCREATE_BY, "
                    lcQuery += "DCREATE_DATE) "
                    lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', {7}, '{8}', '{9}', GETDATE(), '{10}', GETDATE()) "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CATTRIBUTE_GROUP,
                    .CATTRIBUTE_ID,
                    .CPROGRAM_ID,
                    .CPROGRAM_NAME,
                    .CDESCRIPTION,
                    getBit(.LSPEC),
                    .CINITIAL_VERSION,
                    .CUPDATE_BY,
                    .CCREATE_BY)

                ElseIf poCRUDMode = eCRUDMode.EditMode Then

                    lcQuery = "UPDATE CSM_PROGRAMS "
                    lcQuery += "SET "
                    lcQuery += "CPROGRAM_NAME = '{5}', "
                    lcQuery += "CDESCRIPTION = '{6}', "
                    lcQuery += "LSPEC = {7}, "
                    lcQuery += "CUPDATE_BY = '{8}', "
                    lcQuery += "DUPDATE_DATE = GETDATE() "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                    lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                    lcQuery += "AND CPROGRAM_ID = '{4}' "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CATTRIBUTE_GROUP,
                    .CATTRIBUTE_ID,
                    .CPROGRAM_ID,
                    .CPROGRAM_NAME,
                    .CDESCRIPTION,
                    getBit(.LSPEC),
                    .CUPDATE_BY)

                End If
            End With
            loDb.SqlExecNonQuery(lcQuery, loConn, True)
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

End Class
