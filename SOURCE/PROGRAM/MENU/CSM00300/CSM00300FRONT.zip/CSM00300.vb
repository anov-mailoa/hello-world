﻿Imports CSM00300Front.CSM00300ServiceRef
Imports R_FrontEnd
Imports CSM00300FrontResources
Imports R_Common
Imports ClientHelper
Imports CSM00300Front.CSM00300StreamingServiceRef
Imports System.ServiceModel.Channels
Imports RCustDBFrontHelper
Imports System.Drawing
Imports System.IO
Imports RCustDBFrontHelper.FileServiceRef
Imports System.ServiceModel

Public Class CSM00300

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSM00300Service/CSM00300Service.svc"
    Dim C_ServiceNameStream As String = "CSM00300Service/CSM00300StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CFILE As String
    Dim _CFILE_NAME As String
    Dim loGridKey As New CSM00300KeyDTO
#End Region

#Region " SUB and FUNCTION "

    Private Sub RefreshGrids()
        Dim loTableKey As New CSM00300KeyDTO

        With loTableKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = cboApplication.SelectedValue.Trim
            .CATTRIBUTE_GROUP = "PROGRAM"
        End With

        With gvProgram
            .R_RefreshGrid(loTableKey)
            .Columns(0).Sort(Telerik.WinControls.UI.RadSortOrder.Ascending, False)
        End With
    End Sub

    Private Sub RefreshAttributeCombo()
        Dim loService As CSM00300ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00300Service, CSM00300ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)

        bsAttribute.DataSource = loService.GetAttributeCombo(_CCOMPID, cboApplication.SelectedValue.Trim, "PROGRAM")
        loService.Close()
    End Sub

    Private Function GetIconByte(poKey As CSM00300KeyDTO) As Byte()
        Dim loException As New R_Exception
        Dim loFileHandler As New FileHandler
        Dim loKey As New RCustDBFileKeyDTO
        Dim loReturn As Byte()

        Try
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor

            With loKey
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = poKey.CAPPS_CODE
                .CATTRIBUTE_GROUP = poKey.CATTRIBUTE_GROUP
                .CATTRIBUTE_ID = poKey.CATTRIBUTE_ID
                .CITEM_ID = poKey.CPROGRAM_ID
                .CACTION = "VIEWICON"
                .CUSER_ID = _CUSERID
                .CFILE_GROUP = "PROGRAM_ICON"
            End With
            With loFileHandler
                .CCOMPANY_ID = _CCOMPID
                .CUSER_ID = _CUSERID
                loReturn = .DownloadByte(loKey)
            End With
        Catch ex As Exception
            loException.Add(ex)
        Finally
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        End Try
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        If loException.Haserror Then
            Me.R_DisplayException(loException)
        End If
        Return loReturn
    End Function

#End Region

#Region " Form Methods "

    Private Sub CSM00300_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Dim loSvc As CSM00300ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00300Service, CSM00300ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loAppCombo As New List(Of RLicenseAppComboDTO)

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            ' Application
            loAppCombo = loSvc.GetAppCombo(_CCOMPID, _CUSERID)
            If loAppCombo.Count <= 0 Then
                cboApplication.Items.Clear()
                gvProgram.Enabled = False
            End If
            bsApps.DataSource = loAppCombo

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub CSM00300_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " COMBO Actions "

    Private Sub cboApplication_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboApplication.SelectedValueChanged
        Dim loEx As New R_Exception
        Dim loSvc As CSM00300ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00300Service, CSM00300ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loVersionCombo As New List(Of RCustDBVersionComboDTO)
        Dim loAttributeCombo As New List(Of RCustDBAttributeComboDTO)

        Try
            ' Attribute Field
            loAttributeCombo = loSvc.GetAttributeCombo(_CCOMPID, CType(sender, R_RadDropDownList).SelectedValue, "PROGRAM")
            bsAttribute.DataSource = loAttributeCombo
            loSvc.Close()
            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " GRIDVIEW Events "

    Private Sub gvProgram_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvProgram.R_Display
        Dim loIconByte As Byte()

        With loGridKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = poEntity._CAPPS_CODE
            .CATTRIBUTE_GROUP = "PROGRAM"
            .CATTRIBUTE_ID = poEntity._CATTRIBUTE_ID
            .CPROGRAM_ID = poEntity._CPROGRAM_ID
        End With
        With pbIcon
            ' Download icon byte
            loIconByte = GetIconByte(loGridKey)
            If loIconByte IsNot Nothing Then
                Using mStream As New MemoryStream(loIconByte)
                    .Image = Image.FromStream(mStream)
                End Using
            Else
                .Image = Nothing
            End If
        End With
    End Sub

    Private Sub gvProgram_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvProgram.R_Saving
        With CType(poEntity, CSM00300DTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = cboApplication.SelectedValue.Trim
            ._CATTRIBUTE_GROUP = "PROGRAM"
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With
    End Sub

    Private Sub gvProgram_R_ServiceDelete(poEntity As Object) Handles gvProgram.R_ServiceDelete
        Dim loService As CSM00300ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00300Service, CSM00300ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String

        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As FaultException
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loService IsNot Nothing Then
            loService.Close()
        End If

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvProgram_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvProgram.R_ServiceGetListRecord
        Dim loServiceStream As CSM00300StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00300StreamingService, CSM00300StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00300GridDTO)
        Dim loListEntity As New List(Of CSM00300DTO)

        Try
            With CType(poEntity, CSM00300KeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cAttributeGroup", .CATTRIBUTE_GROUP)
                R_Utility.R_SetStreamingContext("cAttributeId", .CATTRIBUTE_ID)
            End With

            loRtn = loServiceStream.GetProgramList()
            loStreaming = R_StreamUtility(Of CSM00300GridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00300GridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New CSM00300DTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                           ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                           ._CATTRIBUTE_GROUP = loDto.CATTRIBUTE_GROUP,
                                                           ._CATTRIBUTE_ID = loDto.CATTRIBUTE_ID,
                                                           ._CPROGRAM_ID = loDto.CPROGRAM_ID,
                                                           ._CPROGRAM_NAME = loDto.CPROGRAM_NAME,
                                                           ._CDESCRIPTION = loDto.CDESCRIPTION,
                                                           ._LSPEC = loDto.LSPEC,
                                                           ._CINITIAL_VERSION = loDto.CINITIAL_VERSION,
                                                           ._CCREATE_BY = loDto.CCREATE_BY,
                                                           ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                           ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                           ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        If loServiceStream IsNot Nothing Then
            loServiceStream.Close()
        End If

        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvProgram_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvProgram.R_ServiceGetRecord
        Dim loService As CSM00300ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00300Service, CSM00300ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New CSM00300DTO With {._CCOMPANY_ID = _CCOMPID,
                                                                             ._CAPPS_CODE = cboApplication.SelectedValue.Trim,
                                                                             ._CATTRIBUTE_GROUP = "PROGRAM",
                                                                             ._CATTRIBUTE_ID = CType(bsGvProgram.Current, CSM00300DTO)._CATTRIBUTE_ID,
                                                                             ._CPROGRAM_ID = CType(bsGvProgram.Current, CSM00300DTO)._CPROGRAM_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loService IsNot Nothing Then
            loService.Close()
        End If

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvProgram_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvProgram.R_ServiceSave
        Dim loService As CSM00300ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00300Service, CSM00300ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String
        Dim oRes As New Resources_Dummy_Class

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As FaultException
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(R_Utility.R_GetError(GetType(CSM00300FrontResources.Resources_Dummy_Class), lcErr))
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loService IsNot Nothing Then
            loService.Close()
        End If

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvProgram_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvProgram.R_Validation
        Dim loEx As New R_Exception()

        Try
            pcError = ""
            With poGridCellCollection
                If String.IsNullOrWhiteSpace(.Item("_CPROGRAM_ID").Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00300_01")
                    loEx.Add("CSM00300_01", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00300_01"))
                    plCancel = True
                End If

                If String.IsNullOrWhiteSpace(.Item("_CPROGRAM_NAME").Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00300_02")
                    loEx.Add("CSM00300_02", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00300_02"))
                    plCancel = True
                End If

                If String.IsNullOrWhiteSpace(.Item("_CATTRIBUTE_ID").Value) Then
                    pcError += R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00300_03")
                    loEx.Add("CSM00300_03", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00300_03"))
                    plCancel = True
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " Icon Actions "

    Private Sub btnBrowse_Click(sender As Object, e As System.EventArgs) Handles btnBrowse.Click
        With ofdIcon
            .InitialDirectory = IO.Path.Combine(My.Application.Info.DirectoryPath, "Data")
            .Filter = "PNG Images|*.png"
            .ShowDialog()
        End With
    End Sub

    Private Sub btnUpload_Click(sender As Object, e As System.EventArgs) Handles btnUpload.Click
        Dim loException As New R_Exception
        Dim loFileHandler As New FileHandler
        Dim lnImageSize As Integer

        Try
            ' Check filename
            If _CFILE.Trim.Equals("") Then
                loException.Add("Err001", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "Err001").Trim)
                Exit Try
            End If
            ' Check image size
            lnImageSize = pbIcon.Image.Width
            If lnImageSize <> 113 Then
                loException.Add("Err001", "Invalid image size.")
                Exit Try
            End If

            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
            With loFileHandler
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = loGridKey.CAPPS_CODE
                .CATTRIBUTE_GROUP = loGridKey.CATTRIBUTE_GROUP
                .CATTRIBUTE_ID = loGridKey.CATTRIBUTE_ID
                .CITEM_ID = loGridKey.CPROGRAM_ID
                .CACTION = "SAVEICON"
                .CUSER_ID = _CUSERID
                .CFILE_NAME = _CFILE_NAME
                .CDESCRIPTION = ""
                .CPROGRAM_ID = "CSM00300"
                .CFILE_GROUP = "PROGRAM_ICON"
                .ProcessSingleFile(_CFILE)
                Threading.Thread.Sleep(5000)
            End With
            RefreshGrids()
        Catch ex As Exception
            loException.Add(ex)
        Finally
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            _CFILE = ""
        End Try
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        If loException.Haserror Then
            Me.R_DisplayException(loException)
        End If
    End Sub

    Private Sub ofdIcon_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles ofdIcon.FileOk
        Dim loImageByte As Byte()
        _CFILE = ofdIcon.FileName
        _CFILE_NAME = ofdIcon.SafeFileName
        With pbIcon
            loImageByte = R_Utility.GetByteFromFile(_CFILE)
            Using mStream As New MemoryStream(loImageByte)
                .Image = Image.FromStream(mStream)
            End Using
        End With
    End Sub

#End Region

End Class
