﻿Public Class RVT00100CheckFilesDTO
    Public Property CFOLDER As String
    Public Property CFILENAME As String
End Class
