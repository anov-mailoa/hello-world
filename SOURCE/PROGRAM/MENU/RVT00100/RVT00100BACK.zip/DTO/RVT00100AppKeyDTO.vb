﻿Public Class RVT00100AppKeyDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
End Class
