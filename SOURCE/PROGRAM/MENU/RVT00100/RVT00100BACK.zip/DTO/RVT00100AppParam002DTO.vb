﻿Imports R_BackEnd

<Serializable()> _
Public Class RVT00100AppParam002DTO
    Inherits R_DTOBase

    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CPARAMETER_ID As String
    Public Property CPARAMETER_GROUP As String
    Public Property CATTRIBUTE_GROUP As String
    Public Property CATTRIBUTE_ID As String
    Public Property CSOURCE_GROUP_ID As String
    Public Property CITEM_ID As String
    Public Property CSOURCE_ID As String
    Public Property CITEM_ATTRIBUTE_ID As String
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)
    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)

End Class
