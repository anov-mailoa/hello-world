﻿Public Class RVT00100SourceListDTO
    Public Property CPROGRAM_ID As String
    Public Property CPROGRAM_NAME As String
    Public Property CATTRIBUTE_GROUP As String
    Public Property CATTRIBUTE_ID As String
    Public Property CSOURCE_ID As String
    Public Property CDESCRIPTION As String
End Class
