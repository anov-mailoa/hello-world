﻿Public Class RVT00100NextVerDTO
    Public Property CLAST_VERSION As String
    Public Property CNEXT_VERSION_1 As String
    Public Property CNEXT_VERSION_2 As String
    Public Property CNEXT_VERSION_3 As String
    Public Property CNEXT_VERSION_4 As String
End Class
