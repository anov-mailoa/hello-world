﻿Public Class RVT00100AppParam002KeyDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CPARAMETER_ID As String
    Public Property CPARAMETER_GROUP As String
End Class
