﻿Public Class RVT00100ReleaseFilesDTO
    Public Property CSEQUENCE As String
    Public Property CPATH As String
    Public Property CREVISION As String
    Public Property CSOURCE_ID As String
    Public Property CPARAMETER_GROUP As String
    Public Property OFILE_BYTE As Byte()
End Class
