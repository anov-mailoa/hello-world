﻿Public Class RVT00100AppVersionComboDTO
    Public Property CVERSION As String
End Class
