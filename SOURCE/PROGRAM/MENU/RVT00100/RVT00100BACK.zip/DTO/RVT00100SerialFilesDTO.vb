﻿<Serializable()>
Public Class RVT00100SerialFilesDTO
    Public Property CFOLDER As String
    Public Property CFILENAME As String
    Public Property LFOUND As Boolean
End Class
