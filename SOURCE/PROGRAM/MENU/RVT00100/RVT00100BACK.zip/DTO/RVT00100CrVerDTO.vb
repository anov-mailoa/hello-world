﻿Public Class RVT00100CrVerDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CINCREMENT As String
    Public Property CSKIP_MAJOR As String
    Public Property CSKIP_MINOR As String
    Public Property CALIAS As String
    Public Property CCODE_NAME As String
    Public Property CUSER_ID As String
    Public Property CNOTE As String
End Class
