﻿Public Class RVT00100LogTypeComboDTO
    Public Property CLOG_TYPE As String
End Class
