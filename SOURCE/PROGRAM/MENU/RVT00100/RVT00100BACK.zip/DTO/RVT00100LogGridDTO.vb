﻿Public Class RVT00100LogGridDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CVERSION As String
    Public Property CAPP_UNIT As String
    Public Property CLOG_TYPE As String
    Public Property CLOG_CONTENT As String
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)
    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)
End Class
