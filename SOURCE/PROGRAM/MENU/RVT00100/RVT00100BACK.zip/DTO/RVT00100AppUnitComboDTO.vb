﻿Public Class RVT00100AppUnitComboDTO
    Public Property CAPP_UNIT As String
End Class
