﻿Public Class RVT00100ProviderComboDTO
    Public Property CCOMPANY_ID As String
    Public Property CCOMPANY_NAME As String
End Class
