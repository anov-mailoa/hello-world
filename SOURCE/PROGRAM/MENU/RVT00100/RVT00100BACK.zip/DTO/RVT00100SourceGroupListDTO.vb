﻿Public Class RVT00100SourceGroupListDTO
    Public Property CSOURCE_GROUP_ID As String
    Public Property CDESCRIPTION As String
    Public Property CATTRIBUTE_GROUP As String
    Public Property CATTRIBUTE_ID As String
End Class
