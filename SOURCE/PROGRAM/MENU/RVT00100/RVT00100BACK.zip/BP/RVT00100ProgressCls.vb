﻿Imports R_Common
Imports R_BackEnd
Imports System.Data.Common
Imports System.Transactions
Imports System.IO
Imports RCustDBFileCommon
Imports System.Configuration

Public Class RVT00100ProgressCls
    Implements R_IBatchProcess

    Public Sub R_BatchProcess(poBatchProcessPar As R_BatchProcessPar) Implements R_IBatchProcess.R_BatchProcess
        Dim loEx As New R_Exception
        Dim loDb As New R_Db
        Dim lcQuery As String
        Dim loConn As DbConnection = Nothing
        Dim lnCount As Integer = 0
        Dim loObject As List(Of RCustDBFileProcessKeyDTO)
        Dim loFileList As List(Of RVT00100SerialFilesDTO)
        Dim llFound As Boolean
        Dim lnTry As Integer = 0
        Dim lnMaxTry As Integer = 30
        Dim lcTriggerFilename As String = "D:\RealCodeTools\SignTool\RealSignToolTrigger.txt"
        Dim loTriggerFileWriter As StreamWriter
        Dim loTriggerFileStream As FileStream
        Dim loTriggerFileReader As StreamReader
        Dim lcTriggerCode As String

        Try
            lnCount = poBatchProcessPar.UserParameters.Where(Function(x) x.Key.Equals("COUNT")).FirstOrDefault.Value
            loObject = R_Utility.Deserialize(poBatchProcessPar.UserParameters.Where(Function(x) x.Key.Equals("LIST")).FirstOrDefault.Value)

            ' copy loObject ke loFileList
            loFileList = New List(Of RVT00100SerialFilesDTO)
            For Each loRow As RCustDBFileProcessKeyDTO In loObject
                loFileList.Add(New RVT00100SerialFilesDTO() With {.CFOLDER = loRow.CFILE_GROUP, .CFILENAME = loRow.CFILE_NAME, .LFOUND = False})
            Next

            'Using TransScope As New TransactionScope(TransactionScopeOption.Required, New TimeSpan(0, 1, 0, 0))
            loConn = loDb.GetConnection()

            For i = 1 To lnCount

                ' cari file mana yang sedang diproses
                llFound = False
                lnTry = 1
                Do While Not llFound And lnTry <= lnMaxTry
                    DebugText("File #" + i.ToString.Trim + " (checking trial #" + lnTry.ToString.Trim + ")...")
                    For Each loFile As RVT00100SerialFilesDTO In loFileList
                        If Not loFile.LFOUND AndAlso File.Exists(Path.Combine(loFile.CFOLDER, loFile.CFILENAME)) Then
                            llFound = True
                            loFile.LFOUND = True
                            DebugText("File " + loFile.CFILENAME.Trim + " created...")
                            lcQuery = "exec RSP_WriteUploadProcessStatus '{0}', '{1}', '{2}', '{3}', '{4}'"
                            lcQuery = String.Format(lcQuery, poBatchProcessPar.Key.COMPANY_ID, poBatchProcessPar.Key.USER_ID, poBatchProcessPar.Key.KEY_GUID.Trim, i, "Package " + loFile.CFILENAME + " created...")
                            loDb.SqlExecNonQuery(lcQuery, loConn, False)
                            Exit For
                        End If
                    Next
                    lnTry += 1
                    If lnTry > lnMaxTry And Not llFound Then
                        DebugText("File #" + i.ToString.Trim + " checking skipped, please check on server...")
                        lcQuery = "exec RSP_WriteUploadProcessStatus '{0}', '{1}', '{2}', '{3}', '{4}'"
                        lcQuery = String.Format(lcQuery, poBatchProcessPar.Key.COMPANY_ID, poBatchProcessPar.Key.USER_ID, poBatchProcessPar.Key.KEY_GUID.Trim, i, "Package #" + i.ToString.Trim + " checking skipped, please check on server after process complete...")
                        loDb.SqlExecNonQuery(lcQuery, loConn, False)
                    End If
                    Threading.Thread.Sleep(30000)
                Loop
                'check process abortion
                loTriggerFileStream = New FileStream(lcTriggerFilename, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)
                loTriggerFileReader = New StreamReader(loTriggerFileStream)
                With loTriggerFileReader
                    lcTriggerCode = .ReadLine()
                    .Close()
                End With
                ' if trigger code e A abort process
                If lcTriggerCode.Trim.Equals("A") Then
                    DebugText("Abort process...")
                    Exit For
                End If
            Next
            lcQuery = "exec RSP_WriteUploadProcessStatus '{0}', '{1}', '{2}', '{3}', '{4}', '{5}'"
            lcQuery = String.Format(lcQuery, poBatchProcessPar.Key.COMPANY_ID, poBatchProcessPar.Key.USER_ID, poBatchProcessPar.Key.KEY_GUID.Trim, lnCount, "Process complete.", 1)
            loDb.SqlExecNonQuery(lcQuery, loConn, True)

            If ConfigurationManager.AppSettings.GetValues("SignToolOn")(0) = "True" Then
                    ' change to 2 to start queue process
                    loTriggerFileWriter = My.Computer.FileSystem.OpenTextFileWriter(lcTriggerFilename, False)
                    With loTriggerFileWriter
                        .Write("0")
                        .Close()
                    End With
                End If

            '    TransScope.Complete()
            'End Using
        Catch ex As Exception
            DebugText("Error: " + ex.Message)
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub DebugText(pcDebugLine As String)
        Dim loTextFileWriter As StreamWriter
        Dim loTextFileStream As FileStream
        Dim loTextFilename As String
        Dim lcTimeLabel As String

        loTextFilename = "D:\RealCode\Debug-" + Now.ToString("yyyyMMdd").Trim + ".log"
        If Not File.Exists(loTextFilename) Then
            File.Create(loTextFilename).Close()
        End If
        loTextFileWriter = My.Computer.FileSystem.OpenTextFileWriter(loTextFilename, True)
        With loTextFileWriter
            lcTimeLabel = Now.ToString.Trim + ": "
            .WriteLine(lcTimeLabel + pcDebugLine)
            .Close()
        End With
    End Sub
End Class
