﻿Imports R_BackEnd
Imports R_Common
Imports System.Data.Common

Public Class RVT00100AppParam002Cls
    Inherits R_BusinessObject(Of RVT00100AppParam002DTO)

    Protected Overrides Sub R_Deleting(poEntity As RVT00100AppParam002DTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loResult As RVT00100AppParam002DTO

        Try
            loConn = loDb.GetConnection()

            With poEntity

                'delete main table
                lcQuery = "DELETE RVM_APP_PARAM_002 "
                lcQuery += "WHERE "
                lcQuery += "CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CPARAMETER_ID = '{2}' "
                lcQuery = String.Format(lcQuery,
                .CCOMPANY_ID,
                .CAPPS_CODE,
                .CPARAMETER_ID)

                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As RVT00100AppParam002DTO) As RVT00100AppParam002DTO
        Dim lcQuery As String
        Dim loResult As RVT00100AppParam002DTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity

                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "RVM_APP_PARAM_002 (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CPARAMETER_ID = '{2}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CPARAMETER_ID)
            End With

            loResult = loDb.SqlExecObjectQuery(Of RVT00100AppParam002DTO)(lcQuery).FirstOrDefault
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As RVT00100AppParam002DTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As RVT00100AppParam002DTO
        Dim lcParameterID As String

        Try
            loConn = loDb.GetConnection()

            With poNewEntity

                If poCRUDMode = eCRUDMode.AddMode Then
                    ' check duplicate in the same parameter group
                    lcQuery = "SELECT * "
                    lcQuery += "FROM "
                    lcQuery += "RVM_APP_PARAM_002 (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CPARAMETER_GROUP = '{2}' "
                    lcQuery += "AND CATTRIBUTE_GROUP = '{3}' "
                    lcQuery += "AND CATTRIBUTE_ID = '{4}' "
                    lcQuery += "AND CSOURCE_GROUP_ID = '{5}' "
                    lcQuery += "AND CITEM_ID = '{6}' "
                    lcQuery += "AND CSOURCE_ID = '{7}' "
                    lcQuery += "AND CITEM_ATTRIBUTE_ID = '{8}' "
                    lcQuery = String.Format(lcQuery, _
                                            .CCOMPANY_ID, _
                                            .CAPPS_CODE, _
                                            .CPARAMETER_GROUP, _
                                            .CATTRIBUTE_GROUP, _
                                            .CATTRIBUTE_ID, _
                                            .CSOURCE_GROUP_ID, _
                                            .CITEM_ID, _
                                            .CSOURCE_ID, _
                                            .CITEM_ATTRIBUTE_ID)

                    loResult = loDb.SqlExecObjectQuery(Of RVT00100AppParam002DTO)(lcQuery, loConn, False).FirstOrDefault
                    If loResult IsNot Nothing Then
                        Throw New Exception("Duplicate row.")
                    End If

                    ' Get last ID
                    lcQuery = "SELECT TOP 1 * "
                    lcQuery += "FROM "
                    lcQuery += "RVM_APP_PARAM_002 (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "ORDER BY CPARAMETER_ID DESC "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE)

                    loResult = loDb.SqlExecObjectQuery(Of RVT00100AppParam002DTO)(lcQuery, loConn, False).FirstOrDefault
                    If loResult IsNot Nothing Then
                        lcParameterID = loResult.CPARAMETER_ID
                        lcParameterID = Right("00000000" & CInt(lcParameterID + 1).ToString.Trim, 8)
                    Else
                        lcParameterID = "00000001"
                    End If

                    .CPARAMETER_ID = lcParameterID
                    .CCREATE_BY = .CUPDATE_BY

                    lcQuery = "INSERT INTO RVM_APP_PARAM_002 ("
                    lcQuery += "CCOMPANY_ID, "
                    lcQuery += "CAPPS_CODE, "
                    lcQuery += "CPARAMETER_ID, "
                    lcQuery += "CPARAMETER_GROUP, "
                    lcQuery += "CATTRIBUTE_GROUP, "
                    lcQuery += "CATTRIBUTE_ID, "
                    lcQuery += "CSOURCE_GROUP_ID, "
                    lcQuery += "CITEM_ID, "
                    lcQuery += "CSOURCE_ID, "
                    lcQuery += "CITEM_ATTRIBUTE_ID, "
                    lcQuery += "CUPDATE_BY, "
                    lcQuery += "DUPDATE_DATE, "
                    lcQuery += "CCREATE_BY, "
                    lcQuery += "DCREATE_DATE) "
                    lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', GETDATE(), '{11}', GETDATE()) "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CPARAMETER_ID,
                    .CPARAMETER_GROUP,
                    .CATTRIBUTE_GROUP,
                    .CATTRIBUTE_ID,
                    .CSOURCE_GROUP_ID,
                    .CITEM_ID,
                    .CSOURCE_ID,
                    .CITEM_ATTRIBUTE_ID,
                    .CUPDATE_BY,
                    .CCREATE_BY)
                    loDb.SqlExecNonQuery(lcQuery)

                ElseIf poCRUDMode = eCRUDMode.EditMode Then
                    lcQuery = "UPDATE RVM_APP_PARAM_002 "
                    lcQuery += "SET CITEM_ID = '{3}', "
                    lcQuery += "CSOURCE_ID = '{4}', "
                    lcQuery += "CITEM_ATTRIBUTE_ID = '{5}', "
                    lcQuery += "CUPDATE_BY = '{6}', "
                    lcQuery += "DUPDATE_DATE = GETDATE() "
                    lcQuery += "WHERE "
                    lcQuery += "CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CPARAMETER_ID = '{2}' "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CPARAMETER_ID,
                    .CITEM_ID,
                    .CSOURCE_ID,
                    .CITEM_ATTRIBUTE_ID,
                    .CUPDATE_BY)
                    loDb.SqlExecNonQuery(lcQuery)
                End If
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Function GetParameters(poTableKey As RVT00100AppParam002KeyDTO) As List(Of RVT00100AppParam002GridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RVT00100AppParam002GridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poTableKey

                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "RVM_APP_PARAM_002 (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CPARAMETER_GROUP = '{2}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CPARAMETER_GROUP)
            End With

            loResult = loDb.SqlExecObjectQuery(Of RVT00100AppParam002GridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetItemList(poKey As RVT00100ItemKeyDTO) As List(Of RVT00100ItemListDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RVT00100ItemListDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "EXEC RSP_Get_Item_Combo '{0}', '{1}', '{2}', '{3}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID)
            End With

            loResult = loDb.SqlExecObjectQuery(Of RVT00100ItemListDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult

    End Function

    Public Function GetSourceGroupList(poKey As RVT00100ItemKeyDTO) As List(Of RVT00100SourceGroupListDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RVT00100SourceGroupListDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "SELECT CATTRIBUTE_GROUP, CATTRIBUTE_ID, CSOURCE_GROUP_ID, CDESCRIPTION "
                lcQuery += "FROM CSM_SOURCE_GROUPS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID)
            End With

            loResult = loDb.SqlExecObjectQuery(Of RVT00100SourceGroupListDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult

    End Function

    Public Function GetSourceList(poKey As RVT00100ItemKeyDTO) As List(Of RVT00100SourceListDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RVT00100SourceListDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "SELECT A.CATTRIBUTE_GROUP, A.CATTRIBUTE_ID, A.CPROGRAM_ID, A.CSOURCE_ID, A.CDESCRIPTION, B.CPROGRAM_NAME "
                lcQuery += "FROM CSM_SOURCES A (NOLOCK) "
                lcQuery += "JOIN CSM_PROGRAMS B (NOLOCK) "
                lcQuery += "ON B.CCOMPANY_ID = A.CCOMPANY_ID "
                lcQuery += "AND B.CAPPS_CODE = A.CAPPS_CODE "
                lcQuery += "AND B.CATTRIBUTE_GROUP = A.CATTRIBUTE_GROUP "
                lcQuery += "AND B.CATTRIBUTE_ID = A.CATTRIBUTE_ID "
                lcQuery += "AND B.CPROGRAM_ID = A.CPROGRAM_ID "
                lcQuery += "WHERE A.CCOMPANY_ID = '{0}' "
                lcQuery += "AND A.CAPPS_CODE = '{1}' "
                lcQuery += "AND A.CATTRIBUTE_GROUP = '{2}' "
                lcQuery += "AND A.CATTRIBUTE_ID = '{3}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID)
            End With

            loResult = loDb.SqlExecObjectQuery(Of RVT00100SourceListDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult

    End Function
End Class
