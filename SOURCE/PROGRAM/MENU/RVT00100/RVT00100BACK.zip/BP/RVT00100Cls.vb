﻿Imports R_Common
Imports R_BackEnd
Imports System.Data.Common
Imports ServerHelper.General
Imports System.IO
Imports Ionic.Zip
Imports R_Version
Imports System.Configuration
Imports R_Deployment
Imports System.Transactions

Public Class RVT00100Cls
    Inherits R_BusinessObject(Of RVT00100DTO)

#Region " VARIABLES "
    Private Shared C_ZipPath As String = "D:\RealCode\Temp\Zips"
    Private Shared C_RootPath As String = "D:\RealCodeRelease"
#End Region

    Protected Overrides Sub R_Deleting(poEntity As RVT00100DTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loResult As RVT00100DTO

        Try
            loConn = loDb.GetConnection()

            With poEntity
                ' validasi
                lcQuery = "SELECT TOP 1 * "
                lcQuery += "FROM "
                lcQuery += "RVT_APP_INCLUDES (NOLOCK) "
                lcQuery += "WHERE CINCL_COMPANY_ID = '{0}' "
                lcQuery += "AND CINCL_APPS_CODE = '{1}' "
                lcQuery += "AND CINCL_VERSION = '{2}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION)

                loResult = loDb.SqlExecObjectQuery(Of RVT00100DTO)(lcQuery, loConn, False).FirstOrDefault
                If loResult IsNot Nothing Then
                    Throw New Exception("Application " + .CAPPS_CODE.Trim + " version " + .CVERSION.Trim + " is used.")
                End If

                lcQuery = "SELECT TOP 1 * "
                lcQuery += "FROM "
                lcQuery += "CSM_PROJECTS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION)

                loResult = loDb.SqlExecObjectQuery(Of RVT00100DTO)(lcQuery, loConn, False).FirstOrDefault
                If loResult IsNot Nothing Then
                    Throw New Exception("Application " + .CAPPS_CODE.Trim + " version " + .CVERSION.Trim + " is used.")
                End If

                'delete design, program and source version table
                lcQuery = "DELETE CSM_DESIGN_VERSIONS "
                lcQuery += "WHERE "
                lcQuery += "CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery = String.Format(lcQuery,
                .CCOMPANY_ID,
                .CAPPS_CODE,
                .CVERSION)
                loDb.SqlExecNonQuery(lcQuery, loConn, False)
                lcQuery = "DELETE CSM_SOURCE_VERSIONS "
                lcQuery += "WHERE "
                lcQuery += "CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery = String.Format(lcQuery,
                .CCOMPANY_ID,
                .CAPPS_CODE,
                .CVERSION)
                loDb.SqlExecNonQuery(lcQuery, loConn, False)
                lcQuery = "DELETE CSM_PROGRAM_VERSIONS "
                lcQuery += "WHERE "
                lcQuery += "CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery = String.Format(lcQuery,
                .CCOMPANY_ID,
                .CAPPS_CODE,
                .CVERSION)
                loDb.SqlExecNonQuery(lcQuery, loConn, False)

                'delete main table
                lcQuery = "DELETE RVT_APP_VERSION "
                lcQuery += "WHERE "
                lcQuery += "CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery = String.Format(lcQuery,
                .CCOMPANY_ID,
                .CAPPS_CODE,
                .CVERSION)

                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As RVT00100DTO) As RVT00100DTO
        Dim lcQuery As String
        Dim loResult As RVT00100DTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "RVT_APP_VERSION (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery += "AND CAPPS_CODE = '{1}' "
            lcQuery += "AND CVERSION = '{2}' "
            lcQuery = String.Format(lcQuery, poEntity.CCOMPANY_ID, poEntity.CAPPS_CODE, poEntity.CVERSION)

            loResult = loDb.SqlExecObjectQuery(Of RVT00100DTO)(lcQuery).FirstOrDefault
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As RVT00100DTO, poCRUDMode As R_Common.eCRUDMode)
        ' Update only
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As RVT00100DTO

        Try
            loConn = loDb.GetConnection()

            With poNewEntity

                If poCRUDMode = eCRUDMode.EditMode Then
                    lcQuery = "UPDATE RVT_APP_VERSION "
                    lcQuery += "SET "
                    lcQuery += "CALIAS = '{3}', "
                    lcQuery += "CCODE_NAME = '{4}', "
                    lcQuery += "CNOTE = '{5}', "
                    lcQuery += "CUPDATE_BY = '{6}', "
                    lcQuery += "DUPDATE_DATE = GETDATE() "
                    lcQuery += "WHERE "
                    lcQuery += "CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CVERSION = '{2}' "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CVERSION,
                    .CALIAS,
                    .CCODE_NAME,
                    .CNOTE,
                    .CUPDATE_BY)

                    loDb.SqlExecNonQuery(lcQuery, loConn, True)
                End If
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Function ReleaseVersion(poKey As RVT00100ReleaseDTO) As List(Of RVT00100SerialFilesDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcRtn As String = "OK"
        Dim loRtn As New List(Of RVT00100SerialFilesDTO)

        Try

            Using TransScope As New TransactionScope(TransactionScopeOption.Required, New TimeSpan(0, 40, 0))

                loCmd = loDb.GetCommand()
                lcQuery = "EXEC RSP_Release_Version '{0}', '{1}', '{2}', '{3}', @CRET_MSG OUTPUT "
                With poKey
                    lcQuery = String.Format(lcQuery,
                                        .CCOMPANY_ID,
                                        .CAPPS_CODE,
                                        .CVERSION,
                                        .CUSER_ID)
                End With
                loCmd.CommandText = lcQuery
                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@CRET_MSG"
                    .DbType = DbType.String
                    .Size = 50
                    .Direction = ParameterDirection.Output
                End With
                loCmd.Parameters.Add(loPar)
                loCmd.CommandTimeout = 2400
                loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd, True)

                If loCmd.Parameters("@CRET_MSG") Is Nothing Then
                    Throw New Exception("UNKNOWN_ERROR")
                Else
                    If Not loCmd.Parameters("@CRET_MSG").Value.Equals("OK") Then
                        Throw New Exception(loCmd.Parameters("@CRET_MSG").Value)
                    End If
                End If

                TransScope.Complete()
            End Using

            loRtn = DumpFiles(poKey)

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loRtn
    End Function

    Public Function GetVersions(poTableKey As RVT00100GridDTO) As List(Of RVT00100GridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RVT00100GridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poTableKey

                lcQuery = "SELECT A.CCOMPANY_ID, A.CAPPS_CODE, A.CVERSION, A.CMAJOR, A.CMINOR, A.CALIAS, A.CCODE_NAME, "
                lcQuery += "A.CSTATUS, A.COPEN_DATE, A.COPEN_BY, A.CRELEASE_DATE, A.CRELEASE_BY, "
                lcQuery += "A.CUPDATE_BY, A.DUPDATE_DATE, A.CCREATE_BY, A.DCREATE_DATE, "
                lcQuery += "ISNULL(B.CREVISION, '') AS CLAST_REVISION, ISNULL(B.CRELEASE_DATE,'') AS CLAST_REVISION_DATE, ISNULL(B.CRELEASE_BY, '') AS CLAST_REVISION_BY, "
                lcQuery += "CONVERT(datetime,A.COPEN_DATE,112) AS DOPEN_DATE, "
                lcQuery += "CONVERT(datetime,A.CRELEASE_DATE,112) AS DRELEASE_DATE, "
                lcQuery += "CONVERT(datetime,ISNULL(B.CRELEASE_DATE,''),112) AS DLAST_REVISION_DATE, "
                lcQuery += "A.CNOTE "
                lcQuery += "FROM RVT_APP_VERSION A (NOLOCK) "
                lcQuery += "LEFT JOIN RVT_APP_REVISION B (NOLOCK) "
                lcQuery += "ON B.CCOMPANY_ID = A.CCOMPANY_ID "
                lcQuery += "AND B.CAPPS_CODE = A.CAPPS_CODE "
                lcQuery += "AND B.CVERSION = A.CVERSION "
                lcQuery += "LEFT JOIN RVT_APP_REVISION C (NOLOCK) "
                lcQuery += "ON C.CCOMPANY_ID = B.CCOMPANY_ID "
                lcQuery += "AND C.CAPPS_CODE = B.CAPPS_CODE "
                lcQuery += "AND C.CVERSION = B.CVERSION "
                lcQuery += "AND C.CREVISION > B.CREVISION "
                lcQuery += "WHERE A.CCOMPANY_ID = '{0}' "
                lcQuery += "AND A.CAPPS_CODE = '{1}' "
                lcQuery += "AND C.CREVISION IS NULL "
                lcQuery += "ORDER BY A.CMAJOR, A.CMINOR "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE)
            End With

            loResult = loDb.SqlExecObjectQuery(Of RVT00100GridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult

    End Function

    Public Function CreateVersion(poKey As RVT00100CrVerDTO) As String
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcRtn As String = "OK"

        Try

            Using TransScope As New TransactionScope(TransactionScopeOption.Required, New TimeSpan(0, 40, 0))

                loCmd = loDb.GetCommand()

                lcQuery = "EXEC RSP_Create_Version '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', @CRET_MSG OUTPUT "
                With poKey
                    lcQuery = String.Format(lcQuery,
                                        .CCOMPANY_ID,
                                        .CAPPS_CODE,
                                        .CINCREMENT,
                                        .CSKIP_MAJOR,
                                        .CSKIP_MINOR,
                                        .CALIAS,
                                        .CCODE_NAME,
                                        .CUSER_ID,
                                        .CNOTE)
                End With
                loCmd.CommandText = lcQuery
                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@CRET_MSG"
                    .DbType = DbType.String
                    .Size = 50
                    .Direction = ParameterDirection.Output
                End With
                loCmd.Parameters.Add(loPar)
                loCmd.CommandTimeout = 2400
                Logger.Log.Debug("Sebelum execute SP...")
                loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd, True)
                Logger.Log.Debug("Setelah execute SP...")

                If loCmd.Parameters("@CRET_MSG") Is Nothing Then
                    Throw New Exception("UNKNOWN_ERROR")
                Else
                    If Not loCmd.Parameters("@CRET_MSG").Value.Equals("OK") Then
                        Throw New Exception(loCmd.Parameters("@CRET_MSG").Value)
                    End If
                End If

                Logger.Log.Debug("Sebelum TransScope.Complete...")
                TransScope.Complete()
                Logger.Log.Debug("Setelah TransScope.Complete...")
            End Using

        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loEx.Haserror Then
            Logger.Log.Error(loEx)
        End If
        loEx.ThrowExceptionIfErrors()
        Return lcRtn
    End Function

    Public Function ChangeVersionStatus(poKey As RVT00100DTO) As String
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcRtn As String = "OK"

        Try

            Using TransScope As New TransactionScope(TransactionScopeOption.Required, New TimeSpan(0, 40, 0))

                loCmd = loDb.GetCommand()

                lcQuery = "EXEC RSP_Change_Version_Status '{0}', '{1}', '{2}', '{3}', '{4}', @CRET_MSG OUTPUT "
                With poKey
                    lcQuery = String.Format(lcQuery,
                                        .CCOMPANY_ID,
                                        .CAPPS_CODE,
                                        .CVERSION,
                                        .CSTATUS,
                                        .CUPDATE_BY)
                End With
                loCmd.CommandText = lcQuery
                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@CRET_MSG"
                    .DbType = DbType.String
                    .Size = 50
                    .Direction = ParameterDirection.Output
                End With
                loCmd.Parameters.Add(loPar)
                loCmd.CommandTimeout = 2400
                Logger.Log.Debug("Sebelum execute SP...")
                loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd, True)
                Logger.Log.Debug("Setelah execute SP...")

                If loCmd.Parameters("@CRET_MSG") Is Nothing Then
                    Throw New Exception("UNKNOWN_ERROR")
                Else
                    If Not loCmd.Parameters("@CRET_MSG").Value.Equals("OK") Then
                        Throw New Exception(loCmd.Parameters("@CRET_MSG").Value)
                    End If
                End If

                Logger.Log.Debug("Sebelum TransScope.Complete...")
                TransScope.Complete()
                Logger.Log.Debug("Setelah TransScope.Complete...")
            End Using

        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loEx.Haserror Then
            Logger.Log.Error(loEx)
        End If
        loEx.ThrowExceptionIfErrors()
        Return lcRtn
    End Function

    Public Function DumpFiles(poKey As RVT00100ReleaseDTO) As List(Of RVT00100SerialFilesDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        'Dim lcRtn As String = "OK"
        Dim loRtn As New List(Of RVT00100SerialFilesDTO)
        Dim loPackageFile As RVT00100SerialFilesDTO
        Dim loAppInfo As RVT00100ReleaseDTO
        Dim loAppParam As New List(Of RVT00100AppParam002GridDTO)
        Dim loTempByte As List(Of RVT00100ReleaseFilesDTO)
        Dim lcSourceFilePath As String
        Dim lcZipFilePath As String
        Dim lcFrontFilePath As String
        Dim lcBackFilePath As String
        Dim lcPackagesFilePath As String
        Dim lcPackagesFilePath2 As String
        Dim lcPackagesFileName As String
        Dim lcDBRevPath As String
        Dim loPublishers As New List(Of RVT00100ReleaseFilesDTO)
        Dim lcRevision As String = "0000"
        Dim lcNextRevision As String = "0000"
        Dim lcMSBuildPath As String = ""
        Dim lcRDeployPath As String = "D:\RealCodeTools"
        Dim lcLogFilePath As String = ""
        Dim lcBackendFilePath As String = ""
        Dim loFilenames As List(Of String)
        Dim lcFilenames As String()
        Dim lcPatchPath As String
        Dim loMainFiles As New List(Of RVT00100CheckFilesDTO)
        Dim loMainFile As RVT00100CheckFilesDTO
        Dim loProgFiles As New List(Of RVT00100CheckFilesDTO)
        Dim loProgFile As RVT00100CheckFilesDTO
        Dim lcSelectionCriteria As String = ""
        Dim lcTriggerFilename As String = "D:\RealCodeTools\SignTool\RealSignToolTrigger.txt"
        Dim loTriggerFileWriter As StreamWriter
        Dim loTriggerFileStream As FileStream
        Dim loTriggerFileReader As StreamReader
        Dim lcTriggerCode As String
        Dim lcCheckPoint As String = ""
        Dim llZipOK As Boolean
        Dim llProcessOK As Boolean
        Dim loGuid As Guid

        Try
            C_RootPath = ConfigurationManager.AppSettings.GetValues("ReleasePath")(0)

            With poKey

                ' find application type first
                lcQuery = "SELECT TOP 1 CAPPLICATION_TYPE "
                lcQuery += "FROM "
                lcQuery += "RVM_APPLICATION (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE)

                loAppInfo = loDb.SqlExecObjectQuery(Of RVT00100ReleaseDTO)(lcQuery).FirstOrDefault
                If loAppInfo Is Nothing OrElse loAppInfo.CAPPLICATION_TYPE.Trim.Equals("") Then
                    Throw New Exception("Please set application type for Application " + .CAPPS_CODE.Trim + ".")
                End If

                ' dump files
                If loAppInfo.CAPPLICATION_TYPE.Trim.Equals("002") Then
                    ' Validasi release
                    lcQuery = "SELECT TOP 1 * "
                    lcQuery += "FROM "
                    lcQuery += "RVT_APP_VERSION (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CVERSION = '{2}' "
                    lcQuery += "AND CSTATUS = 'RELEASED' "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION)
                    loAppParam = loDb.SqlExecObjectQuery(Of RVT00100AppParam002GridDTO)(lcQuery)
                    If loAppParam Is Nothing OrElse loAppParam.Count = 0 Then
                        Throw New Exception("Please release version " + .CVERSION.Trim + " first.")
                    End If
                    lcQuery = "SELECT TOP 1 A.* "
                    lcQuery += "FROM RVM_APP_PARAM_002 A (NOLOCK) "
                    lcQuery += "JOIN CSM_PROGRAM_VERSIONS B (NOLOCK) "
                    lcQuery += "ON B.CCOMPANY_ID = A.CCOMPANY_ID "
                    lcQuery += "AND B.CAPPS_CODE = A.CAPPS_CODE "
                    lcQuery += "AND B.CATTRIBUTE_GROUP = A.CATTRIBUTE_GROUP "
                    lcQuery += "AND B.CATTRIBUTE_ID = A.CATTRIBUTE_ID "
                    lcQuery += "AND B.CPROGRAM_ID = A.CITEM_ID "
                    lcQuery += "AND B.CVERSION = '{2}' "
                    lcQuery += "AND NOT B.CPROJECT_STATUS = 'QCCI' "
                    lcQuery += "WHERE A.CCOMPANY_ID = '{0}' "
                    lcQuery += "AND A.CAPPS_CODE = '{1}' "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION)
                    loAppParam = loDb.SqlExecObjectQuery(Of RVT00100AppParam002GridDTO)(lcQuery)
                    If loAppParam.Count > 0 Then
                        Throw New Exception("Please release all deployment item(s) first.")
                    End If
                    ' validasi setting
                    ' FRONT-MAIN
                    lcQuery = "SELECT TOP 1 * "
                    lcQuery += "FROM "
                    lcQuery += "RVM_APP_PARAM_002 (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CPARAMETER_GROUP = 'FRONT-MAIN' "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE)
                    loAppParam = loDb.SqlExecObjectQuery(Of RVT00100AppParam002GridDTO)(lcQuery)
                    If loAppParam Is Nothing OrElse loAppParam.Count = 0 Then
                        Throw New Exception("Please set source group for FRONT-MAIN parameter group of " + .CAPPS_CODE.Trim + ".")
                    End If
                    ' FRONT-PRG
                    lcQuery = "SELECT TOP 1 * "
                    lcQuery += "FROM "
                    lcQuery += "RVM_APP_PARAM_002 (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CPARAMETER_GROUP = 'FRONT-PRG' "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE)
                    loAppParam = loDb.SqlExecObjectQuery(Of RVT00100AppParam002GridDTO)(lcQuery)
                    If loAppParam Is Nothing OrElse loAppParam.Count = 0 Then
                        Throw New Exception("Please set source group for FRONT-PRG parameter group of " + .CAPPS_CODE.Trim + ".")
                    End If
                    ' FRONT-RES
                    lcQuery = "SELECT TOP 1 * "
                    lcQuery += "FROM "
                    lcQuery += "RVM_APP_PARAM_002 (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CPARAMETER_GROUP = 'FRONT-RES' "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE)
                    loAppParam = loDb.SqlExecObjectQuery(Of RVT00100AppParam002GridDTO)(lcQuery)
                    If loAppParam Is Nothing OrElse loAppParam.Count = 0 Then
                        Throw New Exception("Please set source group for FRONT-RES parameter group of " + .CAPPS_CODE.Trim + ".")
                    End If
                    ' BACK
                    lcQuery = "SELECT TOP 1 * "
                    lcQuery += "FROM "
                    lcQuery += "RVM_APP_PARAM_002 (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CPARAMETER_GROUP = 'BACK' "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE)
                    loAppParam = loDb.SqlExecObjectQuery(Of RVT00100AppParam002GridDTO)(lcQuery)
                    If loAppParam Is Nothing OrElse loAppParam.Count = 0 Then
                        Throw New Exception("Please set source group for BACK parameter group of " + .CAPPS_CODE.Trim + ".")
                    End If
                    ' SERVICE
                    lcQuery = "SELECT TOP 1 * "
                    lcQuery += "FROM "
                    lcQuery += "RVM_APP_PARAM_002 (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CPARAMETER_GROUP = 'SERVICE' "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE)
                    loAppParam = loDb.SqlExecObjectQuery(Of RVT00100AppParam002GridDTO)(lcQuery)
                    If loAppParam Is Nothing OrElse loAppParam.Count = 0 Then
                        Throw New Exception("Please set item for SERVICE parameter group of " + .CAPPS_CODE.Trim + ".")
                    End If

                    If ConfigurationManager.AppSettings.GetValues("SignToolOn")(0) = "True" Then
                        DebugText("Check for currently running packaging process...")
                        'validasi proses packaging
                        loTriggerFileStream = New FileStream(lcTriggerFilename, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)
                        loTriggerFileReader = New StreamReader(loTriggerFileStream)
                        With loTriggerFileReader
                            lcTriggerCode = .ReadLine()
                            .Close()
                        End With
                        ' if trigger code ne 0 cancel process
                        If Not lcTriggerCode.Trim.Equals("0") Then
                            llProcessOK = False
                            Throw New Exception("There is another packaging process running. Please do re-release process later.")
                        Else
                            llProcessOK = True
                            ' else change to 1 to lock packaging queue
                            loTriggerFileWriter = My.Computer.FileSystem.OpenTextFileWriter(lcTriggerFilename, False)
                            With loTriggerFileWriter
                                .Write("1")
                                .Close()
                            End With
                        End If
                    End If

                    DebugText("Get files...")
                    ' Get files
                    'lcQuery = "SELECT * FROM TFILES "
                    lcQuery = "EXEC RSP_Get_Release_Files '{0}', '{1}', '{2}', {3}  "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID,
                                            .CAPPS_CODE,
                                            .CVERSION,
                                            getBit(.LRECOVER_VERSION))
                    loTempByte = loDb.SqlExecObjectQuery(Of RVT00100ReleaseFilesDTO)(lcQuery)

                    DebugText("Unzip files...")
                    ' Save files
                    ' Check and make sure if Realta temp zip folder exists
                    If Not Directory.Exists(C_ZipPath) Then
                        Directory.CreateDirectory(C_ZipPath)
                    End If
                    lcFrontFilePath = C_RootPath.Trim & "\" & .CCOMPANY_ID.Trim & "\" & .CAPPS_CODE.Trim & "\STD\Front"
                    lcBackFilePath = C_RootPath.Trim & "\" & .CCOMPANY_ID.Trim & "\" & .CAPPS_CODE.Trim & "\STD\Back"
                    lcDBRevPath = C_RootPath.Trim & "\" & .CCOMPANY_ID.Trim & "\" & .CAPPS_CODE.Trim & "\STD\DB-Rev"
                    lcPackagesFilePath = C_RootPath.Trim & "\" & .CCOMPANY_ID.Trim & "\" & .CAPPS_CODE.Trim & "\STD\Packages"
                    If Not Directory.Exists(lcPackagesFilePath) Then
                        Directory.CreateDirectory(lcPackagesFilePath)
                    End If
                    Dim loFile As RVT00100ReleaseFilesDTO
                    ' Delete dulu UpdateFiles Programs dan Resources
                    If Directory.Exists(lcFrontFilePath) Then
                        Directory.Delete(lcFrontFilePath, True)
                    End If
                    If Directory.Exists(lcBackFilePath) Then
                        Directory.Delete(lcBackFilePath, True)
                    End If
                    If Directory.Exists(lcDBRevPath) Then
                        Directory.Delete(lcDBRevPath, True)
                    End If
                    DebugText("Loop release files...")
                    For i = 0 To loTempByte.Count - 1
                        loFile = loTempByte(i)

                        'lcZipFilePath = C_ZipPath.Trim & "\" & loFile.CSOURCE_ID.Trim & ".zip"
                        ' rename to guid
                        loGuid = Guid.NewGuid()
                        lcZipFilePath = C_ZipPath.Trim & "\" & loFile.CSOURCE_ID.Trim & "-" & loGuid.ToString("N").Trim & ".zip"
                        ' Create folder if not exists
                        lcSourceFilePath = C_RootPath.Trim & loFile.CPATH.Trim
                        If Not Directory.Exists(lcSourceFilePath) Then
                            Directory.CreateDirectory(lcSourceFilePath)
                        End If
                        ' save zip file
                        R_Utility.ConvertByteToFile(lcZipFilePath, loFile.OFILE_BYTE)
                        lcCheckPoint = "Checkpoint: " + lcZipFilePath.Trim + ", after ConvertByteToFile."
                        ' ***** Extract file *****
                        'DebugText("Extract files " + loFile.CSOURCE_ID.Trim + ".zip ...")
                        llZipOK = False
                        Do
                            llZipOK = File.Exists(lcZipFilePath)
                            lcCheckPoint = "Checkpoint: " + lcZipFilePath.Trim + ", after File.Exists."
                        Loop While Not llZipOK
                        ' Extract file only if exists
                        Using zip As New ZipFile(lcZipFilePath)
                            zip.ParallelDeflateThreshold = -1
                            lcCheckPoint = "Checkpoint: " + lcZipFilePath.Trim + ", after Read."
                            If loFile.CPARAMETER_GROUP.Trim.Equals("FRONT-PRG") Or
                                loFile.CPARAMETER_GROUP.Trim.Equals("FRONT-RES") Or
                                loFile.CPARAMETER_GROUP.Trim.Equals("BACK") Then
                                ' CR002 - filter extract untuk file2 dll
                                lcSelectionCriteria = "name = " + loFile.CSOURCE_ID.Trim + ".dll"
                                zip.ExtractSelectedEntries(lcSelectionCriteria, Nothing, lcSourceFilePath, ExtractExistingFileAction.OverwriteSilently)
                            Else
                                zip.ExtractAll(lcSourceFilePath, ExtractExistingFileAction.OverwriteSilently)
                            End If
                            lcCheckPoint = "Checkpoint: " + lcZipFilePath.Trim + ", after Extract."
                            zip.Dispose()
                            lcCheckPoint = "Checkpoint: " + lcZipFilePath.Trim + ", after Dispose."
                        End Using
                        ' Delete Zip File
                        File.Delete(lcZipFilePath)

                        ' Buang file di Program yang ada di Main
                        ' Kumpulkan dulu file2 Main
                        If loTempByte(i).CPARAMETER_GROUP = "FRONT-MAIN" Then
                            loFilenames = New List(Of String)
                            loFilenames.AddRange(Directory.GetFiles(lcSourceFilePath, "*.dll", SearchOption.TopDirectoryOnly))
                            For Each fileName As String In loFilenames
                                loMainFile = New RVT00100CheckFilesDTO
                                loMainFile.CFILENAME = fileName.Replace(lcSourceFilePath, "")
                                loMainFile.CFOLDER = lcSourceFilePath
                                loMainFiles.Add(loMainFile)
                            Next
                        End If
                        If loTempByte(i).CPARAMETER_GROUP = "FRONT-PRG" Then
                            loFilenames = New List(Of String)
                            loFilenames.AddRange(Directory.GetFiles(lcSourceFilePath, "*.dll", SearchOption.TopDirectoryOnly))
                            For Each fileName As String In loFilenames
                                loProgFile = New RVT00100CheckFilesDTO
                                loProgFile.CFILENAME = fileName.Replace(lcSourceFilePath, "")
                                loProgFile.CFOLDER = lcSourceFilePath
                                loProgFiles.Add(loProgFile)
                            Next

                            Dim loConflictList = From file1 In loProgFiles Join file2 In loMainFiles
                                                 On file1.CFILENAME Equals file2.CFILENAME And file1.CFOLDER Equals file2.CFOLDER
                                                 Select file1.CFILENAME
                            If loConflictList.ToList.Count > 0 Then
                                For Each fileName As String In loConflictList.ToList
                                    File.Delete(lcSourceFilePath.Trim + fileName.Trim)
                                Next
                            End If
                        End If

                        ' R_Deploy
                        If i < loTempByte.Count - 1 Then
                            If loTempByte(i).CSEQUENCE.Trim = "001" _
                                And loTempByte(i).CSEQUENCE.Trim + loTempByte(i).CREVISION.Trim <> loTempByte(i + 1).CSEQUENCE.Trim + loTempByte(i + 1).CREVISION.Trim Then

                                lcRevision = loTempByte(i).CREVISION.Trim
                                If loTempByte(i + 1).CSEQUENCE.Trim = "002" Then
                                    lcNextRevision = Right("0000" + (CInt(lcRevision) + 1).ToString.Trim, 4)
                                Else
                                    lcNextRevision = loTempByte(i + 1).CREVISION
                                End If

                                Do While lcRevision <> lcNextRevision

                                    ' scan subdir for front main
                                    Dim loSubfolders As String() = GetAllFolders(lcFrontFilePath, False)

                                    'RDeploy
                                    For Each lcPath As String In loSubfolders
                                        ' Delete patch folder
                                        lcPatchPath = lcFrontFilePath + "\" + lcPath.Trim + "\ApplicationFiles\" + .CAPPS_CODE.Trim + "_" + Replace(.CVERSION.Trim, ".", "_") + "_" + lcRevision.Trim
                                        If Directory.Exists(lcPatchPath) Then
                                            Directory.Delete(lcPatchPath, True)
                                        End If

                                        ' Up version
                                        If Directory.Exists(lcFrontFilePath.Trim + "\" + lcPath.Trim + "\UpdateFiles") Then
                                            R_UpVersion.R_DoVersion(lcFrontFilePath.Trim + "\" + lcPath.Trim + "\UpdateFiles", lcPatchPath, .CVERSION.Trim + "." + lcRevision.Trim)

                                            ' create ZIP file
                                            lcPackagesFilePath2 = Path.Combine(lcPackagesFilePath, Replace(.CVERSION.Trim, ".", "_") + "_" + lcRevision.Trim, "Frontend")
                                            lcPackagesFileName = .CAPPS_CODE.Trim + "_" + Replace(.CVERSION.Trim, ".", "_") + "_F_" + lcRevision.Trim + "_" + lcPath.Trim + ".zip"
                                            If Not Directory.Exists(lcPackagesFilePath2) Then
                                                Directory.CreateDirectory(lcPackagesFilePath2)
                                            End If
                                            lcZipFilePath = Path.Combine(lcPackagesFilePath2, lcPackagesFileName)
                                            If File.Exists(lcZipFilePath) Then
                                                File.Delete(lcZipFilePath)
                                            End If
                                            DoZip(lcPatchPath,
                                              lcZipFilePath,
                                              .CAPPS_CODE.Trim + " Version " + .CVERSION.Trim + " Patch " + lcRevision + " - " + lcPath.Trim + " Frontend",
                                              .CAPPS_CODE.Trim + .CVERSION.Trim,
                                              .CAPPS_CODE.Trim + "_" + Replace(.CVERSION.Trim, ".", "_") + "_F_" + lcRevision.Trim + "_" + lcPath.Trim)
                                            loPackageFile = New RVT00100SerialFilesDTO
                                            loPackageFile.CFOLDER = lcPackagesFilePath2
                                            loPackageFile.CFILENAME = lcPackagesFileName
                                            loRtn.Add(loPackageFile)
                                        End If
                                    Next

                                    lcRevision = Right("0000" + (CInt(lcRevision) + 1).ToString.Trim, 4)
                                Loop
                            End If
                        End If
                        ' Get publisher folders
                        If loTempByte(i).CSEQUENCE = "002" Then
                            loPublishers.Add(loTempByte(i))
                        End If
                    Next

                    lcRevision = Right("0000" + (CInt(lcRevision) - 1).ToString.Trim, 4)
                    ' Publish and generate back CAB files
                    If loPublishers.Count > 0 Then
                        lcLogFilePath = C_RootPath.Trim & "\" & .CCOMPANY_ID.Trim & "\" & .CAPPS_CODE.Trim & "\STD\BuildLog.txt"
                        lcMSBuildPath = ConfigurationManager.AppSettings.GetValues("MSBuildPath")(0)
                    End If
                    For i = 0 To loPublishers.Count - 1
                        ' Publish
                        ' Cari file solution atau VBproject
                        lcBackendFilePath = C_RootPath.Trim & "\" & .CCOMPANY_ID.Trim & "\" & .CAPPS_CODE.Trim & "\STD\Backend\" & loPublishers(i).CSOURCE_ID
                        loFilenames.Clear()
                        loFilenames.AddRange(Directory.GetFiles(C_RootPath.Trim & loPublishers(i).CPATH, "*.vbproj", SearchOption.TopDirectoryOnly))

                        lcFilenames = loFilenames.ToArray
                        If lcFilenames.Count = 1 Then
                            R_MsBuild.Build(lcMSBuildPath, lcFilenames(0), lcLogFilePath, R_eAction.Publish, lcBackendFilePath)
                        End If
                        ' Generate Zip file
                        lcPackagesFilePath2 = Path.Combine(lcPackagesFilePath, Replace(.CVERSION.Trim, ".", "_") + "_" + lcRevision.Trim, "Backend")
                        lcPackagesFileName = .CAPPS_CODE.Trim + "_" + Replace(.CVERSION.Trim, ".", "_") + "_B_" + lcRevision.Trim + "_" + loPublishers(i).CSOURCE_ID.Trim + ".zip"
                        If Not Directory.Exists(lcPackagesFilePath2) Then
                            Directory.CreateDirectory(lcPackagesFilePath2)
                        End If
                        lcZipFilePath = Path.Combine(lcPackagesFilePath2, lcPackagesFileName)
                        If File.Exists(lcZipFilePath) Then
                            File.Delete(lcZipFilePath)
                        End If
                        DoZip(lcBackendFilePath,
                              lcZipFilePath,
                              .CAPPS_CODE.Trim + " Version " + .CVERSION.Trim + " - " + loPublishers(i).CSOURCE_ID.Trim + " Backend",
                              .CAPPS_CODE.Trim + .CVERSION.Trim,
                              .CAPPS_CODE.Trim + "_" + Replace(.CVERSION.Trim, ".", "_") + "_B_" + lcRevision.Trim + "_" + loPublishers(i).CSOURCE_ID.Trim)
                        loPackageFile = New RVT00100SerialFilesDTO
                        loPackageFile.CFOLDER = lcPackagesFilePath2
                        loPackageFile.CFILENAME = lcPackagesFileName
                        loRtn.Add(loPackageFile)
                    Next

                    ' Package Database Patch
                    If Directory.Exists(lcDBRevPath) Then
                        lcPackagesFilePath2 = Path.Combine(lcPackagesFilePath, Replace(.CVERSION.Trim, ".", "_") + "_" + lcRevision.Trim, "DB-Patch")
                        lcPackagesFileName = .CAPPS_CODE.Trim + "_" + Replace(.CVERSION.Trim, ".", "_") + "_D_" + lcRevision.Trim + ".zip"
                        If Not Directory.Exists(lcPackagesFilePath2) Then
                            Directory.CreateDirectory(lcPackagesFilePath2)
                        End If
                        lcZipFilePath = Path.Combine(lcPackagesFilePath2, lcPackagesFileName)
                        If File.Exists(lcZipFilePath) Then
                            File.Delete(lcZipFilePath)
                        End If
                        ZipOnly(lcDBRevPath,
                                        lcZipFilePath,
                                        .CAPPS_CODE.Trim + " Version " + .CVERSION.Trim + " Patch " + lcRevision + " - DB Script",
                                        .CAPPS_CODE.Trim + .CVERSION.Trim)
                        loPackageFile = New RVT00100SerialFilesDTO
                        loPackageFile.CFOLDER = lcPackagesFilePath2
                        loPackageFile.CFILENAME = lcPackagesFileName
                        loRtn.Add(loPackageFile)
                    End If

                    If ConfigurationManager.AppSettings.GetValues("SignToolOn")(0) = "True" Then
                        ' change to 2 to start queue process
                        loTriggerFileWriter = My.Computer.FileSystem.OpenTextFileWriter(lcTriggerFilename, False)
                        With loTriggerFileWriter
                            .Write("2")
                            .Close()
                        End With
                    End If

                    ' End of smart client file handling
                End If

            End With

        Catch ex As Exception
            loEx.Add(ex)
            If ConfigurationManager.AppSettings.GetValues("SignToolOn")(0) = "True" Then
                ' delete queue file
                If File.Exists("D:\RealCodeTools\SignTool\RealSignToolQueue.txt") Then
                    File.Delete("D:\RealCodeTools\SignTool\RealSignToolQueue.txt")
                End If
                ' reset trigger file if there is no other process
                If llProcessOK Then
                    loTriggerFileWriter = My.Computer.FileSystem.OpenTextFileWriter(lcTriggerFilename, False)
                    With loTriggerFileWriter
                        .Write("0")
                        .Close()
                    End With
                End If
            End If
        End Try

        If loEx.Haserror Then
            For Each loException In loEx.GetErrorList
                DebugText("Error on DumpFiles: " + loException.ErrDescp.Trim() + "(" + loException.ErrNo.Trim + ")")
                If loException.HasErrorDetail Then
                    For Each loExDt In loException.ErrorDetails
                        DebugText("  Detail: " + loExDt.ErrDescp.Trim() + "(" + loExDt.ErrNo.Trim + ")")
                    Next
                End If
            Next

        End If
        loEx.ThrowExceptionIfErrors()
        Return loRtn
    End Function

    Private Sub DoZip(ByVal pcSourceFolder As String, ByVal pcNewFileFullName As String, ByVal pcComment As String, ByVal pcFileID As String, ByVal pcCommandId As String)
        Dim loPSI As New ProcessStartInfo()
        Dim lcTriggerFilename As String
        Dim lcTriggerCode As String
        Dim lcCommandFilename As String
        Dim loCommandFileWriter As StreamWriter
        Dim lcCommandLine As String
        Dim loEx As New R_Exception
        Dim loTriggerFileWriter As StreamWriter
        Dim loTriggerFileStream As FileStream
        Dim loTriggerFileReader As StreamReader

        Try

            If ConfigurationManager.AppSettings.GetValues("SignToolOn")(0) = "True" Then
                lcTriggerFilename = "D:\RealCodeTools\SignTool\RealSignToolQueue.txt"
                'lcCommandFilename = "D:\RealCodeTools\SignTool\RealSignTool.cmd"
                lcCommandFilename = "D:\RealCodeTools\SignTool\" + pcCommandId.Trim + ".cmd"
                If Not File.Exists(lcCommandFilename) Then
                    File.Create(lcCommandFilename).Close()
                End If
                'cek file RealSignToolQueue.txt
                If Not File.Exists(lcTriggerFilename) Then
                    File.Create(lcTriggerFilename).Close()
                End If
                If File.Exists(lcTriggerFilename) Then
                    ' create command file
                    'DebugText("Sebelum set command line...")
                    lcCommandLine = "@echo off" + vbCrLf
                    lcCommandLine += "D:\RealCodeTools\SignTool\RealSignTool.exe " +
                        ConfigurationManager.AppSettings.GetValues("SignToolPath")(0) + " " +
                        pcSourceFolder.Trim + " " +
                        pcNewFileFullName.Trim + " " +
                        """" + pcComment.Trim + """ " +
                        pcFileID.Trim()
                    'DebugText("Command line: " + lcCommandLine.Trim)
                    loCommandFileWriter = My.Computer.FileSystem.OpenTextFileWriter(lcCommandFilename, False)
                    'DebugText("Sesudah set file writer untuk " + lcCommandFilename.Trim)
                    With loCommandFileWriter
                        .WriteLine(lcCommandLine)
                        .Close()
                    End With
                    'DebugText("Sesudah tulis file " + lcCommandFilename.Trim)

                    'lcTriggerCode = "1"
                    lcTriggerCode = lcCommandFilename + vbCrLf
                    loTriggerFileWriter = My.Computer.FileSystem.OpenTextFileWriter(lcTriggerFilename, True)
                    With loTriggerFileWriter
                        .Write(lcTriggerCode)
                        .Close()
                    End With
                End If
            Else
                ZipOnly(pcSourceFolder, pcNewFileFullName, pcComment, pcFileID)
            End If
        Catch ex As Exception
            DebugText("Error: " + ex.Message)
            loEx.Add(ex)
        End Try
        loEx.ThrowExceptionIfErrors()

    End Sub

    Private Sub ZipOnly(ByVal pcSourceFolder As String, ByVal pcNewFileFullName As String, ByVal pcComment As String, ByVal pcFileID As String)

        Dim loZip As New R_Zip
        Dim lcFileKey As String
        Dim lcPassword As String
        Dim loEx As New R_Exception

        Try

            lcFileKey = "R3@lt@P@$$w0rd"
            lcPassword = R_Utility.EncryptPbkdf2(pcFileID, lcFileKey)

            loZip.ZipWithPassword(pcSourceFolder, pcNewFileFullName, lcPassword, pcComment)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

    Private Function GetAllFolders(ByVal pcDirectory As String, plFullName As Boolean, Optional plRecursive As Boolean = False) As String()
        'Create object
        Dim loDirInfo As New IO.DirectoryInfo(pcDirectory)
        'Array to store paths
        Dim loPath() As String = {}
        'Loop through subfolders
        For Each subfolder As IO.DirectoryInfo In loDirInfo.GetDirectories()
            'Add this folders name
            Array.Resize(loPath, loPath.Length + 1)
            loPath(loPath.Length - 1) = IIf(plFullName, subfolder.FullName, subfolder.Name)
            'Recall function with each subdirectory, if recursive
            If plRecursive And plFullName Then
                For Each s As String In GetAllFolders(subfolder.FullName, True, True)
                    Array.Resize(loPath, loPath.Length + 1)
                    loPath(loPath.Length - 1) = s
                Next
            End If
        Next
        Return loPath
    End Function

    Private Sub DebugText(pcDebugLine As String)
        Dim loTextFileWriter As StreamWriter
        Dim loTextFileStream As FileStream
        Dim loTextFilename As String
        Dim lcTimeLabel As String

        loTextFilename = "D:\RealCode\Debug-" + Now.ToString("yyyyMMdd").Trim + ".log"
        If Not File.Exists(loTextFilename) Then
            File.Create(loTextFilename).Close()
        End If
        loTextFileWriter = My.Computer.FileSystem.OpenTextFileWriter(loTextFilename, True)
        With loTextFileWriter
            lcTimeLabel = Now.ToString.Trim + ": "
            .WriteLine(lcTimeLabel + pcDebugLine)
            .Close()
        End With
    End Sub

End Class
