﻿Imports R_Common
Imports R_BackEnd
Imports System.Data.Common
Imports ServerHelper.General

Public Class RVT00100LogCls
    Inherits R_BusinessObject(Of RVT00100LogDTO)

    Protected Overrides Sub R_Deleting(poEntity As RVT00100LogDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loResult As RVT00100LogDTO

        Try
            loConn = loDb.GetConnection()

            With poEntity
                ' validasi
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "RVT_APP_INCLUDES (NOLOCK) "
                lcQuery += "WHERE CINCL_COMPANY_ID = '{0}' "
                lcQuery += "AND CINCL_APPS_CODE = '{1}' "
                lcQuery += "AND CINCL_VERSION = '{2}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION)

                loResult = loDb.SqlExecObjectQuery(Of RVT00100LogDTO)(lcQuery, loConn, False).FirstOrDefault
                If loResult IsNot Nothing Then
                    Throw New Exception("Application " + .CAPPS_CODE.Trim + " version " + .CVERSION.Trim + " is used.")
                End If

                'delete main table
                lcQuery = "DELETE RVT_APP_VERSION_LOG "
                lcQuery += "WHERE "
                lcQuery += "CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery += "AND CAPP_UNIT = '{3}' "
                lcQuery += "AND CLOG_TYPE = '{4}' "
                lcQuery = String.Format(lcQuery,
                .CCOMPANY_ID,
                .CAPPS_CODE,
                .CVERSION,
                .CAPP_UNIT,
                .CLOG_TYPE)

                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As RVT00100LogDTO) As RVT00100LogDTO
        Dim lcQuery As String
        Dim loResult As RVT00100LogDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity

                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "RVT_APP_VERSION_LOG (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery += "AND CAPP_UNIT = '{3}' "
                lcQuery += "AND CLOG_TYPE = '{4}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CAPP_UNIT, .CLOG_TYPE)
            End With

            loResult = loDb.SqlExecObjectQuery(Of RVT00100LogDTO)(lcQuery).FirstOrDefault
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As RVT00100LogDTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As RVT00100LogDTO

        Try
            loConn = loDb.GetConnection()

            With poNewEntity

                If poCRUDMode = eCRUDMode.AddMode Then
                    lcQuery = "SELECT * "
                    lcQuery += "FROM "
                    lcQuery += "RVT_APP_VERSION_LOG (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CVERSION = '{2}' "
                    lcQuery += "AND CAPP_UNIT = '{3}' "
                    lcQuery += "AND CLOG_TYPE = '{4}' "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CAPP_UNIT, .CLOG_TYPE)

                    loResult = loDb.SqlExecObjectQuery(Of RVT00100LogDTO)(lcQuery, loConn, True).FirstOrDefault
                    If loResult IsNot Nothing Then
                        Throw New Exception("Log for object " + .CAPP_UNIT.Trim + " and log type " + .CLOG_TYPE.Trim + " is already exist")
                    End If

                    .CCREATE_BY = .CUPDATE_BY
                    .DUPDATE_DATE = Now
                    .DCREATE_DATE = Now

                    lcQuery = "INSERT INTO RVT_APP_VERSION_LOG ("
                    lcQuery += "CCOMPANY_ID, "
                    lcQuery += "CAPPS_CODE, "
                    lcQuery += "CVERSION, "
                    lcQuery += "CAPP_UNIT, "
                    lcQuery += "CLOG_TYPE, "
                    lcQuery += "CLOG_CONTENT, "
                    lcQuery += "CUPDATE_BY, "
                    lcQuery += "DUPDATE_DATE, "
                    lcQuery += "CCREATE_BY, "
                    lcQuery += "DCREATE_DATE) "
                    lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', {7}, '{8}', {9}) "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CVERSION,
                    .CAPP_UNIT,
                    .CLOG_TYPE,
                    .CLOG_CONTENT,
                    .CUPDATE_BY,
                    getDate(.DUPDATE_DATE),
                    .CCREATE_BY,
                    getDate(.DCREATE_DATE))

                    loDb.SqlExecNonQuery(lcQuery)

                ElseIf poCRUDMode = eCRUDMode.EditMode Then

                    lcQuery = "UPDATE RVT_APP_VERSION_LOG "
                    lcQuery += "SET "
                    lcQuery += "CLOG_CONTENT = '{5}', "
                    lcQuery += "CUPDATE_BY = '{6}', "
                    lcQuery += "DUPDATE_DATE = {7} "
                    lcQuery += "WHERE "
                    lcQuery += "CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CVERSION = '{2}' "
                    lcQuery += "AND CAPP_UNIT = '{3}' "
                    lcQuery += "AND CLOG_TYPE = '{4}' "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CVERSION,
                    .CAPP_UNIT,
                    .CLOG_TYPE,
                    .CLOG_CONTENT,
                    .CUPDATE_BY,
                    getDate(.DUPDATE_DATE))

                    loDb.SqlExecNonQuery(lcQuery, loConn, True)
                End If
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

    Public Function GetVersionLog(poTableKey As RVT00100LogGridDTO) As List(Of RVT00100LogGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RVT00100LogGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poTableKey

                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "RVT_APP_VERSION_LOG (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                If .CAPP_UNIT IsNot Nothing Then
                    If Not .CAPP_UNIT.Trim.Equals("") Then
                        lcQuery += "AND CAPP_UNIT = '{3}' "
                    End If
                End If
                If .CLOG_TYPE IsNot Nothing Then
                    If Not .CLOG_TYPE.Trim.Equals("") Then
                        lcQuery += "AND CLOG_TYPE = '{4}' "
                    End If
                End If
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CAPP_UNIT, .CLOG_TYPE)
            End With

            loResult = loDb.SqlExecObjectQuery(Of RVT00100LogGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetLogTypeCombo() As List(Of RVT00100LogTypeComboDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RVT00100LogTypeComboDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "RVM_LOG_TYPE (NOLOCK) "
            lcQuery = String.Format(lcQuery)

            loResult = loDb.SqlExecObjectQuery(Of RVT00100LogTypeComboDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetAppUnitCombo(poKey As RVT00100AppKeyDTO) As List(Of RVT00100AppUnitComboDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RVT00100AppUnitComboDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "RVM_APP_UNIT (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery += "AND CAPPS_CODE = '{1}' "
            With poKey
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE)
            End With

            loResult = loDb.SqlExecObjectQuery(Of RVT00100AppUnitComboDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function


End Class
