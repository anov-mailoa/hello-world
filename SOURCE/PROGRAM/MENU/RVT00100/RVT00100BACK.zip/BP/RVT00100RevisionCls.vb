﻿Imports System.Data.Common
Imports R_BackEnd
Imports R_Common
Imports RVT00100Back

Public Class RVT00100RevisionCls
    Inherits R_BusinessObject(Of RVT00100RevisionDTO)

    Protected Overrides Sub R_Saving(poNewEntity As RVT00100RevisionDTO, poCRUDMode As eCRUDMode)
        ' Update only
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As RVT00100RevisionDTO

        Try
            loConn = loDb.GetConnection()

            With poNewEntity

                If poCRUDMode = eCRUDMode.EditMode Then
                    lcQuery = "UPDATE RVT_APP_REVISION "
                    lcQuery += "SET "
                    lcQuery += "CNOTE = '{4}', "
                    lcQuery += "CUPDATE_BY = '{5}', "
                    lcQuery += "DUPDATE_DATE = GETDATE() "
                    lcQuery += "WHERE "
                    lcQuery += "CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CVERSION = '{2}' "
                    lcQuery += "AND CREVISION = '{3}' "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CVERSION,
                    .CREVISION,
                    .CNOTE,
                    .CUPDATE_BY)

                    loDb.SqlExecNonQuery(lcQuery, loConn, True)
                End If
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Sub R_Deleting(poEntity As RVT00100RevisionDTO)
        Throw New NotImplementedException()
    End Sub

    Public Function GetRevisions(poTableKey As RVT00100RevisionGridDTO) As List(Of RVT00100RevisionGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RVT00100RevisionGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poTableKey

                lcQuery = "SELECT "
                lcQuery += "CONVERT(datetime,CRELEASE_DATE,112) AS DRELEASE_DATE, "
                lcQuery += "* "
                lcQuery += "FROM "
                lcQuery += "RVT_APP_REVISION (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION)
            End With

            loResult = loDb.SqlExecObjectQuery(Of RVT00100RevisionGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult

    End Function

    Protected Overrides Function R_Display(poEntity As RVT00100RevisionDTO) As RVT00100RevisionDTO
        Dim lcQuery As String
        Dim loResult As RVT00100RevisionDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "RVT_APP_REVISION (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery += "AND CAPPS_CODE = '{1}' "
            lcQuery += "AND CVERSION = '{2}' "
            lcQuery += "AND CREVISION = '{3}' "
            lcQuery = String.Format(lcQuery, poEntity.CCOMPANY_ID, poEntity.CAPPS_CODE, poEntity.CVERSION, poEntity.CREVISION)

            loResult = loDb.SqlExecObjectQuery(Of RVT00100RevisionDTO)(lcQuery).FirstOrDefault
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function
End Class
