﻿Imports R_Common
Imports RVT00100FrontResources

Public Class ErrorHandler
    Public Shared Function ConvertError(poEx As R_Exception) As R_Exception
        Dim lcErrNo As String
        Dim lcErrDescp As String
        Dim loEx As New R_Exception

        For Each loError As R_Error In poEx.ErrorList
            lcErrNo = loError.ErrDescp.Trim
            lcErrDescp = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErrNo)
            loEx.Add(lcErrNo, lcErrDescp)
        Next

        Return loEx
    End Function
End Class
