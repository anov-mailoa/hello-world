﻿Public Class RVT00100ParameterGroupComboDTO
    Public Property CPARAMETER_GROUP As String
End Class
