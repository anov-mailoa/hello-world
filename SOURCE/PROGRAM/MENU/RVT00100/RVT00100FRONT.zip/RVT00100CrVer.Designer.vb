﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RVT00100CrVer
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.rdbMajor = New R_FrontEnd.R_RadRadioButton(Me.components)
        Me.rdbMinor = New R_FrontEnd.R_RadRadioButton(Me.components)
        Me.lblIncrement = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblAlias = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblCodeName = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtAlias = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtCodeName = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.btnCreate = New R_FrontEnd.R_RadButton(Me.components)
        Me.txtApplication = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.rdbSkip = New R_FrontEnd.R_RadRadioButton(Me.components)
        Me.spnMajor = New R_FrontEnd.R_RadSpinEditor(Me.components)
        Me.spnMinor = New R_FrontEnd.R_RadSpinEditor(Me.components)
        Me.rdbSPack = New R_FrontEnd.R_RadRadioButton(Me.components)
        Me.txtNote = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblNote = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtVersion = New R_FrontEnd.R_RadTextBox(Me.components)
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.rdbMajor, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.rdbMinor, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblIncrement, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblAlias, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCodeName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtAlias, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtCodeName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnCreate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.rdbSkip, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spnMajor, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spnMinor, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.rdbSPack, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtNote, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblNote, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(12, 12)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 0
        Me.lblApplication.Text = "Application..."
        '
        'rdbMajor
        '
        Me.rdbMajor.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.rdbMajor.Location = New System.Drawing.Point(118, 61)
        Me.rdbMajor.Name = "rdbMajor"
        Me.rdbMajor.R_ConductorGridSource = Nothing
        Me.rdbMajor.R_ConductorSource = Nothing
        Me.rdbMajor.R_ResourceId = "rdbMajor"
        Me.rdbMajor.Size = New System.Drawing.Size(122, 18)
        Me.rdbMajor.TabIndex = 3
        Me.rdbMajor.Text = "R_RadRadioButton1"
        '
        'rdbMinor
        '
        Me.rdbMinor.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.rdbMinor.Location = New System.Drawing.Point(118, 85)
        Me.rdbMinor.Name = "rdbMinor"
        Me.rdbMinor.R_ConductorGridSource = Nothing
        Me.rdbMinor.R_ConductorSource = Nothing
        Me.rdbMinor.R_ResourceId = "rdbMinor"
        Me.rdbMinor.Size = New System.Drawing.Size(122, 18)
        Me.rdbMinor.TabIndex = 4
        Me.rdbMinor.Text = "R_RadRadioButton2"
        '
        'lblIncrement
        '
        Me.lblIncrement.AutoSize = False
        Me.lblIncrement.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblIncrement.Location = New System.Drawing.Point(12, 38)
        Me.lblIncrement.Name = "lblIncrement"
        Me.lblIncrement.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblIncrement.R_ResourceId = "lblIncrement"
        Me.lblIncrement.Size = New System.Drawing.Size(100, 18)
        Me.lblIncrement.TabIndex = 11
        Me.lblIncrement.Text = "Application..."
        '
        'lblAlias
        '
        Me.lblAlias.AutoSize = False
        Me.lblAlias.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblAlias.Location = New System.Drawing.Point(12, 134)
        Me.lblAlias.Name = "lblAlias"
        Me.lblAlias.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblAlias.R_ResourceId = "lblAlias"
        Me.lblAlias.Size = New System.Drawing.Size(100, 18)
        Me.lblAlias.TabIndex = 14
        Me.lblAlias.Text = "Application..."
        '
        'lblCodeName
        '
        Me.lblCodeName.AutoSize = False
        Me.lblCodeName.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCodeName.Location = New System.Drawing.Point(12, 160)
        Me.lblCodeName.Name = "lblCodeName"
        Me.lblCodeName.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCodeName.R_ResourceId = "lblCodeName"
        Me.lblCodeName.Size = New System.Drawing.Size(100, 18)
        Me.lblCodeName.TabIndex = 15
        Me.lblCodeName.Text = "Application..."
        '
        'txtAlias
        '
        Me.txtAlias.Location = New System.Drawing.Point(118, 133)
        Me.txtAlias.Name = "txtAlias"
        Me.txtAlias.R_ConductorGridSource = Nothing
        Me.txtAlias.R_ConductorSource = Nothing
        Me.txtAlias.R_UDT = Nothing
        Me.txtAlias.Size = New System.Drawing.Size(400, 20)
        Me.txtAlias.TabIndex = 6
        '
        'txtCodeName
        '
        Me.txtCodeName.Location = New System.Drawing.Point(118, 159)
        Me.txtCodeName.Name = "txtCodeName"
        Me.txtCodeName.R_ConductorGridSource = Nothing
        Me.txtCodeName.R_ConductorSource = Nothing
        Me.txtCodeName.R_UDT = Nothing
        Me.txtCodeName.Size = New System.Drawing.Size(400, 20)
        Me.txtCodeName.TabIndex = 7
        '
        'btnCreate
        '
        Me.btnCreate.Location = New System.Drawing.Point(408, 263)
        Me.btnCreate.Name = "btnCreate"
        Me.btnCreate.R_ConductorGridSource = Nothing
        Me.btnCreate.R_ConductorSource = Nothing
        Me.btnCreate.R_DescriptionId = Nothing
        Me.btnCreate.R_ResourceId = "btnCreate"
        Me.btnCreate.Size = New System.Drawing.Size(110, 24)
        Me.btnCreate.TabIndex = 9
        Me.btnCreate.Text = "R_RadButton1"
        '
        'txtApplication
        '
        Me.txtApplication.Location = New System.Drawing.Point(118, 11)
        Me.txtApplication.Name = "txtApplication"
        Me.txtApplication.R_ConductorGridSource = Nothing
        Me.txtApplication.R_ConductorSource = Nothing
        Me.txtApplication.R_UDT = Nothing
        Me.txtApplication.ReadOnly = True
        Me.txtApplication.Size = New System.Drawing.Size(400, 20)
        Me.txtApplication.TabIndex = 6
        Me.txtApplication.TabStop = False
        '
        'bsApps
        '
        Me.bsApps.DataSource = GetType(RVT00100Front.RVT00100ServiceRef.RLicenseAppComboDTO)
        '
        'rdbSkip
        '
        Me.rdbSkip.CheckState = System.Windows.Forms.CheckState.Checked
        Me.rdbSkip.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.rdbSkip.Location = New System.Drawing.Point(118, 37)
        Me.rdbSkip.Name = "rdbSkip"
        Me.rdbSkip.R_ConductorGridSource = Nothing
        Me.rdbSkip.R_ConductorSource = Nothing
        Me.rdbSkip.R_ResourceId = "rdbSkip"
        Me.rdbSkip.Size = New System.Drawing.Size(122, 18)
        Me.rdbSkip.TabIndex = 0
        Me.rdbSkip.Text = "R_RadRadioButton2"
        Me.rdbSkip.ToggleState = Telerik.WinControls.Enumerations.ToggleState.[On]
        '
        'spnMajor
        '
        Me.spnMajor.Location = New System.Drawing.Point(271, 37)
        Me.spnMajor.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.spnMajor.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.spnMajor.Name = "spnMajor"
        Me.spnMajor.R_ConductorGridSource = Nothing
        Me.spnMajor.R_ConductorSource = Nothing
        Me.spnMajor.Size = New System.Drawing.Size(37, 20)
        Me.spnMajor.TabIndex = 1
        Me.spnMajor.TabStop = False
        Me.spnMajor.TextAlignment = System.Windows.Forms.HorizontalAlignment.Right
        Me.spnMajor.ThousandsSeparator = True
        Me.spnMajor.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'spnMinor
        '
        Me.spnMinor.Location = New System.Drawing.Point(314, 37)
        Me.spnMinor.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.spnMinor.Name = "spnMinor"
        Me.spnMinor.R_ConductorGridSource = Nothing
        Me.spnMinor.R_ConductorSource = Nothing
        Me.spnMinor.Size = New System.Drawing.Size(37, 20)
        Me.spnMinor.TabIndex = 2
        Me.spnMinor.TabStop = False
        Me.spnMinor.TextAlignment = System.Windows.Forms.HorizontalAlignment.Right
        Me.spnMinor.ThousandsSeparator = True
        '
        'rdbSPack
        '
        Me.rdbSPack.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.rdbSPack.Location = New System.Drawing.Point(118, 109)
        Me.rdbSPack.Name = "rdbSPack"
        Me.rdbSPack.R_ConductorGridSource = Nothing
        Me.rdbSPack.R_ConductorSource = Nothing
        Me.rdbSPack.R_ResourceId = "rdbSPack"
        Me.rdbSPack.Size = New System.Drawing.Size(122, 18)
        Me.rdbSPack.TabIndex = 5
        Me.rdbSPack.Text = "R_RadRadioButton2"
        '
        'txtNote
        '
        Me.txtNote.AcceptsReturn = True
        Me.txtNote.AutoSize = False
        Me.txtNote.Location = New System.Drawing.Point(118, 185)
        Me.txtNote.Multiline = True
        Me.txtNote.Name = "txtNote"
        Me.txtNote.R_ConductorGridSource = Nothing
        Me.txtNote.R_ConductorSource = Nothing
        Me.txtNote.R_UDT = Nothing
        Me.txtNote.Size = New System.Drawing.Size(400, 72)
        Me.txtNote.TabIndex = 8
        '
        'lblNote
        '
        Me.lblNote.AutoSize = False
        Me.lblNote.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblNote.Location = New System.Drawing.Point(12, 186)
        Me.lblNote.Name = "lblNote"
        Me.lblNote.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblNote.R_ResourceId = "lblNote"
        Me.lblNote.Size = New System.Drawing.Size(100, 18)
        Me.lblNote.TabIndex = 23
        Me.lblNote.Text = "Application..."
        '
        'txtVersion
        '
        Me.txtVersion.Location = New System.Drawing.Point(271, 108)
        Me.txtVersion.Name = "txtVersion"
        Me.txtVersion.R_ConductorGridSource = Nothing
        Me.txtVersion.R_ConductorSource = Nothing
        Me.txtVersion.R_UDT = Nothing
        Me.txtVersion.ReadOnly = True
        Me.txtVersion.Size = New System.Drawing.Size(80, 20)
        Me.txtVersion.TabIndex = 25
        Me.txtVersion.TabStop = False
        '
        'RVT00100CrVer
        '
        Me.ClientSize = New System.Drawing.Size(530, 296)
        Me.Controls.Add(Me.txtVersion)
        Me.Controls.Add(Me.txtNote)
        Me.Controls.Add(Me.lblNote)
        Me.Controls.Add(Me.rdbSPack)
        Me.Controls.Add(Me.spnMinor)
        Me.Controls.Add(Me.spnMajor)
        Me.Controls.Add(Me.rdbSkip)
        Me.Controls.Add(Me.txtApplication)
        Me.Controls.Add(Me.btnCreate)
        Me.Controls.Add(Me.txtCodeName)
        Me.Controls.Add(Me.txtAlias)
        Me.Controls.Add(Me.lblCodeName)
        Me.Controls.Add(Me.lblAlias)
        Me.Controls.Add(Me.lblIncrement)
        Me.Controls.Add(Me.rdbMinor)
        Me.Controls.Add(Me.rdbMajor)
        Me.Controls.Add(Me.lblApplication)
        Me.Name = "RVT00100CrVer"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.rdbMajor, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.rdbMinor, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblIncrement, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblAlias, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCodeName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtAlias, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtCodeName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnCreate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.rdbSkip, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spnMajor, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spnMinor, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.rdbSPack, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtNote, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblNote, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents rdbMajor As R_FrontEnd.R_RadRadioButton
    Friend WithEvents rdbMinor As R_FrontEnd.R_RadRadioButton
    Friend WithEvents lblIncrement As R_FrontEnd.R_RadLabel
    Friend WithEvents lblAlias As R_FrontEnd.R_RadLabel
    Friend WithEvents lblCodeName As R_FrontEnd.R_RadLabel
    Friend WithEvents txtAlias As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtCodeName As R_FrontEnd.R_RadTextBox
    Friend WithEvents btnCreate As R_FrontEnd.R_RadButton
    Friend WithEvents txtApplication As R_FrontEnd.R_RadTextBox
    Friend WithEvents rdbSkip As R_FrontEnd.R_RadRadioButton
    Friend WithEvents spnMajor As R_FrontEnd.R_RadSpinEditor
    Friend WithEvents spnMinor As R_FrontEnd.R_RadSpinEditor
    Friend WithEvents rdbSPack As R_FrontEnd.R_RadRadioButton
    Friend WithEvents txtNote As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblNote As R_FrontEnd.R_RadLabel
    Friend WithEvents txtVersion As R_FrontEnd.R_RadTextBox
End Class
