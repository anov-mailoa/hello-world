﻿Imports RVT00100FrontResources
Imports R_Common
Imports RVT00100Front.RVT00100ServiceRef
Imports RVT00100Front.RVT00100StreamingServiceRef
Imports R_FrontEnd
Imports ClientHelper
Imports System.ServiceModel.Channels
Imports System.ServiceModel
Imports RCustDBFileCommon
Imports RVT00100Front.RVT00100RevisionServiceRef
Imports Telerik.WinControls.UI

Public Class RVT00100

#Region " VARIABLE "
    Dim C_ServiceName As String = "RVT00100Service/RVT00100Service.svc"
    Dim C_ServiceNameStream As String = "RVT00100Service/RVT00100StreamingService.svc"
    Dim C_RevisionServiceName As String = "RVT00100Service/RVT00100RevisionService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPS_CODE As String
    Dim _CVERSION As String
    Dim _CMAJOR As String
    Dim _CMINOR As String
    Dim _CREVISION As String
    Dim llInitialized As Boolean = False
    Dim loFilterParam As New RVT00100ParamDTO
    Dim _IROW_INDEX As Integer

#End Region

#Region " S U B  &  F U N C T I O N "

    Private Sub RefreshGrids()
        Dim loTableKey As New RVT00100GridDTO

        With loTableKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = cboApplication.SelectedValue.Trim
        End With

        With gvAppVer
            _IROW_INDEX = 0
            If .CurrentRow IsNot Nothing Then
                _IROW_INDEX = .CurrentRow.Index
            End If
            .R_RefreshGrid(loTableKey)
            If .RowCount > 0 Then
                bsGvAppVer.Position = _IROW_INDEX
            End If
        End With
    End Sub

    Private Sub PackageStatus(poFileList As List(Of RVT00100SerialFilesDTO))
        Dim loSvc As R_ProcessAndUploadClient
        Dim loBatchPar As R_BatchParameter
        Dim lcKeyGuid As String
        Dim loEx As New R_Exception
        Dim loUserParameters As New List(Of R_KeyValue)
        Dim loUserPar As R_KeyValue
        Dim loObject As List(Of RCustDBFileProcessKeyDTO)

        Try
            ' disable buttons
            btnCreate.Enabled = False
            btnSetting.Enabled = False
            btnRelease.Enabled = False
            btnRerelease.Enabled = False
            ' show progress bar
            lblPackageStatus.Text = "Processing..."
            pbPackageStatus.Visible = True
            loUserPar = New R_KeyValue
            With loUserPar
                .Key = "COUNT"
                .Value = poFileList.Count
            End With
            loUserParameters.Add(loUserPar)
            ' copy file list to serial object
            loObject = New List(Of RCustDBFileProcessKeyDTO)
            For Each loRow As RVT00100SerialFilesDTO In poFileList
                loObject.Add(New RCustDBFileProcessKeyDTO() With {.CFILE_GROUP = loRow._CFOLDER, .CFILE_NAME = loRow._CFILENAME})
            Next
            loUserPar = New R_KeyValue
            With loUserPar
                .Key = "LIST"
                .Value = R_Utility.Serialize(loObject)
            End With
            loUserParameters.Add(loUserPar)

            'Instantiate FrontHelper
            loSvc = New R_ProcessAndUploadClient(bwPackageStatus, pbPackageStatus, lblPackageStatus)
            AddHandler loSvc.ProcessError, AddressOf PackageProcessError
            AddHandler loSvc.ProcessComplete, AddressOf PackageProcessComplete

            'prepare Batch Parameter
            With loBatchPar
                .COMPANY_ID = _CCOMPID
                .USER_ID = _CUSERID
                '.ClassName = "SAB02400Back.Class1"
                .ClassName = "RVT00100Back.RVT00100ProgressCls"
                .BigObject = Nothing
                .UserParameters = loUserParameters
            End With

            lcKeyGuid = loSvc.R_BatchProcess(loBatchPar, poFileList.Count)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

    Private Sub PackageProcessComplete(pcKeyGuid As String, poProcessResultMode As eProcessResultMode)
        Dim loEx As New R_Exception

        Try
            Select Case poProcessResultMode
                Case eProcessResultMode.Success
                    R_RadMessageBox.Show(R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_ProcessComplete"), Windows.Forms.MessageBoxButtons.OK)
                Case eProcessResultMode.Fail
                    Dim loRtn As List(Of R_ErrorStatusReturn)
                    Dim loHelp As New R_ProcessAndUploadClient(bwPackageStatus, Nothing, Nothing)
                    Dim loPar As R_UploadAndProcessKey

                    Try
                        With loPar
                            .COMPANY_ID = _CCOMPID
                            .USER_ID = _CUSERID
                            .KEY_GUID = pcKeyGuid
                        End With

                        loRtn = loHelp.R_GetErrorProcess(loPar)

                        For Each loError As R_ErrorStatusReturn In loRtn
                            loEx.Add(loError.SeqNo.ToString, loError.ErrorMessage)
                        Next
                    Catch ex As Exception
                        loEx.Add(ex)
                    End Try

                    If loEx.Haserror Then
                        loEx.ThrowExceptionIfErrors()
                    End If
            End Select
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            ' enable buttons
            btnCreate.Enabled = True
            btnSetting.Enabled = True
            btnRelease.Enabled = True
            btnRerelease.Enabled = True
            ' reset progress bar
            lblPackageStatus.Text = ""
            pbPackageStatus.Visible = False
        End Try

        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If
    End Sub

    Private Sub PackageProcessError(pcKeyGuid As String, ex As R_Exception)
        Dim loException As New R_Exception
        If ex.Haserror Then
            For Each loError As R_Error In ex.ErrorList
                loException.Add(loError)
            Next
        End If

        If loException.Haserror Then
            Me.R_DisplayException(loException)
            ' enable buttons
            btnCreate.Enabled = True
            btnSetting.Enabled = True
            btnRelease.Enabled = True
            btnRerelease.Enabled = True
            ' reset progress bar
            lblPackageStatus.Text = ""
            pbPackageStatus.Visible = False
        End If
    End Sub

#End Region

#Region " F O R M "

    Private Sub RVT00100_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loSvc As RVT00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100Service, RVT00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loAppCombo As New List(Of RLicenseAppComboDTO)

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            ' Application
            loAppCombo = loSvc.GetAppCombo(_CCOMPID, _CUSERID, "A")
            bsApps.DataSource = loAppCombo

            llInitialized = True
            RefreshGrids()

            ' Predefined dock
            Me.R_Components = Me.components
            'preRevision.R_HeaderTitle = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "RVT00100RevisionTitle")
            preLog.R_HeaderTitle = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "RVT00100LogTitle")
            preInclude.R_HeaderTitle = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "RVT00100IncludeTitle")

            ' Hide progress bar
            lblPackageStatus.Text = ""
            pbPackageStatus.Visible = False

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub RVT00100_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

    Private Sub RVT00100_R_Return_From_Detail(poOwnedForm As R_FrontEnd.R_FormBase, pcButtonName As String) Handles Me.R_Return_From_Detail
        RefreshGrids()
    End Sub

#End Region

#Region " G R I D V I E W "

    Private Sub gvAppVer_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvAppVer.R_Display
        With CType(poEntity, RVT00100DTO)
            _CAPPS_CODE = ._CAPPS_CODE
            _CVERSION = ._CVERSION
            _CMAJOR = ._CMAJOR
            _CMINOR = ._CMINOR
            txtAlias.Text = ._CALIAS
            txtCodeName.Text = ._CCODE_NAME
            txtNote.Text = ._CNOTE
        End With

        Dim loTableKey As New RVT00100Front.RVT00100StreamingServiceRef.RVT00100RevisionGridDTO
        With loTableKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = _CAPPS_CODE
            .CVERSION = _CVERSION
        End With
        txtRevNote.Text = ""
        gvRevisions.R_RefreshGrid(loTableKey)
    End Sub

    Private Sub gvAppVer_R_ServiceDelete(poEntity As Object) Handles gvAppVer.R_ServiceDelete
        Dim loService As RVT00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100Service, RVT00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            With CType(poEntity, RVT00100DTO)
                ._CCOMPANY_ID = _CCOMPID
            End With

            loService.Svc_R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvAppVer_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvAppVer.R_ServiceGetListRecord
        Dim loServiceStream As RVT00100StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100StreamingService, RVT00100StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of RVT00100GridDTO)
        Dim loListEntity As New List(Of RVT00100DTO)

        Try
            With poEntity
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
            End With

            loRtn = loServiceStream.GetVersions()
            loStreaming = R_StreamUtility(Of RVT00100GridDTO).ReadFromMessage(loRtn)

            For Each loDto As RVT00100GridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New RVT00100DTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                           ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                           ._CVERSION = loDto.CVERSION,
                                                           ._CMAJOR = loDto.CMAJOR,
                                                           ._CMINOR = loDto.CMINOR,
                                                           ._CALIAS = loDto.CALIAS,
                                                           ._CCODE_NAME = loDto.CCODE_NAME,
                                                           ._CSTATUS = loDto.CSTATUS,
                                                           ._DOPEN_DATE = loDto.DOPEN_DATE,
                                                           ._COPEN_BY = loDto.COPEN_BY,
                                                           ._DRELEASE_DATE = loDto.DRELEASE_DATE,
                                                           ._CRELEASE_BY = loDto.CRELEASE_BY,
                                                           ._CCREATE_BY = loDto.CCREATE_BY,
                                                           ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                           ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                           ._DUPDATE_DATE = loDto.DUPDATE_DATE,
                                                           ._CLAST_REVISION = loDto.CLAST_REVISION,
                                                           ._CLAST_REVISION_BY = loDto.CLAST_REVISION_BY,
                                                           ._DLAST_REVISION_DATE = loDto.DLAST_REVISION_DATE,
                                                           ._CNOTE = loDto.CNOTE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvAppVer_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvAppVer.R_ServiceGetRecord
        Dim loService As RVT00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100Service, RVT00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New RVT00100DTO With {._CCOMPANY_ID = _CCOMPID,
                                                                             ._CAPPS_CODE = cboApplication.SelectedValue.Trim,
                                                                             ._CVERSION = CType(bsGvAppVer.Current, RVT00100DTO)._CVERSION})
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loService.Close()
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvRevisions_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvRevisions.R_ServiceGetListRecord
        Dim loServiceStream As RVT00100StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100StreamingService, RVT00100StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of RVT00100RevisionGridDTO)
        Dim loListEntity As New List(Of RVT00100RevisionDTO)

        Try
            With poEntity
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
            End With

            loRtn = loServiceStream.GetRevisions()
            loStreaming = R_StreamUtility(Of RVT00100RevisionGridDTO).ReadFromMessage(loRtn)

            For Each loDto As RVT00100RevisionGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New RVT00100RevisionDTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                           ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                           ._CVERSION = loDto.CVERSION,
                                                           ._CREVISION = loDto.CREVISION,
                                                           ._DRELEASE_DATE = loDto.DRELEASE_DATE,
                                                           ._CRELEASE_BY = loDto.CRELEASE_BY,
                                                           ._CCREATE_BY = loDto.CCREATE_BY,
                                                           ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                           ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                           ._DUPDATE_DATE = loDto.DUPDATE_DATE,
                                                           ._CNOTE = loDto.CNOTE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvRevisions_R_Display(poEntity As Object, poGridCellCollection As GridViewCellInfoCollection, peGridMode As R_eGridMode) Handles gvRevisions.R_Display
        With CType(poEntity, RVT00100RevisionDTO)
            _CAPPS_CODE = ._CAPPS_CODE
            _CVERSION = ._CVERSION
            _CREVISION = ._CREVISION
            txtRevNote.Text = ._CNOTE
        End With
    End Sub

    Private Sub gvRevisions_DataBindingComplete(sender As Object, e As GridViewBindingCompleteEventArgs) Handles gvRevisions.DataBindingComplete
        gvRevisions.BestFitColumns()
    End Sub

    Private Sub gvAppVer_DataBindingComplete(sender As Object, e As GridViewBindingCompleteEventArgs) Handles gvAppVer.DataBindingComplete
        gvAppVer.BestFitColumns()
    End Sub

#End Region

#Region " B U T T O N S "

    Private Sub R_Detail1_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnCreate.R_Before_Open_Form
        Dim loEx As New R_Exception
        poTargetForm = New RVT00100CrVer
        poParameter = New RVT00100ParamDTO

        Try
            With CType(poTargetForm, RVT00100CrVer)
                .Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "btnCreate")
            End With
            With CType(poParameter, RVT00100ParamDTO)
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = cboApplication.SelectedValue.Trim
                .CAPPS_NAME = cboApplication.Text.Trim
                .CVERSION = _CVERSION
                .CMAJOR = _CMAJOR
                .CMINOR = _CMINOR
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub btnRelease_Click(sender As System.Object, e As System.EventArgs) Handles btnRelease.Click
        Dim loEx As New R_Exception
        Dim loSvc As RVT00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100Service, RVT00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loLicense As RVT00100ReleaseDTO
        Dim lcRtn As String
        Dim loRtn As List(Of RVT00100SerialFilesDTO)

        Try
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor

            ' Process
            If bsGvAppVer.Count > 0 Then
                loLicense = New RVT00100ReleaseDTO
                With loLicense
                    .CCOMPANY_ID = _CCOMPID
                    .CAPPS_CODE = cboApplication.SelectedValue.Trim
                    .CVERSION = CType(bsGvAppVer.Current, RVT00100DTO)._CVERSION
                    .CUSER_ID = _CUSERID
                    .LRECOVER_VERSION = chkRecoverVersion.Checked ' this checkbox is currently not used and hidden
                End With
                loRtn = loSvc.ReleaseVersion(loLicense)
                'If Not lcRtn.Equals("OK") Then
                '    loEx.Add(lcRtn, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcRtn))
                '    Exit Try
                'End If
                RefreshGrids()
                PackageStatus(loRtn)
            End If

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        End Try
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        If loEx.Haserror Then
            R_DisplayException(ErrorHandler.ConvertError(loEx))
        End If
    End Sub

    Private Sub btnSetting_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnSetting.R_Before_Open_Form
        Dim loEx As New R_Exception
        poTargetForm = New RVT00100AppParam002
        poParameter = New RVT00100ParamDTO

        Try
            With CType(poTargetForm, RVT00100AppParam002)
                .Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "btnSetting")
            End With
            With CType(poParameter, RVT00100ParamDTO)
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = cboApplication.SelectedValue.Trim
                .CAPPS_NAME = cboApplication.Text.Trim
                .CVERSION = _CVERSION
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub btnRerelease_Click(sender As System.Object, e As System.EventArgs) Handles btnRerelease.Click
        Dim loEx As New R_Exception
        Dim loSvc As RVT00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100Service, RVT00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loLicense As RVT00100ReleaseDTO
        Dim lcRtn As String
        Dim loRtn As List(Of RVT00100SerialFilesDTO)

        Try
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor

            ' Process
            If bsGvAppVer.Count > 0 Then
                loLicense = New RVT00100ReleaseDTO
                With loLicense
                    .CCOMPANY_ID = _CCOMPID
                    .CAPPS_CODE = cboApplication.SelectedValue.Trim
                    .CVERSION = CType(bsGvAppVer.Current, RVT00100DTO)._CVERSION
                    .CUSER_ID = _CUSERID
                    .LRECOVER_VERSION = chkRecoverVersion.Checked ' this checkbox is currently not used and hidden
                End With
                loRtn = loSvc.DumpFiles(loLicense)
                PackageStatus(loRtn)
                'If Not lcRtn.Equals("OK") Then
                '    loEx.Add(lcRtn, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcRtn))
                '    Exit Try
                'End If
            End If

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        End Try
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default

        If loEx.Haserror Then
            R_DisplayException(ErrorHandler.ConvertError(loEx))
            'Else
            '    MsgBox("Process Complete", , Me.R_HeaderTitle)
        End If
    End Sub

    Private Sub btnVersionNote_Click(sender As Object, e As EventArgs) Handles btnSaveVersion.Click
        Dim loService As RVT00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100Service, RVT00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim loEntity As New RVT00100DTO

        Try
            With loEntity
                ._CCOMPANY_ID = _CCOMPID
                ._CAPPS_CODE = _CAPPS_CODE
                ._CVERSION = _CVERSION
                ._CALIAS = txtAlias.Text
                ._CCODE_NAME = txtCodeName.Text
                ._CNOTE = txtNote.Text
                ._CUPDATE_BY = _CUSERID
            End With

            loService.Svc_R_Save(loEntity, R_eGridMode.Edit)
            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub btnRevisionNote_Click(sender As Object, e As EventArgs) Handles btnSaveRevision.Click
        Dim loService As RVT00100RevisionServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100RevisionService, RVT00100RevisionServiceClient)(e_ServiceClientType.RegularService, C_RevisionServiceName)
        Dim loEx As New R_Exception
        Dim loEntity As New RVT00100RevisionDTO
        Dim loTableKey As New RVT00100RevisionGridDTO

        Try
            With loEntity
                ._CCOMPANY_ID = _CCOMPID
                ._CAPPS_CODE = _CAPPS_CODE
                ._CVERSION = _CVERSION
                ._CREVISION = _CREVISION
                ._CNOTE = txtRevNote.Text
                ._CUPDATE_BY = _CUSERID
            End With

            loService.Svc_R_Save(loEntity, R_eGridMode.Edit)
            With loTableKey
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = _CAPPS_CODE
                .CVERSION = _CVERSION
            End With

            With gvRevisions
                _IROW_INDEX = 0
                If .CurrentRow IsNot Nothing Then
                    _IROW_INDEX = .CurrentRow.Index
                End If
                .R_RefreshGrid(loTableKey)
                If .RowCount > 0 Then
                    bsGvRevision.Position = _IROW_INDEX
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Dim loEx As New R_Exception
        Dim loSvc As RVT00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100Service, RVT00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loKey As RVT00100DTO
        Dim lcRtn As String

        Try
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor

            ' Create
            loKey = New RVT00100DTO
            With loKey
                ._CCOMPANY_ID = _CCOMPID
                ._CAPPS_CODE = _CAPPS_CODE
                ._CVERSION = _CVERSION
                ._CSTATUS = "CLOSED"
                ._CUPDATE_BY = _CUSERID
            End With
            lcRtn = loSvc.ChangeVersionStatus(loKey)
            If Not lcRtn.Equals("OK") Then
                loEx.Add(lcRtn, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcRtn))
            End If
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            System.Windows.Forms.Cursor.Current = Windows.Forms.Cursors.Default
        End Try
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        If loEx.Haserror Then
            R_DisplayException(ErrorHandler.ConvertError(loEx))
        Else
            RefreshGrids()
        End If
    End Sub

    Private Sub btnRevise_Click(sender As Object, e As EventArgs) Handles btnRevise.Click
        Dim loEx As New R_Exception
        Dim loSvc As RVT00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100Service, RVT00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loKey As RVT00100DTO
        Dim lcRtn As String

        Try
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor

            ' Create
            loKey = New RVT00100DTO
            With loKey
                ._CCOMPANY_ID = _CCOMPID
                ._CAPPS_CODE = _CAPPS_CODE
                ._CVERSION = _CVERSION
                ._CSTATUS = "REVISED"
                ._CUPDATE_BY = _CUSERID
            End With
            lcRtn = loSvc.ChangeVersionStatus(loKey)
            If Not lcRtn.Equals("OK") Then
                loEx.Add(lcRtn, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcRtn))
            End If
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        End Try
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        If loEx.Haserror Then
            R_DisplayException(ErrorHandler.ConvertError(loEx))
        Else
            RefreshGrids()
        End If
    End Sub

#End Region

#Region " PREDEFINED DOCK Events "

    ' Log
    Private Sub preLog_R_InstantiateDock(ByRef poTargetForm As R_FrontEnd.R_FormBase) Handles preLog.R_InstantiateDock
        poTargetForm = New RVT00100Log
    End Sub

    Private Sub preLog_R_PassParameter(ByRef poParameter As Object) Handles preLog.R_PassParameter
        With loFilterParam
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = CType(bsGvAppVer.Current, RVT00100DTO)._CAPPS_CODE
            .CVERSION = CType(bsGvAppVer.Current, RVT00100DTO)._CVERSION
            .CUSER_ID = _CUSERID
        End With
        poParameter = loFilterParam
    End Sub

    ' Include
    Private Sub preInclude_R_InstantiateDock(ByRef poTargetForm As R_FrontEnd.R_FormBase) Handles preInclude.R_InstantiateDock
        poTargetForm = New RVT00100Includes
    End Sub

    Private Sub preInclude_R_PassParameter(ByRef poParameter As Object) Handles preInclude.R_PassParameter
        With loFilterParam
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = CType(bsGvAppVer.Current, RVT00100DTO)._CAPPS_CODE
            .CVERSION = CType(bsGvAppVer.Current, RVT00100DTO)._CVERSION
            .CUSER_ID = _CUSERID
        End With
        poParameter = loFilterParam
    End Sub

#End Region

#Region " O T H E R "

    Private Sub cboApplication_SelectedIndexChanged(sender As Object, e As Telerik.WinControls.UI.Data.PositionChangedEventArgs) Handles cboApplication.SelectedIndexChanged
        If llInitialized Then
            RefreshGrids()
        End If
    End Sub

#End Region


End Class
