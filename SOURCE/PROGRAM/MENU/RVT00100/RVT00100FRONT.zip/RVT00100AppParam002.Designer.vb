﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RVT00100AppParam002
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewLookUpColumn1 As R_FrontEnd.R_GridViewLookUpColumn = New R_FrontEnd.R_GridViewLookUpColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewLookUpColumn2 As R_FrontEnd.R_GridViewLookUpColumn = New R_FrontEnd.R_GridViewLookUpColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblParameterGroup = New R_FrontEnd.R_RadLabel(Me.components)
        Me.cboParameterGroup = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsParamGroup = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridAppParam = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.txtApplication = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvAppParam = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvAppParam = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsAttributeGroup = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsAttribute = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsSourceGroup = New System.Windows.Forms.BindingSource(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.lblParameterGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboParameterGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsParamGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridAppParam, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvAppParam, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvAppParam.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvAppParam, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsAttributeGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsAttribute, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsSourceGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.gvAppParam, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 72.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(914, 525)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lblParameterGroup)
        Me.Panel1.Controls.Add(Me.cboParameterGroup)
        Me.Panel1.Controls.Add(Me.txtApplication)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(908, 66)
        Me.Panel1.TabIndex = 0
        '
        'lblParameterGroup
        '
        Me.lblParameterGroup.AutoSize = False
        Me.lblParameterGroup.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblParameterGroup.Location = New System.Drawing.Point(9, 34)
        Me.lblParameterGroup.Name = "lblParameterGroup"
        Me.lblParameterGroup.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblParameterGroup.R_ResourceId = "lblParameterGroup"
        Me.lblParameterGroup.Size = New System.Drawing.Size(100, 18)
        Me.lblParameterGroup.TabIndex = 30
        Me.lblParameterGroup.Text = "Application..."
        '
        'cboParameterGroup
        '
        Me.cboParameterGroup.DataSource = Me.bsParamGroup
        Me.cboParameterGroup.DisplayMember = "CPARAMETER_GROUP"
        Me.cboParameterGroup.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList
        Me.cboParameterGroup.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboParameterGroup.Location = New System.Drawing.Point(115, 34)
        Me.cboParameterGroup.Name = "cboParameterGroup"
        Me.cboParameterGroup.R_ConductorGridSource = Me.conGridAppParam
        Me.cboParameterGroup.R_ConductorSource = Nothing
        Me.cboParameterGroup.Size = New System.Drawing.Size(125, 20)
        Me.cboParameterGroup.TabIndex = 29
        Me.cboParameterGroup.Text = "R_RadDropDownList1"
        Me.cboParameterGroup.ValueMember = "CPARAMETER_GROUP"
        '
        'bsParamGroup
        '
        'Me.bsParamGroup.DataSource = GetType(RVT00100Front.RVT00100ParameterGroupComboDTO)
        '
        'conGridAppParam
        '
        Me.conGridAppParam.R_ConductorParent = Nothing
        Me.conGridAppParam.R_IsHeader = True
        Me.conGridAppParam.R_RadGroupBox = Nothing
        '
        'txtApplication
        '
        Me.txtApplication.Location = New System.Drawing.Point(115, 8)
        Me.txtApplication.Name = "txtApplication"
        Me.txtApplication.R_ConductorGridSource = Nothing
        Me.txtApplication.R_ConductorSource = Nothing
        Me.txtApplication.R_UDT = Nothing
        Me.txtApplication.ReadOnly = True
        Me.txtApplication.Size = New System.Drawing.Size(407, 20)
        Me.txtApplication.TabIndex = 28
        Me.txtApplication.TabStop = False
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 27
        Me.lblApplication.Text = "Application..."
        '
        'gvAppParam
        '
        Me.gvAppParam.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvAppParam.EnableFastScrolling = True
        Me.gvAppParam.Location = New System.Drawing.Point(3, 75)
        '
        '
        '
        Me.gvAppParam.MasterTemplate.AutoGenerateColumns = False
        Me.gvAppParam.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn1.FieldName = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn1.Name = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 266
        R_GridViewLookUpColumn1.FieldName = "_CSOURCE_GROUP_ID"
        R_GridViewLookUpColumn1.HeaderText = "_CSOURCE_GROUP_ID"
        R_GridViewLookUpColumn1.Name = "_CSOURCE_GROUP_ID"
        R_GridViewLookUpColumn1.R_EnableADD = True
        R_GridViewLookUpColumn1.R_ResourceId = "_CSOURCE_GROUP_ID"
        R_GridViewLookUpColumn1.R_Title = Nothing
        R_GridViewLookUpColumn1.Width = 269
        R_GridViewTextBoxColumn2.FieldName = "_CITEM_ATTRIBUTE_ID"
        R_GridViewTextBoxColumn2.HeaderText = "_CITEM_ATTRIBUTE_ID"
        R_GridViewTextBoxColumn2.Name = "_CITEM_ATTRIBUTE_ID"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CITEM_ATTRIBUTE_ID"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 93
        R_GridViewTextBoxColumn3.FieldName = "_CITEM_ID"
        R_GridViewTextBoxColumn3.HeaderText = "_CITEM_ID"
        R_GridViewTextBoxColumn3.Name = "_CITEM_ID"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CITEM_ID"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 72
        R_GridViewLookUpColumn2.FieldName = "_CSOURCE_ID"
        R_GridViewLookUpColumn2.HeaderText = "_CSOURCE_ID"
        R_GridViewLookUpColumn2.Name = "_CSOURCE_ID"
        R_GridViewLookUpColumn2.R_EnableADD = True
        R_GridViewLookUpColumn2.R_ResourceId = "_CSOURCE_ID"
        R_GridViewLookUpColumn2.R_Title = Nothing
        R_GridViewLookUpColumn2.Width = 192
        Me.gvAppParam.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewLookUpColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewLookUpColumn2})
        Me.gvAppParam.MasterTemplate.DataSource = Me.bsGvAppParam
        Me.gvAppParam.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvAppParam.MasterTemplate.EnableFiltering = True
        Me.gvAppParam.MasterTemplate.EnableGrouping = False
        Me.gvAppParam.MasterTemplate.ShowFilteringRow = False
        Me.gvAppParam.MasterTemplate.ShowGroupedColumns = True
        Me.gvAppParam.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvAppParam.Name = "gvAppParam"
        Me.gvAppParam.R_ConductorGridSource = Me.conGridAppParam
        Me.gvAppParam.R_ConductorSource = Nothing
        Me.gvAppParam.R_DataAdded = False
        Me.gvAppParam.R_NewRowText = Nothing
        Me.gvAppParam.ShowHeaderCellButtons = True
        Me.gvAppParam.Size = New System.Drawing.Size(908, 447)
        Me.gvAppParam.TabIndex = 1
        Me.gvAppParam.Text = "R_RadGridView1"
        '
        'bsGvAppParam
        '
        Me.bsGvAppParam.DataSource = GetType(RVT00100Front.RVT00100AppParam002ServiceRef.RVT00100AppParam002DTO)
        '
        'bsSourceGroup
        '
        Me.bsSourceGroup.DataSource = GetType(RVT00100Front.RVT00100AppParam002ServiceRef.RCustDBSourceGroupComboDTO)
        '
        'RVT00100AppParam002
        '
        Me.ClientSize = New System.Drawing.Size(914, 525)
        Me.ControlBox = False
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "RVT00100AppParam002"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.lblParameterGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboParameterGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsParamGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridAppParam, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvAppParam.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvAppParam, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvAppParam, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsAttributeGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsAttribute, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsSourceGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents txtApplication As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents gvAppParam As R_FrontEnd.R_RadGridView
    Friend WithEvents bsGvAppParam As System.Windows.Forms.BindingSource
    Friend WithEvents conGridAppParam As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsParamGroup As System.Windows.Forms.BindingSource
    Friend WithEvents bsSourceGroup As System.Windows.Forms.BindingSource
    Friend WithEvents lblParameterGroup As R_FrontEnd.R_RadLabel
    Friend WithEvents cboParameterGroup As R_FrontEnd.R_RadDropDownList
    Friend WithEvents bsAttributeGroup As System.Windows.Forms.BindingSource
    Friend WithEvents bsAttribute As System.Windows.Forms.BindingSource

End Class
