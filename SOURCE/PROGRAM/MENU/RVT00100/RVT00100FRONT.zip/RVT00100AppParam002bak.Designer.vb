﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RVT00100AppParam002bak
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    '<System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtApplication = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.bsGvAppParam = New System.Windows.Forms.BindingSource(Me.components)
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblParameterGroup = New R_FrontEnd.R_RadLabel(Me.components)
        Me.cboParameterGroup = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsParamGroup = New System.Windows.Forms.BindingSource(Me.components)
        Me.gvAppParam = New R_FrontEnd.R_RadGridView(Me.components)
        Me.conGridAppParam = New R_FrontEnd.R_ConductorGrid(Me.components)
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvAppParam, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.lblParameterGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboParameterGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsParamGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvAppParam, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvAppParam.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridAppParam, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 7
        Me.lblApplication.Text = "Application..."
        '
        'txtApplication
        '
        Me.txtApplication.Enabled = False
        Me.txtApplication.Location = New System.Drawing.Point(115, 8)
        Me.txtApplication.Name = "txtApplication"
        Me.txtApplication.R_ConductorGridSource = Nothing
        Me.txtApplication.R_ConductorSource = Nothing
        Me.txtApplication.R_UDT = Nothing
        Me.txtApplication.Size = New System.Drawing.Size(400, 20)
        Me.txtApplication.TabIndex = 19
        '
        'bsGvAppParam
        '
        Me.bsGvAppParam.DataSource = GetType(RVT00100Front.RVT00100AppParam002ServiceRef.RVT00100AppParam002DTO)
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.gvAppParam, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 72.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(702, 288)
        Me.TableLayoutPanel1.TabIndex = 20
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lblParameterGroup)
        Me.Panel1.Controls.Add(Me.cboParameterGroup)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Controls.Add(Me.txtApplication)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(696, 66)
        Me.Panel1.TabIndex = 0
        '
        'lblParameterGroup
        '
        Me.lblParameterGroup.AutoSize = False
        Me.lblParameterGroup.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblParameterGroup.Location = New System.Drawing.Point(9, 34)
        Me.lblParameterGroup.Name = "lblParameterGroup"
        Me.lblParameterGroup.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblParameterGroup.R_ResourceId = "lblParameterGroup"
        Me.lblParameterGroup.Size = New System.Drawing.Size(100, 18)
        Me.lblParameterGroup.TabIndex = 21
        Me.lblParameterGroup.Text = "Application..."
        '
        'cboParameterGroup
        '
        Me.cboParameterGroup.DataSource = Me.bsParamGroup
        Me.cboParameterGroup.DisplayMember = "CPARAMETER_GROUP"
        Me.cboParameterGroup.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList
        Me.cboParameterGroup.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboParameterGroup.Location = New System.Drawing.Point(115, 34)
        Me.cboParameterGroup.Name = "cboParameterGroup"
        Me.cboParameterGroup.R_ConductorGridSource = Nothing
        Me.cboParameterGroup.R_ConductorSource = Nothing
        Me.cboParameterGroup.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboParameterGroup.Size = New System.Drawing.Size(125, 20)
        Me.cboParameterGroup.TabIndex = 20
        Me.cboParameterGroup.Text = "R_RadDropDownList1"
        Me.cboParameterGroup.ValueMember = "CPARAMETER_GROUP"
        '
        'bsParamGroup
        '
        Me.bsParamGroup.DataSource = GetType(RVT00100Front.RVT00100ParameterGroupComboDTO)
        '
        'gvAppParam
        '
        Me.gvAppParam.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvAppParam.EnableFastScrolling = True
        Me.gvAppParam.Location = New System.Drawing.Point(3, 75)
        '
        '
        '
        Me.gvAppParam.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvAppParam.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvAppParam.MasterTemplate.EnableFiltering = True
        Me.gvAppParam.MasterTemplate.EnableGrouping = False
        Me.gvAppParam.MasterTemplate.ShowFilteringRow = False
        Me.gvAppParam.MasterTemplate.ShowGroupedColumns = True
        Me.gvAppParam.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvAppParam.Name = "gvAppParam"
        Me.gvAppParam.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvAppParam.R_ConductorGridSource = Nothing
        Me.gvAppParam.R_ConductorSource = Nothing
        Me.gvAppParam.R_DataAdded = False
        Me.gvAppParam.R_NewRowText = Nothing
        Me.gvAppParam.ShowHeaderCellButtons = True
        Me.gvAppParam.Size = New System.Drawing.Size(696, 210)
        Me.gvAppParam.TabIndex = 1
        Me.gvAppParam.Text = "R_RadGridView1"
        '
        'conGridAppParam
        '
        Me.conGridAppParam.R_ConductorParent = Nothing
        Me.conGridAppParam.R_IsHeader = True
        Me.conGridAppParam.R_RadGroupBox = Nothing
        '
        'RVT00100AppParam002bak
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(702, 288)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "RVT00100AppParam002bak"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvAppParam, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.lblParameterGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboParameterGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsParamGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvAppParam.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvAppParam, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridAppParam, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents txtApplication As R_FrontEnd.R_RadTextBox
    Friend WithEvents bsGvAppParam As System.Windows.Forms.BindingSource
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblParameterGroup As R_FrontEnd.R_RadLabel
    Friend WithEvents cboParameterGroup As R_FrontEnd.R_RadDropDownList
    Friend WithEvents bsParamGroup As System.Windows.Forms.BindingSource
    Friend WithEvents conGridAppParam As R_FrontEnd.R_ConductorGrid
    Friend WithEvents gvAppParam As R_FrontEnd.R_RadGridView

End Class
