﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RVT00100Revision
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.gvRevisions = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvRevision = New System.Windows.Forms.BindingSource(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblAppVersion = New R_FrontEnd.R_RadLabel(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.gvRevisions, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvRevisions.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvRevision, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.lblAppVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.gvRevisions, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 1
        '
        'gvRevisions
        '
        Me.gvRevisions.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvRevisions.EnableFastScrolling = True
        Me.gvRevisions.Location = New System.Drawing.Point(3, 33)
        '
        '
        '
        Me.gvRevisions.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn1.FieldName = "_CREVISION"
        R_GridViewTextBoxColumn1.HeaderText = "_CREVISION"
        R_GridViewTextBoxColumn1.Name = "_CREVISION"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CREVISION"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 82
        R_GridViewDateTimeColumn1.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn1.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn1.FieldName = "_DRELEASE_DATE"
        R_GridViewDateTimeColumn1.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn1.Format = System.Windows.Forms.DateTimePickerFormat.[Long]
        R_GridViewDateTimeColumn1.FormatInfo = New System.Globalization.CultureInfo("en-GB")
        R_GridViewDateTimeColumn1.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn1.HeaderText = "_DRELEASE_DATE"
        R_GridViewDateTimeColumn1.Name = "_DRELEASE_DATE"
        R_GridViewDateTimeColumn1.R_MinDate = New Date(CType(0, Long))
        R_GridViewDateTimeColumn1.R_ResourceId = "_DRELEASE_DATE"
        R_GridViewDateTimeColumn1.Width = 109
        R_GridViewTextBoxColumn2.FieldName = "_CRELEASE_BY"
        R_GridViewTextBoxColumn2.HeaderText = "_CRELEASE_BY"
        R_GridViewTextBoxColumn2.Name = "_CRELEASE_BY"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CRELEASE_BY"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 94
        Me.gvRevisions.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewDateTimeColumn1, R_GridViewTextBoxColumn2})
        Me.gvRevisions.MasterTemplate.DataSource = Me.bsGvRevision
        Me.gvRevisions.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvRevisions.MasterTemplate.EnableFiltering = True
        Me.gvRevisions.MasterTemplate.EnableGrouping = False
        Me.gvRevisions.MasterTemplate.ShowFilteringRow = False
        Me.gvRevisions.MasterTemplate.ShowGroupedColumns = True
        Me.gvRevisions.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvRevisions.Name = "gvRevisions"
        Me.gvRevisions.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvRevisions.R_ConductorGridSource = Nothing
        Me.gvRevisions.R_ConductorSource = Nothing
        Me.gvRevisions.R_DataAdded = False
        Me.gvRevisions.R_NewRowText = Nothing
        Me.gvRevisions.ShowHeaderCellButtons = True
        Me.gvRevisions.Size = New System.Drawing.Size(1271, 539)
        Me.gvRevisions.TabIndex = 3
        Me.gvRevisions.Text = "R_RadGridView1"
        '
        'bsGvRevision
        '
        Me.bsGvRevision.DataSource = GetType(RVT00100Front.RVT00100RevisionServiceRef.RVT00100RevisionDTO)
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lblAppVersion)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 24)
        Me.Panel1.TabIndex = 1
        '
        'lblAppVersion
        '
        Me.lblAppVersion.AutoSize = False
        Me.lblAppVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblAppVersion.Location = New System.Drawing.Point(9, 3)
        Me.lblAppVersion.Name = "lblAppVersion"
        Me.lblAppVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblAppVersion.R_ResourceId = Nothing
        Me.lblAppVersion.Size = New System.Drawing.Size(564, 18)
        Me.lblAppVersion.TabIndex = 0
        Me.lblAppVersion.Text = "R_RadLabel1"
        '
        'RVT00100Revision
        '
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "RVT00100Revision"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "Includes"
        Me.TableLayoutPanel1.ResumeLayout(False)
        CType(Me.gvRevisions.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvRevisions, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvRevision, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        CType(Me.lblAppVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblAppVersion As R_FrontEnd.R_RadLabel
    Friend WithEvents gvRevisions As R_FrontEnd.R_RadGridView
    Friend WithEvents bsGvRevision As System.Windows.Forms.BindingSource

End Class
