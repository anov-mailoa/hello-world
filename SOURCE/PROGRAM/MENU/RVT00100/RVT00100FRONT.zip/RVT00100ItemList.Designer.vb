﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RVT00100ItemList
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.gvManager = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsManager = New System.Windows.Forms.BindingSource(Me.components)
        Me.R_ReturnLookUpAndFind1 = New R_FrontEnd.R_ReturnLookUpAndFind()
        Me.bsAttributeGroup = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsAttribute = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblAttribute = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel1 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadDropDownList1 = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.R_RadDropDownList2 = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.R_RadLabel2 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblAttributeGroup = New R_FrontEnd.R_RadLabel(Me.components)
        Me.cboAttributeGroup = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.cboAttribute = New R_FrontEnd.R_RadDropDownList(Me.components)
        CType(Me.gvManager, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvManager.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsManager, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsAttributeGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsAttribute, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblAttribute, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.lblAttribute.SuspendLayout()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadDropDownList1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadDropDownList2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblAttributeGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboAttributeGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboAttribute, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'gvManager
        '
        Me.gvManager.EnableFastScrolling = True
        Me.gvManager.Location = New System.Drawing.Point(12, 38)
        '
        '
        '
        Me.gvManager.MasterTemplate.AutoGenerateColumns = False
        Me.gvManager.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn1.FieldName = "CPROGRAM_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CPROGRAM_ID"
        R_GridViewTextBoxColumn1.Name = "_CPROGRAM_ID"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CPROGRAM_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 124
        R_GridViewTextBoxColumn2.FieldName = "CPROGRAM_NAME"
        R_GridViewTextBoxColumn2.HeaderText = "_CPROGRAM_NAME"
        R_GridViewTextBoxColumn2.Name = "_CPROGRAM_NAME"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CPROGRAM_NAME"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 149
        R_GridViewTextBoxColumn3.FieldName = "CSOURCE_ID"
        R_GridViewTextBoxColumn3.HeaderText = "_CSOURCE_ID"
        R_GridViewTextBoxColumn3.Name = "_CSOURCE_ID"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CSOURCE_ID"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 110
        R_GridViewTextBoxColumn4.FieldName = "CDESCRIPTION"
        R_GridViewTextBoxColumn4.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxColumn4.Name = "_CDESCRIPTION"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 123
        Me.gvManager.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewTextBoxColumn4})
        Me.gvManager.MasterTemplate.DataSource = Me.bsManager
        Me.gvManager.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvManager.MasterTemplate.EnableFiltering = True
        Me.gvManager.MasterTemplate.EnableGrouping = False
        Me.gvManager.MasterTemplate.ShowFilteringRow = False
        Me.gvManager.MasterTemplate.ShowGroupedColumns = True
        Me.gvManager.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvManager.Name = "gvManager"
        Me.gvManager.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvManager.R_ConductorGridSource = Nothing
        Me.gvManager.R_ConductorSource = Nothing
        Me.gvManager.R_DataAdded = False
        Me.gvManager.R_NewRowText = Nothing
        Me.gvManager.ShowHeaderCellButtons = True
        Me.gvManager.Size = New System.Drawing.Size(523, 207)
        Me.gvManager.TabIndex = 1
        Me.gvManager.Text = "R_RadGridView1"
        '
        'bsManager
        '
        Me.bsManager.DataSource = GetType(RVT00100Front.RVT00100AppParam002StreamingServiceRef.RVT00100SourceListDTO)
        '
        'R_ReturnLookUpAndFind1
        '
        Me.R_ReturnLookUpAndFind1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.R_ReturnLookUpAndFind1.Location = New System.Drawing.Point(373, 251)
        Me.R_ReturnLookUpAndFind1.Name = "R_ReturnLookUpAndFind1"
        Me.R_ReturnLookUpAndFind1.R_BindingSource = Me.bsManager
        Me.R_ReturnLookUpAndFind1.Size = New System.Drawing.Size(162, 31)
        Me.R_ReturnLookUpAndFind1.TabIndex = 2
        '
        'lblAttribute
        '
        Me.lblAttribute.AutoSize = False
        Me.lblAttribute.Controls.Add(Me.R_RadLabel1)
        Me.lblAttribute.Controls.Add(Me.R_RadDropDownList1)
        Me.lblAttribute.Controls.Add(Me.R_RadDropDownList2)
        Me.lblAttribute.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblAttribute.Location = New System.Drawing.Point(15, 12)
        Me.lblAttribute.Name = "lblAttribute"
        Me.lblAttribute.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblAttribute.R_ResourceId = "lblAttribute"
        Me.lblAttribute.Size = New System.Drawing.Size(100, 18)
        Me.lblAttribute.TabIndex = 45
        Me.lblAttribute.Text = "Application..."
        '
        'R_RadLabel1
        '
        Me.R_RadLabel1.AutoSize = False
        Me.R_RadLabel1.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel1.Location = New System.Drawing.Point(0, 86)
        Me.R_RadLabel1.Name = "R_RadLabel1"
        Me.R_RadLabel1.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel1.R_ResourceId = "lblAttributeGroup"
        Me.R_RadLabel1.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel1.TabIndex = 44
        Me.R_RadLabel1.Text = "Application..."
        '
        'R_RadDropDownList1
        '
        Me.R_RadDropDownList1.DisplayMember = "CATTRIBUTE_NAME"
        Me.R_RadDropDownList1.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadDropDownList1.Location = New System.Drawing.Point(104, 0)
        Me.R_RadDropDownList1.Name = "R_RadDropDownList1"
        Me.R_RadDropDownList1.R_ConductorGridSource = Nothing
        Me.R_RadDropDownList1.R_ConductorSource = Nothing
        Me.R_RadDropDownList1.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadDropDownList1.Size = New System.Drawing.Size(206, 20)
        Me.R_RadDropDownList1.TabIndex = 43
        Me.R_RadDropDownList1.Text = "R_RadDropDownList1"
        Me.R_RadDropDownList1.ValueMember = "CATTRIBUTE_ID"
        '
        'R_RadDropDownList2
        '
        Me.R_RadDropDownList2.DisplayMember = "CATTRIBUTE_GROUP"
        Me.R_RadDropDownList2.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadDropDownList2.Location = New System.Drawing.Point(106, 86)
        Me.R_RadDropDownList2.Name = "R_RadDropDownList2"
        Me.R_RadDropDownList2.R_ConductorGridSource = Nothing
        Me.R_RadDropDownList2.R_ConductorSource = Nothing
        Me.R_RadDropDownList2.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadDropDownList2.Size = New System.Drawing.Size(206, 20)
        Me.R_RadDropDownList2.TabIndex = 42
        Me.R_RadDropDownList2.Text = "R_RadDropDownList1"
        Me.R_RadDropDownList2.ValueMember = "CATTRIBUTE_GROUP"
        '
        'R_RadLabel2
        '
        Me.R_RadLabel2.AutoSize = False
        Me.R_RadLabel2.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel2.Location = New System.Drawing.Point(12, 12)
        Me.R_RadLabel2.Name = "R_RadLabel2"
        Me.R_RadLabel2.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel2.R_ResourceId = "lblAttribute"
        Me.R_RadLabel2.Size = New System.Drawing.Size(100, 18)
        Me.R_RadLabel2.TabIndex = 45
        Me.R_RadLabel2.Text = "Application..."
        '
        'lblAttributeGroup
        '
        Me.lblAttributeGroup.AutoSize = False
        Me.lblAttributeGroup.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblAttributeGroup.Location = New System.Drawing.Point(12, 251)
        Me.lblAttributeGroup.Name = "lblAttributeGroup"
        Me.lblAttributeGroup.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblAttributeGroup.R_ResourceId = "lblAttributeGroup"
        Me.lblAttributeGroup.Size = New System.Drawing.Size(100, 18)
        Me.lblAttributeGroup.TabIndex = 44
        Me.lblAttributeGroup.Text = "Application..."
        Me.lblAttributeGroup.Visible = False
        '
        'cboAttributeGroup
        '
        Me.cboAttributeGroup.DataSource = Me.bsAttributeGroup
        Me.cboAttributeGroup.DisplayMember = "CATTRIBUTE_GROUP"
        Me.cboAttributeGroup.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboAttributeGroup.Location = New System.Drawing.Point(118, 251)
        Me.cboAttributeGroup.Name = "cboAttributeGroup"
        Me.cboAttributeGroup.R_ConductorGridSource = Nothing
        Me.cboAttributeGroup.R_ConductorSource = Nothing
        Me.cboAttributeGroup.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboAttributeGroup.Size = New System.Drawing.Size(206, 20)
        Me.cboAttributeGroup.TabIndex = 42
        Me.cboAttributeGroup.Text = "R_RadDropDownList1"
        Me.cboAttributeGroup.ValueMember = "CATTRIBUTE_GROUP"
        Me.cboAttributeGroup.Visible = False
        '
        'cboAttribute
        '
        Me.cboAttribute.DataSource = Me.bsAttribute
        Me.cboAttribute.DisplayMember = "CATTRIBUTE_NAME"
        Me.cboAttribute.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboAttribute.Location = New System.Drawing.Point(119, 12)
        Me.cboAttribute.Name = "cboAttribute"
        Me.cboAttribute.R_ConductorGridSource = Nothing
        Me.cboAttribute.R_ConductorSource = Nothing
        Me.cboAttribute.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboAttribute.Size = New System.Drawing.Size(206, 20)
        Me.cboAttribute.TabIndex = 43
        Me.cboAttribute.Text = "R_RadDropDownList1"
        Me.cboAttribute.ValueMember = "CATTRIBUTE_ID"
        '
        'RVT00100ItemList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(556, 294)
        Me.Controls.Add(Me.R_RadLabel2)
        Me.Controls.Add(Me.lblAttribute)
        Me.Controls.Add(Me.lblAttributeGroup)
        Me.Controls.Add(Me.cboAttributeGroup)
        Me.Controls.Add(Me.cboAttribute)
        Me.Controls.Add(Me.R_ReturnLookUpAndFind1)
        Me.Controls.Add(Me.gvManager)
        Me.Name = "RVT00100ItemList"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "Program List"
        CType(Me.gvManager.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvManager, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsManager, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsAttributeGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsAttribute, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblAttribute, System.ComponentModel.ISupportInitialize).EndInit()
        Me.lblAttribute.ResumeLayout(False)
        Me.lblAttribute.PerformLayout()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadDropDownList1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadDropDownList2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblAttributeGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboAttributeGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboAttribute, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents bsManager As System.Windows.Forms.BindingSource
    Friend WithEvents gvManager As R_FrontEnd.R_RadGridView
    Friend WithEvents R_ReturnLookUpAndFind1 As R_FrontEnd.R_ReturnLookUpAndFind
    Friend WithEvents bsAttributeGroup As System.Windows.Forms.BindingSource
    Friend WithEvents bsAttribute As System.Windows.Forms.BindingSource
    Friend WithEvents lblAttribute As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel2 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel1 As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadDropDownList1 As R_FrontEnd.R_RadDropDownList
    Friend WithEvents R_RadDropDownList2 As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblAttributeGroup As R_FrontEnd.R_RadLabel
    Friend WithEvents cboAttributeGroup As R_FrontEnd.R_RadDropDownList
    Friend WithEvents cboAttribute As R_FrontEnd.R_RadDropDownList

End Class
