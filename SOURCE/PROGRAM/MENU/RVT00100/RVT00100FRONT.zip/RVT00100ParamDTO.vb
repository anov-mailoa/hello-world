﻿Public Class RVT00100ParamDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CAPPS_NAME As String
    Public Property CVERSION As String
    Public Property CUSER_ID As String
    Public Property CMAJOR As String
    Public Property CMINOR As String
End Class
