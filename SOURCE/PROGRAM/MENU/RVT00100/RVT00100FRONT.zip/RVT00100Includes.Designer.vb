﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RVT00100Includes
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewComboBoxColumn1 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Dim R_GridViewComboBoxColumn2 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Dim R_GridViewComboBoxColumn3 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Me.bsProvider = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsAppVer = New System.Windows.Forms.BindingSource(Me.components)
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblAppVersion = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvIncludes = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvIncludes = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridIncludes = New R_FrontEnd.R_ConductorGrid(Me.components)
        CType(Me.bsProvider, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsAppVer, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.lblAppVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvIncludes, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvIncludes.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvIncludes, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridIncludes, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'bsProvider
        '
        Me.bsProvider.DataSource = GetType(RVT00100Front.RVT00100IncludeServiceRef.RVT00100ProviderComboDTO)
        '
        'bsApps
        '
        Me.bsApps.DataSource = GetType(RVT00100Front.RVT00100ServiceRef.RLicenseAppComboDTO)
        '
        'bsAppVer
        '
        Me.bsAppVer.DataSource = GetType(RVT00100Front.RVT00100IncludeServiceRef.RVT00100AppVersionComboDTO)
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.gvIncludes, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lblAppVersion)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 24)
        Me.Panel1.TabIndex = 1
        '
        'lblAppVersion
        '
        Me.lblAppVersion.AutoSize = False
        Me.lblAppVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblAppVersion.Location = New System.Drawing.Point(9, 3)
        Me.lblAppVersion.Name = "lblAppVersion"
        Me.lblAppVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblAppVersion.R_ResourceId = Nothing
        Me.lblAppVersion.Size = New System.Drawing.Size(564, 18)
        Me.lblAppVersion.TabIndex = 0
        Me.lblAppVersion.Text = "R_RadLabel1"
        '
        'gvIncludes
        '
        Me.gvIncludes.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvIncludes.EnableFastScrolling = True
        Me.gvIncludes.Location = New System.Drawing.Point(3, 33)
        '
        '
        '
        Me.gvIncludes.MasterTemplate.AutoGenerateColumns = False
        Me.gvIncludes.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewComboBoxColumn1.DataSource = Me.bsProvider
        R_GridViewComboBoxColumn1.DisplayMember = "CCOMPANY_NAME"
        R_GridViewComboBoxColumn1.FieldName = "_CINCL_COMPANY_ID"
        R_GridViewComboBoxColumn1.HeaderText = "_CINCL_COMPANY_ID"
        R_GridViewComboBoxColumn1.MinWidth = 250
        R_GridViewComboBoxColumn1.Name = "_CINCL_COMPANY_ID"
        R_GridViewComboBoxColumn1.R_EnableADD = True
        R_GridViewComboBoxColumn1.R_ResourceId = "_CINCL_COMPANY_ID"
        R_GridViewComboBoxColumn1.ValueMember = "CCOMPANY_ID"
        R_GridViewComboBoxColumn1.Width = 731
        R_GridViewComboBoxColumn2.DataSource = Me.bsApps
        R_GridViewComboBoxColumn2.DisplayMember = "CAPPS_NAME"
        R_GridViewComboBoxColumn2.FieldName = "_CINCL_APPS_CODE"
        R_GridViewComboBoxColumn2.HeaderText = "_CINCL_APPS_CODE"
        R_GridViewComboBoxColumn2.MinWidth = 250
        R_GridViewComboBoxColumn2.Name = "_CINCL_APPS_CODE"
        R_GridViewComboBoxColumn2.R_EnableADD = True
        R_GridViewComboBoxColumn2.R_ResourceId = "_CINCL_APPS_CODE"
        R_GridViewComboBoxColumn2.ValueMember = "CAPPS_CODE"
        R_GridViewComboBoxColumn2.Width = 439
        R_GridViewComboBoxColumn3.DataSource = Me.bsAppVer
        R_GridViewComboBoxColumn3.DisplayMember = "CVERSION"
        R_GridViewComboBoxColumn3.FieldName = "_CINCL_VERSION"
        R_GridViewComboBoxColumn3.HeaderText = "_CINCL_VERSION"
        R_GridViewComboBoxColumn3.Name = "_CINCL_VERSION"
        R_GridViewComboBoxColumn3.R_EnableADD = True
        R_GridViewComboBoxColumn3.R_EnableEDIT = True
        R_GridViewComboBoxColumn3.R_ResourceId = "_CINCL_VERSION"
        R_GridViewComboBoxColumn3.ValueMember = "CVERSION"
        R_GridViewComboBoxColumn3.Width = 83
        Me.gvIncludes.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewComboBoxColumn1, R_GridViewComboBoxColumn2, R_GridViewComboBoxColumn3})
        Me.gvIncludes.MasterTemplate.DataSource = Me.bsGvIncludes
        Me.gvIncludes.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvIncludes.MasterTemplate.EnableFiltering = True
        Me.gvIncludes.MasterTemplate.EnableGrouping = False
        Me.gvIncludes.MasterTemplate.ShowFilteringRow = False
        Me.gvIncludes.MasterTemplate.ShowGroupedColumns = True
        Me.gvIncludes.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvIncludes.Name = "gvIncludes"
        Me.gvIncludes.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvIncludes.R_ConductorGridSource = Me.conGridIncludes
        Me.gvIncludes.R_ConductorSource = Nothing
        Me.gvIncludes.R_DataAdded = False
        Me.gvIncludes.R_NewRowText = Nothing
        Me.gvIncludes.ShowHeaderCellButtons = True
        Me.gvIncludes.Size = New System.Drawing.Size(1271, 539)
        Me.gvIncludes.TabIndex = 2
        Me.gvIncludes.Text = "R_RadGridView1"
        '
        'bsGvIncludes
        '
        Me.bsGvIncludes.DataSource = GetType(RVT00100Front.RVT00100IncludeServiceRef.RVT00100IncludeDTO)
        '
        'conGridIncludes
        '
        Me.conGridIncludes.R_ConductorParent = Nothing
        Me.conGridIncludes.R_IsHeader = True
        Me.conGridIncludes.R_RadGroupBox = Nothing
        '
        'RVT00100Includes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "RVT00100Includes"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "Includes"
        CType(Me.bsProvider, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsAppVer, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me.lblAppVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvIncludes.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvIncludes, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvIncludes, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridIncludes, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblAppVersion As R_FrontEnd.R_RadLabel
    Friend WithEvents gvIncludes As R_FrontEnd.R_RadGridView
    Friend WithEvents bsProvider As System.Windows.Forms.BindingSource
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource
    Friend WithEvents bsAppVer As System.Windows.Forms.BindingSource
    Friend WithEvents bsGvIncludes As System.Windows.Forms.BindingSource
    Friend WithEvents conGridIncludes As R_FrontEnd.R_ConductorGrid

End Class
