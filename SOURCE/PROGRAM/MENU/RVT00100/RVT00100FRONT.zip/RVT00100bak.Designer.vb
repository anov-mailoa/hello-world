﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RVT00100bak
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cboApplication = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvAppVer = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvAppVer = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridAppVer = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.lblReleaseDate = New R_FrontEnd.R_RadLabel(Me.components)
        Me.dtpReleaseDate = New R_FrontEnd.R_RadDateTimePicker(Me.components)
        Me.btnIncludes = New R_FrontEnd.R_Detail(Me.components)
        Me.btnLog = New R_FrontEnd.R_Detail(Me.components)
        Me.btnRelease = New R_FrontEnd.R_RadButton(Me.components)
        Me.chkBugFix = New R_FrontEnd.R_RadCheckBox(Me.components)
        Me.chkImprovement = New R_FrontEnd.R_RadCheckBox(Me.components)
        Me.chkEnhancement = New R_FrontEnd.R_RadCheckBox(Me.components)
        Me.chkMajor = New R_FrontEnd.R_RadCheckBox(Me.components)
        Me.lblNxVersion = New R_FrontEnd.R_RadLabel(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvAppVer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvAppVer.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvAppVer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridAppVer, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.lblReleaseDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dtpReleaseDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnIncludes, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnLog, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnRelease, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkBugFix, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkImprovement, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkEnhancement, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkMajor, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblNxVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.gvAppVer, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 0, 2)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 120.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(723, 316)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.cboApplication)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(717, 30)
        Me.Panel1.TabIndex = 0
        '
        'cboApplication
        '
        Me.cboApplication.DataSource = Me.bsApps
        Me.cboApplication.DisplayMember = "CAPPS_NAME"
        Me.cboApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboApplication.Location = New System.Drawing.Point(115, 3)
        Me.cboApplication.Name = "cboApplication"
        Me.cboApplication.R_ConductorGridSource = Nothing
        Me.cboApplication.R_ConductorSource = Nothing
        Me.cboApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboApplication.Size = New System.Drawing.Size(400, 20)
        Me.cboApplication.TabIndex = 6
        Me.cboApplication.Text = "R_RadDropDownList1"
        Me.cboApplication.ValueMember = "CAPPS_CODE"
        '
        'bsApps
        '
        Me.bsApps.DataSource = GetType(RVT00100Front.RVT00100ServiceRef.RLicenseAppComboDTO)
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 3)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 5
        Me.lblApplication.Text = "Application..."
        '
        'gvAppVer
        '
        Me.gvAppVer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvAppVer.Location = New System.Drawing.Point(3, 39)
        '
        '
        '
        Me.gvAppVer.MasterTemplate.AllowAddNewRow = False
        Me.gvAppVer.MasterTemplate.AutoGenerateColumns = False
        Me.gvAppVer.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn1.FieldName = "_CVERSION"
        R_GridViewTextBoxColumn1.HeaderText = "_CVERSION"
        R_GridViewTextBoxColumn1.Name = "_CVERSION"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CVERSION"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 122
        R_GridViewDateTimeColumn1.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn1.FieldName = "_DRELEASE_DATE"
        R_GridViewDateTimeColumn1.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn1.HeaderText = "_DRELEASE_DATE"
        R_GridViewDateTimeColumn1.Name = "_DRELEASE_DATE"
        R_GridViewDateTimeColumn1.R_ResourceId = "_CRELEASE_DATE"
        R_GridViewDateTimeColumn1.Width = 83
        R_GridViewTextBoxColumn2.FieldName = "_CUPDATE_BY"
        R_GridViewTextBoxColumn2.HeaderText = "_CUPDATE_BY"
        R_GridViewTextBoxColumn2.Name = "_CUPDATE_BY"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CUPDATE_BY"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 494
        Me.gvAppVer.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewDateTimeColumn1, R_GridViewTextBoxColumn2})
        Me.gvAppVer.MasterTemplate.DataSource = Me.bsGvAppVer
        Me.gvAppVer.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvAppVer.MasterTemplate.EnableFiltering = True
        Me.gvAppVer.MasterTemplate.EnableGrouping = False
        Me.gvAppVer.MasterTemplate.ShowFilteringRow = False
        Me.gvAppVer.MasterTemplate.ShowGroupedColumns = True
        Me.gvAppVer.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvAppVer.Name = "gvAppVer"
        Me.gvAppVer.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvAppVer.R_ConductorGridSource = Me.conGridAppVer
        Me.gvAppVer.R_ConductorSource = Nothing
        Me.gvAppVer.R_DataAdded = False
        Me.gvAppVer.R_NewRowText = Nothing
        Me.gvAppVer.ShowHeaderCellButtons = True
        Me.gvAppVer.Size = New System.Drawing.Size(717, 154)
        Me.gvAppVer.TabIndex = 1
        Me.gvAppVer.Text = "R_RadGridView1"
        '
        'bsGvAppVer
        '
        Me.bsGvAppVer.DataSource = GetType(RVT00100Front.RVT00100ServiceRef.RVT00100DTO)
        '
        'conGridAppVer
        '
        Me.conGridAppVer.R_ConductorParent = Nothing
        Me.conGridAppVer.R_IsHeader = True
        Me.conGridAppVer.R_RadGroupBox = Nothing
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.lblReleaseDate)
        Me.Panel2.Controls.Add(Me.dtpReleaseDate)
        Me.Panel2.Controls.Add(Me.btnIncludes)
        Me.Panel2.Controls.Add(Me.btnLog)
        Me.Panel2.Controls.Add(Me.btnRelease)
        Me.Panel2.Controls.Add(Me.chkBugFix)
        Me.Panel2.Controls.Add(Me.chkImprovement)
        Me.Panel2.Controls.Add(Me.chkEnhancement)
        Me.Panel2.Controls.Add(Me.chkMajor)
        Me.Panel2.Controls.Add(Me.lblNxVersion)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 199)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(717, 114)
        Me.Panel2.TabIndex = 2
        '
        'lblReleaseDate
        '
        Me.lblReleaseDate.AutoSize = False
        Me.lblReleaseDate.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblReleaseDate.Location = New System.Drawing.Point(9, 51)
        Me.lblReleaseDate.Name = "lblReleaseDate"
        Me.lblReleaseDate.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblReleaseDate.R_ResourceId = "lblReleaseDate"
        Me.lblReleaseDate.Size = New System.Drawing.Size(100, 18)
        Me.lblReleaseDate.TabIndex = 9
        Me.lblReleaseDate.Text = "R_RadLabel1"
        '
        'dtpReleaseDate
        '
        Me.dtpReleaseDate.Location = New System.Drawing.Point(129, 50)
        Me.dtpReleaseDate.Name = "dtpReleaseDate"
        Me.dtpReleaseDate.NullText = "No date selected"
        Me.dtpReleaseDate.R_ConductorGridSource = Nothing
        Me.dtpReleaseDate.R_ConductorSource = Nothing
        Me.dtpReleaseDate.Size = New System.Drawing.Size(87, 20)
        Me.dtpReleaseDate.TabIndex = 8
        Me.dtpReleaseDate.TabStop = False
        Me.dtpReleaseDate.Text = "3/8/2016"
        Me.dtpReleaseDate.Value = New Date(2016, 3, 8, 11, 49, 30, 106)
        '
        'btnIncludes
        '
        Me.btnIncludes.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnIncludes.Location = New System.Drawing.Point(241, 81)
        Me.btnIncludes.Name = "btnIncludes"
        Me.btnIncludes.R_ConductorGridSource = Nothing
        Me.btnIncludes.R_ConductorSource = Nothing
        Me.btnIncludes.R_DescriptionId = Nothing
        Me.btnIncludes.R_ResourceId = "btnIncludes"
        Me.btnIncludes.R_Title = Nothing
        Me.btnIncludes.Size = New System.Drawing.Size(110, 24)
        Me.btnIncludes.TabIndex = 7
        Me.btnIncludes.Text = "R_Detail2"
        '
        'btnLog
        '
        Me.btnLog.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnLog.Location = New System.Drawing.Point(125, 81)
        Me.btnLog.Name = "btnLog"
        Me.btnLog.R_ConductorGridSource = Nothing
        Me.btnLog.R_ConductorSource = Nothing
        Me.btnLog.R_DescriptionId = Nothing
        Me.btnLog.R_ResourceId = "btnLog"
        Me.btnLog.R_Title = Nothing
        Me.btnLog.Size = New System.Drawing.Size(110, 24)
        Me.btnLog.TabIndex = 6
        Me.btnLog.Text = "R_Detail1"
        '
        'btnRelease
        '
        Me.btnRelease.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnRelease.Location = New System.Drawing.Point(9, 81)
        Me.btnRelease.Name = "btnRelease"
        Me.btnRelease.R_ConductorGridSource = Nothing
        Me.btnRelease.R_ConductorSource = Nothing
        Me.btnRelease.R_DescriptionId = Nothing
        Me.btnRelease.R_ResourceId = "btnRelease"
        Me.btnRelease.Size = New System.Drawing.Size(110, 24)
        Me.btnRelease.TabIndex = 5
        Me.btnRelease.Text = "R_RadButton1"
        '
        'chkBugFix
        '
        Me.chkBugFix.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.chkBugFix.Location = New System.Drawing.Point(369, 27)
        Me.chkBugFix.Name = "chkBugFix"
        Me.chkBugFix.R_ConductorGridSource = Nothing
        Me.chkBugFix.R_ConductorSource = Nothing
        Me.chkBugFix.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.chkBugFix.R_ResourceId = "chkBugFix"
        Me.chkBugFix.Size = New System.Drawing.Size(107, 18)
        Me.chkBugFix.TabIndex = 4
        Me.chkBugFix.Text = "R_RadCheckBox3"
        '
        'chkImprovement
        '
        Me.chkImprovement.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.chkImprovement.Location = New System.Drawing.Point(249, 27)
        Me.chkImprovement.Name = "chkImprovement"
        Me.chkImprovement.R_ConductorGridSource = Nothing
        Me.chkImprovement.R_ConductorSource = Nothing
        Me.chkImprovement.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.chkImprovement.R_ResourceId = "chkImprovement"
        Me.chkImprovement.Size = New System.Drawing.Size(107, 18)
        Me.chkImprovement.TabIndex = 3
        Me.chkImprovement.Text = "R_RadCheckBox2"
        '
        'chkEnhancement
        '
        Me.chkEnhancement.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.chkEnhancement.Location = New System.Drawing.Point(129, 27)
        Me.chkEnhancement.Name = "chkEnhancement"
        Me.chkEnhancement.R_ConductorGridSource = Nothing
        Me.chkEnhancement.R_ConductorSource = Nothing
        Me.chkEnhancement.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.chkEnhancement.R_ResourceId = "chkEnhancement"
        Me.chkEnhancement.Size = New System.Drawing.Size(107, 18)
        Me.chkEnhancement.TabIndex = 2
        Me.chkEnhancement.Text = "R_RadCheckBox1"
        '
        'chkMajor
        '
        Me.chkMajor.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.chkMajor.Location = New System.Drawing.Point(9, 27)
        Me.chkMajor.Name = "chkMajor"
        Me.chkMajor.R_ConductorGridSource = Nothing
        Me.chkMajor.R_ConductorSource = Nothing
        Me.chkMajor.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.chkMajor.R_ResourceId = "chkMajor"
        Me.chkMajor.Size = New System.Drawing.Size(107, 18)
        Me.chkMajor.TabIndex = 1
        Me.chkMajor.Text = "R_RadCheckBox1"
        '
        'lblNxVersion
        '
        Me.lblNxVersion.AutoSize = False
        Me.lblNxVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblNxVersion.Location = New System.Drawing.Point(9, 3)
        Me.lblNxVersion.Name = "lblNxVersion"
        Me.lblNxVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblNxVersion.R_ResourceId = "lblNxVersion"
        Me.lblNxVersion.Size = New System.Drawing.Size(100, 18)
        Me.lblNxVersion.TabIndex = 0
        Me.lblNxVersion.Text = "R_RadLabel1"
        '
        'RVT00100bak
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(723, 316)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "RVT00100bak"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvAppVer.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvAppVer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvAppVer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridAppVer, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.lblReleaseDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dtpReleaseDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnIncludes, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnLog, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnRelease, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkBugFix, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkImprovement, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkEnhancement, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkMajor, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblNxVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents cboApplication As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource
    Friend WithEvents gvAppVer As R_FrontEnd.R_RadGridView
    Friend WithEvents bsGvAppVer As System.Windows.Forms.BindingSource
    Friend WithEvents conGridAppVer As R_FrontEnd.R_ConductorGrid
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents chkBugFix As R_FrontEnd.R_RadCheckBox
    Friend WithEvents chkImprovement As R_FrontEnd.R_RadCheckBox
    Friend WithEvents chkEnhancement As R_FrontEnd.R_RadCheckBox
    Friend WithEvents chkMajor As R_FrontEnd.R_RadCheckBox
    Friend WithEvents lblNxVersion As R_FrontEnd.R_RadLabel
    Friend WithEvents btnRelease As R_FrontEnd.R_RadButton
    Friend WithEvents btnIncludes As R_FrontEnd.R_Detail
    Friend WithEvents btnLog As R_FrontEnd.R_Detail
    Friend WithEvents lblReleaseDate As R_FrontEnd.R_RadLabel
    Friend WithEvents dtpReleaseDate As R_FrontEnd.R_RadDateTimePicker

End Class
