﻿Imports RVT00100FrontResources
Imports R_Common
Imports RVT00100Front.RVT00100AppParam002StreamingServiceRef
Imports R_FrontEnd
Imports System.ServiceModel.Channels
Imports RVT00100Front.RVT00100AppParam002ServiceRef

Public Class RVT00100ItemList

#Region " VARIABLE "
    Dim C_ServiceName As String = "RVT00100Service/RVT00100AppParam002Service.svc"
    Dim C_ServiceNameStream As String = "RVT00100Service/RVT00100AppParam002StreamingService.svc"
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _CVERSION As String
    Dim _INIT As Boolean = False
    Dim _CATTRIBUTEGROUP As String
#End Region

#Region " FORM Events "

    Private Sub CSM00500Manager_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loSvc As RVT00100AppParam002ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100AppParam002Service, RVT00100AppParam002ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loAttributeGroupCombo As New List(Of RCustDBAttributeGroupComboDTO)
        Dim loAttributeCombo As New List(Of RCustDBAttributeComboDTO)

        Try
            With CType(poParameter, RVT00100ItemListParamDTO)
                _CCOMPID = .CCOMPANY_ID
                _CAPPSCODE = .CAPPS_CODE
                _INIT = True
                _CATTRIBUTEGROUP = .CATTRIBUTE_GROUP
                ' Combos
                'loAttributeGroupCombo = loSvc.GetAttributeGroupCombo(.CCOMPANY_ID, .CAPPS_CODE)
                'bsAttributeGroup.DataSource = loAttributeGroupCombo
                'loSvc.Close()
                loAttributeCombo = loSvc.GetAttributeCombo(_CCOMPID, _CAPPSCODE, .CATTRIBUTE_GROUP)
                bsAttribute.DataSource = loAttributeCombo
                loSvc.Close()
                'If .CATTRIBUTE_GROUP IsNot Nothing Then
                '    cboAttributeGroup.SelectedValue = .CATTRIBUTE_GROUP
                'End If
                If .CATTRIBUTE_ID IsNot Nothing Then
                    cboAttribute.SelectedValue = .CATTRIBUTE_ID
                End If
                'If .CPARAMETER_GROUP.Trim = "BACK" Or .CPARAMETER_GROUP.Trim = "SERVICE" Then
                '    cboAttributeGroup.Enabled = False
                '    cboAttribute.Enabled = False
                'Else
                '    cboAttributeGroup.Enabled = True
                '    cboAttribute.Enabled = True
                'End If
            End With

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub
#End Region

#Region " GRIDVIEW Events "

    Private Sub gvManager_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvManager.R_ServiceGetListRecord
        Dim loServiceStream As RVT00100AppParam002StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100AppParam002StreamingService, RVT00100AppParam002StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of RVT00100SourceListDTO)
        Dim loListEntity As New List(Of RVT00100SourceListDTO)

        Try
            With CType(poEntity, RVT00100ItemKeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cAttributeGroup", .CATTRIBUTE_GROUP)
                R_Utility.R_SetStreamingContext("cAttributeId", .CATTRIBUTE_ID)

                loRtn = loServiceStream.GetSourceList()
                loStreaming = R_StreamUtility(Of RVT00100SourceListDTO).ReadFromMessage(loRtn)

                For Each loDto As RVT00100SourceListDTO In loStreaming
                    If loDto IsNot Nothing Then
                        loDto.CATTRIBUTE_GROUP = .CATTRIBUTE_GROUP
                        loDto.CATTRIBUTE_ID = .CATTRIBUTE_ID
                        loListEntity.Add(loDto)
                    Else
                        Exit For
                    End If
                Next
                poListEntityResult = loListEntity

            End With
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loServiceStream.Close()
        loException.ThrowExceptionIfErrors()
    End Sub
#End Region

#Region " COMBO Actions "
    Private Sub cboAttributeGroup_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboAttributeGroup.SelectedValueChanged
        Dim loEx As New R_Exception
        Dim loSvc As RVT00100AppParam002ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100AppParam002Service, RVT00100AppParam002ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loAttributeCombo As New List(Of RCustDBAttributeComboDTO)

        Try
            If _INIT Then
                loAttributeCombo = loSvc.GetAttributeCombo(_CCOMPID, _CAPPSCODE, CType(sender, R_RadDropDownList).SelectedValue)
                bsAttribute.DataSource = loAttributeCombo
                loSvc.Close()
            End If
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loSvc.Close()
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub cboAttribute_TextChanged(sender As Object, e As System.EventArgs) Handles cboAttribute.SelectedValueChanged
        Dim loKey As New RVT00100ItemKeyDTO

        If _INIT Then
            With loKey
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = _CAPPSCODE
                .CATTRIBUTE_GROUP = _CATTRIBUTEGROUP
                .CATTRIBUTE_ID = sender.SelectedValue
            End With
            gvManager.R_RefreshGrid(loKey)
        End If
    End Sub

#End Region

End Class
