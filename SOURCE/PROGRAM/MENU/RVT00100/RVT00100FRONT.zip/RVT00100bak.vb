﻿Imports RVT00100FrontResources
Imports R_Common
Imports RVT00100Front.RVT00100ServiceRef
Imports RVT00100Front.RVT00100StreamingServiceRef
Imports R_FrontEnd
Imports ClientHelper
Imports System.ServiceModel.Channels

Public Class RVT00100bak

#Region " VARIABLE "
    Dim C_ServiceName As String = "RVT00100Service/RVT00100Service.svc"
    Dim C_ServiceNameStream As String = "RVT00100Service/RVT00100StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPS_CODE As String
    Dim _CCUSTOMER_CODE As String
    Dim llInitialized As Boolean = False
#End Region

#Region " F O R M "

    Private Sub RVT00100_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loSvc As RVT00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100Service, RVT00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loAppCombo As New List(Of RLicenseAppComboDTO)

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            ' Application
            loAppCombo = loSvc.GetAppCombo(_CCOMPID, _CUSERID, "A")
            bsApps.DataSource = loAppCombo

            dtpReleaseDate.Value = Today

            llInitialized = True
            RefreshGrids()

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub RVT00100_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

    Private Sub RefreshGrids()
        Dim loTableKey As New RVT00100GridDTO

        With loTableKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = cboApplication.SelectedValue.Trim
        End With

        gvAppVer.R_RefreshGrid(loTableKey)
    End Sub


#Region " GRIDVIEW "

    Private Sub gvAppVer_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvAppVer.R_Saving
        With CType(poEntity, RVT00100DTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = cboApplication.SelectedValue.Trim
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With
    End Sub

    Private Sub gvAppVer_R_ServiceDelete(poEntity As Object) Handles gvAppVer.R_ServiceDelete
        Dim loService As RVT00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100Service, RVT00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            With CType(poEntity, RVT00100DTO)
                ._CCOMPANY_ID = _CCOMPID
            End With

            loService.Svc_R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvAppVer_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvAppVer.R_ServiceGetListRecord
        Dim loServiceStream As RVT00100StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100StreamingService, RVT00100StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of RVT00100GridDTO)
        Dim loListEntity As New List(Of RVT00100DTO)

        Try
            With poEntity
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
            End With

            loRtn = loServiceStream.GetVersions()
            loStreaming = R_StreamUtility(Of RVT00100GridDTO).ReadFromMessage(loRtn)

            For Each loDto As RVT00100GridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New RVT00100DTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                           ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                           ._CVERSION = loDto.CVERSION,
                                                           ._CRELEASE_DATE = loDto.CRELEASE_DATE,
                                                           ._DRELEASE_DATE = loDto.DRELEASE_DATE,
                                                           ._CCREATE_BY = loDto.CCREATE_BY,
                                                           ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                           ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                           ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvAppVer_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvAppVer.R_ServiceGetRecord
        Dim loService As RVT00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100Service, RVT00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New RVT00100DTO With {._CCOMPANY_ID = _CCOMPID,
                                                                            ._CAPPS_CODE = CType(bsGvAppVer.Current, RVT00100DTO)._CAPPS_CODE,
                                                                             ._CVERSION = CType(bsGvAppVer.Current, RVT00100DTO)._CVERSION})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvAppVer_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvAppVer.R_ServiceSave
        Dim loService As RVT00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100Service, RVT00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

    Private Sub cboApplication_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboApplication.SelectedValueChanged
        If llInitialized Then
            RefreshGrids()
        End If
    End Sub

    Private Sub btnRelease_Click(sender As Object, e As System.EventArgs) Handles btnRelease.Click
        Dim loEx As New R_Exception
        Dim loSvc As RVT00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100Service, RVT00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loLicense As RVT00100ReleaseDTO
        Dim lcCustomerInfo As String()
        Dim lcCustomerName As String = ""

        Try

            ' Validation
            ' Release Type
            If Not chkMajor.Checked And Not chkEnhancement.Checked And Not chkImprovement.Checked And Not chkBugFix.Checked Then
                loEx.Add("RVT00100_01", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "RVT00100_01"))
                Exit Try
            End If

            ' Save
            loLicense = New RVT00100ReleaseDTO
            With loLicense
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = cboApplication.SelectedValue.Trim
                .CUSER_ID = _CUSERID
                .CRELEASE_DATE = Today.ToString("yyyyMMdd")
                .LVERSION_1 = chkMajor.Checked
                .LVERSION_2 = chkEnhancement.Checked
                .LVERSION_3 = chkImprovement.Checked
                .LVERSION_4 = chkBugFix.Checked
            End With
            loSvc.ReleaseVersion(loLicense)

            RefreshGrids()

        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loEx.Haserror Then
            R_DisplayException(loEx)
        End If

    End Sub

    Private Sub btnLog_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnLog.R_Before_Open_Form
        Dim loEx As New R_Exception
        poTargetForm = New RVT00100Log
        poParameter = New RVT00100GridDTO

        Try
            With CType(poParameter, RVT00100GridDTO)
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = cboApplication.SelectedValue.Trim
                .CVERSION = bsGvAppVer.Current._CVERSION
                .CUPDATE_BY = _CUSERID
                .CCREATE_BY = _CUSERID
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub btnIncludes_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnIncludes.R_Before_Open_Form
        Dim loEx As New R_Exception
        poTargetForm = New RVT00100Includes
        poParameter = New RVT00100GridDTO

        Try
            With CType(poParameter, RVT00100GridDTO)
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = cboApplication.SelectedValue.Trim
                .CVERSION = bsGvAppVer.Current._CVERSION
                .CUPDATE_BY = _CUSERID
                .CCREATE_BY = _CUSERID
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loEx.ThrowExceptionIfErrors()

    End Sub
End Class
