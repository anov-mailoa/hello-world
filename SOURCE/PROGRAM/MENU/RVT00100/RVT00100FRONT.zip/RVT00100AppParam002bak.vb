﻿Imports RVT00100FrontResources
Imports R_Common
Imports ClientHelper
Imports RVT00100Front.RVT00100AppParam002ServiceRef
Imports R_FrontEnd
Imports RVT00100Front.RVT00100AppParam002StreamingServiceRef
Imports System.ServiceModel.Channels

Public Class RVT00100AppParam002bak

#Region " VARIABLE "
    Dim C_ServiceName As String = "RVT00100Service/RVT00100AppParam002Service.svc"
    Dim C_ServiceNameStream As String = "RVT00100Service/RVT00100AppParam002StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPS_CODE As String
    Dim _CATTRIBUTEGROUP As String
    Dim _CATTRIBUTEID As String
    Dim _CCUSTOMER_CODE As String
    Dim _CPARAMETER_ID As String
#End Region

#Region " E V E N T S "

    Private Sub RVT00100AppParam_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            ' Application
            With CType(poParameter, RVT00100ParamDTO)
                txtApplication.Text = .CAPPS_NAME
                _CAPPS_CODE = .CAPPS_CODE
            End With

            ' Parameter group combo
            Dim loParamGroupCombo As New List(Of RVT00100ParameterGroupComboDTO)
            cboParameterGroup.Items.Clear()
            loParamGroupCombo.Add(New RVT00100ParameterGroupComboDTO With {.CPARAMETER_GROUP = "FRONT"})
            loParamGroupCombo.Add(New RVT00100ParameterGroupComboDTO With {.CPARAMETER_GROUP = "BACK"})
            loParamGroupCombo.Add(New RVT00100ParameterGroupComboDTO With {.CPARAMETER_GROUP = "PUBLISHER"})
            loParamGroupCombo.Add(New RVT00100ParameterGroupComboDTO With {.CPARAMETER_GROUP = "DATABASE"})

            bsParamGroup.DataSource = loParamGroupCombo

            With gvAppParam
                .R_ShowProgressBar = False
                .R_ShowRefreshButton = False
            End With

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " G R I D V I E W "

    Private Sub gvAppParam_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs)
        gvAppParam.BestFitColumns()
    End Sub

    Private Sub gvAppParam_R_Before_Open_LookUpForm(sender As Object, e As Telerik.WinControls.UI.EditorRequiredEventArgs, ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object)
        If gvAppParam.CurrentColumn.Name.Trim.Equals("_CITEM_ID") Then
            poTargetForm = New RVT00100ItemList
            poParameter = New RVT00100ItemKeyDTO With {.CCOMPANY_ID = _CCOMPID, _
                                                        .CAPPS_CODE = _CAPPS_CODE, _
                                                        .CATTRIBUTE_GROUP = _CATTRIBUTEGROUP, _
                                                        .CATTRIBUTE_ID = _CATTRIBUTEID}
        End If
    End Sub

    Private Sub gvAppParam_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode)
        _CPARAMETER_ID = CType(bsGvAppParam.Current, RVT00100AppParam002DTO)._CPARAMETER_ID
    End Sub

    Private Sub gvAppParam_R_Return_LookUp(sender As Object, e As Telerik.WinControls.UI.EditorRequiredEventArgs, poReturnObject As Object)
        If gvAppParam.CurrentColumn.Name.Trim.Equals("_CITEM_ID") Then
            gvAppParam.CurrentRow.Cells("_CITEM_ID").Value = poReturnObject.CITEM_ID
            gvAppParam.CurrentRow.Cells("_CATTRIBUTE_GROUP").Value = poReturnObject.CATTRIBUTE_GROUP
            _CATTRIBUTEGROUP = poReturnObject.CATTRIBUTE_GROUP
            gvAppParam.CurrentRow.Cells("_CATTRIBUTE_ID").Value = poReturnObject.CATTRIBUTE_ID
            _CATTRIBUTEID = poReturnObject.CATTRIBUTE_ID
        End If
    End Sub

    Private Sub gvAppParam_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode)
        With CType(poEntity, RVT00100AppParam002DTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = _CAPPS_CODE
            ._CCREATE_BY = _CUSERID
            ._CUPDATE_BY = _CUSERID
        End With
    End Sub

    Private Sub gvAppParam_R_ServiceDelete(poEntity As Object)
        Dim loService As RVT00100AppParam002ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100AppParam002Service, RVT00100AppParam002ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String

        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

    Private Sub gvAppParam_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object)
        Dim loServiceStream As RVT00100AppParam002StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100AppParam002StreamingService, RVT00100AppParam002StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of RVT00100AppParam002GridDTO)
        Dim loListEntity As New List(Of RVT00100AppParam002DTO)

        Try
            With CType(poEntity, RVT00100AppParam002KeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cParameterGroup", .CPARAMETER_GROUP)
            End With

            loRtn = loServiceStream.GetParameters()
            loStreaming = R_StreamUtility(Of RVT00100AppParam002GridDTO).ReadFromMessage(loRtn)

            For Each loDto As RVT00100AppParam002GridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New RVT00100AppParam002DTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                           ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                           ._CATTRIBUTE_GROUP = loDto.CATTRIBUTE_GROUP,
                                                           ._CATTRIBUTE_ID = loDto.CATTRIBUTE_ID,
                                                           ._CITEM_ID = loDto.CITEM_ID,
                                                                      ._CSOURCE_GROUP_ID = loDto.CSOURCE_GROUP_ID})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvAppParam_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object)
        Dim loService As RVT00100AppParam002ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100AppParam002Service, RVT00100AppParam002ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New RVT00100AppParam002DTO With {._CCOMPANY_ID = _CCOMPID, _
                                                                                        ._CAPPS_CODE = _CAPPS_CODE, _
                                                                                        ._CPARAMETER_ID = CType(bsGvAppParam.Current, RVT00100AppParam002DTO)._CPARAMETER_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvAppParam_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object)
        Dim loService As RVT00100AppParam002ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100AppParam002Service, RVT00100AppParam002ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

End Class
