﻿Imports RVT00100Front.RVT00100RevisionServiceRef
Imports R_FrontEnd
Imports R_Common
Imports System.ServiceModel.Channels
Imports RVT00100Front.RVT00100ServiceRef
Imports RVT00100Front.RVT00100StreamingServiceRef

Public Class RVT00100Revision

#Region " VARIABLE "
    Dim C_ServiceName As String = "RVT00100Service/RVT00100Service.svc"
    Dim C_ServiceNameStream As String = "RVT00100Service/RVT00100StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPS_CODE As String
    Dim _CVERSION As String
    Dim llInitialized As Boolean = False
#End Region

#Region " F O R M "

    Private Sub RVT00100Revisions_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        With CType(poParameter, RVT00100ParamDTO)
            lblAppVersion.Text = .CAPPS_CODE.Trim + " ver " + .CVERSION
            _CUSERID = .CUSER_ID
            _CCOMPID = .CCOMPANY_ID
            _CAPPS_CODE = .CAPPS_CODE
            _CVERSION = .CVERSION
        End With
        ' Main grid
        Dim loTableKey As New RVT00100Front.RVT00100StreamingServiceRef.RVT00100GridDTO
        With loTableKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = _CAPPS_CODE
            .CVERSION = _CVERSION
        End With
        gvRevisions.R_RefreshGrid(loTableKey)
    End Sub

    Private Sub RVT00100Revisions_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " G R I D V I E W "

    Private Sub gvRevisions_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvRevisions.R_ServiceGetListRecord
        Dim loServiceStream As RVT00100StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100StreamingService, RVT00100StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of RVT00100RevisionGridDTO)
        Dim loListEntity As New List(Of RVT00100RevisionDTO)

        Try
            With poEntity
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
            End With

            loRtn = loServiceStream.GetRevisions()
            loStreaming = R_StreamUtility(Of RVT00100RevisionGridDTO).ReadFromMessage(loRtn)

            For Each loDto As RVT00100RevisionGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New RVT00100RevisionDTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                           ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                           ._CVERSION = loDto.CVERSION,
                                                           ._CREVISION = loDto.CREVISION,
                                                           ._DRELEASE_DATE = loDto.DRELEASE_DATE,
                                                           ._CRELEASE_BY = loDto.CRELEASE_BY,
                                                           ._CCREATE_BY = loDto.CCREATE_BY,
                                                           ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                           ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                           ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()

    End Sub

#End Region

End Class
