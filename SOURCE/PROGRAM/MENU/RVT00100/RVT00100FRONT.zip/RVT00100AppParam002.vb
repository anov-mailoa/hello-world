﻿Imports R_Common
Imports ClientHelper
Imports RVT00100Front.RVT00100AppParam002ServiceRef
Imports RVT00100Front.RVT00100AppParam002StreamingServiceRef
Imports R_FrontEnd
Imports System.ServiceModel.Channels
Imports RVT00100FrontResources

Public Class RVT00100AppParam002

#Region " VARIABLE "
    Dim C_ServiceName As String = "RVT00100Service/RVT00100AppParam002Service.svc"
    Dim C_ServiceNameStream As String = "RVT00100Service/RVT00100AppParam002StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPS_CODE As String
    Dim _CATTRIBUTEGROUP As String
    Dim _CATTRIBUTEID As String
    Dim _CPARAMETER_ID As String
    Dim _CPARAMETER_GROUP As String
    Dim _LINIT As Boolean
    Dim _CITEMATTRIBUTEID As String
#End Region

#Region " S U B  &  F U N C T I O N "

    Private Sub RefreshGrids()
        Dim loTableKey As New RVT00100AppParam002KeyDTO
        Dim llSrcGrpVisible As Boolean
        Dim llItemVisible As Boolean
        Dim llItemEnabled As Boolean
        Dim llItemAttributeVisible As Boolean

        If _LINIT Then
            With loTableKey
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = _CAPPS_CODE
                .CPARAMETER_GROUP = cboParameterGroup.SelectedValue.ToString.Trim
            End With
            With gvAppParam
                llSrcGrpVisible = cboParameterGroup.SelectedValue.Equals("FRONT-PRG") _
                    Or cboParameterGroup.SelectedValue.Equals("FRONT-RES") _
                    Or cboParameterGroup.SelectedValue.Equals("BACK") _
                    Or cboParameterGroup.SelectedValue.Equals("SERVICE")
                llItemVisible = cboParameterGroup.SelectedValue.Equals("FRONT-MAIN") _
                    Or cboParameterGroup.SelectedValue.Equals("FRONT-PRG") _
                    Or cboParameterGroup.SelectedValue.Equals("FRONT-RES") _
                    Or cboParameterGroup.SelectedValue.Equals("BACK") _
                    Or cboParameterGroup.SelectedValue.Equals("SERVICE")
                llItemAttributeVisible = cboParameterGroup.SelectedValue.Equals("FRONT-PRG") _
                    Or cboParameterGroup.SelectedValue.Equals("FRONT-RES") _
                    Or cboParameterGroup.SelectedValue.Equals("BACK") _
                    Or cboParameterGroup.SelectedValue.Equals("SERVICE")
                llItemEnabled = cboParameterGroup.SelectedValue.Equals("FRONT-PRG") _
                    Or cboParameterGroup.SelectedValue.Equals("FRONT-RES") _
                    Or cboParameterGroup.SelectedValue.Equals("BACK") _
                    Or cboParameterGroup.SelectedValue.Equals("SERVICE")
                .Columns("_CITEM_ATTRIBUTE_ID").IsVisible = llItemAttributeVisible
                .Columns("_CITEM_ID").IsVisible = llItemVisible
                .Columns("_CSOURCE_ID").IsVisible = llItemVisible
                .Columns("_CSOURCE_GROUP_ID").IsVisible = llSrcGrpVisible
                CType(.Columns("_CSOURCE_ID"), R_GridViewLookUpColumn).R_EnableEDIT = llItemEnabled
                If cboParameterGroup.SelectedValue.Equals("BACK") _
                    Or cboParameterGroup.SelectedValue.Equals("SERVICE") Then
                    ' Publisher setting
                    CType(.Columns("_CITEM_ATTRIBUTE_ID"), R_GridViewTextBoxColumn).HeaderText = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_CITEM_ATTRIBUTE_ID_PUB")
                    CType(.Columns("_CITEM_ID"), R_GridViewTextBoxColumn).HeaderText = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_CITEM_ID_PUB")
                    CType(.Columns("_CSOURCE_ID"), R_GridViewLookUpColumn).HeaderText = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_CSOURCE_ID_PUB")
                ElseIf cboParameterGroup.SelectedValue.Equals("FRONT-PRG") _
                    Or cboParameterGroup.SelectedValue.Equals("FRONT-RES") Then
                    ' Front Main setting
                    CType(.Columns("_CITEM_ATTRIBUTE_ID"), R_GridViewTextBoxColumn).HeaderText = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_CITEM_ATTRIBUTE_ID_FRONT")
                    CType(.Columns("_CITEM_ID"), R_GridViewTextBoxColumn).HeaderText = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_CITEM_ID_FRONT")
                    CType(.Columns("_CSOURCE_ID"), R_GridViewLookUpColumn).HeaderText = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_CSOURCE_ID_FRONT")
                Else
                    CType(.Columns("_CITEM_ID"), R_GridViewTextBoxColumn).HeaderText = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_CITEM_ID")
                    CType(.Columns("_CSOURCE_ID"), R_GridViewLookUpColumn).HeaderText = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_CSOURCE_ID")
                End If
                .R_RefreshGrid(loTableKey)
            End With
        End If
    End Sub

#End Region

#Region " FORM Events "

    Private Sub CST00200IssueClass_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            _LINIT = False

            ' Application
            With CType(poParameter, RVT00100ParamDTO)
                txtApplication.Text = .CAPPS_NAME
                _CAPPS_CODE = .CAPPS_CODE
            End With

            ' Parameter group combo
            Dim loParamGroupCombo As New List(Of RVT00100ParameterGroupComboDTO)
            cboParameterGroup.Items.Clear()
            loParamGroupCombo.Add(New RVT00100ParameterGroupComboDTO With {.CPARAMETER_GROUP = "FRONT-MAIN"})
            loParamGroupCombo.Add(New RVT00100ParameterGroupComboDTO With {.CPARAMETER_GROUP = "FRONT-PRG"})
            loParamGroupCombo.Add(New RVT00100ParameterGroupComboDTO With {.CPARAMETER_GROUP = "FRONT-RES"})
            loParamGroupCombo.Add(New RVT00100ParameterGroupComboDTO With {.CPARAMETER_GROUP = "BACK"})
            loParamGroupCombo.Add(New RVT00100ParameterGroupComboDTO With {.CPARAMETER_GROUP = "SERVICE"})
            'loParamGroupCombo.Add(New RVT00100ParameterGroupComboDTO With {.CPARAMETER_GROUP = "PUBLISHER"})
            bsParamGroup.DataSource = loParamGroupCombo
            _LINIT = True
            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub CST00200_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " G R I D V I E W "

    Private Sub gvAppParam_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvAppParam.DataBindingComplete
        gvAppParam.BestFitColumns()
    End Sub

    Private Sub gvAppParam_R_Before_Open_LookUpForm(sender As Object, e As Telerik.WinControls.UI.EditorRequiredEventArgs, ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles gvAppParam.R_Before_Open_LookUpForm
        If gvAppParam.CurrentColumn.Name.Trim.Equals("_CSOURCE_ID") Then
            poTargetForm = New RVT00100ItemList
            poParameter = New RVT00100ItemListParamDTO With {.CCOMPANY_ID = _CCOMPID, _
                                                        .CAPPS_CODE = _CAPPS_CODE, _
                                                        .CATTRIBUTE_GROUP = "PROGRAM", _
                                                        .CATTRIBUTE_ID = IIf(cboParameterGroup.SelectedValue.Equals("FRONT-MAIN"), _CATTRIBUTEID, _CITEMATTRIBUTEID), _
                                                             .CPARAMETER_GROUP = _CPARAMETER_GROUP}
        ElseIf gvAppParam.CurrentColumn.Name.Trim.Equals("_CSOURCE_GROUP_ID") Then
            poTargetForm = New RVT00100SourceGroupList
            poParameter = New RVT00100ItemKeyDTO With {.CCOMPANY_ID = _CCOMPID, _
                                                        .CAPPS_CODE = _CAPPS_CODE, _
                                                        .CATTRIBUTE_GROUP = "PROGRAM", _
                                                        .CATTRIBUTE_ID = _CATTRIBUTEID}
        End If
    End Sub

    Private Sub gvAppParam_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvAppParam.R_Display
        _CPARAMETER_ID = CType(bsGvAppParam.Current, RVT00100AppParam002DTO)._CPARAMETER_ID
        _CATTRIBUTEGROUP = CType(bsGvAppParam.Current, RVT00100AppParam002DTO)._CATTRIBUTE_GROUP
        _CATTRIBUTEID = CType(bsGvAppParam.Current, RVT00100AppParam002DTO)._CATTRIBUTE_ID
    End Sub

    Private Sub gvAppParam_R_Return_LookUp(sender As Object, e As Telerik.WinControls.UI.EditorRequiredEventArgs, poReturnObject As Object) Handles gvAppParam.R_Return_LookUp
        If gvAppParam.CurrentColumn.Name.Trim.Equals("_CSOURCE_ID") Then
            gvAppParam.CurrentRow.Cells("_CITEM_ID").Value = poReturnObject.CPROGRAM_ID
            gvAppParam.CurrentRow.Cells("_CSOURCE_ID").Value = poReturnObject.CSOURCE_ID
            If cboParameterGroup.SelectedValue.Equals("FRONT-PRG") _
                Or cboParameterGroup.SelectedValue.Equals("FRONT-RES") _
                Or cboParameterGroup.SelectedValue.Equals("BACK") _
                Or cboParameterGroup.SelectedValue.Equals("SERVICE") Then
                gvAppParam.CurrentRow.Cells("_CITEM_ATTRIBUTE_ID").Value = poReturnObject.CATTRIBUTE_ID
                _CITEMATTRIBUTEID = poReturnObject.CATTRIBUTE_ID
            Else
                gvAppParam.CurrentRow.Cells("_CATTRIBUTE_ID").Value = poReturnObject.CATTRIBUTE_ID
                _CATTRIBUTEID = poReturnObject.CATTRIBUTE_ID
            End If

        ElseIf gvAppParam.CurrentColumn.Name.Trim.Equals("_CSOURCE_GROUP_ID") Then
            gvAppParam.CurrentRow.Cells("_CSOURCE_GROUP_ID").Value = poReturnObject.CSOURCE_GROUP_ID
            gvAppParam.CurrentRow.Cells("_CATTRIBUTE_ID").Value = poReturnObject.CATTRIBUTE_ID
            _CATTRIBUTEID = poReturnObject.CATTRIBUTE_ID
        End If
    End Sub

    Private Sub gvAppParam_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvAppParam.R_Saving
        With CType(poEntity, RVT00100AppParam002DTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = _CAPPS_CODE
            ._CATTRIBUTE_GROUP = "PROGRAM"
            If cboParameterGroup.SelectedValue.Equals("FRONT-MAIN") Then
                ._CSOURCE_GROUP_ID = ""
            End If
            ._CPARAMETER_GROUP = cboParameterGroup.SelectedValue.ToString.Trim
            ._CCREATE_BY = _CUSERID
            ._CUPDATE_BY = _CUSERID
        End With
    End Sub

    Private Sub gvAppParam_R_ServiceDelete(poEntity As Object) Handles gvAppParam.R_ServiceDelete
        Dim loService As RVT00100AppParam002ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100AppParam002Service, RVT00100AppParam002ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String

        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

    Private Sub gvAppParam_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvAppParam.R_ServiceGetListRecord
        Dim loServiceStream As RVT00100AppParam002StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100AppParam002StreamingService, RVT00100AppParam002StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of RVT00100AppParam002GridDTO)
        Dim loListEntity As New List(Of RVT00100AppParam002DTO)

        Try
            With CType(poEntity, RVT00100AppParam002KeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cParameterGroup", .CPARAMETER_GROUP)
            End With

            loRtn = loServiceStream.GetParameters()
            loStreaming = R_StreamUtility(Of RVT00100AppParam002GridDTO).ReadFromMessage(loRtn)

            For Each loDto As RVT00100AppParam002GridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New RVT00100AppParam002DTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                                      ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                                      ._CPARAMETER_ID = loDto.CPARAMETER_ID,
                                                                      ._CATTRIBUTE_GROUP = loDto.CATTRIBUTE_GROUP,
                                                                      ._CATTRIBUTE_ID = loDto.CATTRIBUTE_ID,
                                                                      ._CITEM_ID = loDto.CITEM_ID,
                                                                      ._CSOURCE_GROUP_ID = loDto.CSOURCE_GROUP_ID,
                                                                      ._CSOURCE_ID = loDto.CSOURCE_ID,
                                                                      ._CITEM_ATTRIBUTE_ID = loDto.CITEM_ATTRIBUTE_ID})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvAppParam_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvAppParam.R_ServiceGetRecord
        Dim loService As RVT00100AppParam002ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100AppParam002Service, RVT00100AppParam002ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New RVT00100AppParam002DTO With {._CCOMPANY_ID = _CCOMPID, _
                                                                                        ._CAPPS_CODE = _CAPPS_CODE, _
                                                                                        ._CPARAMETER_ID = CType(bsGvAppParam.Current, RVT00100AppParam002DTO)._CPARAMETER_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvAppParam_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvAppParam.R_ServiceSave
        Dim loService As RVT00100AppParam002ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100AppParam002Service, RVT00100AppParam002ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim lcErr As String

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
            lcErr = loEx.ErrorList(0).ErrDescp
            loEx.ErrorList.Clear()
            loEx.Add(lcErr, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcErr))
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " Parameter Group C O M B O "

    Private Sub cboParameterGroup_SelectedIndexChanged(sender As System.Object, e As Telerik.WinControls.UI.Data.PositionChangedEventArgs) Handles cboParameterGroup.SelectedIndexChanged
        _CPARAMETER_GROUP = cboParameterGroup.SelectedValue
        With gvAppParam
            RefreshGrids()
        End With
    End Sub

#End Region

End Class
