﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RVT00100Log
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewComboBoxColumn1 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Dim R_GridViewComboBoxColumn2 As R_FrontEnd.R_GridViewComboBoxColumn = New R_FrontEnd.R_GridViewComboBoxColumn()
        Dim R_GridViewTextBoxMultilineColumn1 As R_FrontEnd.R_GridViewTextBoxMultilineColumn = New R_FrontEnd.R_GridViewTextBoxMultilineColumn()
        Me.bsAppUnit = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsLogType = New System.Windows.Forms.BindingSource(Me.components)
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblAppVersion = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvVersionLog = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvVersionLog = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridVersionLog = New R_FrontEnd.R_ConductorGrid(Me.components)
        CType(Me.bsAppUnit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsLogType, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.lblAppVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvVersionLog, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvVersionLog.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvVersionLog, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridVersionLog, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'bsAppUnit
        '
        Me.bsAppUnit.DataSource = GetType(RVT00100Front.RVT00100LogServiceRef.RVT00100AppUnitComboDTO)
        '
        'bsLogType
        '
        Me.bsLogType.DataSource = GetType(RVT00100Front.RVT00100LogServiceRef.RVT00100LogTypeComboDTO)
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.gvVersionLog, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lblAppVersion)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 24)
        Me.Panel1.TabIndex = 0
        '
        'lblAppVersion
        '
        Me.lblAppVersion.AutoSize = False
        Me.lblAppVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblAppVersion.Location = New System.Drawing.Point(9, 3)
        Me.lblAppVersion.Name = "lblAppVersion"
        Me.lblAppVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblAppVersion.R_ResourceId = Nothing
        Me.lblAppVersion.Size = New System.Drawing.Size(564, 18)
        Me.lblAppVersion.TabIndex = 0
        Me.lblAppVersion.Text = "R_RadLabel1"
        '
        'gvVersionLog
        '
        Me.gvVersionLog.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvVersionLog.EnableFastScrolling = True
        Me.gvVersionLog.Location = New System.Drawing.Point(3, 33)
        '
        '
        '
        Me.gvVersionLog.MasterTemplate.AutoGenerateColumns = False
        Me.gvVersionLog.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewComboBoxColumn1.DataSource = Me.bsAppUnit
        R_GridViewComboBoxColumn1.DisplayMember = "CAPP_UNIT"
        R_GridViewComboBoxColumn1.FieldName = "_CAPP_UNIT"
        R_GridViewComboBoxColumn1.HeaderText = "_CAPP_UNIT"
        R_GridViewComboBoxColumn1.MinWidth = 200
        R_GridViewComboBoxColumn1.Name = "_CAPP_UNIT"
        R_GridViewComboBoxColumn1.R_EnableADD = True
        R_GridViewComboBoxColumn1.R_ResourceId = "_CAPP_UNIT"
        R_GridViewComboBoxColumn1.ValueMember = "CAPP_UNIT"
        R_GridViewComboBoxColumn1.Width = 352
        R_GridViewComboBoxColumn2.DataSource = Me.bsLogType
        R_GridViewComboBoxColumn2.DisplayMember = "CLOG_TYPE"
        R_GridViewComboBoxColumn2.FieldName = "_CLOG_TYPE"
        R_GridViewComboBoxColumn2.HeaderText = "_CLOG_TYPE"
        R_GridViewComboBoxColumn2.MinWidth = 200
        R_GridViewComboBoxColumn2.Name = "_CLOG_TYPE"
        R_GridViewComboBoxColumn2.R_EnableADD = True
        R_GridViewComboBoxColumn2.R_ResourceId = "_CLOG_TYPE"
        R_GridViewComboBoxColumn2.ValueMember = "CLOG_TYPE"
        R_GridViewComboBoxColumn2.Width = 352
        R_GridViewTextBoxMultilineColumn1.FieldName = "_CLOG_CONTENT"
        R_GridViewTextBoxMultilineColumn1.HeaderText = "_CLOG_CONTENT"
        R_GridViewTextBoxMultilineColumn1.Name = "_CLOG_CONTENT"
        R_GridViewTextBoxMultilineColumn1.R_EnableADD = True
        R_GridViewTextBoxMultilineColumn1.R_EnableEDIT = True
        R_GridViewTextBoxMultilineColumn1.R_ResourceId = "_CLOG_CONTENT"
        R_GridViewTextBoxMultilineColumn1.R_UDT = Nothing
        R_GridViewTextBoxMultilineColumn1.ReadOnly = True
        R_GridViewTextBoxMultilineColumn1.Width = 549
        R_GridViewTextBoxMultilineColumn1.WrapText = True
        Me.gvVersionLog.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewComboBoxColumn1, R_GridViewComboBoxColumn2, R_GridViewTextBoxMultilineColumn1})
        Me.gvVersionLog.MasterTemplate.DataSource = Me.bsGvVersionLog
        Me.gvVersionLog.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvVersionLog.MasterTemplate.EnableFiltering = True
        Me.gvVersionLog.MasterTemplate.EnableGrouping = False
        Me.gvVersionLog.MasterTemplate.ShowFilteringRow = False
        Me.gvVersionLog.MasterTemplate.ShowGroupedColumns = True
        Me.gvVersionLog.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvVersionLog.Name = "gvVersionLog"
        Me.gvVersionLog.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvVersionLog.R_ConductorGridSource = Me.conGridVersionLog
        Me.gvVersionLog.R_ConductorSource = Nothing
        Me.gvVersionLog.R_DataAdded = False
        Me.gvVersionLog.R_NewRowText = Nothing
        Me.gvVersionLog.ShowHeaderCellButtons = True
        Me.gvVersionLog.Size = New System.Drawing.Size(1271, 539)
        Me.gvVersionLog.TabIndex = 1
        Me.gvVersionLog.Text = "R_RadGridView1"
        '
        'bsGvVersionLog
        '
        Me.bsGvVersionLog.DataSource = GetType(RVT00100Front.RVT00100LogServiceRef.RVT00100LogDTO)
        '
        'conGridVersionLog
        '
        Me.conGridVersionLog.R_ConductorParent = Nothing
        Me.conGridVersionLog.R_IsHeader = True
        Me.conGridVersionLog.R_RadGroupBox = Nothing
        '
        'RVT00100Log
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "RVT00100Log"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "Log"
        CType(Me.bsAppUnit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsLogType, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me.lblAppVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvVersionLog.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvVersionLog, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvVersionLog, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridVersionLog, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblAppVersion As R_FrontEnd.R_RadLabel
    Friend WithEvents gvVersionLog As R_FrontEnd.R_RadGridView
    Friend WithEvents bsGvVersionLog As System.Windows.Forms.BindingSource
    Friend WithEvents bsAppUnit As System.Windows.Forms.BindingSource
    Friend WithEvents bsLogType As System.Windows.Forms.BindingSource
    Friend WithEvents conGridVersionLog As R_FrontEnd.R_ConductorGrid

End Class
