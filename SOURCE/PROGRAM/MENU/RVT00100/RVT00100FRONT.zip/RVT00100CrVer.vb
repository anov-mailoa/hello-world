﻿Imports RVT00100FrontResources
Imports R_Common
Imports ClientHelper
Imports RVT00100Front.RVT00100ServiceRef
Imports R_FrontEnd
Imports Telerik.WinControls.UI

Public Class RVT00100CrVer

#Region " VARIABLE "
    Dim C_ServiceName As String = "RVT00100Service/RVT00100Service.svc"
    Dim C_ServiceNameStream As String = "RVT00100Service/RVT00100StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPS_CODE As String
    Dim _CCUSTOMER_CODE As String
    Dim _CMAJOR As String
    Dim _CMINOR As String
#End Region

#Region " E V E N T S "

    Private Sub RVT00100CrVer_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            spnMajor.Enabled = True
            spnMinor.Enabled = True
            btnCreate.Enabled = True

            ' Application
            With CType(poParameter, RVT00100ParamDTO)
                txtApplication.Text = .CAPPS_NAME
                _CAPPS_CODE = .CAPPS_CODE
                _CMAJOR = .CMAJOR
                _CMINOR = .CMINOR
            End With
            txtVersion.Text = CInt(_CMAJOR).ToString.Trim + "." + _CMINOR.Trim
            spnMajor.Minimum = CInt(_CMAJOR)
            spnMinor.Minimum = CInt(_CMINOR)

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub btnCreate_Click(sender As System.Object, e As System.EventArgs) Handles btnCreate.Click
        Dim loEx As New R_Exception
        Dim loSvc As RVT00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IRVT00100Service, RVT00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loKey As RVT00100CrVerDTO
        Dim lcRtn As String

        Try
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
            btnCreate.Enabled = False

            ' Create
            loKey = New RVT00100CrVerDTO
            With loKey
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = _CAPPS_CODE
                .CINCREMENT = IIf(rdbMajor.IsChecked, "1", IIf(rdbMinor.IsChecked, "2", IIf(rdbSkip.IsChecked, "3", "4")))
                .CSKIP_MAJOR = IIf(rdbSkip.IsChecked, spnMajor.Value, IIf(rdbSPack.IsChecked, _CMAJOR, ""))
                .CSKIP_MINOR = IIf(rdbSkip.IsChecked, spnMinor.Value, IIf(rdbSPack.IsChecked, _CMINOR, ""))
                .CALIAS = txtAlias.Text
                .CCODE_NAME = txtCodeName.Text
                .CUSER_ID = _CUSERID
                .CNOTE = txtNote.Text
            End With
            lcRtn = loSvc.CreateVersion(loKey)
            If Not lcRtn.Equals("OK") Then
                loEx.Add(lcRtn, R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), lcRtn))
            End If
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        End Try
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        If loEx.Haserror Then
            R_DisplayException(ErrorHandler.ConvertError(loEx))
        End If
        Me.R_CloseDock()
    End Sub

    Private Sub rdbSkip_ToggleStateChanged(sender As System.Object, args As Telerik.WinControls.UI.StateChangedEventArgs) Handles rdbSkip.ToggleStateChanged
        With CType(sender, R_RadRadioButton)
            spnMajor.Enabled = .IsChecked
            spnMinor.Enabled = .IsChecked
        End With
    End Sub

    Private Sub spnMajor_ValueChanged(sender As Object, e As EventArgs) Handles spnMajor.ValueChanged
        spnMinor.Minimum = IIf(CType(sender, R_RadSpinEditor).Value = CInt(_CMAJOR), CInt(_CMINOR), 0)
    End Sub

#End Region

End Class
