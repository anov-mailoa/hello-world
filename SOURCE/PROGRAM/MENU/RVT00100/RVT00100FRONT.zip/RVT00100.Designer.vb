﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class RVT00100
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn31 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn32 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn33 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn34 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn13 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn35 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn14 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn36 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn37 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn38 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn15 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn39 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn16 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn40 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnRevise = New R_FrontEnd.R_RadButton(Me.components)
        Me.conGridAppVer = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.btnClose = New R_FrontEnd.R_RadButton(Me.components)
        Me.lblPackageStatus = New R_FrontEnd.R_RadLabel(Me.components)
        Me.pbPackageStatus = New R_FrontEnd.R_RadProgressBar(Me.components)
        Me.chkRecoverVersion = New R_FrontEnd.R_RadCheckBox(Me.components)
        Me.btnRerelease = New R_FrontEnd.R_RadButton(Me.components)
        Me.btnSetting = New R_FrontEnd.R_Detail(Me.components)
        Me.btnCreate = New R_FrontEnd.R_Detail(Me.components)
        Me.cboApplication = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.btnRelease = New R_FrontEnd.R_RadButton(Me.components)
        Me.lblAppVersion = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadLabel1 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.gvAppVer = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvAppVer = New System.Windows.Forms.BindingSource(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.txtCodeName = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtAlias = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblCodeName = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblAlias = New R_FrontEnd.R_RadLabel(Me.components)
        Me.btnSaveVersion = New R_FrontEnd.R_RadButton(Me.components)
        Me.txtNote = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblVersionNote = New R_FrontEnd.R_RadLabel(Me.components)
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.gvRevisions = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvRevision = New System.Windows.Forms.BindingSource(Me.components)
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btnSaveRevision = New R_FrontEnd.R_RadButton(Me.components)
        Me.txtRevNote = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblRevisionNote = New R_FrontEnd.R_RadLabel(Me.components)
        Me.preLog = New R_FrontEnd.R_PredefinedDock(Me.components)
        Me.preInclude = New R_FrontEnd.R_PredefinedDock(Me.components)
        Me.bwPackageStatus = New System.ComponentModel.BackgroundWorker()
        Me.conGridRevisions = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.btnRevise, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridAppVer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnClose, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblPackageStatus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbPackageStatus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chkRecoverVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnRerelease, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnSetting, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnCreate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnRelease, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblAppVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel2.SuspendLayout()
        CType(Me.gvAppVer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvAppVer.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvAppVer, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.txtCodeName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtAlias, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCodeName, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblAlias, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnSaveVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtNote, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblVersionNote, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel3.SuspendLayout()
        CType(Me.gvRevisions, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvRevisions.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvRevision, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.btnSaveRevision, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtRevNote, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblRevisionNote, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridRevisions, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel4.SuspendLayout()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle())
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.TableLayoutPanel2, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.TableLayoutPanel3, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.TableLayoutPanel4, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 4
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 108.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 48.96552!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 51.03448!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnRevise)
        Me.Panel1.Controls.Add(Me.btnClose)
        Me.Panel1.Controls.Add(Me.lblPackageStatus)
        Me.Panel1.Controls.Add(Me.pbPackageStatus)
        Me.Panel1.Controls.Add(Me.chkRecoverVersion)
        Me.Panel1.Controls.Add(Me.btnRerelease)
        Me.Panel1.Controls.Add(Me.btnSetting)
        Me.Panel1.Controls.Add(Me.btnCreate)
        Me.Panel1.Controls.Add(Me.cboApplication)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Controls.Add(Me.btnRelease)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 102)
        Me.Panel1.TabIndex = 3
        '
        'btnRevise
        '
        Me.btnRevise.Location = New System.Drawing.Point(119, 69)
        Me.btnRevise.Name = "btnRevise"
        Me.btnRevise.R_ConductorGridSource = Me.conGridAppVer
        Me.btnRevise.R_ConductorSource = Nothing
        Me.btnRevise.R_DescriptionId = Nothing
        Me.btnRevise.R_EnableHASDATA = True
        Me.btnRevise.R_ResourceId = "btnRevise"
        Me.btnRevise.Size = New System.Drawing.Size(110, 24)
        Me.btnRevise.TabIndex = 21
        Me.btnRevise.Text = "btnRevise"
        '
        'conGridAppVer
        '
        Me.conGridAppVer.R_ConductorParent = Nothing
        Me.conGridAppVer.R_IsHeader = True
        Me.conGridAppVer.R_RadGroupBox = Nothing
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(3, 69)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.R_ConductorGridSource = Me.conGridAppVer
        Me.btnClose.R_ConductorSource = Nothing
        Me.btnClose.R_DescriptionId = Nothing
        Me.btnClose.R_EnableHASDATA = True
        Me.btnClose.R_ResourceId = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(110, 24)
        Me.btnClose.TabIndex = 20
        Me.btnClose.Text = "btnClose"
        '
        'lblPackageStatus
        '
        Me.lblPackageStatus.AutoSize = False
        Me.lblPackageStatus.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblPackageStatus.Location = New System.Drawing.Point(831, 42)
        Me.lblPackageStatus.Name = "lblPackageStatus"
        Me.lblPackageStatus.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblPackageStatus.R_ResourceId = Nothing
        Me.lblPackageStatus.Size = New System.Drawing.Size(28, 18)
        Me.lblPackageStatus.TabIndex = 18
        Me.lblPackageStatus.Text = "Text"
        '
        'pbPackageStatus
        '
        Me.pbPackageStatus.Location = New System.Drawing.Point(467, 39)
        Me.pbPackageStatus.Name = "pbPackageStatus"
        '
        '
        '
        Me.pbPackageStatus.RootElement.UseDefaultDisabledPaint = False
        Me.pbPackageStatus.Size = New System.Drawing.Size(358, 24)
        Me.pbPackageStatus.TabIndex = 2
        '
        'chkRecoverVersion
        '
        Me.chkRecoverVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.chkRecoverVersion.Location = New System.Drawing.Point(515, 11)
        Me.chkRecoverVersion.Name = "chkRecoverVersion"
        Me.chkRecoverVersion.R_ConductorGridSource = Nothing
        Me.chkRecoverVersion.R_ConductorSource = Nothing
        Me.chkRecoverVersion.R_ResourceId = "chkRecoverVersion"
        Me.chkRecoverVersion.Size = New System.Drawing.Size(107, 18)
        Me.chkRecoverVersion.TabIndex = 17
        Me.chkRecoverVersion.Text = "R_RadCheckBox1"
        Me.chkRecoverVersion.Visible = False
        '
        'btnRerelease
        '
        Me.btnRerelease.Location = New System.Drawing.Point(351, 39)
        Me.btnRerelease.Name = "btnRerelease"
        Me.btnRerelease.R_ConductorGridSource = Me.conGridAppVer
        Me.btnRerelease.R_ConductorSource = Nothing
        Me.btnRerelease.R_DescriptionId = Nothing
        Me.btnRerelease.R_EnableHASDATA = True
        Me.btnRerelease.R_ResourceId = "btnRerelease"
        Me.btnRerelease.Size = New System.Drawing.Size(110, 24)
        Me.btnRerelease.TabIndex = 16
        Me.btnRerelease.Text = "btnPackage"
        '
        'btnSetting
        '
        Me.btnSetting.Location = New System.Drawing.Point(119, 39)
        Me.btnSetting.Name = "btnSetting"
        Me.btnSetting.R_ConductorGridSource = Nothing
        Me.btnSetting.R_ConductorSource = Nothing
        Me.btnSetting.R_DescriptionId = Nothing
        Me.btnSetting.R_ResourceId = "btnSetting"
        Me.btnSetting.R_Title = Nothing
        Me.btnSetting.Size = New System.Drawing.Size(110, 24)
        Me.btnSetting.TabIndex = 15
        Me.btnSetting.Text = "btnSetting"
        '
        'btnCreate
        '
        Me.btnCreate.Location = New System.Drawing.Point(3, 39)
        Me.btnCreate.Name = "btnCreate"
        Me.btnCreate.R_ConductorGridSource = Nothing
        Me.btnCreate.R_ConductorSource = Nothing
        Me.btnCreate.R_DescriptionId = Nothing
        Me.btnCreate.R_ResourceId = "btnCreate"
        Me.btnCreate.R_Title = Nothing
        Me.btnCreate.Size = New System.Drawing.Size(110, 24)
        Me.btnCreate.TabIndex = 14
        Me.btnCreate.Text = "btnCreateVersion"
        '
        'cboApplication
        '
        Me.cboApplication.DataSource = Me.bsApps
        Me.cboApplication.DisplayMember = "CAPPS_NAME"
        Me.cboApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboApplication.Location = New System.Drawing.Point(109, 9)
        Me.cboApplication.Name = "cboApplication"
        Me.cboApplication.R_ConductorGridSource = Nothing
        Me.cboApplication.R_ConductorSource = Nothing
        Me.cboApplication.Size = New System.Drawing.Size(400, 20)
        Me.cboApplication.TabIndex = 12
        Me.cboApplication.Text = "R_RadDropDownList1"
        Me.cboApplication.ValueMember = "CAPPS_CODE"
        '
        'bsApps
        '
        Me.bsApps.DataSource = GetType(RVT00100Front.RVT00100ServiceRef.RLicenseAppComboDTO)
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(3, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 11
        Me.lblApplication.Text = "Application..."
        '
        'btnRelease
        '
        Me.btnRelease.Location = New System.Drawing.Point(235, 39)
        Me.btnRelease.Name = "btnRelease"
        Me.btnRelease.R_ConductorGridSource = Me.conGridAppVer
        Me.btnRelease.R_ConductorSource = Nothing
        Me.btnRelease.R_DescriptionId = Nothing
        Me.btnRelease.R_EnableHASDATA = True
        Me.btnRelease.R_ResourceId = "btnRelease"
        Me.btnRelease.Size = New System.Drawing.Size(110, 24)
        Me.btnRelease.TabIndex = 8
        Me.btnRelease.Text = "btnRelease"
        '
        'lblAppVersion
        '
        Me.lblAppVersion.AutoSize = False
        Me.lblAppVersion.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblAppVersion.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblAppVersion.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAppVersion.ForeColor = System.Drawing.Color.White
        Me.lblAppVersion.Location = New System.Drawing.Point(974, 3)
        Me.lblAppVersion.Name = "lblAppVersion"
        Me.lblAppVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblAppVersion.R_ResourceId = Nothing
        Me.lblAppVersion.Size = New System.Drawing.Size(294, 16)
        Me.lblAppVersion.TabIndex = 4
        Me.lblAppVersion.Text = "Revision List"
        '
        'R_RadLabel1
        '
        Me.R_RadLabel1.AutoSize = False
        Me.R_RadLabel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.R_RadLabel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.R_RadLabel1.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.R_RadLabel1.ForeColor = System.Drawing.Color.White
        Me.R_RadLabel1.Location = New System.Drawing.Point(3, 3)
        Me.R_RadLabel1.Name = "R_RadLabel1"
        Me.R_RadLabel1.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel1.R_ResourceId = Nothing
        Me.R_RadLabel1.Size = New System.Drawing.Size(965, 16)
        Me.R_RadLabel1.TabIndex = 5
        Me.R_RadLabel1.Text = "Version List"
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel2.ColumnCount = 2
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 300.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.gvRevisions, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.gvAppVer, 0, 0)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(3, 139)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(1271, 207)
        Me.TableLayoutPanel2.TabIndex = 7
        '
        'gvAppVer
        '
        Me.gvAppVer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvAppVer.EnableFastScrolling = True
        Me.gvAppVer.Location = New System.Drawing.Point(3, 3)
        '
        '
        '
        Me.gvAppVer.MasterTemplate.AllowAddNewRow = False
        Me.gvAppVer.MasterTemplate.AutoGenerateColumns = False
        Me.gvAppVer.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn31.FieldName = "_CVERSION"
        R_GridViewTextBoxColumn31.HeaderText = "_CVERSION"
        R_GridViewTextBoxColumn31.Name = "_CVERSION"
        R_GridViewTextBoxColumn31.R_ResourceId = "_CVERSION"
        R_GridViewTextBoxColumn31.R_UDT = Nothing
        R_GridViewTextBoxColumn31.Width = 70
        R_GridViewTextBoxColumn32.FieldName = "_CALIAS"
        R_GridViewTextBoxColumn32.HeaderText = "_CALIAS"
        R_GridViewTextBoxColumn32.Name = "_CALIAS"
        R_GridViewTextBoxColumn32.R_ResourceId = "_CALIAS"
        R_GridViewTextBoxColumn32.R_UDT = Nothing
        R_GridViewTextBoxColumn32.Width = 56
        R_GridViewTextBoxColumn33.FieldName = "_CCODE_NAME"
        R_GridViewTextBoxColumn33.HeaderText = "_CCODE_NAME"
        R_GridViewTextBoxColumn33.Name = "_CCODE_NAME"
        R_GridViewTextBoxColumn33.R_ResourceId = "_CCODE_NAME"
        R_GridViewTextBoxColumn33.R_UDT = Nothing
        R_GridViewTextBoxColumn33.Width = 87
        R_GridViewTextBoxColumn34.FieldName = "_CSTATUS"
        R_GridViewTextBoxColumn34.HeaderText = "_CSTATUS"
        R_GridViewTextBoxColumn34.Name = "_CSTATUS"
        R_GridViewTextBoxColumn34.R_ResourceId = "_CSTATUS"
        R_GridViewTextBoxColumn34.R_UDT = Nothing
        R_GridViewTextBoxColumn34.Width = 65
        R_GridViewDateTimeColumn13.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn13.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn13.FieldName = "_DOPEN_DATE"
        R_GridViewDateTimeColumn13.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn13.Format = System.Windows.Forms.DateTimePickerFormat.[Long]
        R_GridViewDateTimeColumn13.FormatInfo = New System.Globalization.CultureInfo("en-GB")
        R_GridViewDateTimeColumn13.FormatString = "{0: dddd, dd MMMM yyyy }"
        R_GridViewDateTimeColumn13.HeaderText = "_DOPEN_DATE"
        R_GridViewDateTimeColumn13.Name = "_DOPEN_DATE"
        R_GridViewDateTimeColumn13.R_MinDate = New Date(CType(0, Long))
        R_GridViewDateTimeColumn13.R_ResourceId = "_DOPEN_DATE"
        R_GridViewDateTimeColumn13.Width = 85
        R_GridViewTextBoxColumn35.FieldName = "_COPEN_BY"
        R_GridViewTextBoxColumn35.HeaderText = "_COPEN_BY"
        R_GridViewTextBoxColumn35.Name = "_COPEN_BY"
        R_GridViewTextBoxColumn35.R_ResourceId = "_COPEN_BY"
        R_GridViewTextBoxColumn35.R_UDT = Nothing
        R_GridViewTextBoxColumn35.Width = 71
        R_GridViewDateTimeColumn14.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn14.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn14.FieldName = "_DRELEASE_DATE"
        R_GridViewDateTimeColumn14.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn14.Format = System.Windows.Forms.DateTimePickerFormat.[Long]
        R_GridViewDateTimeColumn14.FormatInfo = New System.Globalization.CultureInfo("en-GB")
        R_GridViewDateTimeColumn14.FormatString = "{0: dddd, dd MMMM yyyy }"
        R_GridViewDateTimeColumn14.HeaderText = "_DRELEASE_DATE"
        R_GridViewDateTimeColumn14.Name = "_DRELEASE_DATE"
        R_GridViewDateTimeColumn14.R_MinDate = New Date(CType(0, Long))
        R_GridViewDateTimeColumn14.R_ResourceId = "_CRELEASE_DATE"
        R_GridViewDateTimeColumn14.Width = 97
        R_GridViewTextBoxColumn36.FieldName = "_CRELEASE_BY"
        R_GridViewTextBoxColumn36.HeaderText = "_CRELEASE_BY"
        R_GridViewTextBoxColumn36.Name = "_CRELEASE_BY"
        R_GridViewTextBoxColumn36.R_ResourceId = "_CRELEASE_BY"
        R_GridViewTextBoxColumn36.R_UDT = Nothing
        R_GridViewTextBoxColumn36.Width = 83
        R_GridViewTextBoxColumn37.FieldName = "_CLAST_REVISION"
        R_GridViewTextBoxColumn37.HeaderText = "_CLAST_REVISION"
        R_GridViewTextBoxColumn37.Name = "_CLAST_REVISION"
        R_GridViewTextBoxColumn37.R_ResourceId = "_CLAST_REVISION"
        R_GridViewTextBoxColumn37.R_UDT = Nothing
        R_GridViewTextBoxColumn37.Width = 99
        R_GridViewTextBoxColumn38.FieldName = "_CLAST_REVISION_BY"
        R_GridViewTextBoxColumn38.HeaderText = "_CLAST_REVISION_BY"
        R_GridViewTextBoxColumn38.Name = "_CLAST_REVISION_BY"
        R_GridViewTextBoxColumn38.R_ResourceId = "_CLAST_REVISION_BY"
        R_GridViewTextBoxColumn38.R_UDT = Nothing
        R_GridViewTextBoxColumn38.Width = 114
        R_GridViewDateTimeColumn15.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn15.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn15.FieldName = "_DLAST_REVISION_DATE"
        R_GridViewDateTimeColumn15.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn15.Format = System.Windows.Forms.DateTimePickerFormat.[Long]
        R_GridViewDateTimeColumn15.FormatInfo = New System.Globalization.CultureInfo("en-GB")
        R_GridViewDateTimeColumn15.FormatString = "{0: dddd, dd MMMM yyyy }"
        R_GridViewDateTimeColumn15.HeaderText = "_DLAST_REVISION_DATE"
        R_GridViewDateTimeColumn15.Name = "_DLAST_REVISION_DATE"
        R_GridViewDateTimeColumn15.R_MinDate = New Date(CType(0, Long))
        R_GridViewDateTimeColumn15.R_ResourceId = "_DLAST_REVISION_DATE"
        R_GridViewDateTimeColumn15.Width = 128
        Me.gvAppVer.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn31, R_GridViewTextBoxColumn32, R_GridViewTextBoxColumn33, R_GridViewTextBoxColumn34, R_GridViewDateTimeColumn13, R_GridViewTextBoxColumn35, R_GridViewDateTimeColumn14, R_GridViewTextBoxColumn36, R_GridViewTextBoxColumn37, R_GridViewTextBoxColumn38, R_GridViewDateTimeColumn15})
        Me.gvAppVer.MasterTemplate.DataSource = Me.bsGvAppVer
        Me.gvAppVer.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvAppVer.MasterTemplate.EnableFiltering = True
        Me.gvAppVer.MasterTemplate.EnableGrouping = False
        Me.gvAppVer.MasterTemplate.ShowFilteringRow = False
        Me.gvAppVer.MasterTemplate.ShowGroupedColumns = True
        Me.gvAppVer.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvAppVer.Name = "gvAppVer"
        Me.gvAppVer.R_ConductorGridSource = Me.conGridAppVer
        Me.gvAppVer.R_ConductorSource = Nothing
        Me.gvAppVer.R_DataAdded = False
        Me.gvAppVer.R_NewRowText = Nothing
        Me.gvAppVer.ShowHeaderCellButtons = True
        Me.gvAppVer.Size = New System.Drawing.Size(965, 201)
        Me.gvAppVer.TabIndex = 2
        Me.gvAppVer.Text = "R_RadGridView1"
        '
        'bsGvAppVer
        '
        Me.bsGvAppVer.DataSource = GetType(RVT00100Front.RVT00100ServiceRef.RVT00100DTO)
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.txtCodeName)
        Me.Panel2.Controls.Add(Me.txtAlias)
        Me.Panel2.Controls.Add(Me.lblCodeName)
        Me.Panel2.Controls.Add(Me.lblAlias)
        Me.Panel2.Controls.Add(Me.btnSaveVersion)
        Me.Panel2.Controls.Add(Me.txtNote)
        Me.Panel2.Controls.Add(Me.lblVersionNote)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 3)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(965, 213)
        Me.Panel2.TabIndex = 3
        '
        'txtCodeName
        '
        Me.txtCodeName.Location = New System.Drawing.Point(109, 28)
        Me.txtCodeName.Name = "txtCodeName"
        Me.txtCodeName.R_ConductorGridSource = Nothing
        Me.txtCodeName.R_ConductorSource = Nothing
        Me.txtCodeName.R_UDT = Nothing
        Me.txtCodeName.Size = New System.Drawing.Size(379, 20)
        Me.txtCodeName.TabIndex = 23
        '
        'txtAlias
        '
        Me.txtAlias.Location = New System.Drawing.Point(109, 2)
        Me.txtAlias.Name = "txtAlias"
        Me.txtAlias.R_ConductorGridSource = Nothing
        Me.txtAlias.R_ConductorSource = Nothing
        Me.txtAlias.R_UDT = Nothing
        Me.txtAlias.Size = New System.Drawing.Size(379, 20)
        Me.txtAlias.TabIndex = 22
        '
        'lblCodeName
        '
        Me.lblCodeName.AutoSize = False
        Me.lblCodeName.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCodeName.Location = New System.Drawing.Point(3, 29)
        Me.lblCodeName.Name = "lblCodeName"
        Me.lblCodeName.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCodeName.R_ResourceId = "lblCodeName"
        Me.lblCodeName.Size = New System.Drawing.Size(100, 18)
        Me.lblCodeName.TabIndex = 25
        Me.lblCodeName.Text = "Application..."
        '
        'lblAlias
        '
        Me.lblAlias.AutoSize = False
        Me.lblAlias.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblAlias.Location = New System.Drawing.Point(3, 3)
        Me.lblAlias.Name = "lblAlias"
        Me.lblAlias.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblAlias.R_ResourceId = "lblAlias"
        Me.lblAlias.Size = New System.Drawing.Size(100, 18)
        Me.lblAlias.TabIndex = 24
        Me.lblAlias.Text = "Application..."
        '
        'btnSaveVersion
        '
        Me.btnSaveVersion.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSaveVersion.Location = New System.Drawing.Point(109, 186)
        Me.btnSaveVersion.Name = "btnSaveVersion"
        Me.btnSaveVersion.R_ConductorGridSource = Me.conGridAppVer
        Me.btnSaveVersion.R_ConductorSource = Nothing
        Me.btnSaveVersion.R_DescriptionId = Nothing
        Me.btnSaveVersion.R_EnableHASDATA = True
        Me.btnSaveVersion.R_ResourceId = "btnSaveVersion"
        Me.btnSaveVersion.Size = New System.Drawing.Size(180, 24)
        Me.btnSaveVersion.TabIndex = 21
        Me.btnSaveVersion.Text = "btnSaveVersion"
        '
        'txtNote
        '
        Me.txtNote.AcceptsReturn = True
        Me.txtNote.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtNote.AutoSize = False
        Me.txtNote.Location = New System.Drawing.Point(109, 54)
        Me.txtNote.Multiline = True
        Me.txtNote.Name = "txtNote"
        Me.txtNote.R_ConductorGridSource = Nothing
        Me.txtNote.R_ConductorSource = Nothing
        Me.txtNote.R_UDT = Nothing
        Me.txtNote.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtNote.Size = New System.Drawing.Size(853, 126)
        Me.txtNote.TabIndex = 13
        '
        'lblVersionNote
        '
        Me.lblVersionNote.AutoSize = False
        Me.lblVersionNote.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblVersionNote.Location = New System.Drawing.Point(3, 55)
        Me.lblVersionNote.Name = "lblVersionNote"
        Me.lblVersionNote.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblVersionNote.R_ResourceId = "lblVersionNote"
        Me.lblVersionNote.Size = New System.Drawing.Size(100, 18)
        Me.lblVersionNote.TabIndex = 12
        Me.lblVersionNote.Text = "Application..."
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.ColumnCount = 2
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 300.0!))
        Me.TableLayoutPanel3.Controls.Add(Me.Panel3, 1, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.Panel2, 0, 0)
        Me.TableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(3, 353)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 1
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(1271, 219)
        Me.TableLayoutPanel3.TabIndex = 8
        '
        'gvRevisions
        '
        Me.gvRevisions.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvRevisions.EnableFastScrolling = True
        Me.gvRevisions.Location = New System.Drawing.Point(974, 3)
        '
        '
        '
        Me.gvRevisions.MasterTemplate.AllowAddNewRow = False
        Me.gvRevisions.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn39.FieldName = "_CREVISION"
        R_GridViewTextBoxColumn39.HeaderText = "_CREVISION"
        R_GridViewTextBoxColumn39.Name = "_CREVISION"
        R_GridViewTextBoxColumn39.R_ResourceId = "_CREVISION"
        R_GridViewTextBoxColumn39.R_UDT = Nothing
        R_GridViewTextBoxColumn39.Width = 82
        R_GridViewDateTimeColumn16.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn16.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn16.FieldName = "_DRELEASE_DATE"
        R_GridViewDateTimeColumn16.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn16.Format = System.Windows.Forms.DateTimePickerFormat.[Long]
        R_GridViewDateTimeColumn16.FormatInfo = New System.Globalization.CultureInfo("en-GB")
        R_GridViewDateTimeColumn16.FormatString = "{0: dddd, dd MMMM yyyy }"
        R_GridViewDateTimeColumn16.HeaderText = "_DRELEASE_DATE"
        R_GridViewDateTimeColumn16.Name = "_DRELEASE_DATE"
        R_GridViewDateTimeColumn16.R_MinDate = New Date(CType(0, Long))
        R_GridViewDateTimeColumn16.R_ResourceId = "_DRELEASE_DATE"
        R_GridViewDateTimeColumn16.Width = 109
        R_GridViewTextBoxColumn40.FieldName = "_CRELEASE_BY"
        R_GridViewTextBoxColumn40.HeaderText = "_CRELEASE_BY"
        R_GridViewTextBoxColumn40.Name = "_CRELEASE_BY"
        R_GridViewTextBoxColumn40.R_ResourceId = "_CRELEASE_BY"
        R_GridViewTextBoxColumn40.R_UDT = Nothing
        R_GridViewTextBoxColumn40.Width = 94
        Me.gvRevisions.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn39, R_GridViewDateTimeColumn16, R_GridViewTextBoxColumn40})
        Me.gvRevisions.MasterTemplate.DataSource = Me.bsGvRevision
        Me.gvRevisions.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvRevisions.MasterTemplate.EnableFiltering = True
        Me.gvRevisions.MasterTemplate.EnableGrouping = False
        Me.gvRevisions.MasterTemplate.ShowFilteringRow = False
        Me.gvRevisions.MasterTemplate.ShowGroupedColumns = True
        Me.gvRevisions.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvRevisions.Name = "gvRevisions"
        Me.gvRevisions.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvRevisions.R_ConductorGridSource = Me.conGridRevisions
        Me.gvRevisions.R_ConductorSource = Nothing
        Me.gvRevisions.R_DataAdded = False
        Me.gvRevisions.R_NewRowText = Nothing
        Me.gvRevisions.ShowHeaderCellButtons = True
        Me.gvRevisions.Size = New System.Drawing.Size(294, 201)
        Me.gvRevisions.TabIndex = 6
        Me.gvRevisions.Text = "R_RadGridView1"
        '
        'bsGvRevision
        '
        Me.bsGvRevision.DataSource = GetType(RVT00100Front.RVT00100RevisionServiceRef.RVT00100RevisionDTO)
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.btnSaveRevision)
        Me.Panel3.Controls.Add(Me.txtRevNote)
        Me.Panel3.Controls.Add(Me.lblRevisionNote)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(974, 3)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(294, 213)
        Me.Panel3.TabIndex = 7
        '
        'btnSaveRevision
        '
        Me.btnSaveRevision.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSaveRevision.Location = New System.Drawing.Point(3, 186)
        Me.btnSaveRevision.Name = "btnSaveRevision"
        Me.btnSaveRevision.R_ConductorGridSource = Me.conGridRevisions
        Me.btnSaveRevision.R_ConductorSource = Nothing
        Me.btnSaveRevision.R_DescriptionId = Nothing
        Me.btnSaveRevision.R_EnableHASDATA = True
        Me.btnSaveRevision.R_ResourceId = "btnSaveRevision"
        Me.btnSaveRevision.Size = New System.Drawing.Size(180, 24)
        Me.btnSaveRevision.TabIndex = 22
        Me.btnSaveRevision.Text = "btnSaveRevision"
        '
        'txtRevNote
        '
        Me.txtRevNote.AcceptsReturn = True
        Me.txtRevNote.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtRevNote.AutoSize = False
        Me.txtRevNote.Location = New System.Drawing.Point(3, 28)
        Me.txtRevNote.Multiline = True
        Me.txtRevNote.Name = "txtRevNote"
        Me.txtRevNote.R_ConductorGridSource = Me.conGridRevisions
        Me.txtRevNote.R_ConductorSource = Nothing
        Me.txtRevNote.R_EnableHASDATA = True
        Me.txtRevNote.R_UDT = Nothing
        Me.txtRevNote.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtRevNote.Size = New System.Drawing.Size(291, 152)
        Me.txtRevNote.TabIndex = 14
        '
        'lblRevisionNote
        '
        Me.lblRevisionNote.AutoSize = False
        Me.lblRevisionNote.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblRevisionNote.Location = New System.Drawing.Point(3, 8)
        Me.lblRevisionNote.Name = "lblRevisionNote"
        Me.lblRevisionNote.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblRevisionNote.R_ResourceId = "lblRevisionNote"
        Me.lblRevisionNote.Size = New System.Drawing.Size(100, 18)
        Me.lblRevisionNote.TabIndex = 13
        Me.lblRevisionNote.Text = "Application..."
        '
        'preLog
        '
        Me.preLog.R_ConductorGridSource = Me.conGridAppVer
        Me.preLog.R_ConductorSource = Nothing
        Me.preLog.R_CopyAccess = True
        Me.preLog.R_DockIndex = 0
        Me.preLog.R_EnableHASDATA = True
        Me.preLog.R_HeaderTitle = ""
        '
        'preInclude
        '
        Me.preInclude.R_ConductorGridSource = Me.conGridAppVer
        Me.preInclude.R_ConductorSource = Nothing
        Me.preInclude.R_CopyAccess = True
        Me.preInclude.R_DockIndex = 0
        Me.preInclude.R_EnableHASDATA = True
        Me.preInclude.R_HeaderTitle = ""
        '
        'conGridRevisions
        '
        Me.conGridRevisions.R_ConductorParent = Me.conGridAppVer
        Me.conGridRevisions.R_RadGroupBox = Nothing
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.ColumnCount = 2
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 300.0!))
        Me.TableLayoutPanel4.Controls.Add(Me.R_RadLabel1, 0, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.lblAppVersion, 1, 0)
        Me.TableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(3, 111)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 1
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(1271, 22)
        Me.TableLayoutPanel4.TabIndex = 9
        '
        'RVT00100
        '
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "RVT00100"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.btnRevise, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridAppVer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnClose, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblPackageStatus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbPackageStatus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chkRecoverVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnRerelease, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnSetting, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnCreate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnRelease, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblAppVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel2.ResumeLayout(False)
        CType(Me.gvAppVer.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvAppVer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvAppVer, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.txtCodeName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtAlias, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCodeName, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblAlias, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnSaveVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtNote, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblVersionNote, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel3.ResumeLayout(False)
        CType(Me.gvRevisions.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvRevisions, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvRevision, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        CType(Me.btnSaveRevision, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtRevNote, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblRevisionNote, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridRevisions, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel4.ResumeLayout(False)
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents bsGvAppVer As System.Windows.Forms.BindingSource
    Friend WithEvents conGridAppVer As R_FrontEnd.R_ConductorGrid
    Friend WithEvents gvAppVer As R_FrontEnd.R_RadGridView
    Friend WithEvents btnRelease As R_FrontEnd.R_RadButton
    Friend WithEvents cboApplication As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource
    Friend WithEvents btnCreate As R_FrontEnd.R_Detail
    Friend WithEvents preLog As R_FrontEnd.R_PredefinedDock
    Friend WithEvents preInclude As R_FrontEnd.R_PredefinedDock
    Friend WithEvents btnSetting As R_FrontEnd.R_Detail
    Friend WithEvents btnRerelease As R_FrontEnd.R_RadButton
    Friend WithEvents chkRecoverVersion As R_FrontEnd.R_RadCheckBox
    Friend WithEvents pbPackageStatus As R_FrontEnd.R_RadProgressBar
    Friend WithEvents lblPackageStatus As R_FrontEnd.R_RadLabel
    Friend WithEvents bwPackageStatus As ComponentModel.BackgroundWorker
    Friend WithEvents lblAppVersion As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadLabel1 As R_FrontEnd.R_RadLabel
    Friend WithEvents gvRevisions As R_FrontEnd.R_RadGridView
    Friend WithEvents btnRevise As R_FrontEnd.R_RadButton
    Friend WithEvents btnClose As R_FrontEnd.R_RadButton
    Friend WithEvents bsGvRevision As Windows.Forms.BindingSource
    Friend WithEvents TableLayoutPanel2 As Windows.Forms.TableLayoutPanel
    Friend WithEvents TableLayoutPanel3 As Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel3 As Windows.Forms.Panel
    Friend WithEvents lblVersionNote As R_FrontEnd.R_RadLabel
    Friend WithEvents lblRevisionNote As R_FrontEnd.R_RadLabel
    Friend WithEvents btnSaveVersion As R_FrontEnd.R_RadButton
    Friend WithEvents txtNote As R_FrontEnd.R_RadTextBox
    Friend WithEvents btnSaveRevision As R_FrontEnd.R_RadButton
    Friend WithEvents txtRevNote As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtCodeName As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtAlias As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblCodeName As R_FrontEnd.R_RadLabel
    Friend WithEvents lblAlias As R_FrontEnd.R_RadLabel
    Friend WithEvents conGridRevisions As R_FrontEnd.R_ConductorGrid
    Friend WithEvents Panel1 As Windows.Forms.Panel
    Friend WithEvents Panel2 As Windows.Forms.Panel
    Friend WithEvents TableLayoutPanel4 As Windows.Forms.TableLayoutPanel
End Class
