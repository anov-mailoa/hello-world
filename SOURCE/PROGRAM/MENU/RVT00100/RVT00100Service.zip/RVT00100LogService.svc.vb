﻿Imports R_Common
Imports RVT00100Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "RVT00100LogService" in code, svc and config file together.
Public Class RVT00100LogService
    Implements IRVT00100LogService

    Public Sub Svc_R_Delete(poEntity As RVT00100Back.RVT00100LogDTO) Implements R_BackEnd.R_IServicebase(Of RVT00100Back.RVT00100LogDTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New RVT00100LogCls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As RVT00100Back.RVT00100LogDTO) As RVT00100Back.RVT00100LogDTO Implements R_BackEnd.R_IServicebase(Of RVT00100Back.RVT00100LogDTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New RVT00100LogCls
        Dim loRtn As RVT00100LogDTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As RVT00100Back.RVT00100LogDTO, poCRUDMode As R_Common.eCRUDMode) As RVT00100Back.RVT00100LogDTO Implements R_BackEnd.R_IServicebase(Of RVT00100Back.RVT00100LogDTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New RVT00100LogCls
        Dim loRtn As RVT00100LogDTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetLogTypeCombo() As System.Collections.Generic.List(Of RVT00100Back.RVT00100LogTypeComboDTO) Implements IRVT00100LogService.GetLogTypeCombo
        Dim loException As New R_Exception
        Dim loCls As New RVT00100LogCls
        Dim loRtn As List(Of RVT00100LogTypeComboDTO)

        Try
            loRtn = loCls.GetLogTypeCombo()
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetAppUnitCombo(key As RVT00100Back.RVT00100AppKeyDTO) As System.Collections.Generic.List(Of RVT00100Back.RVT00100AppUnitComboDTO) Implements IRVT00100LogService.GetAppUnitCombo
        Dim loException As New R_Exception
        Dim loCls As New RVT00100LogCls
        Dim loRtn As List(Of RVT00100AppUnitComboDTO)

        Try
            loRtn = loCls.GetAppUnitCombo(key)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn

    End Function
End Class
