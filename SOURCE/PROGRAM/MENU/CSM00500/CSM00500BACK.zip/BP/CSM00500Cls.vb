﻿Imports R_BackEnd
Imports R_Common
Imports System.Data.Common
Imports ServerHelper.General

Public Class CSM00500Cls
    Inherits R_BusinessObject(Of CSM00500DTO)

    Public Function GetProjectList(poKey As CSM00500KeyDTO) As List(Of CSM00500GridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00500GridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CSM_PROJECTS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery += "AND LCUSTOM = {3} "
                If .LCUSTOM Then
                    lcQuery += "AND CCUSTOMER_CODE = '{4}' "
                End If
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, IIf(.LCUSTOM, "1", "0"), .CCUSTOMER_CODE)

            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00500GridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Deleting(poEntity As CSM00500DTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcRtn As String

        Try
            loConn = loDb.GetConnection()

            With poEntity

                'validation
                loCmd = loDb.GetCommand()
                lcQuery = "EXEC RSP_Delete_Project_Validation '{0}', '{1}', '{2}', '{3}', @CRET_MSG OUTPUT "
                With poEntity
                    lcQuery = String.Format(lcQuery, _
                                            .CCOMPANY_ID, _
                                            .CAPPS_CODE, _
                                            .CVERSION, _
                                            .CPROJECT_ID)
                End With
                loCmd.CommandText = lcQuery
                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@CRET_MSG"
                    .DbType = DbType.String
                    .Size = 50
                    .Direction = ParameterDirection.Output
                End With
                loCmd.Parameters.Add(loPar)
                loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)

                If loCmd.Parameters("@CRET_MSG") Is Nothing Then
                    lcRtn = "UNKNOWN_ERROR"
                Else
                    lcRtn = loCmd.Parameters("@CRET_MSG").Value
                End If

                If Not lcRtn.Equals("OK") Then
                    Throw New Exception(lcRtn)
                End If

                'delete project user table
                lcQuery = "DELETE FROM "
                lcQuery += "CSM_PROJECT_USERS "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery += "AND CPROJECT_ID = '{3}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID)
                loDb.SqlExecNonQuery(lcQuery, loConn, False)

                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "CSM_PROJECTS "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery += "AND CPROJECT_ID = '{3}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID)
                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As CSM00500DTO) As CSM00500DTO
        Dim lcQuery As String
        Dim loResult As CSM00500DTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CSM_PROJECTS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery += "AND CPROJECT_ID = '{3}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID)

                loResult = loDb.SqlExecObjectQuery(Of CSM00500DTO)(lcQuery).FirstOrDefault

            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As CSM00500DTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim lcProjectId As String
        Dim lcVersionStatus As String

        Try
            loConn = loDb.GetConnection()

            With poNewEntity
                If poCRUDMode = eCRUDMode.AddMode Then

                    .CSTATUS = "NEW"
                    .CUPDATE_BY = .CUPDATE_BY
                    .CCREATE_BY = .CUPDATE_BY
                    .DUPDATE_DATE = Now
                    .DCREATE_DATE = Now

                    ' cari duplicate
                    lcQuery = "SELECT CPROJECT_ID "
                    lcQuery += "FROM CSM_PROJECTS (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CVERSION = '{2}' "
                    lcQuery += "AND CPROJECT_ID = '{3}' "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID)

                    lcProjectId = loDb.SqlExecObjectQuery(Of String)(lcQuery, loConn, False).FirstOrDefault
                    If lcProjectId IsNot Nothing Then
                        Throw New Exception("DUPLICATE_PROJECT")
                    End If

                    ' validasi version
                    lcQuery = "SELECT CSTATUS "
                    lcQuery += "FROM RVT_APP_VERSION (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CVERSION = '{2}' "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION)

                    lcVersionStatus = loDb.SqlExecObjectQuery(Of String)(lcQuery, loConn, False).FirstOrDefault
                    If lcVersionStatus Is Nothing Then
                        Throw New Exception("INVALID_VERSION")
                    End If
                    If lcVersionStatus.Trim.Equals("CLOSED") Then
                        Throw New Exception("CLOSED_VERSION")
                    End If

                    lcQuery = "INSERT INTO CSM_PROJECTS ("
                    lcQuery += "CCOMPANY_ID, "
                    lcQuery += "CAPPS_CODE, "
                    lcQuery += "CVERSION, "
                    lcQuery += "CPROJECT_ID, "
                    lcQuery += "CPROJECT_NAME, "
                    lcQuery += "CDESCRIPTION, "
                    lcQuery += "LCUSTOM, "
                    lcQuery += "CCUSTOMER_CODE, "
                    lcQuery += "CPROJECT_MANAGER, "
                    lcQuery += "CSTATUS, "
                    lcQuery += "CUPDATE_BY, "
                    lcQuery += "DUPDATE_DATE, "
                    lcQuery += "CCREATE_BY, "
                    lcQuery += "DCREATE_DATE) "
                    lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', {6}, '{7}', '{8}', '{9}', '{10}', {11}, '{12}', {13}) "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CVERSION,
                    .CPROJECT_ID,
                    .CPROJECT_NAME,
                    .CDESCRIPTION,
                    getBit(.LCUSTOM),
                    .CCUSTOMER_CODE,
                    .CPROJECT_MANAGER,
                    .CSTATUS,
                    .CUPDATE_BY,
                    getDate(.DUPDATE_DATE),
                    .CCREATE_BY,
                    getDate(.DCREATE_DATE))

                ElseIf poCRUDMode = eCRUDMode.EditMode Then

                    lcQuery = "UPDATE CSM_PROJECTS "
                    lcQuery += "SET "
                    lcQuery += "CPROJECT_NAME = '{4}', "
                    lcQuery += "CDESCRIPTION = '{5}', "
                    lcQuery += "LCUSTOM = {6}, "
                    lcQuery += "CCUSTOMER_CODE = '{7}', "
                    lcQuery += "CPROJECT_MANAGER = '{8}', "
                    lcQuery += "CUPDATE_BY = '{9}', "
                    lcQuery += "DUPDATE_DATE = {10} "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CVERSION = '{2}' "
                    lcQuery += "AND CPROJECT_ID = '{3}' "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CVERSION,
                    .CPROJECT_ID,
                    .CPROJECT_NAME,
                    .CDESCRIPTION,
                    getBit(.LCUSTOM),
                    .CCUSTOMER_CODE,
                    .CPROJECT_MANAGER,
                    .CUPDATE_BY,
                    getDate(.DUPDATE_DATE))

                End If
            End With
            loDb.SqlExecNonQuery(lcQuery, loConn, True)
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Function CloseProject(poKey As CSM00500KeyDTO) As String
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcRtn As String = "OK"

        Try
            loCmd = loDb.GetCommand()
            lcQuery = "EXEC RSP_Close_Project '{0}', '{1}', '{2}', '{3}', '{4}', @CRET_MSG OUTPUT "
            With poKey
                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CVERSION, _
                                        .CPROJECT_ID, _
                                        .CUSER_ID)
            End With
            loCmd.CommandText = lcQuery
            loPar = loDb.GetParameter()
            With loPar
                .ParameterName = "@CRET_MSG"
                .DbType = DbType.String
                .Size = 50
                .Direction = ParameterDirection.Output
            End With
            loCmd.Parameters.Add(loPar)
            loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)

            If loCmd.Parameters("@CRET_MSG") Is Nothing Then
                lcRtn = "UNKNOWN_ERROR"
            Else
                lcRtn = loCmd.Parameters("@CRET_MSG").Value
            End If
            If Not lcRtn.Equals("OK") Then
                Throw New Exception(lcRtn)
            End If
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return lcRtn
    End Function

End Class
