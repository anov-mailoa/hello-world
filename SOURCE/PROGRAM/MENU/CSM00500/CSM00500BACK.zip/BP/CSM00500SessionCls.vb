﻿Imports R_BackEnd
Imports R_Common
Imports System.Data.Common
Imports ServerHelper.General

Public Class CSM00500SessionCls
    Inherits R_BusinessObject(Of CSM00500SessionDTO)

    Public Function GetProjectSessionList(poKey As CSM00500SessionKeyDTO) As List(Of CSM00500SessionGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00500SessionGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "SELECT A.*, B.CSCHEDULE_TYPE_NAME "
                lcQuery += "FROM "
                lcQuery += "CSM_PROJECT_SESSIONS A (NOLOCK) "
                lcQuery += "JOIN CSM_SCHEDULE_TYPE B (NOLOCK) "
                lcQuery += "ON B.CSCHEDULE_TYPE = A.CINIT_SCHEDULE_TYPE "
                lcQuery += "WHERE A.CCOMPANY_ID = '{0}' "
                lcQuery += "AND A.CAPPS_CODE = '{1}' "
                lcQuery += "AND A.CVERSION = '{2}' "
                lcQuery += "AND A.CPROJECT_ID = '{3}' "
                lcQuery += "ORDER BY A.CSESSION_ID DESC "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID)

            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00500SessionGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Sub CreateSession(poKey As CSM00500SessionKeyDTO)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As CSM00500SessionGridDTO
        Dim lcSession_ID As String
        Dim lcSession_No As String

        Try
            loConn = loDb.GetConnection()

            lcSession_ID = ""
            ' Get last session
            lcQuery = "SELECT TOP 1 * "
            lcQuery += "FROM "
            lcQuery += "CSM_PROJECT_SESSIONS (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery += "AND CAPPS_CODE = '{1}' "
            lcQuery += "AND CVERSION = '{2}' "
            lcQuery += "AND CPROJECT_ID = '{3}' "
            lcQuery += "ORDER BY CSESSION_ID DESC "
            lcQuery = String.Format(lcQuery, poKey.CCOMPANY_ID, poKey.CAPPS_CODE, poKey.CVERSION, poKey.CPROJECT_ID)

            loResult = loDb.SqlExecObjectQuery(Of CSM00500SessionGridDTO)(lcQuery, loConn, True).FirstOrDefault
            If loResult IsNot Nothing Then
                lcSession_ID = loResult.CSESSION_ID
                lcSession_No = Right(lcSession_ID, 12)
                lcSession_ID = Today.ToString("yyyyMMdd") & Right("000000000000" & CInt(lcSession_No + 1).ToString.Trim, 12)
            Else
                lcSession_ID = Today.ToString("yyyyMMdd") & "000000000001"
            End If

            ' Save session data
            With poKey
                lcQuery = "INSERT INTO CSM_PROJECT_SESSIONS ("
                lcQuery += "CCOMPANY_ID, "
                lcQuery += "CAPPS_CODE, "
                lcQuery += "CVERSION, "
                lcQuery += "CPROJECT_ID, "
                lcQuery += "CSESSION_ID, "
                lcQuery += "CINIT_SCHEDULE_TYPE, "
                lcQuery += "DSESSION_DATE, "
                lcQuery += "CSTATUS, "
                lcQuery += "CNOTE, "
                lcQuery += "CUPDATE_BY, "
                lcQuery += "DUPDATE_DATE, "
                lcQuery += "CCREATE_BY, "
                lcQuery += "DCREATE_DATE) "
                lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', GETDATE(), 'NEW', '{6}', '{7}', GETDATE(), '{7}', GETDATE()) "
                lcQuery = String.Format(lcQuery,
                .CCOMPANY_ID,
                .CAPPS_CODE,
                .CVERSION,
                .CPROJECT_ID,
                lcSession_ID,
                .CINIT_SCHEDULE_TYPE,
                .CNOTE,
                .CUSER_ID)
            End With

            loDb.SqlExecNonQuery(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try
        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Sub StartSession(poKey As CSM00500SessionKeyDTO)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As List(Of CSM00500SessionValidationDTO)

        Try
            loConn = loDb.GetConnection()

            ' Validation (session must be fully scheduled)
            lcQuery = "EXEC RSP_Session_Validation '{0}', '{1}', '{2}', '{3}', '{4}', '', '', '', '', 'START' "
            lcQuery = String.Format(lcQuery, poKey.CCOMPANY_ID, poKey.CAPPS_CODE, poKey.CVERSION, poKey.CPROJECT_ID, poKey.CSESSION_ID)

            loResult = loDb.SqlExecObjectQuery(Of CSM00500SessionValidationDTO)(lcQuery, loConn, True)
            If loResult.Count > 0 Then
                For Each result As CSM00500SessionValidationDTO In loResult
                    loEx.Add(result.CMESSAGE_CODE, result.CDESCRIPTION)
                Next
                Exit Try
            End If

            ' Start session
            With poKey

                'lcQuery = "UPDATE CSM_PROJECT_SCHEDULE "
                'lcQuery += "SET "
                'lcQuery += "CSTATUS = 'START', "
                'lcQuery += "CUPDATE_BY = '{5}', "
                'lcQuery += "DUPDATE_DATE = GETDATE() "
                'lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                'lcQuery += "AND CAPPS_CODE = '{1}' "
                'lcQuery += "AND CVERSION = '{2}' "
                'lcQuery += "AND CPROJECT_ID = '{3}' "
                'lcQuery += "AND CSESSION_ID = '{4}' "
                'lcQuery += "AND CPLAN_START_DATE <> '' AND CPLAN_END_DATE <> '' "
                'lcQuery = String.Format(lcQuery,
                '.CCOMPANY_ID,
                '.CAPPS_CODE,
                '.CVERSION,
                '.CPROJECT_ID,
                '.CSESSION_ID,
                '.CUSER_ID)
                'loDb.SqlExecNonQuery(lcQuery)

                lcQuery = "UPDATE CSM_PROJECT_SESSIONS "
                lcQuery += "SET "
                lcQuery += "CNOTE = '{6}', "
                lcQuery += "CSTATUS = 'ON-PROGRESS', "
                lcQuery += "CUPDATE_BY = '{5}', "
                lcQuery += "DUPDATE_DATE = GETDATE() "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery += "AND CPROJECT_ID = '{3}' "
                lcQuery += "AND CSESSION_ID = '{4}' "
                lcQuery = String.Format(lcQuery,
                .CCOMPANY_ID,
                .CAPPS_CODE,
                .CVERSION,
                .CPROJECT_ID,
                .CSESSION_ID,
                .CUSER_ID,
                .CNOTE)
                loDb.SqlExecNonQuery(lcQuery)
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try
        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Sub CloseSession(poKey As CSM00500SessionKeyDTO)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As List(Of CSM00500SessionValidationDTO)

        Try
            loConn = loDb.GetConnection()

            ' Validation (new, on-progress and no unfinished sequence, etc)
            lcQuery = "EXEC RSP_Session_Validation '{0}', '{1}', '{2}', '{3}', '{4}', '', '', '', '', 'CLOSE' "
            lcQuery = String.Format(lcQuery, poKey.CCOMPANY_ID, poKey.CAPPS_CODE, poKey.CVERSION, poKey.CPROJECT_ID, poKey.CSESSION_ID)

            loResult = loDb.SqlExecObjectQuery(Of CSM00500SessionValidationDTO)(lcQuery, loConn, True)
            If loResult.Count > 0 Then
                For Each result As CSM00500SessionValidationDTO In loResult
                    loEx.Add(result.CMESSAGE_CODE, result.CDESCRIPTION)
                Next
                Exit Try
            End If

            ' Close session
            With poKey

                lcQuery = "UPDATE CSM_PROJECT_SESSIONS "
                lcQuery += "SET "
                lcQuery += "DCLOSE_DATE = GETDATE(), "
                lcQuery += "CNOTE = '{5}', "
                lcQuery += "CSTATUS = 'CLOSED', "
                lcQuery += "CUPDATE_BY = '{6}', "
                lcQuery += "DUPDATE_DATE = GETDATE() "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery += "AND CPROJECT_ID = '{3}' "
                lcQuery += "AND CSESSION_ID = '{4}' "
                lcQuery = String.Format(lcQuery,
                .CCOMPANY_ID,
                .CAPPS_CODE,
                .CVERSION,
                .CPROJECT_ID,
                .CSESSION_ID,
                .CNOTE,
                .CUSER_ID)
            End With

            loDb.SqlExecNonQuery(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try
        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Sub R_Deleting(poEntity As CSM00500SessionDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loResult As List(Of CSM00500SessionValidationDTO)

        Try
            loConn = loDb.GetConnection()

            With poEntity

                ' Validation (new, on-progress and no unfinished sequence, etc)
                lcQuery = "EXEC RSP_Session_Validation '{0}', '{1}', '{2}', '{3}', '{4}', '', '', '', '', 'DELETE' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID, .CSESSION_ID)

                loResult = loDb.SqlExecObjectQuery(Of CSM00500SessionValidationDTO)(lcQuery, loConn, False)
                If loResult.Count > 0 Then
                    For Each result As CSM00500SessionValidationDTO In loResult
                        loEx.Add(result.CMESSAGE_CODE, result.CDESCRIPTION)
                    Next
                    Exit Try
                End If

                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "CSM_PROJECT_SESSIONS "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery += "AND CPROJECT_ID = '{3}' "
                lcQuery += "AND CSESSION_ID = '{4}' "
                lcQuery = String.Format(lcQuery, _
                            .CCOMPANY_ID, _
                            .CAPPS_CODE, _
                            .CVERSION, _
                            .CPROJECT_ID, _
                            .CSESSION_ID)
                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As CSM00500SessionDTO) As CSM00500SessionDTO
        Dim lcQuery As String
        Dim loResult As CSM00500SessionDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CSM_PROJECT_SESSIONS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery += "AND CPROJECT_ID = '{3}' "
                lcQuery += "AND CSESSION_ID = '{4}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID, .CSESSION_ID)

                loResult = loDb.SqlExecObjectQuery(Of CSM00500SessionDTO)(lcQuery).FirstOrDefault

            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As CSM00500SessionDTO, poCRUDMode As R_Common.eCRUDMode)
        ' Edit only
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String

        Try
            loConn = loDb.GetConnection()

            With poNewEntity
                If poCRUDMode = eCRUDMode.EditMode Then

                    lcQuery = "UPDATE CSM_PROJECT_SESSIONS "
                    lcQuery += "SET "
                    lcQuery += "CNOTE = '{5}', "
                    lcQuery += "CUPDATE_BY = '{6}', "
                    lcQuery += "DUPDATE_DATE = GETDATE() "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CVERSION = '{2}' "
                    lcQuery += "AND CPROJECT_ID = '{3}' "
                    lcQuery += "AND CSESSION_ID = '{4}' "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CVERSION,
                    .CPROJECT_ID,
                    .CSESSION_ID,
                    .CNOTE,
                    .CUPDATE_BY,
                    getDate(.DUPDATE_DATE))

                End If
            End With
            loDb.SqlExecNonQuery(lcQuery, loConn, True)
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

End Class
