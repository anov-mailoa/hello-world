﻿Imports R_BackEnd
Imports R_Common
Imports System.Data.Common
Imports ServerHelper.General

Public Class CSM00500UsersCls
    Inherits R_BusinessObject(Of CSM00500UsersDTO)

    Public Function GetProjectUserList(poKey As CSM00500UsersKeyDTO) As List(Of CSM00500UsersGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00500UsersGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "SELECT A.*, B.CUSER_NAME "
                lcQuery += "FROM CSM_PROJECT_USERS A (NOLOCK) "
                lcQuery += "JOIN SAM_USER B (NOLOCK) "
                lcQuery += "ON B.CUSER_ID = A.CUSER_ID "
                lcQuery += "WHERE A.CCOMPANY_ID = '{0}' "
                lcQuery += "AND A.CAPPS_CODE = '{1}' "
                lcQuery += "AND A.CVERSION = '{2}' "
                lcQuery += "AND A.CPROJECT_ID = '{3}' "
                lcQuery += "AND A.CSESSION_ID = '{4}' "
                If .CFUNCTION_ID IsNot Nothing Then
                    If Not .CFUNCTION_ID.Trim.Equals("") Then
                        lcQuery += "AND A.CFUNCTION_ID = '{5}' "
                    End If
                End If
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID, .CSESSION_ID, .CFUNCTION_ID)

            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00500UsersGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Deleting(poEntity As CSM00500UsersDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection

        Try
            loConn = loDb.GetConnection()

            With poEntity

                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "CSM_PROJECT_USERS "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery += "AND CPROJECT_ID = '{3}' "
                lcQuery += "AND CSESSION_ID = '{4}' "
                lcQuery += "AND CUSER_ID = '{5}' "
                lcQuery += "AND CFUNCTION_ID = '{6}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID, .CSESSION_ID, .CUSER_ID, .CFUNCTION_ID)

                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As CSM00500UsersDTO) As CSM00500UsersDTO
        Dim lcQuery As String
        Dim loResult As CSM00500UsersDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity
                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CSM_PROJECT_USERS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                lcQuery += "AND CPROJECT_ID = '{3}' "
                lcQuery += "AND CSESSION_ID = '{4}' "
                lcQuery += "AND CUSER_ID = '{5}' "
                lcQuery += "AND CFUNCTION_ID = '{6}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID, .CSESSION_ID, .CUSER_ID, .CFUNCTION_ID)

                loResult = loDb.SqlExecObjectQuery(Of CSM00500UsersDTO)(lcQuery).FirstOrDefault

            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As CSM00500UsersDTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String

        Try
            loConn = loDb.GetConnection()

            With poNewEntity
                If poCRUDMode = eCRUDMode.AddMode Then

                    .CUPDATE_BY = .CUPDATE_BY
                    .CCREATE_BY = .CUPDATE_BY

                    lcQuery = "INSERT INTO CSM_PROJECT_USERS ("
                    lcQuery += "CCOMPANY_ID, "
                    lcQuery += "CAPPS_CODE, "
                    lcQuery += "CVERSION, "
                    lcQuery += "CPROJECT_ID, "
                    lcQuery += "CSESSION_ID, "
                    lcQuery += "CUSER_ID, "
                    lcQuery += "CFUNCTION_ID, "
                    lcQuery += "LMANAGER, "
                    lcQuery += "CLOCATION_ID, "
                    lcQuery += "CUPDATE_BY, "
                    lcQuery += "DUPDATE_DATE, "
                    lcQuery += "CCREATE_BY, "
                    lcQuery += "DCREATE_DATE) "
                    lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', {7}, '{8}', '{9}', GETDATE(), '{10}', GETDATE()) "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CVERSION,
                    .CPROJECT_ID,
                    .CSESSION_ID,
                    .CUSER_ID,
                    .CFUNCTION_ID,
                    getBit(.LMANAGER),
                    .CLOCATION_ID,
                    .CUPDATE_BY,
                    .CCREATE_BY)
                Else
                    lcQuery = "UPDATE CSM_PROJECT_USERS "
                    lcQuery += "SET "
                    lcQuery += "LMANAGER = '{7}', "
                    lcQuery += "CLOCATION_ID = '{8}', "
                    lcQuery += "CUPDATE_BY = '{9}', "
                    lcQuery += "DUPDATE_DATE = GETDATE() "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CVERSION = '{2}' "
                    lcQuery += "AND CPROJECT_ID = '{3}' "
                    lcQuery += "AND CSESSION_ID = '{4}' "
                    lcQuery += "AND CUSER_ID = '{5}' "
                    lcQuery += "AND CFUNCTION_ID = '{6}' "
                    lcQuery = String.Format(lcQuery,
                    .CCOMPANY_ID,
                    .CAPPS_CODE,
                    .CVERSION,
                    .CPROJECT_ID,
                    .CSESSION_ID,
                    .CUSER_ID,
                    .CFUNCTION_ID,
                    getBit(.LMANAGER),
                    .CLOCATION_ID,
                    .CUPDATE_BY)

                End If
            End With
            loDb.SqlExecNonQuery(lcQuery, loConn, True)
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

End Class
