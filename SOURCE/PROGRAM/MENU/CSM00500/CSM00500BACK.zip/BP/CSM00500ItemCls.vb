﻿Imports R_BackEnd
Imports R_Common
Imports CSM00500Common
Imports System.Data.Common
Imports System.Transactions
Imports ServerHelper.General

Public Class CSM00500ItemCls
    Implements R_IBatchProcess

    Public Sub R_BatchProcess(poBatchProcessPar As R_Common.R_BatchProcessPar) Implements R_Common.R_IBatchProcess.R_BatchProcess
        Dim loEx As New R_Exception()
        Dim loObject As List(Of CSM00500BatchDTO)
        Dim loDb As New R_Db
        Dim lcQuery As String
        Dim loConn As DbConnection
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim CUSER_ID As String
        Dim loMapping As New Dictionary(Of String, String)()
        Dim countLoop As Integer = 0
        Dim CCOMP_ID As String
        Dim loResult As List(Of CSM00500SessionValidationDTO)
        Dim lcPreviousItem As String
        Dim lcSkippedItem As String
        Dim loKey As New CSM00500KeyDTO
        Dim lcRtn As String = "UNKNOWN_ERROR"
        'Dim lcScheduleId As String

        Try
            loConn = loDb.GetConnection()

            'get all program
            loObject = R_Utility.Deserialize(poBatchProcessPar.BigObject)
            CCOMP_ID = poBatchProcessPar.Key.COMPANY_ID
            CUSER_ID = poBatchProcessPar.Key.USER_ID

            ' validasi status initial schedule
            lcQuery = "EXEC RSP_Session_Validation '{0}', '{1}', '{2}', '{3}', '{4}', '', '', '', '', 'CHECK_INIT_SCHEDULE' "
            With loObject.FirstOrDefault
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, _
                                    .CAPPS_CODE, _
                                    .CVERSION, _
                                    .CPROJECT_ID, _
                                    .CSESSION_ID)
            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00500SessionValidationDTO)(lcQuery, loConn, False)
            If loResult.Count > 0 Then
                For Each result As CSM00500SessionValidationDTO In loResult
                    loEx.Add(result.CMESSAGE_CODE, result.CDESCRIPTION)
                Next
                Exit Try
            End If

            Using TransScope As New TransactionScope(TransactionScopeOption.Required)

                With loObject.FirstOrDefault
                    loKey.CCOMPANY_ID = .CCOMPANY_ID
                    loKey.CAPPS_CODE = .CAPPS_CODE
                    loKey.CVERSION = .CVERSION
                    loKey.CPROJECT_ID = .CPROJECT_ID
                    loKey.CSESSION_ID = .CSESSION_ID
                    loKey.CUSER_ID = .CUSER_ID
                End With

                For Each save As CSM00500BatchDTO In loObject.OrderBy(Function(x) x.CITEM_ID)
                    countLoop += 1

                    If save.CITEM_ID = lcSkippedItem Then
                        If countLoop < loObject.Count Then
                            Continue For
                        Else
                            Exit For
                        End If
                    End If

                    lcQuery = "exec RSP_WriteUploadProcessStatus '{0}', '{1}', '{2}', '{3}', '{4}'"
                    lcQuery = String.Format(lcQuery, CCOMP_ID, CUSER_ID, poBatchProcessPar.Key.KEY_GUID.Trim, countLoop, "Save " + save.CITEM_ID)
                    loDb.SqlExecNonQuery(lcQuery, loConn, False)

                    'validate item, skip if invalid
                    If Not save.CITEM_ID.Equals(lcPreviousItem) Then
                        lcQuery = "EXEC RSP_Session_Validation '{0}', '{1}', '{2}', '{3}', '{4}', '', '{5}', '{6}', '{7}', 'ADD_ITEM' "
                        lcQuery = String.Format(lcQuery, save.CCOMPANY_ID, _
                                                save.CAPPS_CODE, _
                                                save.CVERSION, _
                                                save.CPROJECT_ID, _
                                                save.CSESSION_ID, _
                                                save.CATTRIBUTE_GROUP, _
                                                save.CATTRIBUTE_ID, _
                                                save.CITEM_ID)
                        loResult = loDb.SqlExecObjectQuery(Of CSM00500SessionValidationDTO)(lcQuery, loConn, False)
                        If loResult.Count > 0 Then
                            For Each result As CSM00500SessionValidationDTO In loResult
                                loEx.Add(result.CMESSAGE_CODE, result.CDESCRIPTION)
                            Next
                            If countLoop < loObject.Count Then
                                lcSkippedItem = save.CITEM_ID
                                Continue For
                            Else
                                Exit For
                            End If
                        Else
                            'insert into project items
                            With save
                                lcQuery = "INSERT INTO CSM_PROJECT_PROGRAMS ("
                                lcQuery += "CCOMPANY_ID, "
                                lcQuery += "CAPPS_CODE, "
                                lcQuery += "CVERSION, "
                                lcQuery += "CPROJECT_ID, "
                                lcQuery += "CSESSION_ID, "
                                lcQuery += "CATTRIBUTE_GROUP, "
                                lcQuery += "CATTRIBUTE_ID, "
                                lcQuery += "CITEM_ID, "
                                lcQuery += "CSTATUS, "
                                lcQuery += "CSPEC_STATUS, "
                                lcQuery += "CUPDATE_BY, "
                                lcQuery += "DUPDATE_DATE, "
                                lcQuery += "CCREATE_BY, "
                                lcQuery += "DCREATE_DATE) "
                                lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', 'NEW', 'NEW', '{8}', GETDATE(), '{9}', GETDATE()) "
                                lcQuery = String.Format(lcQuery,
                                .CCOMPANY_ID,
                                .CAPPS_CODE,
                                .CVERSION,
                                .CPROJECT_ID,
                                .CSESSION_ID,
                                .CATTRIBUTE_GROUP,
                                .CATTRIBUTE_ID,
                                .CITEM_ID,
                                poBatchProcessPar.Key.USER_ID,
                                poBatchProcessPar.Key.USER_ID)
                            End With
                            loDb.SqlExecNonQuery(lcQuery, loConn, False)
                        End If
                    End If

                    lcPreviousItem = save.CITEM_ID
                Next

                ' update schedule
                loCmd = loDb.GetCommand()
                lcQuery = "EXEC RSP_Program_Schedule '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', @CRET_MSG OUTPUT "
                With loKey
                    lcQuery = String.Format(lcQuery, _
                                            .CCOMPANY_ID, _
                                            .CAPPS_CODE, _
                                            .CVERSION, _
                                            .CPROJECT_ID, _
                                            .CSESSION_ID,
                                            CUSER_ID)
                End With
                loCmd.CommandText = lcQuery
                loPar = loDb.GetParameter()
                With loPar
                    .ParameterName = "@CRET_MSG"
                    .DbType = DbType.String
                    .Size = 50
                    .Direction = ParameterDirection.Output
                End With
                loCmd.Parameters.Add(loPar)
                loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)

                If loCmd.Parameters("@CRET_MSG") Is Nothing Then
                    lcRtn = "UNKNOWN_ERROR"
                Else
                    lcRtn = loCmd.Parameters("@CRET_MSG").Value
                End If
                If Not lcRtn.Equals("OK") Then
                    loEx.Add(lcRtn, lcRtn)
                    Exit Try
                End If

                lcQuery = "exec RSP_WriteUploadProcessStatus '{0}', '{1}', '{2}', '{3}', '{4}', '{5}'"
                lcQuery = String.Format(lcQuery, CCOMP_ID, CUSER_ID, poBatchProcessPar.Key.KEY_GUID.Trim, countLoop, "Save Complete", 1)
                loDb.SqlExecNonQuery(lcQuery, loConn, True)

                TransScope.Complete()
            End Using

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Function GetAvailableItems(poKey As CSM00500ItemKeyDTO) As List(Of CSM00500ItemGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00500ItemGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "SELECT A.CATTRIBUTE_ID, C.CATTRIBUTE_NAME, "
                If .LCUSTOM Then
                    lcQuery += "A.CPROGRAM_ID AS CITEM_ID, A.CPROGRAM_NAME AS CITEM_NAME, A.LSPEC, '' AS CINITIAL_VERSION "
                    lcQuery += "FROM CSM_PROGRAMS_CUST A (NOLOCK) "
                Else
                    lcQuery += "A.CITEM_ID, A.CITEM_NAME, A.LSPEC, A.CINITIAL_VERSION "
                    lcQuery += "FROM dbo.RFT_Items('{0}', '{1}', '{3}') A "
                End If
                lcQuery += "JOIN CSM_ATTRIBUTES C (NOLOCK) "
                lcQuery += "ON C.CCOMPANY_ID = A.CCOMPANY_ID "
                lcQuery += "AND C.CAPPS_CODE = A.CAPPS_CODE "
                lcQuery += "AND C.CATTRIBUTE_GROUP = A.CATTRIBUTE_GROUP "
                lcQuery += "AND C.CATTRIBUTE_ID = A.CATTRIBUTE_ID "
                If .LCUSTOM Then
                    lcQuery += "WHERE A.CCOMPANY_ID = '{0}' "
                    lcQuery += "AND A.CAPPS_CODE = '{1}' "
                    lcQuery += "AND A.CCUSTOMER_CODE = '{2}' "
                    lcQuery += "AND A.CATTRIBUTE_GROUP = '{3}' "
                    lcQuery += "AND A.CATTRIBUTE_ID = '{4}' "
                Else
                    lcQuery += "WHERE A.CATTRIBUTE_ID = '{4}' "
                End If
                lcQuery += "AND NOT EXISTS "
                lcQuery += "(SELECT TOP 1 CITEM_ID "
                lcQuery += "FROM CSM_PROJECT_PROGRAMS B (NOLOCK) "
                lcQuery += "WHERE(B.CCOMPANY_ID = A.CCOMPANY_ID) "
                lcQuery += "AND B.CAPPS_CODE = A.CAPPS_CODE "
                lcQuery += "AND B.CVERSION = '{2}' "
                lcQuery += "AND B.CATTRIBUTE_GROUP = A.CATTRIBUTE_GROUP "
                lcQuery += "AND B.CATTRIBUTE_ID = A.CATTRIBUTE_ID "
                lcQuery += "AND B.CPROJECT_ID = '{5}' "
                lcQuery += "AND B.CSESSION_ID = '{6}' "
                If .LCUSTOM Then
                    lcQuery += "AND B.CITEM_ID = A.CPROGRAM_ID "
                Else
                    lcQuery += "AND B.CITEM_ID = A.CITEM_ID "
                End If
                lcQuery += ")"
                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CVERSION, _
                                        .CATTRIBUTE_GROUP, _
                                        .CATTRIBUTE_ID, _
                                        .CPROJECT_ID, _
                                        .CSESSION_ID)

            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00500ItemGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetSelectedItems(poKey As CSM00500ItemKeyDTO) As List(Of CSM00500ItemGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00500ItemGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "SELECT DISTINCT A.CATTRIBUTE_ID, C.CATTRIBUTE_NAME, B.CITEM_ID, "
                lcQuery += "A.CITEM_NAME, "
                lcQuery += "A.LSPEC, A.CINITIAL_VERSION "
                lcQuery += "FROM dbo.RFT_Items('{0}', '{1}', '{3}') A "
                lcQuery += "JOIN CSM_PROJECT_PROGRAMS B (NOLOCK) "
                lcQuery += "ON B.CCOMPANY_ID = A.CCOMPANY_ID "
                lcQuery += "AND B.CAPPS_CODE = A.CAPPS_CODE "
                lcQuery += "AND B.CVERSION = '{2}' "
                lcQuery += "AND B.CATTRIBUTE_GROUP = A.CATTRIBUTE_GROUP "
                lcQuery += "AND B.CATTRIBUTE_ID = A.CATTRIBUTE_ID "
                lcQuery += "AND B.CITEM_ID = A.CITEM_ID "
                lcQuery += "JOIN CSM_ATTRIBUTES C (NOLOCK) "
                lcQuery += "ON C.CCOMPANY_ID = A.CCOMPANY_ID "
                lcQuery += "AND C.CAPPS_CODE = A.CAPPS_CODE "
                lcQuery += "AND C.CATTRIBUTE_GROUP = A.CATTRIBUTE_GROUP "
                lcQuery += "AND C.CATTRIBUTE_ID = A.CATTRIBUTE_ID "
                lcQuery += "WHERE B.CPROJECT_ID = '{5}' "
                lcQuery += "AND B.CSESSION_ID = '{6}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CVERSION, _
                                        .CATTRIBUTE_GROUP, _
                                        .CATTRIBUTE_ID, _
                                        .CPROJECT_ID, _
                                        .CSESSION_ID)

            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00500ItemGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Sub DeleteItem(poKey As CSM00500ItemKeyDTO)
        Dim loEx As New R_Exception()
        Dim loConn As DbConnection
        Dim loDb As New R_Db
        Dim lcQuery As String
        Dim loResult As List(Of CSM00500SessionValidationDTO)
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcRtn As String = "OK"

        Try
            Using TransScope As New TransactionScope(TransactionScopeOption.Required)
                loConn = loDb.GetConnection()
                ' validation:
                '   Status is not CLOSED
                '   Item status is not empty
                With poKey
                    lcQuery = "EXEC RSP_Session_Validation '{0}', '{1}', '{2}', '{3}', '{4}', '', '{5}', '{6}', '{7}', 'DELETE_ITEM' "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, _
                                                            .CAPPS_CODE, _
                                                            .CVERSION, _
                                                            .CPROJECT_ID, _
                                                            .CSESSION_ID, _
                                                            .CATTRIBUTE_GROUP, _
                                                            .CATTRIBUTE_ID, _
                                                            .CITEM_ID)

                    loResult = loDb.SqlExecObjectQuery(Of CSM00500SessionValidationDTO)(lcQuery, loConn, False)
                    If loResult.Count > 0 Then
                        For Each result As CSM00500SessionValidationDTO In loResult
                            loEx.Add(result.CMESSAGE_CODE, result.CDESCRIPTION)
                        Next
                        Exit Try
                    End If
                    ' delete item
                    lcQuery = "DELETE CSM_PROJECT_PROGRAMS "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CVERSION = '{2}' "
                    lcQuery += "AND CPROJECT_ID = '{3}' "
                    lcQuery += "AND CSESSION_ID = '{4}' "
                    lcQuery += "AND CATTRIBUTE_GROUP = '{5}' "
                    lcQuery += "AND CATTRIBUTE_ID = '{6}' "
                    lcQuery += "AND CITEM_ID = '{7}' "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, _
                                            .CAPPS_CODE, _
                                            .CVERSION, _
                                            .CPROJECT_ID, _
                                            .CSESSION_ID, _
                                            .CATTRIBUTE_GROUP, _
                                            .CATTRIBUTE_ID, _
                                            .CITEM_ID)
                    loDb.SqlExecNonQuery(lcQuery, loConn, False)

                    ' update schedule
                    loCmd = loDb.GetCommand()
                    lcQuery = "EXEC RSP_Program_Schedule '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', @CRET_MSG OUTPUT "
                    lcQuery = String.Format(lcQuery, _
                                                .CCOMPANY_ID, _
                                                .CAPPS_CODE, _
                                                .CVERSION, _
                                                .CPROJECT_ID, _
                                                .CSESSION_ID,
                                                .CUSER_ID)
                    loCmd.CommandText = lcQuery
                    loPar = loDb.GetParameter()
                    With loPar
                        .ParameterName = "@CRET_MSG"
                        .DbType = DbType.String
                        .Size = 50
                        .Direction = ParameterDirection.Output
                    End With
                    loCmd.Parameters.Add(loPar)
                    loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)

                    If loCmd.Parameters("@CRET_MSG") Is Nothing Then
                        lcRtn = "UNKNOWN_ERROR"
                    Else
                        lcRtn = loCmd.Parameters("@CRET_MSG").Value
                    End If
                    If Not lcRtn.Equals("OK") Then
                        loEx.Add(lcRtn, lcRtn)
                        Exit Try
                    End If
                End With
                TransScope.Complete()
            End Using

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function GetDefaultPIC(poKey As CSM00500KeyDTO) As CSM00500DefaultPICDTO
        Dim lcQuery As String
        Dim loResult As CSM00500DefaultPICDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "EXEC RSP_Get_Default_PIC '{0}', '{1}', '{2}', '{3}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CVERSION, _
                                        .CPROJECT_ID)

            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00500DefaultPICDTO)(lcQuery).FirstOrDefault
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

End Class
