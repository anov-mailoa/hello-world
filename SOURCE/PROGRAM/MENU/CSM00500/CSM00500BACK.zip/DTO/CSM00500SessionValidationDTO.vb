﻿Public Class CSM00500SessionValidationDTO
    Public Property CMESSAGE_CODE As String
    Public Property CDESCRIPTION As String
End Class
