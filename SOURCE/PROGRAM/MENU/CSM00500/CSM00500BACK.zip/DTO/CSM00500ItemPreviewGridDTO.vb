﻿Public Class CSM00500ItemPreviewGridDTO
    Public Property CATTRIBUTE_GROUP As String
    Public Property CATTRIBUTE_ID As String
    Public Property CATTRIBUTE_NAME As String
    Public Property CITEM_ID As String
    Public Property CITEM_NAME As String
    Public Property CSTATUS As String
    Public Property CLAST_ACTION As String
    Public Property CLAST_ACTION_BY As String
    Public Property CLAST_ACTION_BY_NAME As String
End Class
