﻿Public Class CSM00500DefaultPICDTO
    Public Property CDESIGN_USER_ID As String
    Public Property CDESIGN_USER_NAME As String
    Public Property CDEVELOPMENT_USER_ID As String
    Public Property CDEVELOPMENT_USER_NAME As String
    Public Property CQC_USER_ID As String
    Public Property CQC_USER_NAME As String
End Class
