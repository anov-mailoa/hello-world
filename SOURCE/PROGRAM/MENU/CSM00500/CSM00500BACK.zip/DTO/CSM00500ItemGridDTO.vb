﻿Public Class CSM00500ItemGridDTO
    Public Property LSELECT As Boolean
    Public Property CATTRIBUTE_ID As String
    Public Property CATTRIBUTE_NAME As String
    Public Property CITEM_ID As String
    Public Property CITEM_NAME As String
    Public Property LSPEC As Boolean
    Public Property CINITIAL_VERSION As String
End Class
