﻿Imports R_BackEnd

<Serializable()> _
Public Class CSM00500SessionDTO
    Inherits R_DTOBase

    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CVERSION As String
    Public Property CPROJECT_ID As String
    Public Property CSESSION_ID As String
    Public Property CINIT_SCHEDULE_TYPE As String
    Public Property CSCHEDULE_TYPE_NAME As String
    Public Property DSESSION_DATE As Nullable(Of DateTime)
    Public Property DCLOSE_DATE As Nullable(Of DateTime)
    Public Property CNOTE As String
    Public Property CPLAN_START_DATE As String
    Public Property CPLAN_END_DATE As String
    Public Property CACTUAL_START_DATE As String
    Public Property CACTUAL_END_DATE As String
    Public Property CSTATUS As String
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)
    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)

    Public Property CUSER_NAME As String

    ' for date time format
    Public Property DPLAN_START_DATE As Nullable(Of DateTime)
    Public Property DPLAN_END_DATE As Nullable(Of DateTime)
    Public Property DACTUAL_START_DATE As Nullable(Of DateTime)
    Public Property DACTUAL_END_DATE As Nullable(Of DateTime)

End Class
