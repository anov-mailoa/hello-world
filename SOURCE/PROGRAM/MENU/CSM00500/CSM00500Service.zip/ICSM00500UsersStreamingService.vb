﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports CSM00500Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00500UsersStreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00500UsersStreamingService

    <OperationContract(Action:="getProjectUserList", ReplyAction:="getProjectUserList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetProjectUserList() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of CSM00500UsersGridDTO))

End Interface
