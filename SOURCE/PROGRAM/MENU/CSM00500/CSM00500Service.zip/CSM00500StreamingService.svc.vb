﻿Imports R_Common
Imports CSM00500Back
Imports System.ServiceModel.Channels
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00500StreamingService" in code, svc and config file together.
Public Class CSM00500StreamingService
    Implements ICSM00500StreamingService

    Public Function GetProjectList() As System.ServiceModel.Channels.Message Implements ICSM00500StreamingService.GetProjectList
        Dim loException As New R_Exception
        Dim loCls As New CSM00500Cls
        Dim loRtnTemp As List(Of CSM00500GridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00500KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .LCUSTOM = R_Utility.R_GetStreamingContext("lCustom")
                .CCUSTOMER_CODE = R_Utility.R_GetStreamingContext("cCustomerCode")
            End With

            loRtnTemp = loCls.GetProjectList(loTableKey)

            loRtn = R_StreamUtility(Of CSM00500GridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getProjectList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn

    End Function

    Public Function GetProjectManagerList() As System.ServiceModel.Channels.Message Implements ICSM00500StreamingService.GetProjectManagerList
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtnTemp As List(Of RCustDBUserListDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00500KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
            End With

            loRtnTemp = loCls.GetUserList(loTableKey.CCOMPANY_ID)

            loRtn = R_StreamUtility(Of RCustDBUserListDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getProjectManagerList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn

    End Function

    Public Function GetProjectUserList() As System.ServiceModel.Channels.Message Implements ICSM00500StreamingService.GetProjectUserList
        Dim loException As New R_Exception
        Dim loCls As New CSM00500UsersCls
        Dim loRtnTemp As List(Of CSM00500UsersGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00500UsersKeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .CPROJECT_ID = R_Utility.R_GetStreamingContext("cProjectId")
                .CFUNCTION_ID = R_Utility.R_GetStreamingContext("cFunctionId")
                .CSESSION_ID = R_Utility.R_GetStreamingContext("cSessionId")
            End With

            loRtnTemp = loCls.GetProjectUserList(loTableKey)

            loRtn = R_StreamUtility(Of CSM00500UsersGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getProjectUserList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of CSM00500Back.CSM00500GridDTO), poPar2 As System.Collections.Generic.List(Of RLicenseBack.RCustDBUserListDTO), poPar3 As System.Collections.Generic.List(Of CSM00500Back.CSM00500UsersGridDTO)) Implements ICSM00500StreamingService.Dummy

    End Sub
End Class
