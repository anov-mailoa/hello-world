﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports CSM00500Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00500ItemStreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00500ItemStreamingService

    <OperationContract(Action:="getAvailableItemsList", ReplyAction:="getAvailableItemsList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAvailableItems() As Message

    <OperationContract(Action:="getSelectedItemsList", ReplyAction:="getSelectedItemsList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetSelectedItems() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of CSM00500ItemGridDTO))

End Interface
