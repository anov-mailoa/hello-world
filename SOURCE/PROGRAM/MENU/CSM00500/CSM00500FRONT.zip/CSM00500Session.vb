﻿Imports CSM00500FrontResources
Imports R_Common
Imports ClientHelper
Imports CSM00500Front.CSM00500SessionServiceRef
Imports R_FrontEnd
Imports CSM00500Front.CSM00500SessionStreamingServiceRef
Imports System.ServiceModel.Channels
Imports CSM00500Front.CSM00500ServiceRef
Imports RCustDBFrontHelper.General

Public Class CSM00500Session

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSM00500Service/CSM00500SessionService.svc"
    Dim C_ServiceNameStream As String = "CSM00500Service/CSM00500SessionStreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _CVERSION As String
    Dim _CPROJECTID As String
    Dim _CUSER_NAME As String
    Dim _CCUSTOMER_NAME As String
    Dim _LCUSTOM As Boolean
#End Region

#Region " SUB and FUNCTION "

    Private Sub RefreshGrids()
        Dim loTableKey As New CSM00500KeyDTO

        With loTableKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = _CAPPSCODE
            .CVERSION = _CVERSION
            .CPROJECT_ID = _CPROJECTID
        End With

        gvSession.R_RefreshGrid(loTableKey)
    End Sub


#End Region

#Region " FORM Events "

    Private Sub CSM00500Session_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loSvc As CSM00500SessionServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00500SessionService, CSM00500SessionServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loScheduleTypeCombo As New List(Of RCustDBScheduleTypeComboDTO)

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            With CType(poParameter, CSM00500DetailParameterDTO)
                _CAPPSCODE = .OGRID_KEY.CAPPS_CODE
                _CVERSION = .OGRID_KEY.CVERSION
                _CPROJECTID = .OGRID_KEY.CPROJECT_ID
                _LCUSTOM = .OGRID_KEY.LCUSTOM
                _CCUSTOMER_NAME = .CCUSTOMER_NAME
                txtApplication.Text = .CAPPS_NAME
                txtVersion.Text = IIf(.OGRID_KEY.LCUSTOM, .CCUSTOMER_NAME, .OGRID_KEY.CVERSION)
                txtProject.Text = .CPROJECT_NAME
                lblVersion.Visible = Not .OGRID_KEY.LCUSTOM
                lblCustomer.Visible = .OGRID_KEY.LCUSTOM
                lblCustom.Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), IIf(_LCUSTOM, "rdbCustom", "rdbStandard"))
            End With

            ' combo
            loScheduleTypeCombo = loSvc.GetScheduleTypeCombo("CSM00500")
            bsScheduleType.DataSource = loScheduleTypeCombo
            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loSvc.Close()
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub CSM00500Session_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " BUTTON Actions "

    Private Sub btnCreateSession_Click(sender As Object, e As System.EventArgs) Handles btnCreateSession.Click
        Dim loService As CSM00500SessionServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00500SessionService, CSM00500SessionServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim loPar As New CSM00500SessionKeyDTO

        Try

            With loPar
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = _CAPPSCODE
                .CVERSION = _CVERSION
                .CPROJECT_ID = _CPROJECTID
                .CUSER_ID = _CUSERID
                .CINIT_SCHEDULE_TYPE = cboScheduleType.SelectedValue
            End With
            loService.CreateSession(loPar)
            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loService.Close()
        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If
    End Sub

    Private Sub btnPIC_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnPIC.R_Before_Open_Form
        Dim loPICKey As New CSM00500KeyDTO

        poTargetForm = New CSM00500PIC

        With loPICKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = _CAPPSCODE
            .CVERSION = _CVERSION
            .CPROJECT_ID = _CPROJECTID
            .CSESSION_ID = CType(bsGvSession.Current, CSM00500SessionDTO)._CSESSION_ID
            .LCUSTOM = _LCUSTOM
        End With
        poParameter = New CSM00500DetailParameterDTO With {.CAPPS_NAME = txtApplication.Text.Trim,
                                                        .CPROJECT_NAME = txtProject.Text.Trim,
                                                           .CCUSTOMER_NAME = _CCUSTOMER_NAME,
                                                           .CSESSION_ID = CType(bsGvSession.Current, CSM00500SessionDTO)._CSESSION_ID,
                                                           .CSESSION_STATUS = CType(bsGvSession.Current, CSM00500SessionDTO)._CSTATUS,
                                                        .OGRID_KEY = loPICKey}

    End Sub

    Private Sub btnAddItem_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnAddItem.R_Before_Open_Form
        Dim loPICKey As New CSM00500KeyDTO

        poTargetForm = New CSM00500Item

        With loPICKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = _CAPPSCODE
            .CVERSION = _CVERSION
            .CPROJECT_ID = _CPROJECTID
            .LCUSTOM = _LCUSTOM
        End With
        poParameter = New CSM00500DetailParameterDTO With {.CAPPS_NAME = txtApplication.Text.Trim,
                                                        .CPROJECT_NAME = txtProject.Text.Trim,
                                                           .CCUSTOMER_NAME = _CCUSTOMER_NAME,
                                                           .CSESSION_ID = CType(bsGvSession.Current, CSM00500SessionDTO)._CSESSION_ID,
                                                           .CSESSION_STATUS = CType(bsGvSession.Current, CSM00500SessionDTO)._CSTATUS,
                                                           .CINIT_SCHEDULE_TYPE = CType(bsGvSession.Current, CSM00500SessionDTO)._CINIT_SCHEDULE_TYPE,
                                                        .OGRID_KEY = loPICKey}
    End Sub

    Private Sub btnStartSession_Click(sender As System.Object, e As System.EventArgs) Handles btnStartSession.Click
        Dim loService As CSM00500SessionServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00500SessionService, CSM00500SessionServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim loPar As New CSM00500SessionKeyDTO

        Try
            With loPar
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = _CAPPSCODE
                .CVERSION = _CVERSION
                .CPROJECT_ID = _CPROJECTID
                .CSESSION_ID = CType(bsGvSession.Current, CSM00500SessionDTO)._CSESSION_ID
                .CUSER_ID = _CUSERID
                .CNOTE = CType(bsGvSession.Current, CSM00500SessionDTO)._CNOTE
            End With
            loService.StartSession(loPar)
            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loService.Close()
        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If

    End Sub

    Private Sub btnCloseSession_Click(sender As Object, e As System.EventArgs) Handles btnCloseSession.Click
        Dim loService As CSM00500SessionServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00500SessionService, CSM00500SessionServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception
        Dim loPar As New CSM00500SessionKeyDTO

        Try
            With loPar
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = _CAPPSCODE
                .CVERSION = _CVERSION
                .CPROJECT_ID = _CPROJECTID
                .CSESSION_ID = CType(bsGvSession.Current, CSM00500SessionDTO)._CSESSION_ID
                .CNOTE = CType(bsGvSession.Current, CSM00500SessionDTO)._CNOTE
                .CUSER_ID = _CUSERID
            End With
            loService.CloseSession(loPar)
            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loService.Close()
        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If
    End Sub

#End Region

#Region " GRIDVIEW Events "

    Private Sub gvSession_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvSession.DataBindingComplete
        gvSession.BestFitColumns()
    End Sub

    Private Sub gvSession_R_CheckDelete(poEntity As Object, ByRef plAllowDelete As Boolean) Handles gvSession.R_CheckDelete
        With CType(poEntity, CSM00500SessionDTO)
            plAllowDelete = ._CSTATUS = "NEW"
        End With

    End Sub

    Private Sub gvSession_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvSession.R_Saving
        With CType(poEntity, CSM00500SessionDTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = _CAPPSCODE
            ._CVERSION = _CVERSION
            ._CPROJECT_ID = _CPROJECTID
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With
    End Sub

    Private Sub gvSession_R_ServiceDelete(poEntity As Object) Handles gvSession.R_ServiceDelete
        Dim loService As CSM00500SessionServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00500SessionService, CSM00500SessionServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSession_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvSession.R_ServiceGetListRecord
        Dim loServiceStream As CSM00500SessionStreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00500SessionStreamingService, CSM00500SessionStreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00500SessionGridDTO)
        Dim loListEntity As New List(Of CSM00500SessionDTO)

        Try
            With CType(poEntity, CSM00500KeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
                R_Utility.R_SetStreamingContext("cProjectId", .CPROJECT_ID)
            End With

            loRtn = loServiceStream.GetProjectSessionList()
            loStreaming = R_StreamUtility(Of CSM00500SessionGridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00500SessionGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New CSM00500SessionDTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                                  ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                                  ._CVERSION = loDto.CVERSION,
                                                                  ._CPROJECT_ID = loDto.CPROJECT_ID,
                                                                  ._CSESSION_ID = loDto.CSESSION_ID,
                                                                  ._CSCHEDULE_TYPE_NAME = loDto.CSCHEDULE_TYPE_NAME,
                                                                  ._DSESSION_DATE = loDto.DSESSION_DATE,
                                                                  ._CSTATUS = loDto.CSTATUS,
                                                                  ._CNOTE = loDto.CNOTE,
                                                                  ._DPLAN_START_DATE = StrToDate(loDto.CPLAN_START_DATE),
                                                                  ._DPLAN_END_DATE = StrToDate(loDto.CPLAN_END_DATE),
                                                                  ._DACTUAL_START_DATE = StrToDate(loDto.CACTUAL_START_DATE),
                                                                  ._DACTUAL_END_DATE = StrToDate(loDto.CACTUAL_END_DATE),
                                                                  ._DCLOSE_DATE = loDto.DCLOSE_DATE,
                                                                  ._CINIT_SCHEDULE_TYPE = loDto.CINIT_SCHEDULE_TYPE,
                                                                    ._CCREATE_BY = loDto.CCREATE_BY,
                                                                    ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                                    ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                                    ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loServiceStream.Close()
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSession_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvSession.R_ServiceGetRecord
        Dim loService As CSM00500SessionServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00500SessionService, CSM00500SessionServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New CSM00500SessionDTO With {._CCOMPANY_ID = _CCOMPID,
                                                                                      ._CAPPS_CODE = _CAPPSCODE,
                                                                                  ._CVERSION = _CVERSION,
                                                                                  ._CPROJECT_ID = _CPROJECTID,
                                                                                      ._CSESSION_ID = CType(bsGvSession.Current, CSM00500SessionDTO)._CSESSION_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loService.Close()
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvSession_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvSession.R_ServiceSave
        Dim loService As CSM00500SessionServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00500SessionService, CSM00500SessionServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loService.Close()
        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region


End Class
