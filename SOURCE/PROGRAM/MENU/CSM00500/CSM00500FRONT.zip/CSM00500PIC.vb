﻿Imports CSM00500FrontResources
Imports R_Common
Imports ClientHelper
Imports CSM00500Front.CSM00500UsersServiceRef
Imports R_FrontEnd
Imports CSM00500Front.CSM00500UsersStreamingServiceRef
Imports System.ServiceModel.Channels
Imports CSM00500Front.CSM00500ServiceRef

Public Class CSM00500PIC

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSM00500Service/CSM00500UsersService.svc"
    Dim C_ServiceNameStream As String = "CSM00500Service/CSM00500UsersStreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _CVERSION As String
    Dim _CPROJECTID As String
    Dim _CSESSIONID As String
    Dim _CUSER_NAME As String
    Dim _CCUSTOMER_NAME As String
    Dim _LCUSTOM As Boolean
#End Region

#Region " FORM Events "

    Private Sub CSM00500PIC_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loSvc As CSM00500UsersServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00500UsersService, CSM00500UsersServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loFunctionCombo As New List(Of RCustDBFunctionComboDTO)
        Dim loLocationCombo As New List(Of RCustDBLocationComboDTO)

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            With CType(poParameter, CSM00500DetailParameterDTO)
                _CAPPSCODE = .OGRID_KEY.CAPPS_CODE
                _CVERSION = .OGRID_KEY.CVERSION
                _CPROJECTID = .OGRID_KEY.CPROJECT_ID
                _CSESSIONID = .OGRID_KEY.CSESSION_ID
                _LCUSTOM = .OGRID_KEY.LCUSTOM
                _CCUSTOMER_NAME = .CCUSTOMER_NAME
                txtApplication.Text = .CAPPS_NAME
                txtVersion.Text = .OGRID_KEY.CVERSION
                txtProject.Text = .CPROJECT_NAME
                txtSession.Text = .CSESSION_ID
                lblVersion.Visible = Not .OGRID_KEY.LCUSTOM
                lblCustomer.Visible = .OGRID_KEY.LCUSTOM
                lblCustom.Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), IIf(_LCUSTOM, "rdbCustom", "rdbStandard"))
            End With
            ' initialize function combo
            loFunctionCombo = loSvc.GetFunctionCombo(New RCustDBProjectKeyDTO With {.CCOMPANY_ID = _CCOMPID, _
                                                       .CAPPS_CODE = _CAPPSCODE, _
                                                          .CVERSION = _CVERSION, _
                                                                .CPROJECT_ID = _CPROJECTID, _
                                                                         .CUSER_ID = _CUSERID, _
                                                                                    .LCHECK_PROJECT_MANAGER = True})
            bsFunction.DataSource = loFunctionCombo
            loLocationCombo = loSvc.GetLocationCombo()
            bsLocation.DataSource = loLocationCombo
            loSvc.Close()

            gvUsers.R_RefreshGrid(CType(poParameter, CSM00500DetailParameterDTO).OGRID_KEY)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub CSM00500PIC_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " GRIDVIEW Events "

    Private Sub gvUsers_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvUsers.DataBindingComplete
        gvUsers.BestFitColumns()
    End Sub

    Private Sub gvUsers_R_Before_Open_LookUpForm(sender As Object, e As Telerik.WinControls.UI.EditorRequiredEventArgs, ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles gvUsers.R_Before_Open_LookUpForm
        poTargetForm = New CSM00500UserList
        poParameter = New CSM00500UserListParameterDTO With {.CCOMPANY_ID = _CCOMPID}
    End Sub

    Private Sub gvUsers_R_Return_LookUp(sender As Object, e As Telerik.WinControls.UI.EditorRequiredEventArgs, poReturnObject As Object) Handles gvUsers.R_Return_LookUp
        gvUsers.CurrentRow.Cells("_CUSER_ID").Value = poReturnObject.CUSER_ID
        gvUsers.CurrentRow.Cells("_CUSER_NAME").Value = poReturnObject.CUSER_NAME
    End Sub

    Private Sub gvUsers_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvUsers.R_Saving
        With CType(poEntity, CSM00500UsersDTO)
            ._CCOMPANY_ID = _CCOMPID
            ._CAPPS_CODE = _CAPPSCODE
            ._CVERSION = _CVERSION
            ._CPROJECT_ID = _CPROJECTID
            ._CSESSION_ID = _CSESSIONID
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With
    End Sub

    Private Sub gvUsers_R_ServiceDelete(poEntity As Object) Handles gvUsers.R_ServiceDelete
        Dim loService As CSM00500UsersServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00500UsersService, CSM00500UsersServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loService.Close()
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvUsers_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvUsers.R_ServiceGetListRecord
        Dim loServiceStream As CSM00500UsersStreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00500UsersStreamingService, CSM00500UsersStreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00500UsersGridDTO)
        Dim loListEntity As New List(Of CSM00500UsersDTO)

        Try
            With CType(poEntity, CSM00500KeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
                R_Utility.R_SetStreamingContext("cProjectId", .CPROJECT_ID)
                R_Utility.R_SetStreamingContext("cSessionId", .CSESSION_ID)
            End With

            loRtn = loServiceStream.GetProjectUserList()
            loStreaming = R_StreamUtility(Of CSM00500UsersGridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00500UsersGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New CSM00500UsersDTO With {._CCOMPANY_ID = loDto.CCOMPANY_ID,
                                                                ._CAPPS_CODE = loDto.CAPPS_CODE,
                                                                ._CVERSION = loDto.CVERSION,
                                                                ._CPROJECT_ID = loDto.CPROJECT_ID,
                                                                ._CSESSION_ID = loDto.CSESSION_ID,
                                                                ._CFUNCTION_ID = loDto.CFUNCTION_ID,
                                                                ._CUSER_ID = loDto.CUSER_ID,
                                                                ._CUSER_NAME = loDto.CUSER_NAME,
                                                                ._LMANAGER = loDto.LMANAGER,
                                                                ._CLOCATION_ID = loDto.CLOCATION_ID,
                                                                    ._CCREATE_BY = loDto.CCREATE_BY,
                                                                    ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                                    ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                                    ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loServiceStream.Close()
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvUsers_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvUsers.R_ServiceGetRecord
        Dim loService As CSM00500UsersServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00500UsersService, CSM00500UsersServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New CSM00500UsersDTO With {._CCOMPANY_ID = _CCOMPID,
                                                                                  ._CAPPS_CODE = _CAPPSCODE,
                                                                                  ._CVERSION = _CVERSION,
                                                                                  ._CPROJECT_ID = _CPROJECTID,
                                                                                  ._CSESSION_ID = _CSESSIONID,
                                                                                  ._CFUNCTION_ID = CType(bsGvUsers.Current, CSM00500UsersDTO)._CFUNCTION_ID,
                                                                                  ._CUSER_ID = CType(bsGvUsers.Current, CSM00500UsersDTO)._CUSER_ID,
                                                                                  ._CUSER_NAME = CType(bsGvUsers.Current, CSM00500UsersDTO)._CUSER_NAME})
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loService.Close()
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvUsers_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvUsers.R_ServiceSave
        Dim loService As CSM00500UsersServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00500UsersService, CSM00500UsersServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loService.Close()
        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvUsers_R_Validation(poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode, ByRef plCancel As Boolean, ByRef pcError As String) Handles gvUsers.R_Validation
        Dim loEx As New R_Exception()

        Try
            With poGridCellCollection
                If String.IsNullOrWhiteSpace(.Item("_CFUNCTION_ID").Value) Then
                    loEx.Add("CSM00500_09", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00500_09"))
                    plCancel = True
                End If
                If String.IsNullOrWhiteSpace(.Item("_CLOCATION_ID").Value) Then
                    loEx.Add("CSM00500_10", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CSM00500_10"))
                    plCancel = True
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

End Class
