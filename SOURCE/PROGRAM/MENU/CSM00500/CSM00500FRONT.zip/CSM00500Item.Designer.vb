﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSM00500Item
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewCheckBoxSelectColumn1 As R_FrontEnd.R_GridViewCheckBoxSelectColumn = New R_FrontEnd.R_GridViewCheckBoxSelectColumn()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn1 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn6 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn2 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewTextBoxColumn7 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblCustomer = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblAttributeGroup = New R_FrontEnd.R_RadLabel(Me.components)
        Me.cboAttributeGroup = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsAttributeGroup = New System.Windows.Forms.BindingSource(Me.components)
        Me.conAvailable = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.txtSession = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblSession = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtProject = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.btnProcess = New R_FrontEnd.R_RadButton(Me.components)
        Me.lblProject = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtVersion = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtApplication = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblVersion = New R_FrontEnd.R_RadLabel(Me.components)
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.lblAttribute = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvAvailableItems = New R_FrontEnd.R_RadGridView(Me.components)
        Me.cboAttribute = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.lblAvailableItems = New R_FrontEnd.R_RadLabel(Me.components)
        Me.btnDeleteItem = New R_FrontEnd.R_RadButton(Me.components)
        Me.lblSelectedItems = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvSelectedItems = New R_FrontEnd.R_RadGridView(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.cboScheduleType = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.lblScheduleType = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblQC = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblDevelopment = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblDesign = New R_FrontEnd.R_RadLabel(Me.components)
        Me.btnQC = New R_FrontEnd.R_LookUp(Me.components)
        Me.txtQCPIC = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.btnDevelopment = New R_FrontEnd.R_LookUp(Me.components)
        Me.txtDevelopmentPIC = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.btnDesign = New R_FrontEnd.R_LookUp(Me.components)
        Me.txtDesignPIC = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblPICTitle = New R_FrontEnd.R_RadLabel(Me.components)
        Me.bwCSM00500 = New System.ComponentModel.BackgroundWorker()
        Me.bsGvAvailableItems = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsAttribute = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsGvSelectedItems = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsScheduleType = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblCustom = New R_FrontEnd.R_RadLabel(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblAttributeGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboAttributeGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsAttributeGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conAvailable, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnProcess, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.lblAttribute, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvAvailableItems, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvAvailableItems.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboAttribute, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblAvailableItems, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnDeleteItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblSelectedItems, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvSelectedItems, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvSelectedItems.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.cboScheduleType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblScheduleType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblQC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblDevelopment, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblDesign, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnQC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtQCPIC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnDevelopment, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDevelopmentPIC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnDesign, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtDesignPIC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblPICTitle, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvAvailableItems, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsAttribute, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvSelectedItems, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsScheduleType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCustom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.SplitContainer1, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 0, 2)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 144.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 0.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lblCustom)
        Me.Panel1.Controls.Add(Me.lblCustomer)
        Me.Panel1.Controls.Add(Me.lblAttributeGroup)
        Me.Panel1.Controls.Add(Me.cboAttributeGroup)
        Me.Panel1.Controls.Add(Me.txtSession)
        Me.Panel1.Controls.Add(Me.lblSession)
        Me.Panel1.Controls.Add(Me.txtProject)
        Me.Panel1.Controls.Add(Me.btnProcess)
        Me.Panel1.Controls.Add(Me.lblProject)
        Me.Panel1.Controls.Add(Me.txtVersion)
        Me.Panel1.Controls.Add(Me.txtApplication)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Controls.Add(Me.lblVersion)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 138)
        Me.Panel1.TabIndex = 0
        '
        'lblCustomer
        '
        Me.lblCustomer.AutoSize = False
        Me.lblCustomer.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustomer.Location = New System.Drawing.Point(10, 36)
        Me.lblCustomer.Name = "lblCustomer"
        Me.lblCustomer.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustomer.R_ResourceId = "lblCustomer"
        Me.lblCustomer.Size = New System.Drawing.Size(100, 18)
        Me.lblCustomer.TabIndex = 41
        Me.lblCustomer.Text = "Application..."
        '
        'lblAttributeGroup
        '
        Me.lblAttributeGroup.AutoSize = False
        Me.lblAttributeGroup.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblAttributeGroup.Location = New System.Drawing.Point(10, 113)
        Me.lblAttributeGroup.Name = "lblAttributeGroup"
        Me.lblAttributeGroup.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblAttributeGroup.R_ResourceId = "lblAttributeGroup"
        Me.lblAttributeGroup.Size = New System.Drawing.Size(100, 18)
        Me.lblAttributeGroup.TabIndex = 40
        Me.lblAttributeGroup.Text = "Application..."
        '
        'cboAttributeGroup
        '
        Me.cboAttributeGroup.DataSource = Me.bsAttributeGroup
        Me.cboAttributeGroup.DisplayMember = "CATTRIBUTE_GROUP"
        Me.cboAttributeGroup.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboAttributeGroup.Location = New System.Drawing.Point(116, 113)
        Me.cboAttributeGroup.Name = "cboAttributeGroup"
        Me.cboAttributeGroup.R_ConductorGridSource = Me.conAvailable
        Me.cboAttributeGroup.R_ConductorSource = Nothing
        Me.cboAttributeGroup.R_EnableOTHER = True
        Me.cboAttributeGroup.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboAttributeGroup.Size = New System.Drawing.Size(206, 20)
        Me.cboAttributeGroup.TabIndex = 38
        Me.cboAttributeGroup.Text = "R_RadDropDownList1"
        Me.cboAttributeGroup.ValueMember = "CATTRIBUTE_GROUP"
        '
        'conAvailable
        '
        Me.conAvailable.R_ConductorParent = Nothing
        Me.conAvailable.R_IsHeader = True
        Me.conAvailable.R_RadGroupBox = Nothing
        '
        'txtSession
        '
        Me.txtSession.Location = New System.Drawing.Point(116, 87)
        Me.txtSession.Name = "txtSession"
        Me.txtSession.R_ConductorGridSource = Nothing
        Me.txtSession.R_ConductorSource = Nothing
        Me.txtSession.R_UDT = Nothing
        Me.txtSession.ReadOnly = True
        Me.txtSession.Size = New System.Drawing.Size(206, 20)
        Me.txtSession.TabIndex = 37
        Me.txtSession.TabStop = False
        '
        'lblSession
        '
        Me.lblSession.AutoSize = False
        Me.lblSession.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblSession.Location = New System.Drawing.Point(10, 88)
        Me.lblSession.Name = "lblSession"
        Me.lblSession.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblSession.R_ResourceId = "lblSession"
        Me.lblSession.Size = New System.Drawing.Size(100, 18)
        Me.lblSession.TabIndex = 36
        Me.lblSession.Text = "Application..."
        '
        'txtProject
        '
        Me.txtProject.Location = New System.Drawing.Point(116, 61)
        Me.txtProject.Name = "txtProject"
        Me.txtProject.R_ConductorGridSource = Nothing
        Me.txtProject.R_ConductorSource = Nothing
        Me.txtProject.R_UDT = Nothing
        Me.txtProject.ReadOnly = True
        Me.txtProject.Size = New System.Drawing.Size(206, 20)
        Me.txtProject.TabIndex = 35
        Me.txtProject.TabStop = False
        '
        'btnProcess
        '
        Me.btnProcess.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnProcess.Location = New System.Drawing.Point(1158, 110)
        Me.btnProcess.Name = "btnProcess"
        Me.btnProcess.R_ConductorGridSource = Me.conAvailable
        Me.btnProcess.R_ConductorSource = Nothing
        Me.btnProcess.R_DescriptionId = Nothing
        Me.btnProcess.R_EnableOTHER = True
        Me.btnProcess.R_ResourceId = "btnProcess"
        Me.btnProcess.Size = New System.Drawing.Size(110, 24)
        Me.btnProcess.TabIndex = 9
        Me.btnProcess.Text = "R_RadButton1"
        '
        'lblProject
        '
        Me.lblProject.AutoSize = False
        Me.lblProject.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblProject.Location = New System.Drawing.Point(10, 62)
        Me.lblProject.Name = "lblProject"
        Me.lblProject.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblProject.R_ResourceId = "lblProject"
        Me.lblProject.Size = New System.Drawing.Size(100, 18)
        Me.lblProject.TabIndex = 34
        Me.lblProject.Text = "Application..."
        '
        'txtVersion
        '
        Me.txtVersion.Location = New System.Drawing.Point(116, 35)
        Me.txtVersion.Name = "txtVersion"
        Me.txtVersion.R_ConductorGridSource = Nothing
        Me.txtVersion.R_ConductorSource = Nothing
        Me.txtVersion.R_UDT = Nothing
        Me.txtVersion.ReadOnly = True
        Me.txtVersion.Size = New System.Drawing.Size(206, 20)
        Me.txtVersion.TabIndex = 33
        Me.txtVersion.TabStop = False
        '
        'txtApplication
        '
        Me.txtApplication.Location = New System.Drawing.Point(116, 9)
        Me.txtApplication.Name = "txtApplication"
        Me.txtApplication.R_ConductorGridSource = Nothing
        Me.txtApplication.R_ConductorSource = Nothing
        Me.txtApplication.R_UDT = Nothing
        Me.txtApplication.ReadOnly = True
        Me.txtApplication.Size = New System.Drawing.Size(206, 20)
        Me.txtApplication.TabIndex = 32
        Me.txtApplication.TabStop = False
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(10, 10)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 30
        Me.lblApplication.Text = "Application..."
        '
        'lblVersion
        '
        Me.lblVersion.AutoSize = False
        Me.lblVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblVersion.Location = New System.Drawing.Point(10, 36)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblVersion.R_ResourceId = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(100, 18)
        Me.lblVersion.TabIndex = 31
        Me.lblVersion.Text = "Application..."
        '
        'SplitContainer1
        '
        Me.SplitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(3, 147)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.lblAttribute)
        Me.SplitContainer1.Panel1.Controls.Add(Me.gvAvailableItems)
        Me.SplitContainer1.Panel1.Controls.Add(Me.cboAttribute)
        Me.SplitContainer1.Panel1.Controls.Add(Me.lblAvailableItems)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.btnDeleteItem)
        Me.SplitContainer1.Panel2.Controls.Add(Me.lblSelectedItems)
        Me.SplitContainer1.Panel2.Controls.Add(Me.gvSelectedItems)
        Me.SplitContainer1.Size = New System.Drawing.Size(1271, 425)
        Me.SplitContainer1.SplitterDistance = 629
        Me.SplitContainer1.TabIndex = 1
        '
        'lblAttribute
        '
        Me.lblAttribute.AutoSize = False
        Me.lblAttribute.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblAttribute.Location = New System.Drawing.Point(10, 27)
        Me.lblAttribute.Name = "lblAttribute"
        Me.lblAttribute.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblAttribute.R_ResourceId = "lblAttribute"
        Me.lblAttribute.Size = New System.Drawing.Size(100, 18)
        Me.lblAttribute.TabIndex = 41
        Me.lblAttribute.Text = "Application..."
        '
        'gvAvailableItems
        '
        Me.gvAvailableItems.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gvAvailableItems.EnableFastScrolling = True
        Me.gvAvailableItems.Location = New System.Drawing.Point(3, 53)
        '
        '
        '
        Me.gvAvailableItems.MasterTemplate.AllowAddNewRow = False
        Me.gvAvailableItems.MasterTemplate.AllowDeleteRow = False
        Me.gvAvailableItems.MasterTemplate.AutoGenerateColumns = False
        R_GridViewCheckBoxSelectColumn1.EditMode = Telerik.WinControls.UI.EditMode.OnValueChange
        R_GridViewCheckBoxSelectColumn1.EnableHeaderCheckBox = True
        R_GridViewCheckBoxSelectColumn1.FieldName = "LSELECT"
        R_GridViewCheckBoxSelectColumn1.HeaderText = ""
        R_GridViewCheckBoxSelectColumn1.Name = "_LSELECT"
        R_GridViewCheckBoxSelectColumn1.R_EnableEDIT = True
        R_GridViewCheckBoxSelectColumn1.R_ResourceId = Nothing
        R_GridViewCheckBoxSelectColumn1.Width = 33
        R_GridViewTextBoxColumn1.FieldName = "CITEM_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CITEM_ID"
        R_GridViewTextBoxColumn1.Name = "_CITEM_ID"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CITEM_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.ReadOnly = True
        R_GridViewTextBoxColumn1.Width = 74
        R_GridViewTextBoxColumn2.FieldName = "CITEM_NAME"
        R_GridViewTextBoxColumn2.HeaderText = "_CITEM_NAME"
        R_GridViewTextBoxColumn2.Name = "_CITEM_NAME"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CITEM_NAME"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.ReadOnly = True
        R_GridViewTextBoxColumn2.Width = 95
        R_GridViewCheckBoxColumn1.FieldName = "LSPEC"
        R_GridViewCheckBoxColumn1.HeaderText = "_LSPEC"
        R_GridViewCheckBoxColumn1.Name = "_LSPEC"
        R_GridViewCheckBoxColumn1.R_ResourceId = "_LSPEC"
        R_GridViewCheckBoxColumn1.Width = 72
        R_GridViewTextBoxColumn3.FieldName = "CINITIAL_VERSION"
        R_GridViewTextBoxColumn3.HeaderText = "_CINITIAL_VERSION"
        R_GridViewTextBoxColumn3.Name = "_CINITIAL_VERSION"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CINITIAL_VERSION"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 120
        Me.gvAvailableItems.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewCheckBoxSelectColumn1, R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewCheckBoxColumn1, R_GridViewTextBoxColumn3})
        Me.gvAvailableItems.MasterTemplate.DataSource = Me.bsGvAvailableItems
        Me.gvAvailableItems.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvAvailableItems.MasterTemplate.EnableFiltering = True
        Me.gvAvailableItems.MasterTemplate.EnableGrouping = False
        Me.gvAvailableItems.MasterTemplate.ShowFilteringRow = False
        Me.gvAvailableItems.MasterTemplate.ShowGroupedColumns = True
        Me.gvAvailableItems.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvAvailableItems.Name = "gvAvailableItems"
        Me.gvAvailableItems.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvAvailableItems.R_ConductorGridSource = Me.conAvailable
        Me.gvAvailableItems.R_ConductorSource = Nothing
        Me.gvAvailableItems.R_DataAdded = False
        Me.gvAvailableItems.R_GridType = R_FrontEnd.R_eGridType.BatchUpdating
        Me.gvAvailableItems.R_NewRowText = Nothing
        Me.gvAvailableItems.ShowHeaderCellButtons = True
        Me.gvAvailableItems.Size = New System.Drawing.Size(619, 365)
        Me.gvAvailableItems.TabIndex = 1
        Me.gvAvailableItems.Text = "R_RadGridView1"
        '
        'cboAttribute
        '
        Me.cboAttribute.DataSource = Me.bsAttribute
        Me.cboAttribute.DisplayMember = "CATTRIBUTE_NAME"
        Me.cboAttribute.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboAttribute.Location = New System.Drawing.Point(114, 27)
        Me.cboAttribute.Name = "cboAttribute"
        Me.cboAttribute.R_ConductorGridSource = Me.conAvailable
        Me.cboAttribute.R_ConductorSource = Nothing
        Me.cboAttribute.R_EnableOTHER = True
        Me.cboAttribute.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboAttribute.Size = New System.Drawing.Size(206, 20)
        Me.cboAttribute.TabIndex = 39
        Me.cboAttribute.Text = "R_RadDropDownList1"
        Me.cboAttribute.ValueMember = "CATTRIBUTE_ID"
        '
        'lblAvailableItems
        '
        Me.lblAvailableItems.AutoSize = False
        Me.lblAvailableItems.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblAvailableItems.Location = New System.Drawing.Point(10, 3)
        Me.lblAvailableItems.Name = "lblAvailableItems"
        Me.lblAvailableItems.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblAvailableItems.R_ResourceId = "lblAvailableItems"
        Me.lblAvailableItems.Size = New System.Drawing.Size(100, 18)
        Me.lblAvailableItems.TabIndex = 0
        Me.lblAvailableItems.Text = "R_RadLabel1"
        '
        'btnDeleteItem
        '
        Me.btnDeleteItem.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDeleteItem.Location = New System.Drawing.Point(523, 24)
        Me.btnDeleteItem.Name = "btnDeleteItem"
        Me.btnDeleteItem.R_ConductorGridSource = Nothing
        Me.btnDeleteItem.R_ConductorSource = Nothing
        Me.btnDeleteItem.R_DescriptionId = Nothing
        Me.btnDeleteItem.R_ResourceId = "btnDeleteItem"
        Me.btnDeleteItem.Size = New System.Drawing.Size(110, 24)
        Me.btnDeleteItem.TabIndex = 4
        Me.btnDeleteItem.Text = "R_RadButton1"
        '
        'lblSelectedItems
        '
        Me.lblSelectedItems.AutoSize = False
        Me.lblSelectedItems.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblSelectedItems.Location = New System.Drawing.Point(3, 3)
        Me.lblSelectedItems.Name = "lblSelectedItems"
        Me.lblSelectedItems.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblSelectedItems.R_ResourceId = "lblSelectedItems"
        Me.lblSelectedItems.Size = New System.Drawing.Size(100, 18)
        Me.lblSelectedItems.TabIndex = 3
        Me.lblSelectedItems.Text = "R_RadLabel2"
        '
        'gvSelectedItems
        '
        Me.gvSelectedItems.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gvSelectedItems.EnableFastScrolling = True
        Me.gvSelectedItems.Location = New System.Drawing.Point(3, 53)
        '
        '
        '
        Me.gvSelectedItems.MasterTemplate.AllowAddNewRow = False
        Me.gvSelectedItems.MasterTemplate.AllowDeleteRow = False
        Me.gvSelectedItems.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn4.FieldName = "CATTRIBUTE_NAME"
        R_GridViewTextBoxColumn4.HeaderText = "_CATTRIBUTE_NAME"
        R_GridViewTextBoxColumn4.Name = "_CATTRIBUTE_NAME"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CATTRIBUTE_NAME"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 125
        R_GridViewTextBoxColumn5.FieldName = "CITEM_ID"
        R_GridViewTextBoxColumn5.HeaderText = "_CITEM_ID"
        R_GridViewTextBoxColumn5.Name = "_CITEM_ID"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CITEM_ID"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 74
        R_GridViewTextBoxColumn6.FieldName = "CITEM_NAME"
        R_GridViewTextBoxColumn6.HeaderText = "_CITEM_NAME"
        R_GridViewTextBoxColumn6.Name = "_CITEM_NAME"
        R_GridViewTextBoxColumn6.R_ResourceId = "_CITEM_NAME"
        R_GridViewTextBoxColumn6.R_UDT = Nothing
        R_GridViewTextBoxColumn6.Width = 95
        R_GridViewCheckBoxColumn2.FieldName = "LSPEC"
        R_GridViewCheckBoxColumn2.HeaderText = "_LSPEC"
        R_GridViewCheckBoxColumn2.Name = "_LSPEC"
        R_GridViewCheckBoxColumn2.R_ResourceId = "_LSPEC"
        R_GridViewCheckBoxColumn2.Width = 72
        R_GridViewTextBoxColumn7.FieldName = "CINITIAL_VERSION"
        R_GridViewTextBoxColumn7.HeaderText = "_CINITIAL_VERSION"
        R_GridViewTextBoxColumn7.Name = "_CINITIAL_VERSION"
        R_GridViewTextBoxColumn7.R_ResourceId = "_CINITIAL_VERSION"
        R_GridViewTextBoxColumn7.R_UDT = Nothing
        R_GridViewTextBoxColumn7.Width = 120
        Me.gvSelectedItems.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn4, R_GridViewTextBoxColumn5, R_GridViewTextBoxColumn6, R_GridViewCheckBoxColumn2, R_GridViewTextBoxColumn7})
        Me.gvSelectedItems.MasterTemplate.DataSource = Me.bsGvSelectedItems
        Me.gvSelectedItems.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvSelectedItems.MasterTemplate.EnableFiltering = True
        Me.gvSelectedItems.MasterTemplate.EnableGrouping = False
        Me.gvSelectedItems.MasterTemplate.ShowFilteringRow = False
        Me.gvSelectedItems.MasterTemplate.ShowGroupedColumns = True
        Me.gvSelectedItems.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvSelectedItems.Name = "gvSelectedItems"
        Me.gvSelectedItems.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvSelectedItems.R_ConductorGridSource = Nothing
        Me.gvSelectedItems.R_ConductorSource = Nothing
        Me.gvSelectedItems.R_DataAdded = False
        Me.gvSelectedItems.R_NewRowText = Nothing
        Me.gvSelectedItems.ReadOnly = True
        Me.gvSelectedItems.ShowHeaderCellButtons = True
        Me.gvSelectedItems.Size = New System.Drawing.Size(630, 365)
        Me.gvSelectedItems.TabIndex = 2
        Me.gvSelectedItems.Text = "R_RadGridView2"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.cboScheduleType)
        Me.Panel2.Controls.Add(Me.lblScheduleType)
        Me.Panel2.Controls.Add(Me.lblQC)
        Me.Panel2.Controls.Add(Me.lblDevelopment)
        Me.Panel2.Controls.Add(Me.lblDesign)
        Me.Panel2.Controls.Add(Me.btnQC)
        Me.Panel2.Controls.Add(Me.txtQCPIC)
        Me.Panel2.Controls.Add(Me.btnDevelopment)
        Me.Panel2.Controls.Add(Me.txtDevelopmentPIC)
        Me.Panel2.Controls.Add(Me.btnDesign)
        Me.Panel2.Controls.Add(Me.txtDesignPIC)
        Me.Panel2.Controls.Add(Me.lblPICTitle)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 578)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1271, 1)
        Me.Panel2.TabIndex = 2
        '
        'cboScheduleType
        '
        Me.cboScheduleType.DataSource = Me.bsScheduleType
        Me.cboScheduleType.DisplayMember = "CSCHEDULE_TYPE_NAME"
        Me.cboScheduleType.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboScheduleType.Location = New System.Drawing.Point(470, 3)
        Me.cboScheduleType.Name = "cboScheduleType"
        Me.cboScheduleType.R_ConductorGridSource = Me.conAvailable
        Me.cboScheduleType.R_ConductorSource = Nothing
        Me.cboScheduleType.R_EnableOTHER = True
        Me.cboScheduleType.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboScheduleType.Size = New System.Drawing.Size(206, 20)
        Me.cboScheduleType.TabIndex = 40
        Me.cboScheduleType.Text = "R_RadDropDownList1"
        Me.cboScheduleType.ValueMember = "CSCHEDULE_TYPE"
        '
        'lblScheduleType
        '
        Me.lblScheduleType.AutoSize = False
        Me.lblScheduleType.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblScheduleType.Location = New System.Drawing.Point(358, 3)
        Me.lblScheduleType.Name = "lblScheduleType"
        Me.lblScheduleType.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblScheduleType.R_ResourceId = "lblScheduleType"
        Me.lblScheduleType.Size = New System.Drawing.Size(106, 18)
        Me.lblScheduleType.TabIndex = 13
        Me.lblScheduleType.Text = "R_RadLabel1"
        '
        'lblQC
        '
        Me.lblQC.AutoSize = False
        Me.lblQC.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblQC.Location = New System.Drawing.Point(9, 79)
        Me.lblQC.Name = "lblQC"
        Me.lblQC.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblQC.R_ResourceId = "lblQC"
        Me.lblQC.Size = New System.Drawing.Size(100, 18)
        Me.lblQC.TabIndex = 12
        Me.lblQC.Text = "R_RadLabel1"
        '
        'lblDevelopment
        '
        Me.lblDevelopment.AutoSize = False
        Me.lblDevelopment.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblDevelopment.Location = New System.Drawing.Point(9, 53)
        Me.lblDevelopment.Name = "lblDevelopment"
        Me.lblDevelopment.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblDevelopment.R_ResourceId = "lblDevelopment"
        Me.lblDevelopment.Size = New System.Drawing.Size(100, 18)
        Me.lblDevelopment.TabIndex = 11
        Me.lblDevelopment.Text = "R_RadLabel1"
        '
        'lblDesign
        '
        Me.lblDesign.AutoSize = False
        Me.lblDesign.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblDesign.Location = New System.Drawing.Point(9, 27)
        Me.lblDesign.Name = "lblDesign"
        Me.lblDesign.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblDesign.R_ResourceId = "lblDesign"
        Me.lblDesign.Size = New System.Drawing.Size(100, 18)
        Me.lblDesign.TabIndex = 10
        Me.lblDesign.Text = "R_RadLabel1"
        '
        'btnQC
        '
        Me.btnQC.Location = New System.Drawing.Point(322, 78)
        Me.btnQC.Name = "btnQC"
        Me.btnQC.R_ConductorGridSource = Nothing
        Me.btnQC.R_ConductorSource = Nothing
        Me.btnQC.R_DescriptionId = Nothing
        Me.btnQC.R_Field_Description = ""
        Me.btnQC.R_Field_Value = ""
        Me.btnQC.R_ResourceId = "btnLookup"
        Me.btnQC.R_TextBox_Description = Nothing
        Me.btnQC.R_TextBox_Value = Nothing
        Me.btnQC.R_Title = Nothing
        Me.btnQC.Size = New System.Drawing.Size(30, 20)
        Me.btnQC.TabIndex = 8
        Me.btnQC.Text = "..."
        '
        'txtQCPIC
        '
        Me.txtQCPIC.Location = New System.Drawing.Point(116, 78)
        Me.txtQCPIC.Name = "txtQCPIC"
        Me.txtQCPIC.R_ConductorGridSource = Nothing
        Me.txtQCPIC.R_ConductorSource = Nothing
        Me.txtQCPIC.R_UDT = Nothing
        Me.txtQCPIC.ReadOnly = True
        Me.txtQCPIC.Size = New System.Drawing.Size(200, 20)
        Me.txtQCPIC.TabIndex = 6
        Me.txtQCPIC.TabStop = False
        '
        'btnDevelopment
        '
        Me.btnDevelopment.Location = New System.Drawing.Point(322, 52)
        Me.btnDevelopment.Name = "btnDevelopment"
        Me.btnDevelopment.R_ConductorGridSource = Nothing
        Me.btnDevelopment.R_ConductorSource = Nothing
        Me.btnDevelopment.R_DescriptionId = Nothing
        Me.btnDevelopment.R_Field_Description = ""
        Me.btnDevelopment.R_Field_Value = ""
        Me.btnDevelopment.R_ResourceId = "btnLookup"
        Me.btnDevelopment.R_TextBox_Description = Nothing
        Me.btnDevelopment.R_TextBox_Value = Nothing
        Me.btnDevelopment.R_Title = Nothing
        Me.btnDevelopment.Size = New System.Drawing.Size(30, 20)
        Me.btnDevelopment.TabIndex = 5
        Me.btnDevelopment.Text = "..."
        '
        'txtDevelopmentPIC
        '
        Me.txtDevelopmentPIC.Location = New System.Drawing.Point(116, 52)
        Me.txtDevelopmentPIC.Name = "txtDevelopmentPIC"
        Me.txtDevelopmentPIC.R_ConductorGridSource = Nothing
        Me.txtDevelopmentPIC.R_ConductorSource = Nothing
        Me.txtDevelopmentPIC.R_UDT = Nothing
        Me.txtDevelopmentPIC.ReadOnly = True
        Me.txtDevelopmentPIC.Size = New System.Drawing.Size(200, 20)
        Me.txtDevelopmentPIC.TabIndex = 3
        Me.txtDevelopmentPIC.TabStop = False
        '
        'btnDesign
        '
        Me.btnDesign.Location = New System.Drawing.Point(322, 26)
        Me.btnDesign.Name = "btnDesign"
        Me.btnDesign.R_ConductorGridSource = Nothing
        Me.btnDesign.R_ConductorSource = Nothing
        Me.btnDesign.R_DescriptionId = Nothing
        Me.btnDesign.R_Field_Description = ""
        Me.btnDesign.R_Field_Value = ""
        Me.btnDesign.R_ResourceId = "btnLookup"
        Me.btnDesign.R_TextBox_Description = Nothing
        Me.btnDesign.R_TextBox_Value = Nothing
        Me.btnDesign.R_Title = Nothing
        Me.btnDesign.Size = New System.Drawing.Size(30, 20)
        Me.btnDesign.TabIndex = 2
        Me.btnDesign.Text = "..."
        '
        'txtDesignPIC
        '
        Me.txtDesignPIC.Location = New System.Drawing.Point(116, 26)
        Me.txtDesignPIC.Name = "txtDesignPIC"
        Me.txtDesignPIC.R_ConductorGridSource = Nothing
        Me.txtDesignPIC.R_ConductorSource = Nothing
        Me.txtDesignPIC.R_UDT = Nothing
        Me.txtDesignPIC.ReadOnly = True
        Me.txtDesignPIC.Size = New System.Drawing.Size(200, 20)
        Me.txtDesignPIC.TabIndex = 0
        Me.txtDesignPIC.TabStop = False
        '
        'lblPICTitle
        '
        Me.lblPICTitle.AutoSize = False
        Me.lblPICTitle.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblPICTitle.Location = New System.Drawing.Point(9, 3)
        Me.lblPICTitle.Name = "lblPICTitle"
        Me.lblPICTitle.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblPICTitle.R_ResourceId = "lblPICTitle"
        Me.lblPICTitle.Size = New System.Drawing.Size(106, 18)
        Me.lblPICTitle.TabIndex = 0
        Me.lblPICTitle.Text = "R_RadLabel1"
        '
        'bsGvAvailableItems
        '
        Me.bsGvAvailableItems.DataSource = GetType(CSM00500Front.CSM00500ItemStreamingServiceRef.CSM00500ItemGridDTO)
        '
        'bsAttribute
        '
        Me.bsAttribute.DataSource = GetType(CSM00500Front.CSM00500ItemServiceRef.RCustDBAttributeComboDTO)
        '
        'bsGvSelectedItems
        '
        Me.bsGvSelectedItems.DataSource = GetType(CSM00500Front.CSM00500ItemStreamingServiceRef.CSM00500ItemGridDTO)
        '
        'bsScheduleType
        '
        Me.bsScheduleType.DataSource = GetType(CSM00500Front.CSM00500ItemServiceRef.RCustDBScheduleTypeComboDTO)
        '
        'lblCustom
        '
        Me.lblCustom.AutoSize = False
        Me.lblCustom.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustom.Location = New System.Drawing.Point(328, 62)
        Me.lblCustom.Name = "lblCustom"
        Me.lblCustom.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustom.R_ResourceId = ""
        Me.lblCustom.Size = New System.Drawing.Size(100, 18)
        Me.lblCustom.TabIndex = 42
        Me.lblCustom.Text = "Application..."
        '
        'CSM00500Item
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CSM00500Item"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "Add Item"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblAttributeGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboAttributeGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsAttributeGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conAvailable, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnProcess, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel1.PerformLayout()
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.lblAttribute, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvAvailableItems.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvAvailableItems, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboAttribute, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblAvailableItems, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnDeleteItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblSelectedItems, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvSelectedItems.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvSelectedItems, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.cboScheduleType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblScheduleType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblQC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblDevelopment, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblDesign, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnQC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtQCPIC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnDevelopment, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDevelopmentPIC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnDesign, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtDesignPIC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblPICTitle, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvAvailableItems, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsAttribute, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvSelectedItems, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsScheduleType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCustom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(false)

End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents txtProject As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblProject As R_FrontEnd.R_RadLabel
    Friend WithEvents txtVersion As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtApplication As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents lblVersion As R_FrontEnd.R_RadLabel
    Friend WithEvents txtSession As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblSession As R_FrontEnd.R_RadLabel
    Friend WithEvents cboAttributeGroup As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblAttribute As R_FrontEnd.R_RadLabel
    Friend WithEvents lblAttributeGroup As R_FrontEnd.R_RadLabel
    Friend WithEvents cboAttribute As R_FrontEnd.R_RadDropDownList
    Friend WithEvents bsAttributeGroup As System.Windows.Forms.BindingSource
    Friend WithEvents bsAttribute As System.Windows.Forms.BindingSource
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents gvAvailableItems As R_FrontEnd.R_RadGridView
    Friend WithEvents lblAvailableItems As R_FrontEnd.R_RadLabel
    Friend WithEvents lblSelectedItems As R_FrontEnd.R_RadLabel
    Friend WithEvents gvSelectedItems As R_FrontEnd.R_RadGridView
    Friend WithEvents bsGvAvailableItems As System.Windows.Forms.BindingSource
    Friend WithEvents bsGvSelectedItems As System.Windows.Forms.BindingSource
    Friend WithEvents conAvailable As R_FrontEnd.R_ConductorGrid
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents lblPICTitle As R_FrontEnd.R_RadLabel
    Friend WithEvents txtDesignPIC As R_FrontEnd.R_RadTextBox
    Friend WithEvents btnDesign As R_FrontEnd.R_LookUp
    Friend WithEvents btnQC As R_FrontEnd.R_LookUp
    Friend WithEvents txtQCPIC As R_FrontEnd.R_RadTextBox
    Friend WithEvents btnDevelopment As R_FrontEnd.R_LookUp
    Friend WithEvents txtDevelopmentPIC As R_FrontEnd.R_RadTextBox
    Friend WithEvents btnProcess As R_FrontEnd.R_RadButton
    Friend WithEvents bwCSM00500 As System.ComponentModel.BackgroundWorker
    Friend WithEvents btnDeleteItem As R_FrontEnd.R_RadButton
    Friend WithEvents lblDesign As R_FrontEnd.R_RadLabel
    Friend WithEvents lblDevelopment As R_FrontEnd.R_RadLabel
    Friend WithEvents lblQC As R_FrontEnd.R_RadLabel
    Friend WithEvents lblScheduleType As R_FrontEnd.R_RadLabel
    Friend WithEvents cboScheduleType As R_FrontEnd.R_RadDropDownList
    Friend WithEvents bsScheduleType As System.Windows.Forms.BindingSource
    Friend WithEvents lblCustomer As R_FrontEnd.R_RadLabel
    Friend WithEvents lblCustom As R_FrontEnd.R_RadLabel

End Class
