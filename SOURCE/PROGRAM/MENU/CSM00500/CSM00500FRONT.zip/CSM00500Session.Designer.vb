﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSM00500Session
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn5 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn6 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn6 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn7 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn7 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn8 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn8 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblCustomer = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtProject = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblProject = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtVersion = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtApplication = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblVersion = New R_FrontEnd.R_RadLabel(Me.components)
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.gvSession = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvSession = New System.Windows.Forms.BindingSource(Me.components)
        Me.conGridSession = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.btnPIC = New R_FrontEnd.R_Detail(Me.components)
        Me.cboScheduleType = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.lblScheduleType = New R_FrontEnd.R_RadLabel(Me.components)
        Me.btnStartSession = New R_FrontEnd.R_RadButton(Me.components)
        Me.btnAddItem = New R_FrontEnd.R_Detail(Me.components)
        Me.btnCloseSession = New R_FrontEnd.R_RadButton(Me.components)
        Me.btnCreateSession = New R_FrontEnd.R_RadButton(Me.components)
        Me.bsScheduleType = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblCustom = New R_FrontEnd.R_RadLabel(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel2.SuspendLayout()
        CType(Me.gvSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvSession.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridSession, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.btnPIC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboScheduleType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblScheduleType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnStartSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnAddItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnCloseSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnCreateSession, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsScheduleType, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCustom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.TableLayoutPanel2, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 108.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lblCustom)
        Me.Panel1.Controls.Add(Me.lblCustomer)
        Me.Panel1.Controls.Add(Me.txtProject)
        Me.Panel1.Controls.Add(Me.lblProject)
        Me.Panel1.Controls.Add(Me.txtVersion)
        Me.Panel1.Controls.Add(Me.txtApplication)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Controls.Add(Me.lblVersion)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 102)
        Me.Panel1.TabIndex = 1
        '
        'lblCustomer
        '
        Me.lblCustomer.AutoSize = False
        Me.lblCustomer.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustomer.Location = New System.Drawing.Point(9, 35)
        Me.lblCustomer.Name = "lblCustomer"
        Me.lblCustomer.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustomer.R_ResourceId = "lblCustomer"
        Me.lblCustomer.Size = New System.Drawing.Size(100, 18)
        Me.lblCustomer.TabIndex = 31
        Me.lblCustomer.Text = "Application..."
        '
        'txtProject
        '
        Me.txtProject.Location = New System.Drawing.Point(115, 60)
        Me.txtProject.Name = "txtProject"
        Me.txtProject.R_ConductorGridSource = Nothing
        Me.txtProject.R_ConductorSource = Nothing
        Me.txtProject.R_UDT = Nothing
        Me.txtProject.ReadOnly = True
        Me.txtProject.Size = New System.Drawing.Size(206, 20)
        Me.txtProject.TabIndex = 29
        Me.txtProject.TabStop = False
        '
        'lblProject
        '
        Me.lblProject.AutoSize = False
        Me.lblProject.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblProject.Location = New System.Drawing.Point(9, 61)
        Me.lblProject.Name = "lblProject"
        Me.lblProject.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblProject.R_ResourceId = "lblProject"
        Me.lblProject.Size = New System.Drawing.Size(100, 18)
        Me.lblProject.TabIndex = 28
        Me.lblProject.Text = "Application..."
        '
        'txtVersion
        '
        Me.txtVersion.Location = New System.Drawing.Point(115, 34)
        Me.txtVersion.Name = "txtVersion"
        Me.txtVersion.R_ConductorGridSource = Nothing
        Me.txtVersion.R_ConductorSource = Nothing
        Me.txtVersion.R_UDT = Nothing
        Me.txtVersion.ReadOnly = True
        Me.txtVersion.Size = New System.Drawing.Size(206, 20)
        Me.txtVersion.TabIndex = 27
        Me.txtVersion.TabStop = False
        '
        'txtApplication
        '
        Me.txtApplication.Location = New System.Drawing.Point(115, 8)
        Me.txtApplication.Name = "txtApplication"
        Me.txtApplication.R_ConductorGridSource = Nothing
        Me.txtApplication.R_ConductorSource = Nothing
        Me.txtApplication.R_UDT = Nothing
        Me.txtApplication.ReadOnly = True
        Me.txtApplication.Size = New System.Drawing.Size(206, 20)
        Me.txtApplication.TabIndex = 26
        Me.txtApplication.TabStop = False
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 24
        Me.lblApplication.Text = "Application..."
        '
        'lblVersion
        '
        Me.lblVersion.AutoSize = False
        Me.lblVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblVersion.Location = New System.Drawing.Point(9, 35)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblVersion.R_ResourceId = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(100, 18)
        Me.lblVersion.TabIndex = 25
        Me.lblVersion.Text = "Application..."
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 2
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 240.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.gvSession, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Panel2, 1, 0)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(3, 111)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(1271, 461)
        Me.TableLayoutPanel2.TabIndex = 2
        '
        'gvSession
        '
        Me.gvSession.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvSession.EnableFastScrolling = True
        Me.gvSession.Location = New System.Drawing.Point(3, 3)
        '
        '
        '
        Me.gvSession.MasterTemplate.AllowAddNewRow = False
        Me.gvSession.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn5.FieldName = "_CSESSION_ID"
        R_GridViewTextBoxColumn5.HeaderText = "_CSESSION_ID"
        R_GridViewTextBoxColumn5.Name = "_CSESSION_ID"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CSESSION_ID"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 93
        R_GridViewDateTimeColumn5.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn5.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn5.FieldName = "_DSESSION_DATE"
        R_GridViewDateTimeColumn5.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn5.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn5.HeaderText = "_DSESSION_DATE"
        R_GridViewDateTimeColumn5.Name = "_DSESSION_DATE"
        R_GridViewDateTimeColumn5.R_ResourceId = "_DSESSION_DATE"
        R_GridViewDateTimeColumn5.Width = 110
        R_GridViewTextBoxColumn6.FieldName = "_CSCHEDULE_TYPE_NAME"
        R_GridViewTextBoxColumn6.HeaderText = "_CSCHEDULE_TYPE_NAME"
        R_GridViewTextBoxColumn6.Name = "_CSCHEDULE_TYPE_NAME"
        R_GridViewTextBoxColumn6.R_ResourceId = "_CSCHEDULE_TYPE_NAME"
        R_GridViewTextBoxColumn6.R_UDT = Nothing
        R_GridViewTextBoxColumn6.Width = 153
        R_GridViewDateTimeColumn6.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn6.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn6.FieldName = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn6.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn6.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn6.HeaderText = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn6.Name = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn6.R_ResourceId = "_DPLAN_START_DATE"
        R_GridViewDateTimeColumn6.Width = 131
        R_GridViewDateTimeColumn7.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn7.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn7.FieldName = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn7.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn7.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn7.HeaderText = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn7.Name = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn7.R_ResourceId = "_DPLAN_END_DATE"
        R_GridViewDateTimeColumn7.Width = 121
        R_GridViewTextBoxColumn7.FieldName = "_CSTATUS"
        R_GridViewTextBoxColumn7.HeaderText = "_CSTATUS"
        R_GridViewTextBoxColumn7.Name = "_CSTATUS"
        R_GridViewTextBoxColumn7.R_ResourceId = "_CSESSION_STATUS"
        R_GridViewTextBoxColumn7.R_UDT = Nothing
        R_GridViewTextBoxColumn7.Width = 73
        R_GridViewTextBoxColumn8.FieldName = "_CNOTE"
        R_GridViewTextBoxColumn8.HeaderText = "_CNOTE"
        R_GridViewTextBoxColumn8.MaxLength = 200
        R_GridViewTextBoxColumn8.Name = "_CNOTE"
        R_GridViewTextBoxColumn8.R_EnableEDIT = True
        R_GridViewTextBoxColumn8.R_ResourceId = "_CNOTE"
        R_GridViewTextBoxColumn8.R_UDT = Nothing
        R_GridViewTextBoxColumn8.Width = 63
        R_GridViewDateTimeColumn8.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn8.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn8.FieldName = "_DCLOSE_DATE"
        R_GridViewDateTimeColumn8.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn8.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn8.HeaderText = "_DCLOSE_DATE"
        R_GridViewDateTimeColumn8.Name = "_DCLOSE_DATE"
        R_GridViewDateTimeColumn8.R_ResourceId = "_DCLOSE_DATE"
        R_GridViewDateTimeColumn8.Width = 99
        Me.gvSession.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn5, R_GridViewDateTimeColumn5, R_GridViewTextBoxColumn6, R_GridViewDateTimeColumn6, R_GridViewDateTimeColumn7, R_GridViewTextBoxColumn7, R_GridViewTextBoxColumn8, R_GridViewDateTimeColumn8})
        Me.gvSession.MasterTemplate.DataSource = Me.bsGvSession
        Me.gvSession.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvSession.MasterTemplate.EnableFiltering = True
        Me.gvSession.MasterTemplate.EnableGrouping = False
        Me.gvSession.MasterTemplate.ShowFilteringRow = False
        Me.gvSession.MasterTemplate.ShowGroupedColumns = True
        Me.gvSession.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvSession.Name = "gvSession"
        Me.gvSession.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvSession.R_ConductorGridSource = Me.conGridSession
        Me.gvSession.R_ConductorSource = Nothing
        Me.gvSession.R_DataAdded = False
        Me.gvSession.R_NewRowText = Nothing
        Me.gvSession.ShowHeaderCellButtons = True
        Me.gvSession.Size = New System.Drawing.Size(1025, 455)
        Me.gvSession.TabIndex = 2
        Me.gvSession.Text = "R_RadGridView1"
        '
        'bsGvSession
        '
        Me.bsGvSession.DataSource = GetType(CSM00500Front.CSM00500SessionServiceRef.CSM00500SessionDTO)
        '
        'conGridSession
        '
        Me.conGridSession.R_ConductorParent = Nothing
        Me.conGridSession.R_IsHeader = True
        Me.conGridSession.R_RadGroupBox = Nothing
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.btnPIC)
        Me.Panel2.Controls.Add(Me.cboScheduleType)
        Me.Panel2.Controls.Add(Me.lblScheduleType)
        Me.Panel2.Controls.Add(Me.btnStartSession)
        Me.Panel2.Controls.Add(Me.btnAddItem)
        Me.Panel2.Controls.Add(Me.btnCloseSession)
        Me.Panel2.Controls.Add(Me.btnCreateSession)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(1034, 3)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(234, 455)
        Me.Panel2.TabIndex = 0
        '
        'btnPIC
        '
        Me.btnPIC.Location = New System.Drawing.Point(7, 90)
        Me.btnPIC.Name = "btnPIC"
        Me.btnPIC.R_ConductorGridSource = Me.conGridSession
        Me.btnPIC.R_ConductorSource = Nothing
        Me.btnPIC.R_DescriptionId = Nothing
        Me.btnPIC.R_EnableHASDATA = True
        Me.btnPIC.R_EnableOTHER = True
        Me.btnPIC.R_ResourceId = "btnPIC"
        Me.btnPIC.R_Title = Nothing
        Me.btnPIC.Size = New System.Drawing.Size(110, 24)
        Me.btnPIC.TabIndex = 43
        Me.btnPIC.Text = "R_Detail1"
        '
        'cboScheduleType
        '
        Me.cboScheduleType.DataSource = Me.bsScheduleType
        Me.cboScheduleType.DisplayMember = "CSCHEDULE_TYPE_NAME"
        Me.cboScheduleType.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboScheduleType.Location = New System.Drawing.Point(7, 34)
        Me.cboScheduleType.Name = "cboScheduleType"
        Me.cboScheduleType.R_ConductorGridSource = Nothing
        Me.cboScheduleType.R_ConductorSource = Nothing
        Me.cboScheduleType.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboScheduleType.Size = New System.Drawing.Size(206, 20)
        Me.cboScheduleType.TabIndex = 42
        Me.cboScheduleType.Text = "R_RadDropDownList1"
        Me.cboScheduleType.ValueMember = "CSCHEDULE_TYPE"
        '
        'lblScheduleType
        '
        Me.lblScheduleType.AutoSize = False
        Me.lblScheduleType.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblScheduleType.Location = New System.Drawing.Point(7, 10)
        Me.lblScheduleType.Name = "lblScheduleType"
        Me.lblScheduleType.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblScheduleType.R_ResourceId = "lblScheduleType"
        Me.lblScheduleType.Size = New System.Drawing.Size(206, 18)
        Me.lblScheduleType.TabIndex = 41
        Me.lblScheduleType.Text = "R_RadLabel1"
        '
        'btnStartSession
        '
        Me.btnStartSession.Location = New System.Drawing.Point(7, 150)
        Me.btnStartSession.Name = "btnStartSession"
        Me.btnStartSession.R_ConductorGridSource = Me.conGridSession
        Me.btnStartSession.R_ConductorSource = Nothing
        Me.btnStartSession.R_DescriptionId = Nothing
        Me.btnStartSession.R_EnableHASDATA = True
        Me.btnStartSession.R_EnableOTHER = True
        Me.btnStartSession.R_ResourceId = "btnStartSession"
        Me.btnStartSession.Size = New System.Drawing.Size(110, 24)
        Me.btnStartSession.TabIndex = 3
        Me.btnStartSession.Text = "R_RadButton1"
        '
        'btnAddItem
        '
        Me.btnAddItem.Location = New System.Drawing.Point(7, 120)
        Me.btnAddItem.Name = "btnAddItem"
        Me.btnAddItem.R_ConductorGridSource = Me.conGridSession
        Me.btnAddItem.R_ConductorSource = Nothing
        Me.btnAddItem.R_DescriptionId = Nothing
        Me.btnAddItem.R_EnableHASDATA = True
        Me.btnAddItem.R_EnableOTHER = True
        Me.btnAddItem.R_ResourceId = "btnAddItem"
        Me.btnAddItem.R_Title = Nothing
        Me.btnAddItem.Size = New System.Drawing.Size(110, 24)
        Me.btnAddItem.TabIndex = 2
        Me.btnAddItem.Text = "R_Detail1"
        '
        'btnCloseSession
        '
        Me.btnCloseSession.Location = New System.Drawing.Point(7, 180)
        Me.btnCloseSession.Name = "btnCloseSession"
        Me.btnCloseSession.R_ConductorGridSource = Me.conGridSession
        Me.btnCloseSession.R_ConductorSource = Nothing
        Me.btnCloseSession.R_DescriptionId = Nothing
        Me.btnCloseSession.R_EnableHASDATA = True
        Me.btnCloseSession.R_EnableOTHER = True
        Me.btnCloseSession.R_ResourceId = "btnCloseSession"
        Me.btnCloseSession.Size = New System.Drawing.Size(110, 24)
        Me.btnCloseSession.TabIndex = 1
        Me.btnCloseSession.Text = "R_RadButton1"
        '
        'btnCreateSession
        '
        Me.btnCreateSession.Location = New System.Drawing.Point(7, 60)
        Me.btnCreateSession.Name = "btnCreateSession"
        Me.btnCreateSession.R_ConductorGridSource = Nothing
        Me.btnCreateSession.R_ConductorSource = Nothing
        Me.btnCreateSession.R_DescriptionId = Nothing
        Me.btnCreateSession.R_ResourceId = "btnCreateSession"
        Me.btnCreateSession.Size = New System.Drawing.Size(110, 24)
        Me.btnCreateSession.TabIndex = 0
        Me.btnCreateSession.Text = "R_RadButton1"
        '
        'bsScheduleType
        '
        Me.bsScheduleType.DataSource = GetType(CSM00500Front.CSM00500ItemServiceRef.RCustDBScheduleTypeComboDTO)
        '
        'lblCustom
        '
        Me.lblCustom.AutoSize = False
        Me.lblCustom.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustom.Location = New System.Drawing.Point(327, 61)
        Me.lblCustom.Name = "lblCustom"
        Me.lblCustom.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustom.R_ResourceId = ""
        Me.lblCustom.Size = New System.Drawing.Size(100, 18)
        Me.lblCustom.TabIndex = 32
        Me.lblCustom.Text = "Application..."
        '
        'CSM00500Session
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CSM00500Session"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblProject, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel2.ResumeLayout(False)
        CType(Me.gvSession.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridSession, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.btnPIC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboScheduleType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblScheduleType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnStartSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnAddItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnCloseSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnCreateSession, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsScheduleType, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCustom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents txtProject As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblProject As R_FrontEnd.R_RadLabel
    Friend WithEvents txtVersion As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtApplication As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents lblVersion As R_FrontEnd.R_RadLabel
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents gvSession As R_FrontEnd.R_RadGridView
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents btnAddItem As R_FrontEnd.R_Detail
    Friend WithEvents btnCloseSession As R_FrontEnd.R_RadButton
    Friend WithEvents btnCreateSession As R_FrontEnd.R_RadButton
    Friend WithEvents bsGvSession As System.Windows.Forms.BindingSource
    Friend WithEvents conGridSession As R_FrontEnd.R_ConductorGrid
    Friend WithEvents btnStartSession As R_FrontEnd.R_RadButton
    Friend WithEvents cboScheduleType As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblScheduleType As R_FrontEnd.R_RadLabel
    Friend WithEvents bsScheduleType As System.Windows.Forms.BindingSource
    Friend WithEvents btnPIC As R_FrontEnd.R_Detail
    Friend WithEvents lblCustomer As R_FrontEnd.R_RadLabel
    Friend WithEvents lblCustom As R_FrontEnd.R_RadLabel

End Class
