﻿Imports CSM00500Front.CSM00500ServiceRef

Public Class CSM00500DetailParameterDTO
    Public Property OGRID_KEY As CSM00500KeyDTO
    Public Property CAPPS_NAME As String
    Public Property CPROJECT_NAME As String
    Public Property CSESSION_ID As String
    Public Property CSESSION_STATUS As String
    Public Property CINIT_SCHEDULE_TYPE As String
    Public Property CCUSTOMER_NAME
End Class
