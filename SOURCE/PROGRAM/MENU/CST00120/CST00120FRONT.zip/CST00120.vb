﻿Imports CST00120FrontResources
Imports R_Common
Imports ClientHelper
Imports CST00120Front.CST00120ServiceRef
Imports CST00120Front.CST00120StreamingServiceRef
Imports CST00120Front.CST00120FileServiceRef
Imports R_FrontEnd
Imports System.ServiceModel.Channels
'Imports RCustDBFrontHelper
'Imports RCustDBFileCommon
Imports Telerik.WinControls
Imports System.Drawing
Imports Telerik.WinControls.UI
Imports System.Resources
Imports System.Threading
Imports CST00120Common
Imports System.IO
Imports Ionic.Zip

Public Class CST00120

#Region " VARIABLE "
    Private Shared C_ZipPath As String = "D:\RealCode\Temp\Zips"
    Private Shared C_RootPath As String = "D:\RealCode"
    Dim C_ServiceName As String = "CST00120Service/CST00120Service.svc"
    Dim C_ServiceNameStream As String = "CST00120Service/CST00120StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _CVERSION As String
    Dim _CUSER_NAME As String
    Dim _LDONE_COMBO_SETTING As Boolean = False
    Dim _LREADY_TO_REFRESH As Boolean = False
    Dim _LINIT As Boolean
    Dim _CATTRIBUTEGROUP As String
    Dim _CATTRIBUTEID As String
    Dim _CPROGRAMID As String
    'Dim _CSCHEDULE_ID As String
    Dim _CLAST_ACTION As String
    Dim _CLAST_ACTION_BY As String
    Dim loFilterParam As New CST00120FilterParameterDTO
    Dim loGridKey As New CST00120KeyDTO
#End Region

#Region " SUBs and FUNCTIONs "

    Private Sub RefreshGrids()
        With gvInbox
            bsGvInbox.ResetBindings(False)
            .R_RefreshGrid(loGridKey)
            .Columns(0).Sort(Telerik.WinControls.UI.RadSortOrder.Ascending, False)
        End With
    End Sub

    Private Sub ProcessHandler(pcProcess As String)
        Dim loException As New R_Exception
        Dim loFileHandler As New FileHandler
        Dim loBatchPar As R_BatchParameter = Nothing
        Dim loSvc As R_ProcessAndUploadClient
        Dim lcKeyGuid As String
        Dim lnFiles As Integer = 0

        Try
            ' disable buttons
            btnUpload.Enabled = False
            btnFilter.Enabled = False
            btnRefresh.Enabled = False
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
            ' show progress bar
            lblUploadStatus.Text = "Processing..."
            pbUploadStatus.Visible = True
            Threading.Thread.Sleep(1000)

            Dim loCheckedItems = From item In CType(bsGvInbox.List, List(Of CST00120ProgramListDTO)) Where item.LSELECT = True

            If loCheckedItems.Count > 0 Then
                With loFileHandler
                    .CCOMPANY_ID = _CCOMPID
                    .CUSER_ID = _CUSERID
                    For Each loRow As CST00120ProgramListDTO In loCheckedItems
                        .OFILE_PROCESS_KEY.Add(New RCustDBFileProcessKeyDTO With {.CCOMPANY_ID = _CCOMPID,
                                .CAPPS_CODE = _CAPPSCODE,
                                .CVERSION = _CVERSION,
                                .CATTRIBUTE_GROUP = loRow.CATTRIBUTE_GROUP,
                                .CATTRIBUTE_ID = loRow.CATTRIBUTE_ID,
                                .CPROGRAM_ID = loRow.CPROGRAM_ID,
                                .CUSER_ID = _CUSERID,
                                .LSPEC = loRow.LSPEC})
                    Next
                    .CPROGRAM_ID = "CST00120"

                    loBatchPar = .CheckIn()

                    loSvc = New R_ProcessAndUploadClient(bwUploadStatus, pbUploadStatus, lblUploadStatus)
                    AddHandler loSvc.ProcessError, AddressOf ProcessError
                    AddHandler loSvc.ProcessComplete, AddressOf ProcessComplete

                    lnFiles = loBatchPar.UserParameters.Where(Function(x) x.Key.Equals("COUNT")).FirstOrDefault.Value
                    lcKeyGuid = loSvc.R_BatchProcess(loBatchPar, lnFiles)
                    Threading.Thread.Sleep(5000)
                End With
            Else
                loException.Add("CST00120_01", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CST00120_01").Trim) ' no item selected
                Exit Try
            End If
        Catch ex As Exception
            loException.Add(ex)
        Finally
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        End Try
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        If loException.Haserror Then
            ' enable buttons
            btnUpload.Enabled = True
            btnFilter.Enabled = True
            btnRefresh.Enabled = True
            ' reset progress bar
            lblUploadStatus.Text = ""
            pbUploadStatus.Visible = False
            RefreshGrids()
            Me.R_DisplayException(loException)
        End If
    End Sub

    Private Sub ProcessComplete(pcKeyGuid As String, poProcessResultMode As eProcessResultMode)
        Dim loEx As New R_Exception

        Try
            Select Case poProcessResultMode
                Case eProcessResultMode.Success
                    R_RadMessageBox.Show(R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "_ProcessComplete"), Windows.Forms.MessageBoxButtons.OK)
                Case eProcessResultMode.Fail
                    Dim loRtn As List(Of R_ErrorStatusReturn)
                    Dim loHelp As New R_ProcessAndUploadClient(bwUploadStatus, Nothing, Nothing)
                    Dim loPar As R_UploadAndProcessKey

                    Try
                        With loPar
                            .COMPANY_ID = _CCOMPID
                            .USER_ID = _CUSERID
                            .KEY_GUID = pcKeyGuid
                        End With

                        loRtn = loHelp.R_GetErrorProcess(loPar)

                        For Each loError As R_ErrorStatusReturn In loRtn
                            loEx.Add(loError.SeqNo.ToString, loError.ErrorMessage)
                        Next
                    Catch ex As Exception
                        loEx.Add(ex)
                    End Try

                    If loEx.Haserror Then
                        loEx.ThrowExceptionIfErrors()
                    End If
            End Select
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            ' enable buttons
            btnUpload.Enabled = True
            btnFilter.Enabled = True
            btnRefresh.Enabled = True
            ' reset progress bar
            lblUploadStatus.Text = ""
            pbUploadStatus.Visible = False
            RefreshGrids()
        End Try

        If loEx.Haserror Then
            Me.R_DisplayException(loEx)
        End If

    End Sub

    Private Sub ProcessError(pcKeyGuid As String, ex As R_Exception)
        Dim loException As New R_Exception
        If ex.Haserror Then
            For Each loError As R_Error In ex.ErrorList
                loException.Add(loError)
            Next
        End If

        If loException.Haserror Then
            Me.R_DisplayException(loException)
            ' enable buttons
            btnUpload.Enabled = True
            btnFilter.Enabled = True
            btnRefresh.Enabled = True
            ' reset progress bar
            lblUploadStatus.Text = ""
            pbUploadStatus.Visible = False
        End If
        RefreshGrids()
    End Sub

#End Region

#Region " FILTER "

    Private Sub btnFilter_R_After_Open_Form(poPopUpResult As System.Windows.Forms.DialogResult, poPopUpEntityResult As Object) Handles btnFilter.R_After_Open_Form

        If poPopUpResult = Windows.Forms.DialogResult.OK Then
            loFilterParam = poPopUpEntityResult
            With loFilterParam
                _CAPPSCODE = .OFILTER_KEY.CAPPS_CODE
                _CVERSION = .OFILTER_KEY.CVERSION
                _CATTRIBUTEGROUP = .OFILTER_KEY.CATTRIBUTE_GROUP
                txtApplication.Text = .CAPPS_NAME
                txtVersion.Text = IIf(.LCUSTOM, .CCUSTOMER_NAME, .CCODE_NAME)
            End With
            If Not (String.IsNullOrEmpty(_CAPPSCODE) Or String.IsNullOrEmpty(_CVERSION)) Then
                With loGridKey
                    .CCOMPANY_ID = _CCOMPID
                    .CAPPS_CODE = _CAPPSCODE
                    .CVERSION = _CVERSION
                End With
                RefreshGrids()
            End If
        End If
    End Sub

    Private Sub btnFilter_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnFilter.R_Before_Open_Form
        poTargetForm = New CST00120Filter
        poParameter = loFilterParam
    End Sub

#End Region

#Region " FORM Events "

    Private Sub CST00101_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Try
            _LINIT = False
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            'setTextLanguageBased(gvInbox, gvInbox.Columns.Item("_CATTRIBUTE_ID"))
            '_SetTextLanguageBaseGrid(gvInbox)
            ' Predefined dock
            Me.R_Components = Me.components
            lblUploadStatus.Text = ""
            pbUploadStatus.Visible = False
            loFilterParam.OFILTER_KEY.CCOMPANY_ID = _CCOMPID
            loFilterParam.CREFRESH_COMBO_MODE = "NORMAL"
            btnFilter.PerformClick()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub CST00101_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " GRIDVIEW Events "

    Private Sub gvInbox_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvInbox.R_Display
        With CType(poEntity, CST00120ProgramListDTO)
            _CATTRIBUTEID = .CATTRIBUTE_ID
            _CPROGRAMID = .CPROGRAM_ID
        End With
    End Sub

    Private Sub gvInbox_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvInbox.R_ServiceGetListRecord
        Dim loServiceStream As CST00120StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00120StreamingService, CST00120StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CST00120ProgramListDTO)
        Dim loListEntity As New List(Of CST00120ProgramListDTO)

        Try
            With CType(poEntity, CST00120KeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cVersion", .CVERSION)
            End With

            loRtn = loServiceStream.GetProgramList()
            loStreaming = R_StreamUtility(Of CST00120ProgramListDTO).ReadFromMessage(loRtn)

            For Each loDto As CST00120ProgramListDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " BUTTON Actions "

    Private Sub btnCheckIn_Click(sender As System.Object, e As System.EventArgs) Handles btnUpload.Click
        ProcessHandler("CUTOFF")
    End Sub

    Private Sub btnRefresh_Click(sender As System.Object, e As System.EventArgs) Handles btnRefresh.Click
        RefreshGrids()
    End Sub

    Private Sub gvInbox_DataBindingComplete(sender As Object, e As GridViewBindingCompleteEventArgs) Handles gvInbox.DataBindingComplete
        gvInbox.BestFitColumns()
    End Sub

#End Region

End Class
