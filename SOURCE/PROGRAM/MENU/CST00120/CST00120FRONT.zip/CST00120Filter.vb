﻿Imports CST00120Front.CST00120ServiceRef
Imports R_FrontEnd
Imports ClientHelper
Imports R_Common
Imports System.ServiceModel.Channels

Public Class CST00120Filter

#Region " VARIABLE "
    Dim C_ServiceName As String = "CST00120Service/CST00120Service.svc"
    Dim C_ServiceNameStream As String = "CST00120Service/CST00120StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _LCUSTOM As Boolean
    Dim loFilterParam As New CST00120FilterParameterDTO
    Dim llRefreshCombo As Boolean
#End Region

#Region " SUBs and FUNCTIONs "

    Private Sub ComboManager(pcCode As String, pcValue As String, pcDisplay As String)
        Dim loSvc As CST00120ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00120Service, CST00120ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loProjectKey As New CST00120Front.CST00120ServiceRef.RCustDBProjectKeyDTO
        Dim lcValue As String = ""
        Dim lcDisplay As String = ""

        ' Refresh Combo
        With loProjectKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = loFilterParam.OFILTER_KEY.CAPPS_CODE
            .CVERSION = IIf(_LCUSTOM, loFilterParam.CCUSTOMER_CODE, loFilterParam.CVERSION)
            .CPROJECT_ID = loFilterParam.OFILTER_KEY.CPROJECT_ID
            .CSESSION_ID = loFilterParam.OFILTER_KEY.CSESSION_ID
            .CSTATUS = "*"
            .CUSER_ID = _CUSERID
            .LCHECK_PROJECT_MANAGER = False
        End With

        If pcValue IsNot Nothing Then
            lcValue = pcValue.Trim
        Else
            If Not pcCode.Equals("_INIT") Then
                Exit Sub
            End If
        End If
        If pcDisplay IsNot Nothing Then
            lcDisplay = pcDisplay
        End If

        With loFilterParam
            Select Case pcCode
                Case "_INIT"
                    ' initialize combo
                    cboVersion.Items.Clear()
                    If .OAPPS_LIST Is Nothing Then
                        Dim loAppCombo As New List(Of RLicenseAppComboDTO)
                        loAppCombo = loSvc.GetAppCombo(_CCOMPID, _CUSERID)
                        If loAppCombo.Count <= 0 Then
                            cboApplication.Items.Clear()
                        End If
                        llRefreshCombo = True
                        bsApps.DataSource = loAppCombo
                        .OAPPS_LIST = loAppCombo
                    Else
                        llRefreshCombo = False
                        bsApps.DataSource = .OAPPS_LIST
                        cboApplication.SelectedValue = .OFILTER_KEY.CAPPS_CODE
                        bsVersion.DataSource = .OVERSION_LIST
                        cboVersion.SelectedValue = .CVERSION
                        llRefreshCombo = True
                        llRefreshCombo = False
                        llRefreshCombo = True
                    End If
                    .CREFRESH_COMBO_MODE = "NORMAL"
                Case "_CAPPS_CODE"
                    If Not lcValue.Equals(.OFILTER_KEY.CAPPS_CODE) Then
                        .OVERSION_LIST = Nothing
                    End If
                    If .OVERSION_LIST Is Nothing Then
                        Dim loVersionCombo As New List(Of RCustDBVersionComboDTO)
                        If .CREFRESH_COMBO_MODE = "NORMAL" Then
                            .OFILTER_KEY.CAPPS_CODE = lcValue
                        End If
                        .CAPPS_NAME = lcDisplay
                        loVersionCombo = loSvc.GetVersionCombo(_CCOMPID, .OFILTER_KEY.CAPPS_CODE)
                        If loVersionCombo.Count <= 0 Then
                            cboVersion.Items.Clear()
                        End If
                        bsVersion.DataSource = loVersionCombo
                        .OVERSION_LIST = loVersionCombo
                    End If
                    If .OFILTER_KEY.CVERSION IsNot Nothing Then
                        cboVersion.SelectedValue = .OFILTER_KEY.CVERSION
                    End If
                Case "_CVERSION"
                    .OFILTER_KEY.CVERSION = lcValue
            End Select
            .OFILTER_KEY.CATTRIBUTE_GROUP = "PROGRAM"
        End With
        loSvc.Close()
    End Sub

#End Region

#Region " COMBO Actions "

    Private Sub cboApplication_Trigger(sender As Object, e As System.EventArgs) Handles cboApplication.SelectedIndexChanged
        If llRefreshCombo Then
            ComboManager("_CAPPS_CODE", sender.SelectedValue, sender.SelectedText)
        End If
    End Sub

    Private Sub cboVersion_Trigger(sender As Object, e As System.EventArgs) Handles cboVersion.SelectedIndexChanged
        If llRefreshCombo Then
            With loFilterParam
                .CVERSION = sender.SelectedValue
                .CCODE_NAME = sender.SelectedText
            End With
            ComboManager("_CVERSION", sender.SelectedValue, sender.SelectedText)
        End If
    End Sub

    Private Sub cboFunction_Trigger(sender As Object, e As Telerik.WinControls.UI.Data.PositionChangedEventArgs)
        If llRefreshCombo Then
            ComboManager("_CFUNCTION_ID", sender.SelectedValue, sender.SelectedText)
        End If
    End Sub

    Private Sub cboAttributeGroup_Trigger(sender As Object, e As Telerik.WinControls.UI.Data.PositionChangedEventArgs)
        If llRefreshCombo Then
            ComboManager("_CATTRIBUTE_GROUP", sender.SelectedValue, sender.SelectedText)
        End If
    End Sub

    Private Sub btnRefresh_Click(sender As System.Object, e As System.EventArgs) Handles btnRefresh.Click
        With loFilterParam
            .OAPPS_LIST = Nothing
            .OVERSION_LIST = Nothing
            .CREFRESH_COMBO_MODE = "REFRESH"
        End With
        ComboManager("_INIT", Nothing, Nothing)
    End Sub

#End Region

#Region " FORM Methods "

    Private Sub R_ReturnPopUp1_R_SetPopUpResult(ByRef poEntityResult As Object) Handles R_ReturnPopUp1.R_SetPopUpResult
        poEntityResult = loFilterParam
    End Sub

    Private Sub CST00200Filter_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim loEx As New R_Exception

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            loFilterParam = poParameter

            ComboManager("_INIT", Nothing, Nothing)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

End Class
