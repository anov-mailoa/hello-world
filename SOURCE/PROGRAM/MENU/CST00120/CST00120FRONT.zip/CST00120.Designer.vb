﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CST00120
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewCheckBoxSelectColumn1 As R_FrontEnd.R_GridViewCheckBoxSelectColumn = New R_FrontEnd.R_GridViewCheckBoxSelectColumn()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn1 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnRefresh = New R_FrontEnd.R_RadButton(Me.components)
        Me.txtVersion = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtApplication = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.btnFilter = New R_FrontEnd.R_PopUp(Me.components)
        Me.conGridInbox = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblVersion = New R_FrontEnd.R_RadLabel(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.lblUploadStatus = New R_FrontEnd.R_RadLabel(Me.components)
        Me.btnUpload = New R_FrontEnd.R_RadButton(Me.components)
        Me.pbUploadStatus = New R_FrontEnd.R_RadProgressBar(Me.components)
        Me.gvInbox = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvInbox = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsVersion = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.bwUploadStatus = New System.ComponentModel.BackgroundWorker()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.btnRefresh, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnFilter, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridInbox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.lblUploadStatus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnUpload, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbUploadStatus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvInbox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvInbox.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvInbox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsVersion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.gvInbox, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 72.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnRefresh)
        Me.Panel1.Controls.Add(Me.txtVersion)
        Me.Panel1.Controls.Add(Me.txtApplication)
        Me.Panel1.Controls.Add(Me.btnFilter)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Controls.Add(Me.lblVersion)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 66)
        Me.Panel1.TabIndex = 0
        '
        'btnRefresh
        '
        Me.btnRefresh.Location = New System.Drawing.Point(637, 6)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.R_ConductorGridSource = Nothing
        Me.btnRefresh.R_ConductorSource = Nothing
        Me.btnRefresh.R_DescriptionId = Nothing
        Me.btnRefresh.R_ResourceId = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(110, 24)
        Me.btnRefresh.TabIndex = 60
        Me.btnRefresh.Text = "R_RadButton1"
        '
        'txtVersion
        '
        Me.txtVersion.Location = New System.Drawing.Point(115, 34)
        Me.txtVersion.Name = "txtVersion"
        Me.txtVersion.R_ConductorGridSource = Nothing
        Me.txtVersion.R_ConductorSource = Nothing
        Me.txtVersion.R_UDT = Nothing
        Me.txtVersion.ReadOnly = True
        Me.txtVersion.Size = New System.Drawing.Size(200, 20)
        Me.txtVersion.TabIndex = 52
        Me.txtVersion.TabStop = False
        '
        'txtApplication
        '
        Me.txtApplication.Location = New System.Drawing.Point(115, 8)
        Me.txtApplication.Name = "txtApplication"
        Me.txtApplication.R_ConductorGridSource = Nothing
        Me.txtApplication.R_ConductorSource = Nothing
        Me.txtApplication.R_UDT = Nothing
        Me.txtApplication.ReadOnly = True
        Me.txtApplication.Size = New System.Drawing.Size(400, 20)
        Me.txtApplication.TabIndex = 51
        Me.txtApplication.TabStop = False
        '
        'btnFilter
        '
        Me.btnFilter.Location = New System.Drawing.Point(521, 6)
        Me.btnFilter.Name = "btnFilter"
        Me.btnFilter.R_ConductorGridSource = Me.conGridInbox
        Me.btnFilter.R_ConductorSource = Nothing
        Me.btnFilter.R_DescriptionId = Nothing
        Me.btnFilter.R_EnableOTHER = True
        Me.btnFilter.R_ResourceId = "btnFilter"
        Me.btnFilter.R_Title = "Inbox Filter"
        Me.btnFilter.Size = New System.Drawing.Size(110, 24)
        Me.btnFilter.TabIndex = 42
        Me.btnFilter.Text = "R_PopUp1"
        '
        'conGridInbox
        '
        Me.conGridInbox.R_ConductorParent = Nothing
        Me.conGridInbox.R_IsHeader = True
        Me.conGridInbox.R_RadGroupBox = Nothing
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 30
        Me.lblApplication.Text = "Application..."
        '
        'lblVersion
        '
        Me.lblVersion.AutoSize = False
        Me.lblVersion.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblVersion.Location = New System.Drawing.Point(9, 35)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblVersion.R_ResourceId = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(100, 18)
        Me.lblVersion.TabIndex = 32
        Me.lblVersion.Text = "Application..."
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.lblUploadStatus)
        Me.Panel2.Controls.Add(Me.btnUpload)
        Me.Panel2.Controls.Add(Me.pbUploadStatus)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 542)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1271, 30)
        Me.Panel2.TabIndex = 1
        '
        'lblUploadStatus
        '
        Me.lblUploadStatus.AutoSize = False
        Me.lblUploadStatus.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblUploadStatus.Location = New System.Drawing.Point(362, 6)
        Me.lblUploadStatus.Name = "lblUploadStatus"
        Me.lblUploadStatus.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblUploadStatus.R_ResourceId = Nothing
        Me.lblUploadStatus.Size = New System.Drawing.Size(100, 18)
        Me.lblUploadStatus.TabIndex = 62
        Me.lblUploadStatus.Text = "Text"
        '
        'btnUpload
        '
        Me.btnUpload.Location = New System.Drawing.Point(3, 3)
        Me.btnUpload.Name = "btnUpload"
        Me.btnUpload.R_ConductorGridSource = Me.conGridInbox
        Me.btnUpload.R_ConductorSource = Nothing
        Me.btnUpload.R_DescriptionId = Nothing
        Me.btnUpload.R_EnableHASDATA = True
        Me.btnUpload.R_ResourceId = "btnUpload"
        Me.btnUpload.Size = New System.Drawing.Size(110, 24)
        Me.btnUpload.TabIndex = 3
        Me.btnUpload.Text = "Check-In"
        '
        'pbUploadStatus
        '
        Me.pbUploadStatus.Location = New System.Drawing.Point(119, 3)
        Me.pbUploadStatus.Name = "pbUploadStatus"
        '
        '
        '
        Me.pbUploadStatus.RootElement.UseDefaultDisabledPaint = False
        Me.pbUploadStatus.Size = New System.Drawing.Size(242, 24)
        Me.pbUploadStatus.TabIndex = 61
        '
        'gvInbox
        '
        Me.gvInbox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvInbox.EnableFastScrolling = True
        Me.gvInbox.Location = New System.Drawing.Point(3, 75)
        '
        '
        '
        Me.gvInbox.MasterTemplate.AllowAddNewRow = False
        Me.gvInbox.MasterTemplate.AllowDeleteRow = False
        Me.gvInbox.MasterTemplate.AutoGenerateColumns = False
        R_GridViewCheckBoxSelectColumn1.EditMode = Telerik.WinControls.UI.EditMode.OnValueChange
        R_GridViewCheckBoxSelectColumn1.EnableHeaderCheckBox = True
        R_GridViewCheckBoxSelectColumn1.FieldName = "LSELECT"
        R_GridViewCheckBoxSelectColumn1.HeaderText = ""
        R_GridViewCheckBoxSelectColumn1.Name = "_LSELECT"
        R_GridViewCheckBoxSelectColumn1.R_EnableEDIT = True
        R_GridViewCheckBoxSelectColumn1.R_ResourceId = ""
        R_GridViewCheckBoxSelectColumn1.Width = 33
        R_GridViewTextBoxColumn1.FieldName = "CATTRIBUTE_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn1.Name = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CATTRIBUTE_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 104
        R_GridViewTextBoxColumn2.FieldName = "CPROGRAM_ID"
        R_GridViewTextBoxColumn2.HeaderText = "_CPROGRAM_ID"
        R_GridViewTextBoxColumn2.Name = "_CPROGRAM_ID"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CPROGRAM_ID"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 74
        R_GridViewTextBoxColumn3.FieldName = "CPROGRAM_NAME"
        R_GridViewTextBoxColumn3.HeaderText = "_CPROGRAM_NAME"
        R_GridViewTextBoxColumn3.Name = "_CPROGRAM_NAME"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CPROGRAM_NAME"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 95
        R_GridViewCheckBoxColumn1.FieldName = "LSPEC"
        R_GridViewCheckBoxColumn1.HeaderText = "_LSPEC"
        R_GridViewCheckBoxColumn1.Name = "_LSPEC"
        R_GridViewCheckBoxColumn1.R_ResourceId = "_LSPEC"
        R_GridViewTextBoxColumn4.FieldName = "CINITIAL_VERSION"
        R_GridViewTextBoxColumn4.HeaderText = "_CINITIAL_VERSION"
        R_GridViewTextBoxColumn4.Name = "_CINITIAL_VERSION"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CINITIAL_VERSION"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn5.FieldName = "CNOTE"
        R_GridViewTextBoxColumn5.HeaderText = "_CNOTE"
        R_GridViewTextBoxColumn5.Name = "_CNOTE"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CNOTE"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        Me.gvInbox.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewCheckBoxSelectColumn1, R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewCheckBoxColumn1, R_GridViewTextBoxColumn4, R_GridViewTextBoxColumn5})
        Me.gvInbox.MasterTemplate.DataSource = Me.bsGvInbox
        Me.gvInbox.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvInbox.MasterTemplate.EnableFiltering = True
        Me.gvInbox.MasterTemplate.EnableGrouping = False
        Me.gvInbox.MasterTemplate.EnableSorting = False
        Me.gvInbox.MasterTemplate.ShowFilteringRow = False
        Me.gvInbox.MasterTemplate.ShowGroupedColumns = True
        Me.gvInbox.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvInbox.Name = "gvInbox"
        Me.gvInbox.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvInbox.R_ConductorGridSource = Me.conGridInbox
        Me.gvInbox.R_ConductorSource = Nothing
        Me.gvInbox.R_DataAdded = False
        Me.gvInbox.R_NewRowText = Nothing
        Me.gvInbox.ShowHeaderCellButtons = True
        Me.gvInbox.Size = New System.Drawing.Size(1271, 461)
        Me.gvInbox.TabIndex = 2
        Me.gvInbox.Text = "R_RadGridView1"
        '
        'bsGvInbox
        '
        Me.bsGvInbox.DataSource = GetType(CST00120Front.CST00120StreamingServiceRef.CST00120ProgramListDTO)
        '
        'bsApps
        '
        Me.bsApps.DataSource = GetType(CST00120Front.CST00120ServiceRef.RLicenseAppComboDTO)
        '
        'CST00120
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CST00120"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.btnRefresh, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnFilter, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridInbox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblVersion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        CType(Me.lblUploadStatus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnUpload, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbUploadStatus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvInbox.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvInbox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvInbox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsVersion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource
    Friend WithEvents bsVersion As System.Windows.Forms.BindingSource
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents lblVersion As R_FrontEnd.R_RadLabel
    Friend WithEvents gvInbox As R_FrontEnd.R_RadGridView
    Friend WithEvents conGridInbox As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsGvInbox As System.Windows.Forms.BindingSource
    Friend WithEvents btnUpload As R_FrontEnd.R_RadButton
    Friend WithEvents btnFilter As R_FrontEnd.R_PopUp
    Friend WithEvents txtVersion As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtApplication As R_FrontEnd.R_RadTextBox
    Friend WithEvents btnRefresh As R_FrontEnd.R_RadButton
    Friend WithEvents lblUploadStatus As R_FrontEnd.R_RadLabel
    Friend WithEvents pbUploadStatus As R_FrontEnd.R_RadProgressBar
    Friend WithEvents bwUploadStatus As ComponentModel.BackgroundWorker
End Class
