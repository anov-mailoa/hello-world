﻿' NOTE: You can use the "Rename" command on the context menu to change the class name "CST00120Service" in code, svc and config file together.
' NOTE: In order to launch WCF Test Client for testing this service, please select CST00120Service.svc or CST00120Service.svc.vb at the Solution Explorer and start debugging.
Imports R_Common
Imports RLicenseBack

Public Class CST00120Service
    Implements ICST00120Service
    Public Function GetAppCombo(companyId As String, userId As String) As List(Of RLicenseAppComboDTO) Implements ICST00120Service.GetAppCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseAppComboDTO)

        Try
            loRtn = loCls.GetAppCombo(companyId, userId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetVersionCombo(companyId As String, appsCode As String) As List(Of RCustDBVersionComboDTO) Implements ICST00120Service.GetVersionCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBVersionComboDTO)

        Try
            loRtn = loCls.GetVersionCombo(companyId, appsCode)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Dummy1(key1 As RCustDBProjectKeyDTO) As List(Of RCustDBProcessTransactionDTO) Implements ICST00120Service.Dummy1
        Throw New NotImplementedException()
    End Function
End Class
