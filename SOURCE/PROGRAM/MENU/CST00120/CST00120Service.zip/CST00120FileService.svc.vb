﻿Imports CST00120BACK
Imports R_Common
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the class name "FileService" in code, svc and config file together.
Public Class CST00120FileService
    Implements ICST00120FileService

    Public Function SliceFile(key As RLicenseBack.RCustDBFileKeyDTO) As System.Collections.Generic.List(Of RLicenseBack.RCustDBFileSplitDTO) Implements ICST00120FileService.SliceFile
        Dim loException As New R_Exception
        Dim loCls As New FileHandlerCls
        Dim loRtn As List(Of RCustDBFileSplitDTO)

        Try
            loRtn = loCls.SliceFile(key)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetSlicedFile(key As RLicenseBack.RCustDBFileSplitKeyDTO) As RLicenseBack.RCustDBFileDTO Implements ICST00120FileService.GetSlicedFile
        Dim loException As New R_Exception
        Dim loCls As New FileHandlerCls
        Dim loRtn As RCustDBFileDTO

        Try
            loRtn = loCls.GetSlicedFile(key)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetFileInfo(key As RLicenseBack.RCustDBFileKeyDTO) As System.Collections.Generic.List(Of CST00120BACK.CST00120FileInfoDTO) Implements ICST00120FileService.GetFileInfo
        Dim loException As New R_Exception
        Dim loCls As New CST00120Cls
        Dim loRtn As List(Of CST00120FileInfoDTO)

        Try
            loRtn = loCls.GetItemInfo(key)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

End Class
