﻿Imports R_Common

Public Class Logger
    Private Shared loLogger As R_LoggerBase

    Private Sub New()
    End Sub

    Public Shared ReadOnly Property Log() As R_LoggerBase
        Get
            Return loLogger
        End Get
    End Property

    Shared Sub New()
        loLogger = New R_LoggerBase(GetType(Logger))
    End Sub
End Class
