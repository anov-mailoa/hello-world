﻿Imports System.Data.Common
Imports System.IO
Imports System.Transactions
Imports CST00120Common
Imports Ionic.Zip
Imports R_BackEnd
Imports R_Common
Imports RLicenseBack

Public Class CST00120Cls
    Implements R_IBatchProcess

    Private Const CHUNK_SIZE As Integer = 50 * 1024
    Private Shared C_ZipPath As String = "D:\RealCode\Temp\Zips"
    Private Shared C_RootPath As String = "D:\RealCodeTest"

    Public Sub R_BatchProcess(poBatchProcessPar As R_BatchProcessPar) Implements R_IBatchProcess.R_BatchProcess
        Dim loException As New R_Exception()
        Dim loDb As New R_Db()
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim loObject As List(Of RCustDBFileEntityDTO)
        Dim lcQuery As String
        Dim loProcessKey As RCustDBFileProcessKeyDTO
        Dim lnCount As Integer = 0
        Dim loConn As DbConnection = Nothing

        Try
            loConn = loDb.GetConnection()
            Dim loUserPars = From userPar In CType(poBatchProcessPar.UserParameters, List(Of R_KeyValue)) Where userPar.Key = "OPROCESS_KEY"

            loObject = R_Utility.Deserialize(poBatchProcessPar.BigObject)

            For Each loUserPar As R_KeyValue In loUserPars
                loProcessKey = R_Utility.Deserialize(loUserPar.Value)

                Dim loFiles = From file In loObject Where file.CCOMPANY_ID = loProcessKey.CCOMPANY_ID _
                              And file.CAPPS_CODE = loProcessKey.CAPPS_CODE _
                              And file.CVERSION = loProcessKey.CVERSION _
                              And file.CATTRIBUTE_GROUP = loProcessKey.CATTRIBUTE_GROUP _
                              And file.CATTRIBUTE_ID = loProcessKey.CATTRIBUTE_ID _
                              And file.CITEM_ID = loProcessKey.CPROGRAM_ID

                For Each loFile As RCustDBFileEntityDTO In loFiles

                    With loFile
                        lnCount += 1
                        lcQuery = "exec RSP_WriteUploadProcessStatus '{0}', '{1}', '{2}', '{3}', '{4}'"
                        lcQuery = String.Format(lcQuery, poBatchProcessPar.Key.COMPANY_ID, poBatchProcessPar.Key.USER_ID, poBatchProcessPar.Key.KEY_GUID.Trim, lnCount, "Processing " + loFile.CSOURCE_ID.Trim + " ...")
                        loDb.SqlExecNonQuery(lcQuery, loConn, False)
                        ' Save file
                        loCmd = loDb.GetCommand()
                        lcQuery = "EXEC RSP_Save_Cutoff_Source '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', @OFILE_DATA, @OBUILD_DATA, @OSPEC_DATA "
                        lcQuery = String.Format(lcQuery, .CCOMPANY_ID,
                                                                .CAPPS_CODE,
                                                                .CVERSION,
                                                                .CATTRIBUTE_GROUP,
                                                                .CATTRIBUTE_ID,
                                                                .CITEM_ID,
                                                                .CSOURCE_ID,
                                                                poBatchProcessPar.Key.USER_ID)
                        loCmd.CommandText = lcQuery
                        loPar = loDb.GetParameter()
                        With loPar
                            .ParameterName = "@OFILE_DATA"
                            .DbType = DbType.Binary
                            .Value = IIf(loFile.OFILE_BYTE Is Nothing, DBNull.Value, loFile.OFILE_BYTE)
                        End With
                        loCmd.Parameters.Add(loPar)
                        loPar = loDb.GetParameter()
                        With loPar
                            .ParameterName = "@OBUILD_DATA"
                            .DbType = DbType.Binary
                            .Value = IIf(loFile.OBUILD_BYTE Is Nothing, DBNull.Value, loFile.OBUILD_BYTE)
                        End With
                        loCmd.Parameters.Add(loPar)
                        loPar = loDb.GetParameter()
                        With loPar
                            .ParameterName = "@OSPEC_DATA"
                            .DbType = DbType.Binary
                            .Value = IIf(loFile.OSPEC_BYTE Is Nothing, DBNull.Value, loFile.OSPEC_BYTE)
                        End With
                        loCmd.Parameters.Add(loPar)
                        loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)
                    End With
                Next

            Next

            lcQuery = "exec RSP_WriteUploadProcessStatus '{0}', '{1}', '{2}', '{3}', '{4}', '{5}'"
            lcQuery = String.Format(lcQuery, poBatchProcessPar.Key.COMPANY_ID, poBatchProcessPar.Key.USER_ID, poBatchProcessPar.Key.KEY_GUID.Trim, lnCount, "Process complete.", 1)
            loDb.SqlExecNonQuery(lcQuery, loConn, True)

        Catch ex As Exception
            DebugText("Error: " + ex.Message)
            loException.Add(ex)
        End Try

        loException.ThrowExceptionIfErrors()
    End Sub

    Public Function GetProgramList(poKey As CST00120KeyDTO) As List(Of CST00120ProgramListDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CST00120ProgramListDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "EXEC RSP_Get_Initial_Program '{0}', '{1}', '{2}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION)

            End With
            loResult = loDb.SqlExecObjectQuery(Of CST00120ProgramListDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetItemInfo(poKey As RCustDBFileKeyDTO) As List(Of CST00120FileInfoDTO)
        ' Purpose: Get file info; return the file path
        ' Parameter: File key (.CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CITEM_ID, .CFUNCTION_ID)
        Dim lcQuery As String
        Dim loResult As List(Of CST00120FileInfoDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "EXEC RSP_Get_Item_Info '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CITEM_ID, .CFUNCTION_ID)
            End With
            loResult = loDb.SqlExecObjectQuery(Of CST00120FileInfoDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Private Sub DebugText(pcDebugLine As String)
        Dim loTextFileWriter As StreamWriter
        Dim loTextFileStream As FileStream
        Dim loTextFilename As String
        Dim lcTimeLabel As String

        loTextFilename = "D:\RealCode\Debug-" + Now.ToString("yyyyMMdd").Trim + "-CST00120.log"
        If Not File.Exists(loTextFilename) Then
            File.Create(loTextFilename).Close()
        End If
        loTextFileWriter = My.Computer.FileSystem.OpenTextFileWriter(loTextFilename, True)
        With loTextFileWriter
            lcTimeLabel = Now.ToString.Trim + ": "
            .WriteLine(lcTimeLabel + pcDebugLine)
            .Close()
        End With
    End Sub

End Class
