﻿<Serializable()> _
Public Class RCustDBFileProcessKeyDTO
    ' Main key
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CVERSION As String
    ' Item key
    Public Property CATTRIBUTE_GROUP As String
    Public Property CATTRIBUTE_ID As String
    Public Property CPROGRAM_ID As String
    Public Property LSPEC As Boolean
    Public Property CUSER_ID As String

End Class
