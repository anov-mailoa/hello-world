﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CST00110
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewCheckBoxSelectColumn1 As R_FrontEnd.R_GridViewCheckBoxSelectColumn = New R_FrontEnd.R_GridViewCheckBoxSelectColumn()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtAttribute = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtAttributeGroup = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.txtApplication = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.btnFilter = New R_FrontEnd.R_PopUp(Me.components)
        Me.conGridItem = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.lblAttributeGroup = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblAttribute = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.cboFunction = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsFunction = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblFunction = New R_FrontEnd.R_RadLabel(Me.components)
        Me.btnCopy = New R_FrontEnd.R_RadButton(Me.components)
        Me.gvItem = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsGvItem = New System.Windows.Forms.BindingSource(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.txtAttribute, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtAttributeGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnFilter, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.conGridItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblAttributeGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblAttribute, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.cboFunction, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsFunction, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblFunction, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnCopy, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvItem.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.gvItem, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 90.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.txtAttribute)
        Me.Panel1.Controls.Add(Me.txtAttributeGroup)
        Me.Panel1.Controls.Add(Me.txtApplication)
        Me.Panel1.Controls.Add(Me.btnFilter)
        Me.Panel1.Controls.Add(Me.lblAttributeGroup)
        Me.Panel1.Controls.Add(Me.lblAttribute)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 84)
        Me.Panel1.TabIndex = 0
        '
        'txtAttribute
        '
        Me.txtAttribute.Location = New System.Drawing.Point(115, 60)
        Me.txtAttribute.Name = "txtAttribute"
        Me.txtAttribute.R_ConductorGridSource = Nothing
        Me.txtAttribute.R_ConductorSource = Nothing
        Me.txtAttribute.R_UDT = Nothing
        Me.txtAttribute.ReadOnly = True
        Me.txtAttribute.Size = New System.Drawing.Size(200, 20)
        Me.txtAttribute.TabIndex = 60
        Me.txtAttribute.TabStop = False
        '
        'txtAttributeGroup
        '
        Me.txtAttributeGroup.Location = New System.Drawing.Point(115, 34)
        Me.txtAttributeGroup.Name = "txtAttributeGroup"
        Me.txtAttributeGroup.R_ConductorGridSource = Nothing
        Me.txtAttributeGroup.R_ConductorSource = Nothing
        Me.txtAttributeGroup.R_UDT = Nothing
        Me.txtAttributeGroup.ReadOnly = True
        Me.txtAttributeGroup.Size = New System.Drawing.Size(200, 20)
        Me.txtAttributeGroup.TabIndex = 59
        Me.txtAttributeGroup.TabStop = False
        '
        'txtApplication
        '
        Me.txtApplication.Location = New System.Drawing.Point(115, 8)
        Me.txtApplication.Name = "txtApplication"
        Me.txtApplication.R_ConductorGridSource = Nothing
        Me.txtApplication.R_ConductorSource = Nothing
        Me.txtApplication.R_UDT = Nothing
        Me.txtApplication.ReadOnly = True
        Me.txtApplication.Size = New System.Drawing.Size(400, 20)
        Me.txtApplication.TabIndex = 51
        Me.txtApplication.TabStop = False
        '
        'btnFilter
        '
        Me.btnFilter.Location = New System.Drawing.Point(521, 6)
        Me.btnFilter.Name = "btnFilter"
        Me.btnFilter.R_ConductorGridSource = Me.conGridItem
        Me.btnFilter.R_ConductorSource = Nothing
        Me.btnFilter.R_DescriptionId = Nothing
        Me.btnFilter.R_EnableOTHER = True
        Me.btnFilter.R_ResourceId = "btnFilter"
        Me.btnFilter.R_Title = "Inbox Filter"
        Me.btnFilter.Size = New System.Drawing.Size(110, 24)
        Me.btnFilter.TabIndex = 42
        Me.btnFilter.Text = "R_PopUp1"
        '
        'conGridItem
        '
        Me.conGridItem.R_ConductorParent = Nothing
        Me.conGridItem.R_IsHeader = True
        Me.conGridItem.R_RadGroupBox = Nothing
        '
        'lblAttributeGroup
        '
        Me.lblAttributeGroup.AutoSize = False
        Me.lblAttributeGroup.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblAttributeGroup.Location = New System.Drawing.Point(9, 35)
        Me.lblAttributeGroup.Name = "lblAttributeGroup"
        Me.lblAttributeGroup.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblAttributeGroup.R_ResourceId = "lblAttributeGroup"
        Me.lblAttributeGroup.Size = New System.Drawing.Size(100, 18)
        Me.lblAttributeGroup.TabIndex = 39
        Me.lblAttributeGroup.Text = "R_RadLabel1"
        '
        'lblAttribute
        '
        Me.lblAttribute.AutoSize = False
        Me.lblAttribute.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblAttribute.Location = New System.Drawing.Point(9, 61)
        Me.lblAttribute.Name = "lblAttribute"
        Me.lblAttribute.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblAttribute.R_ResourceId = "lblAttribute"
        Me.lblAttribute.Size = New System.Drawing.Size(100, 18)
        Me.lblAttribute.TabIndex = 33
        Me.lblAttribute.Text = "Application..."
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 30
        Me.lblApplication.Text = "Application..."
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.cboFunction)
        Me.Panel2.Controls.Add(Me.lblFunction)
        Me.Panel2.Controls.Add(Me.btnCopy)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 542)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1271, 30)
        Me.Panel2.TabIndex = 1
        '
        'cboFunction
        '
        Me.cboFunction.DataSource = Me.bsFunction
        Me.cboFunction.DisplayMember = "CFUNCTION_ID"
        Me.cboFunction.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboFunction.Location = New System.Drawing.Point(115, 6)
        Me.cboFunction.Name = "cboFunction"
        Me.cboFunction.R_ConductorGridSource = Nothing
        Me.cboFunction.R_ConductorSource = Nothing
        Me.cboFunction.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboFunction.Size = New System.Drawing.Size(202, 20)
        Me.cboFunction.TabIndex = 46
        Me.cboFunction.Text = "R_RadDropDownList1"
        Me.cboFunction.ValueMember = "CFUNCTION_ID"
        '
        'lblFunction
        '
        Me.lblFunction.AutoSize = False
        Me.lblFunction.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblFunction.Location = New System.Drawing.Point(9, 6)
        Me.lblFunction.Name = "lblFunction"
        Me.lblFunction.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblFunction.R_ResourceId = "lblFunction"
        Me.lblFunction.Size = New System.Drawing.Size(100, 18)
        Me.lblFunction.TabIndex = 45
        Me.lblFunction.Text = "Application..."
        '
        'btnCopy
        '
        Me.btnCopy.Location = New System.Drawing.Point(323, 3)
        Me.btnCopy.Name = "btnCopy"
        Me.btnCopy.R_ConductorGridSource = Me.conGridItem
        Me.btnCopy.R_ConductorSource = Nothing
        Me.btnCopy.R_DescriptionId = Nothing
        Me.btnCopy.R_EnableHASDATA = True
        Me.btnCopy.R_ResourceId = "btnCopy"
        Me.btnCopy.Size = New System.Drawing.Size(110, 24)
        Me.btnCopy.TabIndex = 7
        Me.btnCopy.Text = "Copy"
        '
        'gvItem
        '
        Me.gvItem.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvItem.EnableFastScrolling = True
        Me.gvItem.Location = New System.Drawing.Point(3, 93)
        '
        '
        '
        Me.gvItem.MasterTemplate.AllowAddNewRow = False
        Me.gvItem.MasterTemplate.AllowDeleteRow = False
        Me.gvItem.MasterTemplate.AutoGenerateColumns = False
        R_GridViewCheckBoxSelectColumn1.EditMode = Telerik.WinControls.UI.EditMode.OnValueChange
        R_GridViewCheckBoxSelectColumn1.EnableHeaderCheckBox = True
        R_GridViewCheckBoxSelectColumn1.FieldName = "LSELECT"
        R_GridViewCheckBoxSelectColumn1.HeaderText = ""
        R_GridViewCheckBoxSelectColumn1.Name = "_LSELECT"
        R_GridViewCheckBoxSelectColumn1.R_EnableEDIT = True
        R_GridViewCheckBoxSelectColumn1.R_ResourceId = ""
        R_GridViewCheckBoxSelectColumn1.Width = 33
        R_GridViewTextBoxColumn1.FieldName = "CITEM_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CITEM_ID"
        R_GridViewTextBoxColumn1.Name = "_CITEM_ID"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CITEM_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 74
        R_GridViewTextBoxColumn2.FieldName = "CITEM_NAME"
        R_GridViewTextBoxColumn2.HeaderText = "_CITEM_NAME"
        R_GridViewTextBoxColumn2.Name = "_CITEM_NAME"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CITEM_NAME"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 95
        R_GridViewTextBoxColumn3.FieldName = "CINITIAL_VERSION"
        R_GridViewTextBoxColumn3.HeaderText = "_CINITIAL_VERSION"
        R_GridViewTextBoxColumn3.Name = "_CINITIAL_VERSION"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CINITIAL_VERSION"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 120
        R_GridViewTextBoxColumn4.FieldName = "CVERSION"
        R_GridViewTextBoxColumn4.HeaderText = "_CVERSION"
        R_GridViewTextBoxColumn4.Name = "_CVERSION"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CVERSION"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 79
        R_GridViewTextBoxColumn5.FieldName = "CCUSTOMER_NAME"
        R_GridViewTextBoxColumn5.HeaderText = "_CCUSTOMER_NAME"
        R_GridViewTextBoxColumn5.Name = "_CCUSTOMER_NAME"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CCUSTOMER_NAME"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        Me.gvItem.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewCheckBoxSelectColumn1, R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewTextBoxColumn4, R_GridViewTextBoxColumn5})
        Me.gvItem.MasterTemplate.DataSource = Me.bsGvItem
        Me.gvItem.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvItem.MasterTemplate.EnableFiltering = True
        Me.gvItem.MasterTemplate.EnableGrouping = False
        Me.gvItem.MasterTemplate.EnableSorting = False
        Me.gvItem.MasterTemplate.ShowFilteringRow = False
        Me.gvItem.MasterTemplate.ShowGroupedColumns = True
        Me.gvItem.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvItem.Name = "gvItem"
        Me.gvItem.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvItem.R_ConductorGridSource = Me.conGridItem
        Me.gvItem.R_ConductorSource = Nothing
        Me.gvItem.R_DataAdded = False
        Me.gvItem.R_NewRowText = Nothing
        Me.gvItem.ShowHeaderCellButtons = True
        Me.gvItem.Size = New System.Drawing.Size(1271, 443)
        Me.gvItem.TabIndex = 2
        Me.gvItem.Text = "R_RadGridView1"
        '
        'CST00110
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "CST00110"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.txtAttribute, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtAttributeGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnFilter, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.conGridItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblAttributeGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblAttribute, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.cboFunction, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsFunction, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblFunction, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnCopy, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvItem.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents lblAttribute As R_FrontEnd.R_RadLabel
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents gvItem As R_FrontEnd.R_RadGridView
    Friend WithEvents conGridItem As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsGvItem As System.Windows.Forms.BindingSource
    Friend WithEvents lblAttributeGroup As R_FrontEnd.R_RadLabel
    Friend WithEvents btnCopy As R_FrontEnd.R_RadButton
    Friend WithEvents btnFilter As R_FrontEnd.R_PopUp
    Friend WithEvents txtApplication As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtAttributeGroup As R_FrontEnd.R_RadTextBox
    Friend WithEvents txtAttribute As R_FrontEnd.R_RadTextBox
    Friend WithEvents cboFunction As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblFunction As R_FrontEnd.R_RadLabel
    Friend WithEvents bsFunction As System.Windows.Forms.BindingSource

End Class
