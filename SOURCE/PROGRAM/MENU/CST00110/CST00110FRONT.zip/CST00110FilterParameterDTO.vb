﻿Imports CST00110Front.CST00110ServiceRef

<Serializable()> _
Public Class CST00110FilterParameterDTO
    Public Property OFILTER_KEY As RCustDBItemKeyDTO
    Public Property OAPPS_LIST As List(Of RLicenseAppComboDTO)
    Public Property OATTRIBUTE_GROUP_LIST As List(Of RCustDBAttributeGroupComboDTO)
    Public Property OATTRIBUTE_LIST As List(Of RCustDBAttributeComboDTO)
    Public Property CAPPS_NAME As String
    Public Property CATTRIBUTE_NAME As String
    Public Property CREFRESH_COMBO_MODE As String

    Sub New()
        ' initialization
        OFILTER_KEY = New RCustDBItemKeyDTO
        With OFILTER_KEY
            .CCOMPANY_ID = ""
            .CAPPS_CODE = ""
            .CATTRIBUTE_GROUP = ""
            .CATTRIBUTE_ID = ""
        End With
        CAPPS_NAME = ""
    End Sub
End Class
