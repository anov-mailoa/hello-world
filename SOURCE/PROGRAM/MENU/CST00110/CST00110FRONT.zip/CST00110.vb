﻿Imports CST00110FrontResources
Imports R_Common
Imports ClientHelper
Imports CST00110Front.CST00110ServiceRef
Imports CST00110Front.CST00110StreamingServiceRef
Imports R_FrontEnd
Imports System.ServiceModel.Channels
Imports RCustDBFrontHelper
Imports RCustDBFileCommon

Public Class CST00110

#Region " VARIABLE "
    Dim C_ServiceName As String = "CST00110Service/CST00110Service.svc"
    Dim C_ServiceNameStream As String = "CST00110Service/CST00110StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _CVERSION As String
    Dim _CPROJECTID As String
    Dim _CSESSIONID As String
    Dim _CSCHEDULEID As String
    Dim _CUSER_NAME As String
    Dim _CFUNCTIONID As String
    Dim _LDONE_COMBO_SETTING As Boolean = False
    Dim _LREADY_TO_REFRESH As Boolean = False
    Dim _LINIT As Boolean
    Dim _CATTRIBUTEGROUP As String
    Dim _CATTRIBUTEID As String
    Dim _CITEMID As String
    'Dim _CSCHEDULE_ID As String
    Dim _CACTION As String
    Dim loFilterParam As New CST00110FilterParameterDTO
    Dim loGridKey As New RCustDBItemKeyDTO
#End Region

#Region " SUBs and FUNCTIONs "

    Private Sub RefreshGrids()
        With gvItem
            bsGvItem.ResetBindings(False)
            .R_RefreshGrid(loGridKey)
            .Columns(0).Sort(Telerik.WinControls.UI.RadSortOrder.Ascending, False)
        End With
    End Sub

    Private Sub ProcessHandler(pcProcess As String)
        Dim loException As New R_Exception
        Dim loFileHandler As New FileHandler
        Dim llProcess As Boolean

        Try
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
            llProcess = False

            ' Copy
            Select Case _CFUNCTIONID
                Case "DESIGN"
                    _CACTION = "DSGCO"
                Case "DEVELOPMENT"
                    _CACTION = "DEVCO"
                Case "QC"
                    _CACTION = "QCCO"
            End Select
            Dim loCheckedItems = From item In CType(bsGvItem.List, List(Of RCustDBItemCopySourceDTO)) Where item.LSELECT = True

            If loCheckedItems.Count > 0 Then
                llProcess = True
                For Each loRow As RCustDBItemCopySourceDTO In loCheckedItems
                    With loFileHandler
                        .CCOMPANY_ID = _CCOMPID
                        .CUSER_ID = _CUSERID
                        .OFILE_PROCESS_KEY.Add(New RCustDBFileProcessKeyDTO With {.CCOMPANY_ID = _CCOMPID, _
                            .CAPPS_CODE = _CAPPSCODE, _
                            .CVERSION = loRow.CVERSION, _
                            .CPROJECT_ID = _CPROJECTID, _
                            .CSESSION_ID = _CSESSIONID, _
                            .CSCHEDULE_ID = _CSCHEDULEID, _
                            .CFUNCTION_ID = cboFunction.SelectedValue, _
                            .CATTRIBUTE_GROUP = _CATTRIBUTEGROUP, _
                            .CATTRIBUTE_ID = loRow.CATTRIBUTE_ID, _
                            .CITEM_ID = loRow.CITEM_ID, _
                            .LSPEC = loRow.LSPEC, _
                            .CACTION = _CACTION, _
                            .CUSER_ID = _CUSERID})
                        .CPROGRAM_ID = "CST00110"
                    End With
                Next

                With loFileHandler
                    .CopySource()
                End With
            Else
                loException.Add("CST00100_01", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "CST00100_01").Trim) ' no item selected
                Exit Try
            End If

        Catch ex As Exception
            loException.Add(ex)
        Finally
            If loFileHandler.OEXCEPTION IsNot Nothing Then
                loException.Add(loFileHandler.OEXCEPTION)
            End If
            If llProcess Then
                RefreshGrids()
            End If
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        End Try
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
        If loException.Haserror Then
            Me.R_DisplayException(loException)
        End If
    End Sub


#End Region

#Region " FILTER "

    Private Sub btnFilter_R_After_Open_Form(poPopUpResult As System.Windows.Forms.DialogResult, poPopUpEntityResult As Object) Handles btnFilter.R_After_Open_Form

        If poPopUpResult = Windows.Forms.DialogResult.OK Then
            loFilterParam = poPopUpEntityResult
            With loFilterParam
                _CAPPSCODE = .OFILTER_KEY.CAPPS_CODE
                _CATTRIBUTEGROUP = .OFILTER_KEY.CATTRIBUTE_GROUP
                _CATTRIBUTEID = .OFILTER_KEY.CATTRIBUTE_ID
                txtApplication.Text = .CAPPS_NAME
                txtAttributeGroup.Text = .OFILTER_KEY.CATTRIBUTE_GROUP
                txtAttribute.Text = .CATTRIBUTE_NAME
            End With
            If Not (String.IsNullOrEmpty(_CAPPSCODE) Or String.IsNullOrEmpty(_CATTRIBUTEGROUP) Or String.IsNullOrEmpty(_CATTRIBUTEID)) Then
                With loGridKey
                    .CCOMPANY_ID = _CCOMPID
                    .CAPPS_CODE = _CAPPSCODE
                    .CATTRIBUTE_GROUP = _CATTRIBUTEGROUP
                    .CATTRIBUTE_ID = _CATTRIBUTEID
                End With
                RefreshGrids()
            End If
        End If
    End Sub

    Private Sub btnFilter_R_Before_Open_Form(ByRef poTargetForm As R_FrontEnd.R_FormBase, ByRef poParameter As Object) Handles btnFilter.R_Before_Open_Form
        poTargetForm = New CST00110Filter
        poParameter = loFilterParam
    End Sub

#End Region

#Region " FORM Events "

    Private Sub CST00110_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loSvc As CST00110ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00110Service, CST00110ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)

        Try
            _LINIT = False
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            ' Function combo
            Dim loFunctionCombo As New List(Of RCustDBFunctionComboDTO)
            cboFunction.Items.Clear()
            loFunctionCombo.Add(New RCustDBFunctionComboDTO With {.CFUNCTION_ID = "DESIGN"})
            loFunctionCombo.Add(New RCustDBFunctionComboDTO With {.CFUNCTION_ID = "DEVELOPMENT"})
            loFunctionCombo.Add(New RCustDBFunctionComboDTO With {.CFUNCTION_ID = "QC"})

            bsFunction.DataSource = loFunctionCombo

            loFilterParam.OFILTER_KEY.CCOMPANY_ID = _CCOMPID
            loFilterParam.CREFRESH_COMBO_MODE = "NORMAL"
            btnFilter.PerformClick()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub CST00110_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True
    End Sub

#End Region

#Region " GRIDVIEW Events "

    Private Sub gvItem_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvItem.DataBindingComplete
        gvItem.BestFitColumns()
    End Sub

    Private Sub gvInbox_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvItem.R_ServiceGetListRecord
        Dim loServiceStream As CST00110StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICST00110StreamingService, CST00110StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of RCustDBItemCopySourceDTO)
        Dim loListEntity As New List(Of RCustDBItemCopySourceDTO)

        Try
            With CType(poEntity, RCustDBItemKeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cAttributeGroup", .CATTRIBUTE_GROUP)
                R_Utility.R_SetStreamingContext("cAttributeId", .CATTRIBUTE_ID)
            End With

            loRtn = loServiceStream.GetItemCopySource()
            loStreaming = R_StreamUtility(Of RCustDBItemCopySourceDTO).ReadFromMessage(loRtn)

            For Each loDto As RCustDBItemCopySourceDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(loDto)
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " BUTTON Actions "


    Private Sub btnCopy_Click(sender As Object, e As System.EventArgs) Handles btnCopy.Click
        ProcessHandler("COPY")
    End Sub

#End Region

End Class
