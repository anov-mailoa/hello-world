﻿Imports R_BackEnd

<Serializable()> _
Public Class LAT00200ServerDTO
    Inherits R_DTOBase

    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CCUSTOMER_CODE As String
    Public Property CREGISTRATION_ID As String
    Public Property CSERVER_TYPE As String
    Public Property CSERVER_UID As String
    Public Property CNOTE As String
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)
    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)
End Class
