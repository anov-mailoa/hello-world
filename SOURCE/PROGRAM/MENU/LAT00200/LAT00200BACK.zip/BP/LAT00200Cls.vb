﻿Imports R_BackEnd
Imports R_Common
Imports System.Data.Common
Imports ServerHelper.General

Public Class LAT00200Cls

    Public Sub RegisterServer(poNewEntity As LAT00200ServerDTO)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim lcQuery As String
        Dim loConn As DbConnection
        Dim loResult As LAT00200ServerDTO

        Try
            loConn = loDb.GetConnection()

            ' Check if server has been registered earlier
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "LAM_APP_CUST (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery += "AND CAPPS_CODE = '{1}' "
            lcQuery += "AND CCUSTOMER_CODE = '{2}' "
            lcQuery += "AND CSERVER_UID = '{3}' "
            lcQuery = String.Format(lcQuery, poNewEntity.CCOMPANY_ID, poNewEntity.CAPPS_CODE, poNewEntity.CCUSTOMER_CODE, poNewEntity.CSERVER_UID)

            loResult = loDb.SqlExecObjectQuery(Of LAT00200ServerDTO)(lcQuery, loConn, True).FirstOrDefault
            If loResult IsNot Nothing Then
                If loResult.CSERVER_TYPE = poNewEntity.CSERVER_TYPE Then
                    Throw New Exception("Server ID has been registered previously.")
                    'Else
                    '    Throw New Exception("Server ID has been registered for another server type.")
                End If
            End If

            ' Set CREGISTRATION_ID
            poNewEntity.CREGISTRATION_ID = Now.ToString("yyyyMMdd-HHmmss")

            ' Save server registration data
            lcQuery = "INSERT INTO LAT_SERVER_REG ("
            lcQuery += "CCOMPANY_ID, "
            lcQuery += "CAPPS_CODE, "
            lcQuery += "CCUSTOMER_CODE, "
            lcQuery += "CREGISTRATION_ID, "
            lcQuery += "CSERVER_TYPE, "
            lcQuery += "CSERVER_UID, "
            lcQuery += "CNOTE, "
            lcQuery += "CUPDATE_BY, "
            lcQuery += "DUPDATE_DATE, "
            lcQuery += "CCREATE_BY, "
            lcQuery += "DCREATE_DATE) "
            lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', {8}, '{9}', {10}) "
            lcQuery = String.Format(lcQuery,
            poNewEntity.CCOMPANY_ID,
            poNewEntity.CAPPS_CODE,
            poNewEntity.CCUSTOMER_CODE,
            poNewEntity.CREGISTRATION_ID,
            poNewEntity.CSERVER_TYPE,
            poNewEntity.CSERVER_UID,
            poNewEntity.CNOTE,
            poNewEntity.CUPDATE_BY,
            getDate(poNewEntity.DUPDATE_DATE),
            poNewEntity.CCREATE_BY,
            getDate(poNewEntity.DCREATE_DATE))

            loDb.SqlExecNonQuery(lcQuery)

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Function GetServerData(poTableKey As LAT00200KeyDTO) As List(Of LAT00200ServerGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of LAT00200ServerGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poTableKey

                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "LAT_SERVER_REG (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                If .CAPPS_CODE IsNot Nothing Then
                    If Not .CAPPS_CODE.Trim.Equals("") Then
                        lcQuery += "AND CAPPS_CODE = '{1}' "
                    End If
                End If
                If .CCUSTOMER_CODE IsNot Nothing Then
                    If Not .CCUSTOMER_CODE.Trim.Equals("") Then
                        lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                    End If
                End If
                If .CREGISTRATION_ID IsNot Nothing Then
                    If Not .CREGISTRATION_ID.Trim.Equals("") Then
                        lcQuery += "AND CREGISTRATION_ID = '{3}' "
                    End If
                End If
                If .CSERVER_TYPE IsNot Nothing Then
                    If Not .CSERVER_TYPE.Trim.Equals("") Then
                        lcQuery += "AND CSERVER_TYPE = '{4}' "
                    End If
                End If
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CCUSTOMER_CODE, .CREGISTRATION_ID, .CSERVER_TYPE)
            End With

            loResult = loDb.SqlExecObjectQuery(Of LAT00200ServerGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

End Class
