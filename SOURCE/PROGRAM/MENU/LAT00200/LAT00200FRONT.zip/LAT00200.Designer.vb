﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LAT00200
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn2 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.grpServerType = New R_FrontEnd.R_RadGroupBox(Me.components)
        Me.rdbTraining = New R_FrontEnd.R_RadRadioButton(Me.components)
        Me.rdbLive = New R_FrontEnd.R_RadRadioButton(Me.components)
        Me.rdbTest = New R_FrontEnd.R_RadRadioButton(Me.components)
        Me.cboCustomer = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsCust = New System.Windows.Forms.BindingSource(Me.components)
        Me.cboApplication = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblCustomer = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.lblNote = New R_FrontEnd.R_RadLabel(Me.components)
        Me.txtNote = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.btnRegisterServer = New R_FrontEnd.R_RadButton(Me.components)
        Me.txtInstallationID = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.lblInstallationId = New R_FrontEnd.R_RadLabel(Me.components)
        Me.gvServer = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsServer = New System.Windows.Forms.BindingSource(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.grpServerType, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpServerType.SuspendLayout()
        CType(Me.rdbTraining, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.rdbLive, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.rdbTest, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsCust, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.lblNote, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtNote, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnRegisterServer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtInstallationID, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblInstallationId, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvServer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvServer.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsServer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Panel2, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.gvServer, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 3
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 120.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.grpServerType)
        Me.Panel1.Controls.Add(Me.cboCustomer)
        Me.Panel1.Controls.Add(Me.cboApplication)
        Me.Panel1.Controls.Add(Me.lblCustomer)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 114)
        Me.Panel1.TabIndex = 0
        '
        'grpServerType
        '
        Me.grpServerType.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping
        Me.grpServerType.Controls.Add(Me.rdbTraining)
        Me.grpServerType.Controls.Add(Me.rdbLive)
        Me.grpServerType.Controls.Add(Me.rdbTest)
        Me.grpServerType.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.grpServerType.HeaderText = "R_RadGroupBox1"
        Me.grpServerType.Location = New System.Drawing.Point(115, 58)
        Me.grpServerType.Name = "grpServerType"
        Me.grpServerType.R_ConductorGridSource = Nothing
        Me.grpServerType.R_ConductorSource = Nothing
        Me.grpServerType.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.grpServerType.R_ResourceId = "grpServerType"
        Me.grpServerType.Size = New System.Drawing.Size(400, 53)
        Me.grpServerType.TabIndex = 10
        Me.grpServerType.Text = "R_RadGroupBox1"
        '
        'rdbTraining
        '
        Me.rdbTraining.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.rdbTraining.Location = New System.Drawing.Point(258, 24)
        Me.rdbTraining.Name = "rdbTraining"
        Me.rdbTraining.R_ConductorGridSource = Nothing
        Me.rdbTraining.R_ConductorSource = Nothing
        Me.rdbTraining.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.rdbTraining.R_ResourceId = "rdbTraining"
        Me.rdbTraining.Size = New System.Drawing.Size(122, 18)
        Me.rdbTraining.TabIndex = 10
        Me.rdbTraining.TabStop = False
        Me.rdbTraining.Text = "R_RadRadioButton1"
        '
        'rdbLive
        '
        Me.rdbLive.CheckState = System.Windows.Forms.CheckState.Checked
        Me.rdbLive.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.rdbLive.Location = New System.Drawing.Point(130, 24)
        Me.rdbLive.Name = "rdbLive"
        Me.rdbLive.R_ConductorGridSource = Nothing
        Me.rdbLive.R_ConductorSource = Nothing
        Me.rdbLive.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.rdbLive.R_ResourceId = "rdbLive"
        Me.rdbLive.Size = New System.Drawing.Size(122, 18)
        Me.rdbLive.TabIndex = 8
        Me.rdbLive.Text = "R_RadRadioButton1"
        Me.rdbLive.ToggleState = Telerik.WinControls.Enumerations.ToggleState.[On]
        '
        'rdbTest
        '
        Me.rdbTest.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.rdbTest.Location = New System.Drawing.Point(5, 24)
        Me.rdbTest.Name = "rdbTest"
        Me.rdbTest.R_ConductorGridSource = Nothing
        Me.rdbTest.R_ConductorSource = Nothing
        Me.rdbTest.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.rdbTest.R_ResourceId = "rdbTest"
        Me.rdbTest.Size = New System.Drawing.Size(122, 18)
        Me.rdbTest.TabIndex = 9
        Me.rdbTest.TabStop = False
        Me.rdbTest.Text = "R_RadRadioButton2"
        '
        'cboCustomer
        '
        Me.cboCustomer.DataSource = Me.bsCust
        Me.cboCustomer.DisplayMember = "CCUSTOMER_NAME"
        Me.cboCustomer.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList
        Me.cboCustomer.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboCustomer.Location = New System.Drawing.Point(115, 35)
        Me.cboCustomer.Name = "cboCustomer"
        Me.cboCustomer.R_ConductorGridSource = Nothing
        Me.cboCustomer.R_ConductorSource = Nothing
        Me.cboCustomer.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboCustomer.Size = New System.Drawing.Size(400, 20)
        Me.cboCustomer.TabIndex = 7
        Me.cboCustomer.Text = "R_RadDropDownList1"
        Me.cboCustomer.ValueMember = "CCUSTOMER_CODE"
        '
        'bsCust
        '
        Me.bsCust.DataSource = GetType(LAT00200Front.LAT00200ServiceRef.RLicenseCustComboDTO)
        '
        'cboApplication
        '
        Me.cboApplication.DataSource = Me.bsApps
        Me.cboApplication.DisplayMember = "CAPPS_NAME"
        Me.cboApplication.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList
        Me.cboApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboApplication.Location = New System.Drawing.Point(115, 9)
        Me.cboApplication.Name = "cboApplication"
        Me.cboApplication.R_ConductorGridSource = Nothing
        Me.cboApplication.R_ConductorSource = Nothing
        Me.cboApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboApplication.Size = New System.Drawing.Size(400, 20)
        Me.cboApplication.TabIndex = 6
        Me.cboApplication.Text = "R_RadDropDownList1"
        Me.cboApplication.ValueMember = "CAPPS_CODE"
        '
        'bsApps
        '
        Me.bsApps.DataSource = GetType(LAT00200Front.LAT00200ServiceRef.RLicenseAppComboDTO)
        '
        'lblCustomer
        '
        Me.lblCustomer.AutoSize = False
        Me.lblCustomer.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustomer.Location = New System.Drawing.Point(9, 33)
        Me.lblCustomer.Name = "lblCustomer"
        Me.lblCustomer.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustomer.R_ResourceId = "lblCustomer"
        Me.lblCustomer.Size = New System.Drawing.Size(100, 18)
        Me.lblCustomer.TabIndex = 5
        Me.lblCustomer.Text = "Customer..."
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 4
        Me.lblApplication.Text = "Application..."
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.lblNote)
        Me.Panel2.Controls.Add(Me.txtNote)
        Me.Panel2.Controls.Add(Me.btnRegisterServer)
        Me.Panel2.Controls.Add(Me.txtInstallationID)
        Me.Panel2.Controls.Add(Me.lblInstallationId)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(3, 478)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1271, 94)
        Me.Panel2.TabIndex = 1
        '
        'lblNote
        '
        Me.lblNote.AutoSize = False
        Me.lblNote.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblNote.Location = New System.Drawing.Point(9, 33)
        Me.lblNote.Name = "lblNote"
        Me.lblNote.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblNote.R_ResourceId = "lblNote"
        Me.lblNote.Size = New System.Drawing.Size(100, 18)
        Me.lblNote.TabIndex = 8
        Me.lblNote.Text = "R_RadLabel1"
        '
        'txtNote
        '
        Me.txtNote.AcceptsReturn = True
        Me.txtNote.AutoSize = False
        Me.txtNote.Location = New System.Drawing.Point(115, 32)
        Me.txtNote.Multiline = True
        Me.txtNote.Name = "txtNote"
        Me.txtNote.R_ConductorGridSource = Nothing
        Me.txtNote.R_ConductorSource = Nothing
        Me.txtNote.R_UDT = Nothing
        Me.txtNote.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtNote.Size = New System.Drawing.Size(609, 59)
        Me.txtNote.TabIndex = 7
        '
        'btnRegisterServer
        '
        Me.btnRegisterServer.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnRegisterServer.Location = New System.Drawing.Point(730, 4)
        Me.btnRegisterServer.Name = "btnRegisterServer"
        Me.btnRegisterServer.R_ConductorGridSource = Nothing
        Me.btnRegisterServer.R_ConductorSource = Nothing
        Me.btnRegisterServer.R_DescriptionId = Nothing
        Me.btnRegisterServer.R_ResourceId = "btnRegisterServer"
        Me.btnRegisterServer.Size = New System.Drawing.Size(110, 24)
        Me.btnRegisterServer.TabIndex = 6
        Me.btnRegisterServer.Text = "R_RadButton1"
        '
        'txtInstallationID
        '
        Me.txtInstallationID.Location = New System.Drawing.Point(115, 6)
        Me.txtInstallationID.Name = "txtInstallationID"
        Me.txtInstallationID.R_ConductorGridSource = Nothing
        Me.txtInstallationID.R_ConductorSource = Nothing
        Me.txtInstallationID.R_UDT = Nothing
        Me.txtInstallationID.Size = New System.Drawing.Size(609, 20)
        Me.txtInstallationID.TabIndex = 5
        '
        'lblInstallationId
        '
        Me.lblInstallationId.AutoSize = False
        Me.lblInstallationId.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblInstallationId.Location = New System.Drawing.Point(9, 7)
        Me.lblInstallationId.Name = "lblInstallationId"
        Me.lblInstallationId.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblInstallationId.R_ResourceId = "lblInstallationId"
        Me.lblInstallationId.Size = New System.Drawing.Size(100, 18)
        Me.lblInstallationId.TabIndex = 4
        Me.lblInstallationId.Text = "R_RadLabel1"
        '
        'gvServer
        '
        Me.gvServer.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gvServer.EnableFastScrolling = True
        Me.gvServer.Location = New System.Drawing.Point(3, 123)
        '
        '
        '
        Me.gvServer.MasterTemplate.AllowAddNewRow = False
        Me.gvServer.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn1.FieldName = "_CREGISTRATION_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CREGISTRATION_ID"
        R_GridViewTextBoxColumn1.Name = "_CREGISTRATION_ID"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CREGISTRATION_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 125
        R_GridViewTextBoxColumn2.FieldName = "_CSERVER_UID"
        R_GridViewTextBoxColumn2.HeaderText = "_CSERVER_UID"
        R_GridViewTextBoxColumn2.Name = "_CSERVER_UID"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CSERVER_UID"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 95
        R_GridViewTextBoxColumn3.FieldName = "_CNOTE"
        R_GridViewTextBoxColumn3.HeaderText = "_CNOTE"
        R_GridViewTextBoxColumn3.Name = "_CNOTE"
        R_GridViewTextBoxColumn3.R_ResourceId = "_CNOTE"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 63
        R_GridViewTextBoxColumn4.FieldName = "_CUPDATE_BY"
        R_GridViewTextBoxColumn4.HeaderText = "_CUPDATE_BY"
        R_GridViewTextBoxColumn4.Name = "_CUPDATE_BY"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CUPDATE_BY"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 92
        R_GridViewDateTimeColumn1.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn1.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn1.FieldName = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn1.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn1.HeaderText = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.Name = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.R_ResourceId = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.Width = 107
        R_GridViewTextBoxColumn5.FieldName = "_CCREATE_BY"
        R_GridViewTextBoxColumn5.HeaderText = "_CCREATE_BY"
        R_GridViewTextBoxColumn5.Name = "_CCREATE_BY"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CCREATE_BY"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 90
        R_GridViewDateTimeColumn2.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn2.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn2.FieldName = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn2.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn2.HeaderText = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.Name = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.R_ResourceId = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.Width = 105
        Me.gvServer.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewTextBoxColumn4, R_GridViewDateTimeColumn1, R_GridViewTextBoxColumn5, R_GridViewDateTimeColumn2})
        Me.gvServer.MasterTemplate.DataSource = Me.bsServer
        Me.gvServer.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvServer.MasterTemplate.EnableFiltering = True
        Me.gvServer.MasterTemplate.EnableGrouping = False
        Me.gvServer.MasterTemplate.ShowFilteringRow = False
        Me.gvServer.MasterTemplate.ShowGroupedColumns = True
        Me.gvServer.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvServer.Name = "gvServer"
        Me.gvServer.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvServer.R_ConductorGridSource = Nothing
        Me.gvServer.R_ConductorSource = Nothing
        Me.gvServer.R_DataAdded = False
        Me.gvServer.R_NewRowText = Nothing
        Me.gvServer.ReadOnly = True
        Me.gvServer.ShowHeaderCellButtons = True
        Me.gvServer.Size = New System.Drawing.Size(1271, 349)
        Me.gvServer.TabIndex = 2
        Me.gvServer.Text = "R_RadGridView1"
        '
        'bsServer
        '
        Me.bsServer.DataSource = GetType(LAT00200Front.LAT00200ServiceRef.LAT00200ServerDTO)
        '
        'LAT00200
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "LAT00200"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.grpServerType, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpServerType.ResumeLayout(False)
        Me.grpServerType.PerformLayout()
        CType(Me.rdbTraining, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.rdbLive, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.rdbTest, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsCust, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.lblNote, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtNote, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnRegisterServer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtInstallationID, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblInstallationId, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvServer.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvServer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsServer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents cboCustomer As R_FrontEnd.R_RadDropDownList
    Friend WithEvents cboApplication As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblCustomer As R_FrontEnd.R_RadLabel
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents txtInstallationID As R_FrontEnd.R_RadTextBox
    Friend WithEvents lblInstallationId As R_FrontEnd.R_RadLabel
    Friend WithEvents gvServer As R_FrontEnd.R_RadGridView
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource
    Friend WithEvents bsCust As System.Windows.Forms.BindingSource
    Friend WithEvents bsServer As System.Windows.Forms.BindingSource
    Friend WithEvents btnRegisterServer As R_FrontEnd.R_RadButton
    Friend WithEvents lblNote As R_FrontEnd.R_RadLabel
    Friend WithEvents txtNote As R_FrontEnd.R_RadTextBox
    Friend WithEvents grpServerType As R_FrontEnd.R_RadGroupBox
    Friend WithEvents rdbTest As R_FrontEnd.R_RadRadioButton
    Friend WithEvents rdbLive As R_FrontEnd.R_RadRadioButton
    Friend WithEvents rdbTraining As R_FrontEnd.R_RadRadioButton

End Class
