﻿Imports LAT00200FrontResources
Imports R_Common
Imports LAT00200Front.LAT00200ServiceRef
Imports LAT00200Front.LAT00200StreamingServiceRef
Imports System.ServiceModel.Channels
Imports ClientHelper
Imports R_FrontEnd

Public Class LAT00200

#Region " VARIABLE "
    Dim C_ServiceName As String = "LAT00200Service/LAT00200Service.svc"
    Dim C_ServiceNameStream As String = "LAT00200Service/LAT00200StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim llInitialized As Boolean = False
    Dim _CACTIVATION_TYPE As String = ""

#End Region

    Private Sub LAT00200_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loSvc As LAT00200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00200Service, LAT00200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loAppCombo As New List(Of RVM00100AppComboDTO)
        Dim loCustCombo As New List(Of RLicenseCustComboDTO)

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            ' Application
            loAppCombo = loSvc.GetApplicationCombo(_CCOMPID, _CUSERID)
            bsApps.DataSource = loAppCombo

            ' Customer
            loCustCombo = loSvc.GetCustCombo(_CCOMPID)
            bsCust.DataSource = loCustCombo

            llInitialized = True
            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvServer_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvServer.R_ServiceGetListRecord
        Dim loServiceStream As LAT00200StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00200StreamingService, LAT00200StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of LAT00200ServerGridDTO)
        Dim loListEntity As New List(Of LAT00200ServerDTO)

        Try
            With poEntity
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cCustomerCode", .CCUSTOMER_CODE)
                R_Utility.R_SetStreamingContext("cServerType", .CSERVER_TYPE)
            End With

            loRtn = loServiceStream.GetServerData()
            loStreaming = R_StreamUtility(Of LAT00200ServerGridDTO).ReadFromMessage(loRtn)

            For Each loDto As LAT00200ServerGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New LAT00200ServerDTO With {._CAPPS_CODE = loDto.CAPPS_CODE,
                                                                 ._CCUSTOMER_CODE = loDto.CCUSTOMER_CODE,
                                                                 ._CREGISTRATION_ID = loDto.CREGISTRATION_ID,
                                                                 ._CSERVER_UID = loDto.CSERVER_UID,
                                                                 ._CNOTE = loDto.CNOTE,
                                                                 ._CCREATE_BY = loDto.CCREATE_BY,
                                                                 ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                                 ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                                 ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub RefreshGrids()
        Dim loTableKey As New LAT00200KeyDTO
        Dim loSvc As LAT00200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00200Service, LAT00200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)

        With loTableKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = cboApplication.SelectedValue.Trim
            .CCUSTOMER_CODE = cboCustomer.SelectedValue.Trim
            .CSERVER_TYPE = IIf(rdbLive.IsChecked, "1", IIf(rdbTraining.IsChecked, "2", "0"))
        End With

        gvServer.R_RefreshGrid(loTableKey)
    End Sub

    Private Sub cboApplication_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboApplication.SelectedValueChanged
        If llInitialized Then
            _CACTIVATION_TYPE = bsApps.Current.CACTIVATION_TYPE_NAME
            RefreshGrids()
        End If
    End Sub

    Private Sub cboCustomer_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboCustomer.SelectedValueChanged
        If llInitialized Then
            RefreshGrids()
        End If
    End Sub

    Private Sub btnRegisterServer_Click(sender As System.Object, e As System.EventArgs) Handles btnRegisterServer.Click
        Dim loEx As New R_Exception
        Dim loSvc As LAT00200ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00200Service, LAT00200ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loServer As LAT00200ServerDTO
        Dim lcInstallationID_Decrypted As String = ""
        Dim lcInstallationID As String()

        Try
            ' Validation
            ' Server ID
            If txtInstallationID.Text.Trim.Equals("") Then
                loEx.Add("LAT00200_01", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "LAT00200_01"))
                Exit Try
            Else
                If _CACTIVATION_TYPE.Trim = "002" Then
                    ' Validation for smart client type
                    lcInstallationID_Decrypted = R_Utility.DecryptPbkdf2(txtInstallationID.Text.Trim, "R3@lt@1nst@ll")
                    lcInstallationID = lcInstallationID_Decrypted.Split("|")
                    ' Application ID
                    If Not lcInstallationID(1).Trim.Equals(cboApplication.SelectedValue.Trim) Then
                        loEx.Add("LAT00200_02", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "LAT00200_02"))
                        Exit Try
                    End If
                    ' Company ID
                    ' Split customer name
                    Dim lcCustomerName As String()
                    lcCustomerName = cboCustomer.Text.ToString.Split("|")
                    If Not lcInstallationID(2).Trim.Equals(lcCustomerName(0).Trim) Then
                        loEx.Add("LAT00200_03", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "LAT00200_03"))
                        Exit Try
                    End If

                End If

            End If

            ' Save
            loServer = New LAT00200ServerDTO
            With loServer
                ._CCOMPANY_ID = _CCOMPID
                ._CAPPS_CODE = cboApplication.SelectedValue.Trim
                ._CCUSTOMER_CODE = cboCustomer.SelectedValue.Trim
                ._CSERVER_TYPE = IIf(rdbLive.IsChecked, "1", IIf(rdbTraining.IsChecked, "2", "0"))
                ._CSERVER_UID = txtInstallationID.Text.Trim
                ._CNOTE = txtNote.Text.Trim
                ._CUPDATE_BY = _CUSERID
                ._DUPDATE_DATE = Now
                ._CCREATE_BY = _CUSERID
                ._DCREATE_DATE = Now
            End With
            loSvc.RegisterServer(loServer)

            RefreshGrids()

            ' clear input
            txtInstallationID.Text = ""
            txtNote.Text = ""
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loEx.Haserror Then
            R_DisplayException(loEx)
        End If
    End Sub

    Private Sub rdbLive_CheckStateChanged(sender As Object, e As System.EventArgs) Handles rdbLive.CheckStateChanged
        If CType(sender, R_RadRadioButton).IsChecked And llInitialized Then
            RefreshGrids()
        End If
    End Sub

    Private Sub rdbTest_CheckStateChanged(sender As Object, e As System.EventArgs) Handles rdbTest.CheckStateChanged
        If CType(sender, R_RadRadioButton).IsChecked And llInitialized Then
            RefreshGrids()
        End If
    End Sub

    Private Sub rdbTraining_CheckStateChanged(sender As Object, e As System.EventArgs) Handles rdbTraining.CheckStateChanged
        If CType(sender, R_RadRadioButton).IsChecked And llInitialized Then
            RefreshGrids()
        End If
    End Sub
End Class
