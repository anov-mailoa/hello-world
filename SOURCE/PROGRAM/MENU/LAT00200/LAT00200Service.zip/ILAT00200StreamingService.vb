﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports LAT00200Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ILAT00200StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ILAT00200StreamingService

    <OperationContract(Action:="getServerData", ReplyAction:="getServerData")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetServerData() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of LAT00200ServerGridDTO))

End Interface
