﻿Imports System.ServiceModel
Imports R_Common
Imports RLicenseBack
Imports LAT00100Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ILAT00100Service" in both code and config file together.
<ServiceContract()>
Public Interface ILAT00100Service

    <OperationContract(Action:="getAppCombo", ReplyAction:="getAppCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAppCombo(companyId As String, userId As String) As List(Of LAT00100AppComboDTO)

    <OperationContract(Action:="getCustCombo", ReplyAction:="getCustCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetCustCombo(companyId As String) As List(Of RLicenseCustComboDTO)

    <OperationContract(Action:="getLicenseMode", ReplyAction:="getLicenseMode")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetLicenseMode(companyId As String) As List(Of String)

    <OperationContract(Action:="saveLicense", ReplyAction:="saveLicense")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub SaveLicense(ByVal poNewEntity As LAT00100LicenseDTO)

    <OperationContract(Action:="saveActivation", ReplyAction:="saveActivation")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub SaveActivation(ByVal poNewEntity As LAT00100ActivationDTO)

    <OperationContract(Action:="getServerID", ReplyAction:="getServerID")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetServerID(poPar As LAT00100KeyDTO) As String

    <OperationContract(Action:="getCustAppSetting", ReplyAction:="getCustAppSetting")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetCustAppSetting(poPar As LAT00100KeyDTO) As LAT00100CustAppDTO

    <OperationContract(Action:="getReactivationStatus", ReplyAction:="getReactivationStatus")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetReactivationStatus(poPar As LAT00100KeyDTO) As LAT00100ReactivationStatusDTO

    <OperationContract(Action:="resetReactivationStatus", ReplyAction:="resetReactivationStatus")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub ResetReactivationStatus(poTableKey As LAT00100KeyDTO)

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function Dummy1() As List(Of LAT00100LicenseDTO)

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function Dummy2() As List(Of LAT00100ActivationDTO)

End Interface
