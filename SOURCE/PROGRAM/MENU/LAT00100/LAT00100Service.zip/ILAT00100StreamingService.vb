﻿Imports System.ServiceModel
Imports R_Common
Imports LAT00100Back
Imports System.ServiceModel.Channels
' NOTE: You can use the "Rename" command on the context menu to change the interface name "ILAM00100StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ILAT00100StreamingService

    <OperationContract(Action:="getLicenseData", ReplyAction:="getLicenseData")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetLicenseData() As Message

    <OperationContract(Action:="getActivationData", ReplyAction:="getActivationData")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetActivationData() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of LAT00100LicenseGridDTO), ByVal poPar2 As List(Of LAT00100ActivationGridDTO))

End Interface
