﻿Imports R_Common
Imports R_BackEnd
Imports System.Data.Common
Imports ServerHelper.General
Imports System.Transactions

Public Class LAT00100Cls

    Public Function GetLicenseMode(pcCompanyId As String) As List(Of String)
        Dim loResult As List(Of String)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT CLICENSE_MODE "
            lcQuery += "FROM "
            lcQuery += "LAM_COMPANY_LICENSE_MODE (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery += "ORDER BY LDEFAULT DESC, CLICENSE_MODE "
            lcQuery = String.Format(lcQuery, pcCompanyId)

            loResult = loDb.SqlExecObjectQuery(Of String)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

        Return loResult
    End Function

    Public Sub SaveLicense(poNewEntity As LAT00100LicenseDTO)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As LAT00100LicenseDTO

        Try
            loConn = loDb.GetConnection()

            ' Generate Code
            Dim lcLicenseData As String
            Dim ldGenerateTime As DateTime
            Dim lcLicenseKey As String

            With poNewEntity
                lcLicenseData = .CCUSTOMER_CODE.Trim & "|"
                lcLicenseData += .CCUSTOMER_NAME.Trim & "|"
                lcLicenseData += .CAPPS_CODE.Trim & "|"
                lcLicenseData += .CLICENSE_MODE.Trim & "|"
                lcLicenseData += .NLICENSEE.ToString.Trim & "|"
                ldGenerateTime = Now
                lcLicenseData += ldGenerateTime.ToString("yyyyMMddHHmmss")
                lcLicenseKey = .CSERVER_UID.Trim & "R3@lt@L1c3ns3"
                .CLICENSE_CODE = R_Utility.EncryptPbkdf2(lcLicenseData, lcLicenseKey)
                .CGENERATE_TIME = ldGenerateTime.ToString("yyyy.MM.dd.HH.mm.ss")
            End With

            ' Save license data
            lcQuery = "INSERT INTO LAT_LICENSE ("
            lcQuery += "CCOMPANY_ID, "
            lcQuery += "CAPPS_CODE, "
            lcQuery += "CCUSTOMER_CODE, "
            lcQuery += "CGENERATE_TIME, "
            lcQuery += "CSERVER_TYPE, "
            lcQuery += "CSERVER_UID, "
            lcQuery += "CLICENSE_MODE, "
            lcQuery += "NLICENSEE, "
            lcQuery += "CLICENSE_CODE, "
            lcQuery += "CUPDATE_BY, "
            lcQuery += "DUPDATE_DATE, "
            lcQuery += "CCREATE_BY, "
            lcQuery += "DCREATE_DATE) "
            lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', {7}, '{8}', '{9}', GETDATE(), '{10}', GETDATE()) "
            lcQuery = String.Format(lcQuery,
            poNewEntity.CCOMPANY_ID,
            poNewEntity.CAPPS_CODE,
            poNewEntity.CCUSTOMER_CODE,
            poNewEntity.CGENERATE_TIME,
            poNewEntity.CSERVER_TYPE,
            poNewEntity.CSERVER_UID,
            poNewEntity.CLICENSE_MODE,
            poNewEntity.NLICENSEE,
            poNewEntity.CLICENSE_CODE,
            poNewEntity.CUPDATE_BY,
            poNewEntity.CCREATE_BY)

            loDb.SqlExecNonQuery(lcQuery)

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Sub SaveActivation(poNewEntity As LAT00100ActivationDTO)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String
        Dim loResult As LAT00100ActivationDTO
        Dim lcActivationType As String

        Try
            loConn = loDb.GetConnection()

            ' Generate Code
            Dim lcActivationData As String
            Dim ldGenerateTime As DateTime
            Dim lcActivationKey As String

            With poNewEntity
                lcActivationData = .CCUSTOMER_CODE.Trim & "|"
                lcActivationData += .CAPPS_CODE.Trim & "|"
                lcActivationData += .CSTART_DATE.Trim & "|"
                lcActivationData += .CEXPIRY_DATE & "|"
                lcActivationData += .NGRACE_DAYS.ToString.Trim & "|"
                lcActivationData += .NWARNING_DAYS.ToString.Trim & "|"
                ldGenerateTime = Now
                lcActivationData += ldGenerateTime.ToString("yyyyMMddHHmmss")
                lcActivationKey = .CSERVER_UID.Trim & "R3@lt@R3@ct1v@t10n"
                .CACTIVATION_CODE = R_Utility.EncryptPbkdf2(lcActivationData, lcActivationKey)
                .CGENERATE_TIME = ldGenerateTime.ToString("yyyy.MM.dd.HH.mm.ss")
            End With

            ' untuk Windows activation type (FoxPro), kosongkan activation code (sementara?)
            lcQuery = "SELECT CACTIVATION_TYPE "
            lcQuery += "FROM "
            lcQuery += "RVM_APPLICATION (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery += "AND CAPPS_CODE = '{1}' "
            lcQuery = String.Format(lcQuery, poNewEntity.CCOMPANY_ID, poNewEntity.CAPPS_CODE)
            lcActivationType = loDb.SqlExecObjectQuery(Of String)(lcQuery).FirstOrDefault

            If lcActivationType.Trim = "001" Then
                poNewEntity.CACTIVATION_CODE = ""
            End If

            ' Save activation data
            Using TransScope As New TransactionScope(TransactionScopeOption.Required)

                lcQuery = "INSERT INTO LAT_ACTIVATION ("
                lcQuery += "CCOMPANY_ID, "
                lcQuery += "CAPPS_CODE, "
                lcQuery += "CCUSTOMER_CODE, "
                lcQuery += "CGENERATE_TIME, "
                lcQuery += "CSERVER_TYPE, "
                lcQuery += "CSERVER_UID, "
                lcQuery += "CSTART_DATE, "
                lcQuery += "CEXPIRY_DATE, "
                lcQuery += "NGRACE_DAYS, "
                lcQuery += "NWARNING_DAYS, "
                lcQuery += "CACTIVATION_CODE, "
                lcQuery += "CUPDATE_BY, "
                lcQuery += "DUPDATE_DATE, "
                lcQuery += "CCREATE_BY, "
                lcQuery += "DCREATE_DATE) "
                lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', {8}, {9}, '{10}', '{11}', GETDATE(), '{12}', GETDATE()) "
                lcQuery = String.Format(lcQuery,
                poNewEntity.CCOMPANY_ID,
                poNewEntity.CAPPS_CODE,
                poNewEntity.CCUSTOMER_CODE,
                poNewEntity.CGENERATE_TIME,
                poNewEntity.CSERVER_TYPE,
                poNewEntity.CSERVER_UID,
                poNewEntity.CSTART_DATE,
                poNewEntity.CEXPIRY_DATE,
                poNewEntity.NGRACE_DAYS,
                poNewEntity.NWARNING_DAYS,
                poNewEntity.CACTIVATION_CODE,
                poNewEntity.CUPDATE_BY,
                poNewEntity.CCREATE_BY)

                loDb.SqlExecNonQuery(lcQuery, loConn, False)

                If Not poNewEntity.LREACTIVATION_REQUEST And Not poNewEntity.LACTIVATION_REQUEST Then
                    ' update last expiry date hanya jika dari program
                    lcQuery = "UPDATE LAM_APP_CUST "
                    lcQuery += "SET CLAST_EXPIRY_DATE = '{4}', "
                    lcQuery += "CUPDATE_BY = '{5}', DUPDATE_DATE = GETDATE() "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                    lcQuery += "AND CSERVER_TYPE = '{3}' "
                    lcQuery = String.Format(lcQuery, poNewEntity.CCOMPANY_ID, _
                                            poNewEntity.CAPPS_CODE, _
                                            poNewEntity.CCUSTOMER_CODE, _
                                            poNewEntity.CSERVER_TYPE, _
                                            poNewEntity.CEXPIRY_DATE, _
                                            poNewEntity.CUPDATE_BY)
                    loDb.SqlExecNonQuery(lcQuery, loConn, False)
                End If

                If poNewEntity.LACTIVATION_REQUEST Then
                    If poNewEntity.CREFERENCE_NO IsNot Nothing Then
                        If Not String.IsNullOrEmpty(poNewEntity.CREFERENCE_NO) Then
                            ' Save activation data
                            lcQuery = "INSERT INTO LAT_ACTIVATION_CLOUD ("
                            lcQuery += "CCOMPANY_ID, "
                            lcQuery += "CAPPS_CODE, "
                            lcQuery += "CCUSTOMER_CODE, "
                            lcQuery += "CGENERATE_TIME, "
                            lcQuery += "CREFERENCE_NO, "
                            lcQuery += "LFETCHED, "
                            lcQuery += "LINSTALLED, "
                            lcQuery += "CUPDATE_BY, "
                            lcQuery += "DUPDATE_DATE, "
                            lcQuery += "CCREATE_BY, "
                            lcQuery += "DCREATE_DATE) "
                            lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', 0, 0, '{5}', GETDATE(), '{6}', GETDATE()) "
                            lcQuery = String.Format(lcQuery,
                            poNewEntity.CCOMPANY_ID,
                            poNewEntity.CAPPS_CODE,
                            poNewEntity.CCUSTOMER_CODE,
                            poNewEntity.CGENERATE_TIME,
                            poNewEntity.CREFERENCE_NO,
                            poNewEntity.CUPDATE_BY,
                            poNewEntity.CCREATE_BY)

                            loDb.SqlExecNonQuery(lcQuery, loConn)
                        End If
                    End If
                End If
                TransScope.Complete()
            End Using

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub

    Public Function GetLicenseData(poTableKey As LAT00100KeyDTO) As List(Of LAT00100LicenseGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of LAT00100LicenseGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poTableKey

                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "LAT_LICENSE (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                If .CAPPS_CODE IsNot Nothing Then
                    If Not .CAPPS_CODE.Trim.Equals("") Then
                        lcQuery += "AND CAPPS_CODE = '{1}' "
                    End If
                End If
                If .CCUSTOMER_CODE IsNot Nothing Then
                    If Not .CCUSTOMER_CODE.Trim.Equals("") Then
                        lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                    End If
                End If
                If .CGENERATE_TIME IsNot Nothing Then
                    If Not .CGENERATE_TIME.Trim.Equals("") Then
                        lcQuery += "AND CGENERATE_TIME = '{3}' "
                    End If
                End If
                If .CSERVER_TYPE IsNot Nothing Then
                    If Not .CSERVER_TYPE.Trim.Equals("") Then
                        lcQuery += "AND CSERVER_TYPE = '{4}' "
                    End If
                End If
                lcQuery += "ORDER BY CGENERATE_TIME DESC"
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CCUSTOMER_CODE, .CGENERATE_TIME, .CSERVER_TYPE)
            End With

            loResult = loDb.SqlExecObjectQuery(Of LAT00100LicenseGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetActivationData(poTableKey As LAT00100KeyDTO) As List(Of LAT00100ActivationGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of LAT00100ActivationGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poTableKey

                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "LAT_ACTIVATION (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                If .CAPPS_CODE IsNot Nothing Then
                    If Not .CAPPS_CODE.Trim.Equals("") Then
                        lcQuery += "AND CAPPS_CODE = '{1}' "
                    End If
                End If
                If .CCUSTOMER_CODE IsNot Nothing Then
                    If Not .CCUSTOMER_CODE.Trim.Equals("") Then
                        lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                    End If
                End If
                If .CGENERATE_TIME IsNot Nothing Then
                    If Not .CGENERATE_TIME.Trim.Equals("") Then
                        lcQuery += "AND CGENERATE_TIME = '{3}' "
                    End If
                End If
                If .CSERVER_TYPE IsNot Nothing Then
                    If Not .CSERVER_TYPE.Trim.Equals("") Then
                        lcQuery += "AND CSERVER_TYPE = '{4}' "
                    End If
                End If
                lcQuery += "ORDER BY CGENERATE_TIME DESC"
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CCUSTOMER_CODE, .CGENERATE_TIME, .CSERVER_TYPE)
            End With

            loResult = loDb.SqlExecObjectQuery(Of LAT00100ActivationGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetServerID(poTableKey As LAT00100KeyDTO) As String
        Dim lcQuery As String
        Dim loResult As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poTableKey

                lcQuery = "SELECT CSERVER_UID "
                lcQuery += "FROM "
                lcQuery += "LAM_APP_CUST (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                lcQuery += "AND CSERVER_TYPE = '{3}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CCUSTOMER_CODE, .CSERVER_TYPE)
            End With

            loResult = loDb.SqlExecObjectQuery(Of String)(lcQuery).FirstOrDefault
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetCustAppSetting(poTableKey As LAT00100KeyDTO) As LAT00100CustAppDTO
        Dim lcQuery As String
        Dim loResult As LAT00100CustAppDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poTableKey

                lcQuery = "SELECT CSERVER_UID, LACTIVE, NINTERVAL, NGRACE_DAYS, NWARNING_DAYS, CLAST_EXPIRY_DATE "
                lcQuery += "FROM "
                lcQuery += "LAM_APP_CUST (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                lcQuery += "AND CSERVER_TYPE = '{3}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CCUSTOMER_CODE, .CSERVER_TYPE)
            End With

            loResult = loDb.SqlExecObjectQuery(Of LAT00100CustAppDTO)(lcQuery).FirstOrDefault
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetReactivationStatus(poTableKey As LAT00100KeyDTO) As LAT00100ReactivationStatusDTO
        Dim lcQuery As String
        Dim loResult As LAT00100ReactivationStatusDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poTableKey

                lcQuery = "SELECT CLAST_EXPIRY_DATE, CCURRENT_EXPIRY_DATE, CREACTIVATION_STATUS "
                lcQuery += "FROM "
                lcQuery += "LAM_APP_CUST (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                lcQuery += "AND CSERVER_TYPE = '{3}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CCUSTOMER_CODE, .CSERVER_TYPE)
            End With

            loResult = loDb.SqlExecObjectQuery(Of LAT00100ReactivationStatusDTO)(lcQuery).FirstOrDefault
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Sub ResetReactivationStatus(poTableKey As LAT00100KeyDTO)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String

        Try
            loConn = loDb.GetConnection()

            With poTableKey
                ' reset reactivation status
                lcQuery = "UPDATE LAM_APP_CUST "
                lcQuery += "SET CCURRENT_EXPIRY_DATE = '', "
                lcQuery += "CREACTIVATION_STATUS = '', "
                lcQuery += "CUPDATE_BY = '{4}', DUPDATE_DATE = GETDATE() "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CCUSTOMER_CODE = '{2}' "
                lcQuery += "AND CSERVER_TYPE = '{3}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CCUSTOMER_CODE, _
                                        .CSERVER_TYPE, _
                                        .CUSER_ID)
                loDb.SqlExecNonQuery(lcQuery, loConn)
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Function GetAppCombo(pcCompany_ID As String, pcUser_ID As String) As List(Of LAT00100AppComboDTO)
        Dim lcQuery As String
        Dim loResult As List(Of LAT00100AppComboDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT A.CAPPS_CODE, A.CAPPS_NAME, A.CACTIVATION_TYPE, "
            lcQuery += "ISNULL(B.CDESCRIPTION,'(undefined)') AS CACTIVATION_TYPE_NAME "
            lcQuery += "FROM RVM_APPLICATION A (NOLOCK) "
            lcQuery += "JOIN RVM_ACTIVATION_TYPE B (NOLOCK) "
            lcQuery += "ON B.CACTIVATION_TYPE = A.CACTIVATION_TYPE "
            lcQuery += "JOIN RVM_APP_USER C (NOLOCK) "
            lcQuery += "ON C.CCOMPANY_ID = A.CCOMPANY_ID "
            lcQuery += "AND C.CAPPS_CODE = A.CAPPS_CODE "
            lcQuery += "AND C.CUSER_ID = '{1}' "
            lcQuery += "WHERE A.CCOMPANY_ID = '{0}' "
            lcQuery += "AND A.LCOMMERCIAL = 1 "
            lcQuery = String.Format(lcQuery, pcCompany_ID, pcUser_ID)
            loResult = loDb.SqlExecObjectQuery(Of LAT00100AppComboDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

End Class
