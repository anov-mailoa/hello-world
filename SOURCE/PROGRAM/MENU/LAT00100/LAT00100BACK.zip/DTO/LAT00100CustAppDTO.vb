﻿Public Class LAT00100CustAppDTO
    Public Property CSERVER_UID As String
    Public Property LACTIVE As Boolean
    Public Property NINTERVAL As Integer
    Public Property NGRACE_DAYS As Integer
    Public Property NWARNING_DAYS As Integer
    Public Property CLAST_EXPIRY_DATE As String
End Class
