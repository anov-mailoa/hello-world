﻿Public Class LAT00100ActivationGridDTO

    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CCUSTOMER_CODE As String
    Public Property CGENERATE_TIME As String
    Public Property CSERVER_TYPE As String
    Public Property CSERVER_UID As String
    Public Property CSTART_DATE As String
    Public Property CEXPIRY_DATE As String
    Public Property NGRACE_DAYS As Integer
    Public Property NWARNING_DAYS As Integer
    Public Property CACTIVATION_CODE As String
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)
    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)

End Class
