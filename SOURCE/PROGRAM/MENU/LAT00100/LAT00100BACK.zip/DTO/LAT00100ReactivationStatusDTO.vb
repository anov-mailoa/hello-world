﻿Public Class LAT00100ReactivationStatusDTO
    Public Property CLAST_EXPIRY_DATE As String
    Public Property CCURRENT_EXPIRY_DATE As String
    Public Property CREACTIVATION_STATUS As String
End Class
