﻿Public Class LAT00100KeyDTO

    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CCUSTOMER_CODE As String
    Public Property CGENERATE_TIME As String
    Public Property CSERVER_TYPE As String
    Public Property CUSER_ID As String

End Class
