﻿Imports R_Common
Imports R_BackEnd
Imports System.Data.Common
Imports Real_AutoActivationAgent.LAT00130Ref

Module MainModule

    Sub Main()
        Dim loException As New R_Exception
        Dim loDb As R_Db
        Dim loConn As DbConnection
        Dim loActivations As ActivationConfigCollection
        Dim loActivation As ActivationConfig
        Dim loActivationHelper As New ActivationHelper
        Dim lnActivationMax As Integer
        Dim lcSvcUrl As string

        Dim loSvc As LAT00130ServiceClient
        Dim loCompleteReq As ReactivationCompleteParamDTO
        Dim loCompleteRtn As ReactivationCompleteReturnDTO
        Dim loActivationReq As ReactivationRequestParamDTO
        Dim loActivationRtn As ReactivationRequestReturnDTO

        Dim loLicenseWebDTO As LicenseWebDTO


        Try
            AutoActivationLogger.Log.Info("Start Main")
            'Get Activation URL
            lcSvcUrl = loActivationHelper.GetServiceUrl
            'Get Activation Configuration
            loActivations = loActivationHelper.GetActivations()
            lnActivationMax = loActivations.Count - 1
            For lnIndex = 0 To lnActivationMax
                loActivation = loActivations.ActivationConfigCollection(lnIndex)

                'Instantiate Service
                AutoActivationLogger.Log.Info("Instantiate Service")
                loSvc = New LAT00130ServiceClient("BasicHttpBinding_ILAT00130Service", lcSvcUrl)


                AutoActivationLogger.Log.Info("Request Activation For SProBest " + loActivation.SProBestId.Trim + "App " + loActivation.AppId.Trim + " Customer " + loActivation.CustomerId.Trim)
                'Check Request Activation
                loActivationReq = New ReactivationRequestParamDTO
                With loActivationReq
                    .CCOMPANY_ID = loActivation.SProBestId.Trim
                    .CAPPS_CODE = loActivation.AppId.Trim
                    .CCUSTOMER_CODE = loActivation.CustomerId.Trim
                    .CSERVER_TYPE = loActivation.ServerType.Trim
                End With
                loActivationRtn = loSvc.ReactivationRequest(loActivationReq)
                If loActivationRtn.CRETURN_TYPE = "1" Then
                    'Error
                    loException.Add(loActivationRtn.CRETURN_CODE.Trim, loActivationRtn.CDESCRIPTION.Trim)
                    Exit Try
                End If
                'vfp
                If loActivationRtn.CACTIVATION_TYPE.Trim = "001" Then
                    Select Case loActivationRtn.CRETURN_CODE.Trim
                        Case "400"
                            'Activation Code has not been generated
                            AutoActivationLogger.Log.Error("Request Activation For SProBest " + loActivation.SProBestId.Trim + "App " + loActivation.AppId.Trim + " Customer " + loActivation.CustomerId.Trim + " (" + loActivationRtn.CDESCRIPTION.Trim + ")")
                            Exit Try
                        Case "000"
                            'Success
                            UpdateVFPActivation(loActivation, loActivationRtn)
                            'If Success then request complete
                            loCompleteReq = New ReactivationCompleteParamDTO
                            With loCompleteReq
                                .CCOMPANY_ID = loActivation.SProBestId.Trim
                                .CAPPS_CODE = loActivation.AppId.Trim
                                .CCUSTOMER_CODE = loActivation.CustomerId.Trim
                                .CSERVER_TYPE = loActivation.ServerType.Trim
                            End With
                            loCompleteRtn = loSvc.ReactivationComplete(loCompleteReq)
                            If loCompleteRtn.CRETURN_TYPE = "1" Then
                                'Error
                                loException.Add(loCompleteRtn.CRETURN_CODE.Trim, loCompleteRtn.CDESCRIPTION.Trim)
                                Exit Try
                            End If
                    End Select
                End If
                'Telerik Web
                If loActivationRtn.CACTIVATION_TYPE.Trim = "002" Then
                    Select Case loActivationRtn.CRETURN_CODE.Trim
                        Case "400"
                            'Activation Code has not been generated
                            AutoActivationLogger.Log.Error("Request Activation For SProBest " + loActivation.SProBestId.Trim + "App " + loActivation.AppId.Trim + " Customer " + loActivation.CustomerId.Trim + " (" + loActivationRtn.CDESCRIPTION.Trim + ")")
                            Exit Try
                        Case "000"
                            'Success
                            loLicenseWebDTO = SelectWebLicense(loActivation.ConnectionName.Trim, loActivation.CustomerId.Trim)
                            CheckActivation(loActivation.ConnectionName.Trim, loLicenseWebDTO.CSERVER_UID.Trim, loActivation, loActivationRtn)
                            UpdateWebActivation(loActivation.ConnectionName.Trim, loLicenseWebDTO.CSERVER_UID.Trim, loActivationRtn)
                            Throw New Exception("SENGAJA")
                            'If Success then request complete
                            loCompleteReq = New ReactivationCompleteParamDTO
                            With loCompleteReq
                                .CCOMPANY_ID = loActivation.SProBestId.Trim
                                .CAPPS_CODE = loActivation.AppId.Trim
                                .CCUSTOMER_CODE = loActivation.CustomerId.Trim
                                .CSERVER_TYPE = loActivation.ServerType.Trim
                            End With
                            loCompleteRtn = loSvc.ReactivationComplete(loCompleteReq)
                            If loCompleteRtn.CRETURN_TYPE = "1" Then
                                'Error
                                loException.Add(loCompleteRtn.CRETURN_CODE.Trim, loCompleteRtn.CDESCRIPTION.Trim)
                                Exit Try
                            End If
                    End Select
                End If

            Next




            AutoActivationLogger.Log.Info("Main Success")
        Catch ex As Exception
            loException.Add(ex)
        Finally
            If loSvc IsNot Nothing Then
                If Not (loSvc.State = ServiceModel.CommunicationState.Closed) Then
                    loSvc.Close()
                End If
                loSvc = Nothing
            End If
            If loActivation IsNot Nothing Then
                loActivation = Nothing
            End If
            If loActivations IsNot Nothing Then
                loActivations = Nothing
            End If
            If loActivationHelper IsNot Nothing Then
                loActivationHelper.Dispose()
                loActivationHelper = Nothing
            End If
        End Try

        If loException.Haserror Then
            Try
                AutoActivationLogger.Log.Error("Error Main")
                For Each loError In loException.ErrorList
                    AutoActivationLogger.Log.Error(loError.ErrNo.Trim + " - " + loError.ErrDescp.Trim)
                    If loError.HasErrorDetail Then
                        For Each loErrDt In loError.ErrorDetails
                            AutoActivationLogger.Log.Error(loError.ErrNo.Trim + "(" + loErrDt.ErrNo.Trim + ")" + " - " + loErrDt.ErrDescp.Trim)
                        Next
                    End If
                Next
            Catch ex As Exception
            End Try
        End If
        AutoActivationLogger.Log.Info("End Main")
    End Sub

    Private Sub UpdateVFPActivation(poActivationConfig As ActivationConfig, poActivationRtn As ReactivationRequestReturnDTO)
        Dim lcCmd As String
        Dim loException As New R_Exception
        Const ERR_FILE As String = "File.Err"

        Try
            AutoActivationLogger.Log.Info("Start UpdateVFPActivation")
            lcCmd = poActivationConfig.ActivationPath.Trim + "|" + poActivationConfig.CustomerId.Trim + "|" + poActivationRtn.CSERIAL_NO.Trim + "|" + poActivationRtn.CEXPIRY_DATE.Trim + "|" + poActivationRtn.NGRACE_DAYS.ToString.Trim + "|" + poActivationRtn.NWARNING_DAYS.ToString.Trim
            lcCmd = GetParameter(lcCmd)
            If IO.File.Exists(ERR_FILE) Then
                IO.File.Delete(ERR_FILE)
            End If
            CreateTerm(lcCmd)
            If IO.File.Exists(ERR_FILE) Then
                AutoActivationLogger.Log.Debug("Create CPR Parameter = " + lcCmd)
                loException.Add("ErrCreateTerm-01", "Error Create CPR For SProBest " + poActivationConfig.SProBestId.Trim + "App " + poActivationConfig.AppId.Trim + " Customer " + poActivationConfig.CustomerId.Trim)
                Dim lcError As String
                lcError = IO.File.ReadAllText(ERR_FILE)
                loException.Add("ErrCreateTerm-02", lcError)
                Exit Try
            End If
            AutoActivationLogger.Log.Info("Success UpdateVFPActivation")
        Catch ex As Exception
            AutoActivationLogger.Log.Info("ErrorUpdateVFPActivation")
            loException.Add(ex)
        End Try
        AutoActivationLogger.Log.Info("End UpdateVFPActivation")
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Function GetParameter(lcPar As String) As String
        Dim lcRtn As String = ""
        Dim laRtn As String()

        laRtn = lcPar.Split("|")

        For Each lcStr In laRtn
            lcRtn = lcRtn + """" + lcStr.Trim + """ "
        Next

        Return lcRtn
    End Function

    Private Sub CreateTerm(pcParameter As String)
        Dim startInfo As New ProcessStartInfo
        startInfo.FileName = "r_createterm.exe"
        startInfo.Arguments = pcParameter
        Process.Start(startInfo)
    End Sub



    Private Sub UpdateWebActivation(pcConnectionName As String, pcInstallationKey As String, poActivationRtn As ReactivationRequestReturnDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db
        Dim loException As New R_Exception

        Dim lcCompanyId As String = ""
        Dim lcApplicationId As String = ""
        Dim lcStartDate As String = ""
        Dim lcExpiredDate As String = ""
        Dim lnGraceDays As Integer = 0
        Dim lnWarningDays As Integer = 0
        Dim lcGenerateDate As String = ""
        Dim lnFor As Integer = 0
        Dim loActivationDatas As String()

        Try
            AutoActivationLogger.Log.Info("Start UpdateWebActivation")
            'Decrypt code from activation generator
            loActivationDatas = R_Common.R_Utility.DecryptPbkdf2(poActivationRtn.CACTIVATION_CODE, pcInstallationKey + "R3@lt@R3@ct1v@t10n").Split("|")
            For Each lcActivationData As String In loActivationDatas
                Select Case (lnFor)
                    Case 0
                        lcCompanyId = lcActivationData
                    Case 1
                        lcApplicationId = lcActivationData
                    Case 2
                        lcStartDate = lcActivationData
                    Case 3
                        lcExpiredDate = lcActivationData
                    Case 4
                        lnGraceDays = CInt(lcActivationData)
                    Case 5
                        lnWarningDays = CInt(lcActivationData)
                    Case 6
                        lcGenerateDate = lcActivationData
                End Select
                lnFor = lnFor + 1
            Next


            'UPDATE
            lcQuery = "UPDATE GST_ACTIVATION "
            lcQuery += "SET "
            lcQuery += "CSERVER_UID = '{1}', "
            lcQuery += "CACTIVATION_CODE = '{2}', "
            lcQuery += "CSTART_DATE = Convert(varchar(8), getdate(), 112), "
            lcQuery += "CEXPIRED_DATE = '{3}', "
            lcQuery += "NGRACE_DAYS = {4}, "
            lcQuery += "NWARNING_DAYS = {5}, "
            lcQuery += "CLAST_LOGIN_DATE = '{6}', "
            lcQuery += "CUPDATE_BY = 'SYSTEM', "
            lcQuery += "DUPDATE_DATE = GETDATE(), "
            lcQuery += "CCREATE_BY = 'SYSTEM', "
            lcQuery += "DCREATE_DATE = GETDATE() "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery = String.Format(lcQuery, lcCompanyId.Trim, pcInstallationKey.Trim, poActivationRtn.CACTIVATION_CODE, lcExpiredDate.Trim, lnGraceDays.ToString, lnWarningDays.ToString, R_Common.R_Utility.EncryptPbkdf2(Date.Now().ToString("yyyyMMdd"), pcInstallationKey.Trim + "R3@lt@R3@ct1v@t10nDt"))

            loDb.SqlExecNonQuery(lcQuery, loDb.GetConnection(pcConnectionName), True)
            AutoActivationLogger.Log.Info("Success UpdateWebActivation")
        Catch ex As Exception
            AutoActivationLogger.Log.Info("Error UpdateWebActivation")
            loException.Add(ex)
        Finally
            If loDb IsNot Nothing Then
                loDb = Nothing
            End If
        End Try
        AutoActivationLogger.Log.Info("End UpdateWebActivation")
        loException.ThrowExceptionIfErrors()
    End Sub

    Friend Sub CheckActivation(pcConnectionName As String, pcInstallationKey As String, poActivationConfig As ActivationConfig, poActivationRtn As ReactivationRequestReturnDTO)
        Dim loException As New R_Exception
        Dim loDb As New R_Db
        Dim loConn As DbConnection
        Dim lcCmd As String

        Dim lcCompanyId As String = ""
        Dim lcApplicationId As String = ""
        Dim lcStartDate As String = ""
        Dim lcExpiredDate As String = ""
        Dim lnGraceDays As Integer = 0
        Dim lnWarningDays As Integer = 0
        Dim lcGenerateDate As String = ""
        Dim lnFor As Integer = 0
        Dim loActivationDatas As String()


        Try
            AutoActivationLogger.Log.Info("Start CheckActivation")
            'Get Connection
            loConn = loDb.GetConnection(pcConnectionName)
            'Decrypt code from activation generator
            loActivationDatas = R_Common.R_Utility.DecryptPbkdf2(poActivationRtn.CACTIVATION_CODE, pcInstallationKey + "R3@lt@R3@ct1v@t10n").Split("|")
            If loActivationDatas IsNot Nothing Then
                If loActivationDatas.Count <> 7 Then
                    loException.Add("01", "NC - Invalid activation code parsing count")
                    Exit Try
                End If
            Else
                loException.Add("01", "NC - Invalid activation code encryption")
                Exit Try
            End If
            For Each lcActivationData As String In loActivationDatas
                Select Case (lnFor)
                    Case 0
                        lcCompanyId = lcActivationData
                    Case 1
                        lcApplicationId = lcActivationData
                    Case 2
                        lcStartDate = lcActivationData
                    Case 3
                        lcExpiredDate = lcActivationData
                    Case 4
                        lnGraceDays = CInt(lcActivationData)
                    Case 5
                        lnWarningDays = CInt(lcActivationData)
                    Case 6
                        lcGenerateDate = lcActivationData
                End Select
                lnFor = lnFor + 1
            Next

            If lcApplicationId.Trim.Equals(poActivationConfig.AppId.Trim, StringComparison.InvariantCultureIgnoreCase) = False Then
                loException.Add("02", "AID - Invalid License Code AppId")
                Exit Try
            End If
            AutoActivationLogger.Log.Info("Success CheckActivation")
        Catch ex As Exception
            AutoActivationLogger.Log.Info("Error CheckActivation")
            loException.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try
        AutoActivationLogger.Log.Info("End CheckActivation")

        loException.ThrowExceptionIfErrors()
    End Sub

    Friend Function SelectWebLicense(pcConnectionName As String, ByVal pcCompanyId As String) As LicenseWebDTO
        Dim lcQuery As String
        Dim loDb As New R_Db
        Dim loEx As New R_Exception
        Dim loResult As LicenseWebDTO = Nothing

        Try
            AutoActivationLogger.Log.Info("Start SelectWebLicense")
            lcQuery = "SELECT * "
            lcQuery += "FROM "
            lcQuery += "GST_LICENSE (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery = String.Format(lcQuery, pcCompanyId)

            loResult = loDb.SqlExecObjectQuery(Of LicenseWebDTO)(lcQuery, loDb.GetConnection(pcConnectionName.Trim), True).FirstOrDefault

            If loResult Is Nothing Then
                Throw New Exception("License not found for Company " + pcCompanyId.Trim)
            End If

            AutoActivationLogger.Log.Info("Success SelectWebLicense")
        Catch ex As Exception
            AutoActivationLogger.Log.Info("Error SelectWebLicense")
            loEx.Add(ex)
        Finally
            If loDb IsNot Nothing Then
                loDb = Nothing
            End If
        End Try
        AutoActivationLogger.Log.Info("End SelectWebLicense")

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

End Module
