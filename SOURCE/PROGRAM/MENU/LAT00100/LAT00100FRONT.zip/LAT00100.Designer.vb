﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LAT00100
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn10 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn11 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn12 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDecimalColumn4 As R_FrontEnd.R_GridViewDecimalColumn = New R_FrontEnd.R_GridViewDecimalColumn()
        Dim R_GridViewTextBoxColumn13 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn7 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn14 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn8 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn15 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn16 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn9 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDateTimeColumn10 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewDecimalColumn5 As R_FrontEnd.R_GridViewDecimalColumn = New R_FrontEnd.R_GridViewDecimalColumn()
        Dim R_GridViewDecimalColumn6 As R_FrontEnd.R_GridViewDecimalColumn = New R_FrontEnd.R_GridViewDecimalColumn()
        Dim R_GridViewTextBoxColumn17 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn11 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn18 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn12 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.grpServerType = New R_FrontEnd.R_RadGroupBox(Me.components)
        Me.rdbTraining = New R_FrontEnd.R_RadRadioButton(Me.components)
        Me.rdbLive = New R_FrontEnd.R_RadRadioButton(Me.components)
        Me.rdbTest = New R_FrontEnd.R_RadRadioButton(Me.components)
        Me.cboCustomer = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.txtInstallationID = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.cboApplication = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.lblInstallationId = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblCustomer = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblApplication = New R_FrontEnd.R_RadLabel(Me.components)
        Me.R_RadPageView1 = New R_FrontEnd.R_RadPageView(Me.components)
        Me.pvpLicense = New Telerik.WinControls.UI.RadPageViewPage()
        Me.R_RadPageView2 = New R_FrontEnd.R_RadPageView(Me.components)
        Me.pvpLicenseList = New Telerik.WinControls.UI.RadPageViewPage()
        Me.btnSaveLicense = New R_FrontEnd.R_RadButton(Me.components)
        Me.gvLicense = New R_FrontEnd.R_RadGridView(Me.components)
        Me.pvpGenerateLicense = New Telerik.WinControls.UI.RadPageViewPage()
        Me.btnGenerateLicense = New R_FrontEnd.R_RadButton(Me.components)
        Me.spnLicensee = New R_FrontEnd.R_RadSpinEditor(Me.components)
        Me.lblLicensee = New R_FrontEnd.R_RadLabel(Me.components)
        Me.cboLicenseMode = New R_FrontEnd.R_RadDropDownList(Me.components)
        Me.lblLicenseMode = New R_FrontEnd.R_RadLabel(Me.components)
        Me.pvpActivation = New Telerik.WinControls.UI.RadPageViewPage()
        Me.R_RadPageView3 = New R_FrontEnd.R_RadPageView(Me.components)
        Me.pvpActivationList = New Telerik.WinControls.UI.RadPageViewPage()
        Me.btnSaveActivation = New R_FrontEnd.R_RadButton(Me.components)
        Me.gvActivation = New R_FrontEnd.R_RadGridView(Me.components)
        Me.pvpGenerateActivation = New Telerik.WinControls.UI.RadPageViewPage()
        Me.btnAddPeriod = New R_FrontEnd.R_RadButton(Me.components)
        Me.spnMonth = New R_FrontEnd.R_RadSpinEditor(Me.components)
        Me.spnYear = New R_FrontEnd.R_RadSpinEditor(Me.components)
        Me.lblMonth = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblYear = New R_FrontEnd.R_RadLabel(Me.components)
        Me.btnGenerateActivation = New R_FrontEnd.R_RadButton(Me.components)
        Me.spnWarningDays = New R_FrontEnd.R_RadSpinEditor(Me.components)
        Me.lblWarningDays = New R_FrontEnd.R_RadLabel(Me.components)
        Me.spnGraceDays = New R_FrontEnd.R_RadSpinEditor(Me.components)
        Me.lblGraceDays = New R_FrontEnd.R_RadLabel(Me.components)
        Me.dtpExpiryDate = New R_FrontEnd.R_RadDateTimePicker(Me.components)
        Me.R_RadLabel1 = New R_FrontEnd.R_RadLabel(Me.components)
        Me.dtpStartDate = New R_FrontEnd.R_RadDateTimePicker(Me.components)
        Me.lblActiveDate = New R_FrontEnd.R_RadLabel(Me.components)
        Me.pvpReactivationStatus = New Telerik.WinControls.UI.RadPageViewPage()
        Me.fbdSaveToFile = New System.Windows.Forms.FolderBrowserDialog()
        Me.bsCust = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsApps = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsLicense = New System.Windows.Forms.BindingSource(Me.components)
        Me.bsActivation = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblReactivationStatus = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblCurrentExpiryDate = New R_FrontEnd.R_RadLabel(Me.components)
        Me.lblLastExpiryDate = New R_FrontEnd.R_RadLabel(Me.components)
        Me.dtpLastExpiryDate = New R_FrontEnd.R_RadDateTimePicker(Me.components)
        Me.dtpCurrentExpiryDate = New R_FrontEnd.R_RadDateTimePicker(Me.components)
        Me.txtReactivationStatus = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.R_RadTextBox1 = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.R_RadTextBox2 = New R_FrontEnd.R_RadTextBox(Me.components)
        Me.btnResetReactivationStatus = New R_FrontEnd.R_RadButton(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.grpServerType, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpServerType.SuspendLayout()
        CType(Me.rdbTraining, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.rdbLive, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.rdbTest, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtInstallationID, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblInstallationId, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadPageView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.R_RadPageView1.SuspendLayout()
        Me.pvpLicense.SuspendLayout()
        CType(Me.R_RadPageView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.R_RadPageView2.SuspendLayout()
        Me.pvpLicenseList.SuspendLayout()
        CType(Me.btnSaveLicense, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvLicense, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvLicense.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pvpGenerateLicense.SuspendLayout()
        CType(Me.btnGenerateLicense, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spnLicensee, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblLicensee, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboLicenseMode, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblLicenseMode, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pvpActivation.SuspendLayout()
        CType(Me.R_RadPageView3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.R_RadPageView3.SuspendLayout()
        Me.pvpActivationList.SuspendLayout()
        CType(Me.btnSaveActivation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvActivation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvActivation.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pvpGenerateActivation.SuspendLayout()
        CType(Me.btnAddPeriod, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spnMonth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spnYear, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblMonth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblYear, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnGenerateActivation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spnWarningDays, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblWarningDays, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.spnGraceDays, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblGraceDays, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dtpExpiryDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dtpStartDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblActiveDate, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pvpReactivationStatus.SuspendLayout()
        CType(Me.bsCust, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsLicense, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsActivation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblReactivationStatus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblCurrentExpiryDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblLastExpiryDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dtpLastExpiryDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dtpCurrentExpiryDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtReactivationStatus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadTextBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.R_RadTextBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnResetReactivationStatus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 1277.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.R_RadPageView1, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 150.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 200.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1277, 575)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.grpServerType)
        Me.Panel1.Controls.Add(Me.cboCustomer)
        Me.Panel1.Controls.Add(Me.txtInstallationID)
        Me.Panel1.Controls.Add(Me.cboApplication)
        Me.Panel1.Controls.Add(Me.lblInstallationId)
        Me.Panel1.Controls.Add(Me.lblCustomer)
        Me.Panel1.Controls.Add(Me.lblApplication)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1271, 144)
        Me.Panel1.TabIndex = 1
        '
        'grpServerType
        '
        Me.grpServerType.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping
        Me.grpServerType.Controls.Add(Me.rdbTraining)
        Me.grpServerType.Controls.Add(Me.rdbLive)
        Me.grpServerType.Controls.Add(Me.rdbTest)
        Me.grpServerType.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.grpServerType.HeaderText = "R_RadGroupBox1"
        Me.grpServerType.Location = New System.Drawing.Point(115, 61)
        Me.grpServerType.Name = "grpServerType"
        Me.grpServerType.R_ConductorGridSource = Nothing
        Me.grpServerType.R_ConductorSource = Nothing
        Me.grpServerType.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.grpServerType.R_ResourceId = "grpServerType"
        Me.grpServerType.Size = New System.Drawing.Size(400, 53)
        Me.grpServerType.TabIndex = 11
        Me.grpServerType.Text = "R_RadGroupBox1"
        '
        'rdbTraining
        '
        Me.rdbTraining.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.rdbTraining.Location = New System.Drawing.Point(258, 24)
        Me.rdbTraining.Name = "rdbTraining"
        Me.rdbTraining.R_ConductorGridSource = Nothing
        Me.rdbTraining.R_ConductorSource = Nothing
        Me.rdbTraining.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.rdbTraining.R_ResourceId = "rdbTraining"
        Me.rdbTraining.Size = New System.Drawing.Size(122, 18)
        Me.rdbTraining.TabIndex = 11
        Me.rdbTraining.TabStop = False
        Me.rdbTraining.Text = "R_RadRadioButton1"
        '
        'rdbLive
        '
        Me.rdbLive.CheckState = System.Windows.Forms.CheckState.Checked
        Me.rdbLive.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.rdbLive.Location = New System.Drawing.Point(130, 24)
        Me.rdbLive.Name = "rdbLive"
        Me.rdbLive.R_ConductorGridSource = Nothing
        Me.rdbLive.R_ConductorSource = Nothing
        Me.rdbLive.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.rdbLive.R_ResourceId = "rdbLive"
        Me.rdbLive.Size = New System.Drawing.Size(122, 18)
        Me.rdbLive.TabIndex = 8
        Me.rdbLive.Text = "R_RadRadioButton1"
        Me.rdbLive.ToggleState = Telerik.WinControls.Enumerations.ToggleState.[On]
        '
        'rdbTest
        '
        Me.rdbTest.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.rdbTest.Location = New System.Drawing.Point(5, 24)
        Me.rdbTest.Name = "rdbTest"
        Me.rdbTest.R_ConductorGridSource = Nothing
        Me.rdbTest.R_ConductorSource = Nothing
        Me.rdbTest.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.rdbTest.R_ResourceId = "rdbTest"
        Me.rdbTest.Size = New System.Drawing.Size(122, 18)
        Me.rdbTest.TabIndex = 9
        Me.rdbTest.TabStop = False
        Me.rdbTest.Text = "R_RadRadioButton2"
        '
        'cboCustomer
        '
        Me.cboCustomer.DataSource = Me.bsCust
        Me.cboCustomer.DisplayMember = "CCUSTOMER_NAME"
        Me.cboCustomer.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList
        Me.cboCustomer.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboCustomer.Location = New System.Drawing.Point(115, 35)
        Me.cboCustomer.Name = "cboCustomer"
        Me.cboCustomer.R_ConductorGridSource = Nothing
        Me.cboCustomer.R_ConductorSource = Nothing
        Me.cboCustomer.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboCustomer.Size = New System.Drawing.Size(400, 20)
        Me.cboCustomer.TabIndex = 3
        Me.cboCustomer.Text = "R_RadDropDownList1"
        Me.cboCustomer.ValueMember = "CCUSTOMER_CODE"
        '
        'txtInstallationID
        '
        Me.txtInstallationID.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtInstallationID.Location = New System.Drawing.Point(116, 120)
        Me.txtInstallationID.Name = "txtInstallationID"
        Me.txtInstallationID.R_ConductorGridSource = Nothing
        Me.txtInstallationID.R_ConductorSource = Nothing
        Me.txtInstallationID.R_UDT = Nothing
        Me.txtInstallationID.ReadOnly = True
        Me.txtInstallationID.Size = New System.Drawing.Size(1147, 20)
        Me.txtInstallationID.TabIndex = 3
        Me.txtInstallationID.TabStop = False
        '
        'cboApplication
        '
        Me.cboApplication.DataMember = Nothing
        Me.cboApplication.DataSource = Me.bsApps
        Me.cboApplication.DisplayMember = "CAPPS_NAME"
        Me.cboApplication.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList
        Me.cboApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboApplication.Location = New System.Drawing.Point(115, 9)
        Me.cboApplication.Name = "cboApplication"
        Me.cboApplication.R_ConductorGridSource = Nothing
        Me.cboApplication.R_ConductorSource = Nothing
        Me.cboApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboApplication.Size = New System.Drawing.Size(400, 20)
        Me.cboApplication.TabIndex = 2
        Me.cboApplication.Text = "R_RadDropDownList1"
        Me.cboApplication.ValueMember = "CAPPS_CODE"
        '
        'lblInstallationId
        '
        Me.lblInstallationId.AutoSize = False
        Me.lblInstallationId.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblInstallationId.Location = New System.Drawing.Point(10, 121)
        Me.lblInstallationId.Name = "lblInstallationId"
        Me.lblInstallationId.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblInstallationId.R_ResourceId = "lblInstallationId"
        Me.lblInstallationId.Size = New System.Drawing.Size(100, 18)
        Me.lblInstallationId.TabIndex = 2
        Me.lblInstallationId.Text = "R_RadLabel1"
        '
        'lblCustomer
        '
        Me.lblCustomer.AutoSize = False
        Me.lblCustomer.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCustomer.Location = New System.Drawing.Point(9, 33)
        Me.lblCustomer.Name = "lblCustomer"
        Me.lblCustomer.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCustomer.R_ResourceId = "lblCustomer"
        Me.lblCustomer.Size = New System.Drawing.Size(100, 18)
        Me.lblCustomer.TabIndex = 1
        Me.lblCustomer.Text = "Customer..."
        '
        'lblApplication
        '
        Me.lblApplication.AutoSize = False
        Me.lblApplication.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblApplication.Location = New System.Drawing.Point(9, 9)
        Me.lblApplication.Name = "lblApplication"
        Me.lblApplication.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblApplication.R_ResourceId = "lblApplication"
        Me.lblApplication.Size = New System.Drawing.Size(100, 18)
        Me.lblApplication.TabIndex = 0
        Me.lblApplication.Text = "Application..."
        '
        'R_RadPageView1
        '
        Me.R_RadPageView1.Controls.Add(Me.pvpLicense)
        Me.R_RadPageView1.Controls.Add(Me.pvpActivation)
        Me.R_RadPageView1.DefaultPage = Me.pvpLicense
        Me.R_RadPageView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.R_RadPageView1.Location = New System.Drawing.Point(3, 153)
        Me.R_RadPageView1.Name = "R_RadPageView1"
        Me.R_RadPageView1.R_ConductorGridSource = Nothing
        Me.R_RadPageView1.R_ConductorSource = Nothing
        Me.R_RadPageView1.SelectedPage = Me.pvpActivation
        Me.R_RadPageView1.Size = New System.Drawing.Size(1271, 419)
        Me.R_RadPageView1.TabIndex = 2
        Me.R_RadPageView1.Text = "License"
        '
        'pvpLicense
        '
        Me.pvpLicense.Controls.Add(Me.R_RadPageView2)
        Me.pvpLicense.ItemSize = New System.Drawing.SizeF(111.0!, 24.0!)
        Me.pvpLicense.Location = New System.Drawing.Point(10, 33)
        Me.pvpLicense.Name = "pvpLicense"
        Me.pvpLicense.Size = New System.Drawing.Size(1250, 375)
        Me.pvpLicense.Text = "RadPageViewPage1"
        '
        'R_RadPageView2
        '
        Me.R_RadPageView2.Controls.Add(Me.pvpLicenseList)
        Me.R_RadPageView2.Controls.Add(Me.pvpGenerateLicense)
        Me.R_RadPageView2.DefaultPage = Me.pvpLicenseList
        Me.R_RadPageView2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.R_RadPageView2.Location = New System.Drawing.Point(0, 0)
        Me.R_RadPageView2.Name = "R_RadPageView2"
        Me.R_RadPageView2.R_ConductorGridSource = Nothing
        Me.R_RadPageView2.R_ConductorSource = Nothing
        Me.R_RadPageView2.SelectedPage = Me.pvpGenerateLicense
        Me.R_RadPageView2.Size = New System.Drawing.Size(1250, 375)
        Me.R_RadPageView2.TabIndex = 0
        Me.R_RadPageView2.Text = "R_RadPageView2"
        '
        'pvpLicenseList
        '
        Me.pvpLicenseList.Controls.Add(Me.btnSaveLicense)
        Me.pvpLicenseList.Controls.Add(Me.gvLicense)
        Me.pvpLicenseList.ItemSize = New System.Drawing.SizeF(111.0!, 24.0!)
        Me.pvpLicenseList.Location = New System.Drawing.Point(10, 33)
        Me.pvpLicenseList.Name = "pvpLicenseList"
        Me.pvpLicenseList.Size = New System.Drawing.Size(1229, 331)
        Me.pvpLicenseList.Text = "RadPageViewPage3"
        '
        'btnSaveLicense
        '
        Me.btnSaveLicense.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSaveLicense.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnSaveLicense.Location = New System.Drawing.Point(3, 304)
        Me.btnSaveLicense.Name = "btnSaveLicense"
        Me.btnSaveLicense.R_ConductorGridSource = Nothing
        Me.btnSaveLicense.R_ConductorSource = Nothing
        Me.btnSaveLicense.R_DescriptionId = Nothing
        Me.btnSaveLicense.R_ResourceId = "btnSaveToFile"
        Me.btnSaveLicense.Size = New System.Drawing.Size(110, 24)
        Me.btnSaveLicense.TabIndex = 23
        Me.btnSaveLicense.Text = "R_RadButton1"
        '
        'gvLicense
        '
        Me.gvLicense.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gvLicense.EnableFastScrolling = True
        Me.gvLicense.Location = New System.Drawing.Point(3, 3)
        '
        '
        '
        Me.gvLicense.MasterTemplate.AllowAddNewRow = False
        Me.gvLicense.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn10.FieldName = "_CGENERATE_TIME"
        R_GridViewTextBoxColumn10.HeaderText = "_CGENERATE_TIME"
        R_GridViewTextBoxColumn10.Name = "_CGENERATE_TIME"
        R_GridViewTextBoxColumn10.R_ResourceId = "_CGENERATE_TIME"
        R_GridViewTextBoxColumn10.R_UDT = Nothing
        R_GridViewTextBoxColumn10.Width = 117
        R_GridViewTextBoxColumn11.FieldName = "_CLICENSE_CODE"
        R_GridViewTextBoxColumn11.HeaderText = "_CLICENSE_CODE"
        R_GridViewTextBoxColumn11.Name = "_CLICENSE_CODE"
        R_GridViewTextBoxColumn11.R_ResourceId = "_CLICENSE_CODE"
        R_GridViewTextBoxColumn11.R_UDT = Nothing
        R_GridViewTextBoxColumn11.Width = 109
        R_GridViewTextBoxColumn12.FieldName = "_CLICENSE_MODE"
        R_GridViewTextBoxColumn12.HeaderText = "_CLICENSE_MODE"
        R_GridViewTextBoxColumn12.Name = "_CLICENSE_MODE"
        R_GridViewTextBoxColumn12.R_ResourceId = "_CLICENSE_MODE"
        R_GridViewTextBoxColumn12.R_UDT = Nothing
        R_GridViewTextBoxColumn12.Width = 112
        R_GridViewDecimalColumn4.DataType = GetType(Integer)
        R_GridViewDecimalColumn4.DecimalPlaces = 0
        R_GridViewDecimalColumn4.FieldName = "_NLICENSEE"
        R_GridViewDecimalColumn4.FormatString = "{0:N}"
        R_GridViewDecimalColumn4.HeaderText = "_NLICENSEE"
        R_GridViewDecimalColumn4.Name = "_NLICENSEE"
        R_GridViewDecimalColumn4.R_ResourceId = "_NLICENSEE"
        R_GridViewDecimalColumn4.ThousandsSeparator = True
        R_GridViewDecimalColumn4.Width = 82
        R_GridViewTextBoxColumn13.FieldName = "_CUPDATE_BY"
        R_GridViewTextBoxColumn13.HeaderText = "_CUPDATE_BY"
        R_GridViewTextBoxColumn13.Name = "_CUPDATE_BY"
        R_GridViewTextBoxColumn13.R_ResourceId = "_CUPDATE_BY"
        R_GridViewTextBoxColumn13.R_UDT = Nothing
        R_GridViewTextBoxColumn13.Width = 92
        R_GridViewDateTimeColumn7.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn7.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn7.FieldName = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn7.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn7.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn7.HeaderText = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn7.Name = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn7.R_ResourceId = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn7.Width = 107
        R_GridViewTextBoxColumn14.FieldName = "_CCREATE_BY"
        R_GridViewTextBoxColumn14.HeaderText = "_CCREATE_BY"
        R_GridViewTextBoxColumn14.Name = "_CCREATE_BY"
        R_GridViewTextBoxColumn14.R_ResourceId = "_CCREATE_BY"
        R_GridViewTextBoxColumn14.R_UDT = Nothing
        R_GridViewTextBoxColumn14.Width = 90
        R_GridViewDateTimeColumn8.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn8.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn8.FieldName = "_DCREATE_DATE"
        R_GridViewDateTimeColumn8.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn8.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn8.HeaderText = "_DCREATE_DATE"
        R_GridViewDateTimeColumn8.Name = "_DCREATE_DATE"
        R_GridViewDateTimeColumn8.R_ResourceId = "_DCREATE_DATE"
        R_GridViewDateTimeColumn8.Width = 105
        Me.gvLicense.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn10, R_GridViewTextBoxColumn11, R_GridViewTextBoxColumn12, R_GridViewDecimalColumn4, R_GridViewTextBoxColumn13, R_GridViewDateTimeColumn7, R_GridViewTextBoxColumn14, R_GridViewDateTimeColumn8})
        Me.gvLicense.MasterTemplate.DataSource = Me.bsLicense
        Me.gvLicense.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvLicense.MasterTemplate.EnableFiltering = True
        Me.gvLicense.MasterTemplate.EnableGrouping = False
        Me.gvLicense.MasterTemplate.ShowFilteringRow = False
        Me.gvLicense.MasterTemplate.ShowGroupedColumns = True
        Me.gvLicense.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvLicense.MasterTemplate.ShowRowHeaderColumn = False
        Me.gvLicense.Name = "gvLicense"
        Me.gvLicense.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvLicense.R_ConductorGridSource = Nothing
        Me.gvLicense.R_ConductorSource = Nothing
        Me.gvLicense.R_DataAdded = False
        Me.gvLicense.R_NewRowText = Nothing
        Me.gvLicense.ReadOnly = True
        Me.gvLicense.ShowHeaderCellButtons = True
        Me.gvLicense.Size = New System.Drawing.Size(1223, 294)
        Me.gvLicense.TabIndex = 22
        Me.gvLicense.Text = "R_RadGridView1"
        '
        'pvpGenerateLicense
        '
        Me.pvpGenerateLicense.Controls.Add(Me.btnGenerateLicense)
        Me.pvpGenerateLicense.Controls.Add(Me.spnLicensee)
        Me.pvpGenerateLicense.Controls.Add(Me.lblLicensee)
        Me.pvpGenerateLicense.Controls.Add(Me.cboLicenseMode)
        Me.pvpGenerateLicense.Controls.Add(Me.lblLicenseMode)
        Me.pvpGenerateLicense.ItemSize = New System.Drawing.SizeF(111.0!, 24.0!)
        Me.pvpGenerateLicense.Location = New System.Drawing.Point(10, 33)
        Me.pvpGenerateLicense.Name = "pvpGenerateLicense"
        Me.pvpGenerateLicense.Size = New System.Drawing.Size(1229, 331)
        Me.pvpGenerateLicense.Text = "RadPageViewPage4"
        '
        'btnGenerateLicense
        '
        Me.btnGenerateLicense.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnGenerateLicense.Location = New System.Drawing.Point(3, 70)
        Me.btnGenerateLicense.Name = "btnGenerateLicense"
        Me.btnGenerateLicense.R_ConductorGridSource = Nothing
        Me.btnGenerateLicense.R_ConductorSource = Nothing
        Me.btnGenerateLicense.R_DescriptionId = Nothing
        Me.btnGenerateLicense.R_ResourceId = "btnGenerateLicense"
        Me.btnGenerateLicense.Size = New System.Drawing.Size(162, 24)
        Me.btnGenerateLicense.TabIndex = 33
        Me.btnGenerateLicense.Text = "R_RadButton1"
        '
        'spnLicensee
        '
        Me.spnLicensee.Location = New System.Drawing.Point(114, 44)
        Me.spnLicensee.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.spnLicensee.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.spnLicensee.Name = "spnLicensee"
        Me.spnLicensee.R_ConductorGridSource = Nothing
        Me.spnLicensee.R_ConductorSource = Nothing
        Me.spnLicensee.Size = New System.Drawing.Size(51, 20)
        Me.spnLicensee.TabIndex = 28
        Me.spnLicensee.TabStop = False
        Me.spnLicensee.TextAlignment = System.Windows.Forms.HorizontalAlignment.Right
        Me.spnLicensee.ThousandsSeparator = True
        Me.spnLicensee.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'lblLicensee
        '
        Me.lblLicensee.AutoSize = False
        Me.lblLicensee.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblLicensee.Location = New System.Drawing.Point(8, 45)
        Me.lblLicensee.Name = "lblLicensee"
        Me.lblLicensee.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblLicensee.R_ResourceId = "lblLicensee"
        Me.lblLicensee.Size = New System.Drawing.Size(100, 18)
        Me.lblLicensee.TabIndex = 27
        Me.lblLicensee.Text = "R_RadLabel2"
        '
        'cboLicenseMode
        '
        Me.cboLicenseMode.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cboLicenseMode.DropDownStyle = Telerik.WinControls.RadDropDownStyle.DropDownList
        Me.cboLicenseMode.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.cboLicenseMode.Location = New System.Drawing.Point(114, 18)
        Me.cboLicenseMode.Name = "cboLicenseMode"
        Me.cboLicenseMode.R_ConductorGridSource = Nothing
        Me.cboLicenseMode.R_ConductorSource = Nothing
        Me.cboLicenseMode.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.cboLicenseMode.Size = New System.Drawing.Size(150, 20)
        Me.cboLicenseMode.TabIndex = 26
        '
        'lblLicenseMode
        '
        Me.lblLicenseMode.AutoSize = False
        Me.lblLicenseMode.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblLicenseMode.Location = New System.Drawing.Point(8, 18)
        Me.lblLicenseMode.Name = "lblLicenseMode"
        Me.lblLicenseMode.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblLicenseMode.R_ResourceId = "lblLicenseMode"
        Me.lblLicenseMode.Size = New System.Drawing.Size(100, 18)
        Me.lblLicenseMode.TabIndex = 25
        Me.lblLicenseMode.Text = "R_RadLabel1"
        '
        'pvpActivation
        '
        Me.pvpActivation.Controls.Add(Me.R_RadPageView3)
        Me.pvpActivation.ItemSize = New System.Drawing.SizeF(111.0!, 24.0!)
        Me.pvpActivation.Location = New System.Drawing.Point(10, 33)
        Me.pvpActivation.Name = "pvpActivation"
        Me.pvpActivation.Size = New System.Drawing.Size(1250, 375)
        Me.pvpActivation.Text = "RadPageViewPage2"
        '
        'R_RadPageView3
        '
        Me.R_RadPageView3.Controls.Add(Me.pvpActivationList)
        Me.R_RadPageView3.Controls.Add(Me.pvpGenerateActivation)
        Me.R_RadPageView3.Controls.Add(Me.pvpReactivationStatus)
        Me.R_RadPageView3.DefaultPage = Me.pvpActivationList
        Me.R_RadPageView3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.R_RadPageView3.Location = New System.Drawing.Point(0, 0)
        Me.R_RadPageView3.Name = "R_RadPageView3"
        Me.R_RadPageView3.R_ConductorGridSource = Nothing
        Me.R_RadPageView3.R_ConductorSource = Nothing
        Me.R_RadPageView3.SelectedPage = Me.pvpReactivationStatus
        Me.R_RadPageView3.Size = New System.Drawing.Size(1250, 375)
        Me.R_RadPageView3.TabIndex = 0
        Me.R_RadPageView3.Text = "R_RadPageView3"
        '
        'pvpActivationList
        '
        Me.pvpActivationList.Controls.Add(Me.btnSaveActivation)
        Me.pvpActivationList.Controls.Add(Me.gvActivation)
        Me.pvpActivationList.ItemSize = New System.Drawing.SizeF(115.0!, 28.0!)
        Me.pvpActivationList.Location = New System.Drawing.Point(10, 37)
        Me.pvpActivationList.Name = "pvpActivationList"
        Me.pvpActivationList.Size = New System.Drawing.Size(1229, 327)
        Me.pvpActivationList.Text = "RadPageViewPage5"
        '
        'btnSaveActivation
        '
        Me.btnSaveActivation.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnSaveActivation.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnSaveActivation.Location = New System.Drawing.Point(3, 300)
        Me.btnSaveActivation.Name = "btnSaveActivation"
        Me.btnSaveActivation.R_ConductorGridSource = Nothing
        Me.btnSaveActivation.R_ConductorSource = Nothing
        Me.btnSaveActivation.R_DescriptionId = Nothing
        Me.btnSaveActivation.R_ResourceId = "btnSaveToFile"
        Me.btnSaveActivation.Size = New System.Drawing.Size(110, 24)
        Me.btnSaveActivation.TabIndex = 24
        Me.btnSaveActivation.Text = "R_RadButton1"
        '
        'gvActivation
        '
        Me.gvActivation.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gvActivation.EnableFastScrolling = True
        Me.gvActivation.Location = New System.Drawing.Point(3, 3)
        '
        '
        '
        Me.gvActivation.MasterTemplate.AllowAddNewRow = False
        Me.gvActivation.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn15.FieldName = "_CGENERATE_TIME"
        R_GridViewTextBoxColumn15.HeaderText = "_CGENERATE_TIME"
        R_GridViewTextBoxColumn15.Name = "_CGENERATE_TIME"
        R_GridViewTextBoxColumn15.R_ResourceId = "_CGENERATE_TIME"
        R_GridViewTextBoxColumn15.R_UDT = Nothing
        R_GridViewTextBoxColumn15.Width = 117
        R_GridViewTextBoxColumn16.FieldName = "_CACTIVATION_CODE"
        R_GridViewTextBoxColumn16.HeaderText = "_CACTIVATION_CODE"
        R_GridViewTextBoxColumn16.Name = "_CACTIVATION_CODE"
        R_GridViewTextBoxColumn16.R_ResourceId = "_CACTIVATION_CODE"
        R_GridViewTextBoxColumn16.R_UDT = Nothing
        R_GridViewTextBoxColumn16.Width = 131
        R_GridViewDateTimeColumn9.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn9.FieldName = "_DSTART_DATE"
        R_GridViewDateTimeColumn9.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn9.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn9.HeaderText = "_DSTART_DATE"
        R_GridViewDateTimeColumn9.Name = "_DSTART_DATE"
        R_GridViewDateTimeColumn9.R_ResourceId = "_DSTART_DATE"
        R_GridViewDateTimeColumn9.Width = 98
        R_GridViewDateTimeColumn10.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn10.FieldName = "_DEXPIRY_DATE"
        R_GridViewDateTimeColumn10.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn10.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn10.HeaderText = "_DEXPIRY_DATE"
        R_GridViewDateTimeColumn10.Name = "_DEXPIRY_DATE"
        R_GridViewDateTimeColumn10.R_ResourceId = "_DEXPIRY_DATE"
        R_GridViewDateTimeColumn10.Width = 101
        R_GridViewDecimalColumn5.DataType = GetType(Integer)
        R_GridViewDecimalColumn5.DecimalPlaces = 0
        R_GridViewDecimalColumn5.FieldName = "_NGRACE_DAYS"
        R_GridViewDecimalColumn5.FormatString = "{0:N}"
        R_GridViewDecimalColumn5.HeaderText = "_NGRACE_DAYS"
        R_GridViewDecimalColumn5.Name = "_NGRACE_DAYS"
        R_GridViewDecimalColumn5.R_ResourceId = "_NGRACE_DAYS"
        R_GridViewDecimalColumn5.ThousandsSeparator = True
        R_GridViewDecimalColumn5.Width = 102
        R_GridViewDecimalColumn6.DataType = GetType(Integer)
        R_GridViewDecimalColumn6.DecimalPlaces = 0
        R_GridViewDecimalColumn6.FieldName = "_NWARNING_DAYS"
        R_GridViewDecimalColumn6.FormatString = "{0:N}"
        R_GridViewDecimalColumn6.HeaderText = "_NWARNING_DAYS"
        R_GridViewDecimalColumn6.Name = "_NWARNING_DAYS"
        R_GridViewDecimalColumn6.R_ResourceId = "_NWARNING_DAYS"
        R_GridViewDecimalColumn6.ThousandsSeparator = True
        R_GridViewDecimalColumn6.Width = 120
        R_GridViewTextBoxColumn17.FieldName = "_CUPDATE_BY"
        R_GridViewTextBoxColumn17.HeaderText = "_CUPDATE_BY"
        R_GridViewTextBoxColumn17.Name = "_CUPDATE_BY"
        R_GridViewTextBoxColumn17.R_ResourceId = "_CUPDATE_BY"
        R_GridViewTextBoxColumn17.R_UDT = Nothing
        R_GridViewTextBoxColumn17.Width = 92
        R_GridViewDateTimeColumn11.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn11.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn11.FieldName = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn11.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn11.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn11.HeaderText = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn11.Name = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn11.R_ResourceId = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn11.Width = 107
        R_GridViewTextBoxColumn18.FieldName = "_CCREATE_BY"
        R_GridViewTextBoxColumn18.HeaderText = "_CCREATE_BY"
        R_GridViewTextBoxColumn18.Name = "_CCREATE_BY"
        R_GridViewTextBoxColumn18.R_ResourceId = "_CCREATE_BY"
        R_GridViewTextBoxColumn18.R_UDT = Nothing
        R_GridViewTextBoxColumn18.Width = 90
        R_GridViewDateTimeColumn12.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn12.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn12.FieldName = "_DCREATE_DATE"
        R_GridViewDateTimeColumn12.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn12.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn12.HeaderText = "_DCREATE_DATE"
        R_GridViewDateTimeColumn12.Name = "_DCREATE_DATE"
        R_GridViewDateTimeColumn12.R_ResourceId = "_DCREATE_DATE"
        R_GridViewDateTimeColumn12.Width = 105
        Me.gvActivation.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn15, R_GridViewTextBoxColumn16, R_GridViewDateTimeColumn9, R_GridViewDateTimeColumn10, R_GridViewDecimalColumn5, R_GridViewDecimalColumn6, R_GridViewTextBoxColumn17, R_GridViewDateTimeColumn11, R_GridViewTextBoxColumn18, R_GridViewDateTimeColumn12})
        Me.gvActivation.MasterTemplate.DataSource = Me.bsActivation
        Me.gvActivation.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvActivation.MasterTemplate.EnableFiltering = True
        Me.gvActivation.MasterTemplate.EnableGrouping = False
        Me.gvActivation.MasterTemplate.ShowFilteringRow = False
        Me.gvActivation.MasterTemplate.ShowGroupedColumns = True
        Me.gvActivation.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvActivation.MasterTemplate.ShowRowHeaderColumn = False
        Me.gvActivation.Name = "gvActivation"
        Me.gvActivation.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvActivation.R_ConductorGridSource = Nothing
        Me.gvActivation.R_ConductorSource = Nothing
        Me.gvActivation.R_DataAdded = False
        Me.gvActivation.R_NewRowText = Nothing
        Me.gvActivation.ShowHeaderCellButtons = True
        Me.gvActivation.Size = New System.Drawing.Size(1223, 291)
        Me.gvActivation.TabIndex = 23
        Me.gvActivation.Text = "R_RadGridView2"
        '
        'pvpGenerateActivation
        '
        Me.pvpGenerateActivation.Controls.Add(Me.btnAddPeriod)
        Me.pvpGenerateActivation.Controls.Add(Me.spnMonth)
        Me.pvpGenerateActivation.Controls.Add(Me.spnYear)
        Me.pvpGenerateActivation.Controls.Add(Me.lblMonth)
        Me.pvpGenerateActivation.Controls.Add(Me.lblYear)
        Me.pvpGenerateActivation.Controls.Add(Me.btnGenerateActivation)
        Me.pvpGenerateActivation.Controls.Add(Me.spnWarningDays)
        Me.pvpGenerateActivation.Controls.Add(Me.lblWarningDays)
        Me.pvpGenerateActivation.Controls.Add(Me.spnGraceDays)
        Me.pvpGenerateActivation.Controls.Add(Me.lblGraceDays)
        Me.pvpGenerateActivation.Controls.Add(Me.dtpExpiryDate)
        Me.pvpGenerateActivation.Controls.Add(Me.R_RadLabel1)
        Me.pvpGenerateActivation.Controls.Add(Me.dtpStartDate)
        Me.pvpGenerateActivation.Controls.Add(Me.lblActiveDate)
        Me.pvpGenerateActivation.ItemSize = New System.Drawing.SizeF(115.0!, 28.0!)
        Me.pvpGenerateActivation.Location = New System.Drawing.Point(10, 37)
        Me.pvpGenerateActivation.Name = "pvpGenerateActivation"
        Me.pvpGenerateActivation.Size = New System.Drawing.Size(1229, 327)
        Me.pvpGenerateActivation.Text = "RadPageViewPage6"
        '
        'btnAddPeriod
        '
        Me.btnAddPeriod.Enabled = False
        Me.btnAddPeriod.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnAddPeriod.Location = New System.Drawing.Point(314, 10)
        Me.btnAddPeriod.Name = "btnAddPeriod"
        Me.btnAddPeriod.R_ConductorGridSource = Nothing
        Me.btnAddPeriod.R_ConductorSource = Nothing
        Me.btnAddPeriod.R_DescriptionId = Nothing
        Me.btnAddPeriod.R_ResourceId = "btnAddPeriod"
        Me.btnAddPeriod.Size = New System.Drawing.Size(172, 24)
        Me.btnAddPeriod.TabIndex = 27
        Me.btnAddPeriod.Text = "R_RadButton1"
        Me.btnAddPeriod.Visible = False
        '
        'spnMonth
        '
        Me.spnMonth.Enabled = False
        Me.spnMonth.Location = New System.Drawing.Point(492, 38)
        Me.spnMonth.Maximum = New Decimal(New Integer() {12, 0, 0, 0})
        Me.spnMonth.Name = "spnMonth"
        Me.spnMonth.R_ConductorGridSource = Nothing
        Me.spnMonth.R_ConductorSource = Nothing
        Me.spnMonth.Size = New System.Drawing.Size(51, 20)
        Me.spnMonth.TabIndex = 26
        Me.spnMonth.TabStop = False
        Me.spnMonth.TextAlignment = System.Windows.Forms.HorizontalAlignment.Right
        Me.spnMonth.ThousandsSeparator = True
        Me.spnMonth.Value = New Decimal(New Integer() {1, 0, 0, 0})
        Me.spnMonth.Visible = False
        '
        'spnYear
        '
        Me.spnYear.Enabled = False
        Me.spnYear.Location = New System.Drawing.Point(492, 12)
        Me.spnYear.Name = "spnYear"
        Me.spnYear.R_ConductorGridSource = Nothing
        Me.spnYear.R_ConductorSource = Nothing
        Me.spnYear.Size = New System.Drawing.Size(51, 20)
        Me.spnYear.TabIndex = 25
        Me.spnYear.TabStop = False
        Me.spnYear.TextAlignment = System.Windows.Forms.HorizontalAlignment.Right
        Me.spnYear.ThousandsSeparator = True
        Me.spnYear.Value = New Decimal(New Integer() {1, 0, 0, 0})
        Me.spnYear.Visible = False
        '
        'lblMonth
        '
        Me.lblMonth.AutoSize = False
        Me.lblMonth.Enabled = False
        Me.lblMonth.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblMonth.Location = New System.Drawing.Point(549, 39)
        Me.lblMonth.Name = "lblMonth"
        Me.lblMonth.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblMonth.R_ResourceId = "lblMonth"
        Me.lblMonth.Size = New System.Drawing.Size(75, 18)
        Me.lblMonth.TabIndex = 24
        Me.lblMonth.Text = "R_RadLabel2"
        Me.lblMonth.Visible = False
        '
        'lblYear
        '
        Me.lblYear.AutoSize = False
        Me.lblYear.Enabled = False
        Me.lblYear.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblYear.Location = New System.Drawing.Point(549, 13)
        Me.lblYear.Name = "lblYear"
        Me.lblYear.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblYear.R_ResourceId = "lblYear"
        Me.lblYear.Size = New System.Drawing.Size(75, 18)
        Me.lblYear.TabIndex = 21
        Me.lblYear.Text = "R_RadLabel2"
        Me.lblYear.Visible = False
        '
        'btnGenerateActivation
        '
        Me.btnGenerateActivation.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnGenerateActivation.Location = New System.Drawing.Point(3, 90)
        Me.btnGenerateActivation.Name = "btnGenerateActivation"
        Me.btnGenerateActivation.R_ConductorGridSource = Nothing
        Me.btnGenerateActivation.R_ConductorSource = Nothing
        Me.btnGenerateActivation.R_DescriptionId = Nothing
        Me.btnGenerateActivation.R_ResourceId = "btnGenerateActivation"
        Me.btnGenerateActivation.Size = New System.Drawing.Size(158, 24)
        Me.btnGenerateActivation.TabIndex = 19
        Me.btnGenerateActivation.Text = "R_RadButton1"
        '
        'spnWarningDays
        '
        Me.spnWarningDays.Location = New System.Drawing.Point(110, 64)
        Me.spnWarningDays.Name = "spnWarningDays"
        Me.spnWarningDays.R_ConductorGridSource = Nothing
        Me.spnWarningDays.R_ConductorSource = Nothing
        Me.spnWarningDays.Size = New System.Drawing.Size(51, 20)
        Me.spnWarningDays.TabIndex = 18
        Me.spnWarningDays.TabStop = False
        Me.spnWarningDays.TextAlignment = System.Windows.Forms.HorizontalAlignment.Right
        Me.spnWarningDays.ThousandsSeparator = True
        '
        'lblWarningDays
        '
        Me.lblWarningDays.AutoSize = False
        Me.lblWarningDays.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblWarningDays.Location = New System.Drawing.Point(3, 65)
        Me.lblWarningDays.Name = "lblWarningDays"
        Me.lblWarningDays.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblWarningDays.R_ResourceId = "lblWarningDays"
        Me.lblWarningDays.Size = New System.Drawing.Size(100, 18)
        Me.lblWarningDays.TabIndex = 17
        Me.lblWarningDays.Text = "R_RadLabel2"
        '
        'spnGraceDays
        '
        Me.spnGraceDays.Location = New System.Drawing.Point(110, 38)
        Me.spnGraceDays.Maximum = New Decimal(New Integer() {500, 0, 0, 0})
        Me.spnGraceDays.Name = "spnGraceDays"
        Me.spnGraceDays.R_ConductorGridSource = Nothing
        Me.spnGraceDays.R_ConductorSource = Nothing
        Me.spnGraceDays.Size = New System.Drawing.Size(51, 20)
        Me.spnGraceDays.TabIndex = 16
        Me.spnGraceDays.TabStop = False
        Me.spnGraceDays.TextAlignment = System.Windows.Forms.HorizontalAlignment.Right
        Me.spnGraceDays.ThousandsSeparator = True
        '
        'lblGraceDays
        '
        Me.lblGraceDays.AutoSize = False
        Me.lblGraceDays.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblGraceDays.Location = New System.Drawing.Point(3, 39)
        Me.lblGraceDays.Name = "lblGraceDays"
        Me.lblGraceDays.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblGraceDays.R_ResourceId = "lblGraceDays"
        Me.lblGraceDays.Size = New System.Drawing.Size(100, 18)
        Me.lblGraceDays.TabIndex = 15
        Me.lblGraceDays.Text = "R_RadLabel2"
        '
        'dtpExpiryDate
        '
        Me.dtpExpiryDate.Location = New System.Drawing.Point(220, 12)
        Me.dtpExpiryDate.Name = "dtpExpiryDate"
        Me.dtpExpiryDate.R_ConductorGridSource = Nothing
        Me.dtpExpiryDate.R_ConductorSource = Nothing
        Me.dtpExpiryDate.Size = New System.Drawing.Size(88, 20)
        Me.dtpExpiryDate.TabIndex = 14
        Me.dtpExpiryDate.TabStop = False
        Me.dtpExpiryDate.Text = "10/7/2015"
        Me.dtpExpiryDate.Value = New Date(2015, 10, 7, 10, 9, 52, 549)
        '
        'R_RadLabel1
        '
        Me.R_RadLabel1.AutoSize = False
        Me.R_RadLabel1.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.R_RadLabel1.Location = New System.Drawing.Point(204, 13)
        Me.R_RadLabel1.Name = "R_RadLabel1"
        Me.R_RadLabel1.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.R_RadLabel1.R_ResourceId = ""
        Me.R_RadLabel1.Size = New System.Drawing.Size(10, 18)
        Me.R_RadLabel1.TabIndex = 13
        Me.R_RadLabel1.Text = "-"
        '
        'dtpStartDate
        '
        Me.dtpStartDate.Location = New System.Drawing.Point(110, 12)
        Me.dtpStartDate.Name = "dtpStartDate"
        Me.dtpStartDate.R_ConductorGridSource = Nothing
        Me.dtpStartDate.R_ConductorSource = Nothing
        Me.dtpStartDate.Size = New System.Drawing.Size(88, 20)
        Me.dtpStartDate.TabIndex = 12
        Me.dtpStartDate.TabStop = False
        Me.dtpStartDate.Text = "10/7/2015"
        Me.dtpStartDate.Value = New Date(2015, 10, 7, 10, 9, 52, 549)
        '
        'lblActiveDate
        '
        Me.lblActiveDate.AutoSize = False
        Me.lblActiveDate.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblActiveDate.Location = New System.Drawing.Point(3, 13)
        Me.lblActiveDate.Name = "lblActiveDate"
        Me.lblActiveDate.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblActiveDate.R_ResourceId = "lblActiveDate"
        Me.lblActiveDate.Size = New System.Drawing.Size(100, 18)
        Me.lblActiveDate.TabIndex = 11
        Me.lblActiveDate.Text = "R_RadLabel2"
        '
        'pvpReactivationStatus
        '
        Me.pvpReactivationStatus.Controls.Add(Me.btnResetReactivationStatus)
        Me.pvpReactivationStatus.Controls.Add(Me.dtpCurrentExpiryDate)
        Me.pvpReactivationStatus.Controls.Add(Me.R_RadTextBox1)
        Me.pvpReactivationStatus.Controls.Add(Me.txtReactivationStatus)
        Me.pvpReactivationStatus.Controls.Add(Me.dtpLastExpiryDate)
        Me.pvpReactivationStatus.Controls.Add(Me.lblReactivationStatus)
        Me.pvpReactivationStatus.Controls.Add(Me.lblCurrentExpiryDate)
        Me.pvpReactivationStatus.Controls.Add(Me.lblLastExpiryDate)
        Me.pvpReactivationStatus.Controls.Add(Me.R_RadTextBox2)
        Me.pvpReactivationStatus.ItemSize = New System.Drawing.SizeF(115.0!, 28.0!)
        Me.pvpReactivationStatus.Location = New System.Drawing.Point(10, 37)
        Me.pvpReactivationStatus.Name = "pvpReactivationStatus"
        Me.pvpReactivationStatus.Size = New System.Drawing.Size(1229, 327)
        Me.pvpReactivationStatus.Text = "RadPageViewPage1"
        '
        'bsCust
        '
        Me.bsCust.DataSource = GetType(LAT00100Front.LAT00100ServiceRef.RLicenseCustComboDTO)
        '
        'bsApps
        '
        Me.bsApps.DataSource = GetType(LAT00100Front.LAT00100ServiceRef.LAT00100AppComboDTO)
        '
        'bsLicense
        '
        Me.bsLicense.DataSource = GetType(LAT00100Front.LAT00100ServiceRef.LAT00100LicenseDTO)
        '
        'bsActivation
        '
        Me.bsActivation.DataSource = GetType(LAT00100Front.LAT00100ServiceRef.LAT00100ActivationDTO)
        '
        'lblReactivationStatus
        '
        Me.lblReactivationStatus.AutoSize = False
        Me.lblReactivationStatus.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblReactivationStatus.Location = New System.Drawing.Point(3, 55)
        Me.lblReactivationStatus.Name = "lblReactivationStatus"
        Me.lblReactivationStatus.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblReactivationStatus.R_ResourceId = "lblReactivationStatus"
        Me.lblReactivationStatus.Size = New System.Drawing.Size(125, 18)
        Me.lblReactivationStatus.TabIndex = 20
        Me.lblReactivationStatus.Text = "R_RadLabel2"
        '
        'lblCurrentExpiryDate
        '
        Me.lblCurrentExpiryDate.AutoSize = False
        Me.lblCurrentExpiryDate.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblCurrentExpiryDate.Location = New System.Drawing.Point(3, 29)
        Me.lblCurrentExpiryDate.Name = "lblCurrentExpiryDate"
        Me.lblCurrentExpiryDate.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblCurrentExpiryDate.R_ResourceId = "lblCurrentExpiryDate"
        Me.lblCurrentExpiryDate.Size = New System.Drawing.Size(125, 18)
        Me.lblCurrentExpiryDate.TabIndex = 19
        Me.lblCurrentExpiryDate.Text = "R_RadLabel2"
        '
        'lblLastExpiryDate
        '
        Me.lblLastExpiryDate.AutoSize = False
        Me.lblLastExpiryDate.Font = New System.Drawing.Font("Calibri", 9.0!)
        Me.lblLastExpiryDate.Location = New System.Drawing.Point(3, 3)
        Me.lblLastExpiryDate.Name = "lblLastExpiryDate"
        Me.lblLastExpiryDate.R_FontType = R_FrontEnd.R_FontTypeEnumeration.eFontType.Reguler
        Me.lblLastExpiryDate.R_ResourceId = "lblLastExpiryDate"
        Me.lblLastExpiryDate.Size = New System.Drawing.Size(125, 18)
        Me.lblLastExpiryDate.TabIndex = 18
        Me.lblLastExpiryDate.Text = "R_RadLabel2"
        '
        'dtpLastExpiryDate
        '
        Me.dtpLastExpiryDate.Enabled = False
        Me.dtpLastExpiryDate.Location = New System.Drawing.Point(134, 2)
        Me.dtpLastExpiryDate.Name = "dtpLastExpiryDate"
        Me.dtpLastExpiryDate.R_ConductorGridSource = Nothing
        Me.dtpLastExpiryDate.R_ConductorSource = Nothing
        Me.dtpLastExpiryDate.ReadOnly = True
        Me.dtpLastExpiryDate.Size = New System.Drawing.Size(96, 20)
        Me.dtpLastExpiryDate.TabIndex = 21
        Me.dtpLastExpiryDate.TabStop = False
        Me.dtpLastExpiryDate.Text = "10/7/2015"
        Me.dtpLastExpiryDate.Value = New Date(2015, 10, 7, 10, 9, 52, 549)
        '
        'dtpCurrentExpiryDate
        '
        Me.dtpCurrentExpiryDate.Enabled = False
        Me.dtpCurrentExpiryDate.Location = New System.Drawing.Point(134, 29)
        Me.dtpCurrentExpiryDate.Name = "dtpCurrentExpiryDate"
        Me.dtpCurrentExpiryDate.R_ConductorGridSource = Nothing
        Me.dtpCurrentExpiryDate.R_ConductorSource = Nothing
        Me.dtpCurrentExpiryDate.ReadOnly = True
        Me.dtpCurrentExpiryDate.Size = New System.Drawing.Size(96, 20)
        Me.dtpCurrentExpiryDate.TabIndex = 22
        Me.dtpCurrentExpiryDate.TabStop = False
        Me.dtpCurrentExpiryDate.Text = "10/7/2015"
        Me.dtpCurrentExpiryDate.Value = New Date(2015, 10, 7, 10, 9, 52, 549)
        '
        'txtReactivationStatus
        '
        Me.txtReactivationStatus.Location = New System.Drawing.Point(134, 54)
        Me.txtReactivationStatus.Name = "txtReactivationStatus"
        Me.txtReactivationStatus.R_ConductorGridSource = Nothing
        Me.txtReactivationStatus.R_ConductorSource = Nothing
        Me.txtReactivationStatus.R_UDT = Nothing
        Me.txtReactivationStatus.ReadOnly = True
        Me.txtReactivationStatus.Size = New System.Drawing.Size(96, 20)
        Me.txtReactivationStatus.TabIndex = 23
        Me.txtReactivationStatus.TabStop = False
        '
        'R_RadTextBox1
        '
        Me.R_RadTextBox1.Location = New System.Drawing.Point(134, 29)
        Me.R_RadTextBox1.Name = "R_RadTextBox1"
        Me.R_RadTextBox1.R_ConductorGridSource = Nothing
        Me.R_RadTextBox1.R_ConductorSource = Nothing
        Me.R_RadTextBox1.R_UDT = Nothing
        Me.R_RadTextBox1.ReadOnly = True
        Me.R_RadTextBox1.Size = New System.Drawing.Size(96, 20)
        Me.R_RadTextBox1.TabIndex = 24
        Me.R_RadTextBox1.TabStop = False
        '
        'R_RadTextBox2
        '
        Me.R_RadTextBox2.Location = New System.Drawing.Point(134, 2)
        Me.R_RadTextBox2.Name = "R_RadTextBox2"
        Me.R_RadTextBox2.R_ConductorGridSource = Nothing
        Me.R_RadTextBox2.R_ConductorSource = Nothing
        Me.R_RadTextBox2.R_UDT = Nothing
        Me.R_RadTextBox2.ReadOnly = True
        Me.R_RadTextBox2.Size = New System.Drawing.Size(96, 20)
        Me.R_RadTextBox2.TabIndex = 24
        Me.R_RadTextBox2.TabStop = False
        '
        'btnResetReactivationStatus
        '
        Me.btnResetReactivationStatus.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnResetReactivationStatus.Location = New System.Drawing.Point(3, 80)
        Me.btnResetReactivationStatus.Name = "btnResetReactivationStatus"
        Me.btnResetReactivationStatus.R_ConductorGridSource = Nothing
        Me.btnResetReactivationStatus.R_ConductorSource = Nothing
        Me.btnResetReactivationStatus.R_DescriptionId = Nothing
        Me.btnResetReactivationStatus.R_ResourceId = "btnResetReactivationStatus"
        Me.btnResetReactivationStatus.Size = New System.Drawing.Size(158, 24)
        Me.btnResetReactivationStatus.TabIndex = 25
        Me.btnResetReactivationStatus.Text = "R_RadButton1"
        '
        'LAT00100
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "LAT00100"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.grpServerType, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpServerType.ResumeLayout(False)
        Me.grpServerType.PerformLayout()
        CType(Me.rdbTraining, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.rdbLive, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.rdbTest, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtInstallationID, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblInstallationId, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblApplication, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadPageView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.R_RadPageView1.ResumeLayout(False)
        Me.pvpLicense.ResumeLayout(False)
        CType(Me.R_RadPageView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.R_RadPageView2.ResumeLayout(False)
        Me.pvpLicenseList.ResumeLayout(False)
        CType(Me.btnSaveLicense, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvLicense.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvLicense, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pvpGenerateLicense.ResumeLayout(False)
        Me.pvpGenerateLicense.PerformLayout()
        CType(Me.btnGenerateLicense, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spnLicensee, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblLicensee, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboLicenseMode, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblLicenseMode, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pvpActivation.ResumeLayout(False)
        CType(Me.R_RadPageView3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.R_RadPageView3.ResumeLayout(False)
        Me.pvpActivationList.ResumeLayout(False)
        CType(Me.btnSaveActivation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvActivation.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvActivation, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pvpGenerateActivation.ResumeLayout(False)
        Me.pvpGenerateActivation.PerformLayout()
        CType(Me.btnAddPeriod, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spnMonth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spnYear, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblMonth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblYear, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnGenerateActivation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spnWarningDays, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblWarningDays, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.spnGraceDays, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblGraceDays, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dtpExpiryDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadLabel1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dtpStartDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblActiveDate, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pvpReactivationStatus.ResumeLayout(False)
        Me.pvpReactivationStatus.PerformLayout()
        CType(Me.bsCust, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsApps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsLicense, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsActivation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblReactivationStatus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblCurrentExpiryDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblLastExpiryDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dtpLastExpiryDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dtpCurrentExpiryDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtReactivationStatus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadTextBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.R_RadTextBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnResetReactivationStatus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents cboCustomer As R_FrontEnd.R_RadDropDownList
    Friend WithEvents cboApplication As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblCustomer As R_FrontEnd.R_RadLabel
    Friend WithEvents lblApplication As R_FrontEnd.R_RadLabel
    Friend WithEvents bsApps As System.Windows.Forms.BindingSource
    Friend WithEvents bsCust As System.Windows.Forms.BindingSource
    Friend WithEvents lblInstallationId As R_FrontEnd.R_RadLabel
    Friend WithEvents txtInstallationID As R_FrontEnd.R_RadTextBox
    Friend WithEvents bsLicense As System.Windows.Forms.BindingSource
    Friend WithEvents bsActivation As System.Windows.Forms.BindingSource
    Friend WithEvents fbdSaveToFile As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents grpServerType As R_FrontEnd.R_RadGroupBox
    Friend WithEvents rdbLive As R_FrontEnd.R_RadRadioButton
    Friend WithEvents rdbTest As R_FrontEnd.R_RadRadioButton
    Friend WithEvents R_RadPageView1 As R_FrontEnd.R_RadPageView
    Friend WithEvents pvpLicense As Telerik.WinControls.UI.RadPageViewPage
    Friend WithEvents R_RadPageView2 As R_FrontEnd.R_RadPageView
    Friend WithEvents pvpLicenseList As Telerik.WinControls.UI.RadPageViewPage
    Friend WithEvents pvpGenerateLicense As Telerik.WinControls.UI.RadPageViewPage
    Friend WithEvents pvpActivation As Telerik.WinControls.UI.RadPageViewPage
    Friend WithEvents R_RadPageView3 As R_FrontEnd.R_RadPageView
    Friend WithEvents pvpActivationList As Telerik.WinControls.UI.RadPageViewPage
    Friend WithEvents pvpGenerateActivation As Telerik.WinControls.UI.RadPageViewPage
    Friend WithEvents btnSaveLicense As R_FrontEnd.R_RadButton
    Friend WithEvents gvLicense As R_FrontEnd.R_RadGridView
    Friend WithEvents btnGenerateLicense As R_FrontEnd.R_RadButton
    Friend WithEvents spnLicensee As R_FrontEnd.R_RadSpinEditor
    Friend WithEvents lblLicensee As R_FrontEnd.R_RadLabel
    Friend WithEvents cboLicenseMode As R_FrontEnd.R_RadDropDownList
    Friend WithEvents lblLicenseMode As R_FrontEnd.R_RadLabel
    Friend WithEvents btnSaveActivation As R_FrontEnd.R_RadButton
    Friend WithEvents gvActivation As R_FrontEnd.R_RadGridView
    Friend WithEvents btnGenerateActivation As R_FrontEnd.R_RadButton
    Friend WithEvents spnWarningDays As R_FrontEnd.R_RadSpinEditor
    Friend WithEvents lblWarningDays As R_FrontEnd.R_RadLabel
    Friend WithEvents spnGraceDays As R_FrontEnd.R_RadSpinEditor
    Friend WithEvents lblGraceDays As R_FrontEnd.R_RadLabel
    Friend WithEvents dtpExpiryDate As R_FrontEnd.R_RadDateTimePicker
    Friend WithEvents R_RadLabel1 As R_FrontEnd.R_RadLabel
    Friend WithEvents dtpStartDate As R_FrontEnd.R_RadDateTimePicker
    Friend WithEvents lblActiveDate As R_FrontEnd.R_RadLabel
    Friend WithEvents lblMonth As R_FrontEnd.R_RadLabel
    Friend WithEvents lblYear As R_FrontEnd.R_RadLabel
    Friend WithEvents btnAddPeriod As R_FrontEnd.R_RadButton
    Friend WithEvents spnMonth As R_FrontEnd.R_RadSpinEditor
    Friend WithEvents spnYear As R_FrontEnd.R_RadSpinEditor
    Friend WithEvents rdbTraining As R_FrontEnd.R_RadRadioButton
    Friend WithEvents pvpReactivationStatus As Telerik.WinControls.UI.RadPageViewPage
    Friend WithEvents txtReactivationStatus As R_FrontEnd.R_RadTextBox
    Friend WithEvents dtpCurrentExpiryDate As R_FrontEnd.R_RadDateTimePicker
    Friend WithEvents dtpLastExpiryDate As R_FrontEnd.R_RadDateTimePicker
    Friend WithEvents lblReactivationStatus As R_FrontEnd.R_RadLabel
    Friend WithEvents lblCurrentExpiryDate As R_FrontEnd.R_RadLabel
    Friend WithEvents lblLastExpiryDate As R_FrontEnd.R_RadLabel
    Friend WithEvents R_RadTextBox1 As R_FrontEnd.R_RadTextBox
    Friend WithEvents R_RadTextBox2 As R_FrontEnd.R_RadTextBox
    Friend WithEvents btnResetReactivationStatus As R_FrontEnd.R_RadButton

End Class
