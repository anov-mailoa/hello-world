﻿Imports R_FrontEnd
Imports LAT00100Front.LAT00100ServiceRef
Imports LAT00100Front.LAT00100StreamingServiceRef
Imports R_Common
Imports System.ServiceModel.Channels
Imports ClientHelper
Imports LAT00100FrontResources
Imports RCustDBFrontHelper.General
Imports System.IO

Public Class LAT00100

#Region " VARIABLE "
    Dim C_ServiceName As String = "LAT00100Service/LAT00100Service.svc"
    Dim C_ServiceNameStream As String = "LAT00100Service/LAT00100StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim llInitialized As Boolean = False
    Dim _curLicenseDTO As New LAT00100LicenseDTO
    Dim _curActivationDTO As New LAT00100ActivationDTO
    Dim _CSERVER_UID As String = ""
    Dim _LACTIVE As Boolean
    Dim _NINTERVAL As Integer = 1
    Dim _NGRACE_DAYS As Integer = 0
    Dim _NWARNING_DAYS As Integer = 0
    Dim _CLAST_EXPIRY_DATE As String
    Dim _CACTIVATION_TYPE As String
#End Region

#Region " F O R M "

    Private Sub LAT00100_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loSvc As LAT00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00100Service, LAT00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loAppCombo As New List(Of LAT00100AppComboDTO)
        Dim loCustCombo As New List(Of RLicenseCustComboDTO)
        Dim loLicenseMode As New List(Of String)

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId

            ' Application
            loAppCombo = loSvc.GetAppCombo(_CCOMPID, _CUSERID)
            If loAppCombo.Count <= 0 Then
                cboApplication.Items.Clear()
                loEx.Add("LAT00100_06", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "LAT00100_06"))
                Exit Try
            End If
            bsApps.DataSource = loAppCombo
            _CACTIVATION_TYPE = CType(bsApps.Current, LAT00100AppComboDTO).CACTIVATION_TYPE

            ' Customer
            loCustCombo = loSvc.GetCustCombo(_CCOMPID)
            If loCustCombo.Count <= 0 Then
                cboCustomer.Items.Clear()
                loEx.Add("LAT00100_05", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "LAT00100_05"))
                Exit Try
            End If
            bsCust.DataSource = loCustCombo

            ' License Mode
            loLicenseMode = loSvc.GetLicenseMode(_CCOMPID)
            'loLicenseMode = loSvc.GetLicenseMode()
            cboLicenseMode.DataSource = loLicenseMode

            ' Active Date
            dtpStartDate.Value = Now.AddDays((Now.Day - 1) * -1)
            dtpExpiryDate.Value = dtpStartDate.Value.AddMonths(1).AddDays(-1)

            ' PageView
            pvpLicense.Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "lblLicenseTitle")
            pvpLicenseList.Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "lblList")
            pvpGenerateLicense.Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "lblGenerate")
            pvpActivation.Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "lblActivationTitle")
            pvpActivationList.Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "lblList")
            pvpGenerateActivation.Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "lblGenerate")
            pvpReactivationStatus.Text = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "lblReactivationStatus")

            llInitialized = True
            RefreshGrids()
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        If loEx.Haserror Then
            btnGenerateLicense.Enabled = False
            btnGenerateActivation.Enabled = False
            btnSaveLicense.Enabled = False
            btnSaveActivation.Enabled = False
        End If
        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " LICENSE Grid "

    Private Sub gvLicense_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvLicense.DataBindingComplete
        gvLicense.BestFitColumns()
    End Sub

    Private Sub gvLicense_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvLicense.R_Display
        If poEntity IsNot Nothing Then
            With CType(poEntity, LAT00100LicenseDTO)
                _curLicenseDTO = poEntity
            End With
        End If
    End Sub

    Private Sub gvLicense_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvLicense.R_ServiceGetListRecord
        Dim loServiceStream As LAT00100StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00100StreamingService, LAT00100StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of LAT00100LicenseGridDTO)
        Dim loListEntity As New List(Of LAT00100LicenseDTO)

        Try
            With poEntity
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cCustomerCode", .CCUSTOMER_CODE)
                R_Utility.R_SetStreamingContext("cServerType", .CSERVER_TYPE)
            End With

            loRtn = loServiceStream.GetLicenseData()
            loStreaming = R_StreamUtility(Of LAT00100LicenseGridDTO).ReadFromMessage(loRtn)

            For Each loDto As LAT00100LicenseGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New LAT00100LicenseDTO With {._CAPPS_CODE = loDto.CAPPS_CODE,
                                                                  ._CCUSTOMER_CODE = loDto.CCUSTOMER_CODE,
                                                                  ._CGENERATE_TIME = loDto.CGENERATE_TIME,
                                                                  ._CLICENSE_MODE = loDto.CLICENSE_MODE,
                                                                  ._CLICENSE_CODE = loDto.CLICENSE_CODE,
                                                                  ._NLICENSEE = loDto.NLICENSEE,
                                                                  ._CCREATE_BY = loDto.CCREATE_BY,
                                                                  ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                                  ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                                  ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity

        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " ACTIVATION Grid "

    Private Sub gvActivation_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvActivation.DataBindingComplete
        gvActivation.BestFitColumns()
    End Sub

    Private Sub gvActivation_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvActivation.R_Display
        If poEntity IsNot Nothing Then
            With CType(poEntity, LAT00100ActivationDTO)
                _curActivationDTO = poEntity
            End With
        End If

    End Sub

    Private Sub gvActivation_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvActivation.R_ServiceGetListRecord
        Dim loServiceStream As LAT00100StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00100StreamingService, LAT00100StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of LAT00100ActivationGridDTO)
        Dim loListEntity As New List(Of LAT00100ActivationDTO)

        Try
            With poEntity
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)
                R_Utility.R_SetStreamingContext("cAppsCode", .CAPPS_CODE)
                R_Utility.R_SetStreamingContext("cCustomerCode", .CCUSTOMER_CODE)
                R_Utility.R_SetStreamingContext("cServerType", .CSERVER_TYPE)
            End With

            loRtn = loServiceStream.GetActivationData()
            loStreaming = R_StreamUtility(Of LAT00100ActivationGridDTO).ReadFromMessage(loRtn)

            For Each loDto As LAT00100ActivationGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New LAT00100ActivationDTO With {._CAPPS_CODE = loDto.CAPPS_CODE,
                                                                     ._CCUSTOMER_CODE = loDto.CCUSTOMER_CODE,
                                                                     ._CGENERATE_TIME = loDto.CGENERATE_TIME,
                                                                     ._CACTIVATION_CODE = loDto.CACTIVATION_CODE,
                                                                     ._CSTART_DATE = loDto.CSTART_DATE,
                                                                     ._CEXPIRY_DATE = loDto.CEXPIRY_DATE,
                                                                     ._DSTART_DATE = StrToDate(loDto.CSTART_DATE),
                                                                     ._DEXPIRY_DATE = StrToDate(loDto.CEXPIRY_DATE),
                                                                     ._NGRACE_DAYS = loDto.NGRACE_DAYS,
                                                                     ._NWARNING_DAYS = loDto.NWARNING_DAYS,
                                                                     ._CCREATE_BY = loDto.CCREATE_BY,
                                                                     ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                                     ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                                     ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity

        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " SUBs and FUNCTIONs "

    Private Sub ShowSaveDialog(pcFilename As String, pcFileContent As String)
        Dim loFile As System.IO.StreamWriter

        fbdSaveToFile.RootFolder = Environment.SpecialFolder.MyComputer
        fbdSaveToFile.Description = "Save file " & pcFilename.Trim & " to folder below..."
        If fbdSaveToFile.ShowDialog = Windows.Forms.DialogResult.OK Then
            loFile = My.Computer.FileSystem.OpenTextFileWriter(fbdSaveToFile.SelectedPath.Trim & _
                        IIf(fbdSaveToFile.SelectedPath.EndsWith("\"), "", "\") & pcFilename, True)
            loFile.WriteLine(pcFileContent)
            loFile.Close()
        End If

    End Sub

    Private Sub RefreshCustomerCombo()
        Dim lnComboIndex As Integer = 0
        Dim loSvc As LAT00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00100Service, LAT00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loCustCombo As New List(Of RLicenseCustComboDTO)

        If cboCustomer.SelectedIndex >= 0 Then
            llInitialized = False
            lnComboIndex = cboCustomer.SelectedIndex
            loCustCombo = loSvc.GetCustCombo(_CCOMPID)
            bsCust.DataSource = loCustCombo
            cboCustomer.Rebind()
            cboCustomer.SelectedIndex = lnComboIndex
            llInitialized = True
        End If
    End Sub

    Private Sub RefreshGrids()
        Dim loTableKey As New LAT00100KeyDTO
        Dim loSvc As LAT00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00100Service, LAT00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loCustApp As LAT00100CustAppDTO
        Dim loReactivationStatus As LAT00100ReactivationStatusDTO

        With loTableKey
            .CCOMPANY_ID = _CCOMPID
            .CAPPS_CODE = cboApplication.SelectedValue.Trim
            .CCUSTOMER_CODE = cboCustomer.SelectedValue.Trim
            .CSERVER_TYPE = IIf(rdbLive.IsChecked, "1", IIf(rdbTraining.IsChecked, "2", "0"))
        End With

        gvLicense.R_RefreshGrid(loTableKey)
        gvActivation.R_RefreshGrid(loTableKey)
        ' initiate input objects
        loCustApp = loSvc.GetCustAppSetting(loTableKey)
        If loCustApp IsNot Nothing Then
            With loCustApp
                _CSERVER_UID = .CSERVER_UID
                _LACTIVE = .LACTIVE
                _NINTERVAL = .NINTERVAL
                _NGRACE_DAYS = .NGRACE_DAYS
                _NWARNING_DAYS = .NWARNING_DAYS
                _CLAST_EXPIRY_DATE = .CLAST_EXPIRY_DATE
            End With
            If _CLAST_EXPIRY_DATE.Trim.Equals("") Then
                _CLAST_EXPIRY_DATE = Today.ToString("yyyyMMdd")
            End If
        Else
            _CSERVER_UID = ""
            _LACTIVE = False
            _NINTERVAL = 1
            _NGRACE_DAYS = 0
            _NWARNING_DAYS = 0
            _CLAST_EXPIRY_DATE = Today.ToString("yyyyMMdd")
        End If
        ' Reactivation Status
        loReactivationStatus = loSvc.GetReactivationStatus(loTableKey)
        If loReactivationStatus IsNot Nothing Then
            dtpLastExpiryDate.Visible = True
            dtpCurrentExpiryDate.Visible = True

            If loReactivationStatus.CLAST_EXPIRY_DATE.Trim.Equals("") Then
                dtpLastExpiryDate.Visible = False
            Else
                dtpLastExpiryDate.Value = StrToDate(loReactivationStatus.CLAST_EXPIRY_DATE)
            End If
            If loReactivationStatus.CCURRENT_EXPIRY_DATE.Trim.Equals("") Then
                dtpCurrentExpiryDate.Visible = False
            Else
                dtpCurrentExpiryDate.Value = StrToDate(loReactivationStatus.CCURRENT_EXPIRY_DATE)
            End If
            txtReactivationStatus.Text = loReactivationStatus.CREACTIVATION_STATUS
        Else
            dtpLastExpiryDate.Visible = False
            dtpCurrentExpiryDate.Visible = False
            txtReactivationStatus.Text = ""
        End If

        cboLicenseMode.SelectedIndex = -1
        spnLicensee.Value = spnLicensee.Minimum
        txtInstallationID.Text = _CSERVER_UID
        dtpStartDate.Value = StrToDate(_CLAST_EXPIRY_DATE).Value.AddDays(1)
        dtpExpiryDate.Value = StrToDate(_CLAST_EXPIRY_DATE).Value.AddMonths(_NINTERVAL)
        spnGraceDays.Value = _NGRACE_DAYS
        spnWarningDays.Value = _NWARNING_DAYS
    End Sub

    Private Sub UpdateVFPActivation()
        Dim lcCmd As String
        Dim loException As New R_Exception
        Dim loCRPPath As String
        Dim lnGraceDays As Integer
        Const ERR_FILE As String = "File.Err"

        Try
            ' if activation type = Windows (001), create crp file in RealCode/Company/App/CRP
            loCRPPath = "D:\RealCode\" + _CCOMPID.Trim + "\" + cboApplication.SelectedValue.Trim + "\CRP"
            If Not Directory.Exists(loCRPPath) Then
                Directory.CreateDirectory(loCRPPath)
            End If

            lnGraceDays = DateDiff(DateInterval.Day, dtpStartDate.Value, dtpExpiryDate.Value) + spnGraceDays.Value + 1

            lcCmd = loCRPPath.Trim + "|" + cboCustomer.SelectedValue.Trim + "|" + _CSERVER_UID.Trim + "|" + dtpStartDate.Value.ToString("yyyyMMdd").Trim + "|" + lnGraceDays.ToString.Trim + "|" + spnWarningDays.Value.ToString.Trim
            lcCmd = GetParameter(lcCmd)
            If IO.File.Exists(ERR_FILE) Then
                IO.File.Delete(ERR_FILE)
            End If
            CreateTerm(lcCmd)
            If IO.File.Exists(ERR_FILE) Then
                loException.Add("ErrCreateTerm-01", "Error Create CRP.")
                Dim lcError As String
                lcError = IO.File.ReadAllText(ERR_FILE)
                loException.Add("ErrCreateTerm-02", lcError)
                Exit Try
            End If
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Function GetParameter(lcPar As String) As String
        Dim lcRtn As String = ""
        Dim laRtn As String()

        laRtn = lcPar.Split("|")

        For Each lcStr In laRtn
            lcRtn = lcRtn + """" + lcStr.Trim + """ "
        Next

        Return lcRtn
    End Function

    Private Sub CreateTerm(pcParameter As String)
        Dim startInfo As New ProcessStartInfo
        startInfo.FileName = "r_createterm.exe"
        startInfo.Arguments = pcParameter
        Process.Start(startInfo)
    End Sub

#End Region

#Region " COMBOs "

    Private Sub cboApplication_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboApplication.SelectedValueChanged
        If llInitialized Then
            _CACTIVATION_TYPE = CType(bsApps.Current, LAT00100AppComboDTO).CACTIVATION_TYPE
            RefreshGrids()
        End If
    End Sub

    Private Sub cboCustomer_SelectedValueChanged(sender As Object, e As System.EventArgs) Handles cboCustomer.SelectedValueChanged
        If llInitialized Then
            RefreshGrids()
        End If
    End Sub

    Private Sub dtpStartDate_ValueChanged(sender As Object, e As System.EventArgs) Handles dtpStartDate.ValueChanged
        If _NINTERVAL > 0 Then
            dtpExpiryDate.Value = CType(sender, R_RadDateTimePicker).Value.AddMonths(_NINTERVAL).AddDays(-1)
        End If
    End Sub

#End Region

#Region " BUTTONs "

    Private Sub btnGenerateActivation_Click(sender As System.Object, e As System.EventArgs) Handles btnGenerateActivation.Click
        Dim loEx As New R_Exception
        Dim loSvc As LAT00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00100Service, LAT00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loActivation As LAT00100ActivationDTO

        Try
            ' Validation
            ' Installation ID
            If txtInstallationID.Text.Trim.Equals("") Then
                loEx.Add("LAT00100_01", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "LAT00100_01"))
                Exit Try
            End If
            ' Expiry Date
            If dtpExpiryDate.Value < dtpStartDate.Value Then
                loEx.Add("LAT00100_03", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "LAT00100_03"))
                Exit Try
            End If

            ' if activation type = Windows (001), create crp file in RealCode/Company/App/CRP
            If _CACTIVATION_TYPE.Trim = "001" Then
                UpdateVFPActivation()
            End If

            ' Save
            loActivation = New LAT00100ActivationDTO
            With loActivation
                ._CCOMPANY_ID = _CCOMPID
                ._CAPPS_CODE = cboApplication.SelectedValue.Trim
                ._CCUSTOMER_CODE = cboCustomer.SelectedValue.Trim
                ._CGENERATE_TIME = "" 'digenerate di backend
                ._CSERVER_TYPE = IIf(rdbLive.IsChecked, "1", IIf(rdbTraining.IsChecked, "2", "0"))
                ._CSERVER_UID = txtInstallationID.Text.Trim
                ._CSTART_DATE = dtpStartDate.Value.ToString("yyyyMMdd")
                ._CEXPIRY_DATE = dtpExpiryDate.Value.ToString("yyyyMMdd")
                ._NGRACE_DAYS = spnGraceDays.Value
                ._NWARNING_DAYS = spnWarningDays.Value
                ._CACTIVATION_CODE = "" 'digenerate di backend
                ._CUPDATE_BY = _CUSERID
                ._DUPDATE_DATE = Now
                ._CCREATE_BY = _CUSERID
                ._DCREATE_DATE = Now
            End With
            loSvc.SaveActivation(loActivation)

            RefreshGrids()

            ' go to list page
            pvpActivationList.Show()

        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loEx.Haserror Then
            R_DisplayException(loEx)
        End If
    End Sub

    Private Sub btnGenerateLicense_Click(sender As System.Object, e As System.EventArgs) Handles btnGenerateLicense.Click
        Dim loEx As New R_Exception
        Dim lcInstallationID_Decrypted As String = ""
        Dim loSvc As LAT00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00100Service, LAT00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loLicense As LAT00100LicenseDTO
        Dim lcCustomerInfo As String()
        Dim lcCustomerName As String = ""

        Try
            ' Refresh Customer Combo
            RefreshCustomerCombo()

            ' Validation
            ' Installation ID
            If txtInstallationID.Text.Trim.Equals("") Then
                loEx.Add("LAT00100_01", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "LAT00100_01"))
                Exit Try
            End If

            ' Customer Name
            lcCustomerInfo = cboCustomer.Text.Trim.Split("|")
            If rdbTest.IsChecked Then
                lcCustomerName = cboCustomer.SelectedValue.Trim & " - Testing Company"
            End If
            If rdbLive.IsChecked Then
                lcCustomerName = lcCustomerInfo(1).Trim
            End If
            If rdbTraining.IsChecked Then
                lcCustomerName = cboCustomer.SelectedValue.Trim & " - Training Company"
            End If
            ' Save
            loLicense = New LAT00100LicenseDTO
            With loLicense
                ._CCOMPANY_ID = _CCOMPID
                ._CAPPS_CODE = cboApplication.SelectedValue.Trim
                ._CCUSTOMER_CODE = cboCustomer.SelectedValue.Trim
                ._CGENERATE_TIME = "" 'digenerate di backend
                ._CSERVER_TYPE = IIf(rdbLive.IsChecked, "1", IIf(rdbTraining.IsChecked, "2", "0"))
                ._CSERVER_UID = txtInstallationID.Text.Trim
                ._CLICENSE_MODE = cboLicenseMode.Text.Trim
                ._NLICENSEE = spnLicensee.Value
                ._CLICENSE_CODE = "" 'digenerate di backend
                ._CUPDATE_BY = _CUSERID
                ._DUPDATE_DATE = Now
                ._CCREATE_BY = _CUSERID
                ._DCREATE_DATE = Now
                ._CCUSTOMER_NAME = lcCustomerName
            End With
            loSvc.SaveLicense(loLicense)

            RefreshGrids()

            ' go to list page
            pvpLicenseList.Show()

        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loEx.Haserror Then
            R_DisplayException(loEx)
        End If
    End Sub

    Private Sub btnSaveLicense_Click(sender As System.Object, e As System.EventArgs) Handles btnSaveLicense.Click
        Dim lcFilename As String
        Dim lcFileContent As String

        lcFileContent = _curLicenseDTO._CLICENSE_CODE

        ' save to file: appid+custid+generatetime(yyyy.MM.dd.hh.mm.ss)+.license

        lcFilename = cboApplication.SelectedValue.ToString.ToUpper.Trim + "_"
        lcFilename += cboCustomer.SelectedValue.ToString.ToUpper.Trim + "_"
        lcFilename += _curLicenseDTO._CGENERATE_TIME.Trim
        lcFilename += ".license"

        ShowSaveDialog(lcFilename, lcFileContent)

    End Sub

    Private Sub btnSaveActivation_Click(sender As System.Object, e As System.EventArgs) Handles btnSaveActivation.Click
        Dim lcFilename As String
        Dim lcFileContent As String

        lcFileContent = _curActivationDTO._CACTIVATION_CODE

        ' save to file: appid+custid+generatetime(yyyy.MM.dd.hh.mm.ss)+.activation

        lcFilename = cboApplication.SelectedValue.ToString.ToUpper.Trim + "_"
        lcFilename += cboCustomer.SelectedValue.ToString.ToUpper.Trim + "_"
        lcFilename += _curActivationDTO._CGENERATE_TIME.Trim
        lcFilename += ".activation"

        ShowSaveDialog(lcFilename, lcFileContent)

    End Sub

    Private Sub btnResetReactivationStatus_Click(sender As System.Object, e As System.EventArgs) Handles btnResetReactivationStatus.Click
        Dim loTableKey As New LAT00100KeyDTO
        Dim loEx As New R_Exception
        Dim loSvc As LAT00100ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ILAT00100Service, LAT00100ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)

        Try
            ' Refresh Customer Combo
            RefreshCustomerCombo()

            ' Save
            With loTableKey
                .CCOMPANY_ID = _CCOMPID
                .CAPPS_CODE = cboApplication.SelectedValue.Trim
                .CCUSTOMER_CODE = cboCustomer.SelectedValue.Trim
                .CSERVER_TYPE = IIf(rdbLive.IsChecked, "1", IIf(rdbTraining.IsChecked, "2", "0"))
                .CUSER_ID = _CUSERID
            End With
            loSvc.ResetReactivationStatus(loTableKey)

            RefreshGrids()

            ' go to list page
            pvpReactivationStatus.Show()

        Catch ex As Exception
            loEx.Add(ex)
        End Try
        If loEx.Haserror Then
            R_DisplayException(loEx)
        End If
    End Sub

#End Region

#Region " RADIOs "

    Private Sub rdbLive_CheckStateChanged(sender As Object, e As System.EventArgs) Handles rdbLive.CheckStateChanged
        If CType(sender, R_RadRadioButton).IsChecked And llInitialized Then
            RefreshGrids()
        End If
    End Sub

    Private Sub rdbTest_CheckStateChanged(sender As Object, e As System.EventArgs) Handles rdbTest.CheckStateChanged
        If CType(sender, R_RadRadioButton).IsChecked And llInitialized Then
            RefreshGrids()
        End If
    End Sub

    Private Sub rdbTraining_CheckStateChanged(sender As Object, e As System.EventArgs) Handles rdbTraining.CheckStateChanged
        If CType(sender, R_RadRadioButton).IsChecked And llInitialized Then
            RefreshGrids()
        End If
    End Sub
#End Region

#Region " End Active Date Calculator "

    Private Sub btnAddPeriod_Click(sender As System.Object, e As System.EventArgs) Handles btnAddPeriod.Click
        CalculateEndDate()
    End Sub

    Private Sub spnYear_ValueChanged(sender As System.Object, e As System.EventArgs) Handles spnYear.ValueChanged
        CalculateEndDate()
    End Sub

    Private Sub spnMonth_ValueChanged(sender As Object, e As System.EventArgs) Handles spnMonth.ValueChanged
        CalculateEndDate()
    End Sub

    Private Sub CalculateEndDate()
        If spnYear.Value > 0 Or spnMonth.Value > 0 Then

            dtpExpiryDate.Value = dtpStartDate.Value.AddYears(spnYear.Value)
            dtpExpiryDate.Value = dtpExpiryDate.Value.AddMonths(spnMonth.Value)
            dtpExpiryDate.Value = dtpExpiryDate.Value.AddDays(-1)
        Else
            dtpExpiryDate.Value = dtpStartDate.Value
        End If
    End Sub
#End Region


End Class
