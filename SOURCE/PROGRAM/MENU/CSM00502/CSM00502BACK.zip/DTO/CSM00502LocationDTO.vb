﻿Imports R_BackEnd

<Serializable()> _
Public Class CSM00502LocationDTO
    Inherits R_DTOBase

    Public Property CLOCATION_ID As String
    Public Property CLOCATION_NAME As String
    Public Property CDAYOFF_BIT_STRING As String
    Public Property LMON_OFF As Boolean
    Public Property LTUE_OFF As Boolean
    Public Property LWED_OFF As Boolean
    Public Property LTHU_OFF As Boolean
    Public Property LFRI_OFF As Boolean
    Public Property LSAT_OFF As Boolean
    Public Property LSUN_OFF As Boolean
    Public Property CDESCRIPTION As String
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)
    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)
End Class
