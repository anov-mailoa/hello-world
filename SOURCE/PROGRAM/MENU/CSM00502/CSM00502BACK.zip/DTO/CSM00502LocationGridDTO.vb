﻿Public Class CSM00502LocationGridDTO
    Public Property CLOCATION_ID As String
    Public Property CLOCATION_NAME As String
    Public Property CDAYOFF_BIT_STRING As String
    Public Property CDESCRIPTION As String
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)
    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)
End Class
