﻿Public Class CSM00502KeyDTO
    Public Property CLOCATION_ID As String
End Class
