﻿Imports R_BackEnd
Imports R_Common
Imports System.Data.Common

Public Class CSM00502Cls
    Inherits R_BusinessObject(Of CSM00502LocationDTO)

    Public Function GetLocationList(poKey As CSM00502KeyDTO) As List(Of CSM00502LocationGridDTO)
        Dim lcQuery As String
        Dim loResult As List(Of CSM00502LocationGridDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "SELECT * "
                lcQuery += "FROM "
                lcQuery += "CSM_LOCATIONS (NOLOCK) "
                lcQuery = String.Format(lcQuery)

            End With
            loResult = loDb.SqlExecObjectQuery(Of CSM00502LocationGridDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Deleting(poEntity As CSM00502LocationDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcRtn As String

        Try
            loConn = loDb.GetConnection()

            'validation
            loCmd = loDb.GetCommand()
            lcQuery = "EXEC RSP_Delete_Location_Validation '{0}', @CRET_MSG OUTPUT "
            With poEntity
                lcQuery = String.Format(lcQuery, .CLOCATION_ID)
            End With
            loCmd.CommandText = lcQuery
            loPar = loDb.GetParameter()
            With loPar
                .ParameterName = "@CRET_MSG"
                .DbType = DbType.String
                .Size = 50
                .Direction = ParameterDirection.Output
            End With
            loCmd.Parameters.Add(loPar)
            loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)

            If loCmd.Parameters("@CRET_MSG") Is Nothing Then
                lcRtn = "UNKNOWN_ERROR"
            Else
                lcRtn = loCmd.Parameters("@CRET_MSG").Value
            End If

            If Not lcRtn.Equals("OK") Then
                Throw New Exception(lcRtn)
            End If

            With poEntity
                'delete main table
                lcQuery = "DELETE FROM "
                lcQuery += "CSM_LOCATIONS "
                lcQuery += "WHERE CLOCATION_ID = '{0}' "
                lcQuery = String.Format(lcQuery, .CLOCATION_ID)

                loDb.SqlExecNonQuery(lcQuery, loConn, True)
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Protected Overrides Function R_Display(poEntity As CSM00502LocationDTO) As CSM00502LocationDTO
        Dim lcQuery As String
        Dim loResult As CSM00502LocationDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poEntity
                lcQuery = "SELECT *, "
                lcQuery += "CONVERT(bit, SUBSTRING(CDAYOFF_BIT_STRING, 1, 1)) AS LMON_OFF, "
                lcQuery += "CONVERT(bit, SUBSTRING(CDAYOFF_BIT_STRING, 2, 1)) AS LTUE_OFF, "
                lcQuery += "CONVERT(bit, SUBSTRING(CDAYOFF_BIT_STRING, 3, 1)) AS LWED_OFF, "
                lcQuery += "CONVERT(bit, SUBSTRING(CDAYOFF_BIT_STRING, 4, 1)) AS LTHU_OFF, "
                lcQuery += "CONVERT(bit, SUBSTRING(CDAYOFF_BIT_STRING, 5, 1)) AS LFRI_OFF, "
                lcQuery += "CONVERT(bit, SUBSTRING(CDAYOFF_BIT_STRING, 6, 1)) AS LSAT_OFF, "
                lcQuery += "CONVERT(bit, SUBSTRING(CDAYOFF_BIT_STRING, 7, 1)) AS LSUN_OFF "
                lcQuery += "FROM "
                lcQuery += "CSM_LOCATIONS (NOLOCK) "
                lcQuery += "WHERE CLOCATION_ID = '{0}' "
                lcQuery = String.Format(lcQuery, .CLOCATION_ID)

                loResult = loDb.SqlExecObjectQuery(Of CSM00502LocationDTO)(lcQuery).FirstOrDefault

            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Protected Overrides Sub R_Saving(poNewEntity As CSM00502LocationDTO, poCRUDMode As R_Common.eCRUDMode)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String

        Try
            loConn = loDb.GetConnection()

            With poNewEntity
                If poCRUDMode = eCRUDMode.AddMode Then

                    .CUPDATE_BY = .CUPDATE_BY
                    .CCREATE_BY = .CUPDATE_BY

                    lcQuery = "INSERT INTO CSM_LOCATIONS ("
                    lcQuery += "CLOCATION_ID, "
                    lcQuery += "CLOCATION_NAME, "
                    lcQuery += "CDAYOFF_BIT_STRING, "
                    lcQuery += "CDESCRIPTION, "
                    lcQuery += "CUPDATE_BY, "
                    lcQuery += "DUPDATE_DATE, "
                    lcQuery += "CCREATE_BY, "
                    lcQuery += "DCREATE_DATE) "
                    lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', GETDATE(), '{5}', GETDATE()) "
                    lcQuery = String.Format(lcQuery,
                    .CLOCATION_ID,
                    .CLOCATION_NAME,
                    .CDAYOFF_BIT_STRING,
                    .CDESCRIPTION,
                    .CUPDATE_BY,
                    .CCREATE_BY)

                ElseIf poCRUDMode = eCRUDMode.EditMode Then


                    lcQuery = "UPDATE CSM_LOCATIONS "
                    lcQuery += "SET "
                    lcQuery += "CLOCATION_NAME = '{1}', "
                    lcQuery += "CDAYOFF_BIT_STRING = '{2}', "
                    lcQuery += "CDESCRIPTION = '{3}', "
                    lcQuery += "CUPDATE_BY = '{4}', "
                    lcQuery += "DUPDATE_DATE = GETDATE() "
                    lcQuery += "WHERE CLOCATION_ID = '{0}' "
                    lcQuery = String.Format(lcQuery,
                    .CLOCATION_ID,
                    .CLOCATION_NAME,
                    .CDAYOFF_BIT_STRING,
                    .CDESCRIPTION,
                    .CUPDATE_BY)

                End If
            End With
            loDb.SqlExecNonQuery(lcQuery, loConn, True)
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
End Class
