﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CSM00502
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn3 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewCheckBoxColumn1 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewCheckBoxColumn2 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewCheckBoxColumn3 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewCheckBoxColumn4 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewCheckBoxColumn5 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewCheckBoxColumn6 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewCheckBoxColumn7 As R_FrontEnd.R_GridViewCheckBoxColumn = New R_FrontEnd.R_GridViewCheckBoxColumn()
        Dim R_GridViewTextBoxColumn4 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn1 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Dim R_GridViewTextBoxColumn5 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewDateTimeColumn2 As R_FrontEnd.R_GridViewDateTimeColumn = New R_FrontEnd.R_GridViewDateTimeColumn()
        Me.conGridLocation = New R_FrontEnd.R_ConductorGrid(Me.components)
        Me.bsGvLocation = New System.Windows.Forms.BindingSource(Me.components)
        Me.gvLocation = New R_FrontEnd.R_RadGridView(Me.components)
        CType(Me.conGridLocation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsGvLocation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvLocation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvLocation.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'conGridLocation
        '
        Me.conGridLocation.R_ConductorParent = Nothing
        Me.conGridLocation.R_IsHeader = True
        Me.conGridLocation.R_RadGroupBox = Nothing
        '
        'bsGvLocation
        '
        Me.bsGvLocation.DataSource = GetType(CSM00502Front.CSM00502ServiceRef.CSM00502LocationDTO)
        '
        'gvLocation
        '
        Me.gvLocation.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gvLocation.EnableFastScrolling = True
        Me.gvLocation.Location = New System.Drawing.Point(0, 0)
        '
        '
        '
        Me.gvLocation.MasterTemplate.AutoGenerateColumns = False
        R_GridViewTextBoxColumn1.FieldName = "_CLOCATION_ID"
        R_GridViewTextBoxColumn1.HeaderText = "_CLOCATION_ID"
        R_GridViewTextBoxColumn1.Name = "_CLOCATION_ID"
        R_GridViewTextBoxColumn1.R_EnableADD = True
        R_GridViewTextBoxColumn1.R_ResourceId = "_CLOCATION_ID"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 108
        R_GridViewTextBoxColumn2.FieldName = "_CLOCATION_NAME"
        R_GridViewTextBoxColumn2.HeaderText = "_CLOCATION_NAME"
        R_GridViewTextBoxColumn2.Multiline = True
        R_GridViewTextBoxColumn2.Name = "_CLOCATION_NAME"
        R_GridViewTextBoxColumn2.R_EnableADD = True
        R_GridViewTextBoxColumn2.R_EnableEDIT = True
        R_GridViewTextBoxColumn2.R_ResourceId = "_CLOCATION_NAME"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 72
        R_GridViewTextBoxColumn3.FieldName = "_CDESCRIPTION"
        R_GridViewTextBoxColumn3.HeaderText = "_CDESCRIPTION"
        R_GridViewTextBoxColumn3.Name = "_CDESCRIPTION"
        R_GridViewTextBoxColumn3.R_EnableADD = True
        R_GridViewTextBoxColumn3.R_EnableEDIT = True
        R_GridViewTextBoxColumn3.R_ResourceId = "_CDESCRIPTION"
        R_GridViewTextBoxColumn3.R_UDT = Nothing
        R_GridViewTextBoxColumn3.Width = 72
        R_GridViewCheckBoxColumn1.Checked = Telerik.WinControls.Enumerations.ToggleState.[On]
        R_GridViewCheckBoxColumn1.FieldName = "_LMON_OFF"
        R_GridViewCheckBoxColumn1.HeaderText = "_LMON_OFF"
        R_GridViewCheckBoxColumn1.Name = "_LMON_OFF"
        R_GridViewCheckBoxColumn1.R_EnableADD = True
        R_GridViewCheckBoxColumn1.R_EnableEDIT = True
        R_GridViewCheckBoxColumn1.R_ResourceId = "_LMON_OFF"
        R_GridViewCheckBoxColumn2.Checked = Telerik.WinControls.Enumerations.ToggleState.[On]
        R_GridViewCheckBoxColumn2.FieldName = "_LTUE_OFF"
        R_GridViewCheckBoxColumn2.HeaderText = "_LTUE_OFF"
        R_GridViewCheckBoxColumn2.Name = "_LTUE_OFF"
        R_GridViewCheckBoxColumn2.R_EnableADD = True
        R_GridViewCheckBoxColumn2.R_EnableEDIT = True
        R_GridViewCheckBoxColumn2.R_ResourceId = "_LTUE_OFF"
        R_GridViewCheckBoxColumn3.Checked = Telerik.WinControls.Enumerations.ToggleState.[On]
        R_GridViewCheckBoxColumn3.FieldName = "_LWED_OFF"
        R_GridViewCheckBoxColumn3.HeaderText = "_LWED_OFF"
        R_GridViewCheckBoxColumn3.Name = "_LWED_OFF"
        R_GridViewCheckBoxColumn3.R_EnableADD = True
        R_GridViewCheckBoxColumn3.R_EnableEDIT = True
        R_GridViewCheckBoxColumn3.R_ResourceId = "_LWED_OFF"
        R_GridViewCheckBoxColumn4.Checked = Telerik.WinControls.Enumerations.ToggleState.[On]
        R_GridViewCheckBoxColumn4.FieldName = "_LTHU_OFF"
        R_GridViewCheckBoxColumn4.HeaderText = "_LTHU_OFF"
        R_GridViewCheckBoxColumn4.Name = "_LTHU_OFF"
        R_GridViewCheckBoxColumn4.R_EnableADD = True
        R_GridViewCheckBoxColumn4.R_EnableEDIT = True
        R_GridViewCheckBoxColumn4.R_ResourceId = "_LTHU_OFF"
        R_GridViewCheckBoxColumn5.Checked = Telerik.WinControls.Enumerations.ToggleState.[On]
        R_GridViewCheckBoxColumn5.FieldName = "_LFRI_OFF"
        R_GridViewCheckBoxColumn5.HeaderText = "_LFRI_OFF"
        R_GridViewCheckBoxColumn5.Name = "_LFRI_OFF"
        R_GridViewCheckBoxColumn5.R_EnableADD = True
        R_GridViewCheckBoxColumn5.R_EnableEDIT = True
        R_GridViewCheckBoxColumn5.R_ResourceId = "_LFRI_OFF"
        R_GridViewCheckBoxColumn6.Checked = Telerik.WinControls.Enumerations.ToggleState.[On]
        R_GridViewCheckBoxColumn6.FieldName = "_LSAT_OFF"
        R_GridViewCheckBoxColumn6.HeaderText = "_LSAT_OFF"
        R_GridViewCheckBoxColumn6.Name = "_LSAT_OFF"
        R_GridViewCheckBoxColumn6.R_EnableADD = True
        R_GridViewCheckBoxColumn6.R_EnableEDIT = True
        R_GridViewCheckBoxColumn6.R_ResourceId = "_LSAT_OFF"
        R_GridViewCheckBoxColumn7.Checked = Telerik.WinControls.Enumerations.ToggleState.[On]
        R_GridViewCheckBoxColumn7.FieldName = "_LSUN_OFF"
        R_GridViewCheckBoxColumn7.HeaderText = "_LSUN_OFF"
        R_GridViewCheckBoxColumn7.Name = "_LSUN_OFF"
        R_GridViewCheckBoxColumn7.R_EnableADD = True
        R_GridViewCheckBoxColumn7.R_EnableEDIT = True
        R_GridViewCheckBoxColumn7.R_ResourceId = "_LSUN_OFF"
        R_GridViewTextBoxColumn4.FieldName = "_CUPDATE_BY"
        R_GridViewTextBoxColumn4.HeaderText = "_CUPDATE_BY"
        R_GridViewTextBoxColumn4.Name = "_CUPDATE_BY"
        R_GridViewTextBoxColumn4.R_ResourceId = "_CUPDATE_BY"
        R_GridViewTextBoxColumn4.R_UDT = Nothing
        R_GridViewTextBoxColumn4.Width = 76
        R_GridViewDateTimeColumn1.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn1.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn1.FieldName = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn1.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn1.HeaderText = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.Name = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.R_ResourceId = "_DUPDATE_DATE"
        R_GridViewDateTimeColumn1.Width = 90
        R_GridViewTextBoxColumn5.FieldName = "_CCREATE_BY"
        R_GridViewTextBoxColumn5.HeaderText = "_CCREATE_BY"
        R_GridViewTextBoxColumn5.Name = "_CCREATE_BY"
        R_GridViewTextBoxColumn5.R_ResourceId = "_CCREATE_BY"
        R_GridViewTextBoxColumn5.R_UDT = Nothing
        R_GridViewTextBoxColumn5.Width = 74
        R_GridViewDateTimeColumn2.DataType = GetType(System.Nullable(Of Date))
        R_GridViewDateTimeColumn2.ExcelExportType = Telerik.WinControls.UI.Export.DisplayFormatType.MediumTime
        R_GridViewDateTimeColumn2.FieldName = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.FilteringMode = Telerik.WinControls.UI.GridViewTimeFilteringMode.[Date]
        R_GridViewDateTimeColumn2.FormatString = "{0: M/d/yyyy }"
        R_GridViewDateTimeColumn2.HeaderText = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.Name = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.R_ResourceId = "_DCREATE_DATE"
        R_GridViewDateTimeColumn2.Width = 28
        Me.gvLocation.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2, R_GridViewTextBoxColumn3, R_GridViewCheckBoxColumn1, R_GridViewCheckBoxColumn2, R_GridViewCheckBoxColumn3, R_GridViewCheckBoxColumn4, R_GridViewCheckBoxColumn5, R_GridViewCheckBoxColumn6, R_GridViewCheckBoxColumn7, R_GridViewTextBoxColumn4, R_GridViewDateTimeColumn1, R_GridViewTextBoxColumn5, R_GridViewDateTimeColumn2})
        Me.gvLocation.MasterTemplate.DataSource = Me.bsGvLocation
        Me.gvLocation.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvLocation.MasterTemplate.EnableFiltering = True
        Me.gvLocation.MasterTemplate.EnableGrouping = False
        Me.gvLocation.MasterTemplate.ShowFilteringRow = False
        Me.gvLocation.MasterTemplate.ShowGroupedColumns = True
        Me.gvLocation.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvLocation.Name = "gvLocation"
        Me.gvLocation.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.None
        Me.gvLocation.R_ConductorGridSource = Me.conGridLocation
        Me.gvLocation.R_ConductorSource = Nothing
        Me.gvLocation.R_DataAdded = False
        Me.gvLocation.R_NewRowText = Nothing
        Me.gvLocation.ShowHeaderCellButtons = True
        Me.gvLocation.Size = New System.Drawing.Size(1277, 575)
        Me.gvLocation.TabIndex = 1
        Me.gvLocation.Text = "R_RadGridView1"
        '
        'CSM00502
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(1277, 575)
        Me.Controls.Add(Me.gvLocation)
        Me.Name = "CSM00502"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        CType(Me.conGridLocation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsGvLocation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvLocation.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvLocation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents conGridLocation As R_FrontEnd.R_ConductorGrid
    Friend WithEvents bsGvLocation As System.Windows.Forms.BindingSource
    Friend WithEvents gvLocation As R_FrontEnd.R_RadGridView

End Class
