﻿Imports CSM00502FrontResources
Imports R_Common
Imports ClientHelper
Imports CSM00502Front.CSM00502ServiceRef
Imports CSM00502Front.CSM00502StreamingServiceRef
Imports R_FrontEnd
Imports System.ServiceModel.Channels

Public Class CSM00502

#Region " VARIABLE "
    Dim C_ServiceName As String = "CSM00502Service/CSM00502Service.svc"
    Dim C_ServiceNameStream As String = "CSM00502Service/CSM00502StreamingService.svc"
    Dim _CUSERID As String
    Dim _CCOMPID As String
    Dim _CCUSTCODE As String
#End Region

#Region " F O R M Methods "

    Private Sub CSM00502_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception

        Try
            _CUSERID = U_GlobalVar.UserId
            _CCOMPID = U_GlobalVar.CompId
            gvLocation.R_RefreshGrid(New CSM00502LocationDTO With {._CLOCATION_ID = ""})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub CSM00502_R_LockUnlock(peLockUnlock As R_FrontEnd.R_eLockUnlock, poEntity As Object, ByRef plSuccessLockUnlock As Boolean) Handles Me.R_LockUnlock
        plSuccessLockUnlock = True

    End Sub

#End Region

#Region " GRIDVIEW Methods "

    'Private Sub gvLocation_R_Display(poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvLocation.R_Display
    '    With CType(poEntity, CSM00502LocationDTO)
    '        ._LMON_OFF = (Mid(._CDAYOFF_BIT_STRING, 1, 1) = "1")
    '        ._LTUE_OFF = (Mid(._CDAYOFF_BIT_STRING, 2, 1) = "1")
    '        ._LWED_OFF = (Mid(._CDAYOFF_BIT_STRING, 3, 1) = "1")
    '        ._LTHU_OFF = (Mid(._CDAYOFF_BIT_STRING, 4, 1) = "1")
    '        ._LFRI_OFF = (Mid(._CDAYOFF_BIT_STRING, 5, 1) = "1")
    '        ._LSAT_OFF = (Mid(._CDAYOFF_BIT_STRING, 6, 1) = "1")
    '        ._LSUN_OFF = (Mid(._CDAYOFF_BIT_STRING, 7, 1) = "1")
    '    End With

    'End Sub

    Private Sub gvLocation_R_Saving(ByRef poEntity As Object, poGridCellCollection As Telerik.WinControls.UI.GridViewCellInfoCollection, peGridMode As R_FrontEnd.R_eGridMode) Handles gvLocation.R_Saving
        Dim lcBitString As String

        With CType(poEntity, CSM00502LocationDTO)
            lcBitString = IIf(._LMON_OFF, "1", "0")
            lcBitString += IIf(._LTUE_OFF, "1", "0")
            lcBitString += IIf(._LWED_OFF, "1", "0")
            lcBitString += IIf(._LTHU_OFF, "1", "0")
            lcBitString += IIf(._LFRI_OFF, "1", "0")
            lcBitString += IIf(._LSAT_OFF, "1", "0")
            lcBitString += IIf(._LSUN_OFF, "1", "0")
            ._CDAYOFF_BIT_STRING = lcBitString
            ._CUPDATE_BY = _CUSERID
            ._DUPDATE_DATE = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
        End With
    End Sub

    Private Sub gvLocation_R_ServiceDelete(poEntity As Object) Handles gvLocation.R_ServiceDelete
        Dim loService As CSM00502ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00502Service, CSM00502ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            loService.Svc_R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvLocation_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvLocation.R_ServiceGetListRecord
        Dim loServiceStream As CSM00502StreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00502StreamingService, CSM00502StreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of CSM00502LocationGridDTO)
        Dim loListEntity As New List(Of CSM00502LocationDTO)

        Try
            With CType(poEntity, CSM00502LocationDTO)
                R_Utility.R_SetStreamingContext("cLocationId", ._CLOCATION_ID)
            End With

            loRtn = loServiceStream.GetLocationList()
            loStreaming = R_StreamUtility(Of CSM00502LocationGridDTO).ReadFromMessage(loRtn)

            For Each loDto As CSM00502LocationGridDTO In loStreaming
                If loDto IsNot Nothing Then
                    loListEntity.Add(New CSM00502LocationDTO With {._CLOCATION_ID = loDto.CLOCATION_ID,
                                                                   ._CLOCATION_NAME = loDto.CLOCATION_NAME,
                                                                   ._CDESCRIPTION = loDto.CDESCRIPTION,
                                                                   ._LMON_OFF = (Mid(loDto.CDAYOFF_BIT_STRING, 1, 1) = "1"),
                                                                   ._LTUE_OFF = (Mid(loDto.CDAYOFF_BIT_STRING, 2, 1) = "1"),
                                                                   ._LWED_OFF = (Mid(loDto.CDAYOFF_BIT_STRING, 3, 1) = "1"),
                                                                   ._LTHU_OFF = (Mid(loDto.CDAYOFF_BIT_STRING, 4, 1) = "1"),
                                                                   ._LFRI_OFF = (Mid(loDto.CDAYOFF_BIT_STRING, 5, 1) = "1"),
                                                                   ._LSAT_OFF = (Mid(loDto.CDAYOFF_BIT_STRING, 6, 1) = "1"),
                                                                   ._LSUN_OFF = (Mid(loDto.CDAYOFF_BIT_STRING, 7, 1) = "1"),
                                                                   ._CCREATE_BY = loDto.CCREATE_BY,
                                                                   ._DCREATE_DATE = loDto.DCREATE_DATE,
                                                                   ._CUPDATE_BY = loDto.CUPDATE_BY,
                                                                   ._DUPDATE_DATE = loDto.DUPDATE_DATE})
                Else
                    Exit For
                End If
            Next
            poListEntityResult = loListEntity
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvLocation_R_ServiceGetRecord(poEntity As Object, ByRef poEntityResult As Object) Handles gvLocation.R_ServiceGetRecord
        Dim loService As CSM00502ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00502Service, CSM00502ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_GetRecord(New CSM00502LocationDTO With {._CLOCATION_ID = CType(poEntity, CSM00502LocationDTO)._CLOCATION_ID})
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Private Sub gvLocation_R_ServiceSave(poEntity As Object, peGridMode As R_FrontEnd.R_eGridMode, ByRef poEntityResult As Object) Handles gvLocation.R_ServiceSave
        Dim loService As CSM00502ServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of ICSM00502Service, CSM00502ServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loEx As New R_Exception

        Try
            poEntityResult = loService.Svc_R_Save(poEntity, peGridMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

End Class
