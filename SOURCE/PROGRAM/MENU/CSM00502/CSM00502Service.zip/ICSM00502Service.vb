﻿Imports System.ServiceModel
Imports R_BackEnd
Imports CSM00502Back
Imports R_Common

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00502Service" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00502Service
    Inherits R_IServicebase(Of CSM00502LocationDTO)

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function Dummy() As List(Of CSM00502KeyDTO)

End Interface
