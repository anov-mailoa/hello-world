﻿Imports R_Common
Imports CSM00502Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00502Service" in code, svc and config file together.
Public Class CSM00502Service
    Implements ICSM00502Service

    Public Sub Svc_R_Delete(poEntity As CSM00502Back.CSM00502LocationDTO) Implements R_BackEnd.R_IServicebase(Of CSM00502Back.CSM00502LocationDTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New CSM00502Cls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As CSM00502Back.CSM00502LocationDTO) As CSM00502Back.CSM00502LocationDTO Implements R_BackEnd.R_IServicebase(Of CSM00502Back.CSM00502LocationDTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New CSM00502Cls
        Dim loRtn As CSM00502LocationDTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As CSM00502Back.CSM00502LocationDTO, poCRUDMode As R_Common.eCRUDMode) As CSM00502Back.CSM00502LocationDTO Implements R_BackEnd.R_IServicebase(Of CSM00502Back.CSM00502LocationDTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New CSM00502Cls
        Dim loRtn As CSM00502LocationDTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Dummy() As System.Collections.Generic.List(Of CSM00502Back.CSM00502KeyDTO) Implements ICSM00502Service.Dummy

    End Function
End Class
