﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports CSM00502Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00502StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00502StreamingService

    <OperationContract(Action:="getLocationList", ReplyAction:="getLocationList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetLocationList() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of CSM00502LocationGridDTO))

End Interface
