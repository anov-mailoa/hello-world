﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports LAT00110Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ILAT00110StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ILAT00110StreamingService

    <OperationContract(Action:="getStagingData", ReplyAction:="getStagingData")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetStagingData() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of LAT00110StagingDTO), ByVal poPar2 As LAT00110KeyDTO)

End Interface
