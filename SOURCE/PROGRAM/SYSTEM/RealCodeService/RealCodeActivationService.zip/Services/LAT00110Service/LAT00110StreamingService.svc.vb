﻿Imports R_Common
Imports LAT00110Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "LAT00110StreamingService" in code, svc and config file together.
Public Class LAT00110StreamingService
    Implements ILAT00110StreamingService

    Public Function GetStagingData() As System.ServiceModel.Channels.Message Implements ILAT00110StreamingService.GetStagingData
        Dim loException As New R_Exception
        Dim loCls As New LAT00110Cls
        Dim loRtnTemp As List(Of LAT00110StagingDTO)
        Dim loRtn As Message
        Dim loTableKey As New LAT00110KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
            End With

            loRtnTemp = loCls.GetStagingData(loTableKey)

            loRtn = R_StreamUtility(Of LAT00110StagingDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getStagingData")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of LAT00110Back.LAT00110StagingDTO), poPar2 As LAT00110Back.LAT00110KeyDTO) Implements ILAT00110StreamingService.Dummy

    End Sub
End Class
