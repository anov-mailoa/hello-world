﻿Imports R_Common
Imports LAT00110Back
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the class name "LAT00110Service" in code, svc and config file together.
Public Class LAT00110Service
    Implements ILAT00110Service

    Public Function ActivationCodeInstall(poPar As LAT00110Back.ActivationCodeInstallParamDTO) As LAT00110Back.ActivationCodeInstallReturnDTO Implements ILAT00110Service.ActivationCodeInstall
        Dim loException As New R_Exception
        Dim loCls As New LAT00110Cls
        Dim loRtn As ActivationCodeInstallReturnDTO

        Try
            loRtn = loCls.ActivationCodeInstall(poPar)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function ActivationRequest(poPar As LAT00110Back.ActivationRequestParamDTO) As LAT00110Back.ActivationRequestReturnDTO Implements ILAT00110Service.ActivationRequest
        Dim loException As New R_Exception
        Dim loCls As New LAT00110Cls
        Dim loRtn As ActivationRequestReturnDTO

        Try
            loRtn = loCls.ActivationRequest(poPar)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function ActivationStatus(poPar As LAT00110Back.ActivationStatusParamDTO) As LAT00110Back.ActivationStatusReturnDTO Implements ILAT00110Service.ActivationStatus
        Dim loException As New R_Exception
        Dim loCls As New LAT00110Cls
        Dim loRtn As ActivationStatusReturnDTO

        Try
            loRtn = loCls.ActivationStatus(poPar)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetAppCombo(companyId As String, userId As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseAppComboDTO) Implements ILAT00110Service.GetAppCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseAppComboDTO)

        Try
            loRtn = loCls.GetAppCombo(companyId, userId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
