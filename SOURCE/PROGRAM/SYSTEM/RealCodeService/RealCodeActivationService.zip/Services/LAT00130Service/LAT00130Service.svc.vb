﻿Imports R_Common
Imports LAT00130Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "LAT00130Service" in code, svc and config file together.
Public Class LAT00130Service
    Implements ILAT00130Service

    Public Function ReactivationRequest(poPar As LAT00130Back.ReactivationRequestParamDTO) As LAT00130Back.ReactivationRequestReturnDTO Implements ILAT00130Service.ReactivationRequest
        Dim loException As New R_Exception
        Dim loCls As New LAT00130Cls
        Dim loRtn As ReactivationRequestReturnDTO

        Try
            loRtn = loCls.ReactivationRequest(poPar)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function ReactivationComplete(poPar As LAT00130Back.ReactivationCompleteParamDTO) As LAT00130Back.ReactivationCompleteReturnDTO Implements ILAT00130Service.ReactivationComplete
        Dim loException As New R_Exception
        Dim loCls As New LAT00130Cls
        Dim loRtn As ReactivationCompleteReturnDTO

        Try
            loRtn = loCls.ReactivationComplete(poPar)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
