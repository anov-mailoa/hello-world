﻿Imports R_Common
Imports SAM01100Back
Imports System.ServiceModel.Channels
' NOTE: You can use the "Rename" command on the context menu to change the class name "SAM01100StreamingService" in code, svc and config file together.
Public Class SAM01100StreamingService
    Implements ISAM01100StreamingService

    Public Function getMenuList() As System.ServiceModel.Channels.Message Implements ISAM01100StreamingService.getMenuList
        Dim loException As New R_Exception
        Dim loCls As New SAM01100Cls
        Dim loRtnTemp As List(Of SAM01100GridDTO)
        Dim loRtn As Message
        Dim lcCompId As String

        Try
            lcCompId = R_Utility.R_GetStreamingContext("cCompId")

            loRtnTemp = loCls.getMenuList(lcCompId)

            loRtn = R_StreamUtility(Of SAM01100GridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getMenuList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function getMenuProgramList() As System.ServiceModel.Channels.Message Implements ISAM01100StreamingService.getMenuProgramList
        Dim loException As New R_Exception
        Dim loCls As New SAM01100Cls
        Dim loRtnTemp As List(Of SAM01100MenuProgramDTOnon)
        Dim loRtn As Message
        Dim lcCompId As String
        Dim lcMenuId As String

        Try
            lcCompId = R_Utility.R_GetStreamingContext("cCompId")
            lcMenuId = R_Utility.R_GetStreamingContext("cMenuId")

            loRtnTemp = loCls.getMenuProgramList(lcCompId, lcMenuId)

            loRtn = R_StreamUtility(Of SAM01100MenuProgramDTOnon).WriteToMessage(loRtnTemp.AsEnumerable, "getMenuProgramList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function getProgramList() As System.ServiceModel.Channels.Message Implements ISAM01100StreamingService.getProgramList
        Dim loException As New R_Exception
        Dim loCls As New SAM01100Cls
        Dim loRtnTemp As List(Of ProgramDTO)
        Dim loRtn As Message

        Try
            loRtnTemp = loCls.getProgramList()

            loRtn = R_StreamUtility(Of ProgramDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getProgramList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub Dummy(poPar As System.Collections.Generic.List(Of SAM01100Back.SAM01100GridDTO), poPar1 As System.Collections.Generic.List(Of SAM01100Back.SAM01100MenuProgramDTOnon), poPar2 As System.Collections.Generic.List(Of SAM01100Back.ProgramDTO), poPar3 As System.Collections.Generic.List(Of SAM01100Back.ButtonDTO)) Implements ISAM01100StreamingService.Dummy

    End Sub

    Public Function getProgramButton() As System.ServiceModel.Channels.Message Implements ISAM01100StreamingService.getProgramButton
        Dim loException As New R_Exception
        Dim loCls As New SAM01100Cls
        Dim loRtnTemp As List(Of ButtonDTO)
        Dim loRtn As Message
        Dim lcProgId As String
        Dim lcCompId As String
        Dim lcMenuId As String

        Try
            lcProgId = R_Utility.R_GetStreamingContext("ProgID")
            lcCompId = R_Utility.R_GetStreamingContext("CompID")
            lcMenuId = R_Utility.R_GetStreamingContext("MenuID")

            loRtnTemp = loCls.getProgramButton(lcProgId, lcCompId, lcMenuId)

            loRtn = R_StreamUtility(Of ButtonDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getProgramButton")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
