﻿Imports System.ServiceModel
Imports R_BackEnd
Imports CSM00400Back
Imports R_Common
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00400Service" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00400Service
    Inherits R_IServicebase(Of CSM00400DTO)

    <OperationContract(Action:="getSourceGroupCombo", ReplyAction:="getSourceGroupCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetSourceGroupCombo(companyId As String, appsCode As String, attributeGroup As String, attributeId As String) As List(Of RCustDBSourceGroupComboDTO)

    <OperationContract(Action:="generateSource", ReplyAction:="generateSource")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub GenerateSource(poKey As List(Of CSM00400KeyDTO))

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function Dummy1() As List(Of CSM00400KeyDTO)

End Interface
