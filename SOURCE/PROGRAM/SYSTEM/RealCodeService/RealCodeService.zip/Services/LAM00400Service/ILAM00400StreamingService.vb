﻿Imports System.ServiceModel
Imports R_Common
Imports LAM00400Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ILAM00400StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ILAM00400StreamingService

    <OperationContract(Action:="getAvailableLicenseMode", ReplyAction:="getAvailableLicenseMode")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function getAvailableLicenseMode() As Message

    <OperationContract(Action:="getSelectedLicenseMode", ReplyAction:="getSelectedLicenseMode")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function getSelectedLicenseMode() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of LicenseModeDTO))

End Interface
