﻿' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00700StreamingService" in code, svc and config file together.
' NOTE: In order to launch WCF Test Client for testing this service, please select CSM00700StreamingService.svc or CSM00700StreamingService.svc.vb at the Solution Explorer and start debugging.
Imports System.ServiceModel.Channels
Imports CSM00700Back
Imports R_Common
Imports RLicenseService

Public Class CSM00700StreamingService
    Implements ICSM00700StreamingService

    Public Sub Dummy(poPar1 As List(Of CSM00700DatabaseGridDTO), poPar2 As List(Of CSM00700DbTablesGridDTO), poPar3 As List(Of CSM00700DbColumnsGridDTO)) Implements ICSM00700StreamingService.Dummy
        Throw New NotImplementedException()
    End Sub

    Public Function GetDatabaseList() As Message Implements ICSM00700StreamingService.GetDatabaseList
        Dim loException As New R_Exception
        Dim loCls As New CSM00700DatabaseCls
        Dim loRtnTemp As List(Of CSM00700DatabaseGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00700KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
            End With

            loRtnTemp = loCls.GetDatabaseList(loTableKey)

            loRtn = R_StreamUtility(Of CSM00700DatabaseGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getDatabaseList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetTableList() As Message Implements ICSM00700StreamingService.GetTableList
        Dim loException As New R_Exception
        Dim loCls As New CSM00700DatabaseCls
        Dim loRtnTemp As List(Of CSM00700DbTablesGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00700KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CDATABASE_ID = R_Utility.R_GetStreamingContext("cDatabaseID")
            End With

            loRtnTemp = loCls.GetTableList(loTableKey)

            loRtn = R_StreamUtility(Of CSM00700DbTablesGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getTableList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetColumnList() As Message Implements ICSM00700StreamingService.GetColumnList
        Dim loException As New R_Exception
        Dim loCls As New CSM00700DatabaseCls
        Dim loRtnTemp As List(Of CSM00700DbColumnsGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00700KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CDATABASE_ID = R_Utility.R_GetStreamingContext("cDatabaseID")
                .CTABLE_NAME = R_Utility.R_GetStreamingContext("cTableName")
            End With

            loRtnTemp = loCls.GetColumnList(loTableKey)

            loRtn = R_StreamUtility(Of CSM00700DbColumnsGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getColumnList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
