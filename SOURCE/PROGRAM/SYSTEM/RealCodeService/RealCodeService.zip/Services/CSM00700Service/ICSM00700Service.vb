﻿Imports System.ServiceModel
Imports CSM00700Back
Imports R_BackEnd
Imports R_Common
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00700Service" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00700Service
    Inherits R_IServicebase(Of CSM00700DatabaseDTO)

    <OperationContract(Action:="getAppCombo", ReplyAction:="getAppCombo")>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function GetAppCombo(companyId As String, userId As String) As List(Of RLicenseAppComboDTO)

    <OperationContract(Action:="addDatabase", ReplyAction:="addDatabase")>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function AddDatabase(ByVal poKey As CSM00700DatabaseDTO) As String

    <OperationContract()>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function Dummy(poPar1 As CSM00700DbTablesDTO,
                   poPar2 As CSM00700DbColumnsDTO) As List(Of CSM00700KeyDTO)

End Interface
