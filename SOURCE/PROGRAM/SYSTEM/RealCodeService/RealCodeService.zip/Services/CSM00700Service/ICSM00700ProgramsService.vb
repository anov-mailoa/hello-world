﻿Imports System.ServiceModel
Imports CSM00700Back
Imports R_BackEnd
Imports R_Common
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00700ProgramsService" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00700ProgramsService
    Inherits R_IServicebase(Of CSM00700DbProgramsDTO)

    <OperationContract(Action:="getAttributeCombo", ReplyAction:="getAttributeCombo")>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function GetAttributeCombo(companyId As String, appsCode As String, attributeGroup As String) As List(Of RCustDBAttributeComboDTO)

    <OperationContract(Action:="getAttributeGroupCombo", ReplyAction:="getAttributeGroupCombo")>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function GetAttributeGroupCombo(companyId As String, appsCode As String) As List(Of RCustDBAttributeGroupComboDTO)

End Interface
