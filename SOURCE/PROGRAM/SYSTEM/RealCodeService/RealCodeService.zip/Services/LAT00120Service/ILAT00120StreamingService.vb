﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports LAT00100Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ILAT00120StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ILAT00120StreamingService

    <OperationContract(Action:="getActivationData", ReplyAction:="getActivationData")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetActivationData() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of LAT00100ActivationGridDTO))

End Interface
