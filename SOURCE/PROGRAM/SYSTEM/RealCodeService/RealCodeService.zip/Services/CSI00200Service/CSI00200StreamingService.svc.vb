﻿Imports R_Common
Imports CSI00200Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSI00200StreamingService" in code, svc and config file together.
Public Class CSI00200StreamingService
    Implements ICSI00200StreamingService

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of CSI00200Back.CSI00200IssueStatusDTO), poPar2 As System.Collections.Generic.List(Of CSI00200Back.CSI00200AssignmentDTO)) Implements ICSI00200StreamingService.Dummy

    End Sub

    Public Function GetAssignment() As System.ServiceModel.Channels.Message Implements ICSI00200StreamingService.GetAssignment
        Dim loException As New R_Exception
        Dim loCls As New CSI00200Cls
        Dim loRtnTemp As List(Of CSI00200AssignmentDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSI00200ParamDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .CPROJECT_ID = R_Utility.R_GetStreamingContext("cProjectId")
                .CSESSION_ID = R_Utility.R_GetStreamingContext("cSessionId")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CATTRIBUTE_ID = R_Utility.R_GetStreamingContext("cAttributeId")
                .CITEM_ID = R_Utility.R_GetStreamingContext("cItemId")
                .CISSUE_ID = R_Utility.R_GetStreamingContext("cIssueId")
            End With

            loRtnTemp = loCls.GetAssignment(loTableKey)

            loRtn = R_StreamUtility(Of CSI00200AssignmentDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getAssignment")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetIssueStatus() As System.ServiceModel.Channels.Message Implements ICSI00200StreamingService.GetIssueStatus
        Dim loException As New R_Exception
        Dim loCls As New CSI00200Cls
        Dim loRtnTemp As List(Of CSI00200IssueStatusDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSI00200ParamDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .CPROJECT_ID = R_Utility.R_GetStreamingContext("cProjectId")
                .CSESSION_ID = R_Utility.R_GetStreamingContext("cSessionId")
                .LOUTSTANDING = R_Utility.R_GetStreamingContext("lOutstanding")
                .COPTION = R_Utility.R_GetStreamingContext("cOption")
                .CUSER_ID = R_Utility.R_GetStreamingContext("cUserId")
            End With

            loRtnTemp = loCls.GetIssueStatus(loTableKey)

            loRtn = R_StreamUtility(Of CSI00200IssueStatusDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getIssueStatus")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
