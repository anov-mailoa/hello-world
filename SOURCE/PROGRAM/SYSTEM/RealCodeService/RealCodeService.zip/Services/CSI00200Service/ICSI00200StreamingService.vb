﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports CSI00200Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSI00200StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ICSI00200StreamingService

    <OperationContract(Action:="getIssueStatus", ReplyAction:="getIssueStatus")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetIssueStatus() As Message

    <OperationContract(Action:="getAssignment", ReplyAction:="getAssignment")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAssignment() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of CSI00200IssueStatusDTO), ByVal poPar2 As List(Of CSI00200AssignmentDTO))

End Interface
