﻿Imports R_Common
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSI00200Service" in code, svc and config file together.
Public Class CSI00200Service
    Implements ICSI00200Service

    Public Sub Dummy1(poPar1 As CSI00200Back.CSI00200ParamDTO) Implements ICSI00200Service.Dummy1

    End Sub

    Public Function GetAppCombo(companyId As String, userId As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseAppComboDTO) Implements ICSI00200Service.GetAppCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseAppComboDTO)

        Try
            loRtn = loCls.GetAppCombo(companyId, userId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetProjectCombo(key As RLicenseBack.RCustDBProjectKeyDTO) As System.Collections.Generic.List(Of RLicenseBack.RCustDBProjectComboDTO) Implements ICSI00200Service.GetProjectCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBProjectComboDTO)

        Try
            loRtn = loCls.GetProjectCombo(key)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetSessionCombo(key As RLicenseBack.RCustDBProjectKeyDTO) As System.Collections.Generic.List(Of RLicenseBack.RCustDBSessionComboDTO) Implements ICSI00200Service.GetSessionCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBSessionComboDTO)

        Try
            loRtn = loCls.GetSessionCombo(key)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetVersionCombo(companyId As String, appsCode As String) As System.Collections.Generic.List(Of RLicenseBack.RCustDBVersionComboDTO) Implements ICSI00200Service.GetVersionCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBVersionComboDTO)

        Try
            loRtn = loCls.GetVersionCombo(companyId, appsCode)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
