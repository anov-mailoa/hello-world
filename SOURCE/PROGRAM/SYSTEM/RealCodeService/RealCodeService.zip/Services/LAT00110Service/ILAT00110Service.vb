﻿Imports System.ServiceModel
Imports LAT00110Back
Imports R_Common
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ILAT00110Service" in both code and config file together.
<ServiceContract()>
Public Interface ILAT00110Service

    <OperationContract(Action:="getAppCombo", ReplyAction:="getAppCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAppCombo(companyId As String, userId As String) As List(Of RLicenseAppComboDTO)

    <OperationContract(Action:="activationRequest", ReplyAction:="activationRequest")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function ActivationRequest(poPar As ActivationRequestParamDTO) As ActivationRequestReturnDTO

    <OperationContract(Action:="activationStatus", ReplyAction:="activationStatus")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function ActivationStatus(poPar As ActivationStatusParamDTO) As ActivationStatusReturnDTO

    <OperationContract(Action:="activationCodeInstall", ReplyAction:="activationCodeInstall")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function ActivationCodeInstall(poPar As ActivationCodeInstallParamDTO) As ActivationCodeInstallReturnDTO

End Interface
