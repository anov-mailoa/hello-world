﻿Imports R_Common
Imports LAM00200Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "LAM00200StreamingService" in code, svc and config file together.
Public Class LAM00200StreamingService
    Implements ILAM00200StreamingService

    Public Function GetCustList() As System.ServiceModel.Channels.Message Implements ILAM00200StreamingService.GetCustList
        Dim loException As New R_Exception
        Dim loCls As New LAM00200Cls
        Dim loRtnTemp As List(Of LAM00200GridDTO)
        Dim loRtn As Message
        Dim lcCompId As String

        Try
            lcCompId = R_Utility.R_GetStreamingContext("cCompId")

            loRtnTemp = loCls.getCustList(lcCompId)

            loRtn = R_StreamUtility(Of LAM00200GridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getCustList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetCustGrpList() As System.ServiceModel.Channels.Message Implements ILAM00200StreamingService.GetCustGrpList
        Dim loException As New R_Exception
        Dim loCls As New LAM00200Cls
        Dim loRtnTemp As List(Of LAM00200CustGrpDTO)
        Dim loRtn As Message

        Try

            loRtnTemp = loCls.getCustGrpList()

            loRtn = R_StreamUtility(Of LAM00200CustGrpDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getCustGrpList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of LAM00200Back.LAM00200GridDTO), poPar2 As System.Collections.Generic.List(Of LAM00200Back.LAM00200CustGrpDTO), poPar3 As System.Collections.Generic.List(Of LAM00200Back.LAM00200ContactGridDTO)) Implements ILAM00200StreamingService.Dummy

    End Sub

    Public Function GetCustContactList() As System.ServiceModel.Channels.Message Implements ILAM00200StreamingService.GetCustContactList
        Dim loException As New R_Exception
        Dim loCls As New LAM00200ContactCls
        Dim loRtnTemp As List(Of LAM00200ContactGridDTO)
        Dim loRtn As Message
        Dim lcCompId As String
        Dim lcCustCode As String

        Try
            lcCompId = R_Utility.R_GetStreamingContext("cCompId")
            lcCustCode = R_Utility.R_GetStreamingContext("cCustCode")

            loRtnTemp = loCls.getCustContactList(lcCompId, lcCustCode)

            loRtn = R_StreamUtility(Of LAM00200ContactGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getCustContactList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
