﻿Imports System.ServiceModel
Imports R_Common
Imports LAM00200Back
Imports System.ServiceModel.Channels
' NOTE: You can use the "Rename" command on the context menu to change the interface name "ILAM00200StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ILAM00200StreamingService

    <OperationContract(Action:="getCustList", ReplyAction:="getCustList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetCustList() As Message

    <OperationContract(Action:="getCustGrpList", ReplyAction:="getCustGrpList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetCustGrpList() As Message

    <OperationContract(Action:="getCustContactList", ReplyAction:="getCustContactList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetCustContactList() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of LAM00200GridDTO),
              ByVal poPar2 As List(Of LAM00200CustGrpDTO),
              ByVal poPar3 As List(Of LAM00200ContactGridDTO))

End Interface
