﻿Imports R_Common
Imports LAM00200Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "LAM00200Service" in code, svc and config file together.
Public Class LAM00200Service
    Implements ILAM00200Service

    Public Sub Svc_R_Delete(poEntity As LAM00200Back.LAM00200DTO) Implements R_BackEnd.R_IServicebase(Of LAM00200Back.LAM00200DTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New LAM00200Cls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As LAM00200Back.LAM00200DTO) As LAM00200Back.LAM00200DTO Implements R_BackEnd.R_IServicebase(Of LAM00200Back.LAM00200DTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New LAM00200Cls
        Dim loRtn As LAM00200DTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As LAM00200Back.LAM00200DTO, poCRUDMode As R_Common.eCRUDMode) As LAM00200Back.LAM00200DTO Implements R_BackEnd.R_IServicebase(Of LAM00200Back.LAM00200DTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New LAM00200Cls
        Dim loRtn As LAM00200DTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
