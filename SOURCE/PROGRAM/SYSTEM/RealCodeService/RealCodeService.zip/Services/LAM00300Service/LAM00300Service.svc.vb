﻿Imports R_Common
Imports RLicenseBack
Imports LAM00300Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "LAM00300Service" in code, svc and config file together.
Public Class LAM00300Service
    Implements ILAM00300Service

    Public Sub Svc_R_Delete(poEntity As LAM00300Back.LAM00300DTO) Implements R_BackEnd.R_IServicebase(Of LAM00300Back.LAM00300DTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New LAM00300Cls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As LAM00300Back.LAM00300DTO) As LAM00300Back.LAM00300DTO Implements R_BackEnd.R_IServicebase(Of LAM00300Back.LAM00300DTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New LAM00300Cls
        Dim loRtn As LAM00300DTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As LAM00300Back.LAM00300DTO, poCRUDMode As R_Common.eCRUDMode) As LAM00300Back.LAM00300DTO Implements R_BackEnd.R_IServicebase(Of LAM00300Back.LAM00300DTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New LAM00300Cls
        Dim loRtn As LAM00300DTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetAppCombo(companyId As String, userId As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseAppComboDTO) Implements ILAM00300Service.GetAppCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseAppComboDTO)

        Try
            loRtn = loCls.GetAppCombo(companyId, userId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetCustCombo(companyId As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseCustComboDTO) Implements ILAM00300Service.GetCustCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseCustComboDTO)

        Try
            loRtn = loCls.GetCustCombo(companyId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
