﻿Imports System.ServiceModel
Imports LAM00300Back
Imports RLicenseBack
Imports R_BackEnd
Imports R_Common

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ILAM00300Service" in both code and config file together.
<ServiceContract()>
Public Interface ILAM00300Service
    Inherits R_IServicebase(Of LAM00300DTO)

    <OperationContract(Action:="getAppCombo", ReplyAction:="getAppCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAppCombo(companyId As String, userId As String) As List(Of RLicenseAppComboDTO)

    <OperationContract(Action:="getCustCombo", ReplyAction:="getCustCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetCustCombo(companyId As String) As List(Of RLicenseCustComboDTO)

End Interface
