﻿Imports R_Common
Imports RLicenseBack
Imports LAT00100Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "LAT00100Service" in code, svc and config file together.
Public Class LAT00100Service
    Implements ILAT00100Service

    Public Function GetAppCombo(companyId As String, userId As String) As System.Collections.Generic.List(Of LAT00100Back.LAT00100AppComboDTO) Implements ILAT00100Service.GetAppCombo
        Dim loException As New R_Exception
        Dim loCls As New LAT00100Cls
        Dim loRtn As List(Of LAT00100AppComboDTO)

        Try
            loRtn = loCls.GetAppCombo(companyId, userId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetCustCombo(companyId As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseCustComboDTO) Implements ILAT00100Service.GetCustCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseCustComboDTO)

        Try
            loRtn = loCls.GetCustCombo(companyId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetLicenseMode(companyId As String) As System.Collections.Generic.List(Of String) Implements ILAT00100Service.GetLicenseMode
        Dim loException As New R_Exception
        Dim loCls As New LAT00100Cls
        Dim loRtn As List(Of String)

        Try
            loRtn = loCls.GetLicenseMode(companyId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub SaveLicense(poNewEntity As LAT00100Back.LAT00100LicenseDTO) Implements ILAT00100Service.SaveLicense
        Dim loEx As New R_Exception
        Dim loCls As New LAT00100Cls

        Try
            loCls.SaveLicense(poNewEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Sub SaveActivation(poNewEntity As LAT00100Back.LAT00100ActivationDTO) Implements ILAT00100Service.SaveActivation
        Dim loEx As New R_Exception
        Dim loCls As New LAT00100Cls

        Try
            loCls.SaveActivation(poNewEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function GetServerID(poPar As LAT00100KeyDTO) As String Implements ILAT00100Service.GetServerID
        Dim loException As New R_Exception
        Dim loCls As New LAT00100Cls
        Dim loRtn As String

        Try
            loRtn = loCls.GetServerID(poPar)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Dummy1() As System.Collections.Generic.List(Of LAT00100Back.LAT00100LicenseDTO) Implements ILAT00100Service.Dummy1

    End Function

    Public Function Dummy2() As System.Collections.Generic.List(Of LAT00100Back.LAT00100ActivationDTO) Implements ILAT00100Service.Dummy2

    End Function

    Public Function GetCustAppSetting(poPar As LAT00100Back.LAT00100KeyDTO) As LAT00100Back.LAT00100CustAppDTO Implements ILAT00100Service.GetCustAppSetting
        Dim loException As New R_Exception
        Dim loCls As New LAT00100Cls
        Dim loRtn As LAT00100CustAppDTO

        Try
            loRtn = loCls.GetCustAppSetting(poPar)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetReactivationStatus(poPar As LAT00100Back.LAT00100KeyDTO) As LAT00100Back.LAT00100ReactivationStatusDTO Implements ILAT00100Service.GetReactivationStatus
        Dim loException As New R_Exception
        Dim loCls As New LAT00100Cls
        Dim loRtn As LAT00100ReactivationStatusDTO

        Try
            loRtn = loCls.GetReactivationStatus(poPar)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub ResetReactivationStatus(poTableKey As LAT00100Back.LAT00100KeyDTO) Implements ILAT00100Service.ResetReactivationStatus
        Dim loEx As New R_Exception
        Dim loCls As New LAT00100Cls

        Try
            loCls.ResetReactivationStatus(poTableKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub
End Class
