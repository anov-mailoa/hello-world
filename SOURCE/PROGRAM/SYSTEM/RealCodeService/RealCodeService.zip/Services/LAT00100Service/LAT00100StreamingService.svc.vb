﻿Imports R_Common
Imports System.ServiceModel.Channels
Imports LAT00100Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "LAM00100StreamingService" in code, svc and config file together.
Public Class LAT00100StreamingService
    Implements ILAT00100StreamingService

    Public Function GetLicenseData() As System.ServiceModel.Channels.Message Implements ILAT00100StreamingService.GetLicenseData
        Dim loException As New R_Exception
        Dim loCls As New LAT00100Cls
        Dim loRtnTemp As List(Of LAT00100LicenseGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New LAT00100KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CCUSTOMER_CODE = R_Utility.R_GetStreamingContext("cCustomerCode")
                .CSERVER_TYPE = R_Utility.R_GetStreamingContext("cServerType")
            End With

            loRtnTemp = loCls.GetLicenseData(loTableKey)

            loRtn = R_StreamUtility(Of LAT00100LicenseGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getLicenseData")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn

    End Function

    Public Function GetActivationData() As System.ServiceModel.Channels.Message Implements ILAT00100StreamingService.GetActivationData
        Dim loException As New R_Exception
        Dim loCls As New LAT00100Cls
        Dim loRtnTemp As List(Of LAT00100ActivationGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New LAT00100KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CCUSTOMER_CODE = R_Utility.R_GetStreamingContext("cCustomerCode")
                .CSERVER_TYPE = R_Utility.R_GetStreamingContext("cServerType")
            End With

            loRtnTemp = loCls.GetActivationData(loTableKey)

            loRtn = R_StreamUtility(Of LAT00100ActivationGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getActivationData")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of LAT00100Back.LAT00100LicenseGridDTO), poPar2 As System.Collections.Generic.List(Of LAT00100Back.LAT00100ActivationGridDTO)) Implements ILAT00100StreamingService.Dummy

    End Sub
End Class
