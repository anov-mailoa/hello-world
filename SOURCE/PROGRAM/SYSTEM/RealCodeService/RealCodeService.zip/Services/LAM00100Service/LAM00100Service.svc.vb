﻿Imports R_Common
Imports LAM00100Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "LAM00100Service" in code, svc and config file together.
Public Class LAM00100Service
    Implements ILAM00100Service

    Public Sub Svc_R_Delete(poEntity As LAM00100Back.LAM00100DTO) Implements R_BackEnd.R_IServicebase(Of LAM00100Back.LAM00100DTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New LAM00100Cls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As LAM00100Back.LAM00100DTO) As LAM00100Back.LAM00100DTO Implements R_BackEnd.R_IServicebase(Of LAM00100Back.LAM00100DTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New LAM00100Cls
        Dim loRtn As LAM00100DTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As LAM00100Back.LAM00100DTO, poCRUDMode As R_Common.eCRUDMode) As LAM00100Back.LAM00100DTO Implements R_BackEnd.R_IServicebase(Of LAM00100Back.LAM00100DTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New LAM00100Cls
        Dim loRtn As LAM00100DTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

End Class
