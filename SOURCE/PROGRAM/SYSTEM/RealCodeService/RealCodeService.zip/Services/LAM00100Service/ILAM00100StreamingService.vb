﻿Imports System.ServiceModel
Imports R_Common
Imports LAM00100Back
Imports System.ServiceModel.Channels
' NOTE: You can use the "Rename" command on the context menu to change the interface name "ILAM00100StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ILAM00100StreamingService

    <OperationContract(Action:="getAppList", ReplyAction:="getAppList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAppList() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar As List(Of LAM00100GridDTO))

End Interface
