﻿Imports System.ServiceModel
Imports R_Common
Imports RLicenseBack
Imports CSI00100Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSI00100Service" in both code and config file together.
<ServiceContract()>
Public Interface ICSI00100Service

    <OperationContract(Action:="getAppCombo", ReplyAction:="getAppCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAppCombo(companyId As String, userId As String) As List(Of RLicenseAppComboDTO)

    <OperationContract(Action:="getVersionCombo", ReplyAction:="getVersionCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetVersionCombo(companyId As String, appsCode As String) As List(Of RCustDBVersionComboDTO)

    <OperationContract(Action:="getProjectCombo", ReplyAction:="getProjectCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetProjectCombo(key As RCustDBProjectKeyDTO) As List(Of RCustDBProjectComboDTO)

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy1(poPar1 As CSI00100ParamDTO)

End Interface
