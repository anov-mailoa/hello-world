﻿Imports R_Common
Imports CSI00100Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSI00100StreamingService" in code, svc and config file together.
Public Class CSI00100StreamingService
    Implements ICSI00100StreamingService

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of CSI00100Back.CSI00100ProjectStatusDTO), poPar2 As System.Collections.Generic.List(Of CSI00100Back.CSI00100ActionLogDTO)) Implements ICSI00100StreamingService.Dummy

    End Sub

    Public Function GetActionLog() As System.ServiceModel.Channels.Message Implements ICSI00100StreamingService.GetActionLog
        Dim loException As New R_Exception
        Dim loCls As New CSI00100Cls
        Dim loRtnTemp As List(Of CSI00100ActionLogDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSI00100ParamDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .CPROJECT_ID = R_Utility.R_GetStreamingContext("cProjectId")
                .CSESSION_ID = R_Utility.R_GetStreamingContext("cSessionId")
                .CSCHEDULE_ID = R_Utility.R_GetStreamingContext("cScheduleId")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CATTRIBUTE_ID = R_Utility.R_GetStreamingContext("cAttributeId")
                .CITEM_ID = R_Utility.R_GetStreamingContext("cItemId")
                .CFUNCTION_ID = R_Utility.R_GetStreamingContext("cFunctionId")
            End With

            loRtnTemp = loCls.GetActionLog(loTableKey)

            loRtn = R_StreamUtility(Of CSI00100ActionLogDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getActionLog")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetProjectStatus() As System.ServiceModel.Channels.Message Implements ICSI00100StreamingService.GetProjectStatus
        Dim loException As New R_Exception
        Dim loCls As New CSI00100Cls
        Dim loRtnTemp As List(Of CSI00100ProjectStatusDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSI00100ParamDTO

        Dim loTest As New CSI00100ProjectStatusDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .CPROJECT_ID = R_Utility.R_GetStreamingContext("cProjectId")
                .CUSER_ID = R_Utility.R_GetStreamingContext("cUserId")
                .COPTION = R_Utility.R_GetStreamingContext("cOption")
            End With

            loRtnTemp = loCls.GetProjectStatus(loTableKey)

            loRtn = R_StreamUtility(Of CSI00100ProjectStatusDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getProjectStatus")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn

    End Function
End Class
