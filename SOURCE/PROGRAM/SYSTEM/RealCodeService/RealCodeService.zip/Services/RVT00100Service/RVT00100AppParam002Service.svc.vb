﻿Imports R_Common
Imports RVT00100Back
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the class name "RVT00100AppParam002Service" in code, svc and config file together.
Public Class RVT00100AppParam002Service
    Implements IRVT00100AppParam002Service

    Public Sub Svc_R_Delete(poEntity As RVT00100Back.RVT00100AppParam002DTO) Implements R_BackEnd.R_IServicebase(Of RVT00100Back.RVT00100AppParam002DTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New RVT00100AppParam002Cls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As RVT00100Back.RVT00100AppParam002DTO) As RVT00100Back.RVT00100AppParam002DTO Implements R_BackEnd.R_IServicebase(Of RVT00100Back.RVT00100AppParam002DTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New RVT00100AppParam002Cls
        Dim loRtn As RVT00100AppParam002DTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As RVT00100Back.RVT00100AppParam002DTO, poCRUDMode As R_Common.eCRUDMode) As RVT00100Back.RVT00100AppParam002DTO Implements R_BackEnd.R_IServicebase(Of RVT00100Back.RVT00100AppParam002DTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New RVT00100AppParam002Cls
        Dim loRtn As RVT00100AppParam002DTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetAttributeCombo(companyId As String, appsCode As String, attributeGroup As String) As System.Collections.Generic.List(Of RLicenseBack.RCustDBAttributeComboDTO) Implements IRVT00100AppParam002Service.GetAttributeCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBAttributeComboDTO)

        Try
            loRtn = loCls.GetAttributeCombo(companyId, appsCode, attributeGroup)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetAttributeGroupCombo(companyId As String, appsCode As String) As System.Collections.Generic.List(Of RLicenseBack.RCustDBAttributeGroupComboDTO) Implements IRVT00100AppParam002Service.GetAttributeGroupCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBAttributeGroupComboDTO)

        Try
            loRtn = loCls.GetAttributeGroupCombo(companyId, appsCode)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetSourceGroupCombo(companyId As String, appsCode As String, attributeGroup As String, attributeId As String) As System.Collections.Generic.List(Of RLicenseBack.RCustDBSourceGroupComboDTO) Implements IRVT00100AppParam002Service.GetSourceGroupCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBSourceGroupComboDTO)

        Try
            loRtn = loCls.GetSourceGroupCombo(companyId, appsCode, attributeGroup, attributeId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
