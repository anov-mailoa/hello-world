﻿Imports System.ServiceModel
Imports R_BackEnd
Imports RVT00100Back
Imports R_Common
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IRVT00100AppParam002Service" in both code and config file together.
<ServiceContract()>
Public Interface IRVT00100AppParam002Service
    Inherits R_IServicebase(Of RVT00100AppParam002DTO)

    <OperationContract(Action:="getAttributeCombo", ReplyAction:="getAttributeCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAttributeCombo(companyId As String, appsCode As String, attributeGroup As String) As List(Of RCustDBAttributeComboDTO)

    <OperationContract(Action:="getAttributeGroupCombo", ReplyAction:="getAttributeGroupCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAttributeGroupCombo(companyId As String, appsCode As String) As List(Of RCustDBAttributeGroupComboDTO)

    <OperationContract(Action:="getSourceGroupCombo", ReplyAction:="getSourceGroupCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetSourceGroupCombo(companyId As String, appsCode As String, attributeGroup As String, attributeId As String) As List(Of RCustDBSourceGroupComboDTO)

End Interface
