﻿Imports System.ServiceModel
Imports R_BackEnd
Imports RVT00100Back
Imports R_Common

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IRVT00100IncludeService" in both code and config file together.
<ServiceContract()>
Public Interface IRVT00100IncludeService
    Inherits R_IServicebase(Of RVT00100IncludeDTO)

    <OperationContract(Action:="getProviderCombo", ReplyAction:="getProviderCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetProviderCombo(pcCompanyID As String) As List(Of RVT00100ProviderComboDTO)

    <OperationContract(Action:="getAppVersionCombo", ReplyAction:="getAppVersionCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAppVersionCombo(poTableKey As RVT00100GridDTO) As List(Of RVT00100AppVersionComboDTO)

End Interface
