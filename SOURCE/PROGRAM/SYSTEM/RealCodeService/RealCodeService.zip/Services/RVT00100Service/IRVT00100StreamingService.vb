﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports RVT00100Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IRVT00100StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface IRVT00100StreamingService

    <OperationContract(Action:="getVersions", ReplyAction:="getVersions")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetVersions() As Message

    <OperationContract(Action:="getRevisions", ReplyAction:="getRevisions")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetRevisions() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of RVT00100GridDTO), ByVal poPar2 As List(Of RVT00100RevisionGridDTO))

End Interface
