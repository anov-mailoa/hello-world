﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports RVT00100Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IRVT00100IncludeStreamingService" in both code and config file together.
<ServiceContract()>
Public Interface IRVT00100IncludeStreamingService

    <OperationContract(Action:="getIncludes", ReplyAction:="getIncludes")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetIncludes() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of RVT00100IncludeGridDTO))

End Interface
