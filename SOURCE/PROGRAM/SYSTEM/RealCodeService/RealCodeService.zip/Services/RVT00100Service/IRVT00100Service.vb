﻿Imports System.ServiceModel
Imports R_BackEnd
Imports RVT00100Back
Imports R_Common
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IRVT00100Service" in both code and config file together.
<ServiceContract()>
Public Interface IRVT00100Service
    Inherits R_IServicebase(Of RVT00100DTO)

    <OperationContract(Action:="releaseVersion", ReplyAction:="releaseVersion")>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function ReleaseVersion(ByVal poProcessParam As RVT00100ReleaseDTO) As List(Of RVT00100SerialFilesDTO)

    <OperationContract(Action:="getAppCombo", ReplyAction:="getAppCombo")>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function GetAppCombo(companyId As String, userId As String, endProduct As String) As List(Of RLicenseAppComboDTO)

    <OperationContract(Action:="createVersion", ReplyAction:="createVersion")>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function CreateVersion(ByVal poKey As RVT00100CrVerDTO) As String

    <OperationContract(Action:="dumpFiles", ReplyAction:="dumpFiles")>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function DumpFiles(ByVal poProcessParam As RVT00100ReleaseDTO) As List(Of RVT00100SerialFilesDTO)

    <OperationContract(Action:="changeVersionStatus", ReplyAction:="changeVersionStatus")>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function ChangeVersionStatus(ByVal poProcessParam As RVT00100DTO) As String

End Interface
