﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports RVT00100Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IRVT00100AppParam002StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface IRVT00100AppParam002StreamingService

    <OperationContract(Action:="getParameters", ReplyAction:="getParameters")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetParameters() As Message

    <OperationContract(Action:="getItemList", ReplyAction:="getItemList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetItemList() As Message

    <OperationContract(Action:="getSourceGroupList", ReplyAction:="getSourceGroupList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetSourceGroupList() As Message

    <OperationContract(Action:="getSourceList", ReplyAction:="getSourceList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetSourceList() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of RVT00100AppParam002GridDTO), _
              ByVal poPar2 As RVT00100AppParam002KeyDTO, _
              ByVal poPar3 As RVT00100ItemKeyDTO, _
              ByVal poPar4 As List(Of RVT00100ItemListDTO), _
              ByVal poPar5 As List(Of RVT00100SourceGroupListDTO), _
              ByVal poPar6 As List(Of RVT00100SourceListDTO))

End Interface
