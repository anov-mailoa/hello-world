﻿Imports System.ServiceModel
Imports R_Common
Imports SAM01210Back
Imports SAM01200Back
Imports R_BackEnd
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ISAM01210Service" in both code and config file together.
<ServiceContract()>
Public Interface ISAM01210Service
    Inherits R_IServicebase(Of SAM01210DTO)

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function getSMTP(pcCompId As String) As String

    <OperationContract()> _
<FaultContract(GetType(R_ServiceExceptions))> _
    Function getCmbMenu(pcCompId As String) As List(Of cmbDTO)

End Interface
