﻿Imports System.ServiceModel
Imports R_Common
Imports LAT00130Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ILAT00130Service" in both code and config file together.
<ServiceContract()>
Public Interface ILAT00130Service

    <OperationContract(Action:="reactivationRequest", ReplyAction:="reactivationRequest")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function ReactivationRequest(poPar As ReactivationRequestParamDTO) As ReactivationRequestReturnDTO

    <OperationContract(Action:="reactivationComplete", ReplyAction:="reactivationComplete")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function ReactivationComplete(poPar As ReactivationCompleteParamDTO) As ReactivationCompleteReturnDTO

End Interface
