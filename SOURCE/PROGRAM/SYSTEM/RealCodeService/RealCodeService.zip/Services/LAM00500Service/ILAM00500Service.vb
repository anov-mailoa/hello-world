﻿Imports System.ServiceModel
Imports LAM00500Back
Imports R_BackEnd

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ILAM00500Service" in both code and config file together.
<ServiceContract()>
Public Interface ILAM00500Service
    Inherits R_IServicebase(Of LAM00500DTO)

End Interface
