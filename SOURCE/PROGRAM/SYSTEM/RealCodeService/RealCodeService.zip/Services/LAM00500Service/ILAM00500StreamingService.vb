﻿Imports System.ServiceModel
Imports R_Common
Imports LAM00500Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ILAM00500StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ILAM00500StreamingService

    <OperationContract(Action:="getCustGrpList", ReplyAction:="getCustGrpList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetCustGrpList() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of LAM00500GridDTO))



End Interface
