﻿Imports R_Common
Imports CSM00300Back
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00300Service" in code, svc and config file together.
Public Class CSM00300Service
    Implements ICSM00300Service

    Public Sub Svc_R_Delete(poEntity As CSM00300Back.CSM00300DTO) Implements R_BackEnd.R_IServicebase(Of CSM00300Back.CSM00300DTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New CSM00300Cls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As CSM00300Back.CSM00300DTO) As CSM00300Back.CSM00300DTO Implements R_BackEnd.R_IServicebase(Of CSM00300Back.CSM00300DTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New CSM00300Cls
        Dim loRtn As CSM00300DTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As CSM00300Back.CSM00300DTO, poCRUDMode As R_Common.eCRUDMode) As CSM00300Back.CSM00300DTO Implements R_BackEnd.R_IServicebase(Of CSM00300Back.CSM00300DTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New CSM00300Cls
        Dim loRtn As CSM00300DTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Dummy1() As System.Collections.Generic.List(Of CSM00300Back.CSM00300KeyDTO) Implements ICSM00300Service.Dummy1

    End Function

    Public Function GetAppCombo(companyId As String, userId As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseAppComboDTO) Implements ICSM00300Service.GetAppCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseAppComboDTO)

        Try
            loRtn = loCls.GetAppCombo(companyId, userId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetAttributeCombo(companyId As String, appsCode As String, attributeGroup As String) As System.Collections.Generic.List(Of RLicenseBack.RCustDBAttributeComboDTO) Implements ICSM00300Service.GetAttributeCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBAttributeComboDTO)

        Try
            loRtn = loCls.GetAttributeCombo(companyId, appsCode, attributeGroup)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetVersionCombo(companyId As String, appsCode As String) As System.Collections.Generic.List(Of RLicenseBack.RCustDBVersionComboDTO) Implements ICSM00300Service.GetVersionCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBVersionComboDTO)

        Try
            loRtn = loCls.GetVersionCombo(companyId, appsCode)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
