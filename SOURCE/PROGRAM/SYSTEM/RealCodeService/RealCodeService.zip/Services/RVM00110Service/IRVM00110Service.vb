﻿Imports System.ServiceModel
Imports R_BackEnd
Imports RVM00100Back
Imports R_Common

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IRVM00100CustomerService" in both code and config file together.
<ServiceContract()>
Public Interface IRVM00110Service
    Inherits R_IServicebase(Of RVM00100CustomerDTO)

    <OperationContract(Action:="getApplicationCombo", ReplyAction:="getApplicationCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetApplicationCombo(companyId As String, userId As String) As List(Of RVM00100AppComboDTO)


End Interface
