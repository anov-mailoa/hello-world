﻿Imports R_Common
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the class name "FileService" in code, svc and config file together.
Public Class FileService
    Implements IFileService

    Public Function SliceFile(key As RLicenseBack.RCustDBFileKeyDTO) As System.Collections.Generic.List(Of RLicenseBack.RCustDBFileSplitDTO) Implements IFileService.SliceFile
        Dim loException As New R_Exception
        Dim loCls As New FileHandlerCls
        Dim loRtn As List(Of RCustDBFileSplitDTO)

        Try
            loRtn = loCls.SliceFile(key)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetSlicedFile(key As RLicenseBack.RCustDBFileSplitKeyDTO) As RLicenseBack.RCustDBFileDTO Implements IFileService.GetSlicedFile
        Dim loException As New R_Exception
        Dim loCls As New FileHandlerCls
        Dim loRtn As RCustDBFileDTO

        Try
            loRtn = loCls.GetSlicedFile(key)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetFileInfo(key As RLicenseBack.RCustDBFileKeyDTO) As System.Collections.Generic.List(Of RLicenseBack.RCustDBFileInfoDTO) Implements IFileService.GetFileInfo
        Dim loException As New R_Exception
        Dim loCls As New FileHandlerCls
        Dim loRtn As List(Of RCustDBFileInfoDTO)

        Try
            loRtn = loCls.GetItemInfo(key)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub CheckoutStatus(key As List(Of RLicenseBack.RCustDBProcessTransactionDTO)) Implements IFileService.CheckoutStatus
        Dim loException As New R_Exception
        Dim loCls As New FileHandlerCls

        Try
            loCls.CheckoutStatus(key)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Sub CancelCheckoutStatus(key As RLicenseBack.RCustDBProcessTransactionDTO) Implements IFileService.CancelCheckoutStatus
        Dim loException As New R_Exception
        Dim loCls As New FileHandlerCls

        Try
            loCls.CancelCheckoutStatus(key)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function CheckinValidation(key As RLicenseBack.RCustDBProcessTransactionDTO) As System.Collections.Generic.List(Of RLicenseBack.RCustDBProcessValidationDTO) Implements IFileService.CheckinValidation
        Dim loException As New R_Exception
        Dim loCls As New FileHandlerCls
        Dim loRtn As List(Of RCustDBProcessValidationDTO)

        Try
            loRtn = loCls.CheckinValidation(key)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
