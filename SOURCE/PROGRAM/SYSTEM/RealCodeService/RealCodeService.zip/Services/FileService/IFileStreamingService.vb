﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IFileStreamingService" in both code and config file together.
<ServiceContract()>
Public Interface IFileStreamingService

    <OperationContract(Action:="getSourceFile", ReplyAction:="getSourceFile")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetSourceFile() As Message

    <OperationContract(Action:="getCustomerList", ReplyAction:="getCustomerList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetCustomerList() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of RCustDBFileDTO), ByVal poPar2 As RCustDBFileKeyDTO, ByVal poPar3 As List(Of RCustDBCustListDTO))


End Interface
