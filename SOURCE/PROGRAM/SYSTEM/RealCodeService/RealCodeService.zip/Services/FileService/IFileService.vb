﻿Imports System.ServiceModel
Imports R_Common
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IFileService" in both code and config file together.
<ServiceContract()>
Public Interface IFileService

    <OperationContract(Action:="getSlicedFile", ReplyAction:="getSlicedFile")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetSlicedFile(key As RCustDBFileSplitKeyDTO) As RCustDBFileDTO

    <OperationContract(Action:="sliceFile", ReplyAction:="sliceFile")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function SliceFile(key As RCustDBFileKeyDTO) As List(Of RCustDBFileSplitDTO)

    <OperationContract(Action:="getFileInfo", ReplyAction:="getFileInfo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetFileInfo(key As RCustDBFileKeyDTO) As List(Of RCustDBFileInfoDTO)

    <OperationContract(Action:="checkoutStatus", ReplyAction:="checkoutStatus")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub CheckoutStatus(key As List(Of RCustDBProcessTransactionDTO))

    <OperationContract(Action:="cancelCheckoutStatus", ReplyAction:="cancelCheckoutStatus")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub CancelCheckoutStatus(key As RCustDBProcessTransactionDTO)

    <OperationContract(Action:="checkinValidation", ReplyAction:="checkinValidation")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function CheckinValidation(key As RCustDBProcessTransactionDTO) As List(Of RCustDBProcessValidationDTO)

    '' Temp method, for testing only
    '<OperationContract(Action:="getItemSource", ReplyAction:="getItemSource")> _
    '<FaultContract(GetType(R_ServiceExceptions))> _
    'Function GetItemSource(key As RCustDBFileKeyDTO) As List(Of RCustDBFileDTO)

End Interface
