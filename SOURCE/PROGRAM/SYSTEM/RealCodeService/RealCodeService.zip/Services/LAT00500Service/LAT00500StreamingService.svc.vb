﻿Imports R_Common
Imports LAT00500Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "LAT00500StreamingService" in code, svc and config file together.
Public Class LAT00500StreamingService
    Implements ILAT00500StreamingService

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of LAT00500Back.LAT00500GridDTO)) Implements ILAT00500StreamingService.Dummy

    End Sub

    Public Function GetContract() As System.ServiceModel.Channels.Message Implements ILAT00500StreamingService.GetContract
        Dim loException As New R_Exception
        Dim loCls As New LAT00500Cls
        Dim loRtnTemp As List(Of LAT00500GridDTO)
        Dim loRtn As Message
        Dim loTableKey As New LAT00500KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CCUSTOMER_CODE = R_Utility.R_GetStreamingContext("cCustomerCode")
            End With

            loRtnTemp = loCls.GetContract(loTableKey)

            loRtn = R_StreamUtility(Of LAT00500GridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getContract")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
