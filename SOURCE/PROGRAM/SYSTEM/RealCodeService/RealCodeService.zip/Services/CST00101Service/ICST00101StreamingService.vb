﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports RLicenseBack
Imports CST00200Back
Imports CST00101BACK

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICST00101StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ICST00101StreamingService

    <OperationContract(Action:="getItemInbox", ReplyAction:="getItemInbox")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetItemInbox() As Message

    <OperationContract(Action:="getIssueList", ReplyAction:="getIssueList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetIssueList() As Message

    <OperationContract(Action:="getIssueAttachments", ReplyAction:="getIssueAttachments")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetIssueAttachment() As Message

    <OperationContract(Action:="getInboxNotification", ReplyAction:="getInboxNotification")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetInboxNotification() As Message

    <OperationContract(Action:="getItemRestore", ReplyAction:="getItemRestore")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetItemRestore() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of CST00101ItemInboxDTO), _
              ByVal poPar2 As CST00101InboxKeyDTO, _
              ByVal poPar3 As RCustDBIssueListDTO, _
              ByVal poPar4 As RCustDBIssueKeyDTO, _
              ByVal poPar5 As CST00200KeyDTO,
              ByVal poPar6 As CST00200AttachGridDTO, _
              ByVal poPar7 As List(Of RCustDBInboxNotificationDTO), _
              ByVal poPar8 As List(Of RCustDBItemRestoreDTO))
End Interface
