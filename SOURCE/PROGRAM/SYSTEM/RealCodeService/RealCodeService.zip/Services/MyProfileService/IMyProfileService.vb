﻿Imports System.ServiceModel
Imports R_Common
Imports MyProfileBack
Imports R_BackEnd
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IMyProfileService" in both code and config file together.
<ServiceContract()>
Public Interface IMyProfileService

    Inherits R_IServicebase(Of MyProfileDTO)

End Interface
