﻿Imports System.ServiceModel
Imports R_Common
Imports LAM00600Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ILAM00600StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ILAM00600StreamingService

    <OperationContract(Action:="getAppsConfigField", ReplyAction:="getAppsConfigField")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAppsConfigField() As Message

    <OperationContract(Action:="getAppsFieldCombo", ReplyAction:="getAppsFieldCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAppsFieldCombo() As Message

    <OperationContract(Action:="getAvailableFieldName", ReplyAction:="getAvailableFieldName")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function getAvailableFieldName() As Message

    <OperationContract(Action:="getSelectedFieldName", ReplyAction:="getSelectedFieldName")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function getSelectedFieldName() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of LAM00600GridDTO))

End Interface
