﻿Imports System.ServiceModel
Imports R_Common
Imports RLicenseBack
Imports CST00120BACK

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICST00120Service" in both code and config file together.
<ServiceContract()>
Public Interface ICST00120Service

    <OperationContract(Action:="getAppCombo", ReplyAction:="getAppCombo")>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function GetAppCombo(companyId As String, userId As String) As List(Of RLicenseAppComboDTO)

    <OperationContract(Action:="getVersionCombo", ReplyAction:="getVersionCombo")>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function GetVersionCombo(companyId As String, appsCode As String) As List(Of RCustDBVersionComboDTO)

    <OperationContract()>
    <FaultContract(GetType(R_ServiceExceptions))>
    Function Dummy1(key1 As RCustDBProjectKeyDTO) As List(Of RCustDBProcessTransactionDTO)
End Interface
