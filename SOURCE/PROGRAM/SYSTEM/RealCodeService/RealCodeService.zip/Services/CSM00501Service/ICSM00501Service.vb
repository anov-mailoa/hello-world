﻿Imports System.ServiceModel
Imports R_Common
Imports CSM00501Back
Imports CSM00501Back.CSM00501Cls

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00501Service" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00501Service

    <OperationContract(Action:="getHolidayList", ReplyAction:="getHolidayList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetHolidayList(year As String, month As String) As List(Of CSM00501HolidayListDTO)

    <OperationContract(Action:="setHoliday", ReplyAction:="setHoliday")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub SetHoliday(key As CSM00501HolidayCRUDDTO, action As CRUDAction)

End Interface
