﻿Imports R_Common
Imports CSM00501Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00501Service" in code, svc and config file together.
Public Class CSM00501Service
    Implements ICSM00501Service

    Public Function GetHolidayList(year As String, month As String) As System.Collections.Generic.List(Of CSM00501Back.CSM00501HolidayListDTO) Implements ICSM00501Service.GetHolidayList
        Dim loException As New R_Exception
        Dim loCls As New CSM00501Cls
        Dim loRtn As List(Of CSM00501HolidayListDTO)

        Try
            loRtn = loCls.GetHolidayList(year, month)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub SetHoliday(key As CSM00501Back.CSM00501HolidayCRUDDTO, action As CSM00501Back.CSM00501Cls.CRUDAction) Implements ICSM00501Service.SetHoliday
        Dim loException As New R_Exception
        Dim loCls As New CSM00501Cls

        Try
            loCls.SetHoliday(key, action)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

    End Sub

End Class
