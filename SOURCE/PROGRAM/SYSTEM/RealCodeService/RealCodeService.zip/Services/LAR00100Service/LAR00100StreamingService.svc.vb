﻿Imports R_Common
Imports LAR00100Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "LAR00100StreamingService" in code, svc and config file together.
Public Class LAR00100StreamingService
    Implements ILAR00100StreamingService

    'Public Function GetCuco() As System.ServiceModel.Channels.Message Implements ILAR00100StreamingService.GetCuco
    '    Dim loException As New R_Exception
    '    Dim loCls As New LAR00100Cls
    '    Dim loRtnTemp As List(Of LAR00100CuCoDtlDTO)
    '    Dim loRtn As Message
    '    Dim loTableKey As New LAR00100CuCoDtlDTO

    '    Try
    '        With loTableKey
    '            .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
    '            .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
    '            .CCUSTOMER_CODE = R_Utility.R_GetStreamingContext("cCustomerCode")
    '        End With

    '        loRtnTemp = loCls.GetCuCo(loTableKey)

    '        loRtn = R_StreamUtility(Of LAR00100CuCoDtlDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getCuCo")
    '    Catch ex As Exception
    '        loException.Add(ex)
    '    End Try

    '    loException.ConvertAndThrowToServiceExceptionIfErrors()

    '    Return loRtn
    'End Function

    Public Function GetCuCoHistory() As System.ServiceModel.Channels.Message Implements ILAR00100StreamingService.GetCuCoHistory
        Dim loException As New R_Exception
        Dim loCls As New LAR00100Cls
        Dim loRtnTemp As List(Of LAR00100CuCoDtlDTO)
        Dim loRtn As Message
        Dim loTableKey As New LAR00100CuCoDtlDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CCUSTOMER_CODE = R_Utility.R_GetStreamingContext("cCustomerCode")
            End With

            loRtnTemp = loCls.GetCuCoHistory(loTableKey)

            loRtn = R_StreamUtility(Of LAR00100CuCoDtlDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getCuCoHistory")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    'Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of LAR00100Back.LAR00100CuCoDtlDTO)) Implements ILAR00100StreamingService.Dummy

    'End Sub

    'Public Function GetCuco(tableKey As LAR00100Back.LAR00100CuCoDtlDTO) As System.Collections.Generic.List(Of LAR00100Back.LAR00100CuCoDtlDTO) Implements ILAR00100StreamingService.GetCuco
    '    Dim loException As New R_Exception
    '    Dim loCls As New LAR00100Cls
    '    Dim loRtn As List(Of LAR00100CuCoDtlDTO)

    '    Try
    '        loRtn = loCls.GetCuCo(tableKey)
    '    Catch ex As Exception
    '        loException.Add(ex)
    '    End Try

    '    loException.ConvertAndThrowToServiceExceptionIfErrors()
    'End Function

End Class
