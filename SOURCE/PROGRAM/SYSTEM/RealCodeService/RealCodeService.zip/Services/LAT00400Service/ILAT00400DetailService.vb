﻿Imports System.ServiceModel
Imports R_BackEnd
Imports R_Common
Imports LAT00400Back
Imports LAM00600Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ILAT00400DetailService" in both code and config file together.
<ServiceContract()>
Public Interface ILAT00400DetailService
    Inherits R_IServicebase(Of LAT00400CuCoDtlDTO)

    <OperationContract(Action:="getAppsFieldCombo", ReplyAction:="getAppsFieldCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAppsFieldCombo(tableKey As LAM00600KeyDTO) As List(Of LAM00600GridDTO)

End Interface
