﻿Imports R_Common
Imports LAT00400Back
Imports LAM00600Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "LAT00400DetailService" in code, svc and config file together.
Public Class LAT00400DetailService
    Implements ILAT00400DetailService

    Public Sub Svc_R_Delete(poEntity As LAT00400Back.LAT00400CuCoDtlDTO) Implements R_BackEnd.R_IServicebase(Of LAT00400Back.LAT00400CuCoDtlDTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New LAT00400DetailCls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As LAT00400Back.LAT00400CuCoDtlDTO) As LAT00400Back.LAT00400CuCoDtlDTO Implements R_BackEnd.R_IServicebase(Of LAT00400Back.LAT00400CuCoDtlDTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New LAT00400DetailCls
        Dim loRtn As LAT00400CuCoDtlDTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As LAT00400Back.LAT00400CuCoDtlDTO, poCRUDMode As R_Common.eCRUDMode) As LAT00400Back.LAT00400CuCoDtlDTO Implements R_BackEnd.R_IServicebase(Of LAT00400Back.LAT00400CuCoDtlDTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New LAT00400DetailCls
        Dim loRtn As LAT00400CuCoDtlDTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetAppsFieldCombo(tableKey As LAM00600Back.LAM00600KeyDTO) As System.Collections.Generic.List(Of LAM00600Back.LAM00600GridDTO) Implements ILAT00400DetailService.GetAppsFieldCombo
        Dim loException As New R_Exception
        Dim loCls As New LAM00600Cls
        Dim loRtn As List(Of LAM00600GridDTO)

        Try
            loRtn = loCls.GetAppsFieldCombo(tableKey)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
