﻿Imports R_Common
Imports RLicenseBack
Imports LAT00300Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "LAT00300Service" in code, svc and config file together.
Public Class LAT00300Service
    Implements ILAT00300Service

    Public Function GetCustCombo(companyId As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseCustComboDTO) Implements ILAT00300Service.GetCustCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseCustComboDTO)

        Try
            loRtn = loCls.GetCustCombo(companyId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub ChangeCustomerName(poNewEntity As LAT00300Back.LAT00300NameDTO) Implements ILAT00300Service.ChangeCustomerName
        Dim loEx As New R_Exception
        Dim loCls As New LAT00300Cls

        Try
            loCls.ChangeCustomerName(poNewEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Dummy1() As System.Collections.Generic.List(Of LAT00300Back.LAT00300KeyDTO) Implements ILAT00300Service.Dummy1

    End Function
End Class
