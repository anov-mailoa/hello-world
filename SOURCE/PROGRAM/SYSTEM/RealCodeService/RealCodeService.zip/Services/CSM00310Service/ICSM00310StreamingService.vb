﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports CSM00310BACK
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00310StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00310StreamingService

    <OperationContract(Action:="getProgramCustList", ReplyAction:="getProgramCustList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetProgramCustList() As Message

    <OperationContract(Action:="getStandardProgramList", ReplyAction:="getStandardProgramList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetStandardProgramList() As Message

    <OperationContract(Action:="getCustomerList", ReplyAction:="getCustomerList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetCustomerList() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of CSM00310GridDTO), ByVal poPar2 As List(Of RCustDBCustListDTO), ByVal poPar3 As List(Of CSM00310ItemListDTO))

End Interface
