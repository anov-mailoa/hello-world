﻿Imports R_Common
Imports RLicenseBack
Imports CSM00310BACK

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00310Service" in code, svc and config file together.
Public Class CSM00310Service
    Implements ICSM00310Service

    Public Sub Svc_R_Delete(poEntity As CSM00310BACK.CSM00310DTO) Implements R_BackEnd.R_IServicebase(Of CSM00310BACK.CSM00310DTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New CSM00310Cls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As CSM00310BACK.CSM00310DTO) As CSM00310BACK.CSM00310DTO Implements R_BackEnd.R_IServicebase(Of CSM00310BACK.CSM00310DTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New CSM00310Cls
        Dim loRtn As CSM00310DTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As CSM00310BACK.CSM00310DTO, poCRUDMode As R_Common.eCRUDMode) As CSM00310BACK.CSM00310DTO Implements R_BackEnd.R_IServicebase(Of CSM00310BACK.CSM00310DTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New CSM00310Cls
        Dim loRtn As CSM00310DTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Dummy1() As System.Collections.Generic.List(Of CSM00310BACK.CSM00310KeyDTO) Implements ICSM00310Service.Dummy1

    End Function

    Public Function GetAppCombo(companyId As String, userId As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseAppComboDTO) Implements ICSM00310Service.GetAppCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseAppComboDTO)

        Try
            loRtn = loCls.GetAppCombo(companyId, userId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetAttributeCombo(companyId As String, appsCode As String, attributeGroup As String) As System.Collections.Generic.List(Of RLicenseBack.RCustDBAttributeComboDTO) Implements ICSM00310Service.GetAttributeCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBAttributeComboDTO)

        Try
            loRtn = loCls.GetAttributeCombo(companyId, appsCode, attributeGroup)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub AddFromStandard(poProgramList As System.Collections.Generic.List(Of CSM00310BACK.CSM00310AddStdDTO)) Implements ICSM00310Service.AddFromStandard
        Dim loException As New R_Exception
        Dim loCls As New CSM00310Cls

        Try
            loCls.AddFromStandard(poProgramList)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function DumpFiles(poProcessParam As CSM00310BACK.CSM00310ReleaseDTO) As String Implements ICSM00310Service.DumpFiles
        Dim loEx As New R_Exception
        Dim loCls As New CSM00310Cls
        Dim lcRtn As String

        Try
            lcRtn = loCls.DumpFiles(poProcessParam)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
        Return lcRtn
    End Function
End Class
