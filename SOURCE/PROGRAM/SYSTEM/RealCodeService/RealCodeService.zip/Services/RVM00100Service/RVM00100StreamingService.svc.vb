﻿Imports R_Common
Imports RVM00100Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "RVM00100StreamingService" in code, svc and config file together.
Public Class RVM00100StreamingService
    Implements IRVM00100StreamingService

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of RVM00100Back.RVM00100GridDTO)) Implements IRVM00100StreamingService.Dummy

    End Sub

    Public Function GetApplications() As System.ServiceModel.Channels.Message Implements IRVM00100StreamingService.GetApplications
        Dim loException As New R_Exception
        Dim loCls As New RVM00100Cls
        Dim loRtnTemp As List(Of RVM00100GridDTO)
        Dim loRtn As Message
        Dim loTableKey As New RVM00100GridDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
            End With

            loRtnTemp = loCls.GetApplications(loTableKey)

            loRtn = R_StreamUtility(Of RVM00100GridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getApplications")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
