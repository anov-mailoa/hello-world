﻿Imports R_Common
Imports RVM00100Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "RVM00100UserService" in code, svc and config file together.
Public Class RVM00100UserService
    Implements IRVM00100UserService

    Public Sub DeleteItem(key As RVM00100Back.RVM00100UserDTO) Implements IRVM00100UserService.DeleteItem
        Dim loException As New R_Exception
        Dim loCls As New RVM00100UserCls

        Try
            loCls.DeleteItem(key)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub
End Class
