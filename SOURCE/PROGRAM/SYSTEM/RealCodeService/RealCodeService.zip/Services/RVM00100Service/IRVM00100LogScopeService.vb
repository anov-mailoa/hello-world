﻿Imports System.ServiceModel
Imports R_BackEnd
Imports RVM00100Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IRVM00100LogScopeService" in both code and config file together.
<ServiceContract()>
Public Interface IRVM00100LogScopeService
    Inherits R_IServicebase(Of RVM00100LogScopeDTO)

End Interface
