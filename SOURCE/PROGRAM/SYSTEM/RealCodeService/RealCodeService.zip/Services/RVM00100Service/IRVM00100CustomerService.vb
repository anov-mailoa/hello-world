﻿Imports System.ServiceModel
Imports R_BackEnd
Imports RVM00100Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IRVM00100CustomerService" in both code and config file together.
<ServiceContract()>
Public Interface IRVM00100CustomerService
    Inherits R_IServicebase(Of RVM00100CustomerDTO)

End Interface
