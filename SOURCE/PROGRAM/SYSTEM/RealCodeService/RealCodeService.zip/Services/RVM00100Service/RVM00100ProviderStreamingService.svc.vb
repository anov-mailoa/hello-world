﻿Imports R_Common
Imports RVM00100Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "RVM00100ProviderStreamingService" in code, svc and config file together.
Public Class RVM00100ProviderStreamingService
    Implements IRVM00100ProviderStreamingService

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of RVM00100Back.RVM00100ProviderGridDTO)) Implements IRVM00100ProviderStreamingService.Dummy

    End Sub

    Public Function GetAvailableItems() As System.ServiceModel.Channels.Message Implements IRVM00100ProviderStreamingService.GetAvailableItems
        Dim loException As New R_Exception
        Dim loCls As New RVM00100ProviderCls
        Dim loRtnTemp As List(Of RVM00100ProviderGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New RVM00100ProviderDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
            End With

            loRtnTemp = loCls.GetAvailableItems(loTableKey)

            loRtn = R_StreamUtility(Of RVM00100ProviderGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getAvailableItemsList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetSelectedItems() As System.ServiceModel.Channels.Message Implements IRVM00100ProviderStreamingService.GetSelectedItems
        Dim loException As New R_Exception
        Dim loCls As New RVM00100ProviderCls
        Dim loRtnTemp As List(Of RVM00100ProviderGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New RVM00100ProviderDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
            End With

            loRtnTemp = loCls.GetSelectedItems(loTableKey)

            loRtn = R_StreamUtility(Of RVM00100ProviderGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getSelectedItemsList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
