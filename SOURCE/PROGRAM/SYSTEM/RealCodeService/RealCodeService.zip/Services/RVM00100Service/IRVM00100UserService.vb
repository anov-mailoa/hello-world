﻿Imports System.ServiceModel
Imports RVM00100Back
Imports R_Common

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IRVM00100UserService" in both code and config file together.
<ServiceContract()>
Public Interface IRVM00100UserService

    <OperationContract(Action:="deleteItem", ReplyAction:="deleteItem")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub DeleteItem(key As RVM00100UserDTO)

End Interface
