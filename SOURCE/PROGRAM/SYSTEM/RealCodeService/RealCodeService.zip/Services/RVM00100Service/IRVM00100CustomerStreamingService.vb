﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports RVM00100Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IRVM00100CustomerStreamingService" in both code and config file together.
<ServiceContract()>
Public Interface IRVM00100CustomerStreamingService

    <OperationContract(Action:="getApplicationCustomers", ReplyAction:="getApplicationCustomers")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetApplicationCustomers() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of RVM00100CustomerGridDTO))


End Interface
