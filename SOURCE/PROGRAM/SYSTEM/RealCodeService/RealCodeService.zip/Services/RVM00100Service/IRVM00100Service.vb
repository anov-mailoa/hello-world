﻿Imports System.ServiceModel
Imports RVM00100Back
Imports R_BackEnd
Imports R_Common

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IRVM00100Service" in both code and config file together.
<ServiceContract()>
Public Interface IRVM00100Service
    Inherits R_IServicebase(Of RVM00100DTO)

    <OperationContract(Action:="getApplicationTypeCombo", ReplyAction:="getApplicationTypeCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetApplicationTypeCombo() As List(Of RVM00100ApplicationTypeComboDTO)

    <OperationContract(Action:="getActivationTypeCombo", ReplyAction:="getActivationTypeCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetActivationTypeCombo() As List(Of RVM00100ActivationTypeComboDTO)

End Interface
