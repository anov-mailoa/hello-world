﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICST00110StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ICST00110StreamingService

    <OperationContract(Action:="getItemCopySource", ReplyAction:="getItemCopySource")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetItemCopySource() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of RCustDBItemCopySourceDTO))

End Interface
