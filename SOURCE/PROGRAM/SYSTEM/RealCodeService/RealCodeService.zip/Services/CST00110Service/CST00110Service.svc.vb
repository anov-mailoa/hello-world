﻿Imports R_Common
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the class name "CST00110Service" in code, svc and config file together.
Public Class CST00110Service
    Implements ICST00110Service

    Public Function GetAppCombo(companyId As String, userId As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseAppComboDTO) Implements ICST00110Service.GetAppCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseAppComboDTO)

        Try
            loRtn = loCls.GetAppCombo(companyId, userId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetAttributeCombo(companyId As String, appsCode As String, attributeGroup As String) As System.Collections.Generic.List(Of RLicenseBack.RCustDBAttributeComboDTO) Implements ICST00110Service.GetAttributeCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBAttributeComboDTO)

        Try
            loRtn = loCls.GetAttributeCombo(companyId, appsCode, attributeGroup)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetAttributeGroupCombo(companyId As String, appsCode As String) As System.Collections.Generic.List(Of RLicenseBack.RCustDBAttributeGroupComboDTO) Implements ICST00110Service.GetAttributeGroupCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBAttributeGroupComboDTO)

        Try
            loRtn = loCls.GetAttributeGroupCombo(companyId, appsCode)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub Dummy1(key1 As RLicenseBack.RCustDBItemKeyDTO) Implements ICST00110Service.Dummy1

    End Sub

    Public Function GetFunctionCombo(key As RLicenseBack.RCustDBProjectKeyDTO) As System.Collections.Generic.List(Of RLicenseBack.RCustDBFunctionComboDTO) Implements ICST00110Service.GetFunctionCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBFunctionComboDTO)

        Try
            loRtn = loCls.GetFunctionCombo(key)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
