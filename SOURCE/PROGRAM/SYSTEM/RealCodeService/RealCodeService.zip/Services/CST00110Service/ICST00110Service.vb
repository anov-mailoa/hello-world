﻿Imports System.ServiceModel
Imports R_Common
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICST00110Service" in both code and config file together.
<ServiceContract()>
Public Interface ICST00110Service

    <OperationContract(Action:="getAppCombo", ReplyAction:="getAppCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAppCombo(companyId As String, userId As String) As List(Of RLicenseAppComboDTO)

    <OperationContract(Action:="getAttributeGroupCombo", ReplyAction:="getAttributeGroupCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAttributeGroupCombo(companyId As String, appsCode As String) As List(Of RCustDBAttributeGroupComboDTO)

    <OperationContract(Action:="getAttributeCombo", ReplyAction:="getAttributeCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAttributeCombo(companyId As String, appsCode As String, attributeGroup As String) As List(Of RCustDBAttributeComboDTO)

    <OperationContract(Action:="getFunctionCombo", ReplyAction:="getFunctionCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetFunctionCombo(key As RCustDBProjectKeyDTO) As List(Of RCustDBFunctionComboDTO)

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy1(key1 As RCustDBItemKeyDTO)

End Interface
