﻿Imports R_Common
Imports RLicenseBack
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "CST00110StreamingService" in code, svc and config file together.
Public Class CST00110StreamingService
    Implements ICST00110StreamingService

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of RLicenseBack.RCustDBItemCopySourceDTO)) Implements ICST00110StreamingService.Dummy

    End Sub

    Public Function GetItemCopySource() As System.ServiceModel.Channels.Message Implements ICST00110StreamingService.GetItemCopySource
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtnTemp As List(Of RCustDBItemCopySourceDTO)
        Dim loRtn As Message
        Dim loTableKey As New RCustDBItemKeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CATTRIBUTE_ID = R_Utility.R_GetStreamingContext("cAttributeId")
            End With

            loRtnTemp = loCls.GetItemCopySource(loTableKey)

            loRtn = R_StreamUtility(Of RCustDBItemCopySourceDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getItemCopySource")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
