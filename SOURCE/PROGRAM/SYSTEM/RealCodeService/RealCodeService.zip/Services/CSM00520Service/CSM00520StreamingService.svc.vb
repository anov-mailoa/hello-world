﻿Imports R_Common
Imports CSM00520Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00520StreamingService" in code, svc and config file together.
Public Class CSM00520StreamingService
    Implements ICSM00520StreamingService

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of CSM00520Back.CSM00520GridDTO)) Implements ICSM00520StreamingService.Dummy

    End Sub

    Public Function GetComplaintSessionList() As System.ServiceModel.Channels.Message Implements ICSM00520StreamingService.GetComplaintSessionList
        Dim loException As New R_Exception
        Dim loCls As New CSM00520Cls
        Dim loRtnTemp As List(Of CSM00520GridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00520KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .CPROJECT_ID = R_Utility.R_GetStreamingContext("cProjectId")
            End With

            loRtnTemp = loCls.GetComplaintSessionList(loTableKey)

            loRtn = R_StreamUtility(Of CSM00520GridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getComplaintSessionList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn

    End Function

End Class
