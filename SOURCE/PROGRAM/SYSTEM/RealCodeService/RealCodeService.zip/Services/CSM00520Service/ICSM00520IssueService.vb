﻿Imports System.ServiceModel
Imports R_BackEnd
Imports CSM00520Back
Imports R_Common
Imports CST00200Back
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00520IssueService" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00520IssueService
    Inherits R_IServicebase(Of CSM00520IssueDTO)

    <OperationContract(Action:="getIssueTypeCombo", ReplyAction:="getIssueTypeCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetIssueTypeCombo() As List(Of CST00200IssueTypeComboDTO)

    <OperationContract(Action:="getIssueClassCombo", ReplyAction:="getIssueClassCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetIssueClassCombo(key As CST00200KeyDTO) As List(Of CST00200IssueClassComboDTO)

    <OperationContract(Action:="getAttributeCombo", ReplyAction:="getAttributeCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAttributeCombo(companyId As String, appsCode As String, attributeGroup As String) As List(Of RCustDBAttributeComboDTO)

    <OperationContract(Action:="getAttributeGroupCombo", ReplyAction:="getAttributeGroupCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAttributeGroupCombo(companyId As String, appsCode As String) As List(Of RCustDBAttributeGroupComboDTO)

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of CSM00520IssueKeyDTO))

End Interface
