﻿Imports R_Common
Imports CSM00511BACK
Imports RLicenseBack
Imports CSM00500Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00511Service" in code, svc and config file together.
Public Class CSM00511Service
    Implements ICSM00511Service

    Public Sub CloseSchedule(poKey As CSM00500Back.CSM00500KeyDTO) Implements ICSM00511Service.CloseSchedule
        Dim loEx As New R_Exception
        Dim loCls As New CSM00500ScheduleCls

        Try
            loCls.CloseSchedule(poKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Dummy1() As System.Collections.Generic.List(Of CSM00500Back.CSM00500KeyDTO) Implements ICSM00511Service.Dummy1

    End Function

    Public Function GetAppCombo(companyId As String, userId As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseAppComboDTO) Implements ICSM00511Service.GetAppCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseAppComboDTO)

        Try
            loRtn = loCls.GetAppCombo(companyId, userId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetProjectCombo(key As RLicenseBack.RCustDBProjectKeyDTO) As System.Collections.Generic.List(Of RLicenseBack.RCustDBProjectComboDTO) Implements ICSM00511Service.GetProjectCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBProjectComboDTO)

        Try
            loRtn = loCls.GetProjectCombo(key)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn

    End Function

    Public Function GetSessionCombo(key As RLicenseBack.RCustDBProjectKeyDTO) As System.Collections.Generic.List(Of RLicenseBack.RCustDBSessionComboDTO) Implements ICSM00511Service.GetSessionCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBSessionComboDTO)

        Try
            loRtn = loCls.GetSessionCombo(key)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn

    End Function

    Public Function GetVersionCombo(companyId As String, appsCode As String) As System.Collections.Generic.List(Of RLicenseBack.RCustDBVersionComboDTO) Implements ICSM00511Service.GetVersionCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBVersionComboDTO)

        Try
            loRtn = loCls.GetVersionCombo(companyId, appsCode)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub StartSchedule(poKey As CSM00500Back.CSM00500KeyDTO) Implements ICSM00511Service.StartSchedule
        Dim loEx As New R_Exception
        Dim loCls As New CSM00500ScheduleCls

        Try
            loCls.StartSchedule(poKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

    End Sub

    Public Sub Svc_R_Delete(poEntity As CSM00511BACK.CSM00511ScheduleDTO) Implements R_BackEnd.R_IServicebase(Of CSM00511BACK.CSM00511ScheduleDTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New CSM00511ScheduleCls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

    End Sub

    Public Function Svc_R_GetRecord(poEntity As CSM00511BACK.CSM00511ScheduleDTO) As CSM00511BACK.CSM00511ScheduleDTO Implements R_BackEnd.R_IServicebase(Of CSM00511BACK.CSM00511ScheduleDTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New CSM00511ScheduleCls
        Dim loRtn As CSM00511ScheduleDTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn

    End Function

    Public Function Svc_R_Save(poEntity As CSM00511BACK.CSM00511ScheduleDTO, poCRUDMode As R_Common.eCRUDMode) As CSM00511BACK.CSM00511ScheduleDTO Implements R_BackEnd.R_IServicebase(Of CSM00511BACK.CSM00511ScheduleDTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New CSM00511ScheduleCls
        Dim loRtn As CSM00511ScheduleDTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
