﻿Imports System.ServiceModel
Imports R_BackEnd
Imports CSM00500Back
Imports R_Common
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00500Service" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00500Service
    Inherits R_IServicebase(Of CSM00500DTO)

    <OperationContract(Action:="getAppCombo", ReplyAction:="getAppCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAppCombo(companyId As String, userId As String) As List(Of RLicenseAppComboDTO)

    <OperationContract(Action:="getVersionCombo", ReplyAction:="getVersionCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetVersionCombo(companyId As String, appsCode As String) As List(Of RCustDBVersionComboDTO)

    <OperationContract(Action:="closeProject", ReplyAction:="closeProject")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub CloseProject(poKey As CSM00500KeyDTO)

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function Dummy1() As List(Of CSM00500KeyDTO)

End Interface
