﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports CSM00500Back
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00500StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00500StreamingService

    <OperationContract(Action:="getProjectList", ReplyAction:="getProjectList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetProjectList() As Message

    <OperationContract(Action:="getProjectManagerList", ReplyAction:="getProjectManagerList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetProjectManagerList() As Message

    <OperationContract(Action:="getProjectUserList", ReplyAction:="getProjectUserList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetProjectUserList() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of CSM00500GridDTO), ByVal poPar2 As List(Of RCustDBUserListDTO), ByVal poPar3 As List(Of CSM00500UsersGridDTO))


End Interface
