﻿Imports System.ServiceModel
Imports R_Common
Imports RLicenseBack
Imports CSM00500Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00500ItemService" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00500ItemService

    <OperationContract(Action:="getAttributeCombo", ReplyAction:="getAttributeCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAttributeCombo(companyId As String, appsCode As String, attributeGroup As String) As List(Of RCustDBAttributeComboDTO)

    <OperationContract(Action:="getAttributeGroupCombo", ReplyAction:="getAttributeGroupCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAttributeGroupCombo(companyId As String, appsCode As String) As List(Of RCustDBAttributeGroupComboDTO)

    <OperationContract(Action:="getScheduleTypeCombo", ReplyAction:="getScheduleTypeCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetScheduleTypeCombo(programId As String) As List(Of RCustDBScheduleTypeComboDTO)

    <OperationContract(Action:="deleteItem", ReplyAction:="deleteItem")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub DeleteItem(key As CSM00500ItemKeyDTO)

    <OperationContract(Action:="getDefaultPIC", ReplyAction:="getDefaultPIC")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetDefaultPIC(key As CSM00500KeyDTO) As CSM00500DefaultPICDTO

End Interface
