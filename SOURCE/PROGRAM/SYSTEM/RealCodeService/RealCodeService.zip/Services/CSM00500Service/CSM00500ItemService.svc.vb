﻿Imports R_Common
Imports RLicenseBack
Imports CSM00500Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00500ItemService" in code, svc and config file together.
Public Class CSM00500ItemService
    Implements ICSM00500ItemService

    Public Function GetAttributeCombo(companyId As String, appsCode As String, attributeGroup As String) As System.Collections.Generic.List(Of RLicenseBack.RCustDBAttributeComboDTO) Implements ICSM00500ItemService.GetAttributeCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBAttributeComboDTO)

        Try
            loRtn = loCls.GetAttributeCombo(companyId, appsCode, attributeGroup)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetAttributeGroupCombo(companyId As String, appsCode As String) As System.Collections.Generic.List(Of RLicenseBack.RCustDBAttributeGroupComboDTO) Implements ICSM00500ItemService.GetAttributeGroupCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBAttributeGroupComboDTO)

        Try
            loRtn = loCls.GetAttributeGroupCombo(companyId, appsCode)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub DeleteItem(key As CSM00500Back.CSM00500ItemKeyDTO) Implements ICSM00500ItemService.DeleteItem
        Dim loException As New R_Exception
        Dim loCls As New CSM00500ItemCls

        Try
            loCls.DeleteItem(key)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

    End Sub

    Public Function GetDefaultPIC(key As CSM00500Back.CSM00500KeyDTO) As CSM00500Back.CSM00500DefaultPICDTO Implements ICSM00500ItemService.GetDefaultPIC
        Dim loException As New R_Exception
        Dim loCls As New CSM00500ItemCls
        Dim loRtn As CSM00500DefaultPICDTO

        Try
            loRtn = loCls.GetDefaultPIC(key)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetScheduleTypeCombo(programId As String) As System.Collections.Generic.List(Of RLicenseBack.RCustDBScheduleTypeComboDTO) Implements ICSM00500ItemService.GetScheduleTypeCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBScheduleTypeComboDTO)

        Try
            loRtn = loCls.GetScheduleTypeCombo(programId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
