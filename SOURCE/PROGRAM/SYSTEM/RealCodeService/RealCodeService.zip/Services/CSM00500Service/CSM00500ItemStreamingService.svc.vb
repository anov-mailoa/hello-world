﻿Imports R_Common
Imports CSM00500Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00500ItemStreamingService" in code, svc and config file together.
Public Class CSM00500ItemStreamingService
    Implements ICSM00500ItemStreamingService

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of CSM00500Back.CSM00500ItemGridDTO)) Implements ICSM00500ItemStreamingService.Dummy

    End Sub

    Public Function GetAvailableItems() As System.ServiceModel.Channels.Message Implements ICSM00500ItemStreamingService.GetAvailableItems
        Dim loException As New R_Exception
        Dim loCls As New CSM00500ItemCls
        Dim loRtnTemp As List(Of CSM00500ItemGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00500ItemKeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .CPROJECT_ID = R_Utility.R_GetStreamingContext("cProjectId")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CATTRIBUTE_ID = R_Utility.R_GetStreamingContext("cAttributeId")
                .CSESSION_ID = R_Utility.R_GetStreamingContext("cSessionId")
                .LCUSTOM = R_Utility.R_GetStreamingContext("lCustom")
                .CCUSTOMER_CODE = R_Utility.R_GetStreamingContext("cCustomerCode")
            End With

            loRtnTemp = loCls.GetAvailableItems(loTableKey)

            loRtn = R_StreamUtility(Of CSM00500ItemGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getAvailableItemsList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetSelectedItems() As System.ServiceModel.Channels.Message Implements ICSM00500ItemStreamingService.GetSelectedItems
        Dim loException As New R_Exception
        Dim loCls As New CSM00500ItemCls
        Dim loRtnTemp As List(Of CSM00500ItemGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00500ItemKeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .CPROJECT_ID = R_Utility.R_GetStreamingContext("cProjectId")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CATTRIBUTE_ID = R_Utility.R_GetStreamingContext("cAttributeId")
                .CSESSION_ID = R_Utility.R_GetStreamingContext("cSessionId")
                .LCUSTOM = R_Utility.R_GetStreamingContext("lCustom")
                .CCUSTOMER_CODE = R_Utility.R_GetStreamingContext("cCustomerCode")
            End With

            loRtnTemp = loCls.GetSelectedItems(loTableKey)

            loRtn = R_StreamUtility(Of CSM00500ItemGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getSelectedItemsList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
