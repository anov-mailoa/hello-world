﻿Imports R_Common
Imports CSM00500Back
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00500UsersService" in code, svc and config file together.
Public Class CSM00500UsersService
    Implements ICSM00500UsersService

    Public Sub Svc_R_Delete(poEntity As CSM00500Back.CSM00500UsersDTO) Implements R_BackEnd.R_IServicebase(Of CSM00500Back.CSM00500UsersDTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New CSM00500UsersCls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As CSM00500Back.CSM00500UsersDTO) As CSM00500Back.CSM00500UsersDTO Implements R_BackEnd.R_IServicebase(Of CSM00500Back.CSM00500UsersDTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New CSM00500UsersCls
        Dim loRtn As CSM00500UsersDTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As CSM00500Back.CSM00500UsersDTO, poCRUDMode As R_Common.eCRUDMode) As CSM00500Back.CSM00500UsersDTO Implements R_BackEnd.R_IServicebase(Of CSM00500Back.CSM00500UsersDTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New CSM00500UsersCls
        Dim loRtn As CSM00500UsersDTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Dummy1() As System.Collections.Generic.List(Of CSM00500Back.CSM00500UsersKeyDTO) Implements ICSM00500UsersService.Dummy1

    End Function

    Public Function GetFunctionCombo(poKey As RCustDBProjectKeyDTO) As System.Collections.Generic.List(Of RLicenseBack.RCustDBFunctionComboDTO) Implements ICSM00500UsersService.GetFunctionCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBFunctionComboDTO)

        Try
            loRtn = loCls.GetFunctionCombo(poKey)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetLocationCombo() As System.Collections.Generic.List(Of RLicenseBack.RCustDBLocationComboDTO) Implements ICSM00500UsersService.GetLocationCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBLocationComboDTO)

        Try
            loRtn = loCls.GetLocationCombo()
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
