﻿Imports R_Common
Imports CSM00500Back
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00500SessionService" in code, svc and config file together.
Public Class CSM00500SessionService
    Implements ICSM00500SessionService


    Public Sub Svc_R_Delete(poEntity As CSM00500Back.CSM00500SessionDTO) Implements R_BackEnd.R_IServicebase(Of CSM00500Back.CSM00500SessionDTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New CSM00500SessionCls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As CSM00500Back.CSM00500SessionDTO) As CSM00500Back.CSM00500SessionDTO Implements R_BackEnd.R_IServicebase(Of CSM00500Back.CSM00500SessionDTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New CSM00500SessionCls
        Dim loRtn As CSM00500SessionDTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As CSM00500Back.CSM00500SessionDTO, poCRUDMode As R_Common.eCRUDMode) As CSM00500Back.CSM00500SessionDTO Implements R_BackEnd.R_IServicebase(Of CSM00500Back.CSM00500SessionDTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New CSM00500SessionCls
        Dim loRtn As CSM00500SessionDTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Dummy1() As System.Collections.Generic.List(Of CSM00500Back.CSM00500SessionKeyDTO) Implements ICSM00500SessionService.Dummy1

    End Function

    Public Sub CloseSession(poKey As CSM00500Back.CSM00500SessionKeyDTO) Implements ICSM00500SessionService.CloseSession
        Dim loEx As New R_Exception
        Dim loCls As New CSM00500SessionCls

        Try
            loCls.CloseSession(poKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Sub CreateSession(poKey As CSM00500Back.CSM00500SessionKeyDTO) Implements ICSM00500SessionService.CreateSession
        Dim loEx As New R_Exception
        Dim loCls As New CSM00500SessionCls

        Try
            loCls.CreateSession(poKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Sub StartSession(poKey As CSM00500Back.CSM00500SessionKeyDTO) Implements ICSM00500SessionService.StartSession
        Dim loEx As New R_Exception
        Dim loCls As New CSM00500SessionCls

        Try
            loCls.StartSession(poKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function GetScheduleTypeCombo(programId As String) As System.Collections.Generic.List(Of RLicenseBack.RCustDBScheduleTypeComboDTO) Implements ICSM00500SessionService.GetScheduleTypeCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBScheduleTypeComboDTO)

        Try
            loRtn = loCls.GetScheduleTypeCombo(programId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

End Class
