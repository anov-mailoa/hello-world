﻿Imports R_Common
Imports SAM01200Back
Imports System.ServiceModel.Channels
' NOTE: You can use the "Rename" command on the context menu to change the class name "SAM01200StreamingService" in code, svc and config file together.
Public Class SAM01200StreamingService
    Implements ISAM01200StreamingService

    Public Function getUserCompanyList() As System.ServiceModel.Channels.Message Implements ISAM01200StreamingService.getUserCompanyList
        Dim loException As New R_Exception
        Dim loCls As New SAM01200Cls
        Dim loRtnTemp As List(Of UserCompanyDTOnon)
        Dim loRtn As Message
        Dim lcUserId As String

        Try
            lcUserId = R_Utility.R_GetStreamingContext("cUserId")

            loRtnTemp = loCls.getUserCompanyList(lcUserId)

            loRtn = R_StreamUtility(Of UserCompanyDTOnon).WriteToMessage(loRtnTemp.AsEnumerable, "getUserCompanyList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function getUserList() As System.ServiceModel.Channels.Message Implements ISAM01200StreamingService.getUserList
        Dim loException As New R_Exception
        Dim loCls As New SAM01200Cls
        Dim loRtnTemp As List(Of SAM01200UserDTOnon)
        Dim loRtn As Message

        Try
            loRtnTemp = loCls.getUserList()

            loRtn = R_StreamUtility(Of SAM01200UserDTOnon).WriteToMessage(loRtnTemp.AsEnumerable, "getUserList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function getUserMenuList() As System.ServiceModel.Channels.Message Implements ISAM01200StreamingService.getUserMenuList
        Dim loException As New R_Exception
        Dim loCls As New SAM01200Cls
        Dim loRtnTemp As List(Of UserMenuDTOnon)
        Dim loRtn As Message
        Dim lcUserId As String
        Dim lcCompId As String

        Try
            lcCompId = R_Utility.R_GetStreamingContext("cCompanyId")
            lcUserId = R_Utility.R_GetStreamingContext("cUserId")

            loRtnTemp = loCls.getUserMenuList(lcUserId, lcCompId)

            loRtn = R_StreamUtility(Of UserMenuDTOnon).WriteToMessage(loRtnTemp.AsEnumerable, "getUserMenuList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function getCompanyMultiple() As System.ServiceModel.Channels.Message Implements ISAM01200StreamingService.getCompanyMultiple
        Dim loException As New R_Exception
        Dim loCls As New SAM01200Cls
        Dim loRtnTemp As List(Of UserCompanyDTOnon)
        Dim loRtn As Message

        Try
            loRtnTemp = loCls.getCompanyMultiple()

            loRtn = R_StreamUtility(Of UserCompanyDTOnon).WriteToMessage(loRtnTemp.AsEnumerable, "getCompanyMultiple")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function getMenuMultiple() As System.ServiceModel.Channels.Message Implements ISAM01200StreamingService.getMenuMultiple
        Dim loException As New R_Exception
        Dim loCls As New SAM01200Cls
        Dim loRtnTemp As List(Of UserMenuDTOnon)
        Dim loRtn As Message
        Dim lcCompId As String

        Try
            lcCompId = R_Utility.R_GetStreamingContext("cCompanyId")

            loRtnTemp = loCls.getMenuMultiple(lcCompId)

            loRtn = R_StreamUtility(Of UserMenuDTOnon).WriteToMessage(loRtnTemp.AsEnumerable, "getMenuMultiple")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub Dummy(poPar As System.Collections.Generic.List(Of SAM01200Back.SAM01200UserDTOnon), poPar1 As System.Collections.Generic.List(Of SAM01200Back.UserCompanyDTOnon), poPar2 As System.Collections.Generic.List(Of SAM01200Back.UserMenuDTOnon), poPar3 As System.Collections.Generic.List(Of SAM01200Back.CompanyCopyDTO)) Implements ISAM01200StreamingService.Dummy

    End Sub

    Public Function getCompanyCopyList() As System.ServiceModel.Channels.Message Implements ISAM01200StreamingService.getCompanyCopyList
        Dim loException As New R_Exception
        Dim loCls As New SAM01200Cls
        Dim loRtnTemp As List(Of CompanyCopyDTO)
        Dim loRtn As Message
        Dim lcUserId As String

        Try
            lcUserId = R_Utility.R_GetStreamingContext("cUserId")

            loRtnTemp = loCls.getCompanyCopyList(lcUserId)

            loRtn = R_StreamUtility(Of CompanyCopyDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getCompanyCopyList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function getMenuCopyList() As System.ServiceModel.Channels.Message Implements ISAM01200StreamingService.getMenuCopyList
        Dim loException As New R_Exception
        Dim loCls As New SAM01200Cls
        Dim loRtnTemp As List(Of UserMenuDTOnon)
        Dim loRtn As Message
        Dim lcCompId As String

        Try
            lcCompId = R_Utility.R_GetStreamingContext("cCompanyId")

            loRtnTemp = loCls.getMenuCopyList(lcCompId)

            loRtn = R_StreamUtility(Of UserMenuDTOnon).WriteToMessage(loRtnTemp.AsEnumerable, "getMenuCopyList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
