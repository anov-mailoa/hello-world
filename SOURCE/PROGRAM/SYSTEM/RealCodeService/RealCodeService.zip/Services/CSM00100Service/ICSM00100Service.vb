﻿Imports System.ServiceModel
Imports CSM00100Back
Imports RLicenseBack
Imports R_BackEnd
Imports R_Common

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00100Service" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00100Service
    Inherits R_IServicebase(Of CSM00100AttrGrpDTO)

    <OperationContract(Action:="getAppCombo", ReplyAction:="getAppCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAppCombo(companyId As String, userId As String) As List(Of RLicenseAppComboDTO)

    <OperationContract(Action:="getFromAppCombo", ReplyAction:="getFromAppCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetFromAppCombo(companyId As String, userId As String) As List(Of RLicenseAppComboDTO)

    <OperationContract(Action:="generateAttributeGroup", ReplyAction:="generateAttributeGroup")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub GenerateAttributeGroup(poNewEntity As CSM00100AttrGrpDTO, pcFrom_Apps_Code As String)

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function Dummy1() As List(Of CSM00100AttrGrpKeyDTO)

End Interface
