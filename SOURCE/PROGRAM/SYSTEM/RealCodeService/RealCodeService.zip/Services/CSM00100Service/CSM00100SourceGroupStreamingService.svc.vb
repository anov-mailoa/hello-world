﻿Imports R_Common
Imports CSM00100Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00100SourceGroupStreamingService" in code, svc and config file together.
Public Class CSM00100SourceGroupStreamingService
    Implements ICSM00100SourceGroupStreamingService

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of CSM00100Back.CSM00100SourceGroupGridDTO)) Implements ICSM00100SourceGroupStreamingService.Dummy

    End Sub

    Public Function GetSourceGroupList() As System.ServiceModel.Channels.Message Implements ICSM00100SourceGroupStreamingService.GetSourceGroupList
        Dim loException As New R_Exception
        Dim loCls As New CSM00100SourceGroupCls
        Dim loRtnTemp As List(Of CSM00100SourceGroupGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00100SourceGroupKeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CATTRIBUTE_ID = R_Utility.R_GetStreamingContext("cAttributeId")
            End With

            loRtnTemp = loCls.GetSourceGroupList(loTableKey)

            loRtn = R_StreamUtility(Of CSM00100SourceGroupGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getSourceGroupList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function
End Class
