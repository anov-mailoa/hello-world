﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports CSM00100Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00100AttributeStreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00100AttributeStreamingService

    <OperationContract(Action:="getAttributeList", ReplyAction:="getAttributeList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAttributeList() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of CSM00100AttributeGridDTO))

End Interface
