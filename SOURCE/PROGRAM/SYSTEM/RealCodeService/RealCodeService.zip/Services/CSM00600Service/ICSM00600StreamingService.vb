﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports CSM00600Back
Imports RLicenseBack
Imports CST00200Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00600StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00600StreamingService

    <OperationContract(Action:="getCRList", ReplyAction:="getCRList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetCRList() As Message

    <OperationContract(Action:="getIssueCombo", ReplyAction:="getIssueCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetIssueCombo() As Message

    <OperationContract(Action:="getItemList", ReplyAction:="getItemList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetItemList() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of CSM00600GridDTO), _
              ByVal poPar2 As List(Of RCustDBIssueComboDTO), _
              ByVal poPar3 As RCustDBIssueKeyDTO, _
              ByVal poPar4 As List(Of RCustDBItemComboDTO))

End Interface
