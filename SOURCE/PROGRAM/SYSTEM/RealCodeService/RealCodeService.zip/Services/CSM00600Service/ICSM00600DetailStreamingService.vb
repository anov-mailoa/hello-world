﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports CSM00600Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00600DetailStreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00600DetailStreamingService

    <OperationContract(Action:="getCRDetailList", ReplyAction:="getCRDetailList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetCRDetailList() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of CSM00600DetailGridDTO))

End Interface
