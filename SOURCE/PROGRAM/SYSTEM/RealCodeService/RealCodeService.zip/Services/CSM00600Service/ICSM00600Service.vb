﻿Imports System.ServiceModel
Imports R_BackEnd
Imports CSM00600Back
Imports R_Common
Imports RLicenseBack

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00600Service" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00600Service
    Inherits R_IServicebase(Of CSM00600DTO)

    <OperationContract(Action:="getAppCombo", ReplyAction:="getAppCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAppCombo(companyId As String, userId As String) As List(Of RLicenseAppComboDTO)

    <OperationContract(Action:="getAttributeGroupCombo", ReplyAction:="getAttributeGroupCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAttributeGroupCombo(companyId As String, appsCode As String) As List(Of RCustDBAttributeGroupComboDTO)

    <OperationContract(Action:="getAttributeCombo", ReplyAction:="getAttributeCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAttributeCombo(companyId As String, appsCode As String, attributeGroup As String) As List(Of RCustDBAttributeComboDTO)

    <OperationContract(Action:="getItemCombo", ReplyAction:="getItemCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetItemCombo(key As RCustDBItemKeyDTO) As List(Of RCustDBItemComboDTO)

    <OperationContract(Action:="getVersionCombo", ReplyAction:="getVersionCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetVersionCombo(companyId As String, appsCode As String) As List(Of RCustDBVersionComboDTO)

    <OperationContract(Action:="scheduleCR", ReplyAction:="scheduleCR")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub ScheduleCR(poPar As CSM00600KeyDTO)

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function Dummy() As List(Of CSM00600KeyDTO)

End Interface
