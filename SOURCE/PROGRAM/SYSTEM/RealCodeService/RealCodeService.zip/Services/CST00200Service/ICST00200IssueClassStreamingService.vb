﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports CST00200Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICST00200IssueTypeStreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ICST00200IssueClassStreamingService

    <OperationContract(Action:="getIssueClassList", ReplyAction:="getIssueClassList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetIssueClassList() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As CST00200IssueClassGridDTO)

End Interface
