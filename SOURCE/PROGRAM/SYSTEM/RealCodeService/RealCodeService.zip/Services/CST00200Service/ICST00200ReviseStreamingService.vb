﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports RLicenseBack
Imports CST00200Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICST00200ReviseStreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ICST00200ReviseStreamingService

    <OperationContract(Action:="getReviseIssueList", ReplyAction:="getReviseIssueList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetReviseIssueList() As Message

    <OperationContract(Action:="getItemList", ReplyAction:="getItemList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetItemList() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of CST00200ItemListDTO), ByVal poPar2 As CST00200GridDTO, ByVal poPar3 As RCustDBInboxKeyDTO)

End Interface
