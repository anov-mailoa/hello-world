﻿Imports R_Common
Imports RLicenseBack
Imports CSM00500Back

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00510Service" in code, svc and config file together.
Public Class CSM00510Service
    Implements ICSM00510Service

    Public Sub Svc_R_Delete(poEntity As CSM00500Back.CSM00500ScheduleDTO) Implements R_BackEnd.R_IServicebase(Of CSM00500Back.CSM00500ScheduleDTO).Svc_R_Delete
        Dim loEx As New R_Exception
        Dim loCls As New CSM00500ScheduleCls

        Try
            loCls.R_Delete(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Function Svc_R_GetRecord(poEntity As CSM00500Back.CSM00500ScheduleDTO) As CSM00500Back.CSM00500ScheduleDTO Implements R_BackEnd.R_IServicebase(Of CSM00500Back.CSM00500ScheduleDTO).Svc_R_GetRecord
        Dim loEx As New R_Exception
        Dim loCls As New CSM00500ScheduleCls
        Dim loRtn As CSM00500ScheduleDTO = Nothing

        Try
            loRtn = loCls.R_GetRecord(poEntity)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Svc_R_Save(poEntity As CSM00500Back.CSM00500ScheduleDTO, poCRUDMode As R_Common.eCRUDMode) As CSM00500Back.CSM00500ScheduleDTO Implements R_BackEnd.R_IServicebase(Of CSM00500Back.CSM00500ScheduleDTO).Svc_R_Save
        Dim loEx As New R_Exception
        Dim loCls As New CSM00500ScheduleCls
        Dim loRtn As CSM00500ScheduleDTO = Nothing

        Try
            loRtn = loCls.R_Save(poEntity, poCRUDMode)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function Dummy1() As System.Collections.Generic.List(Of CSM00500Back.CSM00500KeyDTO) Implements ICSM00510Service.Dummy1

    End Function

    Public Function GetAppCombo(companyId As String, userId As String) As System.Collections.Generic.List(Of RLicenseBack.RLicenseAppComboDTO) Implements ICSM00510Service.GetAppCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RLicenseAppComboDTO)

        Try
            loRtn = loCls.GetAppCombo(companyId, userId)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetVersionCombo(companyId As String, appsCode As String) As System.Collections.Generic.List(Of RLicenseBack.RCustDBVersionComboDTO) Implements ICSM00510Service.GetVersionCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBVersionComboDTO)

        Try
            loRtn = loCls.GetVersionCombo(companyId, appsCode)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetProjectCombo(poKey As RCustDBProjectKeyDTO) As System.Collections.Generic.List(Of RLicenseBack.RCustDBProjectComboDTO) Implements ICSM00510Service.GetProjectCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBProjectComboDTO)

        Try
            loRtn = loCls.GetProjectCombo(poKey)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetSessionCombo(poKey As RCustDBProjectKeyDTO) As System.Collections.Generic.List(Of RLicenseBack.RCustDBSessionComboDTO) Implements ICSM00510Service.GetSessionCombo
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtn As List(Of RCustDBSessionComboDTO)

        Try
            loRtn = loCls.GetSessionCombo(poKey)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub StartSchedule(poKey As CSM00500Back.CSM00500KeyDTO) Implements ICSM00510Service.StartSchedule
        Dim loEx As New R_Exception
        Dim loCls As New CSM00500ScheduleCls

        Try
            loCls.StartSchedule(poKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

    Public Sub CloseSchedule(poKey As CSM00500Back.CSM00500KeyDTO) Implements ICSM00510Service.CloseSchedule
        Dim loEx As New R_Exception
        Dim loCls As New CSM00500ScheduleCls

        Try
            loCls.CloseSchedule(poKey)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ConvertAndThrowToServiceExceptionIfErrors()
    End Sub

End Class
