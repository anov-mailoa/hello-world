﻿Imports System.ServiceModel
Imports R_Common
Imports System.ServiceModel.Channels
Imports CSM00500Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ICSM00510StreamingService" in both code and config file together.
<ServiceContract()>
Public Interface ICSM00510StreamingService

    <OperationContract(Action:="getProjectScheduleList", ReplyAction:="getProjectScheduleList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetProjectScheduleList() As Message

    <OperationContract(Action:="getItemScheduleList", ReplyAction:="getItemScheduleList")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetItemScheduleList() As Message

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub Dummy(ByVal poPar1 As List(Of CSM00500ScheduleGridDTO), ByVal poPar2 As List(Of CSM00500ItemPreviewGridDTO))

End Interface
