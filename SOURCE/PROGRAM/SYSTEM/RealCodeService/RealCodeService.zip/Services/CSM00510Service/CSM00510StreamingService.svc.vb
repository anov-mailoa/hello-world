﻿Imports R_Common
Imports CSM00500Back
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "CSM00510StreamingService" in code, svc and config file together.
Public Class CSM00510StreamingService
    Implements ICSM00510StreamingService

    Public Function GetProjectScheduleList() As System.ServiceModel.Channels.Message Implements ICSM00510StreamingService.GetProjectScheduleList
        Dim loException As New R_Exception
        Dim loCls As New CSM00500ScheduleCls
        Dim loRtnTemp As List(Of CSM00500ScheduleGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00500KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .CPROJECT_ID = R_Utility.R_GetStreamingContext("cProjectId")
                .CSESSION_ID = R_Utility.R_GetStreamingContext("cSessionId")
            End With

            loRtnTemp = loCls.GetScheduleList(loTableKey)

            loRtn = R_StreamUtility(Of CSM00500ScheduleGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getProjectScheduleList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetItemScheduleList() As System.ServiceModel.Channels.Message Implements ICSM00510StreamingService.GetItemScheduleList
        Dim loException As New R_Exception
        Dim loCls As New CSM00500ScheduleCls
        Dim loRtnTemp As List(Of CSM00500ItemPreviewGridDTO)
        Dim loRtn As Message
        Dim loTableKey As New CSM00500KeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .CPROJECT_ID = R_Utility.R_GetStreamingContext("cProjectId")
                .CSESSION_ID = R_Utility.R_GetStreamingContext("cSessionId")
                .CSCHEDULE_ID = R_Utility.R_GetStreamingContext("cScheduleId")
            End With

            loRtnTemp = loCls.GetItemScheduleList(loTableKey)

            loRtn = R_StreamUtility(Of CSM00500ItemPreviewGridDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getItemScheduleList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of CSM00500Back.CSM00500ScheduleGridDTO), poPar2 As System.Collections.Generic.List(Of CSM00500Back.CSM00500ItemPreviewGridDTO)) Implements ICSM00510StreamingService.Dummy

    End Sub
End Class
