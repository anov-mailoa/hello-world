﻿Imports System.ServiceModel
Imports R_Common
Imports RLicenseBack
Imports LAT00200Back
Imports RVM00100Back

' NOTE: You can use the "Rename" command on the context menu to change the interface name "ILAT00200Service" in both code and config file together.
<ServiceContract()>
Public Interface ILAT00200Service

    <OperationContract(Action:="getAppCombo", ReplyAction:="getAppCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetAppCombo(companyId As String, userId As String) As List(Of RLicenseAppComboDTO)

    <OperationContract(Action:="getApplicationCombo", ReplyAction:="getApplicationCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetApplicationCombo(companyId As String, userId As String) As List(Of RVM00100AppComboDTO)


    <OperationContract(Action:="getCustCombo", ReplyAction:="getCustCombo")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function GetCustCombo(companyId As String) As List(Of RLicenseCustComboDTO)

    <OperationContract(Action:="registerServer", ReplyAction:="registerServer")> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Sub RegisterServer(ByVal poNewEntity As LAT00200ServerDTO)

    <OperationContract()> _
    <FaultContract(GetType(R_ServiceExceptions))> _
    Function Dummy1() As List(Of LAT00200KeyDTO)

End Interface
