﻿Public Class General
    Public Shared Function StrToDate(ByVal pcDate As String) As Nullable(Of DateTime)
        Dim ldReturn As Nullable(Of DateTime)

        If Not pcDate.Trim.Equals("") Then
            ldReturn = DateTime.ParseExact(pcDate, "yyyyMMdd", Nothing)
        End If

        Return ldReturn
    End Function
End Class
