﻿Imports RCustDBFrontHelper.FileServiceRef
Imports R_Common
Imports R_FrontEnd
Imports System.IO
Imports Ionic.Zip
Imports RCustDBFrontHelperResources
Imports RCustDBFileCommon

Public Class FileHandler

#Region " PROPERTY "
    ' Input
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CVERSION As String
    Public Property CATTRIBUTE_GROUP As String
    Public Property CATTRIBUTE_ID As String
    Public Property CITEM_ID As String
    Public Property CFUNCTION_ID As String
    Public Property CUSER_ID As String

    Public Property CPROJECT_ID As String
    Public Property CSESSION_ID As String
    Public Property CSCHEDULE_ID As String
    Public Property CACTION As String
    Public Property CPROGRAM_ID As String

    Public Property CISSUE_ID As String
    Public Property CFILE_NAME As String
    Public Property CDESCRIPTION As String

    Public Property CFILE_GROUP As String

    Public Property OFILE_PROCESS_KEY As List(Of RCustDBFileProcessKeyDTO)

    Public Property OEXCEPTION As R_Exception

    Public Property CBACKUP_NOTE As String

#End Region

#Region " VARIABLE "
    Private Shared C_ServiceName As String = "FileService/FileService.svc"
    Private Shared C_ServiceNameStream As String = "CST00100Service/CST00100StreamingService.svc"
    Private Shared C_ZipPath As String = "D:\RealCode\Temp\Zips"
    Private Shared C_RootPath As String = "D:\RealCode"
    Dim loService As FileServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IFileService, FileServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
    Dim lcWarning As String = ""
    Dim llFindFirstExistingFile As Boolean = False
    Dim llReplaceAll As Boolean = False

#End Region

    Sub New()
        Dim oRes As New Resources_Dummy_Class
        OFILE_PROCESS_KEY = New List(Of RCustDBFileProcessKeyDTO)
    End Sub

    Private Shared Function Combine(Of T)(ParamArray arrays As T()()) As T()
        Dim lnLength As Integer = arrays.Sum(Function(x) x.Length) - 1
        Dim ret As T() = New T(lnLength) {}
        Dim offset As Integer = 0
        For Each data As T() In arrays
            Buffer.BlockCopy(data, 0, ret, offset, data.Length)
            offset += data.Length
        Next
        Return ret
    End Function

    Private Function GetPath(pcFileCode As String, poFileKey As RCustDBFileKeyDTO) As String
        Dim lcPath As String

        Select Case pcFileCode
            Case "Source"

                lcPath = C_RootPath & "\" & poFileKey.CCOMPANY_ID.Trim & "\" & _
                            poFileKey.CAPPS_CODE.Trim & "\" & _
                            poFileKey.CVERSION.Trim & "\" & _
                            poFileKey.CATTRIBUTE_GROUP.Trim & "\" & _
                            poFileKey.CATTRIBUTE_ID.Trim & "\" & _
                            poFileKey.CITEM_ID.Trim
            Case "Zip"
                lcPath = C_ZipPath + "\" + poFileKey.CITEM_ID.Trim + ".zip"
            Case Else
                lcPath = ""
        End Select

        Return lcPath
    End Function

    Public Function DownloadByte(poKey As RCustDBFileKeyDTO) As Byte()
        Dim loException As New R_Exception
        Dim loFileSplit As New List(Of RCustDBFileSplitDTO)
        Dim loDatas As Byte()

        Try
            ' Kirim dulu permintaan untuk split file, return value   = guid & number of split
            loFileSplit = loService.SliceFile(poKey)

            ' Setelah itu loop proses untuk ambil file
            For Each loFile As RCustDBFileSplitDTO In loFileSplit
                If loFile.NSPLIT_ROW > 0 Then
                    loDatas = MergeFile(loFile)
                Else
                    loDatas = Nothing
                End If
            Next

        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
        Return loDatas
    End Function

    Public Sub DownloadFile(poKey As RCustDBFileKeyDTO)
        Dim loException As New R_Exception
        Dim loFileSplit As New List(Of RCustDBFileSplitDTO)
        Dim lcSourceFilePath As String
        Dim llFileExists As Boolean
        Dim loDatas As Byte()

        Try
            ' Kirim dulu permintaan untuk split file, return value   = guid & number of split
            loFileSplit = loService.SliceFile(poKey)

            ' Setelah itu loop proses untuk ambil file
            For Each loFile As RCustDBFileSplitDTO In loFileSplit
                If loFile.NSPLIT_ROW > 0 Then
                    llFileExists = True
                    loDatas = MergeFile(loFile)
                Else
                    llFileExists = False
                End If


                If llFileExists Then
                    ' Create folder if not exists
                    lcSourceFilePath = C_RootPath.Trim & loFile.CFILE_PATH.Trim
                    If Not Directory.Exists(lcSourceFilePath) Then
                        Directory.CreateDirectory(lcSourceFilePath)
                    End If
                    ' Save file
                    R_Utility.ConvertByteToFile(lcSourceFilePath & loFile.OFILE_KEY.CFILE_NAME, loDatas)
                End If

            Next

        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()

    End Sub

    Private Sub DownloadZipFile(poKey As RCustDBFileKeyDTO)
        Dim loException As New R_Exception
        Dim loFileSplit As New List(Of RCustDBFileSplitDTO)
        Dim lcSourceFilePath As String
        Dim lcZipFilePath As String
        Dim llFileExists As Boolean
        Dim loDatas As Byte()
        Dim llSkipExtract As Boolean
        Dim lcFiles As String
        Dim lcSelectionCriteria As String = ""

        Try
            lcZipFilePath = GetPath("Zip", poKey)
            ' Check and make sure if Realta temp zip folder exists
            If Not Directory.Exists(C_ZipPath) Then
                Directory.CreateDirectory(C_ZipPath)
            End If

            ' Kirim dulu permintaan untuk split file, return value = guid & number of split
            loFileSplit = loService.SliceFile(poKey)
            If loFileSplit.Count <= 0 Then
                lcWarning = R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "Err004").Trim & " (Item ID: " & poKey.CITEM_ID.Trim & ")"
                Exit Try
            End If

            ' Setelah itu loop proses untuk ambil file
            For Each loFile As RCustDBFileSplitDTO In loFileSplit
                If loFile.NSPLIT_ROW > 0 Then
                    llFileExists = True
                    loDatas = MergeFile(loFile)
                Else
                    llFileExists = False
                End If

                ' Create folder if not exists
                lcSourceFilePath = C_RootPath.Trim & loFile.CFILE_PATH.Trim
                If Not Directory.Exists(lcSourceFilePath) Then
                    Directory.CreateDirectory(lcSourceFilePath)
                End If

                If llFileExists Then
                    ' Save file
                    R_Utility.ConvertByteToFile(lcZipFilePath, loDatas)
                    ' ***** Extract file *****
                    ' Extract file only if exists
                    Using zip As ZipFile = ZipFile.Read(lcZipFilePath)
                        zip.ParallelDeflateThreshold = -1
                        llSkipExtract = False
                        If CPROGRAM_ID = "CST00110" Then
                            ' untuk program copy source, cek existing files
                            Dim loSelect As MsgBoxResult
                            For i = 0 To zip.EntryFileNames.Count - 1
                                If Not llReplaceAll Then
                                    If File.Exists(lcSourceFilePath + zip.EntryFileNames(i)) Then
                                        lcFiles = lcSourceFilePath
                                        If zip.EntryFileNames.Count = 1 Then
                                            lcFiles += zip.EntryFileNames(i)
                                        End If
                                        If Not llFindFirstExistingFile Then
                                            llFindFirstExistingFile = True
                                            loSelect = MsgBox("Source files found in local folder. Do you want to replace all existing files?", MsgBoxStyle.YesNo, "Replace all existing files.")
                                            If loSelect = MsgBoxResult.Yes Then
                                                llReplaceAll = True
                                                Exit For
                                            End If
                                        End If
                                        loSelect = MsgBox("Source files found in local folder. Do you want to overwrite?" + vbCrLf + "(" + lcFiles.Trim + ")", MsgBoxStyle.YesNo, "Overwrite source")
                                        If loSelect = MsgBoxResult.No Then
                                            llSkipExtract = True
                                        End If
                                    End If
                                    Exit For
                                End If
                            Next
                            'If Directory.EnumerateFiles(lcSourceFilePath).Count > 0 _
                            '    Or Directory.EnumerateDirectories(lcSourceFilePath).Count > 0 Then
                            'End If
                        End If
                        If Not llSkipExtract Then
                            'If poKey.CFUNCTION_ID.Trim = "QC" Then
                            '    If (lcSourceFilePath.ToUpper.Contains("BACK") Or lcSourceFilePath.ToUpper.Contains("FRONT")) Then
                            '        ' CR002 - filter extract untuk file2 dll
                            '        lcSelectionCriteria = "name = " + loFile.OFILE_KEY.CSOURCE_ID.Trim + ".dll"
                            '        zip.ExtractSelectedEntries(lcSelectionCriteria, Nothing, lcSourceFilePath, ExtractExistingFileAction.OverwriteSilently)
                            '    Else
                            '        zip.ExtractAll(lcSourceFilePath, ExtractExistingFileAction.OverwriteSilently)
                            '    End If
                            'Else
                            zip.ExtractAll(lcSourceFilePath, ExtractExistingFileAction.OverwriteSilently)
                            'End If
                        End If
                    End Using
                    ' Delete Zip File
                    File.Delete(lcZipFilePath)
                End If
            Next

        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Function MergeFile(poFile As RCustDBFileSplitDTO) As Byte()
        Dim loException As New R_Exception
        Dim loFileSlice As RCustDBFileDTO
        Dim loFileSplitKey As New RCustDBFileSplitKeyDTO
        Dim loList As ArrayList
        Dim loDatas As Byte()

        Try
            loList = New ArrayList()
            For i = 0 To poFile.NSPLIT_ROW - 1
                With loFileSplitKey
                    .CCOMPANY_ID = poFile.OFILE_KEY.CCOMPANY_ID
                    .CUSER_ID = poFile.OFILE_KEY.CUSER_ID
                    .CKEY_GUID = poFile.CKEY_GUID
                    .ISEQ_NO = i
                End With
                loFileSlice = loService.GetSlicedFile(loFileSplitKey)

                'Combine Byte Array
                '------------------------------
                loList.Add(New KeyValuePair(Of Integer, Byte())(i, loFileSlice.OFILE_BYTE))
            Next
            loDatas = Combine(Of Byte)(loList.ToArray.OrderBy(Function(x) CType(x, KeyValuePair(Of Integer, Byte())).Key).Select(Function(x) CType(x, KeyValuePair(Of Integer, Byte())).Value).ToArray())

        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
        Return loDatas
    End Function

    Public Sub ProcessSingleFile(pcFilePath As String)
        Dim loException As New R_Exception
        Dim loSourceByte As Byte()
        Dim loFileByte As RCustDBFileEntityDTO
        Dim loFileBytes As New List(Of RCustDBFileEntityDTO)
        Dim loProcessKey As New RCustDBFileProcessKeyDTO

        Try
            loSourceByte = R_Utility.GetByteFromFile(pcFilePath)
            'Kirim Data ke Big Object
            loFileByte = New RCustDBFileEntityDTO
            With loFileByte
                .CCOMPANY_ID = CCOMPANY_ID
                .CAPPS_CODE = CAPPS_CODE
                .CVERSION = CVERSION
                .CPROJECT_ID = CPROJECT_ID
                .CSESSION_ID = CSESSION_ID
                .CSCHEDULE_ID = CSCHEDULE_ID
                .CATTRIBUTE_GROUP = CATTRIBUTE_GROUP
                .CATTRIBUTE_ID = CATTRIBUTE_ID
                .CITEM_ID = CITEM_ID
                .CFUNCTION_ID = CFUNCTION_ID
                .CISSUE_ID = CISSUE_ID
                .CFILE_NAME = CFILE_NAME
                .CDESCRIPTION = CDESCRIPTION
                .OFILE_BYTE = loSourceByte
                .OBUILD_BYTE = Nothing
            End With
            loFileBytes.Add(loFileByte)
            'prepare Batch Parameter
            With loProcessKey
                .CCOMPANY_ID = CCOMPANY_ID
                .CAPPS_CODE = CAPPS_CODE
                .CVERSION = CVERSION
                .CPROJECT_ID = CPROJECT_ID
                .CSESSION_ID = CSESSION_ID
                .CFUNCTION_ID = CFUNCTION_ID
                .CSCHEDULE_ID = CSCHEDULE_ID
                .CACTION = CACTION
                .CUSER_ID = CUSER_ID
                .CATTRIBUTE_GROUP = CATTRIBUTE_GROUP
                .CATTRIBUTE_ID = CATTRIBUTE_ID
                .CITEM_ID = CITEM_ID
                .CFILE_GROUP = CFILE_GROUP
            End With

            UploadFile(loFileBytes, loProcessKey)

        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub UploadFile(poFileBytes As List(Of RCustDBFileEntityDTO), poProcessKey As RCustDBFileProcessKeyDTO)
        Dim loException As New R_Exception
        Dim loBatchPar As R_BatchParameter
        Dim loUserParameters As New List(Of R_KeyValue)
        Dim loUserPar As R_KeyValue
        Dim loSvc As R_ProcessAndUploadClient
        Dim lcKeyGuid As String

        Try
            'Instantiate FrontHelper
            loSvc = New R_ProcessAndUploadClient(Nothing, Nothing, Nothing)
            AddHandler loSvc.ProcessError, AddressOf ProcessError

            'preapare Batch Parameter
            With loUserPar
                .Key = "OPROCESS_KEY"
                .Value = R_Utility.Serialize(poProcessKey)
            End With
            loUserParameters.Add(loUserPar)

            With loBatchPar
                .COMPANY_ID = CCOMPANY_ID
                .USER_ID = CUSER_ID
                .ClassName = "RLicenseBack.FileHandlerCls"
                .BigObject = poFileBytes
                .UserParameters = loUserParameters
            End With
            lcKeyGuid = loSvc.R_BatchProcess(loBatchPar, Nothing)

        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ThrowExceptionIfErrors()
    End Sub

    Public Sub CheckOut()
        Dim loException As New R_Exception
        Dim loKey As New RCustDBFileKeyDTO
        Dim loStatusKeys As New List(Of RCustDBProcessTransactionDTO)
        Dim loStatusKey As RCustDBProcessTransactionDTO
        Dim loValidationResult As List(Of RCustDBProcessValidationDTO)

        Try
            ' Download file
            For Each loItem As RCustDBFileProcessKeyDTO In OFILE_PROCESS_KEY

                loStatusKey = New RCustDBProcessTransactionDTO With {
                                 .CCOMPANY_ID = loItem.CCOMPANY_ID, _
                                 .CAPPS_CODE = loItem.CAPPS_CODE, _
                                 .CVERSION = loItem.CVERSION, _
                                 .CPROJECT_ID = loItem.CPROJECT_ID, _
                                 .CSESSION_ID = loItem.CSESSION_ID, _
                                 .CSCHEDULE_ID = loItem.CSCHEDULE_ID, _
                                 .CATTRIBUTE_GROUP = loItem.CATTRIBUTE_GROUP, _
                                 .CATTRIBUTE_ID = loItem.CATTRIBUTE_ID, _
                                 .CITEM_ID = loItem.CITEM_ID, _
                                 .CFUNCTION_ID = loItem.CFUNCTION_ID, _
                                 .CACTION = loItem.CACTION, _
                                 .CUSER_ID = loItem.CUSER_ID}

                loValidationResult = loService.CheckinValidation(loStatusKey)
                If loValidationResult.Count > 0 Then
                    For Each result As RCustDBProcessValidationDTO In loValidationResult
                        loException.Add(result.CMESSAGE_CODE, result.CDESCRIPTION)
                    Next
                    Continue For
                End If

                With loKey
                    .CCOMPANY_ID = loItem.CCOMPANY_ID
                    .CAPPS_CODE = loItem.CAPPS_CODE
                    .CVERSION = loItem.CVERSION
                    .CATTRIBUTE_GROUP = loItem.CATTRIBUTE_GROUP
                    .CATTRIBUTE_ID = loItem.CATTRIBUTE_ID
                    .CITEM_ID = loItem.CITEM_ID
                    .CFUNCTION_ID = loItem.CFUNCTION_ID
                    .CUSER_ID = loItem.CUSER_ID
                    .CFILE_GROUP = "SOURCE"
                End With
                If Not loItem.CACTION.Equals("DEVSCO") Then
                    DownloadZipFile(loKey)
                End If
                ' Download spec if DEV or QC
                If (loItem.CFUNCTION_ID.Equals("DEVELOPMENT") Or loItem.CFUNCTION_ID.Equals("QC")) And loItem.LSPEC Then
                    ' sementara ubah function menjadi DESIGN untuk mendapatkan spec
                    loKey.CFUNCTION_ID = "DESIGN"
                    DownloadZipFile(loKey)
                    ' kembalikan function menjadi seperti semula
                    loKey.CFUNCTION_ID = loItem.CFUNCTION_ID
                End If

                loStatusKeys.Add(loStatusKey)
            Next

            loService.CheckoutStatus(loStatusKeys)
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Public Sub CopySource()
        Dim loException As New R_Exception
        Dim loKey As New RCustDBFileKeyDTO

        Try
            ' Download file
            For Each loItem As RCustDBFileProcessKeyDTO In OFILE_PROCESS_KEY

                With loKey
                    .CCOMPANY_ID = loItem.CCOMPANY_ID
                    .CAPPS_CODE = loItem.CAPPS_CODE
                    .CVERSION = loItem.CVERSION
                    .CPROJECT_ID = loItem.CPROJECT_ID
                    .CSESSION_ID = loItem.CSESSION_ID
                    .CSCHEDULE_ID = loItem.CSCHEDULE_ID
                    .CATTRIBUTE_GROUP = loItem.CATTRIBUTE_GROUP
                    .CATTRIBUTE_ID = loItem.CATTRIBUTE_ID
                    .CITEM_ID = loItem.CITEM_ID
                    .CFUNCTION_ID = loItem.CFUNCTION_ID
                    .CACTION = loItem.CACTION
                    .CBACKUP_TIME = loItem.CBACKUP_TIME
                    .CUSER_ID = loItem.CUSER_ID
                    .CFILE_GROUP = "SOURCE"
                End With
                DownloadZipFile(loKey)
                If Not lcWarning.Trim.Equals("") Then
                    loException.Add("Err", lcWarning)
                    Continue For
                End If
                ' Download spec if DEV or QC
                If (loItem.CFUNCTION_ID.Equals("DEVELOPMENT") Or loItem.CFUNCTION_ID.Equals("QC")) And loItem.LSPEC Then
                    ' sementara ubah function menjadi DESIGN untuk mendapatkan spec
                    loKey.CFUNCTION_ID = "DESIGN"
                    DownloadZipFile(loKey)
                    ' kembalikan function menjadi seperti semula
                    loKey.CFUNCTION_ID = loItem.CFUNCTION_ID
                End If
                If Not lcWarning.Trim.Equals("") Then
                    loException.Add("Err", lcWarning)
                    Continue For
                End If
            Next

        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Public Sub CheckIn()
        'Dim loService As FileServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IFileService, FileServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loException As New R_Exception
        Dim loBatchPar As R_BatchParameter
        Dim loUserParameters As New List(Of R_KeyValue)
        Dim loUserPar As R_KeyValue
        Dim loSvc As R_ProcessAndUploadClient
        Dim lcSourceFilePath As String
        Dim lcZipFilePath As String
        Dim loKey As New RCustDBFileKeyDTO
        Dim loProcessKey As New RCustDBFileProcessKeyDTO
        Dim loFileInfo As New List(Of RCustDBFileInfoDTO)
        Dim loFileByte As RCustDBFileEntityDTO
        Dim loFileBytes As New List(Of RCustDBFileEntityDTO)
        Dim loSourceByte As Byte()
        Dim loBuildByte As Byte()
        Dim lcKeyGuid As String
        Dim loFilenames As New List(Of String)
        Dim lcFilenames As String()
        Dim loSearchPatterns As String()
        Dim loStatusKey As New RCustDBProcessTransactionDTO
        Dim loValidationResult As List(Of RCustDBProcessValidationDTO)
        Dim llSkipItem As Boolean

        Try
            For Each loItem As RCustDBFileProcessKeyDTO In OFILE_PROCESS_KEY
                llSkipItem = False

                With loKey
                    .CCOMPANY_ID = loItem.CCOMPANY_ID
                    .CAPPS_CODE = loItem.CAPPS_CODE
                    .CVERSION = loItem.CVERSION
                    .CATTRIBUTE_GROUP = loItem.CATTRIBUTE_GROUP
                    .CATTRIBUTE_ID = loItem.CATTRIBUTE_ID
                    .CITEM_ID = loItem.CITEM_ID
                    .CFUNCTION_ID = loItem.CFUNCTION_ID
                    .CUSER_ID = loItem.CUSER_ID
                    .CFILE_GROUP = "SOURCE"
                End With

                lcZipFilePath = GetPath("Zip", loKey)
                loSourceByte = Nothing
                loBuildByte = Nothing

                ' Validation
                With loStatusKey
                    .CCOMPANY_ID = loItem.CCOMPANY_ID
                    .CAPPS_CODE = loItem.CAPPS_CODE
                    .CVERSION = loItem.CVERSION
                    .CPROJECT_ID = loItem.CPROJECT_ID
                    .CSESSION_ID = loItem.CSESSION_ID
                    .CSCHEDULE_ID = loItem.CSCHEDULE_ID
                    .CATTRIBUTE_GROUP = loItem.CATTRIBUTE_GROUP
                    .CATTRIBUTE_ID = loItem.CATTRIBUTE_ID
                    .CITEM_ID = loItem.CITEM_ID
                    .CFUNCTION_ID = loItem.CFUNCTION_ID
                    .CACTION = loItem.CACTION
                    .CUSER_ID = loItem.CUSER_ID
                End With
                loValidationResult = loService.CheckinValidation(loStatusKey)
                If loValidationResult.Count > 0 Then
                    For Each result As RCustDBProcessValidationDTO In loValidationResult
                        loException.Add(result.CMESSAGE_CODE, result.CDESCRIPTION)
                    Next
                    Continue For
                End If

                ' Check and make sure if Realta temp zip folder exists
                If Not Directory.Exists(C_ZipPath) Then
                    Directory.CreateDirectory(C_ZipPath)
                End If

                If loItem.CFUNCTION_ID.Equals("DESIGN") Or loItem.CFUNCTION_ID.Equals("DEVELOPMENT") Then
                    ' Get source info
                    With loKey
                        .CCOMPANY_ID = loItem.CCOMPANY_ID
                        .CAPPS_CODE = loItem.CAPPS_CODE
                        .CVERSION = loItem.CVERSION
                        .CATTRIBUTE_GROUP = loItem.CATTRIBUTE_GROUP
                        .CATTRIBUTE_ID = loItem.CATTRIBUTE_ID
                        .CITEM_ID = loItem.CITEM_ID
                        .CFUNCTION_ID = loItem.CFUNCTION_ID
                        .CUSER_ID = loItem.CUSER_ID
                    End With
                    loFileInfo = loService.GetFileInfo(loKey)

                    If loFileInfo.Count <= 0 Then
                        loException.Add("Err004", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "Err004").Trim & " (Item ID: " & loItem.CITEM_ID.Trim & ")") ' Item has never been checked-out
                        Continue For
                    End If

                    ' loop for each source
                    For Each loFile As RCustDBFileInfoDTO In loFileInfo

                        lcSourceFilePath = C_RootPath.Trim & loFile.CFILE_PATH.Trim
                        If loFile.LSINGLE_FILE Then
                            If Not File.Exists(lcSourceFilePath.Trim + loFile.CSOURCE_ID.Trim + loFile.CFILE_EXTENSION.Trim) Then
                                loException.Add("Err001", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "Err001").Trim & " (File: " & lcSourceFilePath.Trim & loFile.CSOURCE_ID.Trim & loFile.CFILE_EXTENSION.Trim & ")") ' Folder does not exist
                                llSkipItem = True
                                Exit For
                            End If
                        Else
                            ' ***** Zip file *****
                            ' Check if source folder exists
                            If Not Directory.Exists(lcSourceFilePath) Then
                                loException.Add("Err001", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "Err001").Trim & " (Folder: " & lcSourceFilePath.Trim & ")") ' Folder does not exist
                                llSkipItem = True
                                Exit For
                            Else
                                If Directory.EnumerateFiles(lcSourceFilePath).Count = 0 _
                                    And Directory.EnumerateDirectories(lcSourceFilePath).Count = 0 Then
                                    loException.Add("Err002", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "Err002").Trim & " (Folder: " & lcSourceFilePath.Trim & ")") ' Folder is empty
                                    llSkipItem = True
                                    Exit For
                                End If
                            End If
                        End If

                        Using zip As ZipFile = New ZipFile
                            zip.CompressionMethod = CompressionMethod.Deflate
                            zip.ParallelDeflateThreshold = -1
                            If loFile.LSINGLE_FILE Then
                                zip.AddFile(lcSourceFilePath.Trim + loFile.CSOURCE_ID.Trim + loFile.CFILE_EXTENSION.Trim, "")
                            Else
                                zip.AddDirectory(lcSourceFilePath)
                            End If
                            zip.Save(lcZipFilePath)
                        End Using
                        loSourceByte = R_Utility.GetByteFromFile(lcZipFilePath)
                        File.Delete(lcZipFilePath)

                        If loItem.CFUNCTION_ID.Equals("DEVELOPMENT") And loFile.LBUILD_CHECK_IN Then
                            lcSourceFilePath = C_RootPath.Trim & loFile.CBUILD_PATH.Trim
                            ' Check if build folder exists
                            If Not Directory.Exists(lcSourceFilePath) Then
                                loException.Add("Err001", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "Err001").Trim & " (Folder: " & lcSourceFilePath.Trim & ")") ' Folder does not exist
                                llSkipItem = True
                                Exit For
                            Else
                                If Directory.EnumerateFiles(lcSourceFilePath).Count = 0 _
                                    And Directory.EnumerateDirectories(lcSourceFilePath).Count = 0 Then
                                    loException.Add("Err002", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "Err002").Trim & " (Folder: " & lcSourceFilePath.Trim & ")") ' Folder is empty
                                    llSkipItem = True
                                    Exit For
                                Else
                                    ' Check if build file exists
                                    ' First, split search patterns
                                    If loFile.CBUILD_EXTENSION.Trim.Equals("") Then
                                        loException.Add("Err005", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "Err005").Trim & " (Folder: " & lcSourceFilePath.Trim & ")") ' no build file extensions defined
                                        llSkipItem = True
                                    Else
                                        loSearchPatterns = loFile.CBUILD_EXTENSION.Split("|")
                                        loFilenames.Clear()
                                        For Each loSearchPattern As String In loSearchPatterns
                                            loFilenames.AddRange(Directory.GetFiles(lcSourceFilePath, loSearchPattern, SearchOption.TopDirectoryOnly)) ' .Select(Function(x) Path.GetFileName(x)))
                                        Next
                                        lcFilenames = loFilenames.ToArray
                                        If lcFilenames.Count = 0 Then
                                            loException.Add("Err003", R_Utility.R_GetMessage(GetType(Resources_Dummy_Class), "Err003").Trim & " (Folder: " & lcSourceFilePath.Trim & ")") ' no build file
                                            llSkipItem = True
                                            Exit For
                                        End If
                                    End If
                                End If
                            End If
                            Using zip As ZipFile = New ZipFile
                                zip.CompressionMethod = CompressionMethod.Deflate
                                zip.ParallelDeflateThreshold = -1
                                zip.AddFiles(lcFilenames, "")
                                zip.Save(lcZipFilePath)
                            End Using
                            loBuildByte = R_Utility.GetByteFromFile(lcZipFilePath)
                            File.Delete(lcZipFilePath)
                        End If

                        'Kirim Data ke Big Object
                        loFileByte = New RCustDBFileEntityDTO
                        With loFileByte
                            .CCOMPANY_ID = loItem.CCOMPANY_ID
                            .CAPPS_CODE = loItem.CAPPS_CODE
                            .CVERSION = loItem.CVERSION
                            .CPROJECT_ID = loItem.CPROJECT_ID
                            .CSESSION_ID = loItem.CSESSION_ID
                            .CFUNCTION_ID = loItem.CFUNCTION_ID
                            .CSCHEDULE_ID = loItem.CSCHEDULE_ID
                            .CATTRIBUTE_GROUP = loItem.CATTRIBUTE_GROUP
                            .CATTRIBUTE_ID = loItem.CATTRIBUTE_ID
                            .CITEM_ID = loItem.CITEM_ID
                            .CSOURCE_ID = loFile.CSOURCE_ID
                            .CNOTE = CBACKUP_NOTE
                            .OFILE_BYTE = loSourceByte
                            .OBUILD_BYTE = loBuildByte
                        End With
                        loFileBytes.Add(loFileByte)
                    Next
                End If
                If llSkipItem Then
                    Continue For
                End If

                'prepare Batch Parameter
                With loProcessKey
                    .CCOMPANY_ID = loItem.CCOMPANY_ID
                    .CAPPS_CODE = loItem.CAPPS_CODE
                    .CVERSION = loItem.CVERSION
                    .CPROJECT_ID = loItem.CPROJECT_ID
                    .CSESSION_ID = loItem.CSESSION_ID
                    .CFUNCTION_ID = loItem.CFUNCTION_ID
                    .CSCHEDULE_ID = loItem.CSCHEDULE_ID
                    .CACTION = loItem.CACTION
                    .CUSER_ID = loItem.CUSER_ID
                    .CATTRIBUTE_GROUP = loItem.CATTRIBUTE_GROUP
                    .CATTRIBUTE_ID = loItem.CATTRIBUTE_ID
                    .CITEM_ID = loItem.CITEM_ID
                    .CFILE_GROUP = "SOURCE"
                End With
                With loUserPar
                    .Key = "OPROCESS_KEY"
                    .Value = R_Utility.Serialize(loProcessKey)
                End With
                loUserParameters.Add(loUserPar)
            Next


            If loUserParameters.Count > 0 Then

                'Instantiate FrontHelper

                loSvc = New R_ProcessAndUploadClient(Nothing, Nothing, Nothing)
                AddHandler loSvc.ProcessError, AddressOf ProcessError
                AddHandler loSvc.ProcessComplete, AddressOf ProcessComplete

                With loBatchPar
                    .COMPANY_ID = CCOMPANY_ID
                    .USER_ID = CUSER_ID
                    .ClassName = "RLicenseBack.FileHandlerCls"
                    .BigObject = loFileBytes
                    .UserParameters = loUserParameters
                End With
                lcKeyGuid = loSvc.R_BatchProcess(loBatchPar, Nothing)
            End If

        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ThrowExceptionIfErrors()

    End Sub

    Public Sub CancelCheckOut()
        'Dim loService As FileServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IFileService, FileServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)
        Dim loException As New R_Exception
        Dim loStatusKeys As New List(Of RCustDBProcessTransactionDTO)

        Try
            For Each loItem As RCustDBFileProcessKeyDTO In OFILE_PROCESS_KEY

                ' Update status
                loStatusKeys.Add(New RCustDBProcessTransactionDTO With {
                                 .CCOMPANY_ID = loItem.CCOMPANY_ID, _
                                 .CAPPS_CODE = loItem.CAPPS_CODE, _
                                 .CVERSION = loItem.CVERSION, _
                                 .CPROJECT_ID = loItem.CPROJECT_ID, _
                                 .CSESSION_ID = loItem.CSESSION_ID, _
                                 .CSCHEDULE_ID = loItem.CSCHEDULE_ID, _
                                 .CATTRIBUTE_GROUP = loItem.CATTRIBUTE_GROUP, _
                                 .CATTRIBUTE_ID = loItem.CATTRIBUTE_ID, _
                                 .CITEM_ID = loItem.CITEM_ID, _
                                 .CFUNCTION_ID = loItem.CFUNCTION_ID, _
                                 .CACTION = loItem.CACTION, _
                                 .CUSER_ID = loItem.CUSER_ID})
            Next
            loService.CheckoutStatus(loStatusKeys)
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loException.ThrowExceptionIfErrors()
    End Sub

    Private Sub ProcessComplete(pcKeyGuid As String, poProcessResultMode As eProcessResultMode)
        Dim loEx As New R_Exception()

        Select Case poProcessResultMode
            Case eProcessResultMode.Success
                MsgBox("Process Complete")
            Case eProcessResultMode.Fail
                Dim loException As New R_Exception
                Dim loRtn As List(Of R_ErrorStatusReturn)
                Dim loHelp As New R_ProcessAndUploadClient(Nothing, Nothing, Nothing)
                Dim loPar As R_UploadAndProcessKey

                Try
                    With loPar
                        .COMPANY_ID = CCOMPANY_ID
                        .USER_ID = CUSER_ID
                        .KEY_GUID = pcKeyGuid
                    End With
                    loRtn = loHelp.R_GetErrorProcess(loPar)

                    For Each loError As R_ErrorStatusReturn In loRtn
                        loEx.Add(loError.SeqNo.ToString, loError.ErrorMessage)
                    Next
                Catch ex As Exception
                    loException.Add(ex)
                End Try

                If loException.Haserror Then
                    loEx.ThrowExceptionIfErrors()
                End If
        End Select
    End Sub

    Private Sub ProcessError(pcKeyGuid As String, ex As R_Exception)
        Dim loException As New R_Exception

        If ex.Haserror Then
            loException.Add(ex)
            OEXCEPTION = loException
        End If
        loException.ThrowExceptionIfErrors()
    End Sub

End Class
