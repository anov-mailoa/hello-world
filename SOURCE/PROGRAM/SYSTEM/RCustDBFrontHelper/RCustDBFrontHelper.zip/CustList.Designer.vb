﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CustList
    Inherits R_FrontEnd.R_FormBase

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim R_GridViewTextBoxColumn1 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Dim R_GridViewTextBoxColumn2 As R_FrontEnd.R_GridViewTextBoxColumn = New R_FrontEnd.R_GridViewTextBoxColumn()
        Me.gvCustomer = New R_FrontEnd.R_RadGridView(Me.components)
        Me.bsCustomer = New System.Windows.Forms.BindingSource(Me.components)
        Me.R_ReturnLookUpAndFind1 = New R_FrontEnd.R_ReturnLookUpAndFind()
        CType(Me.gvCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gvCustomer.MasterTemplate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.bsCustomer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'gvCustomer
        '
        Me.gvCustomer.EnableFastScrolling = True
        Me.gvCustomer.Location = New System.Drawing.Point(12, 12)
        '
        '
        '
        Me.gvCustomer.MasterTemplate.AutoGenerateColumns = False
        Me.gvCustomer.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        R_GridViewTextBoxColumn1.FieldName = "CCUSTOMER_CODE"
        R_GridViewTextBoxColumn1.HeaderText = "_CCUSTOMER_CODE"
        R_GridViewTextBoxColumn1.Name = "_CCUSTOMER_CODE"
        R_GridViewTextBoxColumn1.R_ResourceId = "_CCUSTOMER_CODE"
        R_GridViewTextBoxColumn1.R_UDT = Nothing
        R_GridViewTextBoxColumn1.Width = 126
        R_GridViewTextBoxColumn2.FieldName = "CCUSTOMER_NAME"
        R_GridViewTextBoxColumn2.HeaderText = "_CCUSTOMER_NAME"
        R_GridViewTextBoxColumn2.Name = "_CCUSTOMER_NAME"
        R_GridViewTextBoxColumn2.R_ResourceId = "_CCUSTOMER_NAME"
        R_GridViewTextBoxColumn2.R_UDT = Nothing
        R_GridViewTextBoxColumn2.Width = 275
        Me.gvCustomer.MasterTemplate.Columns.AddRange(New Telerik.WinControls.UI.GridViewDataColumn() {R_GridViewTextBoxColumn1, R_GridViewTextBoxColumn2})
        Me.gvCustomer.MasterTemplate.DataSource = Me.bsCustomer
        Me.gvCustomer.MasterTemplate.EnableAlternatingRowColor = True
        Me.gvCustomer.MasterTemplate.EnableFiltering = True
        Me.gvCustomer.MasterTemplate.EnableGrouping = False
        Me.gvCustomer.MasterTemplate.ShowFilteringRow = False
        Me.gvCustomer.MasterTemplate.ShowGroupedColumns = True
        Me.gvCustomer.MasterTemplate.ShowHeaderCellButtons = True
        Me.gvCustomer.Name = "gvCustomer"
        Me.gvCustomer.R_AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill
        Me.gvCustomer.R_ConductorGridSource = Nothing
        Me.gvCustomer.R_ConductorSource = Nothing
        Me.gvCustomer.R_DataAdded = False
        Me.gvCustomer.R_NewRowText = Nothing
        Me.gvCustomer.ShowHeaderCellButtons = True
        Me.gvCustomer.Size = New System.Drawing.Size(420, 231)
        Me.gvCustomer.TabIndex = 1
        Me.gvCustomer.Text = "R_RadGridView1"
        '
        'bsCustomer
        '
        Me.bsCustomer.DataSource = GetType(RCustDBFrontHelper.FileStreamingServiceRef.RCustDBCustListDTO)
        '
        'R_ReturnLookUpAndFind1
        '
        Me.R_ReturnLookUpAndFind1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.R_ReturnLookUpAndFind1.Location = New System.Drawing.Point(270, 249)
        Me.R_ReturnLookUpAndFind1.Name = "R_ReturnLookUpAndFind1"
        Me.R_ReturnLookUpAndFind1.R_BindingSource = Me.bsCustomer
        Me.R_ReturnLookUpAndFind1.Size = New System.Drawing.Size(162, 31)
        Me.R_ReturnLookUpAndFind1.TabIndex = 2
        '
        'CSM00310CustList
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.ClientSize = New System.Drawing.Size(453, 280)
        Me.Controls.Add(Me.R_ReturnLookUpAndFind1)
        Me.Controls.Add(Me.gvCustomer)
        Me.Name = "CSM00310CustList"
        '
        '
        '
        Me.RootElement.ApplyShapeToControl = True
        Me.Text = "Customer List"
        CType(Me.gvCustomer.MasterTemplate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gvCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.bsCustomer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents bsCustomer As System.Windows.Forms.BindingSource
    Friend WithEvents gvCustomer As R_FrontEnd.R_RadGridView
    Friend WithEvents R_ReturnLookUpAndFind1 As R_FrontEnd.R_ReturnLookUpAndFind

End Class
