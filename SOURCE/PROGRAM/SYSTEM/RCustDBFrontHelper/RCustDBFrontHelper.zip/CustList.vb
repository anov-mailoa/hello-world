﻿Imports RCustDBFrontHelperResources
Imports R_Common
Imports RCustDBFrontHelper.FileStreamingServiceRef
Imports R_FrontEnd
Imports System.ServiceModel.Channels
Imports RCustDBFrontHelper.FileServiceRef

Public Class CustList

#Region " VARIABLE "
    Dim C_ServiceName As String = "FileService/FileService.svc"
    Dim C_ServiceNameStream As String = "FileService/FileStreamingService.svc"
    Dim _CCOMPID As String
    Dim _CAPPSCODE As String
    Dim _CVERSION As String
    Dim _INIT As Boolean = False
#End Region

#Region " FORM Events "

    Private Sub CSM00500Manager_R_Init_From_Master(poParameter As Object) Handles Me.R_Init_From_Master
        Dim oRes As New Resources_Dummy_Class
        Dim loEx As New R_Exception
        Dim loSvc As FileServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IFileService, FileServiceClient)(e_ServiceClientType.RegularService, C_ServiceName)

        Try
            gvCustomer.R_RefreshGrid(poParameter)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

    End Sub
#End Region

#Region " GRIDVIEW Events "

    Private Sub gvManager_DataBindingComplete(sender As Object, e As Telerik.WinControls.UI.GridViewBindingCompleteEventArgs) Handles gvCustomer.DataBindingComplete
        gvCustomer.BestFitColumns()
    End Sub

    Private Sub gvManager_R_ServiceGetListRecord(poEntity As Object, ByRef poListEntityResult As Object) Handles gvCustomer.R_ServiceGetListRecord
        Dim loServiceStream As FileStreamingServiceClient = R_ServiceClientWrapper.R_GetServiceClient(Of IFileStreamingService, FileStreamingServiceClient)(e_ServiceClientType.StreamingService, C_ServiceNameStream)
        Dim loException As New R_Exception
        Dim loRtn As Message
        Dim loStreaming As IEnumerable(Of RCustDBCustListDTO)
        Dim loListEntity As New List(Of RCustDBCustListDTO)

        Try
            With CType(poEntity, RCustDBFrontHelper.FileStreamingServiceRef.RCustDBFileKeyDTO)
                R_Utility.R_SetStreamingContext("cCompanyId", .CCOMPANY_ID)

                loRtn = loServiceStream.GetCustomerList()
                loStreaming = R_StreamUtility(Of RCustDBCustListDTO).ReadFromMessage(loRtn)

                For Each loDto As RCustDBCustListDTO In loStreaming
                    If loDto IsNot Nothing Then
                        loListEntity.Add(loDto)
                    Else
                        Exit For
                    End If
                Next
                poListEntityResult = loListEntity

            End With
        Catch ex As Exception
            loException.Add(ex)
        End Try
        loServiceStream.Close()
        loException.ThrowExceptionIfErrors()
    End Sub
#End Region

End Class
