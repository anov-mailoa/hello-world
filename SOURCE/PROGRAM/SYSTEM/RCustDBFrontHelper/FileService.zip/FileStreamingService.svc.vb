﻿Imports R_Common
Imports RLicenseBack
Imports System.ServiceModel.Channels

' NOTE: You can use the "Rename" command on the context menu to change the class name "FileStreamingService" in code, svc and config file together.
Public Class FileStreamingService
    Implements IFileStreamingService

    Public Function GetSourceFile() As System.ServiceModel.Channels.Message Implements IFileStreamingService.GetSourceFile
        Dim loException As New R_Exception
        Dim loCls As New FileHandlerCls
        Dim loRtnTemp As List(Of RCustDBFileDTO)
        Dim loRtn As Message
        Dim loTableKey As New RCustDBFileKeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
                .CAPPS_CODE = R_Utility.R_GetStreamingContext("cAppsCode")
                .CVERSION = R_Utility.R_GetStreamingContext("cVersion")
                .CATTRIBUTE_GROUP = R_Utility.R_GetStreamingContext("cAttributeGroup")
                .CATTRIBUTE_ID = R_Utility.R_GetStreamingContext("cAttributeId")
                .CITEM_ID = R_Utility.R_GetStreamingContext("cItemId")
            End With

            'loRtnTemp = loCls.GetSourceFile(loTableKey)

            loRtn = R_StreamUtility(Of RCustDBFileDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getSourceFile")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Function GetCustomerList() As System.ServiceModel.Channels.Message Implements IFileStreamingService.GetCustomerList
        Dim loException As New R_Exception
        Dim loCls As New RLicenseCls
        Dim loRtnTemp As List(Of RCustDBCustListDTO)
        Dim loRtn As Message
        Dim loTableKey As New RCustDBFileKeyDTO

        Try
            With loTableKey
                .CCOMPANY_ID = R_Utility.R_GetStreamingContext("cCompanyId")
            End With

            loRtnTemp = loCls.GetCustList(loTableKey.CCOMPANY_ID)

            loRtn = R_StreamUtility(Of RCustDBCustListDTO).WriteToMessage(loRtnTemp.AsEnumerable, "getCustomerList")
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ConvertAndThrowToServiceExceptionIfErrors()

        Return loRtn
    End Function

    Public Sub Dummy(poPar1 As System.Collections.Generic.List(Of RLicenseBack.RCustDBFileDTO), poPar2 As RLicenseBack.RCustDBFileKeyDTO, poPar3 As System.Collections.Generic.List(Of RLicenseBack.RCustDBCustListDTO)) Implements IFileStreamingService.Dummy

    End Sub
End Class
