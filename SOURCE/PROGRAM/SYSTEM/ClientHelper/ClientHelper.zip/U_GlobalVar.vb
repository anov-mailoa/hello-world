﻿Imports R_Common

Public Class U_GlobalVar
    Inherits R_FrontEnd.R_GlobalVar
    Implements IInitiator

    'Private Shared _UserId As String
    Private Shared _culture As String
    'Private Shared _CompId As String
    Private Shared _DTO As GlobalVarDTO
    Private Shared _Broadcast As Boolean
    'Private Shared _UserName As String
    Private Shared _CompanyName As String

    Public Shared ReadOnly Property Culture() As String
        Get
            Return _culture
        End Get
    End Property

    'Public Shared ReadOnly Property UserId() As String
    '    Get
    '        Return _UserId
    '    End Get
    'End Property

    'Public Shared ReadOnly Property CompId() As String
    '    Get
    '        Return _CompId
    '    End Get
    'End Property

    Public Shared ReadOnly Property DTO() As GlobalVarDTO
        Get
            Return _DTO
        End Get
    End Property

    Public Shared ReadOnly Property Broadcast() As Boolean
        Get
            Return _Broadcast
        End Get
    End Property

    'Public Shared ReadOnly Property UserName() As String
    '    Get
    '        Return _UserName
    '    End Get
    'End Property

    Public Shared ReadOnly Property CompanyName() As String
        Get
            Return _CompanyName
        End Get
    End Property

    'Public Sub Set_UserId(ByVal pcUserId As String) Implements IInitiator.Set_UserId
    '    _UserId = pcUserId
    '    R_Context.R_SetContext(CommonHelper.FrontBackGlobalVarEnumerator.USER_ID, pcUserId)
    'End Sub

    Public Sub Set_Culture(pcCulture As String) Implements IInitiator.Set_Culture
        _culture = pcCulture
        R_Context.R_SetContext(CommonHelper.FrontBackGlobalVarEnumerator.CULTURE, pcCulture)
    End Sub

    'Public Sub Set_CompId(ByVal pcCompId As String) Implements IInitiator.Set_CompId
    '    _CompId = pcCompId
    '    R_Context.R_SetContext(CommonHelper.FrontBackGlobalVarEnumerator.COMP_ID, pcCompId)
    'End Sub

    Public Sub Set_DTO(poDTO As GlobalVarDTO) Implements IInitiator.Set_DTO
        _DTO = poDTO
    End Sub

    Public Sub Set_Broadcast(ByVal plBroadcast As Boolean) Implements IInitiator.Set_Broadcast
        _Broadcast = plBroadcast
    End Sub

    'Public Sub Set_UserName(pcUserName As String) Implements IInitiator.Set_UserName
    '    _UserName = pcUserName
    '    R_Context.R_SetContext(CommonHelper.FrontBackGlobalVarEnumerator.USER_NAME, pcUserName)
    'End Sub

    Public Sub Set_CompanyName(ByVal pcCompanyName As String) Implements IInitiator.Set_CompanyName
        _CompanyName = pcCompanyName
        R_Context.R_SetContext(CommonHelper.FrontBackGlobalVarEnumerator.COMPANY_NAME, pcCompanyName)
    End Sub
End Class

Public Interface IInitiator
    Inherits R_FrontEnd.R_IGlobalVarInitiator

    'Sub Set_UserId(ByVal pcUserId As String)
    Sub Set_Culture(ByVal pcCulture As String)
    'Sub Set_CompId(ByVal pcCompId As String)
    Sub Set_DTO(ByVal poDTO As GlobalVarDTO)
    Sub Set_Broadcast(ByVal plBroadcast As Boolean)
    'Sub Set_UserName(ByVal pcUserName As String)
    Sub Set_CompanyName(ByVal pcCompanyName As String)
End Interface