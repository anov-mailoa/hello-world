﻿Public Class GlobalVarDTO
    Public Property cReportFilePath As String
    Public Property cCompanyLogoFilePath As String
End Class
