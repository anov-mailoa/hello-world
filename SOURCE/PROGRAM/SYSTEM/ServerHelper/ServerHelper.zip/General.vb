﻿Public Class General
    Public Shared Function getDate(pcDate As String) As String
        Return String.Format("CONVERT(DATETIME, '{0}')", pcDate)
    End Function

    Public Shared Function getBit(plBoolean As Boolean) As String
        Return IIf(plBoolean, "1", "0")
    End Function

End Class
