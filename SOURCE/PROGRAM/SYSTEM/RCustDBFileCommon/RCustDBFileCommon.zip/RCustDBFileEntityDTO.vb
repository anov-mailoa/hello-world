﻿<Serializable()> _
Public Class RCustDBFileEntityDTO
    ' Main key
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CVERSION As String
    ' Project key
    Public Property CPROJECT_ID As String
    Public Property CSESSION_ID As String
    Public Property CSCHEDULE_ID As String
    Public Property CFUNCTION_ID As String
    ' Item key
    Public Property CATTRIBUTE_GROUP As String
    Public Property CATTRIBUTE_ID As String
    Public Property CITEM_ID As String
    Public Property CSOURCE_ID As String
    ' Issue key
    Public Property CISSUE_ID As String
    Public Property CFILE_NAME As String
    Public Property CDESCRIPTION As String

    ' File
    Public Property OFILE_BYTE As Byte()
    Public Property OBUILD_BYTE As Byte()

    ' Backup
    Public Property CNOTE As String

End Class
