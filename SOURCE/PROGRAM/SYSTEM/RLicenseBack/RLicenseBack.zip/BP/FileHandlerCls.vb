﻿Imports R_Common
Imports R_BackEnd
Imports ServerHelper.General
Imports RCustDBFileCommon
Imports HelperStreamExtensionLibrary
Imports System.Data.Common
Imports System.Transactions
Imports System.IO
Imports Ionic.Zip

Public Class FileHandlerCls
    'Implements R_IAttachFile
    Implements R_IBatchProcess

    Private Const CHUNK_SIZE As Integer = 50 * 1024
    Private Shared C_ZipPath As String = "D:\RealCode\Temp\Zips"
    Private Shared C_RootPath As String = "D:\RealCodeTest"

#Region " CHECKOUT "

    Public Function GetSlicedFile(poKey As RCustDBFileSplitKeyDTO) As RCustDBFileDTO
        ' Purpose: Get sliced file; return the sliced file
        ' Parameter: Sliced file key (.CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CITEM_ID, .CFUNCTION_ID)
        Dim lcQuery As String
        Dim loResult As RCustDBFileDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "SELECT ODATA AS OFILE_BYTE "
                lcQuery += "FROM GST_SPLIT_UPLOAD (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CUSER_ID = '{1}' "
                lcQuery += "AND CKEY_GUID = '{2}' "
                lcQuery += "AND ISEQ_NO = {3} "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CUSER_ID, .CKEY_GUID, .ISEQ_NO.ToString.Trim)
            End With
            loResult = loDb.SqlExecObjectQuery(Of RCustDBFileDTO)(lcQuery).FirstOrDefault
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function SliceFile(poKey As RCustDBFileKeyDTO) As List(Of RCustDBFileSplitDTO)
        ' Purpose: Slice file and then return GUID and number of slice
        ' Parameter: File key (.CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CITEM_ID, .CFUNCTION_ID)
        Dim lcQuery As String
        Dim loResult As New List(Of RCustDBFileSplitDTO)
        Dim loTempResult As RCustDBFileSplitDTO
        Dim loTempByte As List(Of RCustDBFileDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loList As ArrayList
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim lcCmd As String
        Dim lcKeyGuid As String
        Dim lnSlice As Integer
        Dim loKey As RCustDBFileKeyDTO

        Try
            ' Get file binary
            loTempByte = GetFileByte(poKey)
            ' Slice files
            lcKeyGuid = ""
            For Each loFile As RCustDBFileDTO In loTempByte
                ' if file exists then slice file
                lnSlice = 0
                If loFile.OFILE_BYTE IsNot Nothing Then
                    loList = New ArrayList()
                    lcKeyGuid = Guid.NewGuid().ToString("N")

                    For Each loItem In loFile.OFILE_BYTE.Slices(CHUNK_SIZE).Select(Function(x, i) Tuple.Create(i, x))
                        loList.Add(loItem)
                        lnSlice += 1
                    Next

                    For Each loItem As Tuple(Of Integer, Byte()) In loList
                        loCmd = loDb.GetCommand()
                        lcCmd = "insert into GST_SPLIT_UPLOAD(CCOMPANY_ID,CUSER_ID,CKEY_GUID,ISEQ_NO,ODATA) VALUES('{0}','{1}','{2}',{3},@Data)"
                        lcCmd = String.Format(lcCmd, poKey.CCOMPANY_ID.Trim, poKey.CUSER_ID.Trim, lcKeyGuid.Trim, loItem.Item1.ToString().Trim)
                        loCmd.CommandText = lcCmd
                        loPar = loDb.GetParameter()
                        With loPar
                            .ParameterName = "@Data"
                            .DbType = DbType.Binary
                            .Value = IIf(loItem.Item2 Is Nothing, DBNull.Value, loItem.Item2)
                        End With
                        loCmd.Parameters.Add(loPar)
                        loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd, True)
                    Next

                End If

                loTempResult = New RCustDBFileSplitDTO
                loKey = New RCustDBFileKeyDTO
                With loTempResult
                    .CFILE_PATH = loFile.CFILE_PATH
                    .CKEY_GUID = lcKeyGuid
                    .OFILE_KEY = poKey.Clone
                    If poKey.CFILE_GROUP = "ISSUE" Then
                        .OFILE_KEY.CFILE_NAME = loFile.CSOURCE_ID
                    End If
                    .NSPLIT_ROW = lnSlice
                End With
                loResult.Add(loTempResult)
            Next
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Private Function GetFileByte(poKey As RCustDBFileKeyDTO) As List(Of RCustDBFileDTO)
        ' Purpose: Get file byte from table
        ' Parameter: File key (.CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CITEM_ID, .CFUNCTION_ID)
        Dim lcQuery As String
        Dim loTempByte As List(Of RCustDBFileDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            ' Get file binary
            With poKey
                Select Case .CFILE_GROUP
                    Case "SOURCE"
                        lcQuery = "EXEC RSP_Get_Item_Source '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}'  "
                        lcQuery = String.Format(lcQuery, .CCOMPANY_ID, _
                                                .CAPPS_CODE, _
                                                .CVERSION, _
                                                .CATTRIBUTE_GROUP, _
                                                .CATTRIBUTE_ID, _
                                                .CITEM_ID, _
                                                .CPROJECT_ID, _
                                                .CSESSION_ID, _
                                                .CSCHEDULE_ID, _
                                                .CBACKUP_TIME, _
                                                .CFUNCTION_ID, _
                                                .CACTION)
                    Case "ISSUE"
                        lcQuery = "EXEC RSP_Get_Issue_Attachment '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}' "
                        lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID, .CSESSION_ID, .CFUNCTION_ID, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CITEM_ID, .CISSUE_ID)
                    Case "PROGRAM_ICON"
                        lcQuery = "EXEC RSP_Get_Program_Icon '{0}', '{1}', '{2}', '{3}', '{4}' "
                        lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CITEM_ID)
                End Select

            End With
            loTempByte = loDb.SqlExecObjectQuery(Of RCustDBFileDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loEx.ThrowExceptionIfErrors()
        Return loTempByte
    End Function

    Public Sub CheckoutStatus(poKey As List(Of RCustDBProcessTransactionDTO))
        ' Purpose: Update checkout status
        ' Parameter: Process key (.CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID, .CSESSION_ID, .CSCHEDULE_ID, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CITEM_ID, .CFUNCTION_ID, .CACTION, .CUSER_ID)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loResult As List(Of RCustDBProcessValidationDTO)

        Try
            For Each loKey As RCustDBProcessTransactionDTO In poKey

                With loKey
                    lcQuery = "EXEC RSP_Process_Validation '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}' "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, _
                                                            .CAPPS_CODE, _
                                                            .CVERSION, _
                                                            .CPROJECT_ID, _
                                                            .CSESSION_ID, _
                                                            .CSCHEDULE_ID, _
                                                            .CATTRIBUTE_GROUP, _
                                                            .CATTRIBUTE_ID, _
                                                            .CITEM_ID, _
                                                            .CFUNCTION_ID, _
                                                            .CACTION, _
                                                            .CUSER_ID)
                    loResult = loDb.SqlExecObjectQuery(Of RCustDBProcessValidationDTO)(lcQuery)
                    If loResult.Count > 0 Then
                        For Each result As RCustDBProcessValidationDTO In loResult
                            loEx.Add(result.CMESSAGE_CODE, result.CDESCRIPTION)
                        Next
                        Continue For
                    End If
                    lcQuery = "EXEC RSP_Item_Process '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}' "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, _
                                                    .CAPPS_CODE, _
                                                    .CVERSION, _
                                                    .CPROJECT_ID, _
                                                    .CSESSION_ID, _
                                                    .CSCHEDULE_ID, _
                                                    .CATTRIBUTE_GROUP, _
                                                    .CATTRIBUTE_ID, _
                                                    .CITEM_ID, _
                                                    .CFUNCTION_ID, _
                                                    .CACTION, _
                                                    .CUSER_ID)
                End With
                loDb.SqlExecNonQuery(lcQuery)
            Next

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#End Region

#Region " CHECKIN "

    Public Function CheckinValidation(poKey As RCustDBProcessTransactionDTO) As List(Of RCustDBProcessValidationDTO)
        ' Purpose: checkin validation
        ' Parameter: Process key (.CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID, .CSESSION_ID, .CSCHEDULE_ID, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CITEM_ID, .CFUNCTION_ID, .CACTION, .CUSER_ID)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loResult As List(Of RCustDBProcessValidationDTO)

        Try
            With poKey
                lcQuery = "EXEC RSP_Process_Validation '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, _
                                                        .CAPPS_CODE, _
                                                        .CVERSION, _
                                                        .CPROJECT_ID, _
                                                        .CSESSION_ID, _
                                                        .CSCHEDULE_ID, _
                                                        .CATTRIBUTE_GROUP, _
                                                        .CATTRIBUTE_ID, _
                                                        .CITEM_ID, _
                                                        .CFUNCTION_ID, _
                                                        .CACTION, _
                                                        .CUSER_ID)
                loResult = loDb.SqlExecObjectQuery(Of RCustDBProcessValidationDTO)(lcQuery)
            End With
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Sub R_BatchProcess(poBatchProcessPar As R_Common.R_BatchProcessPar) Implements R_Common.R_IBatchProcess.R_BatchProcess
        Dim loException As New R_Exception()
        Dim loDb As New R_Db()
        Dim loCmd As DbCommand
        Dim loPar As DbParameter
        Dim loObject As List(Of RCustDBFileEntityDTO)
        Dim lcQuery As String
        Dim loProcessKey As RCustDBFileProcessKeyDTO
        'Dim loFiles As List(Of RCustDBFileEntityDTO)
        Dim loFileSetting As RCustDBFileDTO
        Dim lcSourceFilePath As String
        Dim lcZipFilePath As String

        Try
            Dim loUserPars = From userPar In CType(poBatchProcessPar.UserParameters, List(Of R_KeyValue)) Where userPar.Key = "OPROCESS_KEY"

            'loUserPars = poBatchProcessPar.UserParameters.Where(Function(x) x.Key.Equals("OPROCESS_KEY", StringComparison.InvariantCultureIgnoreCase))
            loObject = R_Utility.Deserialize(poBatchProcessPar.BigObject)

            ' transaction block
            ' source check-in
            For Each loUserPar As R_KeyValue In loUserPars
                Using TransScope As New TransactionScope(TransactionScopeOption.Required)
                    loProcessKey = R_Utility.Deserialize(loUserPar.Value)

                    If loProcessKey.CFILE_GROUP = "SOURCE" Then
                        ' loop loObject
                        If loProcessKey.CFUNCTION_ID = "DESIGN" Or loProcessKey.CFUNCTION_ID = "DEVELOPMENT" Then
                            Dim loFiles = From file In loObject Where file.CCOMPANY_ID = loProcessKey.CCOMPANY_ID _
                                      And file.CAPPS_CODE = loProcessKey.CAPPS_CODE _
                                      And file.CVERSION = loProcessKey.CVERSION _
                                      And file.CPROJECT_ID = loProcessKey.CPROJECT_ID _
                                      And file.CSESSION_ID = loProcessKey.CSESSION_ID _
                                      And file.CSCHEDULE_ID = loProcessKey.CSCHEDULE_ID _
                                      And file.CATTRIBUTE_GROUP = loProcessKey.CATTRIBUTE_GROUP _
                                      And file.CATTRIBUTE_ID = loProcessKey.CATTRIBUTE_ID _
                                      And file.CITEM_ID = loProcessKey.CITEM_ID

                            For Each loFile As RCustDBFileEntityDTO In loFiles
                                With loFile
                                    ' Save file
                                    loCmd = loDb.GetCommand()
                                    lcQuery = "EXEC RSP_Save_Item_Source '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}', @OFILE_DATA, @OBUILD_DATA, '{13}' "
                                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, _
                                                                           .CAPPS_CODE, _
                                                                           .CVERSION, _
                                                                           .CPROJECT_ID, _
                                                                           .CSESSION_ID, _
                                                                           .CSCHEDULE_ID, _
                                                                           .CATTRIBUTE_GROUP, _
                                                                           .CATTRIBUTE_ID, _
                                                                           .CITEM_ID, _
                                                                           .CSOURCE_ID, _
                                                                poBatchProcessPar.Key.USER_ID, _
                                                                           .CFUNCTION_ID, _
                                                                loProcessKey.CACTION, _
                                                                .CNOTE)
                                    loCmd.CommandText = lcQuery
                                    loPar = loDb.GetParameter()
                                    With loPar
                                        .ParameterName = "@OFILE_DATA"
                                        .DbType = DbType.Binary
                                        .Value = IIf(loFile.OFILE_BYTE Is Nothing, DBNull.Value, loFile.OFILE_BYTE)
                                    End With
                                    loCmd.Parameters.Add(loPar)
                                    loPar = loDb.GetParameter()
                                    With loPar
                                        .ParameterName = "@OBUILD_DATA"
                                        .DbType = DbType.Binary
                                        .Value = IIf(loFile.OBUILD_BYTE Is Nothing, DBNull.Value, loFile.OBUILD_BYTE)
                                    End With
                                    loCmd.Parameters.Add(loPar)
                                    loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)

                                    ' Save to RealCodeTest
                                    ' Get path
                                    lcQuery = "EXEC RSP_Get_Test_Env_Settings '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}'   "
                                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, _
                                                            .CAPPS_CODE, _
                                                            .CATTRIBUTE_GROUP, _
                                                            .CATTRIBUTE_ID, _
                                                            .CITEM_ID, _
                                                            .CSOURCE_ID, _
                                                            .CVERSION, _
                                                            .CPROJECT_ID)
                                    loFileSetting = loDb.SqlExecObjectQuery(Of RCustDBFileDTO)(lcQuery).FirstOrDefault

                                    ' Save files
                                    If loFileSetting IsNot Nothing AndAlso loFile.OBUILD_BYTE IsNot Nothing Then
                                        ' Check and make sure if Realta temp zip folder exists
                                        If Not Directory.Exists(C_ZipPath) Then
                                            Directory.CreateDirectory(C_ZipPath)
                                        End If
                                        lcZipFilePath = C_ZipPath.Trim & "\" & loFile.CSOURCE_ID.Trim & ".zip"
                                        ' Create folder if not exists
                                        lcSourceFilePath = C_RootPath.Trim & loFileSetting.CFILE_PATH.Trim
                                        If Not Directory.Exists(lcSourceFilePath) Then
                                            Directory.CreateDirectory(lcSourceFilePath)
                                        End If
                                        ' save zip file
                                        R_Utility.ConvertByteToFile(lcZipFilePath, loFile.OBUILD_BYTE)
                                        ' ***** Extract file *****
                                        ' Extract file only if exists
                                        Using zip As ZipFile = ZipFile.Read(lcZipFilePath)
                                            zip.ExtractAll(lcSourceFilePath, ExtractExistingFileAction.OverwriteSilently)
                                        End Using
                                        ' Delete Zip File
                                        File.Delete(lcZipFilePath)
                                    End If

                                End With
                            Next
                        End If

                        ' Save to process log
                        If Not loProcessKey.CACTION.Equals("BACKUP") Then
                            With loProcessKey
                                lcQuery = "EXEC RSP_Item_Process '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}' "
                                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, _
                                                                        .CAPPS_CODE, _
                                                                        .CVERSION, _
                                                                        .CPROJECT_ID, _
                                                                        .CSESSION_ID, _
                                                                        .CSCHEDULE_ID, _
                                                                        .CATTRIBUTE_GROUP, _
                                                                        .CATTRIBUTE_ID, _
                                                                        .CITEM_ID, _
                                                                        .CFUNCTION_ID, _
                                                                        .CACTION, _
                                                                        .CUSER_ID)
                                loDb.SqlExecNonQuery(lcQuery)
                            End With

                        End If

                    End If

                    ' issue attachments
                    If loProcessKey.CFILE_GROUP = "ISSUE" Then
                        ' save file
                        For Each loFile As RCustDBFileEntityDTO In loObject
                            loCmd = loDb.GetCommand()
                            With loFile
                                lcQuery = "INSERT INTO CST_ISSUES_ATTACH ("
                                lcQuery += "CCOMPANY_ID, "
                                lcQuery += "CAPPS_CODE, "
                                lcQuery += "CVERSION, "
                                lcQuery += "CPROJECT_ID, "
                                lcQuery += "CSESSION_ID, "
                                lcQuery += "CATTRIBUTE_GROUP, "
                                lcQuery += "CATTRIBUTE_ID, "
                                lcQuery += "CITEM_ID, "
                                lcQuery += "CISSUE_ID, "
                                lcQuery += "CFILE_NAME, "
                                lcQuery += "CDESCRIPTION, "
                                lcQuery += "OBINARY_FILE_DATA, "
                                lcQuery += "CUPDATE_BY, "
                                lcQuery += "DUPDATE_DATE, "
                                lcQuery += "CCREATE_BY, "
                                lcQuery += "DCREATE_DATE) "
                                lcQuery += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', @OFILE_DATA, '{11}', GETDATE(), '{11}', GETDATE()) "
                                lcQuery = String.Format(lcQuery,
                                .CCOMPANY_ID,
                                .CAPPS_CODE,
                                .CVERSION,
                                .CPROJECT_ID,
                                .CSESSION_ID,
                                .CATTRIBUTE_GROUP,
                                .CATTRIBUTE_ID,
                                .CITEM_ID,
                                .CISSUE_ID,
                                .CFILE_NAME,
                                .CDESCRIPTION,
                                poBatchProcessPar.Key.USER_ID)
                                loCmd.CommandText = lcQuery
                                loPar = loDb.GetParameter()
                                With loPar
                                    .ParameterName = "@OFILE_DATA"
                                    .DbType = DbType.Binary
                                    .Value = IIf(loFile.OFILE_BYTE Is Nothing, DBNull.Value, loFile.OFILE_BYTE)
                                End With
                                loCmd.Parameters.Add(loPar)
                                loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)
                            End With
                        Next
                    End If

                    ' program icon
                    If loProcessKey.CFILE_GROUP = "PROGRAM_ICON" Then
                        For Each loFile As RCustDBFileEntityDTO In loObject
                            loCmd = loDb.GetCommand()
                            With loFile
                                lcQuery = "UPDATE CSM_PROGRAMS "
                                lcQuery += "SET OBINARY_ICON_DATA = @OFILE_DATA, "
                                lcQuery += "CUPDATE_BY = '{5}', "
                                lcQuery += "DUPDATE_DATE = GETDATE() "
                                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                                lcQuery += "AND CAPPS_CODE = '{1}' "
                                lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
                                lcQuery += "AND CATTRIBUTE_ID = '{3}' "
                                lcQuery += "AND CPROGRAM_ID = '{4}' "
                                lcQuery = String.Format(lcQuery,
                                .CCOMPANY_ID,
                                .CAPPS_CODE,
                                .CATTRIBUTE_GROUP,
                                .CATTRIBUTE_ID,
                                .CITEM_ID,
                                poBatchProcessPar.Key.USER_ID)
                                loCmd.CommandText = lcQuery
                                loPar = loDb.GetParameter()
                                With loPar
                                    .ParameterName = "@OFILE_DATA"
                                    .DbType = DbType.Binary
                                    .Value = IIf(loFile.OFILE_BYTE Is Nothing, DBNull.Value, loFile.OFILE_BYTE)
                                End With
                                loCmd.Parameters.Add(loPar)
                                loDb.SqlExecNonQuery(loDb.GetConnection(), loCmd)
                            End With
                        Next
                    End If
                    TransScope.Complete()
                End Using
            Next


        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ThrowExceptionIfErrors()

    End Sub
    Public Function GetItemInfo(poKey As RCustDBFileKeyDTO) As List(Of RCustDBFileInfoDTO)
        ' Purpose: Get file info; return the file path
        ' Parameter: File key (.CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CITEM_ID, .CFUNCTION_ID)
        Dim lcQuery As String
        Dim loResult As List(Of RCustDBFileInfoDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "EXEC RSP_Get_Item_Info '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CITEM_ID, .CFUNCTION_ID)
            End With
            loResult = loDb.SqlExecObjectQuery(Of RCustDBFileInfoDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

#End Region

#Region " CANCEL CHECKOUT "
    Public Sub CancelCheckoutStatus(poKey As RCustDBProcessTransactionDTO)
        ' Purpose: Update cancel checkout status
        ' Parameter: Process key (.CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID, .CFUNCTION_ID, .CSESSION_ID, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID, .CITEM_ID, .CSEQUENCE, .CACTION, .CUSER_ID)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loResult As List(Of RCustDBProcessValidationDTO)

        Try
            With poKey
                lcQuery = "EXEC RSP_Item_Process '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, _
                                                        .CAPPS_CODE, _
                                                        .CVERSION, _
                                                        .CPROJECT_ID, _
                                                        .CSESSION_ID, _
                                                        .CSCHEDULE_ID, _
                                                        .CATTRIBUTE_GROUP, _
                                                        .CATTRIBUTE_ID, _
                                                        .CITEM_ID, _
                                                        .CFUNCTION_ID, _
                                                        .CACTION, _
                                                        .CUSER_ID)
            End With
            loDb.SqlExecNonQuery(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
#End Region

End Class
