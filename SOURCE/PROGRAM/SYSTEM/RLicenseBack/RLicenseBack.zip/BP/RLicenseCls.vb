﻿Imports R_BackEnd
Imports R_Common
Imports ServerHelper.General

Public Class RLicenseCls

    Public Function GetAppCombo(pcCompany_ID As String, pcUser_ID As String, Optional pcCommercial As String = "Y") As List(Of RLicenseAppComboDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RLicenseAppComboDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "EXEC RSP_Get_App_Combo '{0}', '{1}', '{2}' "
            lcQuery = String.Format(lcQuery, pcCompany_ID, pcUser_ID, pcCommercial)
            loResult = loDb.SqlExecObjectQuery(Of RLicenseAppComboDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetCustCombo(pcCompany_ID As String) As List(Of RLicenseCustComboDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RLicenseCustComboDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT CCUSTOMER_CODE, "
            lcQuery += "RTRIM(CCUSTOMER_CODE) + ' | ' + RTRIM(CCUSTOMER_NAME) AS CCUSTOMER_NAME "
            lcQuery += "FROM "
            lcQuery += "LAM_CUSTOMER (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery = String.Format(lcQuery, pcCompany_ID)

            loResult = loDb.SqlExecObjectQuery(Of RLicenseCustComboDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetCustByAppsCombo(pcCompany_ID As String, pcApps_Code As String) As List(Of RLicenseCustComboDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RLicenseCustComboDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT DISTINCT A.CCUSTOMER_CODE, "
            lcQuery += "RTRIM(A.CCUSTOMER_CODE) + ' | ' + RTRIM(A.CCUSTOMER_NAME) AS CCUSTOMER_NAME "
            lcQuery += "FROM "
            lcQuery += "LAM_CUSTOMER A (NOLOCK) "
            lcQuery += "JOIN LAM_APP_CUST B (NOLOCK) "
            lcQuery += "ON B.CCOMPANY_ID = A.CCOMPANY_ID "
            lcQuery += "AND B.CCUSTOMER_CODE = A.CCUSTOMER_CODE "
            lcQuery += "WHERE A.CCOMPANY_ID = '{0}' "
            lcQuery += "AND B.CAPPS_CODE = '{1}' "
            lcQuery = String.Format(lcQuery, pcCompany_ID, pcApps_Code)

            loResult = loDb.SqlExecObjectQuery(Of RLicenseCustComboDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetVersionCombo(pcCompany_ID As String, pcApps_Code As String) As List(Of RCustDBVersionComboDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RCustDBVersionComboDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "EXEC RSP_Get_Version_Combo '{0}', '{1}' "
            lcQuery = String.Format(lcQuery, pcCompany_ID, pcApps_Code)

            loResult = loDb.SqlExecObjectQuery(Of RCustDBVersionComboDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetAttributeCombo(pcCompany_ID As String, pcApps_Code As String, pcAttribute_Group As String) As List(Of RCustDBAttributeComboDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RCustDBAttributeComboDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT CATTRIBUTE_ID, CATTRIBUTE_NAME "
            lcQuery += "FROM "
            lcQuery += "CSM_ATTRIBUTES (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery += "AND CAPPS_CODE = '{1}' "
            lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
            lcQuery = String.Format(lcQuery, pcCompany_ID, pcApps_Code, pcAttribute_Group)

            loResult = loDb.SqlExecObjectQuery(Of RCustDBAttributeComboDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetSourceGroupCombo(pcCompany_ID As String, pcApps_Code As String, pcAttribute_Group As String, pcAttribute_Id As String) As List(Of RCustDBSourceGroupComboDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RCustDBSourceGroupComboDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT CSOURCE_GROUP_ID "
            lcQuery += "FROM "
            lcQuery += "CSM_SOURCE_GROUPS (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery += "AND CAPPS_CODE = '{1}' "
            lcQuery += "AND CATTRIBUTE_GROUP = '{2}' "
            lcQuery += "AND CATTRIBUTE_ID = '{3}' "
            lcQuery = String.Format(lcQuery, pcCompany_ID, pcApps_Code, pcAttribute_Group, pcAttribute_Id)

            loResult = loDb.SqlExecObjectQuery(Of RCustDBSourceGroupComboDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetUserList(pcCompany_ID As String) As List(Of RCustDBUserListDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RCustDBUserListDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT B.CUSER_ID, A.CUSER_NAME "
            lcQuery += "FROM SAM_USER A (NOLOCK) "
            lcQuery += "JOIN SAM_USER_COMPANY B (NOLOCK) "
            lcQuery += "ON B.CUSER_ID = A.CUSER_ID "
            lcQuery += "WHERE B.CCOMPANY_ID = '{0}' "
            lcQuery += "AND (B.DEND_DATE IS NULL OR B.DEND_DATE <= GETDATE()) "
            lcQuery = String.Format(lcQuery, pcCompany_ID)

            loResult = loDb.SqlExecObjectQuery(Of RCustDBUserListDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetFunctionCombo(poProjectKey As RCustDBProjectKeyDTO) As List(Of RCustDBFunctionComboDTO)
        Dim lcQuery As String
        Dim loResult As New List(Of RCustDBFunctionComboDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loTempResult As String

        Try
            If poProjectKey.LCHECK_PROJECT_MANAGER Then
                ' Check if user is project manager
                With poProjectKey
                    lcQuery = "SELECT CPROJECT_MANAGER "
                    lcQuery += "FROM CSM_PROJECTS (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CVERSION = '{2}' "
                    lcQuery += "AND CPROJECT_ID = '{3}' "
                    lcQuery += "AND CPROJECT_MANAGER = '{4}' "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID, .CUSER_ID)
                End With
                loTempResult = loDb.SqlExecObjectQuery(Of String)(lcQuery).FirstOrDefault
            End If

            If loTempResult IsNot Nothing Then
                ' Initialize function combo
                With loResult
                    .Add(New RCustDBFunctionComboDTO With {.CFUNCTION_ID = "DESIGN", .LMANAGER = True})
                    .Add(New RCustDBFunctionComboDTO With {.CFUNCTION_ID = "DEVELOPMENT", .LMANAGER = True})
                    .Add(New RCustDBFunctionComboDTO With {.CFUNCTION_ID = "QC", .LMANAGER = True})
                End With
            Else
                With poProjectKey
                    lcQuery = "SELECT CFUNCTION_ID, LMANAGER "
                    lcQuery += "FROM CSM_PROJECT_USERS (NOLOCK) "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                    lcQuery += "AND CAPPS_CODE = '{1}' "
                    lcQuery += "AND CVERSION = '{2}' "
                    lcQuery += "AND CPROJECT_ID = '{3}' "
                    lcQuery += "AND CSESSION_ID = '{4}' "
                    lcQuery += "AND CUSER_ID = '{5}' "
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID, .CSESSION_ID, .CUSER_ID)
                End With
                loResult = loDb.SqlExecObjectQuery(Of RCustDBFunctionComboDTO)(lcQuery)
            End If

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetAttributeGroupCombo(pcCompany_ID As String, pcApps_Code As String) As List(Of RCustDBAttributeGroupComboDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RCustDBAttributeGroupComboDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT CATTRIBUTE_GROUP "
            lcQuery += "FROM "
            lcQuery += "CSM_ATTRIBUTE_GROUPS (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery += "AND CAPPS_CODE = '{1}' "
            lcQuery = String.Format(lcQuery, pcCompany_ID, pcApps_Code)

            loResult = loDb.SqlExecObjectQuery(Of RCustDBAttributeGroupComboDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetProjectCombo(poKey As RCustDBProjectKeyDTO) As List(Of RCustDBProjectComboDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RCustDBProjectComboDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "SELECT CPROJECT_ID, CPROJECT_NAME "
                lcQuery += "FROM "
                lcQuery += "CSM_PROJECTS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CVERSION = '{2}' "
                If Not .CSTATUS.Trim.Equals("*") Then
                    lcQuery += "AND CSTATUS = '{3}' "
                End If
                lcQuery += "AND CPROJECT_MANAGER = '{4}' "
                lcQuery += "UNION "
                lcQuery += "SELECT A.CPROJECT_ID, B.CPROJECT_NAME "
                lcQuery += "FROM CSM_PROJECT_USERS A (NOLOCK) "
                lcQuery += "JOIN CSM_PROJECTS B (NOLOCK) "
                lcQuery += "ON B.CCOMPANY_ID = A.CCOMPANY_ID "
                lcQuery += "AND B.CAPPS_CODE = A.CAPPS_CODE "
                lcQuery += "AND B.CVERSION = A.CVERSION "
                lcQuery += "AND B.CPROJECT_ID = A.CPROJECT_ID "
                lcQuery += "WHERE B.CCOMPANY_ID = '{0}' "
                lcQuery += "AND B.CAPPS_CODE = '{1}' "
                lcQuery += "AND B.CVERSION = '{2}' "
                If Not .CSTATUS.Trim.Equals("*") Then
                    lcQuery += "AND B.CSTATUS = '{3}' "
                End If
                lcQuery += "AND A.CUSER_ID = '{4}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CSTATUS, .CUSER_ID)
            End With

            loResult = loDb.SqlExecObjectQuery(Of RCustDBProjectComboDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult

    End Function

    Public Function GetSessionCombo(poKey As RCustDBProjectKeyDTO) As List(Of RCustDBSessionComboDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RCustDBSessionComboDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "EXEC RSP_Get_Session_Combo '{0}', '{1}', '{2}', '{3}', '{4}'"

                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID, .CSTATUS)
            End With

            loResult = loDb.SqlExecObjectQuery(Of RCustDBSessionComboDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetItemInbox(poKey As RCustDBInboxKeyDTO) As List(Of RCustDBItemInboxDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RCustDBItemInboxDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "EXEC RSP_Item_Inbox '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID, .CSESSION_ID, .CSCHEDULE_ID, .CFUNCTION_ID, .CATTRIBUTE_GROUP, .CUSER_ID)

            End With
            loResult = loDb.SqlExecObjectQuery(Of RCustDBItemInboxDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetItemCopySource(poKey As RCustDBItemKeyDTO) As List(Of RCustDBItemCopySourceDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RCustDBItemCopySourceDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "EXEC RSP_Copy_Source_Items '{0}', '{1}', '{2}', '{3}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID)

            End With
            loResult = loDb.SqlExecObjectQuery(Of RCustDBItemCopySourceDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetItemRestore(poKey As RCustDBInboxKeyDTO) As List(Of RCustDBItemRestoreDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RCustDBItemRestoreDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "EXEC RSP_Restore_Items '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CVERSION, _
                                        .CATTRIBUTE_GROUP, _
                                        .CPROJECT_ID, _
                                        .CSESSION_ID, _
                                        .CSCHEDULE_ID, _
                                        .CFUNCTION_ID)

            End With
            loResult = loDb.SqlExecObjectQuery(Of RCustDBItemRestoreDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Sub ItemProcess(poKey As RCustDBProcessTransactionDTO)
        Dim lcQuery As String
        Dim loResult As Integer
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "EXEC RSP_Item_Process '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, _
                                                        .CAPPS_CODE, _
                                                        .CVERSION, _
                                                        .CPROJECT_ID, _
                                                        .CSESSION_ID, _
                                                        .CSCHEDULE_ID, _
                                                        .CATTRIBUTE_GROUP, _
                                                        .CATTRIBUTE_ID, _
                                                        .CITEM_ID, _
                                                        .CFUNCTION_ID, _
                                                        .CACTION, _
                                                        .CUSER_ID)
            End With
            loResult = loDb.SqlExecNonQuery(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Function GetIssueList(poKey As RCustDBIssueKeyDTO) As List(Of RCustDBIssueListDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RCustDBIssueListDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "EXEC RSP_Get_Issue_List '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', {10} "
                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CVERSION, _
                                        .CPROJECT_ID, _
                                        .CSESSION_ID, _
                                        .CATTRIBUTE_GROUP, _
                                        .CATTRIBUTE_ID, _
                                        .CITEM_ID, _
                                        .CSCHEDULE_ID, _
                                        .CPREV_SCHEDULE_ID, _
                                        getBit(.LOUTSTANDING_ONLY))
            End With
            loResult = loDb.SqlExecObjectQuery(Of RCustDBIssueListDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetIssueCombo(poKey As RCustDBIssueKeyDTO) As List(Of RCustDBIssueComboDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RCustDBIssueComboDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "EXEC RSP_Get_Issue_Combo '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', {9} "
                lcQuery = String.Format(lcQuery, _
                                        .CCOMPANY_ID, _
                                        .CAPPS_CODE, _
                                        .CVERSION, _
                                        .CPROJECT_ID, _
                                        .CSESSION_ID, _
                                        .CATTRIBUTE_GROUP, _
                                        .CATTRIBUTE_ID, _
                                        .CITEM_ID, _
                                        .CISSUE_TYPE, _
                                        getBit(.LOUTSTANDING_ONLY))
            End With

            loResult = loDb.SqlExecObjectQuery(Of RCustDBIssueComboDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

        Return loResult
    End Function

    Public Function GetItemCombo(poKey As RCustDBItemKeyDTO) As List(Of RCustDBItemComboDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RCustDBItemComboDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey
                lcQuery = "EXEC RSP_Get_Item_Combo '{0}', '{1}', '{2}', '{3}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CATTRIBUTE_GROUP, .CATTRIBUTE_ID)
            End With

            loResult = loDb.SqlExecObjectQuery(Of RCustDBItemComboDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult

    End Function

    Public Function GetScheduleTypeCombo(pcProgramID As String) As List(Of RCustDBScheduleTypeComboDTO)
        Dim lcQuery As String
        Dim loResult As New List(Of RCustDBScheduleTypeComboDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            If pcProgramID = "CSM00500" Or pcProgramID = "CSM00510" Then
                lcQuery = "SELECT CSCHEDULE_TYPE, CSCHEDULE_TYPE_NAME "
                lcQuery += "FROM "
                lcQuery += "CSM_SCHEDULE_TYPE (NOLOCK) "
                lcQuery += "WHERE LINITIAL = 1 "
                loResult = loDb.SqlExecObjectQuery(Of RCustDBScheduleTypeComboDTO)(lcQuery)
            End If
            If pcProgramID = "CSM00510" Then
                With loResult
                    .Add(New RCustDBScheduleTypeComboDTO With {.CSCHEDULE_TYPE = "4", .CSCHEDULE_TYPE_NAME = "Design Revision"})
                End With
            End If
            If pcProgramID = "" Then
                With loResult
                    .Add(New RCustDBScheduleTypeComboDTO With {.CSCHEDULE_TYPE = "5", .CSCHEDULE_TYPE_NAME = "Design Bugs"})
                    .Add(New RCustDBScheduleTypeComboDTO With {.CSCHEDULE_TYPE = "6", .CSCHEDULE_TYPE_NAME = "Program Bugs"})
                End With
            End If

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetLocationCombo() As List(Of RCustDBLocationComboDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RCustDBLocationComboDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT CLOCATION_ID, CLOCATION_NAME "
            lcQuery += "FROM "
            lcQuery += "CSM_LOCATIONS (NOLOCK) "
            lcQuery = String.Format(lcQuery)

            loResult = loDb.SqlExecObjectQuery(Of RCustDBLocationComboDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetScheduleCombo(poKey As RCustDBProjectKeyDTO) As List(Of RCustDBScheduleComboDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RCustDBScheduleComboDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "EXEC RSP_Get_Schedule_Combo '{0}', '{1}', '{2}', '{3}', '{4}', '{5}' "

                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CVERSION, .CPROJECT_ID, .CSESSION_ID, .CSTATUS)
            End With

            loResult = loDb.SqlExecObjectQuery(Of RCustDBScheduleComboDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetInboxNotification(poKey As RCustDBInboxKeyDTO) As List(Of RCustDBInboxNotificationDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RCustDBInboxNotificationDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            With poKey

                lcQuery = "EXEC RSP_Inbox_Notification '{0}', '{1}', '{2}', '{3}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, .CAPPS_CODE, .CFUNCTION_ID, .CUSER_ID)

            End With
            loResult = loDb.SqlExecObjectQuery(Of RCustDBInboxNotificationDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetCustList(pcCompany_ID As String) As List(Of RCustDBCustListDTO)
        Dim lcQuery As String
        Dim loResult As List(Of RCustDBCustListDTO)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT CCUSTOMER_CODE, "
            lcQuery += "RTRIM(CCUSTOMER_NAME) AS CCUSTOMER_NAME "
            lcQuery += "FROM "
            lcQuery += "LAM_CUSTOMER (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery = String.Format(lcQuery, pcCompany_ID)

            loResult = loDb.SqlExecObjectQuery(Of RCustDBCustListDTO)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

End Class
