﻿Public Class RCustDBFileKeyDTO
    Implements ICloneable

    ' Main key
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CVERSION As String
    ' Project key
    Public Property CPROJECT_ID As String
    Public Property CSESSION_ID As String
    Public Property CSCHEDULE_ID As String
    Public Property CFUNCTION_ID As String
    Public Property CSEQUENCE As String
    Public Property CACTION As String
    Public Property CISSUE_ID As String
    Public Property CFILE_NAME As String
    ' Item key
    Public Property CATTRIBUTE_GROUP As String
    Public Property CATTRIBUTE_ID As String
    Public Property CITEM_ID As String
    Public Property CSOURCE_ID As String
    Public Property CBACKUP_TIME As String
    ' Split key
    Public Property CUSER_ID As String
    Public Property CFILE_GROUP As String

    Public Function Clone() As Object Implements System.ICloneable.Clone
        Return Me.MemberwiseClone
    End Function
End Class
