﻿Public Class RCustDBFileInfoDTO
    Public Property CSOURCE_ID As String
    Public Property CFILE_PATH As String
    Public Property CBUILD_PATH As String
    Public Property CBUILD_EXTENSION As String
    Public Property LQC_CHECKOUT As Boolean
    Public Property LBUILD_CHECK_IN As Boolean
    Public Property LSINGLE_FILE As Boolean
    Public Property CFILE_EXTENSION As String
End Class
