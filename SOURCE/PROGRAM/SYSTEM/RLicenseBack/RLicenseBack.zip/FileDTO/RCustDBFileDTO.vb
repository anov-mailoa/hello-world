﻿Public Class RCustDBFileDTO
    Public Property CSOURCE_ID As String
    Public Property CFILE_PATH As String
    Public Property OFILE_BYTE As Byte()
End Class
