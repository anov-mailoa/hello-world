﻿Public Class RCustDBFileSplitKeyDTO
    Public Property CCOMPANY_ID As String
    Public Property CUSER_ID As String
    Public Property CKEY_GUID As String
    Public Property ISEQ_NO As Integer
End Class
