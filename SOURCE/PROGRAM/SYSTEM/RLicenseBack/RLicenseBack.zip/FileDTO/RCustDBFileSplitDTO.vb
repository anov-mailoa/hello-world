﻿Public Class RCustDBFileSplitDTO
    Public Property OFILE_KEY As New RCustDBFileKeyDTO
    Public Property CFILE_PATH As String
    Public Property CKEY_GUID As String
    Public Property NSPLIT_ROW As Integer
End Class
