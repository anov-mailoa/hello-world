﻿Public Class RCustDBScheduleComboDTO
    Public Property CSCHEDULE_ID As String
    Public Property CSCHEDULE_TYPE_NAME As String
    Public Property CSCHEDULE_DESCRIPTION As String
    Public Property CSTATUS As String
    Public Property IDESIGN_SEQUENCE As Integer
    Public Property IDEV_SEQUENCE As Integer
    Public Property IQC_SEQUENCE As Integer
End Class
