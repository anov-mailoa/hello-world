﻿Public Class RCustDBAttributeGroupComboDTO
    Public Property CATTRIBUTE_GROUP As String
End Class
