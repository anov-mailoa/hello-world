﻿Public Class RCustDBItemInboxDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CVERSION As String
    Public Property CPROJECT_ID As String
    Public Property CFUNCTION_ID As String
    Public Property CATTRIBUTE_GROUP As String
    Public Property CATTRIBUTE_ID As String
    Public Property CITEM_ID As String
    Public Property CSESSION_ID As String
    Public Property CSCHEDULE_ID As String
    Public Property NMANDAYS As Decimal
    Public Property CPLAN_START_DATE As String
    Public Property CPLAN_END_DATE As String
    Public Property CREVISED_START_DATE As String
    Public Property CREVISED_END_DATE As String
    Public Property CLAST_ACTION As String
    Public Property CLAST_ACTION_BY As String
    Public Property CITEM_STATUS As String
    Public Property CSPEC_STATUS As String
    Public Property CITEM_NAME As String
    Public Property CASSIGNMENT_STATUS As String
    Public Property CCURRENT_SCHEDULE_ID As String
    Public Property LSPEC As Boolean
    Public Property NISSUES As Integer
    Public Property CLAST_SPEC_ACTION As String
    Public Property CLAST_SPEC_ACTION_BY As String

    ' Datetime format
    Public Property DPLAN_START_DATE As Nullable(Of DateTime)
    Public Property DPLAN_END_DATE As Nullable(Of DateTime)
    Public Property DREVISED_START_DATE As Nullable(Of DateTime)
    Public Property DREVISED_END_DATE As Nullable(Of DateTime)

    ' Front
    Public Property LSELECT As Boolean

End Class
