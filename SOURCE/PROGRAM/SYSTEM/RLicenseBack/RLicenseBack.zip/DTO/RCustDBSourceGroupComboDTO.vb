﻿Public Class RCustDBSourceGroupComboDTO
    Public Property CSOURCE_GROUP_ID As String
End Class
