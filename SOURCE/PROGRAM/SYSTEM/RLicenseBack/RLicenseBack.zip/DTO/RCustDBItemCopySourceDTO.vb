﻿Public Class RCustDBItemCopySourceDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CATTRIBUTE_GROUP As String
    Public Property CATTRIBUTE_ID As String
    Public Property CITEM_ID As String
    Public Property CATTRIBUTE_NAME As String
    Public Property CITEM_NAME As String
    Public Property CINITIAL_VERSION As String
    Public Property CVERSION As String
    Public Property LSPEC As Boolean
    Public Property CCUSTOMER_NAME As String

    ' Front
    Public Property LSELECT As Boolean

End Class
