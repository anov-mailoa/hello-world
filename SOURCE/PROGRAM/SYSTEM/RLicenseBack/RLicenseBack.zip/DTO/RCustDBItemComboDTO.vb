﻿Public Class RCustDBItemComboDTO
    Public Property CITEM_ID As String
    Public Property CITEM_NAME As String
    Public Property LSPEC As Boolean
End Class
