﻿Public Class RCustDBProcessValidationDTO
    Public Property CMESSAGE_CODE As String
    Public Property CDESCRIPTION As String
End Class
