﻿Public Class RCustDBItemRestoreDTO
    Public Property CATTRIBUTE_ID As String
    Public Property CITEM_ID As String
    Public Property CITEM_NAME As String
    Public Property CSOURCE_ID As String
    Public Property CBACKUP_TIME As String
    Public Property CNOTE As String
    Public Property LSELECT As Boolean
End Class
