﻿Public Class RCustDBCustListDTO
    Public Property CCUSTOMER_CODE As String
    Public Property CCUSTOMER_NAME As String
End Class
