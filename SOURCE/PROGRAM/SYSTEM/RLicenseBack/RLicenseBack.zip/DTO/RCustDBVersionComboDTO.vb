﻿Public Class RCustDBVersionComboDTO
    Public Property CVERSION As String
    Public Property CCODE_NAME As String
    Public Property CRELEASE_DATE As String
End Class
