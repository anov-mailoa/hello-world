﻿Public Class RCustDBUserListDTO
    Public Property CUSER_ID As String
    Public Property CUSER_NAME As String
End Class
