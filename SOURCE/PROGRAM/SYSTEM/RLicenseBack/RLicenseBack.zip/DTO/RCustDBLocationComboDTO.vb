﻿Public Class RCustDBLocationComboDTO
    Public Property CLOCATION_ID As String
    Public Property CLOCATION_NAME As String
End Class
