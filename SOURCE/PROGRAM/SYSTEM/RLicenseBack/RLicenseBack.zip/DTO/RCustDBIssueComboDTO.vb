﻿Public Class RCustDBIssueComboDTO
    Public Property CISSUE_ID As String
    Public Property CDESCRIPTION As String
    Public Property LOK As Boolean
End Class
