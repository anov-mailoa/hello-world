﻿Public Class RCustDBProjectKeyDTO
    Public Property CCOMPANY_ID As String
    Public Property CAPPS_CODE As String
    Public Property CVERSION As String
    Public Property CPROJECT_ID As String
    Public Property CSESSION_ID As String
    Public Property CSCHEDULE_ID As String
    Public Property CFUNCTION_ID As String
    Public Property CATTRIBUTE_GROUP As String
    Public Property CATTRIBUTE_ID As String
    Public Property CITEM_ID As String
    Public Property CUSER_ID As String
    Public Property CSTATUS As String

    ' khusus untuk function combo
    Public Property LCHECK_PROJECT_MANAGER As Boolean

End Class
