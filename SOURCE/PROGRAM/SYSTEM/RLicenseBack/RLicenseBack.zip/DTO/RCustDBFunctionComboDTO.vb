﻿Public Class RCustDBFunctionComboDTO
    Public Property CFUNCTION_ID As String
    Public Property LMANAGER As Boolean
End Class
