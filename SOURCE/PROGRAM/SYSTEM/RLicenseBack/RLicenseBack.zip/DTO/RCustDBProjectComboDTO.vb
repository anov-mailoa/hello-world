﻿Public Class RCustDBProjectComboDTO
    Public Property CPROJECT_ID As String
    Public Property CPROJECT_NAME As String
End Class
