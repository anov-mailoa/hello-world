﻿Public Class RCustDBScheduleTypeComboDTO
    Public Property CSCHEDULE_TYPE As String
    Public Property CSCHEDULE_TYPE_NAME As String
End Class
