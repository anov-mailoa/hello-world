﻿Public Class RCustDBSessionComboDTO
    Public Property CSESSION_ID As String
    Public Property CSTATUS As String
    Public Property CSESSION_AND_STATUS As String
End Class
