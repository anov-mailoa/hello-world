﻿Public Class RCustDBAttributeComboDTO
    Public Property CATTRIBUTE_ID As String
    Public Property CATTRIBUTE_NAME As String
End Class
