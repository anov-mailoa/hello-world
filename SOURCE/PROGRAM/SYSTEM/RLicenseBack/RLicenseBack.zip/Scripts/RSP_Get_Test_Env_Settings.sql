/****** Object:  StoredProcedure [dbo].[RSP_Get_Test_Env_Settings]    Script Date: 9/22/2014 3:54:01 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RSP_Get_Test_Env_Settings]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[RSP_Get_Test_Env_Settings]
GO

/****** Object:  StoredProcedure [dbo].[RSP_Get_Test_Env_Settings]    Script Date: 9/22/2014 3:54:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Anov Mailoa
-- Create date: 16 November 2018
-- Description:	RSP_Get_Test_Env_Settings - To get test environment setting for source to be checked-in
-- =============================================
CREATE PROCEDURE [dbo].[RSP_Get_Test_Env_Settings] 
	@CCOMPANY_ID VARCHAR(8), -- 0
	@CAPPS_CODE VARCHAR(20), -- 1
	@CATTRIBUTE_GROUP VARCHAR(20), -- 2
	@CATTRIBUTE_ID VARCHAR(20), -- 3
	@CPROGRAM_ID VARCHAR(50), -- 4
	@CSOURCE_ID VARCHAR(50), -- 5
	@CVERSION VARCHAR(15), -- 6
	@CPROJECT_ID VARCHAR(20) -- 7
WITH RECOMPILE, ENCRYPTION
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @CPATH VARCHAR(MAX)
	SET @CPATH = '\' + RTRIM(@CCOMPANY_ID) + '\' + RTRIM(@CAPPS_CODE) + '\'

	DECLARE @CAPPLICATION_TYPE VARCHAR(5),
		@LCUSTOM BIT

	SELECT @LCUSTOM = LCUSTOM
	FROM CSM_PROJECTS (NOLOCK)
	WHERE CCOMPANY_ID = @CCOMPANY_ID
	AND CAPPS_CODE = @CAPPS_CODE
	AND CVERSION = @CVERSION
	AND CPROJECT_ID = @CPROJECT_ID

	IF @LCUSTOM = 0 SET @CPATH = @CPATH + 'STD\'
	ELSE SET @CPATH = @CPATH + 'CUSTOM\'

	SELECT @CAPPLICATION_TYPE = CAPPLICATION_TYPE
	FROM RVM_APPLICATION (NOLOCK)
	WHERE CCOMPANY_ID = @CCOMPANY_ID
	AND CAPPS_CODE = @CAPPS_CODE

	IF @CAPPLICATION_TYPE = '002' BEGIN
		SELECT CFILE_PATH =  @CPATH + 
			CASE
				WHEN B.CPARAMETER_GROUP = 'BACK' THEN 
					'Back\' + RTRIM(@CVERSION) + '\' + RTRIM(@CATTRIBUTE_ID) + '\Dlls\'
				WHEN B.CPARAMETER_GROUP = 'SERVICE' THEN 
					'Back\' + RTRIM(@CVERSION) + '\' + RTRIM(@CATTRIBUTE_ID) + '\Svc\'
				WHEN B.CPARAMETER_GROUP = 'FRONT-PRG' THEN 
					'Front\UpdateFiles\Program\'
				WHEN B.CPARAMETER_GROUP = 'FRONT-RES' THEN 
					'Front\UpdateFiles\Resource\'
				ELSE ''
			END
		FROM CSM_SOURCES A
		JOIN RVM_APP_PARAM_002 B
		ON B.CCOMPANY_ID = A.CCOMPANY_ID
		AND B.CAPPS_CODE = A.CAPPS_CODE
		AND B.CATTRIBUTE_GROUP = A.CATTRIBUTE_GROUP
		AND B.CATTRIBUTE_ID = A.CATTRIBUTE_ID
		AND B.CSOURCE_GROUP_ID = A.CSOURCE_GROUP_ID
		WHERE A.CCOMPANY_ID = @CCOMPANY_ID
		AND A.CAPPS_CODE = @CAPPS_CODE
		AND A.CATTRIBUTE_GROUP = @CATTRIBUTE_GROUP
		AND A.CATTRIBUTE_ID = @CATTRIBUTE_ID
		AND A.CPROGRAM_ID = @CPROGRAM_ID
		AND A.CSOURCE_ID = @CSOURCE_ID
	END

END
GO
