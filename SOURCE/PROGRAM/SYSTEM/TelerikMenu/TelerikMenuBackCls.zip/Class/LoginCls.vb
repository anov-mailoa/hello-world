﻿Imports R_Common
Imports R_BackEnd
Imports System.Data.Common
Imports TelerikMenuBackResources

Public Class LoginCls
    Public Sub R_UserLocking(ByVal poParameter As LoginDTO)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception
        Dim loConn As DbConnection

        Try
            loConn = loDb.GetConnection()

            With poParameter
                'SAME USER CANNOT LOGIN TWICE
                Dim loTable As DataTable
                Dim lcLicenseMode As String
                Dim lnLicensee As Integer
                Dim lnCurrentUser As Integer
                Dim lnTimeout As Integer
                Dim llValid As Boolean

                If .CCOMPANY_ID = "" Then
                    lcQuery = "SELECT TOP 1 CCOMPANY_ID "
                    lcQuery += "FROM "
                    lcQuery += "SAM_COMPANIES (NOLOCK) "
                    .CCOMPANY_ID = loDb.SqlExecObjectQuery(Of String)(lcQuery, loConn, False).FirstOrDefault
                End If

                'GET INFO FROM GST_LICENSE
                lcQuery = "SELECT CLICENSE_MODE, NLICENSEE, NTIMEOUT "
                lcQuery += "FROM GST_LICENSE "
                lcQuery += "WHERE CCOMPANY_ID = '{0}'"
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID.Trim)
                loTable = loDb.SqlExecQuery(lcQuery, loConn, False)

                If loTable.Rows.Count <= 0 Then
                    Throw New Exception(GetError("err001"))
                End If

                lcLicenseMode = loTable.Rows(0)("CLICENSE_MODE").ToString.Trim
                lnLicensee = CInt(loTable.Rows(0)("NLICENSEE"))
                lnTimeout = CInt(loTable.Rows(0)("NTIMEOUT"))

                'GET RECORD FROM SAT_LOCKING
                lcQuery = "SELECT "
                lcQuery += "CCOMPUTER_ID "
                lcQuery += "FROM SAT_LOCKING "
                lcQuery += "WHERE "
                lcQuery += "CCOMPANY_ID = '{0}' AND "
                lcQuery += "CUSER_ID = '{1}' "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID.Trim, .CUSER_ID.Trim)

                loTable = loDb.SqlExecQuery(lcQuery, loConn, False)
                If loTable.Rows.Count > 0 Then
                    Dim lcError As String
                    lcError = String.Format(GetError("err002"), .CUSER_ID.Trim, lnTimeout.ToString.Trim)
                    Throw New Exception(lcError)
                Else
                    If lcLicenseMode.Equals("CONCURRENT USER", StringComparison.InvariantCultureIgnoreCase) Then
                        'GET USER ACTIVE IN SELECTED COMPANY
                        lcQuery = "SELECT "
                        lcQuery += "JUMLAH = (COUNT(CCOMPANY_ID)) "
                        lcQuery += "FROM SAT_LOCKING "
                        lcQuery += "WHERE CCOMPANY_ID = '{0}'"
                        lcQuery = String.Format(lcQuery, .CCOMPANY_ID.Trim)

                        loTable = loDb.SqlExecQuery(lcQuery, loConn, False)
                        lnCurrentUser = CInt(loTable.Rows(0)("JUMLAH"))

                        If lnCurrentUser >= lnLicensee Then
                            Throw New Exception(GetError("err003"))
                            Exit Try
                        End If
                    Else
                        'GET VALIDATION WITH STORED PROCEDURE
                        lcQuery = "EXEC RSP_LicenseValidation '{0}', {1} "
                        lcQuery = String.Format(lcQuery, lcLicenseMode, lnLicensee)

                        loTable = loDb.SqlExecQuery(lcQuery, loConn, False)
                        If loTable.Rows.Count > 0 Then
                            llValid = CBool(loTable.Rows(0)("LVALID"))

                            If Not llValid Then
                                Throw New Exception(GetError("err001"))
                                Exit Try
                            End If
                        End If
                    End If

                    'INSERT SAT_LOCKING
                    lcQuery = "INSERT INTO SAT_LOCKING "
                    lcQuery += "(CCOMPANY_ID, CUSER_ID, DLOGIN_DATE, DLAST_ACTIVITY_DATE, CCOMPUTER_ID) "
                    lcQuery += "VALUES "
                    lcQuery += "('{0}', '{1}', GETDATE(), GETDATE(), '{2}')"
                    lcQuery = String.Format(lcQuery, .CCOMPANY_ID.Trim, .CUSER_ID.Trim, R_Context._GetInternalContext(R_InternalContextVarEnumerator.COMPUTER_ID).Trim)
                    loDb.SqlExecNonQuery(lcQuery, loConn, False)
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Sub R_UserLockingCompany(ByVal pcCurrentCompanyId As String, ByVal pcNewCompanyId As String, ByVal pcUserId As String)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            'SAME USER CANNOT LOGIN TWICE
            Dim loTable As DataTable
            Dim lcLicenseMode As String
            Dim lnLicensee As Integer
            Dim lnCurrentUser As Integer
            Dim lnTimeout As Integer

            'GET INFO FROM GST_LICENSE
            lcQuery = "SELECT CLICENSE_MODE, NLICENSEE, NTIMEOUT "
            lcQuery += "FROM GST_LICENSE "
            lcQuery += "WHERE CCOMPANY_ID = '{0}'"
            lcQuery = String.Format(lcQuery, pcNewCompanyId.Trim)

            loTable = loDb.SqlExecQuery(lcQuery, loDb.GetConnection(), False)
            If loTable.Rows.Count <= 0 Then
                Throw New Exception(GetError("err001"))
            End If

            lcLicenseMode = loTable.Rows(0)("CLICENSE_MODE").ToString.Trim
            lnLicensee = CInt(loTable.Rows(0)("NLICENSEE"))
            lnTimeout = CInt(loTable.Rows(0)("NTIMEOUT"))

            'GET RECORD FROM SAT_LOCKING
            lcQuery = "SELECT "
            lcQuery += "CCOMPUTER_ID "
            lcQuery += "FROM SAT_LOCKING "
            lcQuery += "WHERE "
            lcQuery += "CCOMPANY_ID = '{0}' AND "
            lcQuery += "CUSER_ID = '{1}' "
            lcQuery = String.Format(lcQuery, pcNewCompanyId.Trim, pcUserId.Trim)

            loTable = loDb.SqlExecQuery(lcQuery, loDb.GetConnection(), False)
            If loTable.Rows.Count > 0 Then
                Dim lcError As String
                lcError = String.Format(GetError("err002"), pcUserId.Trim, lnTimeout.ToString.Trim)
                Throw New Exception(lcError)
            Else
                If lcLicenseMode.Equals("CONCURRENT USER", StringComparison.InvariantCultureIgnoreCase) Then
                    'GET USER ACTIVE IN SELECTED COMPANY
                    lcQuery = "SELECT "
                    lcQuery += "JUMLAH = (COUNT(CCOMPANY_ID)) "
                    lcQuery += "FROM SAT_LOCKING "
                    lcQuery += "WHERE CCOMPANY_ID = '{0}'"
                    lcQuery = String.Format(lcQuery, pcNewCompanyId.Trim)

                    loTable = loDb.SqlExecQuery(lcQuery, loDb.GetConnection(), False)
                    lnCurrentUser = CInt(loTable.Rows(0)("JUMLAH"))

                    If lnCurrentUser >= lnLicensee Then
                        GetError("err003")
                        Exit Try
                    End If
                End If

                'DELETE SAT_LOCKING CURRENT COMPANY
                R_UserLockingFlush(pcCurrentCompanyId, pcUserId)

                'INSERT SAT_LOCKING NEW COMPANY
                'lcQuery = "INSERT INTO SAT_LOCKING "
                'lcQuery += "(CCOMPANY_ID, CUSER_ID, DLOGIN_DATE, DLAST_ACTIVITY_DATE, CCOMPUTER_ID) "
                'lcQuery += "VALUES "
                'lcQuery += "('{0}', '{1}', GETDATE(), GETDATE(), '{2}')"
                'lcQuery = String.Format(lcQuery, pcNewCompanyId.Trim, pcUserId.Trim, R_Context._GetInternalContext(R_InternalContextVarEnumerator.COMPUTER_ID).Trim)
                'loDb.SqlExecNonQuery(lcQuery, loDb.GetConnection(), False)
            End If
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Sub R_UserLockingFlush(ByVal pcCurrentCompanyId As String, ByVal pcUserId As String)
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            'DELETE SAT_LOCKING CURRENT COMPANY
            lcQuery = "DELETE FROM SAT_LOCKING "
            lcQuery += "WHERE "
            lcQuery += "CCOMPANY_ID = '{0}' AND "
            lcQuery += "CUSER_ID = '{1}' "
            lcQuery = String.Format(lcQuery, pcCurrentCompanyId.Trim, pcUserId.Trim)
            loDb.SqlExecNonQuery(lcQuery, loDb.GetConnection(), False)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Function Logon(ByVal poParameter As LoginDTO) As LoginDTO
        Dim loException As New R_Exception
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loResult As LoginDTO
        Dim loRtn As New LoginDTO

        Try
            'get USER_ID and USER_NAME
            lcQuery = "SELECT CUSER_ID, CUSER_NAME, CUSER_PASSWORD, CCULTURE_ID "
            lcQuery += "FROM SAM_USER (NOLOCK) "
            lcQuery += "WHERE CUSER_ID = '{0}' "
            lcQuery = String.Format(lcQuery, poParameter.CUSER_ID)

            loResult = loDb.SqlExecObjectQuery(Of LoginDTO)(lcQuery).FirstOrDefault

            If loResult IsNot Nothing Then
                loRtn = New LoginDTO With {.CUSER_ID = loResult.CUSER_ID,
                                            .CUSER_NAME = loResult.CUSER_NAME,
                                           .CCULTURE_ID = loResult.CCULTURE_ID}

                lcQuery = "SELECT A.CCOMPANY_ID, A.CCOMPANY_NAME, A.CREPORT_CULTURE, A.CNUMBER_FORMAT, A.CDATE_LONG_FORMAT, A.CDATE_SHORT_FORMAT, "
                lcQuery += "A.CTIME_LONG_FORMAT, A.CTIME_SHORT_FORMAT, A.IDECIMAL_PLACES, A.IROUNDING_PLACES, A.CROUNDING_METHOD, A.LENABLE_SAVE_CONFIRMATION, "
                lcQuery += "B.CLICENSE_MODE, B.NLICENSEE FROM SAM_COMPANIES A (NOLOCK) "
                lcQuery += "INNER JOIN GST_LICENSE B (NOLOCK) "
                lcQuery += "ON B.CCOMPANY_ID = A.CCOMPANY_ID "
                lcQuery += "WHERE A.CCOMPANY_ID = '{0}'"
                lcQuery = String.Format(lcQuery, poParameter.CCOMPANY_ID)

                loResult = loDb.SqlExecObjectQuery(Of LoginDTO)(lcQuery).FirstOrDefault

                With loRtn
                    .CCOMPANY_ID = loResult.CCOMPANY_ID
                    .CCOMPANY_NAME = loResult.CCOMPANY_NAME
                    .CREPORT_CULTURE = loResult.CREPORT_CULTURE
                    .CNUMBER_FORMAT = loResult.CNUMBER_FORMAT
                    .CDATE_LONG_FORMAT = loResult.CDATE_LONG_FORMAT
                    .CDATE_SHORT_FORMAT = loResult.CDATE_SHORT_FORMAT
                    .CTIME_LONG_FORMAT = loResult.CTIME_LONG_FORMAT
                    .CTIME_SHORT_FORMAT = loResult.CTIME_SHORT_FORMAT
                    .IDECIMAL_PLACES = loResult.IDECIMAL_PLACES
                    .IROUNDING_PLACES = loResult.IROUNDING_PLACES
                    .CROUNDING_METHOD = loResult.CROUNDING_METHOD
                    .LENABLE_SAVE_CONFIRMATION = loResult.LENABLE_SAVE_CONFIRMATION
                    .CLICENSE_MODE = loResult.CLICENSE_MODE
                    .NLICENSEE = loResult.NLICENSEE
                End With

                Me.R_UserLocking(poParameter)

                Me.doFlushData(loRtn.CUSER_ID, loRtn.CCOMPANY_ID)
            End If

        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ThrowExceptionIfErrors()

        Return loRtn
    End Function

    Public Function getUserCompanyBroadcast(ByVal poParameter As SAM_USER_COMPANYDTO) As SAM_USER_COMPANYDTO
        Dim loException As New R_Exception
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loResult As SAM_USER_COMPANYDTO

        Try
            lcQuery = "SELECT CUSER_ID, CCOMPANY_ID, LENABLE_BROADCAST AS LCAN_BROADCAST "
            lcQuery += "FROM "
            lcQuery += "SAM_USER_COMPANY "
            lcQuery += "WHERE "
            lcQuery += "CUSER_ID = '{0}' AND CCOMPANY_ID = '{1}' "
            lcQuery = String.Format(lcQuery, poParameter.CUSER_ID, poParameter.CCOMPANY_ID)

            loResult = loDb.SqlExecObjectQuery(Of SAM_USER_COMPANYDTO)(lcQuery).FirstOrDefault
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function getCompanyAndUserName(ByVal poParameter As LoginDTO) As LoginDTO
        Dim loException As New R_Exception
        Dim lcQuery As String
        Dim loDb As New R_Db
        Dim loResult As LoginDTO
        Dim loRtn As New LoginDTO
        Dim loConn As DbConnection

        Try
            loConn = loDb.GetConnection()

            lcQuery = "SELECT CUSER_ID, CUSER_NAME "
            lcQuery += "FROM SAM_USER "
            lcQuery += "WHERE CUSER_ID = '{0}' "
            lcQuery = String.Format(lcQuery, poParameter.CUSER_ID.ToString.Trim)

            loResult = loDb.SqlExecObjectQuery(Of LoginDTO)(lcQuery, loConn, False).FirstOrDefault

            loRtn = New LoginDTO With {.CUSER_ID = loResult.CUSER_ID,
                                       .CUSER_NAME = loResult.CUSER_NAME}

            lcQuery = "SELECT CCOMPANY_ID, CCOMPANY_NAME "
            lcQuery += "FROM SAM_COMPANIES "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery = String.Format(lcQuery, poParameter.CCOMPANY_ID)

            loResult = loDb.SqlExecObjectQuery(Of LoginDTO)(lcQuery, loConn, False).FirstOrDefault

            With loRtn
                .CCOMPANY_ID = loResult.CCOMPANY_ID
                .CCOMPANY_NAME = loResult.CCOMPANY_NAME
            End With

            If loRtn Is Nothing Then
                Throw New Exception(GetError("err004"))
            End If
        Catch ex As Exception
            loException.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loException.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Sub doFlushData(ByVal pcUserId As String, ByVal pcCompanyId As String)
        Dim loException As New R_Exception
        Dim lcQuery As String
        Dim loDb As New R_Db()

        Try
            lcQuery = "DELETE GST_SPLIT_UPLOAD  "
            lcQuery += "WHERE CUSER_ID = '{0}' "
            lcQuery += "AND CCOMPANY_ID = '{1}' "
            lcQuery = String.Format(lcQuery, pcUserId, pcCompanyId)
            loDb.SqlExecNonQuery(lcQuery)

            lcQuery = "DELETE GST_UPLOAD_ERROR_STATUS   "
            lcQuery += "WHERE CUSER_ID = '{0}' "
            lcQuery += "AND CCOMPANY_ID = '{1}' "
            lcQuery = String.Format(lcQuery, pcUserId, pcCompanyId)
            loDb.SqlExecNonQuery(lcQuery)

            lcQuery = "DELETE GST_UPLOAD_PROCESS_STATUS   "
            lcQuery += "WHERE CUSER_ID = '{0}' "
            lcQuery += "AND CCOMPANY_ID = '{1}' "
            lcQuery = String.Format(lcQuery, pcUserId, pcCompanyId)
            loDb.SqlExecNonQuery(lcQuery)

            lcQuery = "DELETE GST_XML_RESULT    "
            lcQuery += "WHERE CUSER_ID = '{0}' "
            lcQuery += "AND CCOMPANY_ID = '{1}' "
            lcQuery = String.Format(lcQuery, pcUserId, pcCompanyId)
            loDb.SqlExecNonQuery(lcQuery)

            lcQuery = "DELETE SAM_USER_LOCKING   "
            lcQuery += "WHERE CUSER_ID = '{0}' "
            lcQuery += "AND CCOMPANY_ID = '{1}' "
            lcQuery = String.Format(lcQuery, pcUserId, pcCompanyId)
            loDb.SqlExecNonQuery(lcQuery)
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ThrowExceptionIfErrors()
    End Sub

    Public Function getLastUpdate(ByVal poParameter As LoginDTO) As Nullable(Of Date)
        Dim loException As New R_Exception
        Dim lcQuery As String
        Dim loDb As New R_Db()
        Dim loResult As Nullable(Of Date)
        Dim loRtn As New LoginDTO

        Try
            lcQuery = "SELECT DLAST_UPDATE_PSWD "
            lcQuery += "FROM "
            lcQuery += "SAM_USER "
            lcQuery += "WHERE "
            lcQuery += "CUSER_ID = '{0}' "
            lcQuery = String.Format(lcQuery, poParameter.CUSER_ID)

            loRtn = loDb.SqlExecObjectQuery(Of LoginDTO)(lcQuery).FirstOrDefault

            If loRtn.DLAST_UPDATE_PSWD IsNot Nothing Then
                loResult = loRtn.DLAST_UPDATE_PSWD
            Else
                loResult = Nothing
            End If
        Catch ex As Exception
            loException.Add(ex)
        End Try

        loException.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Private Function GetError(pcErrorId As String) As String
        Try
            Return R_Utility.R_GetError(GetType(Resources_Dummy_Class), pcErrorId, New Globalization.CultureInfo(R_BackGlobalVar.CULTURE_MENU), "TelerikMenuBackResources_msgrsc").ErrDescp
        Catch ex As Exception
            Throw ex
        End Try
    End Function
End Class
