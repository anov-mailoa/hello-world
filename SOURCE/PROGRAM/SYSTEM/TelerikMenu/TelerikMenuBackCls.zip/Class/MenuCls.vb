﻿Imports System.Data.Linq
Imports System.Configuration
Imports R_Common
Imports R_BackEnd
Imports System.Data.Common

Public Class MenuCls
    '' !!!!!!!!!!!!!!!!!! JANGAN LUPA MENU_ID DI SEMUA QUERY !!!!!!!!!!!!!!!!!!!!

    'buat dapetin access menu
    Public Function getMenuAccess(ByVal pcCompanyId As String, ByVal pcUserId As String, ByVal pcLang As String) As List(Of MenuProgramAccessDTO)
        Dim lcCmd As String
        Dim loList As New List(Of MenuProgramAccessDTO)()
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db

        Try
            lcCmd = "SELECT A.CCOMPANY_ID, A.CMENU_ID, B.CPROGRAM_ID, C.CPROGRAM_ACCESS AS CACCESS_ID, D.CMENU_NAME, "
            lcCmd += "CPROGRAM_NAME = CASE WHEN CLANG_ID <> 'EN' THEN ISNULL(F.CPROGRAM_NAME, E.CPROGRAM_NAME) ELSE E.CPROGRAM_NAME END, "
            lcCmd += "CTOOL_TIP = CASE WHEN CLANG_ID <> 'EN' THEN ISNULL(F.CTOOL_TIP, E.CTOOL_TIP) ELSE E.CTOOL_TIP END "
            lcCmd += "FROM SAM_USER_PROGRAM A (NOLOCK) "
            lcCmd += "INNER JOIN SAM_PROGRAM_ACCESS B (NOLOCK) "
            lcCmd += "ON B.CPROGRAM_ID = A.CSUB_MENU_ID "
            lcCmd += "INNER JOIN SAM_MENU_PROGRAM C (NOLOCK) "
            lcCmd += "ON C.CCOMPANY_ID = A.CCOMPANY_ID "
            lcCmd += "AND C.CMENU_ID = A.CMENU_ID "
            lcCmd += "AND C.CPROGRAM_ID = A.CSUB_MENU_ID "
            lcCmd += "INNER JOIN SAM_MENU D (NOLOCK) "
            lcCmd += "ON D.CCOMPANY_ID = A.CCOMPANY_ID "
            lcCmd += "AND D.CMENU_ID = A.CMENU_ID "
            lcCmd += "INNER JOIN SAM_PROGRAM E (NOLOCK) ON A.CSUB_MENU_ID = E.CPROGRAM_ID "
            lcCmd += "LEFT JOIN SAM_PROGRAM_LANG F (NOLOCK) ON E.CPROGRAM_ID = F.CPROGRAM_ID AND CLANG_ID = '{2}' "
            lcCmd += "WHERE A.CCOMPANY_ID = '{0}' AND A.CUSER_ID = '{1}' "
            lcCmd = String.Format(lcCmd, pcCompanyId, pcUserId, pcLang)

            loList = loDb.SqlExecObjectQuery(Of MenuProgramAccessDTO)(lcCmd)
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loEx.ThrowExceptionIfErrors()

        Return loList
    End Function

    'buat dapetin menu
    Public Function getMenu(ByVal pcCompanyId As String, ByVal pcUserId As String, ByVal pcMENU_ID As String, ByVal pcSUB_MENU_ID As String, ByVal pnLEVEL As Integer, ByVal pcModul As String, ByVal pcLang As String) As List(Of MenuDTOnon)
        Dim lcCmd As String
        Dim loList As New List(Of MenuDTOnon)()
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db

        Try
            If pnLEVEL = 1 Then
                lcCmd = "SELECT A.CCOMPANY_ID, A.CUSER_ID, A.CMENU_ID, A.CSUB_MENU_TYPE, A.CSUB_MENU_ID, "
                lcCmd += "CSUB_MENU_NAME = CASE A.CSUB_MENU_TYPE WHEN 'P' THEN ISNULL(D.CPROGRAM_NAME, B.CPROGRAM_NAME) ELSE A.CSUB_MENU_NAME END, "
                lcCmd += "CSUB_MENU_TOOL_TIP = CASE A.CSUB_MENU_TYPE WHEN 'P' THEN ISNULL(D.CTOOL_TIP, B.CTOOL_TIP) ELSE A.CSUB_MENU_NAME END, "
                lcCmd += "CSUB_MENU_IMAGE = CASE A.CSUB_MENU_TYPE WHEN 'P' THEN B.CPROGRAM_BUTTON ELSE '' END, "
                lcCmd += "A.CPARENT_SUB_MENU_ID, A.IGROUP_INDEX, A.IROW_INDEX, A.ICOLUMN_INDEX, A.LFAVORITE, A.IFAVORITE_INDEX, A.ILEVEL, "
                lcCmd += "Modul = B.CMODULE_ID, C.CMENU_NAME INTO #TempMenu FROM SAM_USER_PROGRAM A (NOLOCK) "
                lcCmd += "LEFT OUTER JOIN SAM_PROGRAM B (NOLOCK) ON B.CPROGRAM_ID = A.CSUB_MENU_ID "
                lcCmd += "LEFT OUTER JOIN SAM_PROGRAM_LANG D (NOLOCK) ON D.CPROGRAM_ID = B.CPROGRAM_ID AND D.CLANG_ID = '" + pcLang.Trim + "' "
                lcCmd += "INNER JOIN SAM_MENU C (NOLOCK) ON C.CMENU_ID = A.CMENU_ID AND C.CCOMPANY_ID = A.CCOMPANY_ID "
                lcCmd += "WHERE A.CCOMPANY_ID = '" + pcCompanyId.Trim + "' AND A.CUSER_ID = '" + pcUserId.Trim + "' AND "

                If Not pcMENU_ID = "" Then
                    lcCmd += "A.CMENU_ID = '" + pcMENU_ID.Trim + "' "
                    lcCmd += "AND "
                End If
                lcCmd += "A.ILEVEL = " + pnLEVEL.ToString.Trim

            Else '' pnLEVEL <> 1
                lcCmd = "SELECT A.CCOMPANY_ID, A.CUSER_ID, A.CMENU_ID, A.CSUB_MENU_TYPE, A.CSUB_MENU_ID, A.CSUB_MENU_NAME, CSUB_MENU_TOOL_TIP = A.CSUB_MENU_NAME, "
                lcCmd += "CSUB_MENU_IMAGE = '', A.CPARENT_SUB_MENU_ID, A.IGROUP_INDEX, A.IROW_INDEX, A.ICOLUMN_INDEX, A.LFAVORITE, A.IFAVORITE_INDEX, "
                lcCmd += "A.ILEVEL, Modul = B.CMODULE_ID INTO #TempMenu FROM SAM_USER_PROGRAM A (NOLOCK) "
                lcCmd += "WHERE A.CCOMPANY_ID = '{0}' AND A.CUSER_ID = '{1}' AND A.CMENU_ID = '{2}' AND A.CSUB_MENU_TYPE = 'G' AND A.CPARENT_SUB_MENU_ID = '{3}' "
                lcCmd += "AND A.ILEVEL = {4} "
                lcCmd = String.Format(lcCmd, pcCompanyId.Trim, pcUserId.Trim, pcMENU_ID.Trim, pcSUB_MENU_ID.Trim, pnLEVEL)

                lcCmd += "INSERT INTO #TempMenu "
                lcCmd += "SELECT A.CCOMPANY_ID, A.CUSER_ID, A.CMENU_ID, A.CSUB_MENU_TYPE, A.CSUB_MENU_ID, CSUB_MENU_NAME = B.CPROGRAM_NAME, "
                lcCmd += "CSUB_MENU_TOOL_TIP = B.CTOOL_TIP, CSUB_MENU_IMAGE = B.CPROGRAM_BUTTON, A.CPARENT_SUB_MENU_ID, A.IGROUP_INDEX, A.IROW_INDEX, "
                lcCmd += "A.ICOLUMN_INDEX, A.LFAVORITE, A.IFAVORITE_INDEX, A.ILEVEL, Modul = B.CMODULE_ID "
                lcCmd += "FROM SAM_USER_PROGRAM A (NOLOCK) "
                lcCmd += "LEFT OUTER JOIN SAM_PROGRAM B (NOLOCK) "
                lcCmd += "ON B.CPROGRAM_ID = A.CSUB_MENU_ID "
                lcCmd += "WHERE A.CCOMPANY_ID = '{0}' AND A.CUSER_ID = '{1}' AND A.CMENU_ID = '{2}' AND A.CSUB_MENU_TYPE = 'P' "
                lcCmd += "AND A.CPARENT_SUB_MENU_ID IN "
                lcCmd += "(SELECT C.CSUB_MENU_ID FROM SAM_USER_PROGRAM C (NOLOCK) "
                lcCmd += "WHERE C.CCOMPANY_ID = A.CCOMPANY_ID AND C.CUSER_ID = A.CUSER_ID AND C.CMENU_ID = A.CMENU_ID AND C.CSUB_MENU_TYPE = 'G' "
                lcCmd += "AND C.CPARENT_SUB_MENU_ID = '{3}' AND C.ILEVEL = A.ILEVEL) "
                lcCmd += "AND A.ILEVEL = {4} "
                lcCmd = String.Format(lcCmd, pcCompanyId.Trim, pcUserId.Trim, pcMENU_ID.Trim, pcSUB_MENU_ID.Trim, pnLEVEL.ToString.Trim)
            End If

            lcCmd += "SELECT * FROM #TempMenu "

            If Not pcModul = "" Then
                lcCmd += "WHERE Modul IN(" + pcModul.Trim + ") OR Modul IS NULL "
            End If

            loList = loDb.SqlExecObjectQuery(Of MenuDTOnon)(lcCmd)
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loEx.ThrowExceptionIfErrors()

        Return loList
    End Function

#Region "OLD"
    Public Function getLastId(ByVal pcCompanyId As String, ByVal pcUserId As String, ByVal pcMENU_ID As String, ByVal pcSUB_MENU_TYPE As String) As MenuDTO
        Dim lcCmd As String
        Dim loList As New MenuDTO
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db

        Try
            lcCmd = "SELECT TOP 1 CSUB_MENU_ID "
            lcCmd += "FROM SAM_USER_PROGRAM (NOLOCK) "
            lcCmd += "WHERE CCOMPANY_ID = '{0}' "
            lcCmd += "AND CUSER_ID = '{1}' "
            lcCmd += "AND CMENU_ID = '{2}' "
            lcCmd += "AND CSUB_MENU_TYPE = '{3}' "
            lcCmd += "AND CSUB_MENU_ID NOT IN ('BATCH','MASTER','REPORT','TRANS','INQUI') "
            lcCmd += "ORDER BY CSUB_MENU_ID DESC"
            lcCmd = String.Format(lcCmd, pcCompanyId.Trim, pcUserId.Trim, pcMENU_ID.Trim, pcSUB_MENU_TYPE.Trim)

            loList = loDb.SqlExecObjectQuery(Of MenuDTO)(lcCmd).FirstOrDefault
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loList
    End Function
#End Region

#Region "ADD, EDIT, DELETE GROUP"
    Public Sub insertMenuToDB(ByVal poMenuDTO As MenuDTO)
        Dim lcCmd As String
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db

        Try
            With poMenuDTO
                lcCmd = "INSERT INTO SAM_USER_PROGRAM "
                lcCmd += "(CCOMPANY_ID, CUSER_ID, CMENU_ID, CSUB_MENU_TYPE, CSUB_MENU_ID, CSUB_MENU_NAME, LFAVORITE, IGROUP_INDEX, IROW_INDEX, "
                lcCmd += "ICOLUMN_INDEX, IFAVORITE_INDEX, CPARENT_SUB_MENU_ID, ILEVEL) "
                lcCmd += "VALUES('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}')"
                lcCmd = String.Format(lcCmd, .CCOMPANY_ID.Trim, .CUSER_ID.Trim, .CMENU_ID.Trim, .CSUB_MENU_TYPE.Trim, .CSUB_MENU_ID.Trim, _
                                      .CSUB_MENU_NAME.Trim, "", .IGROUP_INDEX.ToString, .IROW_INDEX.ToString, .ICOLUMN_INDEX.ToString, _
                                      .IFAVORITE_INDEX.ToString, .CPARENT_SUB_MENU_ID.Trim, .ILEVEL.ToString)
            End With
            loDb.SqlExecNonQuery(lcCmd)
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Sub deleteMenuFromDB(ByVal poMenuDTO As MenuDTO)
        Dim lcCmd As String
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db
        Dim loConn As DbConnection

        Try
            loConn = loDb.GetConnection()

            '' Update all index group greater than deleted Group
            If poMenuDTO.CSUB_MENU_TYPE = "G" Then
                With poMenuDTO
                    lcCmd = "UPDATE SAM_USER_PROGRAM "
                    lcCmd += "SET IGROUP_INDEX = IGROUP_INDEX - 1 "
                    lcCmd += "WHERE CCOMPANY_ID = '{0}' "
                    lcCmd += "AND CUSER_ID = '{1}' "
                    lcCmd += "AND CMENU_ID = '{2}' "
                    lcCmd += "AND CPARENT_SUB_MENU_ID = ( "
                    lcCmd += "SELECT CPARENT_SUB_MENU_ID "
                    lcCmd += "FROM SAM_USER_PROGRAM (NOLOCK) "
                    lcCmd += "WHERE CCOMPANY_ID = '{0}' "
                    lcCmd += "AND CUSER_ID = '{1}' "
                    lcCmd += "AND CMENU_ID = '{2}' "
                    lcCmd += "AND CSUB_MENU_TYPE = '{3}' "
                    lcCmd += "AND CSUB_MENU_ID = '{4}') "
                    lcCmd += "AND IGROUP_INDEX > ( "
                    lcCmd += "SELECT IGROUP_INDEX FROM SAM_USER_PROGRAM (NOLOCK) "
                    lcCmd += "WHERE CCOMPANY_ID = '{0}' "
                    lcCmd += "AND CUSER_ID = '{1}' "
                    lcCmd += "AND CMENU_ID = '{2}' "
                    lcCmd += "AND CSUB_MENU_TYPE = '{3}' "
                    lcCmd += "AND CSUB_MENU_ID = '{4}') "
                    lcCmd = String.Format(lcCmd, .CCOMPANY_ID.Trim, .CUSER_ID.Trim, .CMENU_ID.Trim, .CSUB_MENU_TYPE.Trim, .CSUB_MENU_ID.Trim)
                End With

                loDb.SqlExecNonQuery(lcCmd, loConn, False)
            End If

            '' Delete All Group in Folder
            If poMenuDTO.CSUB_MENU_TYPE = "F" Then
                lcCmd = "DELETE FROM SAM_USER_PROGRAM "
                lcCmd = lcCmd + "WHERE CCOMPANY_ID          = '" + poMenuDTO.CCOMPANY_ID.Trim + "' "
                lcCmd = lcCmd + "   AND CUSER_ID            = '" + poMenuDTO.CUSER_ID.Trim + "' "
                lcCmd = lcCmd + "   AND CMENU_ID            = '" + poMenuDTO.CMENU_ID.Trim + "' "
                lcCmd = lcCmd + "   AND CPARENT_SUB_MENU_ID = '" + poMenuDTO.CSUB_MENU_ID.Trim + "' "
            End If

            With poMenuDTO
                lcCmd = "DELETE FROM SAM_USER_PROGRAM "
                lcCmd += "WHERE CCOMPANY_ID = '{0}' "
                lcCmd += "AND CUSER_ID = '{1}' "
                lcCmd += "AND CMENU_ID = '{2}' "
                lcCmd += "AND CSUB_MENU_TYPE = '{3}'"
                lcCmd += "AND CSUB_MENU_ID = '{4}' "
                lcCmd = String.Format(lcCmd, .CCOMPANY_ID.Trim, .CUSER_ID.Trim, .CMENU_ID.Trim, .CSUB_MENU_TYPE.Trim, .CSUB_MENU_ID.Trim)
            End With

            loDb.SqlExecNonQuery(lcCmd, loConn, False)
        Catch ex As Exception
            loEx.add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Sub updateMenuNameToDB(ByVal poMenuDTO As MenuDTO)
        Dim lcCmd As String
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db

        Try
            With poMenuDTO
                lcCmd = "UPDATE SAM_USER_PROGRAM "
                lcCmd += "SET CSUB_MENU_NAME = '{0}' "
                lcCmd += "WHERE CCOMPANY_ID = '{1}' "
                lcCmd += "AND CUSER_ID = '{2}' "
                lcCmd += "AND CMENU_ID = '{3}' "
                lcCmd += "AND CSUB_MENU_TYPE = '{4}' "
                lcCmd += "AND CSUB_MENU_ID = '{5}' "
                lcCmd = String.Format(lcCmd, .CSUB_MENU_NAME.Trim, .CCOMPANY_ID.Trim, .CUSER_ID.Trim, .CMENU_ID.Trim, .CSUB_MENU_TYPE.Trim, .CSUB_MENU_ID.Trim)
            End With

            loDb.SqlExecNonQuery(lcCmd)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
#End Region

    'update db when group index changed
    Public Sub updateGroupIndexToDB(ByVal poMenuDTO As MenuDTO, ByVal pcOperation As String)
        Dim lcCmd As String
        Dim lcParentMenuId As String
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db
        Dim loConn As DbConnection

        Try
            loConn = loDb.GetConnection()

            If poMenuDTO.ILEVEL = 1 Then
                lcParentMenuId = poMenuDTO.CMENU_ID.Trim
            End If

            With poMenuDTO
                lcCmd = "UPDATE SAM_USER_PROGRAM "
                lcCmd += "SET IGROUP_INDEX = {0} "
                lcCmd += "WHERE CCOMPANY_ID = '{1}' "
                lcCmd += "AND CUSER_ID = '{2}'   "
                lcCmd += "AND CMENU_ID = '{3}' "
                lcCmd += "AND CSUB_MENU_TYPE = '{4}' "
                lcCmd += "AND IGROUP_INDEX = " + IIf(pcOperation = "UP", (poMenuDTO.IGROUP_INDEX - 1).ToString.Trim, (poMenuDTO.IGROUP_INDEX + 1).ToString.Trim) + " "
                lcCmd += "AND CPARENT_SUB_MENU_ID = '{5}' "
                lcCmd = String.Format(lcCmd, .IGROUP_INDEX.ToString.Trim, .CCOMPANY_ID.Trim, .CUSER_ID.Trim, .CMENU_ID.Trim, "G", lcParentMenuId.Trim)
            End With
             
            loDb.SqlExecNonQuery(lcCmd, loConn, False)

            With poMenuDTO
                lcCmd = "UPDATE SAM_USER_PROGRAM "
                lcCmd += "SET IGROUP_INDEX = " + IIf(pcOperation = "UP", (poMenuDTO.IGROUP_INDEX - 1).ToString.Trim, (poMenuDTO.IGROUP_INDEX + 1).ToString.Trim) + " "
                lcCmd += "WHERE CCOMPANY_ID = '{0}' "
                lcCmd += "AND CUSER_ID = '{1}' "
                lcCmd += "AND CMENU_ID = '{2}' "
                lcCmd += "AND CSUB_MENU_TYPE = '{3}' "
                lcCmd += "AND CSUB_MENU_ID = '{4}' "
                lcCmd = String.Format(lcCmd, .CCOMPANY_ID.Trim, .CUSER_ID.Trim, .CMENU_ID.Trim, "G", .CSUB_MENU_ID.Trim)
            End With
             
            loDb.SqlExecNonQuery(lcCmd, loConn, False)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Sub updateMenuPositionToDB(ByVal poMenuDTO As MenuDTO)
        Dim lcCmd As String
        Dim loDTOList As List(Of MenuDTO)
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db
        Dim loConn As DbConnection

        Try
            loConn = loDb.GetConnection()

            With poMenuDTO
                lcCmd = "SELECT * FROM SAM_USER_PROGRAM (NOLOCK) "
                lcCmd += "WHERE CCOMPANY_ID = '{0}' "
                lcCmd += "AND CUSER_ID = '{1}' "
                lcCmd += "AND CMENU_ID = '{2}' "
                lcCmd += "AND CPARENT_SUB_MENU_ID = '{3}' "
                lcCmd += "AND IROW_INDEX = {4} "
                lcCmd += "AND ICOLUMN_INDEX >= {5} "
                lcCmd += "AND CSUB_MENU_ID <> '{6}' "
                lcCmd += "ORDER BY ICOLUMN_INDEX ASC "
                lcCmd = String.Format(lcCmd, .CCOMPANY_ID, .CUSER_ID, .CMENU_ID, .CPARENT_SUB_MENU_ID, .IROW_INDEX, .ICOLUMN_INDEX, .CSUB_MENU_ID)
                loDTOList = loDb.SqlExecObjectQuery(Of MenuDTO)(lcCmd, loConn, False)

                Dim loTempColumn As Integer
                loTempColumn = poMenuDTO.ICOLUMN_INDEX

                For Each loDTO As MenuDTO In loDTOList
                    If loDTO.ICOLUMN_INDEX = loTempColumn Then
                        loTempColumn = loTempColumn + 1

                        lcCmd = "UPDATE SAM_USER_PROGRAM SET "
                        lcCmd += "ICOLUMN_INDEX = {0} "
                        lcCmd += "WHERE CCOMPANY_ID = '{1}' "
                        lcCmd += "AND CUSER_ID = '{2}' "
                        lcCmd += "AND CMENU_ID = '{3}' "
                        lcCmd += "AND CSUB_MENU_TYPE = '{4}' "
                        lcCmd += "AND CSUB_MENU_ID = '{5}' "
                        lcCmd = String.Format(lcCmd, loTempColumn, loDTO.CCOMPANY_ID, loDTO.CUSER_ID, .CMENU_ID, loDTO.CSUB_MENU_TYPE, loDTO.CSUB_MENU_ID)
                        loDb.SqlExecNonQuery(lcCmd, loConn, False)
                    Else
                        Exit For
                    End If
                Next

                lcCmd = "UPDATE SAM_USER_PROGRAM SET "
                lcCmd += "CPARENT_SUB_MENU_ID = '{0}', "
                lcCmd += "IROW_INDEX = {1}, "
                lcCmd += "ICOLUMN_INDEX = {2} "
                lcCmd += "WHERE CCOMPANY_ID = '{3}' "
                lcCmd += "AND CUSER_ID = '{4}' "
                lcCmd += "AND CMENU_ID = '{5}' "
                lcCmd += "AND CSUB_MENU_TYPE = '{6}' "
                lcCmd += "AND CSUB_MENU_ID = '{7}' "
                lcCmd = String.Format(lcCmd, .CPARENT_SUB_MENU_ID, .IROW_INDEX, .ICOLUMN_INDEX, .CCOMPANY_ID, .CUSER_ID, .CMENU_ID, .CSUB_MENU_TYPE, .CSUB_MENU_ID)

                loDb.SqlExecNonQuery(lcCmd, loConn, False)
            End With

        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

#Region "CHECK, SAVE, DELETE FROM FAVOURITE"
    Public Function checkMenuFavourite(poMenuDTO As MenuDTO) As Boolean
        Dim lcCmd As String
        Dim loData As New SAM_USER_PROGRAMDTO
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception()

        Try
            'get data SAM_USER_PROGRAM 
            lcCmd = "SELECT * "
            lcCmd += "FROM SAM_USER_PROGRAM "
            lcCmd += "WHERE CCOMPANY_ID = '{0}' AND CUSER_ID = '{1}' AND CMENU_ID = '{2}' AND CSUB_MENU_ID = '{3}'"
            lcCmd = String.Format(lcCmd, poMenuDTO.CCOMPANY_ID, poMenuDTO.CUSER_ID, "FAV", poMenuDTO.CSUB_MENU_ID)
            loData = loDb.SqlExecObjectQuery(Of SAM_USER_PROGRAMDTO)(lcCmd).FirstOrDefault

            If loData IsNot Nothing Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
    End Function

    Public Sub saveMenuFavourite(poMenuDTO As MenuDTO)
        Dim lcCmd As String
        Dim loData As New SAM_USER_PROGRAMDTO
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db()
        Dim loConn As DbConnection
        Dim lcQuery As String

        Try
            loConn = loDb.GetConnection()

            'get data SAM_USER_PROGRAM 
            lcCmd = "SELECT * "
            lcCmd += "FROM SAM_USER_PROGRAM "
            lcCmd += "WHERE CCOMPANY_ID = '{0}' AND CUSER_ID = '{1}' AND CMENU_ID = '{2}' AND CSUB_MENU_ID = '{3}'"
            lcCmd = String.Format(lcCmd, poMenuDTO.CCOMPANY_ID, poMenuDTO.CUSER_ID, poMenuDTO.CMENU_ID, poMenuDTO.CSUB_MENU_ID)
            loData = loDb.SqlExecObjectQuery(Of SAM_USER_PROGRAMDTO)(lcCmd, loConn, False).FirstOrDefault

            Dim iCol As Integer = 0
            Dim iRow As Integer = 0
            With poMenuDTO
                lcQuery = "SELECT A.CMENU_ID, MAX(A.ICOLUMN_INDEX) AS IMAXCOL "
                lcQuery += "FROM SAM_USER_PROGRAM A (NOLOCK) "
                lcQuery += "WHERE A.CCOMPANY_ID = '{0}' AND A.CMENU_ID = '{1}' AND A.CSUB_MENU_TYPE = '{2}' AND A.CUSER_ID = '{3}' AND A.IGROUP_INDEX = '{4}' "
                lcQuery += "GROUP BY CMENU_ID "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, "FAV", "P", .CUSER_ID, "0")
                Dim loMaxIndex = loDb.SqlExecObjectQuery(Of MenuProgramDTO)(lcQuery, loConn, False).FirstOrDefault

                If loMaxIndex Is Nothing Then
                    iCol = 0
                Else
                    iCol = loMaxIndex.IMAXCOL
                End If

                lcQuery = "SELECT A.CMENU_ID, MAX(A.IROW_INDEX) AS IMAXROW "
                lcQuery += "FROM SAM_USER_PROGRAM A (NOLOCK) "
                lcQuery += "WHERE A.CCOMPANY_ID = '{0}' AND A.CMENU_ID = '{1}' AND A.CSUB_MENU_TYPE = '{2}' AND A.CUSER_ID = '{3}' AND A.IGROUP_INDEX = '{4}' AND A.ICOLUMN_INDEX = '{5}' "
                lcQuery += "GROUP BY CMENU_ID "
                lcQuery = String.Format(lcQuery, .CCOMPANY_ID, "FAV", "P", .CUSER_ID, 0, iCol)
                Dim loMaxRow = loDb.SqlExecObjectQuery(Of MenuProgramDTO)(lcQuery, loConn, False).FirstOrDefault
                If loMaxRow Is Nothing Then
                    iRow = 0
                Else
                    iRow = loMaxRow.IMAXROW

                    If iRow = 3 Then
                        iCol += 1
                        iRow = 0
                    Else
                        iRow += 1
                    End If
                End If

                lcCmd = "INSERT INTO SAM_USER_PROGRAM ( "
                lcCmd += "CCOMPANY_ID, CUSER_ID, CMENU_ID, CSUB_MENU_TYPE, CSUB_MENU_ID, CSUB_MENU_NAME, LFAVORITE, IGROUP_INDEX, IROW_INDEX, ICOLUMN_INDEX, "
                lcCmd += "IFAVORITE_INDEX, CPARENT_SUB_MENU_ID, ILEVEL) "
                lcCmd += "VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', {7}, {8}, {9}, {10}, '{11}', {12})"
                lcCmd = String.Format(lcCmd, .CCOMPANY_ID, .CUSER_ID, "FAV", loData.CSUB_MENU_TYPE, .CSUB_MENU_ID, loData.CSUB_MENU_NAME.Trim, _
                                      .LFAVORITE.ToString, 0, iRow, iCol, loData.IFAVORITE_INDEX, "G001", loData.ILEVEL)

                loDb.SqlExecNonQuery(lcCmd, loConn, False)
            End With
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub

    Public Sub deleteMenuFavourite(poMenuDTO As MenuDTO)
        Dim lcCmd As String
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db
        Dim loRtn As New List(Of SAM_USER_PROGRAMDTO)
        Dim loRtnFav As New SAM_USER_PROGRAMDTO
        Dim loConn As DbConnection

        Try
            loConn = loDb.GetConnection()

            With poMenuDTO
                lcCmd = "DELETE FROM SAM_USER_PROGRAM "
                lcCmd += "WHERE CCOMPANY_ID = '{0}' "
                lcCmd += "AND CUSER_ID = '{1}' "
                lcCmd += "AND CMENU_ID = '{2}' "
                lcCmd += "AND CSUB_MENU_ID = '{3}' "
                lcCmd = String.Format(lcCmd, .CCOMPANY_ID, .CUSER_ID, .CMENU_ID, .CSUB_MENU_ID)
                loDb.SqlExecNonQuery(lcCmd, loConn, False)

                'check if program on favourite menu is nothing, rename group to default
                lcCmd = "SELECT * FROM SAM_USER_PROGRAM "
                lcCmd += "WHERE CCOMPANY_ID = '{0}' "
                lcCmd += "AND CUSER_ID = '{1}' "
                lcCmd += "AND CMENU_ID = '{2}' "
                lcCmd += "AND CSUB_MENU_TYPE = '{3}' "
                lcCmd = String.Format(lcCmd, .CCOMPANY_ID, .CUSER_ID, .CMENU_ID, "P")
                loRtn = loDb.SqlExecObjectQuery(Of SAM_USER_PROGRAMDTO)(lcCmd, loConn, False)

                If loRtn.Count = 0 Then
                    'update favourite group
                    lcCmd = "UPDATE SAM_USER_PROGRAM "
                    lcCmd += "SET CSUB_MENU_NAME = '{4}' "
                    lcCmd += "WHERE CCOMPANY_ID = '{0}' "
                    lcCmd += "AND CUSER_ID = '{1}' "
                    lcCmd += "AND CMENU_ID = '{2}' "
                    lcCmd += "AND CSUB_MENU_TYPE = '{3}' "
                    lcCmd = String.Format(lcCmd, .CCOMPANY_ID, .CUSER_ID, .CMENU_ID, "G", "Favourites")
                    loDb.SqlExecNonQuery(lcCmd, loConn, False)
                End If
            End With
        Catch ex As Exception
            loEx.Add(ex)
        Finally
            If loConn IsNot Nothing Then
                If Not (loConn.State = ConnectionState.Closed) Then
                    loConn.Close()
                End If
                loConn.Dispose()
                loConn = Nothing
            End If
        End Try

        loEx.ThrowExceptionIfErrors()
    End Sub
#End Region

    Public Function _getProgramImage(ByVal poMenuDTO As MenuDTO) As String
        Dim lcCmd As String
        Dim loResult As String
        Dim loDTO As New MenuDTO
        Dim loDb As New R_Db
        Dim loEx As New R_Exception()

        Try
            lcCmd = "SELECT CPROGRAM_BUTTON as CSUB_MENU_IMAGE "
            lcCmd += "FROM SAM_PROGRAM (NOLOCK) "
            lcCmd += "WHERE CPROGRAM_ID = '{0}' "
            lcCmd = String.Format(lcCmd, poMenuDTO.CSUB_MENU_ID.Trim)
            loDTO = loDb.SqlExecObjectQuery(Of MenuDTO)(lcCmd).FirstOrDefault

            loResult = loDTO.CSUB_MENU_IMAGE
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function getCompanyList(ByVal pcUserId As String, ByVal pcCompanyId As String) As List(Of SAM_USER_COMPANYDTO)
        Dim loEx As New R_Exception
        Dim lcCmd As String
        Dim loList As New List(Of SAM_USER_COMPANYDTO)
        Dim loDb As New R_Db

        Try
            lcCmd = "SELECT CCOMPANY_ID "
            lcCmd += "FROM SAM_USER_COMPANY A (NOLOCK) "
            lcCmd += "WHERE A.CUSER_ID = '{0}' "
            lcCmd += "AND A.CCOMPANY_ID  <> '{1}' "
            lcCmd = String.Format(lcCmd, pcUserId.Trim, pcCompanyId.Trim)

            loList = loDb.SqlExecObjectQuery(Of SAM_USER_COMPANYDTO)(lcCmd)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

        Return loList
    End Function

    Public Function getSecurity() As Boolean
        Dim llRtn As Boolean = False
        Dim lcCmd As String
        Dim loDTO As New List(Of SecurityDTO)
        Dim loDb As New R_Db
        Dim loEx As New R_Exception()
        Dim loResult As New SecurityDTO

        Try
            lcCmd = "SELECT * "
            lcCmd += "FROM GST_PARAMETER (NOLOCK) "
            lcCmd = String.Format(lcCmd)
            loDTO = loDb.SqlExecObjectQuery(Of SecurityDTO)(lcCmd)

            loResult = loDTO.Where(Function(x) x.cParameterId = "SecurityAndAccountPolicy").Select(Function(x) x).FirstOrDefault

            If loResult.cParameterValue = "bycompany" Then
                llRtn = True
            End If

        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return llRtn
    End Function

    Public Function getAccessButton(pcCompId As String, pcProgId As String) As List(Of MenuProgramAccessDTO)
        'Dim loRtn As String
        Dim loResult As New List(Of MenuProgramAccessDTO)
        Dim lcCmd As String
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception()

        Try
            lcCmd = "SELECT CPROGRAM_ACCESS_BUTTON AS CACCESS_ID, CMENU_ID "
            lcCmd += "FROM SAM_MENU_PROGRAM (NOLOCK) "
            lcCmd += "WHERE CCOMPANY_ID = '{0}' AND CPROGRAM_ID = '{1}' "
            lcCmd = String.Format(lcCmd, pcCompId, pcProgId)
            loResult = loDb.SqlExecObjectQuery(Of MenuProgramAccessDTO)(lcCmd)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()

        Return loResult
    End Function

    Public Sub SaveHistory(pcCompId As String, pcUserId As String, pcProgId As String, pcAction As String)
        Dim lcCmd As String
        Dim loEx As New R_Exception()
        Dim loDb As New R_Db

        Try
            'insert to database
            lcCmd = "INSERT INTO SAH_PROGRAM_HISTORY "
            lcCmd += "(CCOMPANY_ID, CUSER_ID, CPROGRAM_ID, CACTION, DCREATE_DATE) "
            lcCmd += "VALUES('{0}', '{1}', '{2}', '{3}', GETDATE())"
            lcCmd = String.Format(lcCmd, pcCompId, pcUserId, pcProgId, pcAction)

            loDb.SqlExecNonQuery(lcCmd)
        Catch ex As Exception
            loEx.Add(ex)
        End Try
        loEx.ThrowExceptionIfErrors()
    End Sub

End Class
