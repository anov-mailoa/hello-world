﻿Imports System.ComponentModel

Public Class LoginDTO
    Inherits R_BackEnd.R_DTOBase
    Implements INotifyPropertyChanged

    Public Property DLAST_UPDATE_PSWD As String
    Public Property CCULTURE_ID As String
    Public Property CDATE_LONG_FORMAT As String
    Public Property CDATE_SHORT_FORMAT As String
    Public Property CTIME_LONG_FORMAT As String
    Public Property CTIME_SHORT_FORMAT As String
    Public Property CNUMBER_FORMAT As String
    Public Property CREPORT_CULTURE As String
    Public Property IDECIMAL_PLACES As Integer
    Public Property IROUNDING_PLACES As Integer
    Public Property CROUNDING_METHOD As String

    Public Property LENABLE_SAVE_CONFIRMATION As Boolean

    Public Property CLICENSE_MODE As String
    Public Property NLICENSEE As Integer

    Private _CUSER_ID As String
    Private _CUSER_PASSWORD As String
    Private _CUSER_NAME As String
    Private _CCOMPANY_ID As String
    Private _CCOMPANY_NAME As String

    Public Property CUSER_PASSWORD() As String
        Get
            Return Me._CUSER_PASSWORD
        End Get
        Set(ByVal value As String)
            If Not (value = _CUSER_PASSWORD) Then
                Me._CUSER_PASSWORD = value
                NotifyPropertyChanged("CUSER_PASSWORD")
            End If
        End Set
    End Property

    Public Property CUSER_NAME() As String
        Get
            Return Me._CUSER_NAME
        End Get
        Set(ByVal value As String)
            If Not (value = _CUSER_NAME) Then
                Me._CUSER_NAME = value
                NotifyPropertyChanged("CUSER_NAME")
            End If
        End Set
    End Property

    Public Property CCOMPANY_ID() As String
        Get
            Return Me._CCOMPANY_ID
        End Get
        Set(ByVal value As String)
            If Not (value = _CCOMPANY_ID) Then
                Me._CCOMPANY_ID = value
                NotifyPropertyChanged("CCOMPANY_ID")
            End If
        End Set
    End Property

    Public Property CCOMPANY_NAME() As String
        Get
            Return Me._CCOMPANY_NAME
        End Get
        Set(ByVal value As String)
            If Not (value = _CCOMPANY_NAME) Then
                Me._CCOMPANY_NAME = value
                NotifyPropertyChanged("CCOMPANY_NAME")
            End If
        End Set
    End Property

    Public Property CUSER_ID() As String
        Get
            Return Me._CUSER_ID
        End Get
        Set(ByVal value As String)
            If Not (value = _CUSER_ID) Then
                Me._CUSER_ID = value
                NotifyPropertyChanged("CUSER_ID")
            End If
        End Set
    End Property

    Public Event PropertyChanged(ByVal sender As Object, ByVal e As System.ComponentModel.PropertyChangedEventArgs) Implements System.ComponentModel.INotifyPropertyChanged.PropertyChanged

    Private Sub NotifyPropertyChanged(ByVal info As String)
        RaiseEvent PropertyChanged(Me, New PropertyChangedEventArgs(info))
    End Sub


End Class
