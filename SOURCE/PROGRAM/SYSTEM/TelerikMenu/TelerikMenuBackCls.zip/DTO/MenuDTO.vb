﻿Public Class MenuDTO
    Private _CCOMPANY_ID As String
    Private _CUSER_ID As String
    Private _CMENU_ID As String
    Private _CMENU_NAME As String
    Private _CSUB_MENU_TYPE As String
    Private _CSUB_MENU_ID As String
    Private _CSUB_MENU_NAME As String
    Private _CSUB_MENU_TOOL_TIP As String
    Private _CSUB_MENU_IMAGE As String
    Private _CPARENT_SUB_MENU_ID As String
    Private _IGROUP_INDEX As Nullable(Of Integer)
    Private _IROW_INDEX As Nullable(Of Integer)
    Private _ICOLUMN_INDEX As Nullable(Of Integer)
    Private _LFAVORITE As Boolean
    Private _IFAVORITE_INDEX As Nullable(Of Integer)
    Private _ILEVEL As Integer

    Public Property CCOMPANY_ID As String
        Get
            Return _CCOMPANY_ID
        End Get
        Set(ByVal value As String)
            _CCOMPANY_ID = value
        End Set
    End Property

    Public Property CUSER_ID As String
        Get
            Return _CUSER_ID
        End Get
        Set(ByVal value As String)
            _CUSER_ID = value
        End Set
    End Property
    Public Property CMENU_ID As String
        Get
            Return _CMENU_ID
        End Get
        Set(ByVal value As String)
            _CMENU_ID = value
        End Set
    End Property
    Public Property CMENU_NAME As String
        Get
            Return _CMENU_NAME
        End Get
        Set(ByVal value As String)
            _CMENU_NAME = value
        End Set
    End Property
    Public Property CSUB_MENU_TYPE As String
        Get
            Return _CSUB_MENU_TYPE
        End Get
        Set(ByVal value As String)
            _CSUB_MENU_TYPE = value
        End Set
    End Property
    Public Property CSUB_MENU_ID As String
        Get
            Return _CSUB_MENU_ID
        End Get
        Set(ByVal value As String)
            _CSUB_MENU_ID = value
        End Set
    End Property
    Public Property CSUB_MENU_NAME As String
        Get
            Return _CSUB_MENU_NAME
        End Get
        Set(ByVal value As String)
            _CSUB_MENU_NAME = value
        End Set
    End Property
    Public Property CSUB_MENU_TOOL_TIP As String
        Get
            Return _CSUB_MENU_TOOL_TIP
        End Get
        Set(ByVal value As String)
            _CSUB_MENU_TOOL_TIP = value
        End Set
    End Property
    Public Property CSUB_MENU_IMAGE As String
        Get
            Return _CSUB_MENU_IMAGE
        End Get
        Set(ByVal value As String)
            _CSUB_MENU_IMAGE = value
        End Set
    End Property
    Public Property LFAVORITE As Boolean
        Get
            Return _LFAVORITE
        End Get
        Set(ByVal value As Boolean)
            _LFAVORITE = value
        End Set
    End Property
    Public Property IGROUP_INDEX As Nullable(Of Integer)
        Get
            Return _IGROUP_INDEX
        End Get
        Set(ByVal value As Nullable(Of Integer))
            _IGROUP_INDEX = value
        End Set
    End Property
    Public Property IROW_INDEX As Nullable(Of Integer)
        Get
            Return _IROW_INDEX
        End Get
        Set(ByVal value As Nullable(Of Integer))
            _IROW_INDEX = value
        End Set
    End Property
    Public Property ICOLUMN_INDEX As Nullable(Of Integer)
        Get
            Return _ICOLUMN_INDEX
        End Get
        Set(ByVal value As Nullable(Of Integer))
            _ICOLUMN_INDEX = value
        End Set
    End Property
    Public Property IFAVORITE_INDEX As Nullable(Of Integer)
        Get
            Return _IFAVORITE_INDEX
        End Get
        Set(ByVal value As Nullable(Of Integer))
            _IFAVORITE_INDEX = value
        End Set
    End Property
    Public Property CPARENT_SUB_MENU_ID As String
        Get
            Return _CPARENT_SUB_MENU_ID
        End Get
        Set(ByVal value As String)
            _CPARENT_SUB_MENU_ID = value
        End Set
    End Property
    Public Property ILEVEL() As Integer
        Get
            Return _ILEVEL
        End Get
        Set(ByVal value As Integer)
            _ILEVEL = value
        End Set
    End Property
End Class
