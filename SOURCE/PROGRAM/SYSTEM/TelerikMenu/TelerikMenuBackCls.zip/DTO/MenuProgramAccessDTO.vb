﻿Public Class MenuProgramAccessDTO
    Private _CCOMPANY_ID As String
    Private _CMENU_ID As String
    Private _CPROGRAM_ID As String
    Private _CACCESS_ID As String
    Private _CMENU_NAME As String
    Private _CPROGRAM_NAME As String
    Private _CTOOL_TIP As String

    Public Property CCOMPANY_ID As String
        Get
            Return _CCOMPANY_ID
        End Get
        Set(ByVal value As String)
            _CCOMPANY_ID = value
        End Set
    End Property
    Public Property CMENU_ID As String
        Get
            Return _CMENU_ID
        End Get
        Set(ByVal value As String)
            _CMENU_ID = value
        End Set
    End Property
    Public Property CPROGRAM_ID As String
        Get
            Return _CPROGRAM_ID
        End Get
        Set(ByVal value As String)
            _CPROGRAM_ID = value
        End Set
    End Property
    Public Property CACCESS_ID As String
        Get
            Return _CACCESS_ID
        End Get
        Set(ByVal value As String)
            _CACCESS_ID = value
        End Set
    End Property
    Public Property CMENU_NAME As String
        Get
            Return _CMENU_NAME
        End Get
        Set(ByVal value As String)
            _CMENU_NAME = value
        End Set
    End Property
    Public Property CPROGRAM_NAME As String
        Get
            Return _CPROGRAM_NAME
        End Get
        Set(ByVal value As String)
            _CPROGRAM_NAME = value
        End Set
    End Property
    Public Property CTOOL_TIP As String
        Get
            Return _CTOOL_TIP
        End Get
        Set(ByVal value As String)
            _CTOOL_TIP = value
        End Set
    End Property
End Class