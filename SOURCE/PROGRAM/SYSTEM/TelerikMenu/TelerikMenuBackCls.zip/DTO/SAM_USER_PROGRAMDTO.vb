﻿Imports R_BackEnd

<Serializable()> _
Public Class SAM_USER_PROGRAMDTO
    Inherits R_DTOBase

    Public Property CCOMPANY_ID As String
    Public Property CUSER_ID As String
    Public Property CMENU_ID As String
    Public Property CSUB_MENU_TYPE As String
    Public Property CSUB_MENU_ID As String
    Public Property IGROUP_INDEX As Integer
    Public Property IROW_INDEX As Integer
    Public Property ICOLUMN_INDEX As Integer
    Public Property LFAVORITE As Boolean
    Public Property IFAVORITE_INDEX As Integer
    Public Property CPARENT_SUB_MENU_ID As String
    Public Property ILEVEL As Integer
    Public Property CUPDATE_BY As String
    Public Property DUPDATE_DATE As Nullable(Of DateTime)
    Public Property CCREATE_BY As String
    Public Property DCREATE_DATE As Nullable(Of DateTime)
    Public Property CSUB_MENU_NAME As String
End Class
