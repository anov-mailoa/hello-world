﻿Public Class SAM_USER_COMPANYDTO
    Property CUSER_ID As String
    Property CCOMPANY_ID As String
    Property LCAN_BROADCAST As Boolean
End Class
