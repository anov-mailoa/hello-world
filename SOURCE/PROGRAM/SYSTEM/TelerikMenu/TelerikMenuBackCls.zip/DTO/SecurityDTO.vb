﻿Imports R_BackEnd

<Serializable()> _
Public Class SecurityDTO
    Inherits R_DTOBase

    Public Property cParameterId As String
    Public Property cParameterValue As String
End Class
