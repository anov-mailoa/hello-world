/****** Object:  UserDefinedFunction [dbo].[RFN_Is_Dayoff]    Script Date: 9/30/2014 1:40:21 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RFN_Is_Dayoff]') and OBJECTPROPERTY(id, N'IsScalarFunction') = 1)
DROP FUNCTION [dbo].[RFN_Is_Dayoff]
GO

/****** Object:  UserDefinedFunction [dbo].[RFN_Is_Dayoff]    Script Date: 9/30/2014 1:40:21 PM ******/
SET ANSI_NULLS OFF
GO

SET QUOTED_IDENTIFIER OFF
GO


--CREATED BY	: AV - 20160905
--PURPOSE		: RealCode Get File Path
--EXAMPLE		: 

CREATE FUNCTION [dbo].[RFN_Is_Dayoff]
(
	@DGIVEN_DATE DATE,
	@CDAYOFF_BIT_STRING CHAR(7)
)
RETURNS BIT
WITH ENCRYPTION
AS
BEGIN

	DECLARE @LIS_DAYOFF AS BIT

	DECLARE @IX AS int, @IY AS int
	DECLARE @CDAYOFF_BIT AS char(7),
		@IWEEKDAY AS int

	SELECT @IX = @@DATEFIRST, @IY = DATEPART(dw, @DGIVEN_DATE)
	-- @IWEEKDAY = absolute weekday: 0 = Monday ... 6 = Sunday
	SELECT @IWEEKDAY = (@IY + (@IX - 2)) % 7

	SELECT @LIS_DAYOFF = CASE WHEN SUBSTRING(@CDAYOFF_BIT_STRING, @IWEEKDAY + 1, 1) = '1' THEN 1 ELSE 0 END
	
	RETURN @LIS_DAYOFF

END
GO


