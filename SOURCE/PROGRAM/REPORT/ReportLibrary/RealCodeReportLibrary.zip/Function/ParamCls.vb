﻿Imports R_BackEnd
Imports R_Common

Public Class ParamCls
    Public Function GetApps(pcCompanyId As String) As List(Of Apps)
        Dim lcQuery As String
        Dim loResult As List(Of Apps)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT CAPPS_CODE, CAPPS_NAME "
            lcQuery += "FROM RVM_APPLICATION (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery = String.Format(lcQuery, pcCompanyId)
            loResult = loDb.SqlExecObjectQuery(Of Apps)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult

    End Function

    Public Function GetVersions(pcCompanyId As String, pcAppsCode As String) As List(Of Versions)
        Dim lcQuery As String
        Dim loResult As List(Of Versions)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT CVERSION, CALIAS, CCODE_NAME "
            lcQuery += "FROM RVT_APP_VERSION (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery += "AND CAPPS_CODE = '{1}' "
            lcQuery = String.Format(lcQuery, pcCompanyId, pcAppsCode)
            loResult = loDb.SqlExecObjectQuery(Of Versions)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetProjects(pcCompanyId As String, pcAppsCode As String, pcVersion As String) As List(Of Projects)
        Dim lcQuery As String
        Dim loResult As List(Of Projects)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT CPROJECT_ID, CPROJECT_NAME "
            lcQuery += "FROM CSM_PROJECTS (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery += "AND CAPPS_CODE = '{1}' "
            lcQuery += "AND CVERSION = '{2}' "
            lcQuery = String.Format(lcQuery, pcCompanyId, pcAppsCode, pcVersion)
            loResult = loDb.SqlExecObjectQuery(Of Projects)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetProgramAttributes(pcCompanyId As String, pcAppsCode As String) As List(Of Attributes)
        Dim lcQuery As String
        Dim loResult As List(Of Attributes)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT CATTRIBUTE_ID, CATTRIBUTE_NAME "
            lcQuery += "FROM CSM_ATTRIBUTES (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery += "AND CAPPS_CODE = '{1}' "
            lcQuery += "AND CATTRIBUTE_GROUP = 'PROGRAM' "
            lcQuery = String.Format(lcQuery, pcCompanyId, pcAppsCode)
            loResult = loDb.SqlExecObjectQuery(Of Attributes)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetPrograms(pcCompanyId As String, pcAppsCode As String, pcAttributeId As String) As List(Of Programs)
        Dim lcQuery As String
        Dim loResult As List(Of Programs)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            lcQuery = "SELECT CPROGRAM_ID, CPROGRAM_NAME "
            lcQuery += "FROM CSM_PROGRAMS (NOLOCK) "
            lcQuery += "WHERE CCOMPANY_ID = '{0}' "
            lcQuery += "AND CAPPS_CODE = '{1}' "
            lcQuery += "AND CATTRIBUTE_GROUP = 'PROGRAM' "
            lcQuery += "AND CATTRIBUTE_ID = '{2}' "
            lcQuery = String.Format(lcQuery, pcCompanyId, pcAppsCode, pcAttributeId)
            loResult = loDb.SqlExecObjectQuery(Of Programs)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

    Public Function GetItems(pcCompanyId As String, pcAppsCode As String, pcAttributeGroup As String, pcAttributeId As String) As List(Of Items)
        Dim lcQuery As String
        Dim loResult As List(Of Items)
        Dim loDb As New R_Db()
        Dim loEx As New R_Exception

        Try
            If pcAttributeGroup = "PROGRAM" Then
                lcQuery = "SELECT CPROGRAM_ID AS CITEM_ID, CPROGRAM_NAME AS CITEM_NAME "
                lcQuery += "FROM CSM_PROGRAMS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CATTRIBUTE_GROUP = 'PROGRAM' "
                lcQuery += "AND CATTRIBUTE_ID = '{2}' "
                lcQuery = String.Format(lcQuery, pcCompanyId, pcAppsCode, pcAttributeId)
            Else
                lcQuery = "SELECT CDOCUMENT_ID AS CITEM_ID, CDOCUMENT_NAME AS CITEM_NAME "
                lcQuery += "FROM CSM_DESIGNS (NOLOCK) "
                lcQuery += "WHERE CCOMPANY_ID = '{0}' "
                lcQuery += "AND CAPPS_CODE = '{1}' "
                lcQuery += "AND CATTRIBUTE_GROUP = 'DESIGN' "
                lcQuery += "AND CATTRIBUTE_ID = '{2}' "
            End If
            loResult = loDb.SqlExecObjectQuery(Of Items)(lcQuery)
        Catch ex As Exception
            loEx.Add(ex)
        End Try

        loEx.ThrowExceptionIfErrors()
        Return loResult
    End Function

End Class
