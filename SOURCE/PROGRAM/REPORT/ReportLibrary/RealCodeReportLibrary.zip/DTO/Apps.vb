﻿Public Class Apps
    Public Property CAPPS_CODE As String
    Public Property CAPPS_NAME As String
End Class
