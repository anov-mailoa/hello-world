﻿Public Class Versions
    Public Property CVERSION As String
    Public Property CALIAS As String
    Public Property CCODE_NAME As String
End Class
