﻿Public Class Programs
    Public Property CPROGRAM_ID As String
    Public Property CPROGRAM_NAME As String
End Class
