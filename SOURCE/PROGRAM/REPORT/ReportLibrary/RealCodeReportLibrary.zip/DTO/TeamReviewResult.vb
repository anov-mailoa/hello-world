﻿Public Class TeamReviewResult
    Public Property CPROJECT_ID As String
    Public Property CPROJECT_NAME As String
    Public Property CDESCRIPTION As String
    Public Property CSESSION_ID As String
    Public Property CSESSION_NOTE As String
    Public Property CSCHEDULE_ID As String
    Public Property CSCHEDULE_NOTE As String
    Public Property CSCHEDULE_TYPE As String
    Public Property CSCHEDULE_TYPE_NAME As String
    Public Property CATTRIBUTE_GROUP As String
    Public Property CATTRIBUTE_ID As String
    Public Property CITEM_ID As String
    Public Property CITEM_NAME As String
    Public Property CFUNCTION_ID As String
    Public Property CUSER_ID As String
    Public Property CUSER_NAME As String
    Public Property CREASSIGNMENT_ID As String
    Public Property CREASSIGNMENT_NAME As String
    Public Property CLOCATION_ID As String
    Public Property NMANDAYS As Decimal
    Public Property DPLAN_START_DATE As Date
    Public Property DPLAN_END_DATE As Date
End Class
