﻿Public Class ProgramProfileResult
    Public Property CATTRIBUTE_ID As String
    Public Property CPROGRAM_ID As String
    Public Property CPROGRAM_NAME As String
    Public Property CPROGRAM_DESCRIPTION As String
    Public Property LSPEC As Boolean
    Public Property CINITIAL_VERSION As String
    Public Property CSOURCE_ID As String
    Public Property CSOURCE_DESCRIPTION As String
    Public Property CSPEC_PATH As String
    Public Property CSOURCE_PATH As String
    Public Property CSINGLE_SOURCE_FILE As String
    Public Property CBUILD_PATH As String
End Class
