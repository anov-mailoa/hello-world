﻿Public Class CheckinHistoryResult
    Public Property CPROJECT_ID As String
    Public Property CPROJECT_NAME As String
    Public Property CSESSION_ID As String
    Public Property CSESSION_NOTE As String
    Public Property CSCHEDULE_ID As String
    Public Property CSCHEDULE_NOTE As String
    Public Property DACTION_DATE As Date
    Public Property CACTION_TIME As String
    Public Property CFUNCTION_ID As String
    Public Property CUSER_ID As String
    Public Property CUSER_NAME As String
    Public Property CACTION As String
End Class
