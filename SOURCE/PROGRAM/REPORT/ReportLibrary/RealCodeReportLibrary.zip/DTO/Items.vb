﻿Public Class Items
    Public Property CITEM_ID As String
    Public Property CITEM_NAME As String
End Class
