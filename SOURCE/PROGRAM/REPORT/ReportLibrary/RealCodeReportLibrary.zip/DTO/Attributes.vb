﻿Public Class Attributes
    Public Property CATTRIBUTE_ID As String
    Public Property CATTRIBUTE_NAME As String
End Class
