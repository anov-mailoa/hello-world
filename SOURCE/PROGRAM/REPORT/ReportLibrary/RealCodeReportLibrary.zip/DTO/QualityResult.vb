﻿Public Class QualityResult
    Public Property CSESSION_ID As String
    Public Property CSESSION_NOTE As String
    Public Property CATTRIBUTE_GROUP As String
    Public Property CATTRIBUTE_ID As String
    Public Property CITEM_ID As String
    Public Property CITEM_NAME As String
    Public Property CUSER_ID As String
    Public Property CUSER_NAME As String
    Public Property CISSUE_TYPE As String
    Public Property CISSUE_CLASS As String
    Public Property NISSUE_COUNT As Integer
End Class
