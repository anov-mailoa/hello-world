/****** Object:  UserDefinedFunction [dbo].[RFN_Get_Current_Version]    Script Date: 9/30/2014 1:40:21 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RFN_Get_Current_Version]') and OBJECTPROPERTY(id, N'IsScalarFunction') = 1)
DROP FUNCTION [dbo].[RFN_Get_Current_Version]
GO

/****** Object:  UserDefinedFunction [dbo].[RFN_Get_Current_Version]    Script Date: 9/30/2014 1:40:21 PM ******/
SET ANSI_NULLS OFF
GO

SET QUOTED_IDENTIFIER OFF
GO


--CREATED BY	: AV - 20160905
--PURPOSE		: RealCode Get Current Version
--EXAMPLE		: 

CREATE FUNCTION [dbo].[RFN_Get_Current_Version]
(
	@CCOMPANY_ID VARCHAR(8),
	@CAPPS_CODE VARCHAR(20)
)
RETURNS VARCHAR(15)
WITH ENCRYPTION
AS
BEGIN

	DECLARE @CVERSION VARCHAR(15)

	SELECT @CVERSION = MAX(CVERSION)
	FROM RVT_APP_VERSION (NOLOCK) 
	WHERE CCOMPANY_ID = @CCOMPANY_ID 
		AND CAPPS_CODE = @CAPPS_CODE 
		AND CSTATUS IN ('OPEN','RELEASED')
		
	RETURN @CVERSION

END
GO


