/****** Object:  UserDefinedFunction [dbo].[RFN_Truncate_With_Ellipsis]    Script Date: 9/30/2014 1:40:21 PM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RFN_Truncate_With_Ellipsis]') and OBJECTPROPERTY(id, N'IsScalarFunction') = 1)
DROP FUNCTION [dbo].[RFN_Truncate_With_Ellipsis]
GO

/****** Object:  UserDefinedFunction [dbo].[RFN_Truncate_With_Ellipsis]    Script Date: 9/30/2014 1:40:21 PM ******/
SET ANSI_NULLS OFF
GO

SET QUOTED_IDENTIFIER OFF
GO


--CREATED BY	: AV - 20180302
--PURPOSE		: Truncate with ellipsis
--EXAMPLE		: SELECT dbo.RFN_Truncate_With_Ellipsis(CDESCRIPTION, 20)

CREATE FUNCTION [dbo].[RFN_Truncate_With_Ellipsis]
(
	@CSTRING NVARCHAR(MAX),
	@IMAX_LENGTH INT
)
RETURNS NVARCHAR(MAX)
WITH ENCRYPTION
AS
BEGIN

	RETURN	CASE WHEN LEN(LTRIM(RTRIM(@CSTRING))) > @IMAX_LENGTH
					THEN LEFT(@CSTRING, @IMAX_LENGTH - 1) + '�'
				 ELSE @CSTRING
			END

END
GO


